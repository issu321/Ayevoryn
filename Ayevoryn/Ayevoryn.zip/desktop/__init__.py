"""Ayevoryn Windows Desktop Runtime Package (USMANIA TECHS PVT LTD)."""
from desktop.version import APP_NAME, APP_VERSION, PUBLISHER, EXECUTABLE_NAME

__all__ = ['APP_NAME', 'APP_VERSION', 'PUBLISHER', 'EXECUTABLE_NAME']
