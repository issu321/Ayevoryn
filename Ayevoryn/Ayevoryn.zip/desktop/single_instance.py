"""
Single-Instance Guard for Ayevoryn Desktop (USMANIA TECHS PVT LTD).
Uses a Windows named mutex on Windows 10/11 and a PID lockfile fallback on POSIX systems
to prevent conflicting duplicate application instances.
"""
import os
from pathlib import Path
from typing import Optional

from desktop.paths import ensure_user_data_dirs

MUTEX_NAME = 'Local\\UsmaniaTechs_Ayevoryn_Desktop_Mutex_v2'


class SingleInstanceGuard:
    """Context-managed single-instance lock."""

    def __init__(self):
        self._mutex_handle: Optional[int] = None
        self._lock_file: Optional[Path] = None
        self.acquired: bool = False

    def acquire(self) -> bool:
        if os.name == 'nt':
            try:
                import ctypes
                kernel32 = ctypes.windll.kernel32
                handle = kernel32.CreateMutexW(None, False, MUTEX_NAME)
                last_error = kernel32.GetLastError()
                ERROR_ALREADY_EXISTS = 183
                if not handle:
                    return True  # Fail-open only if OS mutex API unavailable
                if last_error == ERROR_ALREADY_EXISTS:
                    kernel32.CloseHandle(handle)
                    self.acquired = False
                    return False
                self._mutex_handle = handle
                self.acquired = True
                return True
            except Exception:
                pass

        # POSIX / fallback PID lockfile
        lock_path = ensure_user_data_dirs()['config'] / 'ayevoryn.pid'
        if lock_path.exists():
            try:
                old_pid = int(lock_path.read_text(encoding='utf-8').strip())
                if old_pid > 0 and old_pid != os.getpid():
                    os.kill(old_pid, 0)
                    self.acquired = False
                    return False
            except (ValueError, OSError):
                pass  # Stale lockfile
        try:
            lock_path.write_text(str(os.getpid()), encoding='utf-8')
            self._lock_file = lock_path
            self.acquired = True
        except Exception:
            self.acquired = True
        return True

    def release(self) -> None:
        if self._mutex_handle is not None and os.name == 'nt':
            try:
                import ctypes
                ctypes.windll.kernel32.CloseHandle(self._mutex_handle)
            except Exception:
                pass
            self._mutex_handle = None
        if self._lock_file is not None:
            try:
                if self._lock_file.exists():
                    self._lock_file.unlink(missing_ok=True)
            except Exception:
                pass
            self._lock_file = None
        self.acquired = False
