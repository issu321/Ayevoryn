"""
Centralized Ayevoryn Product & Release Version Metadata (USMANIA TECHS PVT LTD).
Single source of truth for the desktop runtime, About page, PyInstaller version info, and Inno Setup installer.
"""

APP_NAME = 'Ayevoryn'
APP_DISPLAY_NAME = 'Ayevoryn Enterprise Intelligence'
APP_VERSION = '2.0.0'
APP_VERSION_TUPLE = (2, 0, 0, 0)
PUBLISHER = 'USMANIA TECHS PVT LTD'
PUBLISHER_DIR = 'UsmaniaTechs'
COPYRIGHT_YEAR = '2026'
COPYRIGHT_NOTICE = f'Copyright (c) {COPYRIGHT_YEAR} {PUBLISHER}. All rights reserved.'
EXECUTABLE_NAME = 'Ayevoryn.exe'
INSTALLER_NAME = 'Ayevoryn_Setup.exe'
APP_USER_MODEL_ID = 'UsmaniaTechs.Ayevoryn.Desktop'
