"""
Frozen-Safe Resource & Persistent Windows User Data Path Manager (USMANIA TECHS PVT LTD).
Separates read-only packaged application resources (templates, static, migrations, icons)
from writable persistent user data under %LOCALAPPDATA%\\UsmaniaTechs\\Ayevoryn\\.
Never stores active SQLite databases, uploads, or exports inside temporary PyInstaller folders
or read-only Program Files directories.
"""
import os
import secrets
import shutil
import sqlite3
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict

from desktop.version import APP_NAME, PUBLISHER_DIR


def is_frozen() -> bool:
    """Return True when running inside a PyInstaller frozen executable."""
    return bool(getattr(sys, 'frozen', False) and hasattr(sys, '_MEIPASS'))


def get_bundle_root() -> Path:
    """Return the read-only root directory containing templates, static, migrations, and assets."""
    if is_frozen():
        return Path(sys._MEIPASS).resolve()
    return Path(__file__).resolve().parent.parent


def get_install_root() -> Path:
    """Return the directory containing Ayevoryn.exe (or repository root in dev mode)."""
    if is_frozen():
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def get_user_data_root() -> Path:
    """
    Return the writable persistent user data root.
    Windows: %LOCALAPPDATA%\\UsmaniaTechs\\Ayevoryn
    Other OS: ~/.local/share/UsmaniaTechs/Ayevoryn
    Overridable via AYEVORYN_DATA_DIR for enterprise/IT deployments or tests.
    """
    override = os.environ.get('AYEVORYN_DATA_DIR', '').strip()
    if override:
        root = Path(override).expanduser().resolve()
    elif os.name == 'nt':
        base = os.environ.get('LOCALAPPDATA') or os.environ.get('APPDATA') or str(Path.home() / 'AppData' / 'Local')
        root = Path(base) / PUBLISHER_DIR / APP_NAME
    else:
        xdg = os.environ.get('XDG_DATA_HOME') or str(Path.home() / '.local' / 'share')
        root = Path(xdg) / PUBLISHER_DIR / APP_NAME
    root.mkdir(parents=True, exist_ok=True)
    return root


def ensure_user_data_dirs() -> Dict[str, Path]:
    """Create and return all persistent writable subdirectories under the user data root."""
    root = get_user_data_root()
    dirs = {
        'root': root,
        'data': root / 'data',
        'instance': root / 'instance',
        'uploads': root / 'uploads',
        'avatars': root / 'uploads' / 'avatars',
        'logos': root / 'uploads' / 'logos',
        'exports': root / 'exports',
        'reports': root / 'reports',
        'logs': root / 'logs',
        'backups': root / 'backups',
        'config': root / 'config',
    }
    for p in dirs.values():
        p.mkdir(parents=True, exist_ok=True)
    return dirs


def get_database_path() -> Path:
    """Return the persistent SQLite database file path in user data."""
    return ensure_user_data_dirs()['data'] / 'ayevoryn.db'


def get_icon_path() -> Path:
    """Return the packaged Ayevoryn.ico path."""
    candidates = [
        get_bundle_root() / 'packaging' / 'assets' / 'Ayevoryn.ico',
        get_install_root() / 'packaging' / 'assets' / 'Ayevoryn.ico',
        get_bundle_root() / 'static' / 'favicon.ico',
    ]
    for c in candidates:
        if c.exists():
            return c
    return candidates[0]


def get_or_create_secret_key() -> str:
    """
    Persist a cryptographically strong per-installation Flask SECRET_KEY in user config
    so desktop sessions survive application restarts without hardcoding secrets in the binary.
    """
    env_key = os.environ.get('SECRET_KEY', '').strip()
    if env_key and len(env_key) >= 24 and 'change-in-production' not in env_key:
        return env_key

    key_file = ensure_user_data_dirs()['config'] / 'session_secret.key'
    if key_file.exists():
        stored = key_file.read_text(encoding='utf-8').strip()
        if len(stored) >= 32:
            return stored

    generated = secrets.token_hex(32)
    key_file.write_text(generated, encoding='utf-8')
    try:
        os.chmod(key_file, 0o600)
    except Exception:
        pass
    return generated


def backup_database_if_exists(reason: str = 'upgrade', max_backups: int = 10):
    """
    Safely back up the active SQLite database using sqlite3 online backup API
    before migrations or upgrades, retaining the newest `max_backups` files.
    Returns backup Path or None if no database exists yet.
    """
    db_path = get_database_path()
    if not db_path.exists() or db_path.stat().st_size == 0:
        return None

    backups_dir = ensure_user_data_dirs()['backups']
    stamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    safe_reason = ''.join(c for c in reason if c.isalnum() or c in ('-', '_')) or 'backup'
    dest = backups_dir / f'ayevoryn_{safe_reason}_{stamp}.db'

    try:
        with sqlite3.connect(str(db_path)) as src_conn, sqlite3.connect(str(dest)) as dst_conn:
            src_conn.backup(dst_conn)
    except Exception:
        shutil.copy2(db_path, dest)

    # Prune oldest backups beyond max_backups
    existing = sorted(backups_dir.glob('ayevoryn_*.db'), key=lambda p: p.stat().st_mtime, reverse=True)
    for old in existing[max_backups:]:
        try:
            old.unlink(missing_ok=True)
        except Exception:
            pass
    return dest


def load_user_env_file() -> None:
    """Load optional user-level configuration from %LOCALAPPDATA%\\UsmaniaTechs\\Ayevoryn\\config\\.env."""
    env_file = ensure_user_data_dirs()['config'] / '.env'
    if not env_file.exists():
        return
    try:
        for raw_line in env_file.read_text(encoding='utf-8').splitlines():
            line = raw_line.strip()
            if not line or line.startswith('#') or '=' not in line:
                continue
            key, val = line.split('=', 1)
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val
    except Exception:
        pass


def apply_desktop_environment() -> Dict[str, Path]:
    """
    Configure process environment variables so Flask, SQLAlchemy, uploads, and exports
    run cleanly against the persistent Windows user data directory.
    """
    dirs = ensure_user_data_dirs()
    load_user_env_file()

    db_uri = 'sqlite:///' + get_database_path().as_posix()
    os.environ['AYEVORYN_DESKTOP_MODE'] = '1'
    os.environ.setdefault('FLASK_ENV', 'production')
    os.environ['FLASK_DEBUG'] = '0'
    os.environ['SESSION_COOKIE_SECURE'] = 'false'  # Loopback http://127.0.0.1 desktop runtime
    os.environ.setdefault('DATABASE_URL', db_uri)
    os.environ.setdefault('UPLOAD_FOLDER', str(dirs['uploads']))
    os.environ.setdefault('AYEVORYN_EXPORT_DIR', str(dirs['exports']))
    os.environ.setdefault('AYEVORYN_LOG_DIR', str(dirs['logs']))
    os.environ['SECRET_KEY'] = get_or_create_secret_key()
    return dirs
