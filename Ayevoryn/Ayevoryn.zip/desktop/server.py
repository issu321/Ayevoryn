"""
Managed Loopback-Only Production WSGI Server for Ayevoryn Desktop (USMANIA TECHS PVT LTD).
Runs the existing Flask application via Waitress on 127.0.0.1 with dynamic free-port selection,
health-check readiness verification, and deterministic graceful shutdown on window close.
"""
import logging
import socket
import threading
import time
import urllib.request
from typing import Optional

logger = logging.getLogger('ayevoryn.desktop.server')

LOOPBACK_HOST = '127.0.0.1'
DEFAULT_PREFERRED_PORT = 5179


def find_available_port(host: str = LOOPBACK_HOST, preferred: int = DEFAULT_PREFERRED_PORT) -> int:
    """Return `preferred` if unbound on loopback, otherwise allocate a free ephemeral port."""
    for candidate in (preferred, 0):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            try:
                s.bind((host, candidate))
                return int(s.getsockname()[1])
            except OSError:
                continue
    raise RuntimeError('Unable to bind any local loopback port for Ayevoryn backend.')


class LocalBackendServer:
    """Lifecycle manager for the local Waitress WSGI server hosting the Ayevoryn Flask app."""

    def __init__(self, wsgi_app, host: str = LOOPBACK_HOST, preferred_port: int = DEFAULT_PREFERRED_PORT, threads: int = 8):
        self.wsgi_app = wsgi_app
        self.host = host
        self.port = find_available_port(host=host, preferred=preferred_port)
        self.threads = threads
        self._server = None
        self._thread: Optional[threading.Thread] = None
        self._startup_error: Optional[BaseException] = None
        self._stopped = threading.Event()

    @property
    def base_url(self) -> str:
        return f'http://{self.host}:{self.port}'

    @property
    def startup_error(self) -> Optional[BaseException]:
        return self._startup_error

    def start(self) -> None:
        """Start Waitress in a background thread bound strictly to 127.0.0.1."""
        def _run():
            try:
                from waitress import create_server
                self._server = create_server(
                    self.wsgi_app,
                    host=self.host,
                    port=self.port,
                    threads=self.threads,
                    ident='Ayevoryn-Desktop',
                    channel_timeout=120,
                )
                logger.info('Ayevoryn local backend listening on %s', self.base_url)
                self._server.run()
            except ImportError:
                # Fallback to Werkzeug threaded server only in dev when waitress is not installed
                from werkzeug.serving import make_server
                self._server = make_server(self.host, self.port, self.wsgi_app, threaded=True)
                logger.warning('Waitress not installed; using Werkzeug loopback fallback on %s', self.base_url)
                self._server.serve_forever()
            except BaseException as exc:
                if not self._stopped.is_set():
                    self._startup_error = exc
                    logger.exception('Ayevoryn local backend failed: %s', exc)

        self._thread = threading.Thread(target=_run, name='AyevorynBackendThread', daemon=True)
        self._thread.start()

    def wait_until_ready(self, timeout_seconds: float = 25.0) -> bool:
        """Poll /health on loopback until HTTP 200 or timeout/error."""
        deadline = time.monotonic() + timeout_seconds
        health_url = f'{self.base_url}/health'
        while time.monotonic() < deadline:
            if self._startup_error is not None:
                return False
            try:
                with urllib.request.urlopen(health_url, timeout=1.5) as resp:
                    if resp.status == 200:
                        return True
            except Exception:
                time.sleep(0.2)
        return False

    def stop(self) -> None:
        """Gracefully shut down the local WSGI server so no orphan process remains."""
        self._stopped.set()
        if self._server is not None:
            try:
                if hasattr(self._server, 'close'):
                    self._server.close()
                elif hasattr(self._server, 'shutdown'):
                    self._server.shutdown()
            except Exception as exc:
                logger.warning('Error during backend shutdown: %s', exc)
            self._server = None
        if self._thread is not None and self._thread.is_alive():
            self._thread.join(timeout=3.0)
