"""
Ayevoryn Windows Desktop Application Entry Point (USMANIA TECHS PVT LTD).
Orchestrates:
  1. Single-instance mutex check
  2. Persistent Windows user data directory initialization (%LOCALAPPDATA%\\UsmaniaTechs\\Ayevoryn)
  3. Rotating secret-redacted file logging
  4. Safe pre-startup SQLite backup (preserving all user data across upgrades)
  5. Loopback-only Waitress WSGI backend startup
  6. Native PyWebView desktop window lifecycle & clean shutdown
"""
import atexit
import logging
import logging.handlers
import os
import sys
from pathlib import Path

from desktop.paths import (
    apply_desktop_environment,
    backup_database_if_exists,
    get_bundle_root,
)
from desktop.server import LocalBackendServer
from desktop.single_instance import SingleInstanceGuard
from desktop.version import APP_NAME, APP_VERSION, PUBLISHER
from desktop.window import launch_native_window


def _configure_desktop_logging(log_dir: Path) -> logging.Logger:
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / 'ayevoryn_desktop.log'
    root_logger = logging.getLogger()
    root_logger.setLevel(logging.INFO)

    handler = logging.handlers.RotatingFileHandler(
        str(log_file), maxBytes=5 * 1024 * 1024, backupCount=5, encoding='utf-8'
    )
    handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(name)s: %(message)s'))
    root_logger.addHandler(handler)

    try:
        from security.log_sanitizer import install_secret_redacting_filter
        install_secret_redacting_filter(root_logger)
    except Exception:
        pass
    return logging.getLogger('ayevoryn.desktop')


def _notify_already_running() -> None:
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.user32.MessageBoxW(
                0,
                f'{APP_NAME} is already running. Check your Windows taskbar.',
                f'{APP_NAME} — {PUBLISHER}',
                0x40,
            )
        except Exception:
            pass


def main() -> int:
    # Ensure bundle root is importable in frozen or installed mode
    bundle_root = str(get_bundle_root())
    if bundle_root not in sys.path:
        sys.path.insert(0, bundle_root)

    dirs = apply_desktop_environment()
    logger = _configure_desktop_logging(dirs['logs'])
    logger.info('Launching %s Desktop v%s (%s)', APP_NAME, APP_VERSION, PUBLISHER)

    guard = SingleInstanceGuard()
    if not guard.acquire():
        logger.info('Duplicate desktop instance detected; exiting cleanly.')
        _notify_already_running()
        return 0

    atexit.register(guard.release)

    # Create a safe online SQLite backup before app/migrations run (if DB already exists)
    try:
        backup_path = backup_database_if_exists(reason='startup')
        if backup_path:
            logger.info('Created pre-startup database backup: %s', backup_path.name)
    except Exception as exc:
        logger.warning('Pre-startup backup skipped: %s', exc)

    # Import Flask application factory after desktop environment variables are set
    try:
        from app import create_app
        flask_app = create_app()
    except BaseException as exc:
        logger.exception('Fatal error initializing %s backend: %s', APP_NAME, exc)
        if os.name == 'nt':
            try:
                import ctypes
                ctypes.windll.user32.MessageBoxW(
                    0,
                    f'{APP_NAME} failed to start:\n\n{exc}\n\nSee diagnostic log at:\n{dirs["logs"] / "ayevoryn_desktop.log"}',
                    f'{APP_NAME} Startup Error — {PUBLISHER}',
                    0x10,
                )
            except Exception:
                pass
        guard.release()
        return 1

    server = LocalBackendServer(flask_app)
    server.start()

    def _shutdown():
        logger.info('Shutting down %s local backend...', APP_NAME)
        server.stop()
        guard.release()

    atexit.register(_shutdown)

    launch_native_window(
        backend_url=server.base_url,
        wait_ready_fn=lambda: server.wait_until_ready(timeout_seconds=25.0),
        get_error_fn=lambda: str(server.startup_error or ''),
        on_close_fn=_shutdown,
    )
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
