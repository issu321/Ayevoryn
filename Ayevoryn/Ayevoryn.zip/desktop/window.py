"""
Native Desktop Window Wrapper for Ayevoryn (USMANIA TECHS PVT LTD).
Uses PyWebView (Edge WebView2 on Windows 10/11) to host Ayevoryn inside a native window
with custom icon, branded loading state, clean error recovery, and deterministic backend shutdown.
"""
import html
import logging
import os
import threading
import webbrowser
from typing import Callable

from desktop.paths import ensure_user_data_dirs, get_icon_path
from desktop.version import APP_NAME, APP_USER_MODEL_ID, APP_VERSION, COPYRIGHT_NOTICE, PUBLISHER

logger = logging.getLogger('ayevoryn.desktop.window')


def _set_windows_app_id() -> None:
    """Register Windows AppUserModelID so taskbar pins & groups Ayevoryn with its custom icon."""
    if os.name != 'nt':
        return
    try:
        import ctypes
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
    except Exception:
        pass


def build_splash_html() -> str:
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{APP_NAME}</title>
<style>
  html, body {{
    margin: 0; height: 100%; background: #0B1120; color: #F8FAFC;
    font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
    display: flex; align-items: center; justify-content: center; user-select: none;
  }}
  .card {{ text-align: center; max-width: 420px; padding: 36px; }}
  .mark {{
    width: 64px; height: 64px; margin: 0 auto 20px; border-radius: 16px;
    background: linear-gradient(135deg, #1E293B, #0F172A);
    border: 1px solid rgba(96, 165, 250, 0.35);
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 12px 30px rgba(0, 0, 0, 0.45);
  }}
  .mark svg {{ width: 38px; height: 38px; }}
  h1 {{ margin: 0 0 8px; font-size: 1.5rem; font-weight: 700; letter-spacing: 0.02em; }}
  p {{ margin: 0 0 22px; color: #94A3B8; font-size: 0.92rem; }}
  .bar {{ height: 4px; width: 220px; margin: 0 auto; background: #1E293B; border-radius: 99px; overflow: hidden; }}
  .bar span {{
    display: block; height: 100%; width: 42%; background: #3B82F6; border-radius: 99px;
    animation: slide 1.2s ease-in-out infinite;
  }}
  .foot {{ margin-top: 28px; font-size: 0.74rem; color: #64748B; }}
  @keyframes slide {{ 0% {{ transform: translateX(-100%); }} 100% {{ transform: translateX(260%); }} }}
</style>
</head>
<body>
  <div class="card">
    <div class="mark">
      <svg viewBox="0 0 100 100" fill="none">
        <polygon points="46,16 56,16 32,82 22,82" stroke="#E2E8F0" stroke-width="4" fill="#172033"/>
        <polygon points="56,16 78,82 68,82 50,30" stroke="#60A5FA" stroke-width="4" fill="#131D33"/>
      </svg>
    </div>
    <h1>{APP_NAME}</h1>
    <p>Starting local enterprise intelligence engine...</p>
    <div class="bar"><span></span></div>
    <div class="foot">v{APP_VERSION} &middot; {PUBLISHER}</div>
  </div>
</body>
</html>"""


def build_error_html(message: str, log_dir: str) -> str:
    safe_msg = html.escape(message or 'Unknown startup error')
    safe_log = html.escape(log_dir)
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>{APP_NAME} — Startup Error</title>
<style>
  html, body {{
    margin: 0; height: 100%; background: #0B1120; color: #F8FAFC;
    font-family: 'Segoe UI', system-ui, sans-serif;
    display: flex; align-items: center; justify-content: center;
  }}
  .box {{
    max-width: 540px; background: #111827; border: 1px solid #334155;
    border-radius: 12px; padding: 28px 32px; box-shadow: 0 20px 45px rgba(0,0,0,0.5);
  }}
  h1 {{ margin: 0 0 10px; font-size: 1.25rem; color: #F87171; }}
  p {{ color: #CBD5E1; font-size: 0.92rem; line-height: 1.5; }}
  code {{ display: block; background: #0B1120; padding: 10px 12px; border-radius: 6px; color: #93C5FD; font-size: 0.82rem; word-break: break-all; margin: 12px 0; }}
  .foot {{ margin-top: 18px; font-size: 0.76rem; color: #64748B; }}
</style>
</head>
<body>
  <div class="box">
    <h1>{APP_NAME} could not start cleanly</h1>
    <p>{safe_msg}</p>
    <p>Diagnostic logs are saved in:</p>
    <code>{safe_log}</code>
    <p>Your local database and business records have not been modified. Close this window and relaunch {APP_NAME}.</p>
    <div class="foot">{COPYRIGHT_NOTICE}</div>
  </div>
</body>
</html>"""


def launch_native_window(
    backend_url: str,
    wait_ready_fn: Callable[[], bool],
    get_error_fn: Callable[[], str],
    on_close_fn: Callable[[], None],
) -> None:
    """Launch PyWebView native window with splash screen, transitioning to backend_url once healthy."""
    _set_windows_app_id()
    dirs = ensure_user_data_dirs()
    storage_dir = str(dirs['instance'] / 'webview_storage')
    os.makedirs(storage_dir, exist_ok=True)
    icon_path = str(get_icon_path())

    try:
        import webview
    except ImportError:
        logger.warning('pywebview not installed; waiting for backend and opening default browser.')
        if wait_ready_fn():
            webbrowser.open(backend_url)
        return

    window = webview.create_window(
        title=APP_NAME,
        html=build_splash_html(),
        width=1360,
        height=860,
        min_size=(1024, 680),
        resizable=True,
        text_select=True,
        confirm_close=False,
    )

    def _on_closing():
        try:
            on_close_fn()
        except Exception as exc:
            logger.warning('Shutdown callback error: %s', exc)

    window.events.closing += _on_closing

    def _bootstrap_navigation():
        if wait_ready_fn():
            window.load_url(backend_url)
        else:
            err = get_error_fn() or 'The local Ayevoryn backend did not respond in time.'
            window.load_html(build_error_html(err, str(dirs['logs'])))

    def _on_loaded():
        threading.Thread(target=_bootstrap_navigation, name='AyevorynNavBootstrap', daemon=True).start()

    start_kwargs = {
        'func': _on_loaded,
        'private_mode': False,
        'storage_path': storage_dir,
        'debug': False,
    }
    if os.name == 'nt':
        start_kwargs['gui'] = 'edgechromium'
    if os.path.exists(icon_path):
        start_kwargs['icon'] = icon_path

    try:
        webview.start(**start_kwargs)
    except TypeError:
        # Older pywebview versions may not accept `icon` kwarg on start()
        start_kwargs.pop('icon', None)
        webview.start(**start_kwargs)
    finally:
        _on_closing()
