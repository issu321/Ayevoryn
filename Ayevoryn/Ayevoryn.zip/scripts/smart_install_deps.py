#!/usr/bin/env python3
"""
Ayevoryn Smart Python-Version Dependency Mapper & Installer (USMANIA TECHS PVT LTD)
Reads requirements.txt, detects the active Python MAJOR.MINOR version and OS,
maps every dependency to 100% compatible prebuilt-wheel specs, installs cleanly
with --prefer-binary, and verifies all core runtime modules import successfully.
"""
import importlib
import os
import platform
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REQ_FILE = ROOT / 'requirements.txt'

# Core modules required for Ayevoryn to boot and run all web + AI features
CORE_PACKAGES = {
    'flask', 'flask-sqlalchemy', 'flask-wtf', 'flask-login', 'flask-mail',
    'flask-caching', 'flask-migrate', 'wtforms', 'sqlalchemy', 'werkzeug',
    'jinja2', 'markupsafe', 'itsdangerous', 'bcrypt', 'pyjwt', 'pillow',
    'openpyxl', 'xlsxwriter', 'reportlab', 'qrcode', 'python-dateutil',
    'requests', 'bleach', 'python-dotenv', 'apscheduler',
}

# Optional / OS-specific / heavy scientific packages installed resiliently (never block app launch)
OPTIONAL_PACKAGES = {
    'numpy', 'pandas', 'scikit-learn', 'plotly', 'tablib', 'prophet',
    'psycopg2-binary', 'gunicorn', 'waitress', 'pypdf',
}

CORE_IMPORT_CHECKS = [
    ('flask', 'Flask'),
    ('flask_sqlalchemy', 'Flask-SQLAlchemy'),
    ('flask_login', 'Flask-Login'),
    ('flask_wtf', 'Flask-WTF'),
    ('sqlalchemy', 'SQLAlchemy'),
    ('bcrypt', 'bcrypt'),
    ('requests', 'requests'),
    ('openpyxl', 'openpyxl'),
    ('reportlab', 'reportlab'),
    ('PIL', 'Pillow'),
    ('dotenv', 'python-dotenv'),
    ('apscheduler', 'APScheduler'),
]


def normalize_pkg_name(raw_line: str) -> str:
    line = raw_line.split('#', 1)[0].strip()
    if not line:
        return ''
    for sep in ('==', '>=', '<=', '~=', '!=', '>', '<', ';', '['):
        if sep in line:
            line = line.split(sep, 1)[0].strip()
    return line.lower().replace('_', '-')


def map_spec_for_python(pkg: str, py_ver: tuple, is_windows: bool) -> str:
    """Return a Python-version & OS compatible pip requirement spec with prebuilt wheels."""
    major, minor = py_ver

    # Skip Unix-only gunicorn on Windows; use waitress instead
    if pkg == 'gunicorn' and is_windows:
        return ''

    # Version-aware pinning for scientific & C-extension packages across Python 3.9 -> 3.14+
    if (major, minor) <= (3, 9):
        py39_map = {
            'flask': 'Flask>=2.3,<3.2',
            'flask-sqlalchemy': 'Flask-SQLAlchemy>=3.0,<3.2',
            'sqlalchemy': 'SQLAlchemy>=2.0,<2.1',
            'werkzeug': 'Werkzeug>=2.3,<3.2',
            'numpy': 'numpy>=1.24,<2.1',
            'pandas': 'pandas>=2.0,<2.3',
            'scikit-learn': 'scikit-learn>=1.3,<1.7',
            'pillow': 'Pillow>=10.0,<12.0',
            'bcrypt': 'bcrypt>=4.0,<5.0',
        }
        return py39_map.get(pkg, pkg)

    if (major, minor) in ((3, 10), (3, 11)):
        py310_map = {
            'flask': 'Flask>=3.0,<3.2',
            'flask-sqlalchemy': 'Flask-SQLAlchemy>=3.1,<3.2',
            'sqlalchemy': 'SQLAlchemy>=2.0,<2.1',
            'numpy': 'numpy>=1.26,<2.3',
            'pandas': 'pandas>=2.1,<2.4',
            'scikit-learn': 'scikit-learn>=1.4,<1.7',
            'pillow': 'Pillow>=10.2',
            'bcrypt': 'bcrypt>=4.1',
        }
        return py310_map.get(pkg, pkg)

    if (major, minor) == (3, 12):
        py312_map = {
            'flask': 'Flask>=3.0',
            'flask-sqlalchemy': 'Flask-SQLAlchemy>=3.1',
            'sqlalchemy': 'SQLAlchemy>=2.0.25',
            'numpy': 'numpy>=1.26.4',
            'pandas': 'pandas>=2.2.0',
            'scikit-learn': 'scikit-learn>=1.4.2',
            'pillow': 'Pillow>=10.3.0',
            'bcrypt': 'bcrypt>=4.1.2',
        }
        return py312_map.get(pkg, pkg)

    # Python 3.13 / 3.14+: require modern wheels that support 3.13+ C-API
    py313_plus_map = {
        'flask': 'Flask>=3.0.3',
        'flask-sqlalchemy': 'Flask-SQLAlchemy>=3.1.1',
        'sqlalchemy': 'SQLAlchemy>=2.0.36',
        'numpy': 'numpy>=2.1.0',
        'pandas': 'pandas>=2.2.3',
        'scikit-learn': 'scikit-learn>=1.5.2',
        'pillow': 'Pillow>=11.0.0',
        'bcrypt': 'bcrypt>=4.2.0',
        'reportlab': 'reportlab>=4.2.5',
    }
    return py313_plus_map.get(pkg, pkg)


def run_pip(args: list, allow_break_system: bool = False) -> int:
    cmd = [sys.executable, '-m', 'pip'] + args
    res = subprocess.run(cmd, cwd=str(ROOT))
    if res.returncode != 0 and allow_break_system and '--break-system-packages' not in args:
        cmd2 = [sys.executable, '-m', 'pip'] + args + ['--break-system-packages']
        res = subprocess.run(cmd2, cwd=str(ROOT))
    return res.returncode


def main() -> int:
    py_ver = (sys.version_info.major, sys.version_info.minor)
    py_str = f"{py_ver[0]}.{py_ver[1]}.{sys.version_info.micro}"
    os_name = platform.system()
    is_windows = os_name.lower() == 'windows'
    in_venv = (sys.prefix != getattr(sys, 'base_prefix', sys.prefix))
    allow_break = (not in_venv) and (not is_windows)

    print("==================================================================")
    print("  AYEVORYN — Enterprise Digital Twin & Pulse AI Platform")
    print("  Publisher: USMANIA TECHS PVT LTD")
    print(f"  Detected Python: {py_str} ({os_name}) | Venv: {'Yes' if in_venv else 'System'}")
    print("==================================================================")

    if py_ver < (3, 9):
        print(f"[ERROR] Python {py_str} is too old. Please install Python 3.9 or newer.")
        return 1

    # 1. Read & deduplicate requirements.txt
    raw_pkgs = []
    seen = set()
    if REQ_FILE.exists():
        for line in REQ_FILE.read_text(encoding='utf-8').splitlines():
            p = normalize_pkg_name(line)
            if p and p not in seen:
                seen.add(p)
                raw_pkgs.append(p)
    # Ensure pypdf is included for PDF attachment analysis & waitress on Windows
    for extra in ('pypdf', 'waitress' if is_windows else 'gunicorn'):
        if extra not in seen:
            seen.add(extra)
            raw_pkgs.append(extra)

    core_specs = []
    opt_specs = []
    for p in raw_pkgs:
        spec = map_spec_for_python(p, py_ver, is_windows)
        if not spec:
            continue
        if p in CORE_PACKAGES:
            core_specs.append(spec)
        else:
            opt_specs.append(spec)

    print(f"[1/4] Upgrading pip/wheel for Python {py_ver[0]}.{py_ver[1]}...")
    run_pip(['install', '--upgrade', 'pip', 'setuptools', 'wheel', '--quiet'], allow_break_system=allow_break)

    print(f"[2/4] Installing {len(core_specs)} core Ayevoryn modules (prebuilt wheels preferred)...")
    rc = run_pip(['install', '--prefer-binary', '--upgrade'] + core_specs, allow_break_system=allow_break)
    if rc != 0:
        print("[WARN] Batch core install encountered an issue; retrying package-by-package...")
        for spec in core_specs:
            run_pip(['install', '--prefer-binary', spec], allow_break_system=allow_break)

    print(f"[3/4] Installing {len(opt_specs)} analytics & optional modules for Python {py_ver[0]}.{py_ver[1]}...")
    for spec in opt_specs:
        # On Python 3.13+, skip prophet if binary wheel is unavailable so install stays fast & clean
        if spec.lower().startswith('prophet') and py_ver >= (3, 13):
            print("  -> Skipping 'prophet' on Python 3.13+ (Ayevoryn uses built-in forecasting engine).")
            continue
        rc_opt = run_pip(['install', '--prefer-binary', '--only-binary=:all:', spec, '--quiet'], allow_break_system=allow_break)
        if rc_opt != 0 and not spec.lower().startswith(('prophet', 'psycopg2')):
            run_pip(['install', '--prefer-binary', spec, '--quiet'], allow_break_system=allow_break)

    print("[4/4] Verifying core runtime imports...")
    missing = []
    for mod_name, label in CORE_IMPORT_CHECKS:
        try:
            importlib.import_module(mod_name)
            print(f"  [OK] {label}")
        except Exception as exc:
            print(f"  [FAIL] {label}: {exc}")
            missing.append(label)

    if missing:
        print(f"[ERROR] Missing required modules after install: {', '.join(missing)}")
        return 1

    print("[SUCCESS] All Ayevoryn core dependencies verified 100% ready!")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
