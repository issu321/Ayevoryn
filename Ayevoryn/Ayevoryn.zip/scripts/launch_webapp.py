#!/usr/bin/env python3
"""
Ayevoryn Silent Web App Auto-Launcher (USMANIA TECHS PVT LTD)
Starts app.py detached in the background (no blocking terminal window),
waits until http://127.0.0.1:5000 is accepting HTTP requests, and
immediately opens the Ayevoryn web application in the default browser.
"""
import os
import platform
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APP_URL = os.environ.get('AYEVORYN_URL', 'http://127.0.0.1:5000')
LOG_DIR = ROOT / 'logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / 'ayevoryn_server.log'


def is_server_alive(url: str, timeout: float = 1.2) -> bool:
    try:
        req = urllib.request.Request(url, method='GET')
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return 200 <= resp.status < 500
    except Exception:
        return False


def start_background_server() -> None:
    if is_server_alive(APP_URL):
        return

    is_windows = platform.system().lower() == 'windows'
    py_exec = sys.executable

    if is_windows:
        # Prefer pythonw.exe on Windows so NO console/terminal window stays open!
        pyw = Path(py_exec).with_name('pythonw.exe')
        if pyw.exists():
            py_exec = str(pyw)

    env = os.environ.copy()
    env.setdefault('FLASK_DEBUG', '0')
    env.setdefault('PYTHONUNBUFFERED', '1')

    log_fh = open(LOG_FILE, 'ab')
    if is_windows:
        DETACHED_PROCESS = 0x00000008
        CREATE_NEW_PROCESS_GROUP = 0x00000200
        CREATE_NO_WINDOW = 0x08000000
        subprocess.Popen(
            [py_exec, str(ROOT / 'app.py')],
            cwd=str(ROOT),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
            creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP | CREATE_NO_WINDOW,
            close_fds=True,
        )
    else:
        subprocess.Popen(
            [py_exec, str(ROOT / 'app.py')],
            cwd=str(ROOT),
            env=env,
            stdin=subprocess.DEVNULL,
            stdout=log_fh,
            stderr=log_fh,
            start_new_session=True,
            close_fds=True,
        )


def open_browser(url: str) -> None:
    is_linux = platform.system().lower() == 'linux'
    if is_linux:
        sudo_user = os.environ.get('SUDO_USER')
        for opener in ('xdg-open', 'sensible-browser', 'firefox', 'chromium', 'google-chrome'):
            try:
                res = subprocess.run(['which', opener], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode == 0:
                    cmd = ['su', '-', sudo_user, '-c', f"{opener} '{url}' >/dev/null 2>&1 &"] if (sudo_user and os.geteuid() == 0) else [opener, url]
                    subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, start_new_session=True)
                    return
            except Exception:
                continue
        return
    if False:
        for opener in ('xdg-open',):
            try:
                res = subprocess.run(['which', opener], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
                if res.returncode == 0:
                    subprocess.Popen(
                        [opener, url],
                        stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL,
                        start_new_session=True,
                    )
                    return
            except Exception:
                continue
    try:
        webbrowser.open(url, new=2)
    except Exception:
        pass


def main() -> int:
    start_background_server()
    deadline = time.monotonic() + 28.0
    while time.monotonic() < deadline:
        if is_server_alive(APP_URL):
            open_browser(APP_URL)
            return 0
        time.sleep(0.5)
    # Even if startup took slightly longer, open the URL so browser catches it immediately
    open_browser(APP_URL)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
