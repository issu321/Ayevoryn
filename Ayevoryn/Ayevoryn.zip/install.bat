@echo off
setlocal EnableExtensions
title AYEVORYN Installer - USMANIA TECHS PVT LTD
cd /d "%~dp0"

echo ========================================================================
echo   AYEVORYN - Enterprise Digital Twin ^& Pulse AI Platform
echo   Publisher: USMANIA TECHS PVT LTD
echo   Windows Automated Setup (Direct System Python - No Venv Required)
echo ========================================================================
echo.

REM Detect Python on Windows (python or py launcher)
set "PY_CMD="
where python >nul 2>&1
if %ERRORLEVEL%==0 (
    set "PY_CMD=python"
) else (
    where py >nul 2>&1
    if %ERRORLEVEL%==0 (
        set "PY_CMD=py -3"
    )
)

if "%PY_CMD%"=="" (
    echo [ERROR] Python 3.9+ was not found in PATH.
    echo Please install Python from https://www.python.org/downloads/ and check "Add Python to PATH".
    pause
    exit /b 1
)

for /f "tokens=1" %%V in ('%PY_CMD% -c "import sys; print(sys.version.split()[0])"') do set "PY_VER=%%V"
echo [Ayevoryn] Detected Windows Python %PY_VER%
echo [Ayevoryn] Mapping ^& installing 100%% compatible modules from requirements.txt...
echo.

%PY_CMD% "%~dp0scripts\smart_install_deps.py"
if errorlevel 1 (
    echo.
    echo [ERROR] Dependency verification failed. Please check your internet connection and retry.
    pause
    exit /b 1
)

echo.
echo [Ayevoryn] Launching Ayevoryn Web Application automatically in your browser...
%PY_CMD% "%~dp0scripts\launch_webapp.py"
exit /b 0
