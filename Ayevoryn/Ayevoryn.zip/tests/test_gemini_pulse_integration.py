"""
Tests for Pulse AI Google Gemini integration:
- Supports AQ.* Google AI Studio Auth Keys via native x-goog-api-key header (never Bearer).
- Automatic fallback to Vertex AI Express host when AQ.* key gets 401/403 on AI Studio host.
- Automatic model fallback across gemini-2.5-flash -> gemini-2.0-flash -> gemini-2.5-flash-lite.
- Resolves API keys from both environment variables and DB platform_settings.
"""

import io
import json
import urllib.error
from unittest.mock import patch, MagicMock

from services.pulse_ai_engine import PulseAIProviderManager


def _mock_urlopen_response(payload_dict):
    resp = MagicMock()
    resp.read.return_value = json.dumps(payload_dict).encode('utf-8')
    resp.__enter__.return_value = resp
    resp.__exit__.return_value = False
    return resp


def test_gemini_uses_x_goog_api_key_header_for_aq_keys():
    captured_requests = []

    def fake_urlopen(req, timeout=24):
        captured_requests.append(req)
        return _mock_urlopen_response({
            'candidates': [{'content': {'parts': [{'text': 'Real company answer: ₹100,000.00 liquid reserves.'}]}}],
            'usageMetadata': {'totalTokenCount': 42}
        })

    with patch('urllib.request.urlopen', side_effect=fake_urlopen):
        text, model, tokens, err = PulseAIProviderManager._call_gemini_endpoint(
            api_key='AQ.test_key_12345',
            model='gemini-2.5-flash',
            system_prompt='System context with company data',
            messages=[{'role': 'user', 'content': 'What are our liquid reserves?'}]
        )

    assert err is None
    assert '100,000.00' in text
    assert model == 'gemini-2.5-flash'
    assert tokens == 42
    assert len(captured_requests) == 1
    req = captured_requests[0]
    assert 'generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent' in req.full_url
    assert req.get_header('X-goog-api-key') == 'AQ.test_key_12345'
    assert req.get_header('Authorization') is None


def test_gemini_aq_key_falls_back_to_vertex_express_on_403():
    urls_called = []

    def fake_urlopen(req, timeout=24):
        urls_called.append(req.full_url)
        if 'generativelanguage.googleapis.com' in req.full_url:
            raise urllib.error.HTTPError(req.full_url, 403, 'Forbidden', {}, io.BytesIO(b'{"error":"SERVICE_BLOCKED"}'))
        return _mock_urlopen_response({
            'candidates': [{'content': {'parts': [{'text': 'PULSE_AI_GEMINI_ONLINE'}]}}],
            'usageMetadata': {'totalTokenCount': 12}
        })

    with patch('urllib.request.urlopen', side_effect=fake_urlopen):
        text, model, tokens, err = PulseAIProviderManager._call_gemini_endpoint(
            api_key='AQ.vertex_express_key',
            model='gemini-2.5-flash',
            system_prompt='Test',
            messages=[{'role': 'user', 'content': 'ping'}]
        )

    assert err is None
    assert text == 'PULSE_AI_GEMINI_ONLINE'
    assert any('generativelanguage.googleapis.com' in u for u in urls_called)
    assert any('aiplatform.googleapis.com/v1/publishers/google/models/gemini-2.5-flash:generateContent' in u for u in urls_called)


def test_gemini_model_fallback_on_404():
    models_called = []

    def fake_urlopen(req, timeout=24):
        models_called.append(req.full_url)
        if 'gemini-2.5-flash:' in req.full_url:
            raise urllib.error.HTTPError(req.full_url, 404, 'Not Found', {}, io.BytesIO(b'{}'))
        return _mock_urlopen_response({
            'candidates': [{'content': {'parts': [{'text': 'Fallback model OK'}]}}],
            'usageMetadata': {'totalTokenCount': 15}
        })

    with patch('urllib.request.urlopen', side_effect=fake_urlopen):
        text, model, tokens, err = PulseAIProviderManager._call_gemini_endpoint(
            api_key='AIza_test_key',
            model='gemini-2.5-flash',
            system_prompt='Test',
            messages=[{'role': 'user', 'content': 'hello'}]
        )

    assert err is None
    assert text == 'Fallback model OK'
    assert model == 'gemini-2.0-flash'
