"""
Ayevoryn Windows Desktop Productization & Packaging Verification Suite (USMANIA TECHS PVT LTD).
Tests all desktop runtime modules, persistent data/backup behavior, loopback port conflict handling,
multi-size Windows icon assets, PyInstaller spec, and Inno Setup installer configuration.
"""
import compileall
import os
import socket
import sqlite3
import tempfile
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent


class TestDesktopRuntimeModules(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self._old_data_dir = os.environ.get('AYEVORYN_DATA_DIR')
        self._old_secret = os.environ.get('SECRET_KEY')
        os.environ['AYEVORYN_DATA_DIR'] = self._tmp.name
        os.environ.pop('SECRET_KEY', None)

    def tearDown(self):
        if self._old_data_dir is None:
            os.environ.pop('AYEVORYN_DATA_DIR', None)
        else:
            os.environ['AYEVORYN_DATA_DIR'] = self._old_data_dir
        if self._old_secret is None:
            os.environ.pop('SECRET_KEY', None)
        else:
            os.environ['SECRET_KEY'] = self._old_secret
        self._tmp.cleanup()

    def test_version_metadata(self):
        from desktop import version
        self.assertEqual(version.APP_NAME, 'Ayevoryn')
        self.assertEqual(version.EXECUTABLE_NAME, 'Ayevoryn.exe')
        self.assertEqual(version.INSTALLER_NAME, 'Ayevoryn_Setup.exe')
        self.assertEqual(version.PUBLISHER, 'USMANIA TECHS PVT LTD')

    def test_persistent_dirs_secret_key_and_sqlite_backup(self):
        from desktop import paths

        dirs = paths.apply_desktop_environment()
        for k in ('data', 'uploads', 'exports', 'logs', 'backups', 'config', 'instance'):
            self.assertTrue(dirs[k].exists(), f"Missing persistent dir: {k}")

        self.assertEqual(os.environ.get('AYEVORYN_DESKTOP_MODE'), '1')
        self.assertEqual(os.environ.get('FLASK_DEBUG'), '0')

        # Secret key persists across calls
        k1 = paths.get_or_create_secret_key()
        os.environ.pop('SECRET_KEY', None)
        k2 = paths.get_or_create_secret_key()
        self.assertEqual(k1, k2)
        self.assertGreaterEqual(len(k1), 32)

        # Create real SQLite DB and verify online backup works without modifying source
        db_file = paths.get_database_path()
        with sqlite3.connect(str(db_file)) as conn:
            conn.execute('CREATE TABLE items (id INTEGER PRIMARY KEY, name TEXT)')
            conn.execute("INSERT INTO items (name) VALUES ('Usmania Record')")
            conn.commit()

        bkp = paths.backup_database_if_exists(reason='test')
        self.assertIsNotNone(bkp)
        self.assertTrue(bkp.exists())
        with sqlite3.connect(str(bkp)) as conn:
            rows = conn.execute('SELECT name FROM items').fetchall()
        self.assertEqual(rows, [('Usmania Record',)])

    def test_single_instance_guard(self):
        from desktop.single_instance import SingleInstanceGuard
        g = SingleInstanceGuard()
        self.assertTrue(g.acquire())
        g.release()
        self.assertFalse(g.acquired)

    def test_loopback_port_conflict_fallback(self):
        from desktop.server import find_available_port
        # Occupy a port on 127.0.0.1 and verify find_available_port picks a different free port
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as blocker:
            blocker.bind(('127.0.0.1', 0))
            blocker.listen(1)
            busy_port = blocker.getsockname()[1]
            chosen = find_available_port(host='127.0.0.1', preferred=busy_port)
            self.assertNotEqual(chosen, busy_port)
            self.assertGreater(chosen, 0)

    def test_window_splash_and_error_html(self):
        from desktop.window import build_splash_html, build_error_html
        splash = build_splash_html()
        self.assertIn('Ayevoryn', splash)
        self.assertIn('USMANIA TECHS PVT LTD', splash)
        err = build_error_html('<script>bad</script>', 'C:\\Logs')
        self.assertNotIn('<script>bad</script>', err)
        self.assertIn('&lt;script&gt;bad&lt;/script&gt;', err)


class TestWindowsBrandingAndPackagingFiles(unittest.TestCase):
    def test_icon_and_wizard_assets(self):
        assets = ROOT / 'packaging' / 'assets'
        ico = assets / 'Ayevoryn.ico'
        master = assets / 'Ayevoryn_master_1024.png'
        svg = assets / 'Ayevoryn_icon.svg'
        sidebar = assets / 'wizard_sidebar.bmp'
        small = assets / 'wizard_small.bmp'
        favicon = ROOT / 'static' / 'favicon.ico'

        for p in (ico, master, svg, sidebar, small, favicon):
            self.assertTrue(p.exists(), f"Missing asset: {p}")

        with Image.open(ico) as im:
            sizes = sorted(im.info.get('sizes', []))
            self.assertEqual(sizes, [(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])

        with Image.open(master) as im:
            self.assertEqual(im.size, (1024, 1024))
            self.assertEqual(im.mode, 'RGBA')

        with Image.open(sidebar) as im:
            self.assertEqual(im.size, (164, 314))
        with Image.open(small) as im:
            self.assertEqual(im.size, (55, 58))

    def test_pyinstaller_spec_and_inno_setup_integrity(self):
        spec = (ROOT / 'packaging' / 'Ayevoryn.spec').read_text(encoding='utf-8')
        self.assertIn("name='Ayevoryn'", spec)
        self.assertIn('console=False', spec)
        self.assertIn('Ayevoryn.ico', spec)
        self.assertIn('version_info.txt', spec)
        self.assertIn("'desktop' / 'entry.py'", spec)
        self.assertNotIn('business_simulator.db', spec)

        vinfo = (ROOT / 'packaging' / 'version_info.txt').read_text(encoding='utf-8')
        self.assertIn('USMANIA TECHS PVT LTD', vinfo)
        self.assertIn('Ayevoryn.exe', vinfo)

        iss = (ROOT / 'packaging' / 'installer.iss').read_text(encoding='utf-8')
        self.assertIn('#define MyAppName "Ayevoryn"', iss)
        self.assertIn('#define MyAppPublisher "USMANIA TECHS PVT LTD"', iss)
        self.assertIn('#define MyAppExeName "Ayevoryn.exe"', iss)
        self.assertIn('OutputBaseFilename=Ayevoryn_Setup', iss)
        self.assertIn('PrivilegesRequired=lowest', iss)
        self.assertIn('assets\\Ayevoryn.ico', iss)
        self.assertIn('assets\\wizard_sidebar.bmp', iss)
        self.assertIn('assets\\wizard_small.bmp', iss)

        bat = (ROOT / 'build_windows.bat').read_text(encoding='utf-8')
        self.assertIn('Ayevoryn.spec', bat)
        self.assertIn('installer.iss', bat)
        self.assertIn('verify_build.bat', bat)

    def test_desktop_package_compiles_cleanly(self):
        self.assertTrue(compileall.compile_dir(str(ROOT / 'desktop'), quiet=1))



    def test_app_py_no_duplicate_flask_kwargs_and_no_double_init(self):
        import ast
        app_src = (ROOT / 'app.py').read_text(encoding='utf-8')
        tree = ast.parse(app_src)
        flask_calls = []
        for node in ast.walk(tree):
            if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'Flask':
                flask_calls.append(node)
        self.assertEqual(len(flask_calls), 1, "Expected exactly one Flask(...) constructor call in app.py")
        call = flask_calls[0]
        explicit_kw = [kw.arg for kw in call.keywords if kw.arg is not None]
        has_starstar = any(kw.arg is None for kw in call.keywords)
        # If **kwargs is passed, template_folder/static_folder must NOT also be passed as explicit keywords
        if has_starstar:
            self.assertNotIn('template_folder', explicit_kw, "Duplicate template_folder risk with **kwargs")
            self.assertNotIn('static_folder', explicit_kw, "Duplicate static_folder risk with **kwargs")
        self.assertIn('_is_desktop_runtime', app_src, "app.py must skip eager module-level create_app() in desktop/frozen mode")

        cfg_src = (ROOT / 'config' / 'settings.py').read_text(encoding='utf-8')
        self.assertIn("os.environ.get('UPLOAD_FOLDER')", cfg_src, "UPLOAD_FOLDER must honor desktop env override")


if __name__ == '__main__':
    unittest.main(verbosity=2)

    def test_branded_windows_and_kali_installers(self):
        root = Path(__file__).resolve().parent.parent
        inst_bat = (root / 'install.bat').read_text(encoding='utf-8')
        run_bat = (root / 'run.bat').read_text(encoding='utf-8').strip()
        inst_sh = (root / 'install.sh').read_text(encoding='utf-8')
        self.assertEqual(run_bat, 'python app.py')
        self.assertIn('USMANIA TECHS PVT LTD', inst_bat)
        self.assertNotIn('-m venv', inst_bat)
        self.assertIn('smart_install_deps.py', inst_bat)
        self.assertIn('launch_webapp.py', inst_bat)
        self.assertIn('USMANIA TECHS PVT LTD', inst_sh)
        self.assertIn('python3 -m venv .venv', inst_sh)
        self.assertIn('smart_install_deps.py', inst_sh)
        self.assertIn('launch_webapp.py', inst_sh)
        import importlib.util
        spec = importlib.util.spec_from_file_location('smart_deps', root / 'scripts' / 'smart_install_deps.py')
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        self.assertEqual(mod.map_spec_for_python('gunicorn', (3, 12), is_windows=True), '')
        self.assertIn('>=2.1', mod.map_spec_for_python('numpy', (3, 13), is_windows=False))
        self.assertIn('>=4.2', mod.map_spec_for_python('bcrypt', (3, 13), is_windows=True))

