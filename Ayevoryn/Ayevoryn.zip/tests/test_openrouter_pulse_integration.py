"""
Tests for Pulse AI OpenRouter integration:
- Semantic reranking via POST https://openrouter.ai/api/v1/rerank with nvidia/nemotron-3.5-rerank-8b:free.
- Real conversational chat via POST https://openrouter.ai/api/v1/chat/completions with NVIDIA Nemotron 3.5 free models & openrouter/free fallback.
- Safe handling when a rerank model ID is passed to chat (auto-maps to nvidia/nemotron-3.5-lightning:free).
- Strips <think>...</think> reasoning tags cleanly.
"""

import io
import json
import urllib.error
from unittest.mock import patch, MagicMock

from services.pulse_ai_engine import PulseAIProviderManager


def _mock_urlopen_response(payload_dict):
    resp = MagicMock()
    resp.read.return_value = json.dumps(payload_dict).encode('utf-8')
    resp.__enter__.return_value = resp
    resp.__exit__.return_value = False
    return resp


def test_openrouter_rerank_uses_nemotron_3_5_rerank_8b():
    captured = []

    def fake_urlopen(req, timeout=10):
        captured.append(req)
        return _mock_urlopen_response({
            'results': [
                {'index': 1, 'relevance_score': 0.95},
                {'index': 0, 'relevance_score': 0.22},
            ]
        })

    sections = [
        {'name': 'inventory', 'text': 'Warehouse SKUs'},
        {'name': 'financials', 'text': '30d revenue and profit'},
    ]
    with patch('urllib.request.urlopen', side_effect=fake_urlopen):
        ordered, used, model_used = PulseAIProviderManager.rerank_context_sections(
            query='What is our 30 day revenue?',
            sections=sections,
            api_key='sk-or-v1-test',
            model='nvidia/nemotron-3.5-rerank-8b:free'
        )

    assert used is True
    assert model_used == 'nvidia/nemotron-3.5-rerank-8b:free'
    assert ordered[0]['name'] == 'financials'
    assert captured[0].full_url == 'https://openrouter.ai/api/v1/rerank'
    assert captured[0].get_header('Authorization') == 'Bearer sk-or-v1-test'


def test_openrouter_chat_handles_rerank_slug_and_strips_think_tags():
    captured_payloads = []

    def fake_urlopen(req, timeout=30):
        captured_payloads.append(json.loads(req.data.decode('utf-8')))
        return _mock_urlopen_response({
            'model': 'nvidia/nemotron-3.5-lightning:free',
            'choices': [{'message': {'content': '<think>internal reasoning</think>Your liquid reserves are ₹100,000.00.'}}],
            'usage': {'total_tokens': 55}
        })

    with patch('urllib.request.urlopen', side_effect=fake_urlopen):
        text, model_used, tokens, err = PulseAIProviderManager._call_openrouter_endpoint(
            api_key='sk-or-v1-test',
            model='nvidia/nemotron-3.5-rerank-8b:free',
            system_prompt='Company data',
            messages=[{'role': 'user', 'content': 'What is our cash balance?'}]
        )

    assert err is None
    assert text == 'Your liquid reserves are ₹100,000.00.'
    assert model_used == 'nvidia/nemotron-3.5-lightning:free'
    assert captured_payloads[0]['model'] == 'nvidia/nemotron-3.5-lightning:free'


def test_openrouter_chat_falls_back_to_openrouter_free_on_429():
    called_models = []

    def fake_urlopen(req, timeout=30):
        payload = json.loads(req.data.decode('utf-8'))
        called_models.append(payload['model'])
        if payload['model'] != 'openrouter/free':
            raise urllib.error.HTTPError(req.full_url, 429, 'Rate Limited', {}, io.BytesIO(b'{}'))
        return _mock_urlopen_response({
            'model': 'openrouter/free',
            'choices': [{'message': {'content': 'Fallback free model response OK'}}],
            'usage': {'total_tokens': 25}
        })

    with patch('urllib.request.urlopen', side_effect=fake_urlopen):
        text, model_used, tokens, err = PulseAIProviderManager._call_openrouter_endpoint(
            api_key='sk-or-v1-test',
            model='nvidia/nemotron-3.5-lightning:free',
            system_prompt='Company data',
            messages=[{'role': 'user', 'content': 'Hello'}]
        )

    assert err is None
    assert text == 'Fallback free model response OK'
    assert model_used == 'openrouter/free'
    assert 'openrouter/free' in called_models
