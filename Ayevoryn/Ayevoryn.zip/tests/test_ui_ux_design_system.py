"""
Ayevoryn Full Enterprise UI/UX Transformation Verification Suite (USMANIA TECHS PVT LTD).
Verifies:
  - Unified Light Mode (soft white + sky blue) & Dark Mode (deep navy + sky blue) tokens
  - Hover/contrast safety, dark-mode white-leak prevention, focus-visible & prefers-reduced-motion
  - Enterprise Chart.js & Plotly theme/tooltip/ResizeObserver engine (ayevoryn_charts.js)
  - Universal integration across all 14 standalone/base templates (covering all 94 templates)
  - Clean Jinja2 parsing across ALL 94 templates in templates/
"""
import glob
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class TestEnterpriseUIUXDesignSystem(unittest.TestCase):
    def test_design_system_tokens_and_accessibility(self):
        css = (ROOT / 'static' / 'css' / 'ayevoryn_design_system.css').read_text(encoding='utf-8')
        for token in (
            '--brand: #38BDF8',
            '--bg: #F5F9FD',
            '--bg-secondary: #EDF5FB',
            '--text-primary: #172B3A',
            '--border: #E3ECF4',
            '--brand: #56C8FF',
            '--bg: #0A111B',
            '--surface: #142131',
            '--text-primary: #EAF3FC',
            '--border: #26394D',
            ':focus-visible',
            'prefers-reduced-motion: reduce',
            '.ayevoryn-skeleton',
        ):
            self.assertIn(token, css, f"Missing design system token/rule: {token}")

        # Balanced CSS braces check
        self.assertEqual(css.count('{'), css.count('}'), "Unbalanced braces in ayevoryn_design_system.css")

    def test_chart_engine_integrity(self):
        js = (ROOT / 'static' / 'js' / 'ayevoryn_charts.js').read_text(encoding='utf-8')
        for sym in ('safePctChange', 'formatCompactNumber', 'createAreaGradient', 'syncAllChartsToTheme', 'ResizeObserver', 'ayevoryn:themechange'):
            self.assertIn(sym, js, f"Missing chart engine symbol: {sym}")
        self.assertEqual(js.count('{'), js.count('}'), "Unbalanced braces in ayevoryn_charts.js")

    def test_all_standalone_and_base_templates_wired(self):
        pages = [
            'templates/base.html',
            'templates/superadmin/base.html',
            'templates/superadmin/force_password_change.html',
            'templates/superadmin/mfa_verify.html',
            'templates/auth/login.html',
            'templates/auth/register.html',
            'templates/landing/index.html',
            'templates/landing/features.html',
            'templates/landing/architecture.html',
            'templates/landing/decision_models.html',
            'templates/landing/dependency_intelligence.html',
            'templates/landing/about.html',
            'templates/landing/privacy.html',
            'templates/landing/terms.html',
        ]
        for rel in pages:
            txt = (ROOT / rel).read_text(encoding='utf-8')
            self.assertIn('ayevoryn_design_system.css', txt, f"Design system not linked in {rel}")
            self.assertIn('favicon.ico', txt, f"Favicon not linked in {rel}")

        base_txt = (ROOT / 'templates' / 'base.html').read_text(encoding='utf-8')
        self.assertIn('ayevoryn_charts.js', base_txt)
        self.assertIn('ayevoryn:themechange', base_txt)
        self.assertNotIn('#FF9900', base_txt, "Legacy AWS orange progress bar should be replaced with Ayevoryn sky-blue")

    def test_all_94_jinja2_templates_parse_cleanly(self):
        try:
            from jinja2 import Environment
        except ImportError:
            self.skipTest('jinja2 not installed')
        env = Environment()
        all_templates = sorted(glob.glob(str(ROOT / 'templates' / '**' / '*.html'), recursive=True))
        self.assertGreaterEqual(len(all_templates), 90)
        for tpath in all_templates:
            src = Path(tpath).read_text(encoding='utf-8', errors='ignore')
            env.parse(src)



    def test_zero_legacy_theme_bleed_and_ui_emojis(self):
        import re
        dash = (ROOT / 'templates' / 'dashboard.html').read_text(encoding='utf-8')
        self.assertNotIn('⚡', dash)
        self.assertNotRegex(dash, re.compile(r'background(?:-color)?\s*:\s*(?:#fff(?:fff)?|white)\b', re.I))

        sup = (ROOT / 'templates' / 'business_twin' / 'twin_suppliers.html').read_text(encoding='utf-8')
        self.assertNotIn('★', sup)

        # Verify zero legacy purple/black primary tokens in CSS files
        legacy = re.compile(r'#(?:6366F1|4F46E5|7C3AED|8B5CF6|2563EB|0A0B0E|11141E)\b', re.I)
        for css_p in (ROOT / 'static' / 'css').glob('*.css'):
            txt = css_p.read_text(encoding='utf-8')
            self.assertEqual(legacy.findall(txt), [], f"Legacy purple/black hex found in {css_p.name}")

        # Verify backend theme engine uses Ayevoryn Light & Ayevoryn Dark
        themes_py = (ROOT / 'config' / 'themes.py').read_text(encoding='utf-8')
        self.assertIn("'name': 'Ayevoryn Light'", themes_py)
        self.assertIn("'name': 'Ayevoryn Dark'", themes_py)
        self.assertIn('#F7FAFC', themes_py)
        self.assertIn('#0B1120', themes_py)



    def test_zero_fabricated_chart_fallbacks_and_signature_area_chart(self):
        dash = (ROOT / 'templates' / 'dashboard.html').read_text(encoding='utf-8')
        self.assertNotIn('[48, 32, 14, 6]', dash, "Hardcoded fake revenueMixChart values must be removed")
        self.assertNotIn("name: 'Sales & Mktg'", dash, "Hardcoded fake fallback departments must be removed")
        self.assertNotIn('1 + 0.015 * i', dash, "Synthetic unit economics ramp must be removed")
        self.assertIn("fill: 'tozeroy'", dash, "Dashboard P&L chart must use smooth area/line style")
        self.assertIn('revenue_mix', dash, "Revenue mix chart must bind real backend revenue_mix")

        dr = (ROOT / 'routes' / 'dashboard.py').read_text(encoding='utf-8')
        self.assertIn('revenue_mix=revenue_mix', dr)

        ao = (ROOT / 'templates' / 'analytics' / 'analytics_overview.html').read_text(encoding='utf-8')
        self.assertNotIn('budget: 500000, spent: 102020', ao, "Fake department fallback in analytics_overview must be removed")
        self.assertIn('renderEmptyState', ao)



    def test_premium_glass_v2_and_motion_engine(self):
        css = (ROOT / 'static' / 'css' / 'ayevoryn_design_system.css').read_text(encoding='utf-8')
        for tok in ('#F7FAFC', '#EFF6FF', '#0B1120', '#101B2D', '#172235', '#60A5FA', '.ayev-progress-ring', '.ayev-chart-enter', 'min-height: 44px'):
            self.assertIn(tok, css, f"Missing Premium Glass UI V2 token/rule: {tok}")

        mjs = (ROOT / 'static' / 'js' / 'ayevoryn_motion_v2.js').read_text(encoding='utf-8')
        for sym in ('parseFormattedNumber', 'animateCounterElement', 'initCircularProgressRings', 'initChartRevealAnimations', 'prefers-reduced-motion', 'aria-label', 'stroke-dashoffset'):
            self.assertIn(sym, mjs, f"Missing motion v2 symbol: {sym}")
        self.assertEqual(mjs.count('{'), mjs.count('}'), "Unbalanced braces in ayevoryn_motion_v2.js")

        for rel in ('templates/base.html', 'templates/superadmin/base.html', 'templates/landing/index.html'):
            self.assertIn('ayevoryn_motion_v2.js', (ROOT / rel).read_text(encoding='utf-8'))

        themes_py = (ROOT / 'config' / 'themes.py').read_text(encoding='utf-8')
        self.assertIn('#F7FAFC', themes_py)
        self.assertIn('#0B1120', themes_py)



    def test_dashboard_no_func_shadow_and_ambient_bgs_and_footer(self):
        import ast
        dr_src = (ROOT / 'routes' / 'dashboard.py').read_text(encoding='utf-8')
        tree = ast.parse(dr_src)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == 'index':
                for sub in ast.walk(node):
                    if isinstance(sub, ast.ImportFrom) and sub.module == 'sqlalchemy':
                        names = [a.name for a in sub.names]
                        self.assertNotIn('func', names, "Local `from sqlalchemy import func` shadows module-level func and causes UnboundLocalError!")
        self.assertIn("FinancialRecord.transaction_type == 'revenue'", dr_src)

        css = (ROOT / 'static' / 'css' / 'ayevoryn_design_system.css').read_text(encoding='utf-8')
        self.assertIn('ambient_bg_light_hq.jpg', css)
        self.assertIn('ambient_bg_dark_hq.jpg', css)

        about = (ROOT / 'templates' / 'landing' / 'about.html').read_text(encoding='utf-8')
        self.assertNotIn('rgba(15,23,42,0.7)', about, "About page must not hardcode dark boxes in light mode")
        self.assertIn('aevoryn_theme', about)

        base = (ROOT / 'templates' / 'base.html').read_text(encoding='utf-8')
        self.assertIn('padding-right:210px', base, "Footer must clear the bottom-right Pulse AI floating button")


if __name__ == '__main__':
    unittest.main(verbosity=2)

    def test_superadmin_unified_dark_mode_and_nav_toggle(self):
        sa_base = (ROOT / 'templates' / 'superadmin' / 'base.html').read_text(encoding='utf-8')
        self.assertIn('saNavToggleBtn', sa_base)
        self.assertIn('saSidebarCloseBtn', sa_base)
        self.assertIn('window.toggleSaSidebar', sa_base)
        self.assertIn("ayevoryn_design_system.css?v=5.0", sa_base)
        self.assertIn("html.setAttribute('data-theme', nextDs)", sa_base)
        self.assertIn("html.setAttribute('data-bs-theme', nextSa)", sa_base)
        sa_css = (ROOT / 'static' / 'css' / 'superadmin.css').read_text(encoding='utf-8')
        self.assertIn('body.sa-sidebar-collapsed .sa-sidebar', sa_css)
        self.assertIn('.sa-nav-toggle-btn', sa_css)
        self.assertIn('html[data-theme="dark_clay_glass"] .sa-card', sa_css)

