"""
Ayevoryn Full Enterprise UI/UX Transformation Verification Suite (USMANIA TECHS PVT LTD).
Verifies:
  - Unified Light Mode (soft white + sky blue) & Dark Mode (deep navy + sky blue) tokens
  - Hover/contrast safety, dark-mode white-leak prevention, focus-visible & prefers-reduced-motion
  - Enterprise Chart.js & Plotly theme/tooltip/ResizeObserver engine (ayevoryn_charts.js)
  - Universal integration across all 14 standalone/base templates (covering all 94 templates)
  - Clean Jinja2 parsing across ALL 94 templates in templates/
"""
import glob
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class TestEnterpriseUIUXDesignSystem(unittest.TestCase):
    def test_design_system_tokens_and_accessibility(self):
        css = (ROOT / 'static' / 'css' / 'ayevoryn_design_system.css').read_text(encoding='utf-8')
        for token in (
            '--brand: #38BDF8',
            '--bg: #F5F9FD',
            '--bg-secondary: #EDF5FB',
            '--text-primary: #172B3A',
            '--border: #E3ECF4',
            '--brand: #56C8FF',
            '--bg: #0A111B',
            '--surface: #142131',
            '--text-primary: #EAF3FC',
            '--border: #26394D',
            ':focus-visible',
            'prefers-reduced-motion: reduce',
            '.ayevoryn-skeleton',
        ):
            self.assertIn(token, css, f"Missing design system token/rule: {token}")

        # Balanced CSS braces check
        self.assertEqual(css.count('{'), css.count('}'), "Unbalanced braces in ayevoryn_design_system.css")

    def test_chart_engine_integrity(self):
        js = (ROOT / 'static' / 'js' / 'ayevoryn_charts.js').read_text(encoding='utf-8')
        for sym in ('safePctChange', 'formatCompactNumber', 'createAreaGradient', 'syncAllChartsToTheme', 'ResizeObserver', 'ayevoryn:themechange'):
            self.assertIn(sym, js, f"Missing chart engine symbol: {sym}")
        self.assertEqual(js.count('{'), js.count('}'), "Unbalanced braces in ayevoryn_charts.js")

    def test_all_standalone_and_base_templates_wired(self):
        pages = [
            'templates/base.html',
            'templates/superadmin/base.html',
            'templates/superadmin/force_password_change.html',
            'templates/superadmin/mfa_verify.html',
            'templates/auth/login.html',
            'templates/auth/register.html',
            'templates/landing/index.html',
            'templates/landing/features.html',
            'templates/landing/architecture.html',
            'templates/landing/decision_models.html',
            'templates/landing/dependency_intelligence.html',
            'templates/landing/about.html',
            'templates/landing/privacy.html',
            'templates/landing/terms.html',
        ]
        for rel in pages:
            txt = (ROOT / rel).read_text(encoding='utf-8')
            self.assertIn('ayevoryn_design_system.css', txt, f"Design system not linked in {rel}")
            self.assertIn('favicon.ico', txt, f"Favicon not linked in {rel}")

        base_txt = (ROOT / 'templates' / 'base.html').read_text(encoding='utf-8')
        self.assertIn('ayevoryn_charts.js', base_txt)
        self.assertIn('ayevoryn:themechange', base_txt)
        self.assertNotIn('#FF9900', base_txt, "Legacy AWS orange progress bar should be replaced with Ayevoryn sky-blue")

    def test_all_94_jinja2_templates_parse_cleanly(self):
        try:
            from jinja2 import Environment
        except ImportError:
            self.skipTest('jinja2 not installed')
        env = Environment()
        all_templates = sorted(glob.glob(str(ROOT / 'templates' / '**' / '*.html'), recursive=True))
        self.assertGreaterEqual(len(all_templates), 90)
        for tpath in all_templates:
            src = Path(tpath).read_text(encoding='utf-8', errors='ignore')
            env.parse(src)



    def test_zero_legacy_theme_bleed_and_ui_emojis(self):
        import re
        dash = (ROOT / 'templates' / 'dashboard.html').read_text(encoding='utf-8')
        self.assertNotIn('⚡', dash)
        self.assertNotRegex(dash, re.compile(r'background(?:-color)?\s*:\s*(?:#fff(?:fff)?|white)\b', re.I))

        sup = (ROOT / 'templates' / 'business_twin' / 'twin_suppliers.html').read_text(encoding='utf-8')
        self.assertNotIn('★', sup)

        # Verify zero legacy purple/black primary tokens in CSS files
        legacy = re.compile(r'#(?:6366F1|4F46E5|7C3AED|8B5CF6|2563EB|0A0B0E|11141E)\b', re.I)
        for css_p in (ROOT / 'static' / 'css').glob('*.css'):
            txt = css_p.read_text(encoding='utf-8')
            self.assertEqual(legacy.findall(txt), [], f"Legacy purple/black hex found in {css_p.name}")

        # Verify backend theme engine uses Ayevoryn Light & Ayevoryn Dark
        themes_py = (ROOT / 'config' / 'themes.py').read_text(encoding='utf-8')
        self.assertIn("'name': 'Ayevoryn Light'", themes_py)
        self.assertIn("'name': 'Ayevoryn Dark'", themes_py)
        self.assertIn('#F7FAFC', themes_py)
        self.assertIn('#0B1120', themes_py)



    def test_zero_fabricated_chart_fallbacks_and_signature_area_chart(self):
        dash = (ROOT / 'templates' / 'dashboard.html').read_text(encoding='utf-8')
        self.assertNotIn('[48, 32, 14, 6]', dash, "Hardcoded fake revenueMixChart values must be removed")
        self.assertNotIn("name: 'Sales & Mktg'", dash, "Hardcoded fake fallback departments must be removed")
        self.assertNotIn('1 + 0.015 * i', dash, "Synthetic unit economics ramp must be removed")
        self.assertIn("fill: 'tozeroy'", dash, "Dashboard P&L chart must use smooth area/line style")
        self.assertIn('revenue_mix', dash, "Revenue mix chart must bind real backend revenue_mix")

        dr = (ROOT / 'routes' / 'dashboard.py').read_text(encoding='utf-8')
        self.assertIn('revenue_mix=revenue_mix', dr)

        ao = (ROOT / 'templates' / 'analytics' / 'analytics_overview.html').read_text(encoding='utf-8')
        self.assertNotIn('budget: 500000, spent: 102020', ao, "Fake department fallback in analytics_overview must be removed")
        self.assertIn('renderEmptyState', ao)



    def test_premium_glass_v2_and_motion_engine(self):
        css = (ROOT / 'static' / 'css' / 'ayevoryn_design_system.css').read_text(encoding='utf-8')
        for tok in ('#F7FAFC', '#EFF6FF', '#0B1120', '#101B2D', '#172235', '#60A5FA', '.ayev-progress-ring', '.ayev-chart-enter', 'min-height: 44px'):
            self.assertIn(tok, css, f"Missing Premium Glass UI V2 token/rule: {tok}")

        mjs = (ROOT / 'static' / 'js' / 'ayevoryn_motion_v2.js').read_text(encoding='utf-8')
        for sym in ('parseFormattedNumber', 'animateCounterElement', 'initCircularProgressRings', 'initChartRevealAnimations', 'prefers-reduced-motion', 'aria-label', 'stroke-dashoffset'):
            self.assertIn(sym, mjs, f"Missing motion v2 symbol: {sym}")
        self.assertEqual(mjs.count('{'), mjs.count('}'), "Unbalanced braces in ayevoryn_motion_v2.js")

        for rel in ('templates/base.html', 'templates/superadmin/base.html', 'templates/landing/index.html'):
            self.assertIn('ayevoryn_motion_v2.js', (ROOT / rel).read_text(encoding='utf-8'))

        themes_py = (ROOT / 'config' / 'themes.py').read_text(encoding='utf-8')
        self.assertIn('#F7FAFC', themes_py)
        self.assertIn('#0B1120', themes_py)



    def test_dashboard_no_func_shadow_and_ambient_bgs_and_footer(self):
        import ast
        dr_src = (ROOT / 'routes' / 'dashboard.py').read_text(encoding='utf-8')
        tree = ast.parse(dr_src)
        for node in ast.walk(tree):
            if isinstance(node, ast.FunctionDef) and node.name == 'index':
                for sub in ast.walk(node):
                    if isinstance(sub, ast.ImportFrom) and sub.module == 'sqlalchemy':
                        names = [a.name for a in sub.names]
                        self.assertNotIn('func', names, "Local `from sqlalchemy import func` shadows module-level func and causes UnboundLocalError!")
        self.assertIn("FinancialRecord.transaction_type == 'revenue'", dr_src)

        css = (ROOT / 'static' / 'css' / 'ayevoryn_design_system.css').read_text(encoding='utf-8')
        self.assertIn('ambient_bg_light_hq.jpg', css)
        self.assertIn('ambient_bg_dark_hq.jpg', css)

        about = (ROOT / 'templates' / 'landing' / 'about.html').read_text(encoding='utf-8')
        self.assertNotIn('rgba(15,23,42,0.7)', about, "About page must not hardcode dark boxes in light mode")
        self.assertIn('aevoryn_theme', about)

        base = (ROOT / 'templates' / 'base.html').read_text(encoding='utf-8')
        self.assertIn('padding-right:210px', base, "Footer must clear the bottom-right Pulse AI floating button")



    def test_curved_pill_nav_trading_chart_and_live_treasury_ledger(self):
        for rel in (
            'templates/landing/index.html',
            'templates/landing/features.html',
            'templates/landing/architecture.html',
            'templates/landing/decision_models.html',
            'templates/landing/dependency_intelligence.html',
            'templates/landing/about.html',
            'templates/landing/privacy.html',
            'templates/landing/terms.html',
            'templates/auth/login.html',
            'templates/auth/register.html',
        ):
            content = (ROOT / rel).read_text(encoding='utf-8')
            self.assertIn('_public_nav.html', content, f"Missing shared curved pill nav in {rel}")
            self.assertIn('data-public-theme', content, f"Missing dual theme sync in {rel}")
            self.assertIn('ayevoryn_public.css', content, f"Missing ayevoryn_public.css in {rel}")

        for img in ('finance_team_real.jpg', 'executive_workspace_real.jpg', 'supply_chain_ops_real.jpg'):
            p = ROOT / 'static' / 'images' / 'public_visuals' / img
            self.assertTrue(p.exists() and p.stat().st_size > 50000, f"Missing real photo asset: {img}")

        dd = (ROOT / 'static' / 'js' / 'ayevoryn_dashboard_demo.js').read_text(encoding='utf-8')
        self.assertEqual(dd.count('{'), dd.count('}'), "Unbalanced braces in ayevoryn_dashboard_demo.js")
        idx_html = (ROOT / 'templates' / 'landing' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('data-ayv-dashboard-demo', idx_html)
        self.assertIn('data-ayv-line-canvas', idx_html)
        self.assertIn('data-ayv-pie-canvas', idx_html)

        bub = (ROOT / 'templates' / 'components' / 'public_pulse_assistant.html').read_text(encoding='utf-8')
        self.assertIn('typewriteBubble', bub)

        eng = (ROOT / 'services' / 'pulse_ai_engine.py').read_text(encoding='utf-8')
        self.assertIn('Attempt 3: Explicit real-API cascade', eng)

        bt = (ROOT / 'routes' / 'business_twin.py').read_text(encoding='utf-8')
        self.assertIn('_compute_treasury_live_state', bt)
        self.assertIn('/payments/transactions', bt)
        self.assertIn('/payments/transactions/export-csv', bt)
        self.assertNotIn('ann_rev * 0.4', bt)
        self.assertNotIn('ann_rev * 0.08', bt)

        tp = (ROOT / 'templates' / 'business_twin' / 'twin_payments.html').read_text(encoding='utf-8')
        self.assertIn('txRecordModal', tp)
        self.assertIn('deptBudgetModal', tp)
        self.assertIn('renderDepartmentBudgets', tp)


    def test_micro_interactions_real_copy_and_live_chart_reports(self):
        mcss = (ROOT / 'static' / 'css' / 'ayevoryn_micro_interactions.css').read_text(encoding='utf-8')
        mjs = (ROOT / 'static' / 'js' / 'ayevoryn_micro_interactions.js').read_text(encoding='utf-8')
        self.assertIn('ayv-copy-confirmed', mcss)
        self.assertIn('ayv-dot-loader', mcss)
        self.assertIn('ayv-eq-bars', mcss)
        self.assertIn('window.ayvCopyText', mjs)
        self.assertIn("execCommand('copy')", mjs)
        self.assertEqual(mjs.count('{'), mjs.count('}'), "Unbalanced braces in ayevoryn_micro_interactions.js")

        for rel in (
            'templates/base.html',
            'templates/superadmin/base.html',
            'templates/landing/index.html',
            'templates/auth/login.html',
            'templates/auth/register.html',
        ):
            content = (ROOT / rel).read_text(encoding='utf-8')
            self.assertIn('ayevoryn_micro_interactions.css', content, f"Missing micro-interactions CSS in {rel}")
            self.assertIn('ayevoryn_micro_interactions.js', content, f"Missing micro-interactions JS in {rel}")

        for rel in (
            'templates/ai/pulse_ai_workspace.html',
            'templates/ai/pulse_automations.html',
            'templates/components/app_pulse_agent.html',
            'templates/superadmin/pulse_ai.html',
            'templates/components/public_pulse_assistant.html',
        ):
            self.assertIn('ayvCopyText', (ROOT / rel).read_text(encoding='utf-8'), f"Missing ayvCopyText in {rel}")

        aes = (ROOT / 'services' / 'agent_export_service.py').read_text(encoding='utf-8')
        self.assertIn('def _render_live_chart_png', aes)
        self.assertIn('charts_rendered', aes)
        self.assertIn('Live Charts', aes)

        pat = (ROOT / 'services' / 'pulse_agent_tools.py').read_text(encoding='utf-8')
        self.assertIn('def _build_live_charts', pat)
        self.assertIn('"charts": {"type": "array"', pat)


    def test_bespoke_duotone_svg_icons_wired_appwide(self):
        scss = (ROOT / 'static' / 'css' / 'ayevoryn_svg_icons.css').read_text(encoding='utf-8')
        sjs = (ROOT / 'static' / 'js' / 'ayevoryn_svg_icons.js').read_text(encoding='utf-8')
        self.assertIn('--ayv-ico-tint', scss)
        self.assertIn('ayv-ico-gauge', scss)
        self.assertIn('ayv-ico-wave', scss)
        self.assertIn('ayv-ico-database', scss)
        self.assertIn('window.ayvUpgradeSvgIcons', sjs)
        self.assertEqual(sjs.count('{'), sjs.count('}'), "Unbalanced braces in ayevoryn_svg_icons.js")
        for rel in (
            'templates/base.html',
            'templates/superadmin/base.html',
            'templates/auth/login.html',
            'templates/auth/register.html',
            'templates/landing/index.html',
            'templates/landing/features.html',
            'templates/landing/architecture.html',
            'templates/landing/decision_models.html',
            'templates/landing/dependency_intelligence.html',
            'templates/landing/about.html',
            'templates/landing/privacy.html',
            'templates/landing/terms.html',
        ):
            content = (ROOT / rel).read_text(encoding='utf-8')
            self.assertIn('ayevoryn_svg_icons.css', content, f"Missing SVG icons CSS in {rel}")
            self.assertIn('ayevoryn_svg_icons.js', content, f"Missing SVG icons JS in {rel}")


    def test_vector_pdf_charts_multiformat_link_guard_and_automation_charts(self):
        aes = (ROOT / 'services' / 'agent_export_service.py').read_text(encoding='utf-8')
        self.assertIn('def _build_reportlab_vector_chart', aes)
        self.assertIn('executive_summary', aes)
        self.assertIn('Actionable Recommendations', aes)
        self.assertIn("wb.create_sheet(title='Live Charts', index=0)", aes)

        eng = (ROOT / 'services' / 'pulse_ai_engine.py').read_text(encoding='utf-8')
        self.assertIn('_pick_url_for_label', eng)
        self.assertIn("fn_args.setdefault('_user_prompt', clean_prompt)", eng)
        self.assertIn('_wants_pdf', eng)
        self.assertIn('_wants_excel', eng)

        pas = (ROOT / 'services' / 'pulse_automation_service.py').read_text(encoding='utf-8')
        self.assertIn('def _build_automation_live_charts', pas)
        self.assertIn('_CHARTS_MARKER_RE', pas)

        au = (ROOT / 'templates' / 'ai' / 'pulse_automations.html').read_text(encoding='utf-8')
        self.assertIn('function renderAutomationLiveCharts', au)
        self.assertIn('autoRunChartsGrid', au)


    def test_zero_fake_hallucinated_export_links(self):
        eng = (ROOT / 'services' / 'pulse_ai_engine.py').read_text(encoding='utf-8')
        self.assertIn('ZERO-FAKE-LINK GUARANTEE', eng)
        self.assertIn('if not _have_same:', eng)
        pat = (ROOT / 'services' / 'pulse_agent_tools.py').read_text(encoding='utf-8')
        self.assertIn('all_emps = all_emps[_s_idx:_e_idx]', pat)


    def test_dynamic_tenant_safe_sql_and_custom_charts_tool(self):
        pat = (ROOT / 'services' / 'pulse_agent_tools.py').read_text(encoding='utf-8')
        self.assertIn('"name": "run_live_sql_analysis"', pat)
        self.assertIn('def _build_tenant_scoped_sql', pat)
        self.assertIn('def _execute_tenant_safe_sql', pat)
        self.assertIn('def _chart_spec_from_sql', pat)
        self.assertIn('"custom_charts"', pat)
        self.assertIn('"sql_query"', pat)


    def test_cline_style_python_analyst_sandbox(self):
        pa = (ROOT / 'services' / 'pulse_python_analyst.py').read_text(encoding='utf-8')
        self.assertIn('def validate_python_code_ast', pa)
        self.assertIn('def load_live_company_data_snapshot', pa)
        self.assertIn('def execute_python_data_analysis', pa)
        pat = (ROOT / 'services' / 'pulse_agent_tools.py').read_text(encoding='utf-8')
        self.assertIn('"name": "run_python_data_analysis"', pat)
        self.assertIn('if any(n > 0 for n in _nums):', pat)


    def test_realtime_python_agent_in_automations(self):
        pa = (ROOT / 'services' / 'pulse_python_analyst.py').read_text(encoding='utf-8')
        self.assertIn('db.session.expire_all()', pa)
        self.assertIn("'query_sql':", pa)
        self.assertIn("'figure.dpi': 200", pa)
        pas = (ROOT / 'services' / 'pulse_automation_service.py').read_text(encoding='utf-8')
        self.assertIn('db.session.expire_all()', pas)
        self.assertIn('run_python_data_analysis', pas)
        au = (ROOT / 'templates' / 'ai' / 'pulse_automations.html').read_text(encoding='utf-8')
        self.assertIn('Download PNG', au)

if __name__ == '__main__':
    unittest.main(verbosity=2)

    def test_superadmin_unified_dark_mode_and_nav_toggle(self):
        sa_base = (ROOT / 'templates' / 'superadmin' / 'base.html').read_text(encoding='utf-8')
        self.assertIn('saNavToggleBtn', sa_base)
        self.assertIn('saSidebarCloseBtn', sa_base)
        self.assertIn('window.toggleSaSidebar', sa_base)
        self.assertIn("ayevoryn_design_system.css?v=5.0", sa_base)
        self.assertIn("html.setAttribute('data-theme', nextDs)", sa_base)
        self.assertIn("html.setAttribute('data-bs-theme', nextSa)", sa_base)
        sa_css = (ROOT / 'static' / 'css' / 'superadmin.css').read_text(encoding='utf-8')
        self.assertIn('body.sa-sidebar-collapsed .sa-sidebar', sa_css)
        self.assertIn('.sa-nav-toggle-btn', sa_css)
        self.assertIn('html[data-theme="dark_clay_glass"] .sa-card', sa_css)

    def test_public_website_redesign_typing_and_voice_bubble(self):
        idx = (ROOT / 'templates' / 'landing' / 'index.html').read_text(encoding='utf-8')
        self.assertIn('data-typing-phrases', idx)
        self.assertIn('AI Automated Business Agent', idx)
        self.assertIn('ayevoryn_public.css', idx)
        self.assertIn('public_pulse_assistant.html', idx)
        bub = (ROOT / 'templates' / 'components' / 'public_pulse_assistant.html').read_text(encoding='utf-8')
        self.assertIn('/api/public/pulse-voice', bub)
        self.assertIn('pubPulseMicBtn', bub)
        self.assertIn('ayevoryn_public_pulse_history_v1', bub)
        pr = (ROOT / 'routes' / 'public.py').read_text(encoding='utf-8')
        self.assertIn("'/api/public/pulse-voice'", pr)

