"""
Ayevoryn Secret Redaction & Operational Log Sanitizer (USMANIA TECHS PVT LTD)
Prevents API keys, credentials, bearer tokens, session secrets, and password hashes
from leaking into application logs, error payloads, or AI responses.
"""
import logging
import re
from typing import Any

_REDACTION_PATTERNS = [
    # Vendor API keys & tokens
    (re.compile(r'nvapi-[A-Za-z0-9_\-]{12,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'sk-aisa-[A-Za-z0-9_\-]+|sk-or-v1-[A-Za-z0-9_\-]{16,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'sk-[A-Za-z0-9_\-]{20,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'AQ\.Ab8[A-Za-z0-9_\-]{12,}'), '[REDACTED_API_KEY]'),
    (re.compile(r'AIza[0-9A-Za-z_\-]{20,}'), '[REDACTED_API_KEY]'),
    # Authorization headers & cookies
    (re.compile(r'(?i)(authorization\s*[:=]\s*bearer\s+)[A-Za-z0-9\.\-_~+/]+=*'), r'\1[REDACTED_TOKEN]'),
    (re.compile(r'(?i)(bearer\s+)[A-Za-z0-9\.\-_~+/]{16,}=*'), r'\1[REDACTED_TOKEN]'),
    (re.compile(r'(?i)(ayevoryn_session=)[^;\s]+'), r'\1[REDACTED_SESSION]'),
    # Key-value secret pairs in logs / query strings / reprs
    (re.compile(r'(?i)((?:api[_-]?key|secret[_-]?key|password|passwd|access[_-]?token|refresh[_-]?token|private[_-]?key)\s*[:=]\s*[\'"]?)([^\s,\'"&;\}]{4,})'), r'\1[REDACTED]'),
]


def redact_sensitive_text(text: Any) -> str:
    """Return a string with known secret patterns safely masked."""
    if text is None:
        return ''
    s = str(text)
    for pattern, replacement in _REDACTION_PATTERNS:
        s = pattern.sub(replacement, s)
    return s


class SecretRedactingFilter(logging.Filter):
    """Logging filter that scrubs credentials and API keys from every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            if isinstance(record.msg, str):
                record.msg = redact_sensitive_text(record.msg)
            if record.args:
                if isinstance(record.args, dict):
                    record.args = {
                        k: redact_sensitive_text(v) if isinstance(v, str) else v
                        for k, v in record.args.items()
                    }
                elif isinstance(record.args, tuple):
                    record.args = tuple(
                        redact_sensitive_text(a) if isinstance(a, str) else a
                        for a in record.args
                    )
        except Exception:
            pass
        return True


def install_secret_redacting_filter(logger: logging.Logger = None) -> None:
    """Idempotently attach SecretRedactingFilter to the target logger (or root logger)."""
    target = logger or logging.getLogger()
    for existing in target.filters:
        if isinstance(existing, SecretRedactingFilter):
            return
    target.addFilter(SecretRedactingFilter())
