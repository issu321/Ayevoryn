#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"

echo "[Ayevoryn] Starting on Linux ($(uname -s) $(uname -m))..."

if [ -x "$SCRIPT_DIR/.venv/bin/python3" ]; then
    PY="$SCRIPT_DIR/.venv/bin/python3"
elif [ -x "$SCRIPT_DIR/venv/bin/python3" ]; then
    PY="$SCRIPT_DIR/venv/bin/python3"
else
    PY="python3"
fi

# Verify bcrypt is importable so existing Windows-created accounts log in seamlessly
if ! "$PY" -c "import bcrypt" 2>/dev/null; then
    echo "[Ayevoryn] Installing required 'bcrypt' package for account login..."
    "$PY" -m pip install --break-system-packages bcrypt 2>/dev/null || "$PY" -m pip install bcrypt || true
fi

exec "$PY" app.py
