/**
 * Ayevoryn Premium Glass UI V2 — Motion, Number Counting & Circular Progress Engine
 * (USMANIA TECHS PVT LTD)
 *
 * Capabilities:
 *  1. Mathematically exact number counting animations (preserves currency, decimals,
 *     negative values, zero, compact suffixes, thousands separators, and exact final text).
 *  2. Screen-reader safe (sets aria-label to final value immediately) & reduced-motion aware.
 *  3. Deduplicated IntersectionObserver triggers (never restarts unnecessarily or leaks timers).
 *  4. Smooth SVG Circular Progress Rings derived strictly from real current/target values.
 *  5. Subtle GPU-accelerated chart reveal transitions.
 */
(function (global) {
    'use strict';

    var prefersReducedMotion = function () {
        return !!(global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches);
    };

    var NUM_REGEX = /^([^0-9\-+]*?)([\-+]?\d[\d,]*(?:\.\d+)?)(.*)$/;

    function parseFormattedNumber(rawText) {
        var text = String(rawText || '').trim();
        if (!text) return null;
        // Skip dates, times, ratios with colons/slashes (e.g. 12:30:45, 2026-11-22, 4/10)
        if (/[:\/]/.test(text)) return null;
        var m = text.match(NUM_REGEX);
        if (!m) return null;
        var prefix = m[1] || '';
        var numStr = m[2] || '';
        var suffix = m[3] || '';
        var numeric = parseFloat(numStr.replace(/,/g, ''));
        if (!isFinite(numeric)) return null;
        var decIdx = numStr.indexOf('.');
        var decimals = decIdx >= 0 ? (numStr.length - decIdx - 1) : 0;
        var hasCommas = numStr.indexOf(',') !== -1;
        return {
            original: text,
            prefix: prefix,
            suffix: suffix,
            value: numeric,
            decimals: decimals,
            hasCommas: hasCommas
        };
    }

    function formatAnimatedValue(val, meta) {
        var fixed = val.toFixed(meta.decimals);
        if (meta.hasCommas) {
            var parts = fixed.split('.');
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            fixed = parts.join('.');
        }
        return meta.prefix + fixed + meta.suffix;
    }

    function animateCounterElement(el, durationMs) {
        if (!el || el.dataset.ayevCounted === '1') return;
        // Do not overwrite elements containing nested interactive/badge markup
        if (el.children && el.children.length > 0) return;

        var raw = (el.dataset.targetValue || el.textContent || '').trim();
        var meta = parseFormattedNumber(raw);
        if (!meta) return;

        el.dataset.ayevCounted = '1';
        el.dataset.ayevFinalValue = meta.original;
        el.setAttribute('aria-label', meta.original);
        el.style.fontVariantNumeric = 'tabular-nums';

        // Zero or reduced motion -> display exact final value immediately
        if (prefersReducedMotion() || meta.value === 0) {
            el.textContent = meta.original;
            return;
        }

        // Cancel any prior RAF handle on this element
        if (el._ayevRafId) {
            cancelAnimationFrame(el._ayevRafId);
            el._ayevRafId = null;
        }

        var duration = durationMs || 680;
        var startTs = null;
        var startVal = 0;
        var endVal = meta.value;

        function step(ts) {
            if (startTs === null) startTs = ts;
            var elapsed = ts - startTs;
            var t = Math.min(1, elapsed / duration);
            // Smooth cubic ease-out
            var eased = 1 - Math.pow(1 - t, 3);
            var current = startVal + (endVal - startVal) * eased;

            if (t >= 1) {
                el.textContent = meta.original; // Guarantee exact mathematical final display
                el._ayevRafId = null;
            } else {
                el.textContent = formatAnimatedValue(current, meta);
                el._ayevRafId = requestAnimationFrame(step);
            }
        }

        el._ayevRafId = requestAnimationFrame(step);
    }

    function updateCounterValue(el, newFormattedValue) {
        if (!el) return;
        el.dataset.ayevCounted = '0';
        el.dataset.targetValue = String(newFormattedValue || '');
        el.textContent = String(newFormattedValue || '');
        animateCounterElement(el, 520);
    }

    function initCircularProgressRings(root) {
        var scope = root || document;
        var rings = scope.querySelectorAll('[data-progress-ring], .ayev-progress-ring');
        rings.forEach(function (container) {
            if (container.dataset.ayevRingInit === '1') return;
            var current = parseFloat(container.dataset.current);
            var target = parseFloat(container.dataset.target);
            var explicitPct = parseFloat(container.dataset.percent);

            var pct = 0;
            if (isFinite(current) && isFinite(target)) {
                pct = target > 0 ? (current / target) * 100 : 0;
            } else if (isFinite(explicitPct)) {
                pct = explicitPct;
            }
            var clamped = Math.max(0, Math.min(100, pct));
            container.dataset.ayevRingInit = '1';
            container.setAttribute('role', 'progressbar');
            container.setAttribute('aria-valuemin', '0');
            container.setAttribute('aria-valuemax', '100');
            container.setAttribute('aria-valuenow', String(Math.round(pct * 10) / 10));

            var circle = container.querySelector('.ayev-ring-progress');
            if (!circle) return;
            var r = parseFloat(circle.getAttribute('r') || '36');
            var circumference = 2 * Math.PI * r;
            circle.style.strokeDasharray = circumference + ' ' + circumference;

            var targetOffset = circumference - (clamped / 100) * circumference;
            if (prefersReducedMotion()) {
                circle.style.strokeDashoffset = String(targetOffset);
            } else {
                circle.style.strokeDashoffset = String(circumference);
                requestAnimationFrame(function () {
                    requestAnimationFrame(function () {
                        circle.style.transition = 'stroke-dashoffset 780ms cubic-bezier(0.22, 1, 0.36, 1)';
                        circle.style.strokeDashoffset = String(targetOffset);
                    });
                });
            }
        });
    }

    function initChartRevealAnimations(root) {
        var scope = root || document;
        var charts = scope.querySelectorAll('.js-plotly-plot, .chart-container, .chart-card canvas');
        if (prefersReducedMotion()) return;
        charts.forEach(function (el) {
            if (el.dataset.ayevChartReveal === '1') return;
            el.dataset.ayevChartReveal = '1';
            el.classList.add('ayev-chart-enter');
        });
    }

    function initCounters(root) {
        var scope = root || document;
        var selector = '[data-count-up], .kpi-value, .metric-value, .stat-value, .kpi-number, .summary-metric, .vital-value';
        var nodes = scope.querySelectorAll(selector);
        if (!nodes.length) return;

        if (typeof IntersectionObserver === 'undefined' || prefersReducedMotion()) {
            nodes.forEach(function (n) { animateCounterElement(n); });
            return;
        }

        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    animateCounterElement(entry.target);
                    io.unobserve(entry.target);
                }
            });
        }, { threshold: 0.15 });

        nodes.forEach(function (n) {
            if (n.dataset.ayevCounted !== '1') {
                io.observe(n);
            }
        });
    }

    function bootAll() {
        initCounters(document);
        initCircularProgressRings(document);
        initChartRevealAnimations(document);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', bootAll);
    } else {
        bootAll();
    }

    global.AyevorynMotionV2 = {
        parseFormattedNumber: parseFormattedNumber,
        animateCounterElement: animateCounterElement,
        updateCounterValue: updateCounterValue,
        initCounters: initCounters,
        initCircularProgressRings: initCircularProgressRings,
        initChartRevealAnimations: initChartRevealAnimations
    };
})(window);
