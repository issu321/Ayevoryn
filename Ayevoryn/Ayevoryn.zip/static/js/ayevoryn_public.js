/* ==========================================================================
   AYEVORYN PUBLIC & AUTH INTERACTION ENGINE (V2.0)
   - Synchronizes data-theme & data-public-theme across all pages
   - Smooth welcoming typing animation ([data-typing-phrases])
   - Scroll-reveal IntersectionObserver + Mobile Pill Drawer
   ========================================================================== */
(function () {
    'use strict';

    function getPreferredTheme() {
        const t = localStorage.getItem('ayevoryn_theme') || localStorage.getItem('aevoryn_theme') || localStorage.getItem('ayevoryn_public_theme') || 'dark';
        return t === 'light' ? 'light' : 'dark';
    }

    function applyTheme(theme) {
        const clean = theme === 'light' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', clean);
        document.documentElement.setAttribute('data-public-theme', clean);
        try {
            localStorage.setItem('ayevoryn_theme', clean);
            localStorage.setItem('ayevoryn_public_theme', clean);
            localStorage.setItem('aevoryn_theme', clean);
        } catch (e) {}

        document.querySelectorAll('[data-theme-toggle-btn]').forEach(function (btn) {
            const icon = btn.querySelector('i');
            const label = btn.querySelector('span');
            if (clean === 'dark') {
                if (icon) icon.className = 'fas fa-sun';
                if (label) label.textContent = 'Light';
            } else {
                if (icon) icon.className = 'fas fa-moon';
                if (label) label.textContent = 'Dark';
            }
        });

        window.dispatchEvent(new CustomEvent('ayevoryn:theme-changed', { detail: { theme: clean } }));
    }

    window.toggleAyevorynPublicTheme = function () {
        const current = document.documentElement.getAttribute('data-theme') || getPreferredTheme();
        applyTheme(current === 'dark' ? 'light' : 'dark');
    };

    window.togglePublicTheme = window.toggleAyevorynPublicTheme;

    window.toggleAyevorynMobileNav = function () {
        const drawer = document.getElementById('ayvMobileDrawer');
        if (drawer) drawer.classList.toggle('open');
    };

    function initTypingAnimations() {
        document.querySelectorAll('[data-typing-phrases]').forEach(function (el) {
            if (el.dataset.typingInit === '1') return;
            el.dataset.typingInit = '1';
            let phrases = [];
            try {
                phrases = JSON.parse(el.getAttribute('data-typing-phrases') || '[]');
            } catch (e) {
                phrases = [];
            }
            if (!phrases.length) return;

            let pIdx = 0;
            let cIdx = 0;
            let deleting = false;

            function tick() {
                const phrase = phrases[pIdx];
                if (!deleting) {
                    cIdx++;
                    el.textContent = phrase.slice(0, cIdx);
                    if (cIdx >= phrase.length) {
                        deleting = true;
                        setTimeout(tick, 2200);
                        return;
                    }
                    setTimeout(tick, 52);
                } else {
                    cIdx--;
                    el.textContent = phrase.slice(0, cIdx);
                    if (cIdx <= 0) {
                        deleting = false;
                        pIdx = (pIdx + 1) % phrases.length;
                        setTimeout(tick, 320);
                        return;
                    }
                    setTimeout(tick, 28);
                }
            }
            tick();
        });
    }

    function initScrollReveal() {
        const items = document.querySelectorAll('.ayv-reveal');
        if (!items.length) return;
        if (!('IntersectionObserver' in window)) {
            items.forEach(function (el) { el.classList.add('visible'); });
            return;
        }
        const obs = new IntersectionObserver(function (entries) {
            entries.forEach(function (entry) {
                if (entry.isIntersecting) {
                    entry.target.classList.add('visible');
                    obs.unobserve(entry.target);
                }
            });
        }, { threshold: 0.08 });
        items.forEach(function (el) { obs.observe(el); });
    }

    // Apply immediately to prevent FOUC
    applyTheme(getPreferredTheme());

    document.addEventListener('DOMContentLoaded', function () {
        applyTheme(getPreferredTheme());
        initTypingAnimations();
        initScrollReveal();
    });
})();
