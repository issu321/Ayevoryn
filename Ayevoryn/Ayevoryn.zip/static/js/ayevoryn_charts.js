/**
 * Ayevoryn Enterprise Chart & Analytics Theme Engine (USMANIA TECHS PVT LTD)
 * Provides:
 *  - Consistent Light/Dark Sky-Blue + Teal/Violet/Slate/Coral chart palette
 *  - Smooth, non-flickering floating tooltips with accurate formatting
 *  - Safe percentage/growth helpers (zero divide-by-zero)
 *  - Live Light <-> Dark re-theming for both Chart.js and Plotly instances
 *  - Automatic ResizeObserver reflow when sidebar collapses/expands or window resizes
 */
(function (global) {
    'use strict';

    function isDarkTheme() {
        var t = (document.documentElement.getAttribute('data-theme') || '').toLowerCase();
        var bs = (document.documentElement.getAttribute('data-bs-theme') || '').toLowerCase();
        return t.indexOf('dark') !== -1 || t === 'cyber_midnight' || t === 'void' || bs === 'dark';
    }

    function getThemeTokens() {
        var dark = isDarkTheme();
        return {
            isDark: dark,
            brand: dark ? '#56C8FF' : '#38BDF8',
            brandStrong: dark ? '#249DDE' : '#0284C7',
            palette: dark
                ? ['#56C8FF', '#41C6A5', '#A78BFA', '#7EA8D8', '#F17D85', '#E5B25E']
                : ['#0EA5E9', '#16A085', '#6366F1', '#476E8E', '#E36B73', '#D99A32'],
            textPrimary: dark ? '#EAF3FC' : '#172B3A',
            textSecondary: dark ? '#A3B7CA' : '#607487',
            gridColor: dark ? 'rgba(163, 183, 202, 0.12)' : 'rgba(23, 43, 58, 0.07)',
            tooltipBg: dark ? '#192A3D' : '#FFFFFF',
            tooltipBorder: dark ? '#334A60' : '#D2E2EF',
            tooltipTitle: dark ? '#EAF3FC' : '#172B3A',
            tooltipBody: dark ? '#C7D8E8' : '#4A6075',
            paperBg: 'rgba(0,0,0,0)',
        };
    }

    function safePctChange(current, previous) {
        var c = Number(current);
        var p = Number(previous);
        if (!isFinite(c) || !isFinite(p) || p === 0) return null;
        return ((c - p) / Math.abs(p)) * 100;
    }

    function formatCompactNumber(val, prefix) {
        var n = Number(val);
        if (!isFinite(n)) return '—';
        var p = prefix || '';
        var abs = Math.abs(n);
        var sign = n < 0 ? '-' : '';
        if (abs >= 1e9) return sign + p + (abs / 1e9).toFixed(2) + 'B';
        if (abs >= 1e6) return sign + p + (abs / 1e6).toFixed(2) + 'M';
        if (abs >= 1e3) return sign + p + (abs / 1e3).toFixed(1) + 'K';
        return sign + p + abs.toLocaleString(undefined, { maximumFractionDigits: 2 });
    }

    function createAreaGradient(ctx, colorHex) {
        var grad = ctx.createLinearGradient(0, 0, 0, 280);
        var dark = isDarkTheme();
        var topAlpha = dark ? 0.28 : 0.22;
        if (colorHex && colorHex.indexOf('#') === 0 && colorHex.length === 7) {
            var r = parseInt(colorHex.slice(1, 3), 16);
            var g = parseInt(colorHex.slice(3, 5), 16);
            var b = parseInt(colorHex.slice(5, 7), 16);
            grad.addColorStop(0, 'rgba(' + r + ',' + g + ',' + b + ',' + topAlpha + ')');
            grad.addColorStop(1, 'rgba(' + r + ',' + g + ',' + b + ',0.0)');
            return grad;
        }
        grad.addColorStop(0, dark ? 'rgba(86,200,255,0.28)' : 'rgba(56,189,248,0.22)');
        grad.addColorStop(1, 'rgba(56,189,248,0.0)');
        return grad;
    }

    function applyChartJsDefaults() {
        if (typeof global.Chart === 'undefined') return;
        var t = getThemeTokens();
        var d = global.Chart.defaults;
        d.font.family = "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif";
        d.font.size = 12;
        d.color = t.textSecondary;
        d.borderColor = t.gridColor;
        d.responsive = true;
        d.maintainAspectRatio = false;

        if (d.interaction) {
            d.interaction.mode = 'index';
            d.interaction.intersect = false;
        }
        if (d.plugins && d.plugins.tooltip) {
            var tt = d.plugins.tooltip;
            tt.enabled = true;
            tt.backgroundColor = t.tooltipBg;
            tt.titleColor = t.tooltipTitle;
            tt.bodyColor = t.tooltipBody;
            tt.borderColor = t.tooltipBorder;
            tt.borderWidth = 1;
            tt.padding = 12;
            tt.cornerRadius = 10;
            tt.boxPadding = 5;
            tt.usePointStyle = true;
            tt.displayColors = true;
        }
        if (d.plugins && d.plugins.legend && d.plugins.legend.labels) {
            d.plugins.legend.labels.color = t.textSecondary;
            d.plugins.legend.labels.usePointStyle = true;
            d.plugins.legend.labels.boxWidth = 8;
        }
    }

    function syncAllChartsToTheme() {
        applyChartJsDefaults();
        var t = getThemeTokens();

        // Update all active Chart.js instances cleanly
        if (typeof global.Chart !== 'undefined' && global.Chart.instances) {
            var instances = Object.values(global.Chart.instances);
            instances.forEach(function (chart) {
                if (!chart || !chart.options) return;
                try {
                    if (chart.options.plugins && chart.options.plugins.tooltip) {
                        var tt = chart.options.plugins.tooltip;
                        tt.backgroundColor = t.tooltipBg;
                        tt.titleColor = t.tooltipTitle;
                        tt.bodyColor = t.tooltipBody;
                        tt.borderColor = t.tooltipBorder;
                        tt.borderWidth = 1;
                    }
                    if (chart.options.plugins && chart.options.plugins.legend && chart.options.plugins.legend.labels) {
                        chart.options.plugins.legend.labels.color = t.textSecondary;
                    }
                    if (chart.options.scales) {
                        Object.keys(chart.options.scales).forEach(function (axisKey) {
                            var axis = chart.options.scales[axisKey];
                            if (!axis) return;
                            if (axis.ticks) axis.ticks.color = t.textSecondary;
                            if (axis.grid) axis.grid.color = t.gridColor;
                            if (axis.title) axis.title.color = t.textSecondary;
                        });
                    }
                    chart.update('none');
                } catch (e) {}
            });
        }

        // Update all active Plotly instances cleanly
        if (typeof global.Plotly !== 'undefined') {
            document.querySelectorAll('.js-plotly-plot').forEach(function (el) {
                try {
                    global.Plotly.relayout(el, {
                        'paper_bgcolor': t.paperBg,
                        'plot_bgcolor': t.paperBg,
                        'font.color': t.textSecondary,
                        'xaxis.gridcolor': t.gridColor,
                        'yaxis.gridcolor': t.gridColor,
                        'hoverlabel.bgcolor': t.tooltipBg,
                        'hoverlabel.bordercolor': t.tooltipBorder,
                        'hoverlabel.font.color': t.tooltipTitle
                    });
                } catch (e) {}
            });
        }
    }

    function resizeAllCharts() {
        if (typeof global.Chart !== 'undefined' && global.Chart.instances) {
            Object.values(global.Chart.instances).forEach(function (c) {
                try { if (c && typeof c.resize === 'function') c.resize(); } catch (e) {}
            });
        }
        if (typeof global.Plotly !== 'undefined') {
            document.querySelectorAll('.js-plotly-plot').forEach(function (el) {
                try { global.Plotly.Plots.resize(el); } catch (e) {}
            });
        }
    }


    function renderEmptyState(elOrId, title, message, iconClass) {
        var el = typeof elOrId === 'string' ? document.getElementById(elOrId) : elOrId;
        if (!el) return;
        var icon = iconClass || 'fa-chart-area';
        el.innerHTML =
            '<div class="ayevoryn-empty-state" style="min-height:220px;">' +
            '  <i class="fas ' + icon + '"></i>' +
            '  <div style="font-weight:700;color:var(--text-primary);margin-bottom:4px;">' + (title || 'No data available yet') + '</div>' +
            '  <div style="font-size:0.84rem;max-width:360px;">' + (message || 'Add business records to visualize real analytics here.') + '</div>' +
            '</div>';
    }

    function initObservers() {
        applyChartJsDefaults();

        // Sync charts on theme attribute changes
        var observer = new MutationObserver(function (mutations) {
            for (var i = 0; i < mutations.length; i++) {
                if (mutations[i].attributeName === 'data-theme' || mutations[i].attributeName === 'data-bs-theme') {
                    syncAllChartsToTheme();
                    break;
                }
            }
        });
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'data-bs-theme'] });

        window.addEventListener('ayevoryn:themechange', syncAllChartsToTheme);

        // Reflow charts cleanly when sidebar collapses/expands or main-content resizes
        var mainEl = document.querySelector('.main-content');
        if (mainEl && typeof ResizeObserver !== 'undefined') {
            var timer = null;
            var ro = new ResizeObserver(function () {
                clearTimeout(timer);
                timer = setTimeout(resizeAllCharts, 140);
            });
            ro.observe(mainEl);
        }
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initObservers);
    } else {
        initObservers();
    }

    global.AyevorynCharts = {
        isDarkTheme: isDarkTheme,
        getThemeTokens: getThemeTokens,
        safePctChange: safePctChange,
        formatCompactNumber: formatCompactNumber,
        createAreaGradient: createAreaGradient,
        syncAllChartsToTheme: syncAllChartsToTheme,
        resizeAllCharts: resizeAllCharts,
        renderEmptyState: renderEmptyState
    };
})(window);
