/* ==========================================================================
   AYEVORYN — INTELLIGENT LIQUID GLASS NAVBAR, THEME, CHART & TREND ENGINE
   1. Universal Light / Dark Theme Synchronization (WCAG AA/AAA Verified)
   2. 120fps Directional Scroll Auto-Hide / Compact Capsule Reveal + Top Peek
   3. Sliding Liquid Glass Pill Glider for Navigation Links
   4. Scroll Progress Laser Bar inside Floating Navbar
   5. Zero-Lag Delegated Specular Spotlight Tracking on Leaf Cards
   6. Animated KPI Trend Sparklines, SVG Chart Morphing & Scroll Reveal Engine
   7. Global ⌘K / Ctrl+K Spotlight Quick Navigation Command Palette
   ========================================================================== */

(function() {
  'use strict';

  // 1. Universal Public Theme Switcher & Icon Synchronizer (Works on ALL pages including Register/Login)
  window.updateThemeIcon = function() {
    const cur = document.documentElement.getAttribute('data-public-theme') || 'light';
    const icons = document.querySelectorAll('#pubThemeIcon, #publicThemeIcon, .ayev-theme-icon');
    icons.forEach(function(icon) {
      icon.className = cur === 'dark' ? 'fas fa-sun text-warning' : 'fas fa-moon';
    });
    const badges = document.querySelectorAll('.ayev-active-theme-label');
    badges.forEach(function(b) {
      b.textContent = cur === 'dark' ? 'Dark Glass' : 'Light Glass';
    });
  };

  window.togglePublicTheme = function() {
    const cur = document.documentElement.getAttribute('data-public-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-public-theme', next);
    try {
      localStorage.setItem('ayevoryn_public_theme', next);
    } catch (e) {}
    window.updateThemeIcon();
  };

  // 2. Global ⌘K Spotlight Command Palette
  window.openAyevCommandPalette = function() {
    let backdrop = document.getElementById('ayevCmdBackdrop');
    if (!backdrop) return;
    backdrop.classList.add('open');
    const inp = document.getElementById('ayevCmdSearchInput');
    if (inp) {
      inp.value = '';
      filterCmdItems('');
      setTimeout(function() { inp.focus(); }, 40);
    }
  };

  window.closeAyevCommandPalette = function() {
    const backdrop = document.getElementById('ayevCmdBackdrop');
    if (backdrop) backdrop.classList.remove('open');
  };

  // 3. Universal High-Polish Notification & Toast Engine with Working Close Button
  window.dismissNotification = function(btn) {
    if (!btn) return;
    const toast = btn.closest('.ayev-toast, .toast-glass, .alert, [role="alert"]');
    if (!toast) return;
    if (toast._timer) clearTimeout(toast._timer);
    toast.style.transition = 'all 0.28s cubic-bezier(0.16, 1, 0.3, 1)';
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%) scale(0.92)';
    setTimeout(function() {
      toast.remove();
      const wrap = document.getElementById('ayevToastContainer');
      if (wrap && wrap.children.length === 0) wrap.style.display = 'none';
    }, 280);
  };

  window.showToast = function(message, type, title) {
    type = type || 'info';
    if (type === 'error') type = 'danger';

    let container = document.getElementById('ayevToastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'ayevToastContainer';
      container.className = 'ayev-toast-container';
      document.body.appendChild(container);
    }
    container.style.display = 'flex';

    const icons = {
      success: 'fa-check-circle',
      danger: 'fa-triangle-exclamation',
      warning: 'fa-circle-exclamation',
      info: 'fa-circle-info'
    };
    const defaultTitles = {
      success: 'Success',
      danger: 'Notice',
      warning: 'Warning',
      info: 'Notification'
    };

    const toast = document.createElement('div');
    toast.className = 'ayev-toast ayev-toast-' + type;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    toast.innerHTML = [
      '<div class="ayev-toast-icon"><i class="fas ' + (icons[type] || 'fa-bell') + '"></i></div>',
      '<div class="ayev-toast-body">',
      '  <div class="ayev-toast-title">' + (title || defaultTitles[type] || 'Notification') + '</div>',
      '  <div class="ayev-toast-msg">' + message + '</div>',
      '</div>',
      '<button type="button" class="ayev-toast-close" onclick="window.dismissNotification(this)" aria-label="Close notification" title="Close">',
      '  <i class="fas fa-times"></i>',
      '</button>',
      '<div class="ayev-toast-progress"><div class="ayev-toast-bar"></div></div>'
    ].join('');

    container.appendChild(toast);

    const duration = 4500;
    const bar = toast.querySelector('.ayev-toast-bar');
    if (bar) {
      bar.style.transition = 'width ' + duration + 'ms linear';
      requestAnimationFrame(function() {
        requestAnimationFrame(function() {
          bar.style.width = '0%';
        });
      });
    }

    toast._timer = setTimeout(function() {
      window.dismissNotification(toast.querySelector('.ayev-toast-close'));
    }, duration);

    toast.addEventListener('mouseenter', function() {
      if (toast._timer) clearTimeout(toast._timer);
      if (bar) {
        const computedWidth = window.getComputedStyle(bar).width;
        bar.style.transition = 'none';
        bar.style.width = computedWidth;
      }
    });

    toast.addEventListener('mouseleave', function() {
      toast._timer = setTimeout(function() {
        window.dismissNotification(toast.querySelector('.ayev-toast-close'));
      }, 1800);
    });
  };

  function filterCmdItems(query) {
    const q = (query || '').toLowerCase().trim();
    const items = document.querySelectorAll('.ayev-cmd-item');
    items.forEach(function(item) {
      const text = (item.getAttribute('data-search') || item.textContent || '').toLowerCase();
      item.style.display = (!q || text.indexOf(q) !== -1) ? 'flex' : 'none';
    });
  }

  // 4. Clean One-Time Tab/Scenario Switch Physics Animator
  function triggerPublicOneTimeEnter(container) {
    const root = container || document;
    root.querySelectorAll('.kpi-telemetry-tile').forEach(function(tile) {
      tile.classList.remove('ayev-one-time-enter');
      void tile.offsetWidth;
      tile.classList.add('ayev-one-time-enter');
    });
  }

  // 5. Enhanced Hero Chart & Scenario Morphing on Landing Page
  function installEnhancedHeroHandlers() {
    const p90Line = document.getElementById('heroSplineLineP90');
    const p90Area = document.getElementById('heroSplineAreaP90');
    const baseLine = document.getElementById('heroSplineLineBase');
    const baseArea = document.getElementById('heroSplineAreaBase');

    if (p90Line && baseLine) {
      const HORIZON_CURVES = {
        'today': {
          p90: 'M 40 124 C 130 105, 210 112, 310 68 C 410 56, 500 32, 595 18',
          base: 'M 40 134 C 130 120, 210 124, 310 88 C 410 74, 500 54, 595 40'
        },
        '7d': {
          p90: 'M 40 128 C 130 112, 210 88, 310 70 C 410 48, 500 35, 595 20',
          base: 'M 40 138 C 130 124, 210 108, 310 90 C 410 72, 500 58, 595 42'
        },
        '30d': {
          p90: 'M 40 132 C 130 118, 210 96, 310 74 C 410 52, 500 38, 595 22',
          base: 'M 40 140 C 130 128, 210 114, 310 94 C 410 76, 500 62, 595 46'
        }
      };

      const SCENARIO_CURVES = {
        'baseline': HORIZON_CURVES['30d'],
        'expansion': {
          p90: 'M 40 130 C 130 106, 210 78, 310 52 C 410 34, 500 20, 595 10',
          base: 'M 40 138 C 130 118, 210 96, 310 72 C 410 52, 500 38, 595 24'
        },
        'shock': {
          p90: 'M 40 132 C 130 124, 210 118, 310 104 C 410 88, 500 72, 595 56',
          base: 'M 40 140 C 130 136, 210 132, 310 122 C 410 108, 500 94, 595 78'
        }
      };

      function applyHeroCurve(curve) {
        if (!curve) return;
        p90Line.setAttribute('d', curve.p90);
        if (p90Area) p90Area.setAttribute('d', curve.p90 + ' L 595 152 L 40 152 Z');
        baseLine.setAttribute('d', curve.base);
        if (baseArea) baseArea.setAttribute('d', curve.base + ' L 595 152 L 40 152 Z');
        
      }

      const origSwitchHorizon = window.switchTimeHorizon;
      window.switchTimeHorizon = function(horizon, btn) {
        if (typeof origSwitchHorizon === 'function') origSwitchHorizon(horizon, btn);
        applyHeroCurve(HORIZON_CURVES[horizon] || HORIZON_CURVES['30d']);
      };

      const origSwitchScenario = window.switchHeroScenario;
      window.switchHeroScenario = function(mode, btn) {
        if (typeof origSwitchScenario === 'function') origSwitchScenario(mode, btn);
        applyHeroCurve(SCENARIO_CURVES[mode] || SCENARIO_CURVES['baseline']);
        const goalBar = document.getElementById('shellGoalBar');
        const goalPct = document.getElementById('shellGoalPct');
        if (goalBar && goalPct) {
          if (mode === 'expansion') {
            goalBar.style.width = '98.8%';
            goalPct.textContent = '98.8%';
          } else if (mode === 'shock') {
            goalBar.style.width = '84.5%';
            goalPct.textContent = '84.5%';
          } else {
            goalBar.style.width = '94.2%';
            goalPct.textContent = '94.2%';
          }
        }
      };
    }
  }

  document.addEventListener('DOMContentLoaded', function() {
    window.updateThemeIcon();
    // Hero chart static

    const navWrapper = document.getElementById('ayevNavWrapper');
    const floatingNav = navWrapper ? navWrapper.querySelector('.ayev-floating-nav') : null;
    const navLinksContainer = navWrapper ? navWrapper.querySelector('.ayev-nav-links') : null;

    // Inject Top-Edge Hover Peek Zone & Scroll Progress Bar
    if (navWrapper && floatingNav) {
      const peekZone = document.createElement('div');
      peekZone.className = 'ayev-nav-peek-zone';
      peekZone.setAttribute('aria-hidden', 'true');
      document.body.prepend(peekZone);

      const progWrap = document.createElement('div');
      progWrap.className = 'ayev-nav-progress';
      const progBar = document.createElement('div');
      progBar.className = 'ayev-nav-progress-bar';
      progBar.id = 'ayevNavProgressBar';
      progWrap.appendChild(progBar);
      floatingNav.appendChild(progWrap);

      peekZone.addEventListener('mouseenter', function() {
        navWrapper.classList.remove('nav-hidden');
        navWrapper.classList.add('nav-peek-reveal');
      });

      navWrapper.addEventListener('mouseleave', function() {
        navWrapper.classList.remove('nav-peek-reveal');
      });
    }

    // Sliding Liquid Glass Nav Glider
    if (navLinksContainer) {
      const glider = document.createElement('div');
      glider.className = 'ayev-nav-glider';
      navLinksContainer.prepend(glider);

      const links = Array.from(navLinksContainer.querySelectorAll('.ayev-nav-link'));
      const activeLink = navLinksContainer.querySelector('.ayev-nav-link.active');

      function moveGliderTo(targetEl) {
        if (!targetEl) {
          glider.style.opacity = '0';
          return;
        }
        const parentRect = navLinksContainer.getBoundingClientRect();
        const rect = targetEl.getBoundingClientRect();
        const offsetLeft = rect.left - parentRect.left - 4;
        glider.style.width = rect.width + 'px';
        glider.style.transform = 'translate3d(' + offsetLeft + 'px, 0, 0)';
        glider.style.opacity = '1';
      }

      if (activeLink) {
        setTimeout(function() { moveGliderTo(activeLink); }, 60);
      }

      links.forEach(function(link) {
        link.addEventListener('mouseenter', function() {
          moveGliderTo(link);
        });
      });

      navLinksContainer.addEventListener('mouseleave', function() {
        if (activeLink) {
          moveGliderTo(activeLink);
        } else {
          glider.style.opacity = '0';
        }
      });

      window.addEventListener('resize', function() {
        if (activeLink) moveGliderTo(activeLink);
      }, { passive: true });
    }

    // Intelligent Scroll Auto-Hide / Reveal & Progress Update (120fps rAF locked)
    let lastScrollY = window.pageYOffset || document.documentElement.scrollTop;
    let ticking = false;

    window.addEventListener('scroll', function() {
      if (!ticking) {
        window.requestAnimationFrame(function() {
          const currentScrollY = window.pageYOffset || document.documentElement.scrollTop;
          const docHeight = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
          const scrollPct = Math.min(100, Math.max(0, (currentScrollY / docHeight) * 100));

          const progBar = document.getElementById('ayevNavProgressBar');
          if (progBar) {
            progBar.style.width = scrollPct.toFixed(1) + '%';
          }

          if (navWrapper) {
            if (currentScrollY > 24) {
              navWrapper.classList.add('is-scrolled');
            } else {
              navWrapper.classList.remove('is-scrolled');
            }

            const activeEl = document.activeElement;
            const isInputFocused = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable);
            const isMobileOpen = document.getElementById('ayevMobileDrawer')?.classList.contains('open');

            if (currentScrollY <= 60 || isInputFocused || isMobileOpen) {
              navWrapper.classList.remove('nav-hidden');
            } else if (currentScrollY > lastScrollY + 22 && currentScrollY > 140) {
              navWrapper.classList.add('nav-hidden');
              navWrapper.classList.remove('nav-peek-reveal');
            } else if (currentScrollY < lastScrollY - 16) {
              navWrapper.classList.remove('nav-hidden');
            }
          }

          lastScrollY = Math.max(0, currentScrollY);
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });

    // Zero-Lag Delegated Specular Spotlight Tracking ONLY on Leaf Interactive Cards
    const leafSpotlightSelector = '.kpi-telemetry-tile, .org-mini-card, .arch-layer-card, .ripple-card, .ayev-visual-showcase-card';
    document.querySelectorAll(leafSpotlightSelector).forEach(function(c) {
      c.classList.add('glass-spotlight-card');
    });

    let spotRaf = null;
    let activeSpotCard = null;
    let activeSpotRect = null;

    document.addEventListener('pointerover', function(e) {
      const card = e.target.closest ? e.target.closest(leafSpotlightSelector) : null;
      if (card !== activeSpotCard) {
        activeSpotCard = card;
        activeSpotRect = card ? card.getBoundingClientRect() : null;
      }
    }, { passive: true });

    document.addEventListener('pointermove', function(e) {
      if (!activeSpotCard || !activeSpotRect) return;
      const cx = e.clientX;
      const cy = e.clientY;
      if (!spotRaf) {
        spotRaf = requestAnimationFrame(function() {
          if (activeSpotCard && activeSpotRect) {
            activeSpotCard.style.setProperty('--mouse-x', (cx - activeSpotRect.left) + 'px');
            activeSpotCard.style.setProperty('--mouse-y', (cy - activeSpotRect.top) + 'px');
          }
          spotRaf = null;
        });
      }
    }, { passive: true });

    // Smooth Scroll-Reveal & Progress Bar Entrance Observer across all Public Pages
    if ('IntersectionObserver' in window) {
      const revealObserver = new IntersectionObserver(function(entries) {
        entries.forEach(function(entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            revealObserver.unobserve(entry.target);
          }
        });
      }, { threshold: 0.08, rootMargin: '0px 0px -24px 0px' });

      document.querySelectorAll('.reveal-up, .engine-showcase-card, .arch-layer-card, .model-card, .ripple-card').forEach(function(el) {
        if (!el.classList.contains('reveal-up')) {
          el.classList.add('reveal-up');
        }
        revealObserver.observe(el);
      });
    }

    // Inject Apple Spotlight Command Palette (⌘K) into Public Body
    if (!document.getElementById('ayevCmdBackdrop')) {
      const cmdModal = document.createElement('div');
      cmdModal.id = 'ayevCmdBackdrop';
      cmdModal.className = 'ayev-cmd-backdrop';
      cmdModal.innerHTML = [
        '<div class="ayev-cmd-dialog" onclick="event.stopPropagation()">',
        '  <div class="d-flex align-items-center gap-2 p-3" style="border-bottom: 1px solid var(--pub-border);">',
        '    <i class="fas fa-magnifying-glass text-primary ms-1"></i>',
        '    <input type="text" id="ayevCmdSearchInput" class="form-control border-0 bg-transparent shadow-none" placeholder="Jump to page, simulator engine, or theme action..." style="font-size: 0.92rem;">',
        '    <button type="button" class="ayev-kbd-badge border-0" onclick="closeAyevCommandPalette()">ESC</button>',
        '  </div>',
        '  <div class="p-2" style="max-height: 320px; overflow-y: auto;">',
        '    <div class="ayev-shell-nav-group-label">Public Platform & Architecture</div>',
        '    <a href="/" class="ayev-shell-nav-item ayev-cmd-item" data-search="home index overview dashboard cockpit"><span><i class="fas fa-house text-primary me-2"></i>Home & Executive App Shell</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/features" class="ayev-shell-nav-item ayev-cmd-item" data-search="features engines simulator financial twin"><span><i class="fas fa-cubes text-info me-2"></i>Six Interlocking Simulator Engines</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/architecture" class="ayev-shell-nav-item ayev-cmd-item" data-search="architecture kernel multi-tenant acid"><span><i class="fas fa-layer-group text-primary me-2"></i>Hexagonal Micro-Kernel Architecture</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/decision-models" class="ayev-shell-nav-item ayev-cmd-item" data-search="decision models monte carlo stochastic elasticity"><span><i class="fas fa-brain text-warning me-2"></i>Causal Decision Models & Monte Carlo</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/dependency-intelligence" class="ayev-shell-nav-item ayev-cmd-item" data-search="dependency graph dag topology departments"><span><i class="fas fa-sitemap text-success me-2"></i>Departmental Dependency Graph (DAG)</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <div class="ayev-shell-nav-group-label mt-2">Authentication & Theme</div>',
        '    <a href="/login" class="ayev-shell-nav-item ayev-cmd-item" data-search="login sign in cockpit auth"><span><i class="fas fa-arrow-right-to-bracket text-primary me-2"></i>Sign In to Decision Cockpit</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/setup" class="ayev-shell-nav-item ayev-cmd-item" data-search="register setup provision company organization"><span><i class="fas fa-shield-halved text-success me-2"></i>Provision New Enterprise Organization</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <div class="ayev-shell-nav-item ayev-cmd-item" data-search="theme dark light mode toggle glass" onclick="togglePublicTheme(); closeAyevCommandPalette();"><span><i class="fas fa-circle-half-stroke text-warning me-2"></i>Toggle Light / Dark Glass Theme</span><span class="ayev-kbd-badge">Theme</span></div>',
        '  </div>',
        '</div>'
      ].join('');
      cmdModal.addEventListener('click', function() {
        window.closeAyevCommandPalette();
      });
      document.body.appendChild(cmdModal);

      const inp = document.getElementById('ayevCmdSearchInput');
      if (inp) {
        inp.addEventListener('input', function() {
          filterCmdItems(this.value);
        });
      }
    }

    document.addEventListener('keydown', function(e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        window.openAyevCommandPalette();
      } else if (e.key === 'Escape') {
        window.closeAyevCommandPalette();
      }
    });
  });
})();
