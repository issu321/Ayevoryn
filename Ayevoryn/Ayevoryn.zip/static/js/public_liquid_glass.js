/* ==========================================================================
   AYEVORYN — INTELLIGENT LIQUID GLASS NAVBAR, THEME & COMMAND ENGINE
   1. Universal Light / Dark Theme Synchronization (WCAG AA/AAA Verified)
   2. 60fps Directional Scroll Auto-Hide / Compact Capsule Reveal + Top Peek
   3. Sliding Liquid Glass Pill Glider for Navigation Links
   4. Scroll Progress Laser Bar inside Floating Navbar
   5. Apple visionOS Cursor Specular Spotlight Tracking on Glass Cards
   6. Global ⌘K / Ctrl+K Spotlight Quick Navigation Command Palette
   ========================================================================== */

(function() {
  'use strict';

  // 1. Universal Public Theme Switcher & Icon Synchronizer (Works on ALL pages including Register/Login)
  window.updateThemeIcon = function() {
    const cur = document.documentElement.getAttribute('data-public-theme') || 'light';
    const icons = document.querySelectorAll('#pubThemeIcon, #publicThemeIcon, .ayev-theme-icon');
    icons.forEach(function(icon) {
      icon.className = cur === 'dark' ? 'fas fa-sun text-warning' : 'fas fa-moon';
    });
    const badges = document.querySelectorAll('.ayev-active-theme-label');
    badges.forEach(function(b) {
      b.textContent = cur === 'dark' ? 'Dark Glass' : 'Light Glass';
    });
  };

  window.togglePublicTheme = function() {
    const cur = document.documentElement.getAttribute('data-public-theme') || 'light';
    const next = cur === 'dark' ? 'light' : 'dark';
    document.documentElement.setAttribute('data-public-theme', next);
    try {
      localStorage.setItem('ayevoryn_public_theme', next);
    } catch (e) {}
    window.updateThemeIcon();
  };

  // 2. Global ⌘K Spotlight Command Palette
  window.openAyevCommandPalette = function() {
    let backdrop = document.getElementById('ayevCmdBackdrop');
    if (!backdrop) return;
    backdrop.classList.add('open');
    const inp = document.getElementById('ayevCmdSearchInput');
    if (inp) {
      inp.value = '';
      filterCmdItems('');
      setTimeout(function() { inp.focus(); }, 40);
    }
  };

  window.closeAyevCommandPalette = function() {
    const backdrop = document.getElementById('ayevCmdBackdrop');
    if (backdrop) backdrop.classList.remove('open');
  };

  // 3. Universal High-Polish Notification & Toast Engine with Working Close Button
  window.dismissNotification = function(btn) {
    if (!btn) return;
    const toast = btn.closest('.ayev-toast, .toast-glass, .alert, [role="alert"]');
    if (!toast) return;
    if (toast._timer) clearTimeout(toast._timer);
    toast.style.transition = 'all 0.28s cubic-bezier(0.16, 1, 0.3, 1)';
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(100%) scale(0.92)';
    setTimeout(function() {
      toast.remove();
      const wrap = document.getElementById('ayevToastContainer');
      if (wrap && wrap.children.length === 0) wrap.style.display = 'none';
    }, 280);
  };

  window.showToast = function(message, type, title) {
    type = type || 'info';
    if (type === 'error') type = 'danger';

    let container = document.getElementById('ayevToastContainer');
    if (!container) {
      container = document.createElement('div');
      container.id = 'ayevToastContainer';
      container.className = 'ayev-toast-container';
      document.body.appendChild(container);
    }
    container.style.display = 'flex';

    const icons = {
      success: 'fa-check-circle',
      danger: 'fa-triangle-exclamation',
      warning: 'fa-circle-exclamation',
      info: 'fa-circle-info'
    };
    const defaultTitles = {
      success: 'Success',
      danger: 'Notice',
      warning: 'Warning',
      info: 'Notification'
    };

    const toast = document.createElement('div');
    toast.className = 'ayev-toast ayev-toast-' + type;
    toast.setAttribute('role', 'alert');
    toast.setAttribute('aria-live', 'polite');
    toast.innerHTML = [
      '<div class="ayev-toast-icon"><i class="fas ' + (icons[type] || 'fa-bell') + '"></i></div>',
      '<div class="ayev-toast-body">',
      '  <div class="ayev-toast-title">' + (title || defaultTitles[type] || 'Notification') + '</div>',
      '  <div class="ayev-toast-msg">' + message + '</div>',
      '</div>',
      '<button type="button" class="ayev-toast-close" onclick="window.dismissNotification(this)" aria-label="Close notification" title="Close">',
      '  <i class="fas fa-times"></i>',
      '</button>',
      '<div class="ayev-toast-progress"><div class="ayev-toast-bar"></div></div>'
    ].join('');

    container.appendChild(toast);

    const duration = 4500;
    const bar = toast.querySelector('.ayev-toast-bar');
    if (bar) {
      bar.style.transition = 'width ' + duration + 'ms linear';
      requestAnimationFrame(function() {
        requestAnimationFrame(function() {
          bar.style.width = '0%';
        });
      });
    }

    toast._timer = setTimeout(function() {
      window.dismissNotification(toast.querySelector('.ayev-toast-close'));
    }, duration);

    toast.addEventListener('mouseenter', function() {
      if (toast._timer) clearTimeout(toast._timer);
      if (bar) {
        const computedWidth = window.getComputedStyle(bar).width;
        bar.style.transition = 'none';
        bar.style.width = computedWidth;
      }
    });

    toast.addEventListener('mouseleave', function() {
      toast._timer = setTimeout(function() {
        window.dismissNotification(toast.querySelector('.ayev-toast-close'));
      }, 1800);
    });
  };

  function filterCmdItems(query) {
    const q = (query || '').toLowerCase().trim();
    const items = document.querySelectorAll('.ayev-cmd-item');
    items.forEach(function(item) {
      const text = (item.getAttribute('data-search') || item.textContent || '').toLowerCase();
      item.style.display = (!q || text.indexOf(q) !== -1) ? 'flex' : 'none';
    });
  }

  document.addEventListener('DOMContentLoaded', function() {
    window.updateThemeIcon();

    const navWrapper = document.getElementById('ayevNavWrapper');
    const floatingNav = navWrapper ? navWrapper.querySelector('.ayev-floating-nav') : null;
    const navLinksContainer = navWrapper ? navWrapper.querySelector('.ayev-nav-links') : null;

    // Inject Top-Edge Hover Peek Zone & Scroll Progress Bar
    if (navWrapper && floatingNav) {
      const peekZone = document.createElement('div');
      peekZone.className = 'ayev-nav-peek-zone';
      peekZone.setAttribute('aria-hidden', 'true');
      document.body.prepend(peekZone);

      const progWrap = document.createElement('div');
      progWrap.className = 'ayev-nav-progress';
      const progBar = document.createElement('div');
      progBar.className = 'ayev-nav-progress-bar';
      progBar.id = 'ayevNavProgressBar';
      progWrap.appendChild(progBar);
      floatingNav.appendChild(progWrap);

      peekZone.addEventListener('mouseenter', function() {
        navWrapper.classList.remove('nav-hidden');
        navWrapper.classList.add('nav-peek-reveal');
      });

      navWrapper.addEventListener('mouseleave', function() {
        navWrapper.classList.remove('nav-peek-reveal');
      });

      window.addEventListener('mousemove', function(e) {
        if (e.clientY <= 48 && navWrapper.classList.contains('nav-hidden')) {
          navWrapper.classList.remove('nav-hidden');
          navWrapper.classList.add('nav-peek-reveal');
        }
      }, { passive: true });
    }

    // Sliding Liquid Glass Nav Glider
    if (navLinksContainer) {
      const glider = document.createElement('div');
      glider.className = 'ayev-nav-glider';
      navLinksContainer.prepend(glider);

      const links = Array.from(navLinksContainer.querySelectorAll('.ayev-nav-link'));
      const activeLink = navLinksContainer.querySelector('.ayev-nav-link.active');

      function moveGliderTo(targetEl) {
        if (!targetEl) {
          glider.style.opacity = '0';
          return;
        }
        const parentRect = navLinksContainer.getBoundingClientRect();
        const rect = targetEl.getBoundingClientRect();
        const offsetLeft = rect.left - parentRect.left - 4;
        glider.style.width = rect.width + 'px';
        glider.style.transform = 'translate3d(' + offsetLeft + 'px, 0, 0)';
        glider.style.opacity = '1';
      }

      if (activeLink) {
        setTimeout(function() { moveGliderTo(activeLink); }, 60);
      }

      links.forEach(function(link) {
        link.addEventListener('mouseenter', function() {
          moveGliderTo(link);
        });
      });

      navLinksContainer.addEventListener('mouseleave', function() {
        if (activeLink) {
          moveGliderTo(activeLink);
        } else {
          glider.style.opacity = '0';
        }
      });

      window.addEventListener('resize', function() {
        if (activeLink) moveGliderTo(activeLink);
      }, { passive: true });
    }

    // Intelligent Scroll Auto-Hide / Reveal & Progress Update
    let lastScrollY = window.pageYOffset || document.documentElement.scrollTop;
    let ticking = false;

    window.addEventListener('scroll', function() {
      if (!ticking) {
        window.requestAnimationFrame(function() {
          const currentScrollY = window.pageYOffset || document.documentElement.scrollTop;
          const docHeight = Math.max(1, document.documentElement.scrollHeight - window.innerHeight);
          const scrollPct = Math.min(100, Math.max(0, (currentScrollY / docHeight) * 100));

          const progBar = document.getElementById('ayevNavProgressBar');
          if (progBar) {
            progBar.style.width = scrollPct.toFixed(1) + '%';
          }

          if (navWrapper) {
            if (currentScrollY > 24) {
              navWrapper.classList.add('is-scrolled');
            } else {
              navWrapper.classList.remove('is-scrolled');
            }

            const activeEl = document.activeElement;
            const isInputFocused = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA' || activeEl.isContentEditable);
            const isMobileOpen = document.getElementById('ayevMobileDrawer')?.classList.contains('open');

            if (currentScrollY <= 60 || isInputFocused || isMobileOpen) {
              navWrapper.classList.remove('nav-hidden');
            } else if (currentScrollY > lastScrollY + 20 && currentScrollY > 120) {
              navWrapper.classList.add('nav-hidden');
              navWrapper.classList.remove('nav-peek-reveal');
            } else if (currentScrollY < lastScrollY - 16) {
              navWrapper.classList.remove('nav-hidden');
            }
          }

          lastScrollY = Math.max(0, currentScrollY);
          ticking = false;
        });
        ticking = true;
      }
    }, { passive: true });

    // Cursor Specular Spotlight Tracking across Glass Cards (Optimized to eliminate layout thrashing)
    const glassSelectors = [
      '.ayev-hero-glass-shell',
      '.ayev-glass-surface',
      '.hero-showcase-frame',
      '.kpi-telemetry-tile',
      '.org-mini-card',
      '.arch-layer-card',
      '.engine-showcase-card',
      '.model-card',
      '.ripple-card',
      '.ayev-visual-showcase-card',
      '.telemetry-preview-panel',
      '.matrix-table-wrap',
      '.dept-card',
      '.login-card-glass',
      '.wizard-card'
    ].join(',');

    const cards = document.querySelectorAll(glassSelectors);
    cards.forEach(function(card) {
      card.classList.add('glass-spotlight-card');
      let cachedRect = null;
      let rafId = null;

      card.addEventListener('mouseenter', function() {
        cachedRect = card.getBoundingClientRect();
      }, { passive: true });

      card.addEventListener('mouseleave', function() {
        cachedRect = null;
        if (rafId) {
          cancelAnimationFrame(rafId);
          rafId = null;
        }
      }, { passive: true });

      card.addEventListener('mousemove', function(e) {
        if (!cachedRect) cachedRect = card.getBoundingClientRect();
        const clientX = e.clientX;
        const clientY = e.clientY;

        if (!rafId) {
          rafId = requestAnimationFrame(function() {
            if (cachedRect) {
              const x = clientX - cachedRect.left;
              const y = clientY - cachedRect.top;
              card.style.setProperty('--mouse-x', x + 'px');
              card.style.setProperty('--mouse-y', y + 'px');
            }
            rafId = null;
          });
        }
      }, { passive: true });
    });

    // Inject Apple Spotlight Command Palette (⌘K) into Public Body
    if (!document.getElementById('ayevCmdBackdrop')) {
      const cmdModal = document.createElement('div');
      cmdModal.id = 'ayevCmdBackdrop';
      cmdModal.className = 'ayev-cmd-backdrop';
      cmdModal.innerHTML = [
        '<div class="ayev-cmd-dialog" onclick="event.stopPropagation()">',
        '  <div class="d-flex align-items-center gap-2 p-3" style="border-bottom: 1px solid var(--pub-border);">',
        '    <i class="fas fa-magnifying-glass text-primary ms-1"></i>',
        '    <input type="text" id="ayevCmdSearchInput" class="form-control border-0 bg-transparent shadow-none" placeholder="Jump to page, simulator engine, or theme action..." style="font-size: 0.92rem;">',
        '    <button type="button" class="ayev-kbd-badge border-0" onclick="closeAyevCommandPalette()">ESC</button>',
        '  </div>',
        '  <div class="p-2" style="max-height: 320px; overflow-y: auto;">',
        '    <div class="ayev-shell-nav-group-label">Public Platform & Architecture</div>',
        '    <a href="/" class="ayev-shell-nav-item ayev-cmd-item" data-search="home index overview dashboard cockpit"><span><i class="fas fa-house text-primary me-2"></i>Home & Executive App Shell</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/features" class="ayev-shell-nav-item ayev-cmd-item" data-search="features engines simulator financial twin"><span><i class="fas fa-cubes text-info me-2"></i>Six Interlocking Simulator Engines</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/architecture" class="ayev-shell-nav-item ayev-cmd-item" data-search="architecture kernel multi-tenant acid"><span><i class="fas fa-layer-group text-primary me-2"></i>Hexagonal Micro-Kernel Architecture</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/decision-models" class="ayev-shell-nav-item ayev-cmd-item" data-search="decision models monte carlo stochastic elasticity"><span><i class="fas fa-brain text-warning me-2"></i>Causal Decision Models & Monte Carlo</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/dependency-intelligence" class="ayev-shell-nav-item ayev-cmd-item" data-search="dependency graph dag topology departments"><span><i class="fas fa-sitemap text-success me-2"></i>Departmental Dependency Graph (DAG)</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <div class="ayev-shell-nav-group-label mt-2">Authentication & Theme</div>',
        '    <a href="/login" class="ayev-shell-nav-item ayev-cmd-item" data-search="login sign in cockpit auth"><span><i class="fas fa-arrow-right-to-bracket text-primary me-2"></i>Sign In to Decision Cockpit</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <a href="/setup" class="ayev-shell-nav-item ayev-cmd-item" data-search="register setup provision company organization"><span><i class="fas fa-shield-halved text-success me-2"></i>Provision New Enterprise Organization</span><span class="ayev-kbd-badge">↵</span></a>',
        '    <div class="ayev-shell-nav-item ayev-cmd-item" data-search="theme dark light mode toggle glass" onclick="togglePublicTheme(); closeAyevCommandPalette();"><span><i class="fas fa-circle-half-stroke text-warning me-2"></i>Toggle Light / Dark Glass Theme</span><span class="ayev-kbd-badge">Theme</span></div>',
        '  </div>',
        '</div>'
      ].join('');
      cmdModal.addEventListener('click', function() {
        window.closeAyevCommandPalette();
      });
      document.body.appendChild(cmdModal);

      const inp = document.getElementById('ayevCmdSearchInput');
      if (inp) {
        inp.addEventListener('input', function() {
          filterCmdItems(this.value);
        });
      }
    }

    document.addEventListener('keydown', function(e) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        window.openAyevCommandPalette();
      } else if (e.key === 'Escape') {
        window.closeAyevCommandPalette();
      }
    });
  });
})();
