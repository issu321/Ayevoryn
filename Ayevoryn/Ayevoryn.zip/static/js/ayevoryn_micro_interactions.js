/* ==========================================================================
   AYEVORYN TACTILE MICRO-INTERACTIONS & RELIABLE CLIPBOARD ENGINE (V1.0)
   - Guaranteed real clipboard copy (Clipboard API + execCommand fallback)
   - #40 Copy -> Copied! morphing pill, #21 Ripple Tap, #13 Send Swoosh, #41 Theme Spin
   ========================================================================== */
(function () {
    'use strict';

    function showMicroToast(message) {
        let el = document.getElementById('ayvMicroToast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'ayvMicroToast';
            el.className = 'ayv-micro-toast';
            document.body.appendChild(el);
        }
        el.innerHTML = '<i class="fas fa-circle-check" style="color:#34D399;"></i><span>' + String(message || 'Copied to clipboard') + '</span>';
        el.classList.add('show');
        clearTimeout(el._timer);
        el._timer = setTimeout(function () { el.classList.remove('show'); }, 1800);
    }

    function fallbackExecCopy(text) {
        try {
            const ta = document.createElement('textarea');
            ta.value = text;
            ta.setAttribute('readonly', '');
            ta.style.position = 'fixed';
            ta.style.top = '-9999px';
            ta.style.left = '-9999px';
            ta.style.opacity = '0';
            document.body.appendChild(ta);
            ta.focus();
            ta.select();
            ta.setSelectionRange(0, text.length);
            const ok = document.execCommand('copy');
            document.body.removeChild(ta);
            return !!ok;
        } catch (e) {
            return false;
        }
    }

    function confirmCopyVisual(btnEl) {
        showMicroToast('Copied to clipboard');
        if (!btnEl) return;
        if (!btnEl.dataset.origHtml) {
            btnEl.dataset.origHtml = btnEl.innerHTML;
        }
        btnEl.classList.add('ayv-copy-confirmed');
        btnEl.innerHTML = '<i class="fas fa-check me-1"></i>Copied!';
        clearTimeout(btnEl._copyTimer);
        btnEl._copyTimer = setTimeout(function () {
            btnEl.classList.remove('ayv-copy-confirmed');
            if (btnEl.dataset.origHtml) btnEl.innerHTML = btnEl.dataset.origHtml;
        }, 1700);
    }

    /**
     * Real, guaranteed clipboard copy across HTTP localhost, LAN IPs, and HTTPS.
     * Animates the button to "Copied!" ONLY after clipboard write actually succeeds.
     */
    window.ayvCopyText = function (rawText, btnEl) {
        const text = String(rawText || '').trim();
        if (!text) return Promise.resolve(false);

        if (navigator.clipboard && typeof navigator.clipboard.writeText === 'function' && window.isSecureContext) {
            return navigator.clipboard.writeText(text).then(function () {
                confirmCopyVisual(btnEl);
                return true;
            }).catch(function () {
                const ok = fallbackExecCopy(text);
                if (ok) confirmCopyVisual(btnEl);
                return ok;
            });
        }
        const ok = fallbackExecCopy(text);
        if (ok) confirmCopyVisual(btnEl);
        return Promise.resolve(ok);
    };

    // #21 Subtle Ripple Tap on primary & pill buttons
    document.addEventListener('click', function (e) {
        const btn = e.target.closest('.btn-primary, .ayv-btn-primary-pill, .ayv-btn-ghost-pill, .btn-outline-glass');
        if (btn && !btn.disabled) {
            btn.classList.add('ayv-ripple-host');
            const rect = btn.getBoundingClientRect();
            const size = Math.max(rect.width, rect.height) * 0.65;
            const wave = document.createElement('span');
            wave.className = 'ayv-ripple-wave';
            wave.style.width = wave.style.height = size + 'px';
            wave.style.left = (e.clientX - rect.left - size / 2) + 'px';
            wave.style.top = (e.clientY - rect.top - size / 2) + 'px';
            btn.appendChild(wave);
            setTimeout(function () { wave.remove(); }, 540);
        }

        // #41 Day/Night theme icon spin
        const themeBtn = e.target.closest('[data-theme-toggle-btn], #themeToggleBtn, .theme-toggle-btn');
        if (themeBtn) {
            themeBtn.classList.remove('ayv-theme-spin');
            void themeBtn.offsetWidth;
            themeBtn.classList.add('ayv-theme-spin');
        }

        // #13 Send button swoosh
        const sendBtn = e.target.closest('button[type="submit"], .ayev-send-btn, #pulseSendBtn');
        if (sendBtn && sendBtn.querySelector('.fa-paper-plane')) {
            sendBtn.classList.remove('ayv-send-swoosh');
            void sendBtn.offsetWidth;
            sendBtn.classList.add('ayv-send-swoosh');
        }
    });
})();
