/* ==========================================================================
   AYEVORYN INSTITUTIONAL TRADING-LEVEL INTERACTIVE CHART ENGINE
   - Candlesticks + Volume Histogram + 20-EMA + Monte Carlo P10/P50/P90 Fan
   - Interactive Crosshair HUD + Timeframe (1M/3M/6M/1Y) & Scenario Switcher
   - Theme-aware (Dark & Light) high-DPI HTML5 Canvas rendering
   ========================================================================== */
(function () {
    'use strict';

    function generateSeries(points, scenario) {
        const drift = scenario === 'bull' ? 0.0085 : (scenario === 'stress' ? -0.0042 : 0.0038);
        const vol = scenario === 'stress' ? 0.028 : (scenario === 'bull' ? 0.020 : 0.016);
        let seed = scenario === 'bull' ? 4211 : (scenario === 'stress' ? 9137 : 1337);
        function rand() {
            seed = (seed * 1664525 + 1013904223) % 4294967296;
            return seed / 4294967296;
        }

        const data = [];
        let price = 100.0;
        const now = new Date();
        for (let i = 0; i < points; i++) {
            const dt = new Date(now.getTime() - (points - 1 - i) * 86400000);
            const open = price;
            const shock = (rand() - 0.48) * 2 * vol;
            const close = Math.max(40, open * (1 + drift + shock));
            const high = Math.max(open, close) * (1 + rand() * vol * 0.7);
            const low = Math.min(open, close) * (1 - rand() * vol * 0.7);
            const volume = Math.round(120 + rand() * 380 + Math.abs(close - open) * 28);
            data.push({
                label: dt.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
                open: +open.toFixed(2),
                high: +high.toFixed(2),
                low: +low.toFixed(2),
                close: +close.toFixed(2),
                volume: volume
            });
            price = close;
        }

        // Compute 10-period EMA
        const k = 2 / (10 + 1);
        let ema = data[0].close;
        data.forEach(function (d, idx) {
            ema = idx === 0 ? d.close : d.close * k + ema * (1 - k);
            d.ema = +ema.toFixed(2);
        });

        // Append 14-day stochastic forecast fan (P10, P50, P90)
        const forecast = [];
        const last = data[data.length - 1].close;
        for (let step = 1; step <= 14; step++) {
            const dt = new Date(now.getTime() + step * 86400000);
            const p50 = last * Math.pow(1 + drift, step);
            const spread = last * vol * Math.sqrt(step) * 1.45;
            forecast.push({
                label: dt.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
                p50: +p50.toFixed(2),
                p90: +(p50 + spread).toFixed(2),
                p10: +Math.max(20, p50 - spread).toFixed(2),
            });
        }
        return { history: data, forecast: forecast };
    }

    function initTradingChart(root) {
        const canvas = root.querySelector('canvas[data-ayv-trading-canvas]');
        if (!canvas) return;
        const ctx = canvas.getContext('2d');

        let timeframe = '3M';
        let scenario = 'base';
        let hoverIdx = -1;
        let dataset = generateSeries(60, scenario);

        const tfMap = { '1M': 30, '3M': 60, '6M': 90, '1Y': 120 };

        function updateHud(idx) {
            const hud = root.querySelector('[data-ayv-chart-hud]');
            if (!hud) return;
            const totalHist = dataset.history.length;
            if (idx >= 0 && idx < totalHist) {
                const c = dataset.history[idx];
                const chg = (((c.close - c.open) / c.open) * 100).toFixed(2);
                const cls = c.close >= c.open ? '#10B981' : '#EF4444';
                hud.innerHTML =
                    '<span>Date: <strong>' + c.label + '</strong></span>' +
                    '<span>O: <strong>' + c.open.toFixed(2) + '</strong></span>' +
                    '<span>H: <strong>' + c.high.toFixed(2) + '</strong></span>' +
                    '<span>L: <strong>' + c.low.toFixed(2) + '</strong></span>' +
                    '<span>C: <strong style="color:' + cls + ';">' + c.close.toFixed(2) + ' (' + (chg >= 0 ? '+' : '') + chg + '%)</strong></span>' +
                    '<span>EMA(10): <strong style="color:#38BDF8;">' + c.ema.toFixed(2) + '</strong></span>' +
                    '<span>Vol Index: <strong>' + c.volume + '</strong></span>';
            } else if (idx >= totalHist && idx < totalHist + dataset.forecast.length) {
                const f = dataset.forecast[idx - totalHist];
                hud.innerHTML =
                    '<span>Forecast: <strong>' + f.label + '</strong></span>' +
                    '<span>P90 Upper: <strong style="color:#10B981;">' + f.p90.toFixed(2) + '</strong></span>' +
                    '<span>P50 Median: <strong style="color:#38BDF8;">' + f.p50.toFixed(2) + '</strong></span>' +
                    '<span>P10 Stress: <strong style="color:#F59E0B;">' + f.p10.toFixed(2) + '</strong></span>';
            } else {
                const last = dataset.history[totalHist - 1];
                const fEnd = dataset.forecast[dataset.forecast.length - 1];
                hud.innerHTML =
                    '<span>Index Close: <strong>' + last.close.toFixed(2) + '</strong></span>' +
                    '<span>EMA(10): <strong style="color:#38BDF8;">' + last.ema.toFixed(2) + '</strong></span>' +
                    '<span>14D P50 Target: <strong style="color:#10B981;">' + fEnd.p50.toFixed(2) + '</strong></span>' +
                    '<span>Confidence Band: <strong>' + fEnd.p10.toFixed(1) + ' – ' + fEnd.p90.toFixed(1) + '</strong></span>';
            }
        }

        function draw() {
            const dpr = window.devicePixelRatio || 1;
            const rect = canvas.parentElement.getBoundingClientRect();
            const w = Math.max(320, rect.width);
            const h = Math.max(280, rect.height);
            canvas.width = w * dpr;
            canvas.height = h * dpr;
            canvas.style.width = w + 'px';
            canvas.style.height = h + 'px';
            ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

            const isDark = (document.documentElement.getAttribute('data-theme') || 'dark') === 'dark';
            const gridColor = isDark ? 'rgba(148, 163, 184, 0.12)' : 'rgba(15, 23, 42, 0.08)';
            const textColor = isDark ? '#94A3B8' : '#475569';
            const crossColor = isDark ? 'rgba(56, 189, 248, 0.45)' : 'rgba(2, 132, 199, 0.45)';

            ctx.clearRect(0, 0, w, h);

            const padL = 16, padR = 58, padT = 18, padB = 34;
            const plotW = w - padL - padR;
            const plotH = h - padT - padB;
            const volH = plotH * 0.22;
            const priceH = plotH - volH - 10;

            const hist = dataset.history;
            const fc = dataset.forecast;
            const totalCols = hist.length + fc.length;
            const stepX = plotW / totalCols;

            let minP = Infinity, maxP = -Infinity, maxVol = 1;
            hist.forEach(function (d) {
                if (d.low < minP) minP = d.low;
                if (d.high > maxP) maxP = d.high;
                if (d.volume > maxVol) maxVol = d.volume;
            });
            fc.forEach(function (f) {
                if (f.p10 < minP) minP = f.p10;
                if (f.p90 > maxP) maxP = f.p90;
            });
            const pPad = (maxP - minP) * 0.08 || 1;
            minP -= pPad;
            maxP += pPad;

            function yPrice(v) {
                return padT + (1 - (v - minP) / (maxP - minP)) * priceH;
            }
            function xCol(i) {
                return padL + (i + 0.5) * stepX;
            }

            // Grid lines & right price axis
            ctx.strokeStyle = gridColor;
            ctx.lineWidth = 1;
            ctx.font = '11px ui-monospace, SFMono-Regular, monospace';
            ctx.fillStyle = textColor;
            ctx.textAlign = 'left';
            for (let g = 0; g <= 5; g++) {
                const y = padT + (priceH / 5) * g;
                const val = maxP - ((maxP - minP) / 5) * g;
                ctx.beginPath();
                ctx.moveTo(padL, y);
                ctx.lineTo(w - padR, y);
                ctx.stroke();
                ctx.fillText(val.toFixed(1), w - padR + 8, y + 4);
            }

            // Forecast zone shading
            const fcStartX = xCol(hist.length - 1);
            ctx.fillStyle = isDark ? 'rgba(56, 189, 248, 0.05)' : 'rgba(2, 132, 199, 0.05)';
            ctx.fillRect(fcStartX, padT, w - padR - fcStartX, plotH);

            // Monte Carlo P10-P90 confidence cone
            ctx.beginPath();
            ctx.moveTo(fcStartX, yPrice(hist[hist.length - 1].close));
            fc.forEach(function (f, i) { ctx.lineTo(xCol(hist.length + i), yPrice(f.p90)); });
            for (let i = fc.length - 1; i >= 0; i--) {
                ctx.lineTo(xCol(hist.length + i), yPrice(fc[i].p10));
            }
            ctx.closePath();
            ctx.fillStyle = isDark ? 'rgba(56, 189, 248, 0.16)' : 'rgba(2, 132, 199, 0.14)';
            ctx.fill();

            // P50 dashed median line
            ctx.beginPath();
            ctx.setLineDash([5, 4]);
            ctx.strokeStyle = '#38BDF8';
            ctx.lineWidth = 2;
            ctx.moveTo(fcStartX, yPrice(hist[hist.length - 1].close));
            fc.forEach(function (f, i) { ctx.lineTo(xCol(hist.length + i), yPrice(f.p50)); });
            ctx.stroke();
            ctx.setLineDash([]);

            // Volume histogram
            const volBaseY = padT + plotH;
            const candleW = Math.max(2.5, Math.min(10, stepX * 0.64));
            hist.forEach(function (d, i) {
                const x = xCol(i);
                const vh = (d.volume / maxVol) * volH;
                const up = d.close >= d.open;
                ctx.fillStyle = up ? 'rgba(16, 185, 129, 0.28)' : 'rgba(239, 68, 68, 0.28)';
                ctx.fillRect(x - candleW / 2, volBaseY - vh, candleW, vh);
            });

            // Candlesticks
            hist.forEach(function (d, i) {
                const x = xCol(i);
                const up = d.close >= d.open;
                const col = up ? '#10B981' : '#EF4444';
                ctx.strokeStyle = col;
                ctx.lineWidth = 1.25;
                ctx.beginPath();
                ctx.moveTo(x, yPrice(d.high));
                ctx.lineTo(x, yPrice(d.low));
                ctx.stroke();

                const top = yPrice(Math.max(d.open, d.close));
                const bot = yPrice(Math.min(d.open, d.close));
                ctx.fillStyle = col;
                ctx.fillRect(x - candleW / 2, top, candleW, Math.max(1.5, bot - top));
            });

            // 10-EMA smooth line
            ctx.beginPath();
            ctx.strokeStyle = isDark ? '#38BDF8' : '#0284C7';
            ctx.lineWidth = 2;
            hist.forEach(function (d, i) {
                const x = xCol(i), y = yPrice(d.ema);
                if (i === 0) ctx.moveTo(x, y);
                else ctx.lineTo(x, y);
            });
            ctx.stroke();

            // X-axis labels
            ctx.fillStyle = textColor;
            ctx.textAlign = 'center';
            const labelEvery = Math.max(1, Math.floor(totalCols / 7));
            for (let i = 0; i < totalCols; i += labelEvery) {
                const lbl = i < hist.length ? hist[i].label : fc[i - hist.length].label;
                ctx.fillText(lbl, xCol(i), h - 10);
            }

            // Crosshair
            if (hoverIdx >= 0 && hoverIdx < totalCols) {
                const hx = xCol(hoverIdx);
                ctx.strokeStyle = crossColor;
                ctx.lineWidth = 1;
                ctx.setLineDash([3, 3]);
                ctx.beginPath();
                ctx.moveTo(hx, padT);
                ctx.lineTo(hx, padT + plotH);
                ctx.stroke();
                ctx.setLineDash([]);
            }
        }

        root.querySelectorAll('[data-ayv-tf]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                root.querySelectorAll('[data-ayv-tf]').forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                timeframe = btn.getAttribute('data-ayv-tf');
                dataset = generateSeries(tfMap[timeframe] || 60, scenario);
                hoverIdx = -1;
                updateHud(-1);
                draw();
            });
        });

        root.querySelectorAll('[data-ayv-scenario]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                root.querySelectorAll('[data-ayv-scenario]').forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                scenario = btn.getAttribute('data-ayv-scenario');
                dataset = generateSeries(tfMap[timeframe] || 60, scenario);
                hoverIdx = -1;
                updateHud(-1);
                draw();
            });
        });

        canvas.addEventListener('mousemove', function (e) {
            const rect = canvas.getBoundingClientRect();
            const relX = e.clientX - rect.left - 16;
            const plotW = Math.max(1, rect.width - 74);
            const totalCols = dataset.history.length + dataset.forecast.length;
            const idx = Math.floor((relX / plotW) * totalCols);
            hoverIdx = (idx >= 0 && idx < totalCols) ? idx : -1;
            updateHud(hoverIdx);
            draw();
        });

        canvas.addEventListener('mouseleave', function () {
            hoverIdx = -1;
            updateHud(-1);
            draw();
        });

        window.addEventListener('resize', draw);
        window.addEventListener('ayevoryn:theme-changed', draw);
        updateHud(-1);
        draw();
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-ayv-trading-chart]').forEach(initTradingChart);
    });
})();
