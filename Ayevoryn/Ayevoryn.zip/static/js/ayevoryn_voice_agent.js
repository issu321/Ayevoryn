/**
 * Ayevoryn Human Voice Agent & Smooth AI Stream Animator (USMANIA TECHS PVT LTD)
 * - Single curated Google human female voice: Aria (Google Cloud Chirp3-HD / Gemini Kore / Browser Google US Female)
 * - Sentence-by-sentence pipelined audio streaming: fetches & plays sentence 1 immediately while prefetching sentence 2
 * - STRICT Voice-OFF Gate: Voice replies default to OFF and NEVER auto-speak when OFF
 * - Smooth Gemini-style token-by-token text reveal animation (window.AyevorynStreamAnimator)
 */
(function (global) {
    'use strict';

    var currentAudio = null;
    var activeSessionId = 0;
    var activeAbortControllers = [];

    // Normalize legacy 'true'/'false' values into canonical '1'/'0' (strictly OFF by default)
    (function normalizeVoicePref() {
        try {
            var raw = localStorage.getItem('ayevoryn_voice_reply_enabled');
            if (raw === 'true') localStorage.setItem('ayevoryn_voice_reply_enabled', '1');
            else if (raw !== '1') localStorage.setItem('ayevoryn_voice_reply_enabled', '0');
            localStorage.setItem('ayevoryn_voice_persona', 'female_us');
        } catch (e) {}
    })();

    var FEMALE_VOICE_PATTERNS = [
        /google us english/i,
        /google uk english female/i,
        /microsoft aria online/i,
        /microsoft jenny online/i,
        /microsoft ava online/i,
        /samantha/i,
        /karen|moira|tessa|victoria/i,
        /female|aria|jenny|zira/i
    ];

    function getPersona() {
        return 'female_us';
    }

    function setPersona() {
        try { localStorage.setItem('ayevoryn_voice_persona', 'female_us'); } catch (e) {}
    }

    function isAutoReplyEnabled() {
        try {
            return localStorage.getItem('ayevoryn_voice_reply_enabled') === '1';
        } catch (e) {
            return false;
        }
    }

    function setAutoReplyEnabled(enabled) {
        try {
            localStorage.setItem('ayevoryn_voice_reply_enabled', enabled ? '1' : '0');
        } catch (e) {}
        if (!enabled) stop();
        global.dispatchEvent(new CustomEvent('ayevoryn:voicechange', { detail: { enabled: !!enabled } }));
    }

    function stop() {
        activeSessionId += 1;
        while (activeAbortControllers.length) {
            var ctrl = activeAbortControllers.pop();
            try { ctrl.abort(); } catch (e) {}
        }
        if (currentAudio) {
            try {
                currentAudio.pause();
                currentAudio.currentTime = 0;
                currentAudio.src = '';
            } catch (e) {}
            currentAudio = null;
        }
        try {
            if (global.speechSynthesis) global.speechSynthesis.cancel();
        } catch (e) {}
    }

    function cleanForSpeech(text) {
        return String(text || '')
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            .replace(/```[\s\S]*?```/g, ' ')
            .replace(/^\|?[\s:\-|]+\|?$/gm, ' ')
            .replace(/[#*`_~>|]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /**
     * Split response into short natural chunks for sub-2s first-sentence playback.
     * Chunk 1 is capped at ~145 chars so it synthesizes & starts speaking right away.
     */
    function splitIntoSpeechChunks(cleanText) {
        if (!cleanText) return [];
        var rawSentences = cleanText.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [cleanText];
        var chunks = [];
        var current = '';
        for (var i = 0; i < rawSentences.length; i++) {
            var s = rawSentences[i].trim();
            if (!s) continue;
            var limit = chunks.length === 0 ? 145 : 210;
            if (!current) {
                current = s.length > limit ? s.slice(0, limit).trim() : s;
            } else if ((current.length + 1 + s.length) <= limit) {
                current += ' ' + s;
            } else {
                chunks.push(current);
                current = s.length > 210 ? s.slice(0, 210).trim() : s;
            }
            if (chunks.length >= 4) break;
        }
        if (current && chunks.length < 4) chunks.push(current);
        return chunks;
    }

    function pickBestHumanBrowserVoice() {
        if (!global.speechSynthesis || typeof global.speechSynthesis.getVoices !== 'function') return null;
        var voices = global.speechSynthesis.getVoices() || [];
        if (!voices.length) return null;
        for (var i = 0; i < FEMALE_VOICE_PATTERNS.length; i++) {
            for (var j = 0; j < voices.length; j++) {
                var v = voices[j];
                var label = (v.name || '') + ' ' + (v.lang || '');
                if (FEMALE_VOICE_PATTERNS[i].test(label)) return v;
            }
        }
        return voices.find(function (v) { return /^en/i.test(v.lang || ''); }) || voices[0];
    }

    function speakChunkWithBrowserVoice(chunkText, sessionId) {
        return new Promise(function (resolve) {
            if (sessionId !== activeSessionId || !global.speechSynthesis) {
                resolve();
                return;
            }
            try {
                global.speechSynthesis.cancel();
                var utter = new SpeechSynthesisUtterance(chunkText);
                var voice = pickBestHumanBrowserVoice();
                if (voice) utter.voice = voice;
                utter.rate = 1.03;
                utter.pitch = 1.04;
                utter.onend = function () { resolve(); };
                utter.onerror = function () { resolve(); };
                global.speechSynthesis.speak(utter);
            } catch (e) {
                resolve();
            }
        });
    }

    function fetchChunkAudio(chunkText, sessionId) {
        var csrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
        var headers = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
        if (csrf) headers['X-CSRFToken'] = csrf;

        var ctrl = new AbortController();
        activeAbortControllers.push(ctrl);

        return fetch('/pulse-ai/api/voice/synthesize', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ text: chunkText, voice_id: 'female_us' }),
            signal: ctrl.signal
        })
        .then(function (r) { return r.json(); })
        .catch(function () { return { success: false }; })
        .then(function (data) {
            if (sessionId !== activeSessionId) return null;
            return data;
        });
    }

    function playAudioBase64(data, chunkText, sessionId) {
        return new Promise(function (resolve) {
            if (sessionId !== activeSessionId) {
                resolve();
                return;
            }
            if (data && data.success && data.audio_base64) {
                var src = 'data:' + (data.mime_type || 'audio/mpeg') + ';base64,' + data.audio_base64;
                var audio = new Audio(src);
                currentAudio = audio;
                audio.onended = function () {
                    if (currentAudio === audio) currentAudio = null;
                    resolve();
                };
                audio.onerror = function () {
                    if (currentAudio === audio) currentAudio = null;
                    speakChunkWithBrowserVoice(chunkText, sessionId).then(resolve);
                };
                audio.play().catch(function () {
                    if (currentAudio === audio) currentAudio = null;
                    speakChunkWithBrowserVoice(chunkText, sessionId).then(resolve);
                });
            } else {
                speakChunkWithBrowserVoice(chunkText, sessionId).then(resolve);
            }
        });
    }

    /**
     * Speak text with Aria (Google Human Female Voice) using pipelined sentence streaming.
     * opts:
     *   - auto: true  -> STRICTLY obeys isAutoReplyEnabled(). If OFF, does NOTHING.
     *   - force: true -> Explicit manual click ("Listen", "Test Voice", or active Live Voice Call).
     *   - onStart / onEnd callbacks.
     */
    function speak(text, opts) {
        var options = (opts && typeof opts === 'object') ? opts : {};
        var isAuto = Boolean(options.auto) && !Boolean(options.force);
        if (isAuto && !isAutoReplyEnabled()) {
            return Promise.resolve();
        }

        var clean = cleanForSpeech(text);
        var chunks = splitIntoSpeechChunks(clean);
        if (!chunks.length) return Promise.resolve();

        stop();
        var sessionId = activeSessionId;
        if (typeof options.onStart === 'function') {
            try { options.onStart(); } catch (e) {}
        }

        // Pipeline: prefetch chunk[i+1] while chunk[i] is playing!
        var nextFetchPromise = fetchChunkAudio(chunks[0], sessionId);

        var chain = Promise.resolve();
        chunks.forEach(function (chunkText, idx) {
            chain = chain.then(function () {
                if (sessionId !== activeSessionId) return;
                var currentFetch = nextFetchPromise;
                if (idx + 1 < chunks.length) {
                    nextFetchPromise = fetchChunkAudio(chunks[idx + 1], sessionId);
                } else {
                    nextFetchPromise = null;
                }
                return currentFetch.then(function (audioData) {
                    if (sessionId !== activeSessionId) return;
                    return playAudioBase64(audioData, chunkText, sessionId);
                });
            });
        });

        return chain.finally(function () {
            if (typeof options.onEnd === 'function') {
                try { options.onEnd(); } catch (e) {}
            }
        });
    }

    function previewVoice() {
        return speak(
            'Hi! I am Aria, your Aevoryn Pulse AI voice assistant. I am ready to analyze live metrics, monitor anomalies, and automate your workspace.',
            { force: true }
        );
    }

    // Preload browser voices cleanly
    if (global.speechSynthesis && typeof global.speechSynthesis.onvoiceschanged !== 'undefined') {
        global.speechSynthesis.onvoiceschanged = function () {
            global.speechSynthesis.getVoices();
        };
    }

    /**
     * Smooth Gemini-style progressive text reveal animator (requestAnimationFrame paced).
     */
    function animateMarkdownReveal(targetEl, fullMarkdown, renderFn, scrollContainer, onComplete) {
        var reduced = global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var text = String(fullMarkdown || '');
        if (!targetEl || reduced || text.length < 24) {
            if (targetEl) targetEl.innerHTML = renderFn(text);
            if (typeof onComplete === 'function') onComplete();
            return { cancel: function () {} };
        }

        // Tokenize by words + whitespace so Markdown structure stays clean while streaming smoothly
        var tokens = text.match(/\S+\s*/g) || [text];
        var total = tokens.length;
        var idx = 0;
        var cancelled = false;
        var rafId = null;
        // Adaptive speed: finishes short replies in ~0.7s and long reports in ~2.2s
        var tokensPerFrame = Math.max(2, Math.ceil(total / 75));

        function step() {
            if (cancelled) return;
            idx = Math.min(total, idx + tokensPerFrame);
            var partial = tokens.slice(0, idx).join('');
            var cursorHtml = idx < total ? '<span class="ayev-stream-cursor" aria-hidden="true"></span>' : '';
            targetEl.innerHTML = renderFn(partial) + cursorHtml;
            if (scrollContainer) {
                var nearBottom = (scrollContainer.scrollHeight - scrollContainer.scrollTop - scrollContainer.clientHeight) < 160;
                if (nearBottom) scrollContainer.scrollTop = scrollContainer.scrollHeight;
            }
            if (idx < total) {
                rafId = global.requestAnimationFrame(step);
            } else {
                targetEl.innerHTML = renderFn(text);
                if (typeof onComplete === 'function') onComplete();
            }
        }

        rafId = global.requestAnimationFrame(step);
        return {
            cancel: function () {
                cancelled = true;
                if (rafId) global.cancelAnimationFrame(rafId);
                targetEl.innerHTML = renderFn(text);
            }
        };
    }

    global.AyevorynVoiceAgent = {
        getPersona: getPersona,
        setPersona: setPersona,
        isAutoReplyEnabled: isAutoReplyEnabled,
        setAutoReplyEnabled: setAutoReplyEnabled,
        speak: speak,
        stop: stop,
        pickBestHumanBrowserVoice: pickBestHumanBrowserVoice,
        previewVoice: previewVoice
    };

    global.AyevorynStreamAnimator = {
        animateMarkdownReveal: animateMarkdownReveal
    };
})(window);
