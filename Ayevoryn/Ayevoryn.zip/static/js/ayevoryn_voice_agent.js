/**
 * Ayevoryn Human Voice Agent, Wispr-Flow-Style Dictation Engine & Smooth Stream Animator (USMANIA TECHS PVT LTD)
 * - 8 Curated Human Voices (6 Female: Aria, Nova, Luna, Clara, Elena, Meera | 2 Male: Atlas, Arjun)
 * - Sentence-by-sentence pipelined low-latency audio streaming
 * - STRICT Voice-OFF Gate: Voice replies default to OFF and NEVER auto-speak when OFF
 * - Wispr-Flow-Style Voice Input: live WebAudio mic level visualizer + filler cleanup + auto-punctuation + smart pause commit
 * - Smooth Gemini-style token-by-token text reveal animation (window.AyevorynStreamAnimator)
 */
(function (global) {
    'use strict';

    var currentAudio = null;
    var activeSessionId = 0;
    var activeAbortControllers = [];

    var VALID_PERSONAS = {
        female_us:     { label: 'Aria (Female · Warm)',        lang: 'en-US', gender: 'female', rate: 1.03, pitch: 1.03, sample: 'Hi! I am Aria, your Aevoryn Pulse AI advisor. Ready to analyze financials, run forecasts, and monitor your workspace.' },
        female_bright: { label: 'Nova (Female · Bright)',      lang: 'en-US', gender: 'female', rate: 1.05, pitch: 1.08, sample: 'Hello! I am Nova. Ask me to forecast revenue, export real reports, or automate recurring workflows.' },
        female_soft:   { label: 'Luna (Female · Soft)',        lang: 'en-US', gender: 'female', rate: 1.00, pitch: 1.05, sample: 'Hi there! I am Luna. Tell me what you need across departments, inventory, or live analytics.' },
        female_uk:     { label: 'Clara (Female · British)',    lang: 'en-GB', gender: 'female', rate: 1.02, pitch: 1.02, sample: 'Hello! I am Clara, your executive AI assistant. Ready to prepare forecasts, reports, and strategic briefings.' },
        female_velvet: { label: 'Elena (Female · Calm)',       lang: 'en-US', gender: 'female', rate: 0.98, pitch: 1.00, sample: 'Welcome! I am Elena. I can walk you through cash flow, risks, and live operational metrics calmly and clearly.' },
        female_in:     { label: 'Meera (Female · India)',      lang: 'en-IN', gender: 'female', rate: 1.02, pitch: 1.04, sample: 'Namaste! I am Meera, your Aevoryn Pulse AI voice assistant. I can check live telemetry, UPI QR payments, and reports.' },
        male_us:       { label: 'Atlas (Male · Confident)',    lang: 'en-US', gender: 'male',   rate: 1.00, pitch: 0.94, sample: 'Hello! I am Atlas, your Aevoryn Pulse AI executive advisor. Tell me what you want to query, update, or automate.' },
        male_in:       { label: 'Arjun (Male · India)',        lang: 'en-IN', gender: 'male',   rate: 1.00, pitch: 0.94, sample: 'Hello! I am Arjun, your Aevoryn Pulse AI partner. Ask me to run live sweeps, export reports, or navigate anywhere.' }
    };

    var PERSONA_PATTERNS = {
        female_us:     [/google us english/i, /microsoft aria online/i, /samantha/i, /female|aria|zira/i],
        female_bright: [/microsoft jenny online/i, /microsoft ava online/i, /google uk english female/i, /victoria|karen|female/i],
        female_soft:   [/microsoft emma online/i, /microsoft michelle online/i, /samantha/i, /google us english/i, /female/i],
        female_uk:     [/google uk english female/i, /microsoft sonia online/i, /microsoft libby online/i, /en-gb/i],
        female_velvet: [/microsoft ana online/i, /microsoft aria online/i, /moira|tessa|female/i],
        female_in:     [/microsoft neerja online/i, /google.*india.*female/i, /heera|veena|neerja/i, /en-in/i],
        male_us:       [/google uk english male/i, /microsoft guy online/i, /microsoft andrew online/i, /daniel|alex|david|male/i],
        male_in:       [/microsoft prabhat online/i, /google.*india.*male/i, /ravi|prabhat|rishi/i, /en-in/i]
    };

    (function normalizeVoicePref() {
        try {
            var raw = localStorage.getItem('ayevoryn_voice_reply_enabled');
            if (raw === 'true') localStorage.setItem('ayevoryn_voice_reply_enabled', '1');
            else if (raw !== '1') localStorage.setItem('ayevoryn_voice_reply_enabled', '0');
            var savedP = localStorage.getItem('ayevoryn_voice_persona');
            if (!savedP || !VALID_PERSONAS[savedP]) {
                localStorage.setItem('ayevoryn_voice_persona', 'female_us');
            }
        } catch (e) {}
    })();

    function getPersona() {
        try {
            var p = localStorage.getItem('ayevoryn_voice_persona') || 'female_us';
            return VALID_PERSONAS[p] ? p : 'female_us';
        } catch (e) {
            return 'female_us';
        }
    }

    function setPersona(personaId) {
        if (!VALID_PERSONAS[personaId]) return;
        try { localStorage.setItem('ayevoryn_voice_persona', personaId); } catch (e) {}
        global.dispatchEvent(new CustomEvent('ayevoryn:voicechange', { detail: { persona: personaId } }));
    }

    function getPersonaMeta(personaId) {
        return VALID_PERSONAS[personaId || getPersona()] || VALID_PERSONAS.female_us;
    }

    function isAutoReplyEnabled() {
        try { return localStorage.getItem('ayevoryn_voice_reply_enabled') === '1'; } catch (e) { return false; }
    }

    function setAutoReplyEnabled(enabled) {
        try { localStorage.setItem('ayevoryn_voice_reply_enabled', enabled ? '1' : '0'); } catch (e) {}
        if (!enabled) stop();
        global.dispatchEvent(new CustomEvent('ayevoryn:voicechange', { detail: { enabled: !!enabled } }));
    }

    function stop() {
        activeSessionId += 1;
        while (activeAbortControllers.length) {
            var ctrl = activeAbortControllers.pop();
            try { ctrl.abort(); } catch (e) {}
        }
        if (currentAudio) {
            try { currentAudio.pause(); currentAudio.currentTime = 0; currentAudio.src = ''; } catch (e) {}
            currentAudio = null;
        }
        try { if (global.speechSynthesis) global.speechSynthesis.cancel(); } catch (e) {}
    }

    function cleanForSpeech(text) {
        return String(text || '')
            .replace(/!\[[^\]]*\]\([^)]+\)/g, ' ')
            .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
            .replace(/```[\s\S]*?```/g, ' ')
            .replace(/^\|?[\s:\-|]+\|?$/gm, ' ')
            .replace(/[#*`_~>|]/g, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    /**
     * Wispr-Flow-Style Dictation Polisher:
     * Strips spoken filler hesitations (um, uh, er), normalizes spacing, and capitalizes cleanly.
     */
    function polishDictationText(raw) {
        var s = String(raw || '').trim();
        if (!s) return '';
        s = s.replace(/\b(um+|uh+|er+|ah+|hmm+)\b[,\s]*/gi, ' ');
        s = s.replace(/\s+/g, ' ').trim();
        if (s.length > 0) {
            s = s.charAt(0).toUpperCase() + s.slice(1);
        }
        return s;
    }

    function splitIntoSpeechChunks(cleanText) {
        if (!cleanText) return [];
        var rawSentences = cleanText.match(/[^.!?]+[.!?]+|[^.!?]+$/g) || [cleanText];
        var chunks = [];
        var current = '';
        for (var i = 0; i < rawSentences.length; i++) {
            var s = rawSentences[i].trim();
            if (!s) continue;
            var limit = chunks.length === 0 ? 145 : 210;
            if (!current) {
                current = s.length > limit ? s.slice(0, limit).trim() : s;
            } else if ((current.length + 1 + s.length) <= limit) {
                current += ' ' + s;
            } else {
                chunks.push(current);
                current = s.length > 210 ? s.slice(0, 210).trim() : s;
            }
            if (chunks.length >= 4) break;
        }
        if (current && chunks.length < 4) chunks.push(current);
        return chunks;
    }

    function pickBestHumanBrowserVoice(personaId) {
        if (!global.speechSynthesis || typeof global.speechSynthesis.getVoices !== 'function') return null;
        var voices = global.speechSynthesis.getVoices() || [];
        if (!voices.length) return null;
        var patterns = PERSONA_PATTERNS[personaId] || PERSONA_PATTERNS.female_us;
        for (var i = 0; i < patterns.length; i++) {
            for (var j = 0; j < voices.length; j++) {
                var v = voices[j];
                var label = (v.name || '') + ' ' + (v.lang || '');
                if (patterns[i].test(label)) return v;
            }
        }
        return voices.find(function (v) { return /^en/i.test(v.lang || ''); }) || voices[0];
    }

    function speakChunkWithBrowserVoice(chunkText, personaId, sessionId) {
        return new Promise(function (resolve) {
            if (sessionId !== activeSessionId || !global.speechSynthesis) { resolve(); return; }
            try {
                global.speechSynthesis.cancel();
                var meta = getPersonaMeta(personaId);
                var utter = new SpeechSynthesisUtterance(chunkText);
                var voice = pickBestHumanBrowserVoice(personaId);
                if (voice) utter.voice = voice;
                utter.lang = meta.lang;
                utter.rate = meta.rate;
                utter.pitch = meta.pitch;
                utter.onend = function () { resolve(); };
                utter.onerror = function () { resolve(); };
                global.speechSynthesis.speak(utter);
            } catch (e) { resolve(); }
        });
    }

    function fetchChunkAudio(chunkText, personaId, sessionId) {
        var csrf = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
        var headers = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
        if (csrf) headers['X-CSRFToken'] = csrf;

        var ctrl = new AbortController();
        activeAbortControllers.push(ctrl);

        return fetch('/pulse-ai/api/voice/synthesize', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ text: chunkText, voice_id: personaId }),
            signal: ctrl.signal
        })
        .then(function (r) { return r.json(); })
        .catch(function () { return { success: false }; })
        .then(function (data) { return (sessionId === activeSessionId) ? data : null; });
    }

    function playAudioBase64(data, chunkText, personaId, sessionId) {
        return new Promise(function (resolve) {
            if (sessionId !== activeSessionId) { resolve(); return; }
            if (data && data.success && data.audio_base64) {
                var src = 'data:' + (data.mime_type || 'audio/mpeg') + ';base64,' + data.audio_base64;
                var audio = new Audio(src);
                currentAudio = audio;
                audio.onended = function () { if (currentAudio === audio) currentAudio = null; resolve(); };
                audio.onerror = function () { if (currentAudio === audio) currentAudio = null; speakChunkWithBrowserVoice(chunkText, personaId, sessionId).then(resolve); };
                audio.play().catch(function () { if (currentAudio === audio) currentAudio = null; speakChunkWithBrowserVoice(chunkText, personaId, sessionId).then(resolve); });
            } else {
                speakChunkWithBrowserVoice(chunkText, personaId, sessionId).then(resolve);
            }
        });
    }

    function speak(text, opts) {
        var options = (opts && typeof opts === 'object') ? opts : {};
        var personaId = (typeof opts === 'string' && VALID_PERSONAS[opts]) ? opts : (options.persona || getPersona());
        var isAuto = Boolean(options.auto) && !Boolean(options.force);
        if (isAuto && !isAutoReplyEnabled()) return Promise.resolve();

        var clean = cleanForSpeech(text);
        var chunks = splitIntoSpeechChunks(clean);
        if (!chunks.length) return Promise.resolve();

        stop();
        var sessionId = activeSessionId;
        if (typeof options.onStart === 'function') { try { options.onStart(getPersonaMeta(personaId)); } catch (e) {} }

        var nextFetchPromise = fetchChunkAudio(chunks[0], personaId, sessionId);
        var chain = Promise.resolve();
        chunks.forEach(function (chunkText, idx) {
            chain = chain.then(function () {
                if (sessionId !== activeSessionId) return;
                var currentFetch = nextFetchPromise;
                nextFetchPromise = (idx + 1 < chunks.length) ? fetchChunkAudio(chunks[idx + 1], personaId, sessionId) : null;
                return currentFetch.then(function (audioData) {
                    if (sessionId !== activeSessionId) return;
                    return playAudioBase64(audioData, chunkText, personaId, sessionId);
                });
            });
        });

        return chain.finally(function () {
            if (typeof options.onEnd === 'function') { try { options.onEnd(); } catch (e) {} }
        });
    }

    function previewVoice(overridePersona) {
        var pid = (overridePersona && VALID_PERSONAS[overridePersona]) ? overridePersona : getPersona();
        var meta = getPersonaMeta(pid);
        return speak(meta.sample, { persona: pid, force: true });
    }

    /**
     * Wispr-Flow-Style Voice Input Engine:
     * - Real-time WebAudio mic level visualizer driving live HUD bars
     * - Continuous interim transcript streaming with automatic filler cleanup & capitalization
     * - Smart 1.7s natural-pause auto-commit (never cuts off mid-sentence!)
     */
    function startSmartVoiceInput(callbacks) {
        var SR = global.SpeechRecognition || global.webkitSpeechRecognition;
        if (!SR) {
            if (callbacks && typeof callbacks.onUnsupported === 'function') callbacks.onUnsupported();
            return null;
        }
        stop();
        var rec = new SR();
        var meta = getPersonaMeta();
        rec.lang = meta.lang || 'en-US';
        rec.continuous = true;
        rec.interimResults = true;
        rec.maxAlternatives = 1;

        var finalTranscript = '';
        var interimTranscript = '';
        var silenceTimer = null;
        var committed = false;
        var micStream = null;
        var audioCtx = null;
        var meterRaf = null;

        function stopMicMeter() {
            if (meterRaf) { global.cancelAnimationFrame(meterRaf); meterRaf = null; }
            if (micStream) {
                try { micStream.getTracks().forEach(function (t) { t.stop(); }); } catch (e) {}
                micStream = null;
            }
            if (audioCtx) {
                try { audioCtx.close(); } catch (e) {}
                audioCtx = null;
            }
        }

        // Start optional WebAudio live mic level visualizer (Wispr Flow style reactive waveform)
        if (navigator.mediaDevices && typeof navigator.mediaDevices.getUserMedia === 'function') {
            navigator.mediaDevices.getUserMedia({ audio: true }).then(function (stream) {
                if (committed) {
                    stream.getTracks().forEach(function (t) { t.stop(); });
                    return;
                }
                micStream = stream;
                var AC = global.AudioContext || global.webkitAudioContext;
                if (!AC) return;
                audioCtx = new AC();
                var src = audioCtx.createMediaStreamSource(stream);
                var analyser = audioCtx.createAnalyser();
                analyser.fftSize = 64;
                src.connect(analyser);
                var freqData = new Uint8Array(analyser.frequencyBinCount);
                function tickMeter() {
                    if (committed) return;
                    analyser.getByteFrequencyData(freqData);
                    var bars = document.querySelectorAll('.ayev-voice-bars span, .pulse-waveform span');
                    for (var i = 0; i < bars.length; i++) {
                        var v = freqData[(i * 2) % freqData.length] || 12;
                        var h = Math.max(5, Math.min(22, Math.round(5 + (v / 255) * 18)));
                        bars[i].style.height = h + 'px';
                    }
                    meterRaf = global.requestAnimationFrame(tickMeter);
                }
                meterRaf = global.requestAnimationFrame(tickMeter);
            }).catch(function () {});
        }

        function commitNow() {
            if (committed) return;
            committed = true;
            stopMicMeter();
            if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
            try { rec.stop(); } catch (e) {}
            var full = polishDictationText(finalTranscript + ' ' + interimTranscript);
            if (callbacks && typeof callbacks.onFinal === 'function') callbacks.onFinal(full);
        }

        rec.onstart = function () {
            if (callbacks && typeof callbacks.onStart === 'function') callbacks.onStart(rec.lang);
        };
        rec.onresult = function (event) {
            interimTranscript = '';
            for (var i = event.resultIndex; i < event.results.length; i++) {
                var chunk = event.results[i][0].transcript || '';
                if (event.results[i].isFinal) {
                    finalTranscript += (finalTranscript ? ' ' : '') + chunk.trim();
                } else {
                    interimTranscript += chunk;
                }
            }
            var liveText = polishDictationText(finalTranscript + ' ' + interimTranscript);
            if (callbacks && typeof callbacks.onInterim === 'function') callbacks.onInterim(liveText);
            if (silenceTimer) clearTimeout(silenceTimer);
            if (liveText) {
                silenceTimer = setTimeout(commitNow, 1700);
            }
        };
        rec.onerror = function (ev) {
            stopMicMeter();
            if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
            if (callbacks && typeof callbacks.onError === 'function') callbacks.onError(ev && ev.error ? ev.error : 'mic_error');
        };
        rec.onend = function () {
            stopMicMeter();
            if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
            if (!committed) {
                var full = polishDictationText(finalTranscript + ' ' + interimTranscript);
                committed = true;
                if (full && callbacks && typeof callbacks.onFinal === 'function') callbacks.onFinal(full);
            }
            if (callbacks && typeof callbacks.onEnd === 'function') callbacks.onEnd();
        };

        try {
            rec.start();
        } catch (e) {
            stopMicMeter();
            if (callbacks && typeof callbacks.onError === 'function') callbacks.onError('start_failed');
            return null;
        }
        return {
            stopAndCommit: commitNow,
            abort: function () {
                committed = true;
                stopMicMeter();
                if (silenceTimer) { clearTimeout(silenceTimer); silenceTimer = null; }
                try { rec.abort(); } catch (e) {}
            }
        };
    }

    if (global.speechSynthesis && typeof global.speechSynthesis.onvoiceschanged !== 'undefined') {
        global.speechSynthesis.onvoiceschanged = function () { global.speechSynthesis.getVoices(); };
    }

    function animateMarkdownReveal(targetEl, fullMarkdown, renderFn, scrollContainer, onComplete) {
        var reduced = global.matchMedia && global.matchMedia('(prefers-reduced-motion: reduce)').matches;
        var text = String(fullMarkdown || '');
        if (!targetEl || reduced || text.length < 24) {
            if (targetEl) targetEl.innerHTML = renderFn(text);
            if (typeof onComplete === 'function') onComplete();
            return { cancel: function () {} };
        }
        var tokens = text.match(/\S+\s*/g) || [text];
        var total = tokens.length;
        var idx = 0;
        var cancelled = false;
        var rafId = null;
        var tokensPerFrame = Math.max(2, Math.ceil(total / 75));

        function step() {
            if (cancelled) return;
            idx = Math.min(total, idx + tokensPerFrame);
            var partial = tokens.slice(0, idx).join('');
            var cursorHtml = idx < total ? '<span class="ayev-stream-cursor" aria-hidden="true"></span>' : '';
            targetEl.innerHTML = renderFn(partial) + cursorHtml;
            if (scrollContainer) {
                var nearBottom = (scrollContainer.scrollHeight - scrollContainer.scrollTop - scrollContainer.clientHeight) < 160;
                if (nearBottom) scrollContainer.scrollTop = scrollContainer.scrollHeight;
            }
            if (idx < total) {
                rafId = global.requestAnimationFrame(step);
            } else {
                targetEl.innerHTML = renderFn(text);
                if (typeof onComplete === 'function') onComplete();
            }
        }
        rafId = global.requestAnimationFrame(step);
        return {
            cancel: function () {
                cancelled = true;
                if (rafId) global.cancelAnimationFrame(rafId);
                targetEl.innerHTML = renderFn(text);
            }
        };
    }

    global.AyevorynVoiceAgent = {
        VALID_PERSONAS: VALID_PERSONAS,
        getPersona: getPersona,
        setPersona: setPersona,
        getPersonaMeta: getPersonaMeta,
        isAutoReplyEnabled: isAutoReplyEnabled,
        setAutoReplyEnabled: setAutoReplyEnabled,
        speak: speak,
        stop: stop,
        pickBestHumanBrowserVoice: pickBestHumanBrowserVoice,
        previewVoice: previewVoice,
        startSmartVoiceInput: startSmartVoiceInput,
        polishDictationText: polishDictationText
    };

    global.AyevorynStreamAnimator = {
        animateMarkdownReveal: animateMarkdownReveal
    };
})(window);
