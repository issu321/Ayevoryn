/* ==========================================================================
   AYEVORYN BESPOKE DUOTONE SVG MICRO-ICON REGISTRY & UPGRADER (V1.0)
   Replaces generic static FontAwesome icons across the ENTIRE web app
   (Company Dashboard Left Sidebar, Superadmin Sidebar, Public Website,
   Login/Register, Cards & Buttons) with crisp animated 2-layer duotone SVGs.
   ========================================================================== */
(function () {
    'use strict';

    const ICONS = {
        gauge: {
            cls: 'ayv-ico-gauge',
            svg: '<path class="ayv-tint" d="M4 16a8 8 0 1 1 16 0H4z"/><path class="ayv-stroke" d="M3.5 16.5a8.5 8.5 0 1 1 17 0"/><path class="ayv-stroke ayv-needle" d="M12 14l4.2-4.2"/><circle class="ayv-stroke" cx="12" cy="14" r="1.5"/>'
        },
        robot: {
            cls: 'ayv-ico-nodes',
            svg: '<rect class="ayv-tint" x="4" y="7" width="16" height="12" rx="3.5"/><rect class="ayv-stroke" x="4" y="7" width="16" height="12" rx="3.5"/><path class="ayv-stroke" d="M12 3v4M9.5 12.5h.01M14.5 12.5h.01M9.5 16h5"/>'
        },
        wave: {
            cls: 'ayv-ico-wave',
            svg: '<rect class="ayv-tint" x="3" y="4" width="18" height="16" rx="4"/><path class="ayv-stroke ayv-pulse-path" d="M3 12h4l2.2-5.5 3.6 11L15 12h6"/>'
        },
        nodes: {
            cls: 'ayv-ico-nodes',
            svg: '<rect class="ayv-tint" x="3" y="3" width="6" height="6" rx="1.8"/><rect class="ayv-tint" x="15" y="15" width="6" height="6" rx="1.8"/><rect class="ayv-stroke" x="3" y="3" width="6" height="6" rx="1.8"/><rect class="ayv-stroke ayv-node-hi" x="15" y="3" width="6" height="6" rx="1.8"/><rect class="ayv-stroke" x="15" y="15" width="6" height="6" rx="1.8"/><path class="ayv-stroke" d="M9 6h6M6 9v6a3 3 0 0 0 3 3h6"/>'
        },
        cubes: {
            cls: 'ayv-ico-cubes',
            svg: '<path class="ayv-tint" d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path class="ayv-stroke" d="M12 3l8 4.5v9L12 21l-8-4.5v-9L12 3z"/><path class="ayv-stroke" d="M12 12l8-4.5M12 12v9M12 12L4 7.5"/>'
        },
        bank: {
            cls: 'ayv-ico-bank',
            svg: '<path class="ayv-tint" d="M3 9l9-5 9 5H3z"/><path class="ayv-stroke" d="M3 9l9-5 9 5H3zM5 10v7M9.5 10v7M14.5 10v7M19 10v7M3 20h18"/>'
        },
        sitemap: {
            cls: 'ayv-ico-nodes',
            svg: '<rect class="ayv-tint" x="9" y="3" width="6" height="5" rx="1.5"/><rect class="ayv-stroke" x="9" y="3" width="6" height="5" rx="1.5"/><rect class="ayv-stroke ayv-node-hi" x="3" y="15" width="5" height="5" rx="1.3"/><rect class="ayv-stroke ayv-node-hi" x="9.5" y="15" width="5" height="5" rx="1.3"/><rect class="ayv-stroke ayv-node-hi" x="16" y="15" width="5" height="5" rx="1.3"/><path class="ayv-stroke" d="M12 8v3.5M5.5 15v-2a1.5 1.5 0 0 1 1.5-1.5h10a1.5 1.5 0 0 1 1.5 1.5v2M12 11.5V15"/>'
        },
        clock: {
            cls: 'ayv-ico-clock',
            svg: '<circle class="ayv-tint" cx="12" cy="12" r="8"/><path class="ayv-stroke" d="M3.5 12a8.5 8.5 0 1 0 2.5-6.1L3.5 8"/><path class="ayv-stroke" d="M3.5 4.5V8H7M12 7.5V12l3 1.8"/>'
        },
        flask: {
            cls: 'ayv-ico-flask',
            svg: '<path class="ayv-tint" d="M7.5 14h9l2 5a1.5 1.5 0 0 1-1.4 2H6.9a1.5 1.5 0 0 1-1.4-2l2-5z"/><path class="ayv-stroke" d="M9 3h6M10 3v5.5L5.4 18.8A1.8 1.8 0 0 0 7 21h10a1.8 1.8 0 0 0 1.6-2.2L14 8.5V3"/>'
        },
        chartLine: {
            cls: 'ayv-ico-chart-line',
            svg: '<path class="ayv-tint" d="M4 19V5h16v14H4z" opacity="0.5"/><path class="ayv-stroke" d="M3 19h18M4 5v14"/><path class="ayv-stroke ayv-trend" d="M6.5 15l4-4 3 2.5 5-6"/>'
        },
        chartPie: {
            cls: 'ayv-ico-chart-pie',
            svg: '<path class="ayv-tint" d="M11 4a8 8 0 1 0 8 8h-8V4z"/><path class="ayv-stroke" d="M11 4a8 8 0 1 0 8 8h-8V4z"/><path class="ayv-stroke ayv-wedge" d="M14 3.5a7.5 7.5 0 0 1 6.5 6.5H14V3.5z"/>'
        },
        shield: {
            cls: 'ayv-ico-shield',
            svg: '<path class="ayv-tint" d="M12 3l7.5 3v5.8c0 4.6-3.1 8.1-7.5 9.2-4.4-1.1-7.5-4.6-7.5-9.2V6L12 3z"/><path class="ayv-stroke" d="M12 3l7.5 3v5.8c0 4.6-3.1 8.1-7.5 9.2-4.4-1.1-7.5-4.6-7.5-9.2V6L12 3z"/><path class="ayv-stroke" d="M9 12l2 2 4-4"/>'
        },
        database: {
            cls: 'ayv-ico-database',
            svg: '<ellipse class="ayv-tint ayv-db-top" cx="12" cy="6" rx="7.5" ry="3"/><ellipse class="ayv-stroke ayv-db-top" cx="12" cy="6" rx="7.5" ry="3"/><path class="ayv-stroke" d="M4.5 6v6c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3V6"/><path class="ayv-stroke ayv-db-bot" d="M4.5 12v6c0 1.66 3.36 3 7.5 3s7.5-1.34 7.5-3v-6"/>'
        },
        building: {
            cls: 'ayv-ico-bank',
            svg: '<rect class="ayv-tint" x="5" y="3" width="14" height="18" rx="2"/><rect class="ayv-stroke" x="5" y="3" width="14" height="18" rx="2"/><path class="ayv-stroke" d="M9 7h1.5M13.5 7H15M9 11h1.5M13.5 11H15M9 15h1.5M13.5 15H15M10 21v-3h4v3"/>'
        },
        users: {
            cls: 'ayv-ico-nodes',
            svg: '<circle class="ayv-tint" cx="9" cy="8" r="3.2"/><circle class="ayv-stroke" cx="9" cy="8" r="3.2"/><path class="ayv-stroke" d="M3.5 19a5.5 5.5 0 0 1 11 0"/><circle class="ayv-stroke" cx="16.5" cy="9" r="2.3"/><path class="ayv-stroke" d="M16.5 14a4 4 0 0 1 4 4.5"/>'
        },
        user: {
            cls: 'ayv-ico-nodes',
            svg: '<circle class="ayv-tint" cx="12" cy="8" r="3.8"/><circle class="ayv-stroke" cx="12" cy="8" r="3.8"/><path class="ayv-stroke" d="M5 20a7 7 0 0 1 14 0"/>'
        },
        gear: {
            cls: 'ayv-ico-gear',
            svg: '<circle class="ayv-tint" cx="12" cy="12" r="3.2"/><circle class="ayv-stroke" cx="12" cy="12" r="3.2"/><path class="ayv-stroke" d="M12 2.8v2.1M12 19.1v2.1M4.9 4.9l1.5 1.5M17.6 17.6l1.5 1.5M2.8 12h2.1M19.1 12h2.1M4.9 19.1l1.5-1.5M17.6 6.4l1.5-1.5"/>'
        },
        sliders: {
            cls: 'ayv-ico-gear',
            svg: '<path class="ayv-stroke" d="M4 7h16M4 12h16M4 17h16"/><circle class="ayv-tint ayv-stroke" cx="9" cy="7" r="2"/><circle class="ayv-tint ayv-stroke" cx="15" cy="12" r="2"/><circle class="ayv-tint ayv-stroke" cx="10" cy="17" r="2"/>'
        },
        lock: {
            cls: 'ayv-ico-shield',
            svg: '<rect class="ayv-tint" x="5" y="10.5" width="14" height="10" rx="2.5"/><rect class="ayv-stroke" x="5" y="10.5" width="14" height="10" rx="2.5"/><path class="ayv-stroke" d="M8 10.5V7.5a4 4 0 0 1 8 0v3M12 14.5v2.2"/>'
        },
        bell: {
            cls: 'ayv-ico-bell',
            svg: '<path class="ayv-tint" d="M6 10a6 6 0 0 1 12 0c0 4 1.5 5.5 2 6.5H4c.5-1 2-2.5 2-6.5z"/><path class="ayv-stroke" d="M6 10a6 6 0 0 1 12 0c0 4 1.5 5.5 2 6.5H4c.5-1 2-2.5 2-6.5zM9.8 19.5a2.4 2.4 0 0 0 4.4 0"/>'
        },
        download: {
            cls: 'ayv-ico-download',
            svg: '<path class="ayv-tint" d="M5 16h14v4H5z"/><path class="ayv-stroke ayv-dl-arrow" d="M12 4v10M8.5 10.5L12 14l3.5-3.5"/><path class="ayv-stroke" d="M4.5 16.5v2a1.5 1.5 0 0 0 1.5 1.5h12a1.5 1.5 0 0 0 1.5-1.5v-2"/>'
        },
        trash: {
            cls: 'ayv-ico-trash',
            svg: '<path class="ayv-tint" d="M6.5 7h11l-.9 12.5a1.5 1.5 0 0 1-1.5 1.5H8.9a1.5 1.5 0 0 1-1.5-1.5L6.5 7z"/><path class="ayv-stroke ayv-trash-lid" d="M4.5 6.5h15M9.5 6.5V4.5a1 1 0 0 1 1-1h3a1 1 0 0 1 1 1v2"/><path class="ayv-stroke" d="M6.5 7l.9 12.2a1.5 1.5 0 0 0 1.5 1.3h6.2a1.5 1.5 0 0 0 1.5-1.3L17.5 7M10 11v5.5M14 11v5.5"/>'
        },
        copy: {
            cls: 'ayv-ico-copy',
            svg: '<rect class="ayv-tint" x="9" y="9" width="11" height="11" rx="2"/><rect class="ayv-stroke" x="9" y="9" width="11" height="11" rx="2"/><path class="ayv-stroke" d="M6 15H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v1"/>'
        },
        check: {
            cls: 'ayv-ico-shield',
            svg: '<path class="ayv-stroke" d="M5 12.5l4.5 4.5L19 7.5"/>'
        },
        checkCircle: {
            cls: 'ayv-ico-shield',
            svg: '<circle class="ayv-tint" cx="12" cy="12" r="9"/><circle class="ayv-stroke" cx="12" cy="12" r="9"/><path class="ayv-stroke" d="M8.5 12.2l2.3 2.3 4.8-4.8"/>'
        },
        sun: {
            cls: 'ayv-ico-sun',
            svg: '<circle class="ayv-tint" cx="12" cy="12" r="4"/><circle class="ayv-stroke" cx="12" cy="12" r="4"/><path class="ayv-stroke" d="M12 2.5v2M12 19.5v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2.5 12h2M19.5 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>'
        },
        moon: {
            cls: 'ayv-ico-moon',
            svg: '<path class="ayv-tint" d="M19.5 14.5A7.5 7.5 0 0 1 9.5 4.5a7.5 7.5 0 1 0 10 10z"/><path class="ayv-stroke" d="M19.5 14.5A7.5 7.5 0 0 1 9.5 4.5a7.5 7.5 0 1 0 10 10z"/>'
        },
        arrowRight: {
            cls: 'ayv-ico-arrow-right',
            svg: '<path class="ayv-stroke" d="M5 12h14M13.5 6.5L19 12l-5.5 5.5"/>'
        },
        arrowLeft: {
            cls: 'ayv-ico-arrow-left',
            svg: '<path class="ayv-stroke" d="M19 12H5M10.5 6.5L5 12l5.5 5.5"/>'
        },
        plus: {
            cls: 'ayv-ico-plus',
            svg: '<path class="ayv-stroke" d="M12 5v14M5 12h14"/>'
        },
        pen: {
            cls: 'ayv-ico-nodes',
            svg: '<path class="ayv-tint" d="M15.5 4.5l4 4L9 19H5v-4L15.5 4.5z"/><path class="ayv-stroke" d="M15.5 4.5l4 4L9 19H5v-4L15.5 4.5z"/>'
        },
        search: {
            cls: 'ayv-ico-shield',
            svg: '<circle class="ayv-tint" cx="10.5" cy="10.5" r="6.5"/><circle class="ayv-stroke" cx="10.5" cy="10.5" r="6.5"/><path class="ayv-stroke" d="M15.5 15.5L20 20"/>'
        },
        rocket: {
            cls: 'ayv-ico-rocket',
            svg: '<path class="ayv-tint" d="M14.5 4.5c2.5-.5 5 .5 5 .5s1 2.5.5 5c-.7 3.5-3.5 6.3-6.8 7.5l-4.7-4.7C9.7 9.5 12.5 5.2 14.5 4.5z"/><path class="ayv-stroke" d="M14.5 4.5c2.5-.5 5 .5 5 .5s1 2.5.5 5c-.7 3.5-3.5 6.3-6.8 7.5l-4.7-4.7C9.7 9.5 12.5 5.2 14.5 4.5zM8.5 12.8L5 13.5l-1.5 3.5 3.5-1.5.7-3.5M14 10h.01"/>'
        },
        mic: {
            cls: 'ayv-ico-wave',
            svg: '<rect class="ayv-tint" x="9" y="3.5" width="6" height="10" rx="3"/><rect class="ayv-stroke" x="9" y="3.5" width="6" height="10" rx="3"/><path class="ayv-stroke" d="M5.5 11.5a6.5 6.5 0 0 0 13 0M12 18v3M9 21h6"/>'
        },
        send: {
            cls: 'ayv-ico-arrow-right',
            svg: '<path class="ayv-tint" d="M20.5 3.5L10 14l-6.5-3L20.5 3.5z"/><path class="ayv-stroke" d="M20.5 3.5L13.5 20.5l-3.5-6.5-6.5-3 17-7.5zM10 14l10.5-10.5"/>'
        },
        crown: {
            cls: 'ayv-ico-rocket',
            svg: '<path class="ayv-tint" d="M4 17l-1-9 5 4 4-6 4 6 5-4-1 9H4z"/><path class="ayv-stroke" d="M4 17l-1-9 5 4 4-6 4 6 5-4-1 9H4zM4 20h16"/>'
        },
        globe: {
            cls: 'ayv-ico-gear',
            svg: '<circle class="ayv-tint" cx="12" cy="12" r="8.5"/><circle class="ayv-stroke" cx="12" cy="12" r="8.5"/><path class="ayv-stroke" d="M3.8 12h16.4M12 3.5a12.5 12.5 0 0 1 0 17M12 3.5a12.5 12.5 0 0 0 0 17"/>'
        },
        layers: {
            cls: 'ayv-ico-database',
            svg: '<path class="ayv-tint ayv-db-top" d="M12 4l8 4.2-8 4.2-8-4.2L12 4z"/><path class="ayv-stroke ayv-db-top" d="M12 4l8 4.2-8 4.2-8-4.2L12 4z"/><path class="ayv-stroke" d="M4 12.5l8 4.2 8-4.2"/><path class="ayv-stroke ayv-db-bot" d="M4 16.5l8 4.2 8-4.2"/>'
        },
        file: {
            cls: 'ayv-ico-folder',
            svg: '<path class="ayv-tint" d="M6 3.5h8l4 4v13H6v-17z"/><path class="ayv-stroke" d="M6 3.5h8l4 4v13a1 1 0 0 1-1 1H7a1 1 0 0 1-1-1v-17z"/><path class="ayv-stroke" d="M14 3.5v4h4M9 12h6M9 15.5h4.5"/>'
        },
        folder: {
            cls: 'ayv-ico-folder',
            svg: '<path class="ayv-tint ayv-folder-flap" d="M3.5 7.5a2 2 0 0 1 2-2h4.2l2 2H18.5a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-10z"/><path class="ayv-stroke" d="M3.5 7.5a2 2 0 0 1 2-2h4.2l2 2H18.5a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-13a2 2 0 0 1-2-2v-10z"/>'
        },
        bolt: {
            cls: 'ayv-ico-rocket',
            svg: '<path class="ayv-tint" d="M13 3L5.5 13.5H12L11 21l7.5-10.5H12L13 3z"/><path class="ayv-stroke" d="M13 3L5.5 13.5H12L11 21l7.5-10.5H12L13 3z"/>'
        },
        coins: {
            cls: 'ayv-ico-database',
            svg: '<ellipse class="ayv-tint ayv-db-top" cx="10" cy="7.5" rx="6" ry="2.5"/><ellipse class="ayv-stroke ayv-db-top" cx="10" cy="7.5" rx="6" ry="2.5"/><path class="ayv-stroke" d="M4 7.5v5c0 1.4 2.7 2.5 6 2.5s6-1.1 6-2.5v-5"/><path class="ayv-stroke ayv-db-bot" d="M14 14.5c3.3 0 6-1.1 6-2.5v4.5c0 1.4-2.7 2.5-6 2.5s-6-1.1-6-2.5"/>'
        },
        signOut: {
            cls: 'ayv-ico-arrow-right',
            svg: '<path class="ayv-stroke" d="M10 4.5H6a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h4M15 8l4 4-4 4M19 12H9.5"/>'
        },
        alert: {
            cls: 'ayv-ico-shield',
            svg: '<path class="ayv-tint" d="M12 3.5L20.5 19H3.5L12 3.5z"/><path class="ayv-stroke" d="M12 3.5L20.5 19H3.5L12 3.5zM12 9.5v4M12 16.2h.01"/>'
        },
        home: {
            cls: 'ayv-ico-bank',
            svg: '<path class="ayv-tint" d="M4 11l8-7 8 7v8.5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V11z"/><path class="ayv-stroke" d="M4 11l8-7 8 7v8.5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V11zM9.5 20.5v-6h5v6"/>'
        },
        eye: {
            cls: 'ayv-ico-shield',
            svg: '<path class="ayv-tint" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"/><path class="ayv-stroke" d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"/><circle class="ayv-stroke" cx="12" cy="12" r="2.5"/>'
        },
        receipt: {
            cls: 'ayv-ico-folder',
            svg: '<path class="ayv-tint" d="M6 3.5h12v17l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5-2 1.5v-17z"/><path class="ayv-stroke" d="M6 3.5h12v17l-2-1.5-2 1.5-2-1.5-2 1.5-2-1.5-2 1.5v-17zM9 8.5h6M9 12h6M9 15.5h3.5"/>'
        },
        sparkles: {
            cls: 'ayv-ico-rocket',
            svg: '<path class="ayv-tint" d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3z"/><path class="ayv-stroke" d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3zM18.5 15.5l.8 2.2 2.2.8-2.2.8-.8 2.2-.8-2.2-2.2-.8 2.2-.8.8-2.2z"/>'
        },
        menu: {
            cls: 'ayv-ico-nodes',
            svg: '<path class="ayv-stroke" d="M4 7h16M4 12h12M4 17h16"/>'
        }
    };

    const FA_MAP = {
        'fa-gauge-high': 'gauge',
        'fa-tachometer-alt': 'gauge',
        'fa-robot': 'robot',
        'fa-wave-square': 'wave',
        'fa-waveform-lines': 'wave',
        'fa-diagram-project': 'nodes',
        'fa-project-diagram': 'nodes',
        'fa-network-wired': 'nodes',
        'fa-circle-nodes': 'nodes',
        'fa-cubes': 'cubes',
        'fa-boxes-stacked': 'cubes',
        'fa-building-columns': 'bank',
        'fa-landmark': 'bank',
        'fa-sitemap': 'sitemap',
        'fa-clock-rotate-left': 'clock',
        'fa-flask': 'flask',
        'fa-chart-line': 'chartLine',
        'fa-chart-area': 'chartLine',
        'fa-chart-pie': 'chartPie',
        'fa-shield-halved': 'shield',
        'fa-shield-alt': 'shield',
        'fa-user-shield': 'shield',
        'fa-database': 'database',
        'fa-server': 'database',
        'fa-building': 'building',
        'fa-users': 'users',
        'fa-users-gear': 'users',
        'fa-user-tie': 'user',
        'fa-user': 'user',
        'fa-cog': 'gear',
        'fa-gear': 'gear',
        'fa-sliders': 'sliders',
        'fa-sliders-h': 'sliders',
        'fa-lock': 'lock',
        'fa-bell': 'bell',
        'fa-download': 'download',
        'fa-file-arrow-down': 'download',
        'fa-file-csv': 'download',
        'fa-trash': 'trash',
        'fa-trash-alt': 'trash',
        'fa-trash-can': 'trash',
        'fa-copy': 'copy',
        'fa-check': 'check',
        'fa-check-circle': 'checkCircle',
        'fa-circle-check': 'checkCircle',
        'fa-sun': 'sun',
        'fa-moon': 'moon',
        'fa-arrow-right': 'arrowRight',
        'fa-arrow-left': 'arrowLeft',
        'fa-plus': 'plus',
        'fa-pen': 'pen',
        'fa-pen-to-square': 'pen',
        'fa-magnifying-glass': 'search',
        'fa-search': 'search',
        'fa-rocket': 'rocket',
        'fa-microphone': 'mic',
        'fa-microphone-lines': 'mic',
        'fa-paper-plane': 'send',
        'fa-crown': 'crown',
        'fa-globe': 'globe',
        'fa-satellite-dish': 'globe',
        'fa-layer-group': 'layers',
        'fa-microchip': 'layers',
        'fa-file-alt': 'file',
        'fa-file-lines': 'file',
        'fa-folder-open': 'folder',
        'fa-bolt': 'bolt',
        'fa-coins': 'coins',
        'fa-sign-out-alt': 'signOut',
        'fa-right-to-bracket': 'signOut',
        'fa-power-off': 'signOut',
        'fa-triangle-exclamation': 'alert',
        'fa-circle-exclamation': 'alert',
        'fa-home': 'home',
        'fa-eye': 'eye',
        'fa-receipt': 'receipt',
        'fa-wand-magic-sparkles': 'sparkles',
        'fa-bars': 'menu',
        'fa-bars-staggered': 'menu'
    };

    function upgradeIconEl(iEl) {
        if (!iEl || iEl.tagName !== 'I') return;
        // Skip dynamic JS-mutated ID icons, active spinners, and tiny status dots
        if (iEl.id || iEl.classList.contains('fa-spin') || iEl.classList.contains('fa-spinner') || iEl.classList.contains('fa-circle')) {
            return;
        }
        if (iEl.dataset.ayvUpgraded === '1') return;

        let matchKey = null;
        for (let idx = 0; idx < iEl.classList.length; idx++) {
            const c = iEl.classList[idx];
            if (FA_MAP[c]) {
                matchKey = FA_MAP[c];
                break;
            }
        }
        if (!matchKey || !ICONS[matchKey]) return;

        const spec = ICONS[matchKey];
        const span = document.createElement('span');
        const preserved = [];
        iEl.classList.forEach(function (c) {
            if (c !== 'fas' && c !== 'far' && c !== 'fab' && c !== 'fa' && c.indexOf('fa-') !== 0) {
                preserved.push(c);
            }
        });
        span.className = 'ayv-svg-ico ' + spec.cls + (preserved.length ? ' ' + preserved.join(' ') : '');
        span.setAttribute('aria-hidden', 'true');
        span.dataset.ayvUpgraded = '1';
        if (iEl.getAttribute('style')) span.setAttribute('style', iEl.getAttribute('style'));
        if (iEl.getAttribute('title')) span.setAttribute('title', iEl.getAttribute('title'));
        span.innerHTML = '<svg viewBox="0 0 24 24" focusable="false">' + spec.svg + '</svg>';
        iEl.parentNode.replaceChild(span, iEl);
    }

    function upgradeSubtree(root) {
        if (!root || !root.querySelectorAll) return;
        root.querySelectorAll('i.fas, i.far, i.fa-solid, i.fa-regular').forEach(upgradeIconEl);
    }

    window.ayvUpgradeSvgIcons = upgradeSubtree;

    document.addEventListener('DOMContentLoaded', function () {
        upgradeSubtree(document.body);
        if (typeof MutationObserver !== 'undefined') {
            const obs = new MutationObserver(function (mutations) {
                for (let m = 0; m < mutations.length; m++) {
                    const added = mutations[m].addedNodes;
                    for (let j = 0; j < added.length; j++) {
                        const node = added[j];
                        if (node.nodeType === 1) {
                            if (node.tagName === 'I') upgradeIconEl(node);
                            else if (node.querySelectorAll) upgradeSubtree(node);
                        }
                    }
                }
            });
            obs.observe(document.body, { childList: true, subtree: true });
        }
    });
})();
