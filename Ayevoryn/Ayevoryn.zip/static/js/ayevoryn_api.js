/**
 * Ayevoryn Centralized Async API Client (USMANIA TECHS PVT LTD)
 * Standardizes CSRF header injection, timeouts, JSON error extraction,
 * 401 session-expiration handling, and non-blocking toast feedback across all modules.
 */
(function (global) {
    function getCsrfToken() {
        const meta = document.querySelector('meta[name="csrf-token"]');
        return meta ? (meta.getAttribute('content') || '') : '';
    }

    function ensureToastHost() {
        let host = document.getElementById('ayevorynToastHost');
        if (!host) {
            host = document.createElement('div');
            host.id = 'ayevorynToastHost';
            host.setAttribute('aria-live', 'polite');
            host.style.cssText = 'position:fixed;top:20px;right:20px;z-index:100000;display:flex;flex-direction:column;gap:8px;max-width:380px;';
            document.body.appendChild(host);
        }
        return host;
    }

    function toast(message, type) {
        const host = ensureToastHost();
        const kind = type || 'info';
        const colors = {
            success: { bg: '#065F46', border: '#10B981', icon: 'fa-check-circle' },
            error: { bg: '#7F1D1D', border: '#EF4444', icon: 'fa-exclamation-circle' },
            warning: { bg: '#78350F', border: '#F59E0B', icon: 'fa-exclamation-triangle' },
            info: { bg: '#1E293B', border: '#3B82F6', icon: 'fa-info-circle' }
        };
        const c = colors[kind] || colors.info;
        const el = document.createElement('div');
        el.style.cssText = `background:${c.bg};color:#F8FAFC;border:1px solid ${c.border};border-radius:10px;padding:11px 14px;font-size:0.84rem;font-weight:600;box-shadow:0 10px 28px rgba(0,0,0,0.32);display:flex;align-items:center;gap:9px;opacity:0;transform:translateY(-6px);transition:all 0.2s ease;`;
        el.innerHTML = `<i class="fas ${c.icon}"></i><span>${String(message || '').replace(/</g, '&lt;')}</span>`;
        host.appendChild(el);
        requestAnimationFrame(() => { el.style.opacity = '1'; el.style.transform = 'translateY(0)'; });
        setTimeout(() => {
            el.style.opacity = '0';
            setTimeout(() => el.remove(), 220);
        }, 4200);
    }

    async function request(url, options) {
        const opts = Object.assign({ method: 'GET', timeoutMs: 30000 }, options || {});
        const controller = new AbortController();
        const timer = setTimeout(() => controller.abort(), opts.timeoutMs);

        const headers = Object.assign({ 'Accept': 'application/json' }, opts.headers || {});
        const method = String(opts.method || 'GET').toUpperCase();
        if (method !== 'GET' && method !== 'HEAD') {
            const csrf = getCsrfToken();
            if (csrf && !headers['X-CSRFToken']) headers['X-CSRFToken'] = csrf;
            if (opts.body && !(opts.body instanceof FormData) && !headers['Content-Type']) {
                headers['Content-Type'] = 'application/json';
            }
        }

        const fetchOpts = {
            method: method,
            headers: headers,
            credentials: 'same-origin',
            signal: controller.signal
        };
        if (opts.body !== undefined) {
            fetchOpts.body = (opts.body instanceof FormData || typeof opts.body === 'string')
                ? opts.body
                : JSON.stringify(opts.body);
        }

        try {
            const resp = await fetch(url, fetchOpts);
            clearTimeout(timer);
            if (resp.status === 401) {
                toast('Your session expired. Redirecting to sign in...', 'warning');
                setTimeout(() => { window.location.href = '/login'; }, 900);
                return { ok: false, status: 401, error: 'Session expired' };
            }
            let data = null;
            try { data = await resp.json(); } catch (_) { data = null; }
            if (!resp.ok) {
                const errMsg = (data && (data.error || data.message)) || `Request failed (HTTP ${resp.status})`;
                return { ok: false, status: resp.status, data: data, error: errMsg };
            }
            return { ok: true, status: resp.status, data: data };
        } catch (err) {
            clearTimeout(timer);
            const msg = err.name === 'AbortError'
                ? 'Request timed out. Please try again.'
                : 'Network error. Please verify your connection.';
            return { ok: false, status: 0, error: msg };
        }
    }

    global.AyevorynAPI = {
        get: (url, opts) => request(url, Object.assign({ method: 'GET' }, opts)),
        post: (url, body, opts) => request(url, Object.assign({ method: 'POST', body: body }, opts)),
        patch: (url, body, opts) => request(url, Object.assign({ method: 'PATCH', body: body }, opts)),
        del: (url, opts) => request(url, Object.assign({ method: 'DELETE' }, opts)),
        toast: toast,
        getCsrfToken: getCsrfToken
    };
})(window);
