/* ==========================================================================
   AYEVORYN INTERACTIVE DASHBOARD ANALYTICS PREVIEW ENGINE
   - Real Dashboard-Style Smooth Line/Area Chart (Revenue vs Expenses)
   - Interactive Departmental Budget Donut / Pie Chart with Center KPI Readout
   - Theme-Aware (Dark & Light) High-DPI Canvas Rendering + Hover Tooltips
   ========================================================================== */
(function () {
    'use strict';

    const DATASETS = {
        '30D': {
            labels: ['Wk 1', 'Wk 2', 'Wk 3', 'Wk 4'],
            revenue: [420, 468, 512, 565],
            expense: [295, 310, 322, 338],
            kpiRev: '₹19.65L',
            kpiExp: '₹12.65L',
            kpiMargin: '35.6%',
            kpiRunway: '18.4 mo'
        },
        '90D': {
            labels: ['Month 1', 'Month 2', 'Month 3'],
            revenue: [1640, 1890, 2180],
            expense: [1180, 1260, 1340],
            kpiRev: '₹57.10L',
            kpiExp: '₹37.80L',
            kpiMargin: '33.8%',
            kpiRunway: '21.2 mo'
        },
        '12M': {
            labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
            revenue: [1120, 1210, 1290, 1360, 1480, 1540, 1620, 1710, 1830, 1940, 2080, 2240],
            expense: [880, 910, 945, 970, 1020, 1050, 1095, 1130, 1185, 1230, 1290, 1345],
            kpiRev: '₹1.94Cr',
            kpiExp: '₹1.31Cr',
            kpiMargin: '32.7%',
            kpiRunway: '24.0 mo'
        }
    };

    const PIE_SLICES = [
        { name: 'Engineering & Product', pct: 34, color: '#0EA5E9' },
        { name: 'Operations & Logistics', pct: 24, color: '#10B981' },
        { name: 'Sales & Growth', pct: 19, color: '#6366F1' },
        { name: 'Supply Chain & Inventory', pct: 14, color: '#F59E0B' },
        { name: 'Treasury Reserve', pct: 9, color: '#14B8A6' }
    ];

    function initDashboardDemo(root) {
        const lineCanvas = root.querySelector('canvas[data-ayv-line-canvas]');
        const pieCanvas = root.querySelector('canvas[data-ayv-pie-canvas]');
        if (!lineCanvas || !pieCanvas) return;

        const lCtx = lineCanvas.getContext('2d');
        const pCtx = pieCanvas.getContext('2d');

        let tf = '12M';
        let lineHover = -1;
        let pieHover = -1;

        function isDark() {
            return (document.documentElement.getAttribute('data-theme') || 'dark') === 'dark';
        }

        function updateKpis() {
            const ds = DATASETS[tf] || DATASETS['12M'];
            const set = function (sel, val) {
                const el = root.querySelector(sel);
                if (el) el.textContent = val;
            };
            set('[data-demo-kpi="rev"]', ds.kpiRev);
            set('[data-demo-kpi="exp"]', ds.kpiExp);
            set('[data-demo-kpi="margin"]', ds.kpiMargin);
            set('[data-demo-kpi="runway"]', ds.kpiRunway);
        }

        function drawLineChart() {
            const ds = DATASETS[tf] || DATASETS['12M'];
            const dpr = window.devicePixelRatio || 1;
            const rect = lineCanvas.parentElement.getBoundingClientRect();
            const w = Math.max(280, rect.width);
            const h = Math.max(240, rect.height);
            lineCanvas.width = w * dpr;
            lineCanvas.height = h * dpr;
            lineCanvas.style.width = w + 'px';
            lineCanvas.style.height = h + 'px';
            lCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

            const dark = isDark();
            const gridCol = dark ? 'rgba(148, 163, 184, 0.14)' : 'rgba(15, 23, 42, 0.08)';
            const txtCol = dark ? '#94A3B8' : '#475569';

            lCtx.clearRect(0, 0, w, h);

            const padL = 44, padR = 18, padT = 22, padB = 32;
            const plotW = w - padL - padR;
            const plotH = h - padT - padB;
            const n = ds.labels.length;
            const maxVal = Math.max.apply(null, ds.revenue.concat(ds.expense)) * 1.15;
            const minVal = 0;

            function xPos(i) {
                return padL + (n === 1 ? plotW / 2 : (i / (n - 1)) * plotW);
            }
            function yPos(v) {
                return padT + (1 - (v - minVal) / (maxVal - minVal)) * plotH;
            }

            // Grid & Y labels
            lCtx.strokeStyle = gridCol;
            lCtx.lineWidth = 1;
            lCtx.fillStyle = txtCol;
            lCtx.font = '11px Inter, sans-serif';
            lCtx.textAlign = 'right';
            for (let g = 0; g <= 4; g++) {
                const y = padT + (plotH / 4) * g;
                const val = Math.round(maxVal - (maxVal / 4) * g);
                lCtx.beginPath();
                lCtx.moveTo(padL, y);
                lCtx.lineTo(w - padR, y);
                lCtx.stroke();
                lCtx.fillText(val + 'k', padL - 8, y + 4);
            }

            function drawSmoothSeries(values, strokeColor, fillTop, fillBot) {
                const pts = values.map(function (v, i) { return { x: xPos(i), y: yPos(v) }; });
                const grad = lCtx.createLinearGradient(0, padT, 0, padT + plotH);
                grad.addColorStop(0, fillTop);
                grad.addColorStop(1, fillBot);

                lCtx.beginPath();
                lCtx.moveTo(pts[0].x, padT + plotH);
                lCtx.lineTo(pts[0].x, pts[0].y);
                for (let i = 0; i < pts.length - 1; i++) {
                    const cx = (pts[i].x + pts[i + 1].x) / 2;
                    lCtx.bezierCurveTo(cx, pts[i].y, cx, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
                }
                lCtx.lineTo(pts[pts.length - 1].x, padT + plotH);
                lCtx.closePath();
                lCtx.fillStyle = grad;
                lCtx.fill();

                lCtx.beginPath();
                lCtx.moveTo(pts[0].x, pts[0].y);
                for (let i = 0; i < pts.length - 1; i++) {
                    const cx = (pts[i].x + pts[i + 1].x) / 2;
                    lCtx.bezierCurveTo(cx, pts[i].y, cx, pts[i + 1].y, pts[i + 1].x, pts[i + 1].y);
                }
                lCtx.strokeStyle = strokeColor;
                lCtx.lineWidth = 2.6;
                lCtx.stroke();

                pts.forEach(function (pt, idx) {
                    const active = idx === lineHover;
                    lCtx.beginPath();
                    lCtx.arc(pt.x, pt.y, active ? 5.5 : 3, 0, Math.PI * 2);
                    lCtx.fillStyle = active ? '#FFFFFF' : strokeColor;
                    lCtx.fill();
                    if (active) {
                        lCtx.strokeStyle = strokeColor;
                        lCtx.lineWidth = 2.5;
                        lCtx.stroke();
                    }
                });
            }

            drawSmoothSeries(ds.revenue, '#0EA5E9', 'rgba(14, 165, 233, 0.28)', 'rgba(14, 165, 233, 0.01)');
            drawSmoothSeries(ds.expense, '#10B981', 'rgba(16, 185, 129, 0.22)', 'rgba(16, 185, 129, 0.01)');

            // X labels
            lCtx.fillStyle = txtCol;
            lCtx.textAlign = 'center';
            ds.labels.forEach(function (lbl, i) {
                lCtx.fillText(lbl, xPos(i), h - 10);
            });

            // Hover guide & HUD update
            const hud = root.querySelector('[data-ayv-line-hud]');
            if (lineHover >= 0 && lineHover < n) {
                const hx = xPos(lineHover);
                lCtx.strokeStyle = dark ? 'rgba(56, 189, 248, 0.45)' : 'rgba(2, 132, 199, 0.45)';
                lCtx.setLineDash([4, 4]);
                lCtx.lineWidth = 1.2;
                lCtx.beginPath();
                lCtx.moveTo(hx, padT);
                lCtx.lineTo(hx, padT + plotH);
                lCtx.stroke();
                lCtx.setLineDash([]);

                const rVal = ds.revenue[lineHover];
                const eVal = ds.expense[lineHover];
                const margin = (((rVal - eVal) / rVal) * 100).toFixed(1);
                if (hud) {
                    hud.innerHTML =
                        '<span>Period: <strong>' + ds.labels[lineHover] + '</strong></span>' +
                        '<span>Revenue: <strong style="color:#0EA5E9;">' + rVal + 'k</strong></span>' +
                        '<span>Expenses: <strong style="color:#10B981;">' + eVal + 'k</strong></span>' +
                        '<span>Net Margin: <strong>' + margin + '%</strong></span>';
                }
            } else if (hud) {
                hud.innerHTML =
                    '<span><i class="fas fa-circle" style="color:#0EA5E9;font-size:8px;margin-right:5px;"></i>Revenue Velocity</span>' +
                    '<span><i class="fas fa-circle" style="color:#10B981;font-size:8px;margin-right:5px;"></i>Operating Spend</span>' +
                    '<span style="opacity:0.75;">Hover chart to inspect period breakdown</span>';
            }
        }

        function drawPieChart() {
            const dpr = window.devicePixelRatio || 1;
            const rect = pieCanvas.parentElement.getBoundingClientRect();
            const w = Math.max(220, rect.width);
            const h = Math.max(220, rect.height);
            pieCanvas.width = w * dpr;
            pieCanvas.height = h * dpr;
            pieCanvas.style.width = w + 'px';
            pieCanvas.style.height = h + 'px';
            pCtx.setTransform(dpr, 0, 0, dpr, 0, 0);

            const dark = isDark();
            pCtx.clearRect(0, 0, w, h);

            const cx = w / 2;
            const cy = h / 2;
            const outerR = Math.min(w, h) * 0.42;
            const innerR = outerR * 0.62;

            let startAngle = -Math.PI / 2;
            PIE_SLICES.forEach(function (sl, idx) {
                const sweep = (sl.pct / 100) * Math.PI * 2;
                const endAngle = startAngle + sweep;
                const active = idx === pieHover;
                const rOut = active ? outerR + 7 : outerR;

                pCtx.beginPath();
                pCtx.arc(cx, cy, rOut, startAngle, endAngle);
                pCtx.arc(cx, cy, innerR, endAngle, startAngle, true);
                pCtx.closePath();
                pCtx.fillStyle = sl.color;
                pCtx.fill();

                pCtx.strokeStyle = dark ? 'rgba(6, 13, 28, 0.85)' : 'rgba(255, 255, 255, 0.95)';
                pCtx.lineWidth = 2.5;
                pCtx.stroke();

                startAngle = endAngle;
            });

            // Center KPI label
            const activeSlice = pieHover >= 0 ? PIE_SLICES[pieHover] : null;
            pCtx.textAlign = 'center';
            pCtx.fillStyle = dark ? '#F8FAFC' : '#0F172A';
            pCtx.font = '800 22px Sora, Inter, sans-serif';
            pCtx.fillText(activeSlice ? (activeSlice.pct + '%') : '100%', cx, cy + 2);
            pCtx.fillStyle = dark ? '#94A3B8' : '#475569';
            pCtx.font = '600 11px Inter, sans-serif';
            pCtx.fillText(activeSlice ? activeSlice.name.split(' ')[0] : 'Allocated', cx, cy + 20);
        }

        // Bind timeframe buttons
        root.querySelectorAll('[data-ayv-demo-tf]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                root.querySelectorAll('[data-ayv-demo-tf]').forEach(function (b) { b.classList.remove('active'); });
                btn.classList.add('active');
                tf = btn.getAttribute('data-ayv-demo-tf');
                lineHover = -1;
                updateKpis();
                drawLineChart();
            });
        });

        // Bind legend hover for pie chart
        root.querySelectorAll('[data-pie-idx]').forEach(function (item) {
            item.addEventListener('mouseenter', function () {
                pieHover = parseInt(item.getAttribute('data-pie-idx'), 10);
                drawPieChart();
            });
            item.addEventListener('mouseleave', function () {
                pieHover = -1;
                drawPieChart();
            });
        });

        lineCanvas.addEventListener('mousemove', function (e) {
            const rect = lineCanvas.getBoundingClientRect();
            const relX = e.clientX - rect.left - 44;
            const plotW = Math.max(1, rect.width - 62);
            const n = (DATASETS[tf] || DATASETS['12M']).labels.length;
            const idx = Math.round((relX / plotW) * (n - 1));
            lineHover = (idx >= 0 && idx < n) ? idx : -1;
            drawLineChart();
        });
        lineCanvas.addEventListener('mouseleave', function () {
            lineHover = -1;
            drawLineChart();
        });

        pieCanvas.addEventListener('mousemove', function (e) {
            const rect = pieCanvas.getBoundingClientRect();
            const dx = e.clientX - rect.left - rect.width / 2;
            const dy = e.clientY - rect.top - rect.height / 2;
            const dist = Math.sqrt(dx * dx + dy * dy);
            const outerR = Math.min(rect.width, rect.height) * 0.44;
            const innerR = outerR * 0.56;
            if (dist < innerR || dist > outerR) {
                pieHover = -1;
                drawPieChart();
                return;
            }
            let ang = Math.atan2(dy, dx) + Math.PI / 2;
            if (ang < 0) ang += Math.PI * 2;
            const pct = (ang / (Math.PI * 2)) * 100;
            let acc = 0;
            pieHover = -1;
            for (let i = 0; i < PIE_SLICES.length; i++) {
                acc += PIE_SLICES[i].pct;
                if (pct <= acc) {
                    pieHover = i;
                    break;
                }
            }
            drawPieChart();
        });
        pieCanvas.addEventListener('mouseleave', function () {
            pieHover = -1;
            drawPieChart();
        });

        window.addEventListener('resize', function () {
            drawLineChart();
            drawPieChart();
        });
        window.addEventListener('ayevoryn:theme-changed', function () {
            drawLineChart();
            drawPieChart();
        });

        updateKpis();
        drawLineChart();
        drawPieChart();
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('[data-ayv-dashboard-demo]').forEach(initDashboardDemo);
    });
})();
