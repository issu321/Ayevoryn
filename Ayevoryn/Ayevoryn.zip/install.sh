#!/bin/sh
set -eu

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$SCRIPT_DIR"

echo "========================================================================"
echo "  AYEVORYN - Enterprise Digital Twin & Pulse AI Platform"
echo "  Publisher: USMANIA TECHS PVT LTD"
echo "  Kali Linux / Debian Automated Setup (Isolated .venv)"
echo "========================================================================"
echo ""

if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 is not installed. Run: sudo apt update && sudo apt install -y python3 python3-venv python3-pip"
    exit 1
fi

PY_VER=$(python3 -c 'import sys; print(sys.version.split()[0])')
echo "[Ayevoryn] Detected Linux Python $PY_VER"

# Create isolated virtual environment (.venv)
if [ ! -d ".venv" ] || [ ! -x ".venv/bin/python3" ]; then
    echo "[Ayevoryn] Creating isolated virtual environment (.venv)..."
    if ! python3 -m venv .venv; then
        echo "[ERROR] Failed to create .venv. On Kali/Debian run:"
        echo "        sudo apt update && sudo apt install -y python3-venv python3-full"
        exit 1
    fi
fi

VENV_PY="$SCRIPT_DIR/.venv/bin/python3"

# Self-heal pip inside .venv if a prior partial venv lacked pip
if ! "$VENV_PY" -m pip --version >/dev/null 2>&1; then
    echo "[Ayevoryn] Bootstrapping pip inside .venv..."
    "$VENV_PY" -m ensurepip --upgrade >/dev/null 2>&1 || true
fi

if [ -f "$SCRIPT_DIR/.venv/bin/activate" ]; then
    . "$SCRIPT_DIR/.venv/bin/activate"
fi

echo "[Ayevoryn] Mapping & installing 100% compatible modules for Python $PY_VER inside .venv..."
"$VENV_PY" "$SCRIPT_DIR/scripts/smart_install_deps.py"

echo ""
echo "[Ayevoryn] Launching Ayevoryn Web Application automatically in your browser..."
"$VENV_PY" "$SCRIPT_DIR/scripts/launch_webapp.py"
echo "[Ayevoryn] Ayevoryn is running in the background at http://127.0.0.1:5000 (logs: logs/ayevoryn_server.log)"
