@echo off
setlocal enabledelayedexpansion
REM ============================================================================
REM  Ayevoryn Windows Desktop Build & Installer Script (USMANIA TECHS PVT LTD)
REM  Run from the project root directory on Windows 10/11 (64-bit).
REM  Produces:
REM    dist\Ayevoryn\Ayevoryn.exe
REM    dist_release\Ayevoryn_Setup.exe  (when Inno Setup 6 is installed)
REM ============================================================================

set "ROOT_DIR=%~dp0"
if "%ROOT_DIR:~-1%"=="\" set "ROOT_DIR=%ROOT_DIR:~0,-1%"
cd /d "%ROOT_DIR%"

echo ========================================================================
echo  AYEVORYN WINDOWS DESKTOP BUILDER  ^|  USMANIA TECHS PVT LTD
echo ========================================================================
echo.

REM [1/7] Verify Python 3.10+
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python 3.10+ was not found on PATH. Install Python 3.11 64-bit and retry.
    exit /b 1
)
for /f "tokens=*" %%v in ('python --version') do echo [1/7] Detected %%v

REM [2/7] Create or reuse clean packaging virtual environment
set "VENV_DIR=%ROOT_DIR%\.venv_build"
if not exist "%VENV_DIR%\Scripts\python.exe" (
    echo [2/7] Creating clean build virtual environment at "%VENV_DIR%"...
    python -m venv "%VENV_DIR%"
    if errorlevel 1 (
        echo [ERROR] Failed to create virtual environment.
        exit /b 1
    )
) else (
    echo [2/7] Reusing existing build virtual environment at "%VENV_DIR%"...
)

set "PY=%VENV_DIR%\Scripts\python.exe"
set "PIP=%VENV_DIR%\Scripts\pip.exe"

REM [3/7] Install project and desktop packaging dependencies
echo [3/7] Installing application and Windows desktop packaging dependencies...
"%PY%" -m pip install --upgrade pip wheel setuptools
if errorlevel 1 exit /b 1
"%PIP%" install -r "%ROOT_DIR%\requirements.txt"
if errorlevel 1 (
    echo [ERROR] Failed to install requirements.txt.
    exit /b 1
)
"%PIP%" install -r "%ROOT_DIR%\packaging\requirements-desktop.txt"
if errorlevel 1 (
    echo [ERROR] Failed to install packaging\requirements-desktop.txt.
    exit /b 1
)

REM [4/7] Clean previous build output safely (never touches user data)
echo [4/7] Preparing clean build and dist directories...
if exist "%ROOT_DIR%\build\Ayevoryn" rmdir /s /q "%ROOT_DIR%\build\Ayevoryn"
if exist "%ROOT_DIR%\dist\Ayevoryn" rmdir /s /q "%ROOT_DIR%\dist\Ayevoryn"
if not exist "%ROOT_DIR%\dist_release" mkdir "%ROOT_DIR%\dist_release"

REM [5/7] Build Ayevoryn.exe via PyInstaller
echo [5/7] Building Ayevoryn.exe via PyInstaller...
"%PY%" -m PyInstaller --noconfirm --clean "%ROOT_DIR%\packaging\Ayevoryn.spec"
if errorlevel 1 (
    echo [ERROR] PyInstaller build failed. Inspect the output above.
    exit /b 1
)

REM [6/7] Run automated build verification
echo [6/7] Verifying packaged Ayevoryn.exe bundle...
call "%ROOT_DIR%\packaging\verify_build.bat"
if errorlevel 1 (
    echo [ERROR] Build verification failed.
    exit /b 1
)

REM [7/7] Build Ayevoryn_Setup.exe via Inno Setup 6 (if installed)
echo [7/7] Building Windows Installer (Ayevoryn_Setup.exe)...
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"

if "%ISCC%"=="" (
    echo [WARNING] Inno Setup 6 ^(ISCC.exe^) was not found.
    echo           Install Inno Setup 6 from https://jrsoftware.org/isinfo.php and re-run build_windows.bat
    echo           to generate dist_release\Ayevoryn_Setup.exe.
) else (
    "%ISCC%" "%ROOT_DIR%\packaging\installer.iss"
    if errorlevel 1 (
        echo [ERROR] Inno Setup installer compilation failed.
        exit /b 1
    )
    echo [OK] Installer built: "%ROOT_DIR%\dist_release\Ayevoryn_Setup.exe"
)

REM Copy key release assets into dist_release
copy /y "%ROOT_DIR%\packaging\assets\Ayevoryn.ico" "%ROOT_DIR%\dist_release\Ayevoryn.ico" >nul
copy /y "%ROOT_DIR%\packaging\assets\Ayevoryn_master_1024.png" "%ROOT_DIR%\dist_release\Ayevoryn_master_1024.png" >nul
copy /y "%ROOT_DIR%\packaging\README_WINDOWS_BUILD.md" "%ROOT_DIR%\dist_release\README_WINDOWS_BUILD.md" >nul

echo.
echo ========================================================================
echo  BUILD COMPLETE  ^|  Output folder: "%ROOT_DIR%\dist_release"
echo ========================================================================
exit /b 0
