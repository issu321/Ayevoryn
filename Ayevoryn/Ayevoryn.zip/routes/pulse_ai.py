"""
AEVORYN PULSE AI — ENTERPRISE INTELLIGENCE WORKSPACE ROUTES
Strictly enforces server-side multi-tenant company_id derivation (never trusts client-supplied company_id).
Supports persistent conversations, controlled tool confirmation, and real SSE progressive streaming.
"""

import os
import json
import time
import re
from flask import Blueprint, render_template, request, jsonify, session, Response, stream_with_context, redirect, url_for, send_file, current_app, flash
from flask_login import login_required, current_user

from database.db import db
from database.models.company import Company
from database.models.pulse_ai import AIConversation, AIMessage, AIToolExecution
from security.tenant import get_current_company_id
from services.pulse_ai_engine import PulseAIEngine, PulseAIProviderManager, PulseAIContextRetriever

pulse_ai_bp = Blueprint('pulse_ai', __name__, url_prefix='/pulse-ai')


def _get_verified_tenant_company_id() -> int:
    """
    Strictly derive the organization scope from the authenticated server-side session and user record.
    Never trusts any organization ID sent in request body or query parameters.
    """
    cid = getattr(current_user, 'company_id', None) or get_current_company_id() or session.get('company_id')
    if cid:
        return int(cid)
    first_c = Company.query.first()
    return first_c.id if first_c else None


@pulse_ai_bp.route('/')
@login_required
def workspace():
    """Render the dedicated Pulse AI Enterprise Intelligence Workspace."""
    cid = _get_verified_tenant_company_id()
    if not cid:
        return redirect(url_for('auth.login'))

    company = db.session.get(Company, cid)
    conversations = PulseAIEngine.list_conversations(cid, current_user.id, limit=30)
    provider_status = PulseAIProviderManager.get_provider_status()

    return render_template(
        'ai/pulse_ai_workspace.html',
        company=company,
        conversations=conversations,
        provider_status=provider_status
    )



@pulse_ai_bp.route('/automations')
@login_required
def automations_studio():
    """Dedicated Visual Linked-Node AI Automations Studio linked to Pulse AI."""
    from database.models.company import Company
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    if not cid:
        flash('Please complete company setup to access AI Automations Studio.', 'warning')
        return redirect(url_for('dashboard.index'))
    company = db.session.get(Company, cid)
    automations = PulseAutomationService.list_automations(cid)
    return render_template('ai/pulse_automations.html', company=company, automations=automations)


@pulse_ai_bp.route('/api/status')
@login_required
def api_status():
    cid = _get_verified_tenant_company_id()
    comp = db.session.get(Company, cid) if cid else None
    status = PulseAIProviderManager.get_provider_status()
    return jsonify({
        'success': True,
        'provider': status,
        'tenant': {
            'company_id': comp.id if comp else None,
            'company_name': comp.company_name if comp else None,
            'org_uid': comp.organization_code if comp else None
        }
    })


@pulse_ai_bp.route('/api/conversations', methods=['GET', 'POST'])
@login_required
def api_conversations():
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'Organization context unavailable'}), 400

    if request.method == 'POST':
        data = request.get_json(force=True, silent=True) or {}
        title = (data.get('title') or 'New Executive Briefing').strip()
        conv = PulseAIEngine.get_or_create_conversation(cid, current_user.id, title_hint=title)
        return jsonify({'success': True, 'conversation': conv.to_dict()})

    items = PulseAIEngine.list_conversations(cid, current_user.id, limit=40)
    return jsonify({'success': True, 'conversations': items})


@pulse_ai_bp.route('/api/conversations/<int:conversation_id>', methods=['GET'])
@login_required
def api_get_conversation(conversation_id):
    cid = _get_verified_tenant_company_id()
    data = PulseAIEngine.get_conversation_messages(cid, current_user.id, conversation_id)
    if not data:
        return jsonify({'success': False, 'error': 'Conversation not found or access denied'}), 404
    return jsonify({'success': True, **data})


@pulse_ai_bp.route('/api/conversations/<int:conversation_id>/rename', methods=['POST', 'PATCH'])
@login_required
def api_rename_conversation(conversation_id):
    cid = _get_verified_tenant_company_id()
    data = request.get_json(force=True, silent=True) or {}
    new_title = (data.get('title') or request.form.get('title') or '').strip()
    if not new_title:
        return jsonify({'success': False, 'error': 'Title is required'}), 400
    ok = PulseAIEngine.rename_conversation(cid, current_user.id, conversation_id, new_title)
    if not ok:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    return jsonify({'success': True, 'title': new_title})


@pulse_ai_bp.route('/api/conversations/<int:conversation_id>/delete', methods=['POST', 'DELETE'])
@login_required
def api_delete_conversation(conversation_id):
    cid = _get_verified_tenant_company_id()
    ok = PulseAIEngine.delete_conversation(cid, current_user.id, conversation_id)
    if not ok:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    return jsonify({'success': True})


@pulse_ai_bp.route('/api/chat', methods=['POST'])
@login_required
def api_chat():
    """
    Execute a conversational turn scoped strictly to the authenticated session's company_id.
    Note: Any `company_id` passed in the request JSON is ignored to guarantee multi-tenant security.
    """
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'No active organization context'}), 400

    data = request.get_json(force=True, silent=True) or {}
    model_tier = (data.get('model_tier') or '').strip().lower()
    if model_tier in PULSE_TIER_MAP:
        try:
            from services.superadmin_service import SuperadminService
            _p, _m = PULSE_TIER_MAP[model_tier]
            SuperadminService.set_setting('ai_provider', _p, value_type='string', category='ai_config', user_id=current_user.id)
            SuperadminService.set_setting('ai_model_name', _m, value_type='string', category='ai_config', user_id=current_user.id)
        except Exception:
            pass
    prompt = (data.get('prompt') or data.get('message') or '').strip()
    conversation_id = data.get('conversation_id')

    res = PulseAIEngine.process_conversation_turn(
        company_id=cid,
        user_id=current_user.id,
        prompt=prompt,
        conversation_id=conversation_id,
        require_confirmation_for_mutations=True
    )
    if isinstance(res, dict):
        if res.get('markdown') and not res.get('response'):
            res['response'] = res['markdown']
        if isinstance(res.get('conversation'), dict) and res['conversation'].get('id') and not res.get('conversation_id'):
            res['conversation_id'] = res['conversation']['id']
        if isinstance(res.get('agent_action'), dict) and res['agent_action'].get('type') == 'navigate' and not res.get('navigation_action'):
            res['navigation_action'] = res['agent_action']
    status_code = 200 if res.get('success') else 400
    return jsonify(res), status_code


@pulse_ai_bp.route('/api/stream', methods=['POST', 'GET'])
@login_required
def api_stream():
    """
    Real Server-Sent Events (SSE) progressive streaming endpoint for Pulse AI.
    Synchronizes with genuine backend operations:
      1. state: preparing_context
      2. state: analyzing_company_information
      3. state: executing_tool (only if an analytical/mutation tool is invoked)
      4. state: generating_response + progressive text chunks
      5. state: completed (with full structured tables, metrics, and provenance)
    """
    cid = _get_verified_tenant_company_id()
    uid = current_user.id

    if request.method == 'POST':
        data = request.get_json(force=True, silent=True) or {}
        prompt = (data.get('prompt') or data.get('message') or '').strip()
        conversation_id = data.get('conversation_id')
    else:
        prompt = (request.args.get('prompt') or '').strip()
        conversation_id = request.args.get('conversation_id', type=int)

    if not prompt:
        return jsonify({'success': False, 'error': 'Prompt is required'}), 400

    def _sse_event(event_type: str, payload: dict) -> str:
        return f"event: {event_type}\ndata: {json.dumps(payload, default=str)}\n\n"

    @stream_with_context
    def generate():
        try:
            # Stage 1: Preparing context
            yield _sse_event('stage', {'state': 'preparing_context', 'label': 'Preparing organization context...'})

            domains = PulseAIContextRetriever.detect_domains(prompt)
            # Stage 2: Analyzing company information
            yield _sse_event('stage', {
                'state': 'analyzing_company_information',
                'label': f"Analyzing {', '.join(sorted(domains))} records..."
            })

            # Execute full turn on server
            result = PulseAIEngine.process_conversation_turn(
                company_id=cid,
                user_id=uid,
                prompt=prompt,
                conversation_id=conversation_id,
                require_confirmation_for_mutations=True
            )

            if not result.get('success'):
                yield _sse_event('error', {'state': 'error', 'error': result.get('error', 'Failed to generate response')})
                return

            # Stage 3: If tools were invoked, emit genuine tool stage
            asst_msg = result.get('assistant_message') or {}
            tools = asst_msg.get('tool_calls') or []
            if tools:
                tool_names = ', '.join(t.get('name', 'tool') for t in tools)
                yield _sse_event('stage', {
                    'state': 'executing_tool',
                    'label': f"Executing authorized tool: {tool_names}"
                })

            # Stage 4: Generating response — stream markdown tokens progressively with animated typing cadence
            yield _sse_event('stage', {'state': 'generating_response', 'label': 'Synthesizing executive response...'})
            full_md = result.get('markdown') or ''
            
            # Tokenize into word units with trailing spaces/newlines preserved
            tokens = re.findall(r'\S+\s*', full_md)
            if not tokens:
                tokens = [full_md]

            # If an agentic navigation/action is ready, deliver immediately so transition overlay fires right away
            if result.get('agent_action'):
                yield _sse_event('chunk', {'delta': full_md})
            else:
                batch_size = 4
                for i in range(0, len(tokens), batch_size):
                    piece = ''.join(tokens[i:i + batch_size])
                    yield _sse_event('chunk', {'delta': piece})
                    time.sleep(0.008)

            # Stage 5: Completed
            yield _sse_event('completed', {
                'state': 'completed',
                'label': 'Completed',
                'result': result
            })
        except Exception as e:
            yield _sse_event('error', {'state': 'error', 'error': str(e)})

    headers = {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'X-Accel-Buffering': 'no'
    }
    return Response(generate(), headers=headers)


@pulse_ai_bp.route('/api/actions/<execution_uid>/confirm', methods=['POST'])
@login_required
def api_confirm_action(execution_uid):
    cid = _get_verified_tenant_company_id()
    res = PulseAIEngine.confirm_and_execute_action(
        execution_uid=execution_uid,
        company_id=cid,
        user_id=current_user.id,
        username=current_user.username
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/actions/<execution_uid>/cancel', methods=['POST'])
@login_required
def api_cancel_action(execution_uid):
    cid = _get_verified_tenant_company_id()
    res = PulseAIEngine.cancel_action(
        execution_uid=execution_uid,
        company_id=cid,
        user_id=current_user.id
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/messages/<int:message_id>/feedback', methods=['POST'])
@login_required
def api_message_feedback(message_id):
    cid = _get_verified_tenant_company_id()
    msg = AIMessage.query.filter_by(id=message_id, company_id=cid).first()
    if not msg:
        return jsonify({'success': False, 'error': 'Message not found'}), 404

    data = request.get_json(force=True, silent=True) or {}
    rating = (data.get('rating') or '').strip().lower()
    if rating not in ('up', 'down'):
        return jsonify({'success': False, 'error': 'Invalid rating'}), 400

    msg.feedback_rating = rating
    db.session.commit()
    return jsonify({'success': True, 'message_id': msg.id, 'rating': rating})


@pulse_ai_bp.route('/api/messages/<int:message_id>/regenerate', methods=['POST'])
@login_required
def api_regenerate_message(message_id):
    cid = _get_verified_tenant_company_id()
    msg = AIMessage.query.filter_by(id=message_id, company_id=cid).first()
    if not msg:
        return jsonify({'success': False, 'error': 'Message not found'}), 404

    # Find the preceding user message in the same conversation
    user_msg = AIMessage.query.filter(
        AIMessage.conversation_id == msg.conversation_id,
        AIMessage.company_id == cid,
        AIMessage.role == 'user',
        AIMessage.id <= msg.id
    ).order_by(AIMessage.id.desc()).first()

    if not user_msg:
        return jsonify({'success': False, 'error': 'Original user prompt not found'}), 404

    res = PulseAIEngine.process_conversation_turn(
        company_id=cid,
        user_id=current_user.id,
        prompt=user_msg.content,
        conversation_id=msg.conversation_id,
        require_confirmation_for_mutations=True
    )
    return jsonify(res), (200 if res.get('success') else 400)



PULSE_TIER_MAP = {
    'pulse_pro': ('nvidia', 'nvidia/nemotron-3.5-bolt-e4b'),
    'pulse_fast': ('nvidia', 'nvidia/nemotron-3.5-lightning-30b-a3b'),
    'pulse_edge': ('openrouter', 'nvidia/nemotron-3.5-lightning:free'),
    'pulse_auto': ('openrouter', 'openrouter/free'),
    'pulse_gemini': ('gemini', 'gemini-2.5-flash'),
}


def _resolve_pulse_tier(provider_or_tier: str, model_or_tier: str):
    key = (model_or_tier or '').strip().lower()
    if key in PULSE_TIER_MAP:
        return PULSE_TIER_MAP[key]
    pkey = (provider_or_tier or '').strip().lower()
    if pkey in PULSE_TIER_MAP:
        return PULSE_TIER_MAP[pkey]
    return (provider_or_tier or 'nvidia').strip().lower(), (model_or_tier or 'nvidia/nemotron-3.5-bolt-e4b').strip()


@pulse_ai_bp.route('/api/configure-provider', methods=['POST'])
@login_required
def api_configure_provider():
    """Allow authorized company admins/owners/superadmins to configure Pulse AI engine settings."""
    from services.superadmin_service import SuperadminService
    role = (getattr(current_user, 'role', '') or '').strip().lower()
    is_sa = bool(getattr(current_user, 'is_superadmin', False))
    if not is_sa and role not in ('admin', 'owner', 'ceo', 'cfo', 'superadmin', 'executive'):
        return jsonify({'success': False, 'error': 'Only company administrators can update Pulse AI engine configuration.'}), 403
    data = request.get_json(force=True, silent=True) or {}
    raw_provider = (data.get('provider') or data.get('tier') or 'pulse_pro').strip()
    raw_model = (data.get('model_name') or data.get('tier') or '').strip()
    provider, model_name = _resolve_pulse_tier(raw_provider, raw_model)
    rerank_model = (data.get('rerank_model') or '').strip()
    api_key = (data.get('api_key') or '').strip()

    SuperadminService.set_setting('ai_provider', provider, value_type='string', category='ai_config', user_id=current_user.id)
    if model_name:
        SuperadminService.set_setting('ai_model_name', model_name, value_type='string', category='ai_config', user_id=current_user.id)
    if rerank_model:
        SuperadminService.set_setting('ai_openrouter_rerank_model', rerank_model, value_type='string', category='ai_config', user_id=current_user.id)

    if api_key:
        if provider == 'nvidia' or api_key.startswith('nvapi-'):
            SuperadminService.set_setting('ai_nvidia_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'openrouter' or api_key.startswith('sk-or-'):
            SuperadminService.set_setting('ai_openrouter_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider in ('gemini', 'auto') or api_key.startswith('AQ.') or api_key.startswith('AIza'):
            SuperadminService.set_setting('ai_gemini_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'anthropic' or api_key.startswith('sk-ant'):
            SuperadminService.set_setting('ai_anthropic_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'openai' or api_key.startswith('sk-'):
            SuperadminService.set_setting('ai_openai_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'groq' or api_key.startswith('gsk_'):
            SuperadminService.set_setting('ai_groq_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)

    status = PulseAIProviderManager.get_provider_status()
    return jsonify({'success': True, 'provider_status': status})


@pulse_ai_bp.route('/api/test-connection', methods=['POST'])
@login_required
def api_test_connection():
    """Test live connectivity to Google Gemini or the configured Cloud LLM."""
    data = request.get_json(force=True, silent=True) or {}
    raw_p = (data.get('provider') or data.get('tier') or '').strip()
    raw_m = (data.get('model_name') or data.get('tier') or '').strip()
    provider, model_name = _resolve_pulse_tier(raw_p, raw_m) if (raw_p or raw_m) else (None, None)
    api_key = (data.get('api_key') or '').strip() or None
    res = PulseAIProviderManager.test_provider_connection(
        provider=provider,
        model=model_name,
        api_key=api_key
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/executive-briefing', methods=['POST'])
@login_required
def api_executive_briefing():
    """Generate a live Gemini-powered C-suite executive briefing grounded in the company's real database."""
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'No active organization context'}), 400
    data = request.get_json(force=True, silent=True) or {}
    conversation_id = data.get('conversation_id')
    prompt = (
        "Generate a comprehensive C-Suite Executive Briefing for our company covering: "
        "1) Financial position & 30-day P&L, 2) Treasury & bank account balances, "
        "3) Workforce & department performance, 4) CRM customers, suppliers & inventory status, "
        "5) Top enterprise risks, and 6) Top 3 prioritized strategic actions for this month."
    )
    res = PulseAIEngine.process_conversation_turn(
        company_id=cid,
        user_id=current_user.id,
        prompt=prompt,
        conversation_id=conversation_id,
        require_confirmation_for_mutations=True
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/automations', methods=['GET', 'POST'])
@login_required
def api_automations():
    """List or create real scheduled Pulse AI automations (reports, risk scans, briefings)."""
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'Organization context unavailable'}), 400

    try:
        PulseAutomationService.start_automation_scheduler(current_app._get_current_object())
    except Exception:
        pass

    if request.method == 'POST':
        data = request.get_json(force=True, silent=True) or {}
        res = PulseAutomationService.create_automation(
            company_id=cid,
            user_id=current_user.id,
            name=data.get('name') or 'Scheduled Pulse AI Automation',
            task_type=data.get('task_type') or 'custom_agent_prompt',
            interval_seconds=data.get('interval_seconds'),
            interval_minutes=data.get('interval_minutes'),
            interval_hours=data.get('interval_hours'),
            interval_days=data.get('interval_days'),
            report_type=data.get('report_type') or 'executive',
            format_type=data.get('format_type') or 'pdf',
            prompt=data.get('prompt') or '',
            run_immediately=bool(data.get('run_immediately', False))
        )
        return jsonify(res), (200 if res.get('success') else 400)

    items = PulseAutomationService.list_automations(cid)
    return jsonify({'success': True, 'automations': items})



@pulse_ai_bp.route('/api/automations/<int:auto_id>/runs', methods=['GET'])
@login_required
def api_automation_runs(auto_id):
    """Return full per-run execution history (Run #1, #2, #3, ...) for a specific automation."""
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    runs = PulseAutomationService.list_automation_runs(auto_id, cid)
    return jsonify({'success': True, 'automation_id': auto_id, 'runs': runs}), 200


@pulse_ai_bp.route('/api/automations/<int:auto_id>/run', methods=['POST'])
@login_required
def api_run_automation(auto_id):
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    res = PulseAutomationService.run_automation_now(auto_id, cid)
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/automations/<int:auto_id>/toggle', methods=['POST'])
@login_required
def api_toggle_automation(auto_id):
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    res = PulseAutomationService.toggle_automation(auto_id, cid)
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/automations/<int:auto_id>', methods=['DELETE', 'POST'])
@login_required
def api_delete_automation(auto_id):
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    res = PulseAutomationService.delete_automation(auto_id, cid)
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/exports/<export_uid>', methods=['GET'])
@login_required
def api_download_secure_export(export_uid):
    """Strictly authenticated, tenant-isolated download endpoint for Pulse AI generated Excel/CSV files."""
    from services.agent_export_service import resolve_secure_export_file
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'Organization context unavailable'}), 403
    file_path, mime, dl_name = resolve_secure_export_file(cid, export_uid)
    if not file_path:
        return jsonify({'success': False, 'error': 'Export not found or access denied'}), 404
    return send_file(str(file_path), mimetype=mime, as_attachment=True, download_name=dl_name)


@pulse_ai_bp.route('/api/voice/profiles', methods=['GET'])
@login_required
def api_voice_profiles():
    """Return available white-labeled Male & Female human voice profiles."""
    from services.pulse_voice_service import VOICE_PROFILES
    profiles = [
        {'id': k, 'label': v['label'], 'gender': v['ssml_gender'].lower(), 'language': v['language_code']}
        for k, v in VOICE_PROFILES.items()
    ]
    return jsonify({'success': True, 'profiles': profiles})


@pulse_ai_bp.route('/api/voice/synthesize', methods=['POST'])
@login_required
def api_voice_synthesize():
    """Synthesize natural human Male/Female speech audio server-side (never exposes keys)."""
    from services.pulse_voice_service import synthesize_human_voice
    data = request.get_json(force=True, silent=True) or {}
    text = (data.get('text') or '').strip()
    voice_id = (data.get('voice_id') or 'female_us').strip()
    result = synthesize_human_voice(text, voice_id=voice_id)
    return jsonify(result), 200


@pulse_ai_bp.route('/api/attachments/analyze', methods=['POST'])
@login_required
def api_analyze_attachment():
    """Parse an attached PDF, Excel, CSV, JSON, TXT, or Image file for live Pulse AI analysis."""
    from services.pulse_attachment_service import analyze_uploaded_bytes
    f = request.files.get('file')
    if not f or not f.filename:
        return jsonify({'success': False, 'error': 'No file uploaded.'}), 400
    raw = f.read()
    user_prompt = (request.form.get('prompt') or '').strip()
    res = analyze_uploaded_bytes(f.filename, raw, user_prompt=user_prompt)
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/monitor/live', methods=['GET'])
@login_required
def api_live_autonomous_monitor():
    """Run an autonomous live business telemetry sweep and return anomalies, health score, and active monitors."""
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    uid = getattr(current_user, 'id', 1)
    notify = request.args.get('notify') == '1'
    res = PulseAutomationService.run_live_monitor_sweep(cid, user_id=uid, create_notifications=notify)
    return jsonify(res), 200


@pulse_ai_bp.route('/api/monitor/activate-preset', methods=['POST'])
@login_required
def api_activate_monitor_preset():
    """One-click activation of a recurring autonomous watchdog monitor."""
    from services.pulse_automation_service import PulseAutomationService
    cid = _get_verified_tenant_company_id()
    uid = getattr(current_user, 'id', 1)
    data = request.get_json(force=True, silent=True) or {}
    preset_key = (data.get('preset_key') or '').strip()
    res = PulseAutomationService.activate_preset_monitor(cid, uid, preset_key)
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/company-upi-qr', methods=['GET'])
@login_required
def api_company_upi_qr():
    """Generate or serve the authenticated company's live UPI payment QR code as a crisp PNG image."""
    import io
    from urllib.parse import quote
    from database.models.company import Company
    from database.models.company_payments import CompanyPayments

    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'Organization context unavailable'}), 403

    company = db.session.get(Company, cid)
    pay = CompanyPayments.query.filter_by(company_id=cid).order_by(CompanyPayments.is_primary_account.desc(), CompanyPayments.id.asc()).first()
    upi_id = (getattr(pay, 'upi_id', None) or '').strip() if pay else ''
    upi_link_stored = (getattr(pay, 'upi_link', None) or '').strip() if pay else ''
    display_name = (
        (getattr(pay, 'upi_display_name', None) or '').strip()
        or (getattr(company, 'company_name', None) or 'Ayevoryn Merchant').strip()
    ) if pay or company else 'Ayevoryn Merchant'

    amount = (request.args.get('amount') or '').strip()
    note = (request.args.get('note') or '').strip()
    as_dl = request.args.get('download') == '1'

    # If a custom QR image file was uploaded and no dynamic amount/note override is requested, serve it directly
    if pay and pay.qr_code_path and not amount and not note:
        qr_path = pay.qr_code_path
        if not os.path.isabs(qr_path):
            qr_path = os.path.join(current_app.root_path, qr_path)
        if os.path.isfile(qr_path):
            return send_file(qr_path, mimetype='image/png', as_attachment=as_dl, download_name='company_upi_qr.png')

    if not upi_id and not upi_link_stored:
        return jsonify({'success': False, 'error': 'No UPI ID is configured for this company yet. Add your UPI ID in Settings -> Payments.'}), 404

    if upi_id:
        parts = [f"pa={quote(upi_id, safe='@._-')}", f"pn={quote(display_name, safe='')}"]
        if amount:
            parts.append(f"am={quote(amount, safe='.')}")
        parts.append('cu=INR')
        if note:
            parts.append(f"tn={quote(note, safe='')}")
        upi_uri = 'upi://pay?' + '&'.join(parts)
    else:
        upi_uri = upi_link_stored

    import qrcode
    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=3)
    qr.add_data(upi_uri)
    qr.make(fit=True)
    img = qr.make_image(fill_color='#0B1120', back_color='#FFFFFF').convert('RGB')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    buf.seek(0)
    resp = send_file(buf, mimetype='image/png', as_attachment=as_dl, download_name='company_upi_qr.png')
    resp.headers['Cache-Control'] = 'no-store, max-age=0'
    return resp
