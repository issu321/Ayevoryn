from flask import Blueprint, render_template, redirect, url_for, request, jsonify
from flask_login import current_user
from services.pulse_ai_engine import PulseAIProviderManager

public_bp = Blueprint('public', __name__)


@public_bp.route('/')
def home():
    """AEVORYN Enterprise Digital Twin & Decision Intelligence Public Landing Page."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    return render_template('landing/index.html', active_page='home')


@public_bp.route('/architecture')
def architecture():
    """AEVORYN Platform Architecture Overview."""
    return render_template('landing/architecture.html', active_page='architecture')


@public_bp.route('/features')
def features():
    """AEVORYN Platform Features & Capabilities Tour."""
    return render_template('landing/features.html', active_page='features')


@public_bp.route('/decision-models')
def decision_models():
    """AEVORYN Financial Modeling & Scenario Simulation Showcase."""
    return render_template('landing/decision_models.html', active_page='decision_models')


@public_bp.route('/dependency-intelligence')
def dependency_intelligence():
    """AEVORYN Department Dependency & Impact Analysis Overview."""
    return render_template('landing/dependency_intelligence.html', active_page='dependency_intelligence')


@public_bp.route('/privacy')
def privacy():
    """Ayevoryn Privacy Policy — USMANIA TECHS PVT LTD."""
    return render_template('landing/privacy.html', active_page='privacy')


@public_bp.route('/terms')
def terms():
    """Ayevoryn Terms of Service — USMANIA TECHS PVT LTD."""
    return render_template('landing/terms.html', active_page='terms')


@public_bp.route('/api/public/pulse-assistant', methods=['POST'])
def public_pulse_assistant():
    """
    Live OpenRouter-powered Pulse AI Assistant for public visitors & organization registration.
    Provides real-time guidance on platform capabilities and step-by-step registration tips.
    """
    data = request.get_json(force=True, silent=True) or {}
    prompt = (data.get('prompt') or data.get('message') or '').strip()
    page = (data.get('page') or 'home').strip().lower()
    stage = data.get('stage')
    history = data.get('history') or []

    if not prompt:
        return jsonify({'success': False, 'error': 'Please enter a question for Pulse Assistant.'}), 400
    if len(prompt) > 1200:
        prompt = prompt[:1200]

    # Sanitize client-provided history
    clean_history = []
    if isinstance(history, list):
        for item in history[-6:]:
            if isinstance(item, dict) and item.get('content'):
                role = 'assistant' if item.get('role') == 'assistant' else 'user'
                clean_history.append({'role': role, 'content': str(item.get('content'))[:800]})

    result = PulseAIProviderManager.call_public_onboarding_assistant(
        prompt=prompt,
        page=page,
        registration_stage=stage,
        history=clean_history
    )
    return jsonify(result), (200 if result.get('success') else 500)


@public_bp.route('/about')
def about():
    """Branded About Ayevoryn page displaying version, USMANIA TECHS PVT LTD identity, and OSS notices."""
    import os
    from desktop.version import APP_NAME, APP_VERSION, PUBLISHER, COPYRIGHT_YEAR, COPYRIGHT_NOTICE
    is_desktop = os.environ.get('AYEVORYN_DESKTOP_MODE') == '1'
    return render_template(
        'landing/about.html',
        app_name=APP_NAME,
        app_version=APP_VERSION,
        publisher=PUBLISHER,
        copyright_year=COPYRIGHT_YEAR,
        copyright_notice=COPYRIGHT_NOTICE,
        runtime_mode='Windows Desktop Application (Local Loopback)' if is_desktop else 'Enterprise Web Application',
    )


@public_bp.route('/api/public/pulse-voice', methods=['POST'])
def public_pulse_voice():
    """Synthesize natural human speech for the public floating Pulse AI bubble (length-capped)."""
    from services.pulse_voice_service import synthesize_human_voice
    data = request.get_json(force=True, silent=True) or {}
    text = (data.get('text') or '').strip()[:350]
    voice_id = (data.get('voice_id') or 'female_us').strip()
    if not text:
        return jsonify({'success': False, 'error': 'Empty text'}), 400
    res = synthesize_human_voice(text, voice_id=voice_id)
    return jsonify(res), 200
