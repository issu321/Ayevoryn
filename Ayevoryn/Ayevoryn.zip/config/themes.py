# ══════════════════════════════════════════════════════════════════════════
# AYEVORYN PREMIUM GLASS UI V2 THEME SYSTEM (USMANIA TECHS PVT LTD)
# Soft White & Sky-Blue Glass (Light) | Deep Charcoal-Navy & Sky-Blue Glass (Dark)
# ══════════════════════════════════════════════════════════════════════════

THEMES = {
    'white_clay_glass': {
        'name': 'Ayevoryn Light',
        'color_scheme': 'light',
        'bg_primary': '#F7FAFC',
        'bg_secondary': '#EFF6FF',
        'sidebar_bg': 'rgba(255, 255, 255, 0.84)',
        'topbar_bg': 'rgba(255, 255, 255, 0.82)',
        'accent_primary': '#38BDF8',
        'accent_secondary': '#60A5FA',
        'accent_warning': '#D99A32',
        'accent_success': '#16A085',
        'accent_danger': '#E36B73',
        'text_primary': '#172033',
        'text_secondary': '#64748B',
        'text_muted': '#899BAC',
        'card_bg': 'rgba(255, 255, 255, 0.82)',
        'card_bg_solid': '#FFFFFF',
        'border': 'rgba(203, 213, 225, 0.62)',
        'shadow': '0 4px 16px rgba(23, 32, 51, 0.05)',
        'gradient': 'linear-gradient(180deg, #F7FAFC 0%, #EFF6FF 100%)',
        'aurora': 'radial-gradient(ellipse at 12% 8%, rgba(56, 189, 248, 0.09) 0%, transparent 48%), radial-gradient(ellipse at 88% 90%, rgba(96, 165, 250, 0.07) 0%, transparent 48%)',
    },
    'dark_clay_glass': {
        'name': 'Ayevoryn Dark',
        'color_scheme': 'dark',
        'bg_primary': '#0B1120',
        'bg_secondary': '#101B2D',
        'sidebar_bg': 'rgba(16, 27, 45, 0.86)',
        'topbar_bg': 'rgba(16, 27, 45, 0.84)',
        'accent_primary': '#38BDF8',
        'accent_secondary': '#60A5FA',
        'accent_warning': '#E5B25E',
        'accent_success': '#41C6A5',
        'accent_danger': '#F17D85',
        'text_primary': '#F1F5F9',
        'text_secondary': '#94A3B8',
        'text_muted': '#758CA3',
        'card_bg': 'rgba(23, 34, 53, 0.82)',
        'card_bg_solid': '#172235',
        'border': 'rgba(148, 163, 184, 0.18)',
        'shadow': '0 8px 24px rgba(0, 0, 0, 0.28)',
        'gradient': 'linear-gradient(180deg, #0B1120 0%, #101B2D 100%)',
        'aurora': 'radial-gradient(ellipse at 12% 8%, rgba(56, 189, 248, 0.08) 0%, transparent 50%), radial-gradient(ellipse at 88% 90%, rgba(96, 165, 250, 0.06) 0%, transparent 50%)',
    }
}

LEGACY_THEME_FALLBACKS = {
    'aurora_enterprise': 'dark_clay_glass',
    'midnight_gold': 'dark_clay_glass',
    'arctic_frost': 'dark_clay_glass',
    'neon_cyber': 'dark_clay_glass',
    'solar_flare': 'dark_clay_glass',
    'obsidian_elite': 'dark_clay_glass',
    'forest_zen': 'dark_clay_glass',
    'cosmic_void': 'dark_clay_glass',
    'dark': 'dark_clay_glass',
    'light': 'white_clay_glass',
}


def resolve_theme_id(theme_id):
    """Normalize any theme_id to either 'white_clay_glass' or 'dark_clay_glass'."""
    if not theme_id:
        return 'white_clay_glass'
    if theme_id in THEMES:
        return theme_id
    if theme_id in LEGACY_THEME_FALLBACKS:
        return LEGACY_THEME_FALLBACKS[theme_id]
    if 'white' in str(theme_id).lower() or 'light' in str(theme_id).lower():
        return 'white_clay_glass'
    return 'dark_clay_glass'


def get_theme_css(theme_id):
    resolved_id = resolve_theme_id(theme_id)
    theme = THEMES[resolved_id]
    hexc = (theme.get('accent_primary') or '#38BDF8').lstrip('#')
    try:
        rgb = tuple(int(hexc[i:i+2], 16) for i in (0, 2, 4))
        accent_rgb = f"{rgb[0]}, {rgb[1]}, {rgb[2]}"
    except Exception:
        accent_rgb = "56, 189, 248"
    return f"""
:root {{
    --color-scheme: {theme.get('color_scheme', 'light')};
    --bg-primary: {theme['bg_primary']};
    --bg-secondary: {theme['bg_secondary']};
    --sidebar-bg: {theme.get('sidebar_bg', theme['bg_secondary'])};
    --topbar-bg: {theme.get('topbar_bg', theme['bg_primary'])};
    --accent-primary: {theme['accent_primary']};
    --accent-primary-rgb: {accent_rgb};
    --accent-secondary: {theme['accent_secondary']};
    --accent-warning: {theme['accent_warning']};
    --accent-success: {theme['accent_success']};
    --accent-danger: {theme.get('accent_danger', '#E36B73')};
    --text-primary: {theme['text_primary']};
    --text-secondary: {theme['text_secondary']};
    --text-muted: {theme.get('text_muted', theme['text_secondary'])};
    --card-bg: {theme['card_bg']};
    --card-bg-solid: {theme.get('card_bg_solid', theme['bg_secondary'])};
    --border-color: {theme['border']};
    --shadow: {theme['shadow']};
    --gradient: {theme['gradient']};
    --aurora: {theme['aurora']};
}}
"""
