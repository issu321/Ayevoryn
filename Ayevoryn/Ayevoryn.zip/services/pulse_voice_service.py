"""
Ayevoryn Human Neural Voice Agent Service (USMANIA TECHS PVT LTD)
8 curated, ultra-natural Google human Female (6) & Male (2) voices with sub-2s low-latency synthesis:
  Female Voices (6):
    - female_us     : Aria  (Female · Warm Executive)
    - female_bright : Nova  (Female · Bright & Expressive)
    - female_soft   : Luna  (Female · Soft & Friendly)
    - female_uk     : Clara (Female · British Natural)
    - female_velvet : Elena (Female · Calm & Smooth)
    - female_in     : Meera (Female · Indian English)
  Male Voices (2):
    - male_us       : Atlas (Male · Confident Advisor)
    - male_in       : Arjun (Male · Indian English)
"""
import base64
import logging
import os
import re
import struct
import time
import requests

logger = logging.getLogger('ayevoryn.voice')

GEMINI_TTS_MODEL = 'gemini-2.5-flash-preview-tts'
GEMINI_TTS_URL_TMPL = 'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent'
GOOGLE_TTS_ENDPOINT = 'https://texttospeech.googleapis.com/v1/text:synthesize'

_ENDPOINT_COOLDOWN = {}
_COOLDOWN_SECONDS = 600

VOICE_PROFILES = {
    'female_us': {
        'id': 'female_us',
        'label': 'Aria (Female · Warm Executive)',
        'language_code': 'en-US',
        'gemini_voice': 'Kore',
        'primary_voice': 'en-US-Chirp3-HD-Aoede',
        'fallback_voice': 'en-US-Neural2-F',
        'ssml_gender': 'FEMALE',
        'speaking_rate': 1.03,
        'pitch': 0.0,
    },
    'female_bright': {
        'id': 'female_bright',
        'label': 'Nova (Female · Bright & Expressive)',
        'language_code': 'en-US',
        'gemini_voice': 'Zephyr',
        'primary_voice': 'en-US-Chirp3-HD-Leda',
        'fallback_voice': 'en-US-Neural2-C',
        'ssml_gender': 'FEMALE',
        'speaking_rate': 1.05,
        'pitch': 0.5,
    },
    'female_soft': {
        'id': 'female_soft',
        'label': 'Luna (Female · Soft & Friendly)',
        'language_code': 'en-US',
        'gemini_voice': 'Leda',
        'primary_voice': 'en-US-Chirp3-HD-Callirrhoe',
        'fallback_voice': 'en-US-Neural2-E',
        'ssml_gender': 'FEMALE',
        'speaking_rate': 1.01,
        'pitch': 0.3,
    },
    'female_uk': {
        'id': 'female_uk',
        'label': 'Clara (Female · British Natural)',
        'language_code': 'en-GB',
        'gemini_voice': 'Autonoe',
        'primary_voice': 'en-GB-Chirp3-HD-Aoede',
        'fallback_voice': 'en-GB-Neural2-A',
        'ssml_gender': 'FEMALE',
        'speaking_rate': 1.02,
        'pitch': 0.0,
    },
    'female_velvet': {
        'id': 'female_velvet',
        'label': 'Elena (Female · Calm & Smooth)',
        'language_code': 'en-US',
        'gemini_voice': 'Despina',
        'primary_voice': 'en-US-Chirp3-HD-Despina',
        'fallback_voice': 'en-US-Neural2-G',
        'ssml_gender': 'FEMALE',
        'speaking_rate': 0.99,
        'pitch': -0.2,
    },
    'female_in': {
        'id': 'female_in',
        'label': 'Meera (Female · Indian English)',
        'language_code': 'en-IN',
        'gemini_voice': 'Aoede',
        'primary_voice': 'en-IN-Chirp3-HD-Aoede',
        'fallback_voice': 'en-IN-Neural2-A',
        'ssml_gender': 'FEMALE',
        'speaking_rate': 1.02,
        'pitch': 0.0,
    },
    'male_us': {
        'id': 'male_us',
        'label': 'Atlas (Male · Confident Advisor)',
        'language_code': 'en-US',
        'gemini_voice': 'Charon',
        'primary_voice': 'en-US-Chirp3-HD-Charon',
        'fallback_voice': 'en-US-Neural2-D',
        'ssml_gender': 'MALE',
        'speaking_rate': 1.01,
        'pitch': -0.5,
    },
    'male_in': {
        'id': 'male_in',
        'label': 'Arjun (Male · Indian English)',
        'language_code': 'en-IN',
        'gemini_voice': 'Orus',
        'primary_voice': 'en-IN-Chirp3-HD-Charon',
        'fallback_voice': 'en-IN-Neural2-B',
        'ssml_gender': 'MALE',
        'speaking_rate': 1.01,
        'pitch': -0.5,
    },
}


def _is_cooled_down(key: str) -> bool:
    return time.monotonic() < _ENDPOINT_COOLDOWN.get(key, 0.0)


def _mark_cooldown(key: str, seconds: int = _COOLDOWN_SECONDS) -> None:
    _ENDPOINT_COOLDOWN[key] = time.monotonic() + seconds


def pcm_l16_to_wav_bytes(pcm_bytes: bytes, sample_rate: int = 24000, channels: int = 1, bits_per_sample: int = 16) -> bytes:
    """Wrap raw 16-bit signed linear PCM bytes into a standard playable RIFF/WAV container."""
    data_size = len(pcm_bytes)
    byte_rate = sample_rate * channels * (bits_per_sample // 8)
    block_align = channels * (bits_per_sample // 8)
    header = struct.pack(
        '<4sI4s4sIHHIIHH4sI',
        b'RIFF',
        36 + data_size,
        b'WAVE',
        b'fmt ',
        16,
        1,
        channels,
        sample_rate,
        byte_rate,
        block_align,
        bits_per_sample,
        b'data',
        data_size,
    )
    return header + pcm_bytes


def clean_text_for_speech(text: str, max_chars: int = 420) -> str:
    """Convert Markdown AI responses into crisp, natural spoken prose optimized for fast TTS."""
    s = str(text or '').strip()
    if not s:
        return ''
    s = re.sub(r'!\[[^\]]*\]\([^)]+\)', ' ', s)
    s = re.sub(r'\[([^\]]+)\]\([^)]+\)', r'\1', s)
    s = re.sub(r'```[\s\S]*?```', ' ', s)
    s = re.sub(r'^\|?[\s:\-|]+\|?$', ' ', s, flags=re.M)
    s = s.replace('|', ', ')
    s = re.sub(r'[#*`_~>]', '', s)
    s = re.sub(r'\s+', ' ', s).strip()
    if len(s) > max_chars:
        cut = s[:max_chars]
        last_dot = max(cut.rfind('. '), cut.rfind('! '), cut.rfind('? '))
        s = cut[:last_dot + 1] if last_dot > 60 else cut
    return s


def _get_gemini_api_key() -> str:
    for env_var in ('GEMINI_API_KEY', 'GOOGLE_API_KEY'):
        val = (os.environ.get(env_var) or '').strip()
        if val:
            return val
    try:
        from services.superadmin_service import SuperadminService
        val = (SuperadminService.get_setting('ai_gemini_api_key') or '').strip()
        if val:
            return val
    except Exception:
        pass
    return ''


def _get_google_tts_api_key() -> str:
    val = (os.environ.get('GOOGLE_TTS_API_KEY') or '').strip()
    if val:
        return val
    try:
        from services.superadmin_service import SuperadminService
        val = (SuperadminService.get_setting('ai_google_tts_api_key') or '').strip()
        if val:
            return val
    except Exception:
        pass
    return ''


def _try_google_cloud_tts(spoken: str, profile: dict) -> dict:
    """Fastest path (~350-600ms MP3): Google Cloud Text-to-Speech Chirp 3 HD / Neural2."""
    api_key = _get_google_tts_api_key() or _get_gemini_api_key()
    if not api_key or _is_cooled_down('google_cloud_tts'):
        return {}

    for candidate_voice in (profile['primary_voice'], profile['fallback_voice']):
        cache_key = f'cloud_tts:{candidate_voice}'
        if _is_cooled_down(cache_key):
            continue
        payload = {
            'input': {'text': spoken},
            'voice': {
                'languageCode': profile['language_code'],
                'name': candidate_voice,
                'ssmlGender': profile['ssml_gender'],
            },
            'audioConfig': {
                'audioEncoding': 'MP3',
                'speakingRate': profile['speaking_rate'],
                'pitch': profile['pitch'],
                'effectsProfileId': ['headphone-class-device'],
            },
        }
        try:
            resp = requests.post(
                GOOGLE_TTS_ENDPOINT,
                params={'key': api_key},
                json=payload,
                timeout=4.5,
            )
            if resp.status_code == 200:
                audio_b64 = (resp.json() or {}).get('audioContent')
                if audio_b64:
                    return {
                        'success': True,
                        'audio_base64': audio_b64,
                        'mime_type': 'audio/mpeg',
                        'voice_id': profile['id'],
                        'voice_label': profile['label'],
                    }
            elif resp.status_code in (401, 403):
                _mark_cooldown('google_cloud_tts', 1800)
                return {}
            elif resp.status_code == 400:
                _mark_cooldown(cache_key, 900)
        except Exception as exc:
            logger.debug('Google Cloud TTS (%s) fast fallback: %s', candidate_voice, exc)
            _mark_cooldown(cache_key, 300)
    return {}


def _try_gemini_native_tts(spoken: str, profile: dict) -> dict:
    """Google Gemini Native Human TTS (24kHz PCM -> WAV) with tight low-latency timeout."""
    api_key = _get_gemini_api_key()
    if not api_key or _is_cooled_down('gemini_tts'):
        return {}

    payload = {
        'contents': [{'parts': [{'text': spoken}]}],
        'generationConfig': {
            'responseModalities': ['AUDIO'],
            'speechConfig': {
                'voiceConfig': {
                    'prebuiltVoiceConfig': {'voiceName': profile['gemini_voice']}
                }
            },
        },
    }

    try:
        resp = requests.post(
            GEMINI_TTS_URL_TMPL.format(model=GEMINI_TTS_MODEL),
            headers={'Content-Type': 'application/json', 'x-goog-api-key': api_key},
            json=payload,
            timeout=8.5,
        )
        if resp.status_code != 200:
            if resp.status_code in (400, 401, 403, 404):
                _mark_cooldown('gemini_tts', 600)
            return {}
        body = resp.json()
        candidates = body.get('candidates') or []
        for cand in candidates:
            parts = (cand.get('content') or {}).get('parts') or []
            for part in parts:
                inline = part.get('inlineData') or {}
                b64_data = inline.get('data')
                mime = (inline.get('mimeType') or '').lower()
                if not b64_data:
                    continue
                raw_bytes = base64.b64decode(b64_data)
                if 'pcm' in mime or 'l16' in mime or not mime.startswith('audio/wav'):
                    rate_match = re.search(r'rate=(\d+)', mime)
                    rate = int(rate_match.group(1)) if rate_match else 24000
                    wav_bytes = pcm_l16_to_wav_bytes(raw_bytes, sample_rate=rate)
                    return {
                        'success': True,
                        'audio_base64': base64.b64encode(wav_bytes).decode('ascii'),
                        'mime_type': 'audio/wav',
                        'voice_id': profile['id'],
                        'voice_label': profile['label'],
                    }
                return {
                    'success': True,
                    'audio_base64': b64_data,
                    'mime_type': inline.get('mimeType') or 'audio/wav',
                    'voice_id': profile['id'],
                    'voice_label': profile['label'],
                }
    except Exception as exc:
        logger.debug('Gemini TTS fast fallback: %s', exc)
        _mark_cooldown('gemini_tts', 120)
    return {}


def synthesize_human_voice(text: str, voice_id: str = 'female_us') -> dict:
    """Synthesize realistic human Female/Male speech audio across 8 curated Google voices."""
    spoken = clean_text_for_speech(text)
    if not spoken:
        return {'success': False, 'fallback': 'browser_google_voice', 'reason': 'Empty text'}

    profile = VOICE_PROFILES.get(voice_id) or VOICE_PROFILES['female_us']

    cloud_res = _try_google_cloud_tts(spoken, profile)
    if cloud_res.get('success'):
        return cloud_res

    gem_res = _try_gemini_native_tts(spoken, profile)
    if gem_res.get('success'):
        return gem_res

    return {
        'success': False,
        'fallback': 'browser_google_voice',
        'reason': 'Using natural browser Google/Neural voice.',
        'voice_id': profile['id'],
        'voice_label': profile['label'],
    }
