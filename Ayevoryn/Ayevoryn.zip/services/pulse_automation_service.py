import re
import json
"""
AEVORYN PULSE AI — COMPLETE AUTONOMOUS AUTOMATION & BACKGROUND SCHEDULER SERVICE
Supports ANY recurring AI agent workflow via APScheduler:
  - `custom_agent_prompt`: Wakes up the full NVIDIA NIM multi-hop Pulse AI Agent on schedule to execute ANY prompt/workflow using all 25+ live tools!
  - `generate_report`: Automatically generates real PDF/Excel reports into Report Center.
  - `risk_scan`: Automatically runs multi-domain Decision Intelligence & Risk Scans.
  - `ai_briefing`: Automatically compiles an executive strategic briefing.
Every completed automated run logs its result and creates a real in-app Notification in the user's topbar bell.
"""

import os
import threading
import time
from datetime import datetime, timedelta
from database.db import db
from database.models.company import Company
from database.models.notification import Notification
from database.models.pulse_automation import PulseAutomation, PulseAutomationRun
from config.constants import CURRENCY_SYMBOLS

_SCHEDULER = None
_WORKER_THREAD = None
_RUN_LOCK = threading.Lock()


class PulseAutomationService:

    VALID_REPORT_TYPES = {
        'executive', 'financial', 'board', 'investor', 'risk',
        'growth', 'forecast', 'operational', 'department'
    }
    VALID_TASK_TYPES = {'generate_report', 'risk_scan', 'ai_briefing', 'custom_agent_prompt', 'kpi_monitor'}

    PRESET_AUTONOMOUS_MONITORS = [
        {
            'key': 'cash_margin_watchdog',
            'name': '24/7 Cash & Margin Anomaly Watchdog',
            'task_type': 'kpi_monitor',
            'interval_hours': 6,
            'description': 'Continuously monitors cash balances, operating margins, and expense spikes every 6 hours.',
            'prompt': 'Run live KPI anomaly sweep for treasury balances, cash flow, and margin compression.'
        },
        {
            'key': 'inventory_stockout_guard',
            'name': 'Daily Inventory Stockout Monitor',
            'task_type': 'kpi_monitor',
            'interval_hours': 24,
            'description': 'Flags low-stock and out-of-stock SKUs daily and alerts operations automatically.',
            'prompt': 'Monitor warehouse SKUs against reorder levels and alert on stockout risks.'
        },
        {
            'key': 'continuous_risk_scanner',
            'name': 'Continuous Critical Risk Scanner',
            'task_type': 'risk_scan',
            'interval_hours': 12,
            'description': 'Runs multi-domain Decision Intelligence and Enterprise Risk Scans twice daily.',
            'prompt': 'Scan all departments and dependencies for critical and high severity risks.'
        },
        {
            'key': 'weekly_csuite_briefing',
            'name': 'Weekly Executive PDF Briefing',
            'task_type': 'generate_report',
            'report_type': 'executive',
            'format_type': 'pdf',
            'interval_days': 7,
            'description': 'Automatically compiles and delivers a complete C-Suite Executive PDF report every 7 days.',
            'prompt': 'Generate weekly executive PDF report covering financials, risks, and KPIs.'
        }
    ]

    @staticmethod
    def _create_notification(company_id: int, user_id: int, title: str, message: str, link: str = '/pulse-ai/'):
        try:
            db.session.add(Notification(
                company_id=int(company_id),
                user_id=int(user_id or 1),
                title=title[:200],
                message=message[:1000],
                notification_type='info',
                module='pulse_ai',
                action_link=link,
                action_text='Open Pulse AI'
            ))
        except Exception:
            pass

    @staticmethod
    def create_automation(
        company_id: int,
        user_id: int,
        name: str,
        task_type: str = 'custom_agent_prompt',
        interval_days: float = None,
        interval_hours: float = None,
        interval_minutes: float = None,
        interval_seconds: float = None,
        report_type: str = 'executive',
        format_type: str = 'pdf',
        prompt: str = '',
        run_immediately: bool = False
    ) -> dict:
        clean_task = (task_type or 'custom_agent_prompt').strip().lower()
        if clean_task not in PulseAutomationService.VALID_TASK_TYPES:
            clean_task = 'custom_agent_prompt' if (prompt or '').strip() else 'generate_report'

        clean_rep = (report_type or 'executive').strip().lower()
        if clean_rep not in PulseAutomationService.VALID_REPORT_TYPES:
            clean_rep = 'executive'

        clean_fmt = (format_type or 'pdf').strip().lower()
        if clean_fmt not in ('pdf', 'excel'):
            clean_fmt = 'pdf'

        min_days = 5.0 / 86400.0  # Support down to 5 seconds!
        try:
            if interval_seconds is not None and float(interval_seconds) > 0:
                days = max(min_days, float(interval_seconds) / 86400.0)
            elif interval_minutes is not None and float(interval_minutes) > 0:
                days = max(min_days, float(interval_minutes) / 1440.0)
            elif interval_hours is not None and float(interval_hours) > 0:
                days = max(min_days, float(interval_hours) / 24.0)
            else:
                days = max(min_days, float(interval_days or 3.0))
        except (TypeError, ValueError):
            days = 3.0

        now = datetime.utcnow()
        total_secs = days * 86400.0
        if total_secs < 60:
            freq_label = f"{round(total_secs):g} sec(s)"
        elif total_secs < 3600:
            freq_label = f"{round(total_secs / 60.0, 1):g} min(s)"
        elif days < 1:
            freq_label = f"{round(days * 24.0, 1):g} hour(s)"
        else:
            freq_label = f"{round(days, 2):g} day(s)"
        auto = PulseAutomation(
            company_id=int(company_id),
            user_id=int(user_id or 1),
            name=(name or f"Pulse Automation ({clean_task.replace('_', ' ').title()})").strip()[:200],
            task_type=clean_task,
            report_type=clean_rep,
            format_type=clean_fmt,
            prompt=(prompt or '').strip(),
            interval_days=days,
            is_active=True,
            run_count=0,
            next_run_at=now + timedelta(days=days),
            last_status='scheduled',
            last_result_summary=f"Scheduled to run automatically every {freq_label}."
        )
        db.session.add(auto)
        db.session.commit()

        if run_immediately:
            return PulseAutomationService.run_automation_now(auto.id, company_id)

        return {'success': True, 'automation': auto.to_dict()}

    @staticmethod
    def _ensure_runs_table():
        try:
            PulseAutomationRun.__table__.create(db.engine, checkfirst=True)
        except Exception:
            pass


    _CHARTS_MARKER_RE = re.compile(r'\n?<!--AYV_CHARTS_JSON:(.*?)-->\s*$', re.S)

    @staticmethod
    def _build_automation_live_charts(company_id: int, prompt: str, report_type: str, sym: str) -> list:
        """Build 100% live-DB structured chart payloads (line, donut/pie, bar) for automation run outputs."""
        import json as _json
        from sqlalchemy import func
        from database.models.financial import FinancialRecord
        from database.models.department import Department
        from database.models.department_budget import DepartmentBudget
        from database.models.inventory import Inventory
        from database.models.risk import Risk
        from database.models.forecast import Forecast

        blob = f"{prompt or ''} {report_type or ''}".lower()
        want_forecast = any(k in blob for k in ('forecast', 'predict', 'projection', '30d', '60d', '90d', 'runway'))
        want_line = want_forecast or any(k in blob for k in ('line', 'trend', 'revenue', 'expense', 'cashflow', 'financial', 'executive', 'chart', 'graph', 'margin'))
        want_pie = any(k in blob for k in ('pie', 'donut', 'utilization', 'department', 'budget', 'executive', 'inventory', 'risk', 'chart', 'graph', 'breakdown', 'share'))
        want_bar = any(k in blob for k in ('bar', 'utilization', 'department', 'budget', 'compare', 'executive'))

        # Always include at least live financial trend + department utilization when charts/forecasts/briefings run
        if not (want_line or want_pie or want_bar):
            want_line = True
            want_pie = True

        charts = []
        cid = int(company_id)

        try:
            if want_forecast:
                fc = Forecast.query.filter_by(company_id=cid).order_by(Forecast.id.desc()).first()
                fc_labels, fc_vals = [], []
                if fc and getattr(fc, 'predictions', None):
                    try:
                        pts = _json.loads(fc.predictions) if isinstance(fc.predictions, str) else fc.predictions
                        if isinstance(pts, list):
                            for idx, pt in enumerate(pts[:14]):
                                lbl = str(pt.get('date') or pt.get('period') or f'Day {idx+1}')[-10:]
                                val = float(pt.get('predicted', pt.get('yhat', pt.get('value', 0))) or 0.0)
                                fc_labels.append(lbl)
                                fc_vals.append(round(val, 2))
                    except Exception:
                        pass
                if fc_labels and fc_vals:
                    charts.append({
                        'chart_type': 'line',
                        'title': f"Live Forecast Trajectory: {fc.name or 'Revenue Forecast'} ({sym})",
                        'labels': fc_labels,
                        'series': [{'name': f'Projected ({sym})', 'values': fc_vals, 'color': '#0EA5E9'}],
                    })

            if want_line:
                recs = FinancialRecord.query.filter_by(company_id=cid).order_by(FinancialRecord.transaction_date.asc()).all()
                buckets = {}
                for r in recs:
                    if not r.transaction_date:
                        continue
                    ym = r.transaction_date.strftime('%Y-%m')
                    b = buckets.setdefault(ym, {'rev': 0.0, 'exp': 0.0})
                    tl = (r.transaction_type or '').lower()
                    if tl in ('revenue', 'income', 'deposit'):
                        b['rev'] += float(r.amount or 0.0)
                    elif tl in ('expense', 'payroll', 'withdrawal', 'transfer_out'):
                        b['exp'] += float(r.amount or 0.0)
                if buckets:
                    keys = sorted(buckets.keys())[-12:]
                    charts.append({
                        'chart_type': 'line',
                        'title': f'Live Revenue vs Operating Expenses ({sym})',
                        'labels': keys,
                        'series': [
                            {'name': f'Revenue ({sym})', 'values': [round(buckets[k]['rev'], 2) for k in keys], 'color': '#0EA5E9'},
                            {'name': f'Expenses ({sym})', 'values': [round(buckets[k]['exp'], 2) for k in keys], 'color': '#10B981'},
                        ],
                    })

            # Live department spend aggregation
            dept_exp_rows = (
                db.session.query(
                    FinancialRecord.department_id,
                    func.coalesce(func.sum(FinancialRecord.amount), 0.0).label('spent'),
                )
                .filter(
                    FinancialRecord.company_id == cid,
                    FinancialRecord.transaction_type.in_(['expense', 'payroll', 'withdrawal', 'transfer_out']),
                )
                .group_by(FinancialRecord.department_id)
                .all()
            )
            live_spend = {r.department_id: float(r.spent or 0.0) for r in dept_exp_rows}
            active_budgets = {
                b.department_id: float(b.allocated_amount)
                for b in DepartmentBudget.query.filter_by(company_id=cid, status='active').all()
                if b.allocated_amount is not None
            }
            depts = Department.query.filter_by(company_id=cid, is_active=True).order_by(Department.name.asc()).all()

            if want_pie:
                if 'inventory' in blob or 'stock' in blob or 'sku' in blob:
                    inv_cats = {}
                    for it in Inventory.query.filter_by(company_id=cid).all():
                        cat = it.category or 'General'
                        inv_cats[cat] = inv_cats.get(cat, 0.0) + (int(it.quantity_on_hand or 0) * float(it.unit_cost or 0.0))
                    if inv_cats:
                        charts.append({'chart_type': 'donut', 'title': f'Live Inventory Valuation by Category ({sym})', 'labels': list(inv_cats.keys()), 'values': [round(v, 2) for v in inv_cats.values()]})
                elif 'risk' in blob and 'department' not in blob and 'utilization' not in blob:
                    rc = {}
                    for rk in Risk.query.filter_by(company_id=cid).all():
                        if (rk.status or 'active').lower() in ('resolved', 'closed'):
                            continue
                        lv = (rk.risk_level or 'medium').title()
                        rc[lv] = rc.get(lv, 0) + 1
                    if rc:
                        charts.append({'chart_type': 'donut', 'title': 'Live Active Risk Severity Breakdown', 'labels': list(rc.keys()), 'values': list(rc.values())})
                elif depts:
                    dl, dv = [], []
                    for d in depts:
                        sp = float(live_spend.get(d.id, 0.0))
                        al = float(active_budgets.get(d.id, d.budget or 0.0) or 0.0)
                        val = sp if sp > 0 else al
                        if val > 0:
                            dl.append(d.name)
                            dv.append(round(val, 2))
                    if dl:
                        lbl = 'Live Departmental Spend Share' if any(live_spend.get(d.id, 0.0) > 0 for d in depts) else 'Departmental Budget Share'
                        charts.append({'chart_type': 'donut', 'title': f'{lbl} ({sym})', 'labels': dl, 'values': dv})

            if want_bar and depts:
                charts.append({
                    'chart_type': 'bar',
                    'title': f'Departmental Budget vs Live Spend ({sym})',
                    'labels': [d.name for d in depts],
                    'series': [
                        {'name': 'Allocated', 'values': [round(float(active_budgets.get(d.id, d.budget or 0.0) or 0.0), 2) for d in depts], 'color': '#0EA5E9'},
                        {'name': 'Live Spent', 'values': [round(float(live_spend.get(d.id, 0.0)), 2) for d in depts], 'color': '#EF4444'},
                    ],
                })
        except Exception as e:
            logger.warning(f"Automation live chart build warning: {e}")
        return charts[:4]

    @staticmethod
    def list_automation_runs(automation_id: int, company_id: int, limit: int = 50) -> list:
        PulseAutomationService._ensure_runs_table()
        rows = PulseAutomationRun.query.filter_by(
            automation_id=int(automation_id),
            company_id=int(company_id)
        ).order_by(PulseAutomationRun.run_number.desc(), PulseAutomationRun.id.desc()).limit(limit).all()
        out = []
        for r in rows:
            d = r.to_dict()
            md = d.get('output_markdown') or ''
            charts = []
            m = PulseAutomationService._CHARTS_MARKER_RE.search(md)
            if m:
                try:
                    charts = json.loads(m.group(1))
                except Exception:
                    charts = []
                d['output_markdown'] = md[:m.start()].rstrip()
            d['charts'] = charts
            out.append(d)
        return out

    @staticmethod
    def _record_run(auto, status: str, output_md: str, started_ts: float, download_url: str = None, charts: list = None):
        PulseAutomationService._ensure_runs_table()
        try:
            dur = max(1, int((time.monotonic() - started_ts) * 1000))
            db.session.add(PulseAutomationRun(
                automation_id=auto.id,
                company_id=auto.company_id,
                run_number=int(auto.run_count or 1),
                status=status,
                duration_ms=dur,
                output_markdown=((output_md or '')[:11500] + (f"\n<!--AYV_CHARTS_JSON:{json.dumps(charts)}-->" if charts else ''))[:15000],
                download_url=download_url,
                executed_at=auto.last_run_at or datetime.utcnow(),
            ))
        except Exception:
            pass

    @staticmethod
    def list_automations(company_id: int) -> list:
        rows = PulseAutomation.query.filter_by(company_id=int(company_id)).order_by(
            PulseAutomation.is_active.desc(), PulseAutomation.created_at.desc()
        ).all()
        return [r.to_dict() for r in rows]

    @staticmethod
    def run_automation_now(automation_id: int, company_id: int) -> dict:
        auto = PulseAutomation.query.filter_by(id=int(automation_id), company_id=int(company_id)).first()
        if not auto:
            return {'success': False, 'error': 'Automation not found'}

        try:
            db.session.expire_all()
        except Exception:
            pass
        now = datetime.utcnow()
        started_ts = time.monotonic()
        company = db.session.get(Company, int(company_id))
        sym = CURRENCY_SYMBOLS.get((company.currency if company else 'USD') or 'USD', '$')

        try:
            if auto.task_type == 'custom_agent_prompt':
                from services.pulse_ai_engine import PulseAIEngine
                agent_prompt = (auto.prompt or auto.name or 'Run a comprehensive company health and anomaly check.').strip()
                res = PulseAIEngine.process_conversation_turn(
                    company_id=auto.company_id,
                    user_id=auto.user_id,
                    prompt=(
                        f"[AUTOMATED REAL-TIME AGENT RUN: {auto.name}] {agent_prompt} "
                        "(Use live company DB data via run_python_data_analysis / live tools; "
                        "if charts are requested, save crisp 200-DPI PNG chart(s) via save_chart() and include them inline.)"
                    ),
                    require_confirmation_for_mutations=False
                )
                next_num = (auto.run_count or 0) + 1
                raw_md = (res.get('markdown') or res.get('explanation') or 'Autonomous workflow completed.').strip()
                summary_txt = f"#### Automated Run #{next_num} — {now.strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n{raw_md}"[:12000]
                auto.last_status = 'success' if res.get('success') else 'error'
                auto.last_result_summary = summary_txt
                PulseAutomationService._create_notification(
                    auto.company_id, auto.user_id,
                    f"Pulse Automation Ran: {auto.name}",
                    summary_txt[:300],
                    '/pulse-ai/'
                )
            elif auto.task_type == 'generate_report':
                from services.report_service import ReportService
                report_name = f"{auto.name} — {now.strftime('%Y-%m-%d %H:%M UTC')}"
                report = ReportService.generate_report(
                    company_id=auto.company_id,
                    user_id=auto.user_id,
                    report_type=auto.report_type or 'executive',
                    name=report_name,
                    format_type=auto.format_type or 'pdf',
                    currency_symbol=sym
                )
                auto.last_report_id = getattr(report, 'id', None)
                auto.last_status = 'success'
                auto.last_result_summary = f"Generated {auto.report_type} ({auto.format_type.upper()}) report #{auto.last_report_id}."
                PulseAutomationService._create_notification(
                    auto.company_id, auto.user_id,
                    f"Automated Report Ready: {auto.name}",
                    auto.last_result_summary,
                    f"/reports/download/{auto.last_report_id}" if auto.last_report_id else "/reports/"
                )
            elif auto.task_type == 'kpi_monitor':
                sweep = PulseAutomationService.run_live_monitor_sweep(
                    company_id=auto.company_id,
                    user_id=auto.user_id,
                    create_notifications=True
                )
                status_lbl = sweep.get('status', 'HEALTHY')
                anom_cnt = len(sweep.get('anomalies') or [])
                auto.last_status = 'success'
                m = sweep.get('metrics') or {}
                anom_lines = "\n".join(f"- **[{a['domain']} · {a['severity'].upper()}] {a['title']}**: {a['detail']}" for a in (sweep.get('anomalies') or [])) or "- All monitored KPIs are healthy. Zero critical anomalies."
                metric_lines = "\n".join(f"- **{k.replace('_', ' ').title()}**: {v}" for k, v in m.items())
                auto.last_result_summary = (
                    f"### Autonomous Watchdog Sweep [{status_lbl}] — Health {sweep.get('health_score', 100)}/100\n"
                    f"**Checked:** {sweep.get('checked_at')}\n\n#### Live Telemetry\n{metric_lines}\n\n#### Anomaly Findings ({anom_cnt})\n{anom_lines}"
                )[:12000]
            elif auto.task_type == 'risk_scan':
                from services.decision_intelligence_service import DecisionIntelligenceService
                res = DecisionIntelligenceService.run_decision_scan(
                    company_id=auto.company_id,
                    actor_user_id=auto.user_id,
                    publish_events=True
                )
                total = res.get('total_insights', 0) if isinstance(res, dict) else 0
                auto.last_status = 'success'
                auto.last_result_summary = f"Completed decision & risk scan: {total} verified insight(s) evaluated."
                PulseAutomationService._create_notification(
                    auto.company_id, auto.user_id,
                    f"Automated Risk Scan Complete: {auto.name}",
                    auto.last_result_summary,
                    '/ai-insights/'
                )
            else:
                from services.analytics_service import AnalyticsService
                from services.risk_service import RiskService
                from services.decision_intelligence_service import DecisionIntelligenceService
                from services.pulse_ai_engine import PulseAIProviderManager
                summary = AnalyticsService.get_executive_summary(auto.company_id)
                risk_summary = RiskService.get_risk_summary(auto.company_id)
                ins = [i.to_dict() for i in DecisionIntelligenceService.get_insights(company_id=auto.company_id)]
                brief = PulseAIProviderManager.generate_ai_insights_brief(
                    company_name=company.company_name if company else 'Organization',
                    summary=summary,
                    risk_summary=risk_summary,
                    insights_dicts=ins,
                    currency_symbol=sym
                )
                auto.last_status = 'success'
                auto.last_result_summary = (brief.get('markdown') or 'Executive briefing generated.')[:500]
                PulseAutomationService._create_notification(
                    auto.company_id, auto.user_id,
                    f"Automated Executive Briefing: {auto.name}",
                    auto.last_result_summary[:300],
                    '/pulse-ai/'
                )

            auto.run_count = (auto.run_count or 0) + 1
            auto.last_run_at = now
            auto.next_run_at = now + timedelta(days=float(auto.interval_days or 3.0))
            dl_url = f'/reports/download/{auto.last_report_id}' if auto.last_report_id else (res.get('download_url') if auto.task_type == 'custom_agent_prompt' and isinstance(locals().get('res'), dict) else None)
            live_charts = PulseAutomationService._build_automation_live_charts(auto.company_id, auto.prompt or auto.name, auto.report_type or '', sym)
            PulseAutomationService._record_run(auto, auto.last_status or 'success', auto.last_result_summary or '', started_ts, download_url=dl_url, charts=live_charts)
            db.session.commit()
            return {'success': True, 'automation': auto.to_dict()}
        except Exception as ex:
            auto.run_count = (auto.run_count or 0) + 1
            auto.last_status = 'error'
            auto.last_result_summary = f"Error: {str(ex)[:500]}"
            auto.last_run_at = now
            auto.next_run_at = now + timedelta(days=float(auto.interval_days or 3.0))
            PulseAutomationService._record_run(auto, 'error', auto.last_result_summary, started_ts)
            db.session.commit()
            return {'success': False, 'error': str(ex), 'automation': auto.to_dict()}

    @staticmethod
    def run_live_monitor_sweep(company_id: int, user_id: int = None, create_notifications: bool = False) -> dict:
        """Real-time autonomous business watchdog scanning Financials, Treasury, Inventory, and Risks."""
        cid = int(company_id)
        company = db.session.get(Company, cid)
        sym = CURRENCY_SYMBOLS.get((company.currency if company else 'USD') or 'USD', '$')
        anomalies = []
        metrics = {}

        # 1. Financials & Margin Anomaly Check
        try:
            from services.analytics_service import AnalyticsService
            summary = AnalyticsService.get_executive_summary(cid) or {}
            rev = float(summary.get('total_revenue') or summary.get('revenue') or 0.0)
            exp = float(summary.get('total_expenses') or summary.get('expenses') or 0.0)
            profit = rev - exp
            margin = (profit / rev * 100.0) if rev > 0 else 0.0
            metrics['revenue'] = f"{sym}{rev:,.0f}"
            metrics['expenses'] = f"{sym}{exp:,.0f}"
            metrics['net_margin'] = f"{margin:.1f}%"
            if rev > 0 and profit < 0:
                anomalies.append({
                    'domain': 'Financials',
                    'severity': 'critical',
                    'title': 'Negative Net Operating Profit Detected',
                    'detail': f"Expenses ({sym}{exp:,.0f}) exceed Revenue ({sym}{rev:,.0f}) with net margin {margin:.1f}%.",
                    'recommended_prompt': 'Audit our top expense categories and propose a 15% cost-reduction plan.'
                })
            elif rev > 0 and margin < 12.0:
                anomalies.append({
                    'domain': 'Financials',
                    'severity': 'warning',
                    'title': 'Operating Margin Compression',
                    'detail': f"Current net margin is {margin:.1f}% (below 12% healthy threshold).",
                    'recommended_prompt': 'Simulate how a 10% expense optimization impacts our operating margin.'
                })
        except Exception:
            pass

        # 2. Treasury & Cash Liquidity Check
        try:
            from database.models.financial import FinancialAccount
            accts = FinancialAccount.query.filter_by(company_id=cid).all()
            total_cash = sum(float(getattr(a, 'current_balance', 0) or 0) for a in accts)
            metrics['liquid_cash'] = f"{sym}{total_cash:,.0f}"
            if accts and total_cash <= 0:
                anomalies.append({
                    'domain': 'Treasury',
                    'severity': 'critical',
                    'title': 'Zero or Negative Liquid Treasury Balance',
                    'detail': f"Total balance across {len(accts)} bank account(s) is {sym}{total_cash:,.0f}.",
                    'recommended_prompt': 'Show all bank accounts and urgent cash-flow actions.'
                })
        except Exception:
            pass

        # 3. Inventory Stockout Watchdog
        try:
            from database.models.inventory import Inventory
            items = Inventory.query.filter_by(company_id=cid).all()
            low_items = [
                it for it in items
                if float(getattr(it, 'quantity_on_hand', 0) or 0) <= float(getattr(it, 'reorder_point', 10) or 10)
            ]
            metrics['total_skus'] = len(items)
            metrics['low_stock_skus'] = len(low_items)
            if low_items:
                sample_names = ', '.join(getattr(x, 'name', 'SKU') for x in low_items[:3])
                anomalies.append({
                    'domain': 'Inventory',
                    'severity': 'high' if len(low_items) >= 3 else 'warning',
                    'title': f"{len(low_items)} SKU(s) Below Reorder Threshold",
                    'detail': f"Immediate restock attention needed for: {sample_names}.",
                    'recommended_prompt': 'List all low-stock inventory items and recommend reorder quantities.'
                })
        except Exception:
            pass

        # 4. Enterprise Risk Watchdog
        try:
            from database.models.risk import Risk
            open_risks = Risk.query.filter_by(company_id=cid).filter(
                Risk.status != 'resolved'
            ).all()
            crit_risks = [r for r in open_risks if str(getattr(r, 'risk_level', '')).lower() in ('critical', 'high')]
            metrics['open_risks'] = len(open_risks)
            metrics['critical_high_risks'] = len(crit_risks)
            if crit_risks:
                top_r = getattr(crit_risks[0], 'name', 'Critical Risk')
                anomalies.append({
                    'domain': 'Risk Engine',
                    'severity': 'critical' if any(str(getattr(r, 'risk_level', '')).lower() == 'critical' for r in crit_risks) else 'high',
                    'title': f"{len(crit_risks)} High/Critical Open Risk(s)",
                    'detail': f"Top unresolved exposure: {top_r}.",
                    'recommended_prompt': 'Show our critical enterprise risks and generate a mitigation plan.'
                })
        except Exception:
            pass

        # Compute Autonomous Health Score
        penalty = 0
        for a in anomalies:
            if a['severity'] == 'critical':
                penalty += 22
            elif a['severity'] == 'high':
                penalty += 14
            else:
                penalty += 8
        health_score = max(15, 100 - penalty)
        status = 'CRITICAL' if any(a['severity'] == 'critical' for a in anomalies) else ('ATTENTION' if anomalies else 'HEALTHY')

        if create_notifications and anomalies and user_id:
            top = anomalies[0]
            PulseAutomationService._create_notification(
                cid, int(user_id),
                f"Autonomous Watchdog Alert: {top['title']}",
                f"{top['detail']} ({len(anomalies)} total alert(s) found during autonomous sweep).",
                '/pulse-ai/'
            )
            try:
                db.session.commit()
            except Exception:
                db.session.rollback()

        active_monitors = PulseAutomationService.list_automations(cid)
        return {
            'success': True,
            'checked_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC'),
            'status': status,
            'health_score': health_score,
            'metrics': metrics,
            'anomalies': anomalies,
            'active_monitors': active_monitors,
            'presets': PulseAutomationService.PRESET_AUTONOMOUS_MONITORS,
        }

    @staticmethod
    def activate_preset_monitor(company_id: int, user_id: int, preset_key: str) -> dict:
        preset = next((p for p in PulseAutomationService.PRESET_AUTONOMOUS_MONITORS if p['key'] == preset_key), None)
        if not preset:
            return {'success': False, 'error': 'Unknown monitor preset'}
        return PulseAutomationService.create_automation(
            company_id=company_id,
            user_id=user_id,
            name=preset['name'],
            task_type=preset['task_type'],
            interval_days=preset.get('interval_days'),
            interval_hours=preset.get('interval_hours'),
            report_type=preset.get('report_type', 'executive'),
            format_type=preset.get('format_type', 'pdf'),
            prompt=preset.get('prompt', ''),
            run_immediately=True,
        )

    @staticmethod
    def toggle_automation(automation_id: int, company_id: int) -> dict:
        auto = PulseAutomation.query.filter_by(id=int(automation_id), company_id=int(company_id)).first()
        if not auto:
            return {'success': False, 'error': 'Automation not found'}
        auto.is_active = not bool(auto.is_active)
        if auto.is_active and (not auto.next_run_at or auto.next_run_at < datetime.utcnow()):
            auto.next_run_at = datetime.utcnow() + timedelta(days=float(auto.interval_days or 3.0))
        db.session.commit()
        return {'success': True, 'automation': auto.to_dict()}

    @staticmethod
    def delete_automation(automation_id: int, company_id: int) -> dict:
        auto = PulseAutomation.query.filter_by(id=int(automation_id), company_id=int(company_id)).first()
        if not auto:
            return {'success': False, 'error': 'Automation not found'}
        try:
            PulseAutomationService._ensure_runs_table()
            PulseAutomationRun.query.filter_by(automation_id=auto.id, company_id=int(company_id)).delete()
        except Exception:
            pass
        db.session.delete(auto)
        db.session.commit()
        return {'success': True}

    @staticmethod
    def run_due_automations(app):
        """Background tick executed every 3 seconds to fire all due automations cleanly."""
        if not _RUN_LOCK.acquire(blocking=False):
            return
        try:
            with app.app_context():
                try:
                    now = datetime.utcnow()
                    due = PulseAutomation.query.filter(
                        PulseAutomation.is_active == True,  # noqa: E712
                        PulseAutomation.next_run_at <= now
                    ).all()
                    for auto in due:
                        PulseAutomationService.run_automation_now(auto.id, auto.company_id)
                except Exception:
                    db.session.rollback()
        finally:
            _RUN_LOCK.release()

    @staticmethod
    def start_automation_scheduler(app):
        """Start reliable 3-second background automation daemon once per Flask process."""
        global _SCHEDULER, _WORKER_THREAD
        if app.config.get('TESTING'):
            return
        if _WORKER_THREAD is not None and _WORKER_THREAD.is_alive():
            return

        def _loop():
            while True:
                time.sleep(3)
                try:
                    PulseAutomationService.run_due_automations(app)
                except Exception:
                    pass

        t = threading.Thread(target=_loop, name='ayevoryn-pulse-automations', daemon=True)
        t.start()
        _WORKER_THREAD = t
        _SCHEDULER = t
