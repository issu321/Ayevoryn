"""
Ayevoryn Pulse AI File, Image & Video Attachment Analyzer (USMANIA TECHS PVT LTD)
Safely parses user-attached Excel (.xlsx), CSV, PDF, JSON, TXT, Markdown, Image, and Video files server-side.
- Tabular & text files (.xlsx, .csv, .pdf, .json, .txt, .md, .log) are parsed locally without touching AISA.
- Image (.png, .jpg, .jpeg, .webp, .gif, .bmp) and Video (.mp4, .mov, .webm, .mkv, .avi) files
  automatically invoke the AISA.one multimodal vision/video API (https://api.aisa.one/v1) using AISA_API_KEY
  strictly for media analysis — never interfering with standard Pulse AI database/analytics queries.
"""
import base64
import csv
import io
import json
import logging
import mimetypes
import os
from pathlib import Path

logger = logging.getLogger('ayevoryn.attachments')

IMAGE_EXTENSIONS = {'.png', '.jpg', '.jpeg', '.webp', '.gif', '.bmp'}
VIDEO_EXTENSIONS = {'.mp4', '.mov', '.webm', '.mkv', '.avi'}
ALLOWED_EXTENSIONS = {'.xlsx', '.csv', '.pdf', '.txt', '.md', '.json', '.log'} | IMAGE_EXTENSIONS | VIDEO_EXTENSIONS
MAX_ATTACHMENT_BYTES = 25 * 1024 * 1024  # 25 MB (supports short videos & high-res images)
MAX_EXTRACTED_CHARS = 12000

AISA_BASE_URL = 'https://api.aisa.one/v1'
AISA_VISION_MODELS = ('gpt-4o', 'gpt-4o-mini', 'gemini-2.5-flash', 'qwen-vl-max', 'qwen-vl-plus')
_AISA_DISCOVERED_MODELS = None


def _safe_filename(name: str) -> str:
    base = Path(str(name or 'attachment')).name
    cleaned = ''.join(c for c in base if c.isalnum() or c in ('.', '-', '_', ' '))
    return cleaned.strip() or 'attachment.txt'


def _get_aisa_api_key() -> str:
    val = (os.environ.get('AISA_API_KEY') or '').strip()
    if val:
        return val
    try:
        from services.superadmin_service import SuperadminService
        val = (SuperadminService.get_setting('ai_aisa_api_key') or '').strip()
        if val:
            return val
    except Exception:
        pass
    return ''


def _get_aisa_base_url() -> str:
    return (os.environ.get('AISA_BASE_URL') or AISA_BASE_URL).strip().rstrip('/')


def _discover_aisa_vision_models(api_key: str) -> list:
    """Query GET https://api.aisa.one/v1/models once to prioritize live multimodal models available on the key."""
    global _AISA_DISCOVERED_MODELS
    if _AISA_DISCOVERED_MODELS is not None:
        return list(_AISA_DISCOVERED_MODELS)
    try:
        import requests
        resp = requests.get(
            f"{_get_aisa_base_url()}/models",
            headers={'Authorization': f'Bearer {api_key}'},
            timeout=6,
        )
        if resp.status_code == 200:
            items = (resp.json() or {}).get('data') or []
            ids = [str(m.get('id') or '') for m in items if isinstance(m, dict) and m.get('id')]
            preferred = [m for m in AISA_VISION_MODELS if m in ids]
            extras = [
                mid for mid in ids
                if any(k in mid.lower() for k in ('vision', '-vl', 'gpt-4o', 'gemini-2.5', 'gemini-2.0', 'claude-3', 'glm-5v'))
                and mid not in preferred
            ][:4]
            found = preferred + extras
            if found:
                _AISA_DISCOVERED_MODELS = found
                return list(found)
    except Exception as exc:
        logger.debug('AISA /v1/models discovery fallback: %s', exc)
    return list(AISA_VISION_MODELS)


def _prepare_image_data_url(raw_bytes: bytes, ext: str) -> tuple:
    """Compress oversized images cleanly for fast vision analysis and return (data_url, width, height, mode)."""
    w, h, mode = 0, 0, 'RGB'
    mime = mimetypes.types_map.get(ext, 'image/png')
    img_bytes = raw_bytes
    try:
        from PIL import Image
        with Image.open(io.BytesIO(raw_bytes)) as im:
            w, h = im.size
            mode = im.mode
            # Resize if very large (>1600px or >2.5MB) so multimodal API responds rapidly
            if max(w, h) > 1600 or len(raw_bytes) > 2_500_000:
                copy = im.convert('RGB')
                copy.thumbnail((1600, 1600))
                buf = io.BytesIO()
                copy.save(buf, format='JPEG', quality=84, optimize=True)
                img_bytes = buf.getvalue()
                mime = 'image/jpeg'
    except Exception:
        pass
    b64 = base64.b64encode(img_bytes).decode('ascii')
    return f"data:{mime};base64,{b64}", w, h, mode


def analyze_media_with_aisa(filename: str, raw_bytes: bytes, media_kind: str = 'image', user_prompt: str = '') -> dict:
    """
    Automatically analyze an uploaded image or video via AISA.one (https://api.aisa.one/v1/chat/completions).
    Called STRICTLY for image/video attachments — never for standard text or DB analytics queries.
    """
    api_key = _get_aisa_api_key()
    if not api_key:
        return {'success': False, 'reason': 'AISA_API_KEY not configured'}

    ext = Path(filename).suffix.lower()
    instruction = (user_prompt or '').strip() or (
        "Perform a thorough, structured executive analysis of this "
        + ("video" if media_kind == 'video' else "image")
        + ". Extract all visible text, numbers, charts, tables, anomalies, objects, scenes, and actionable insights clearly."
    )

    content_parts = [{'type': 'text', 'text': instruction}]

    if media_kind == 'image':
        data_url, _, _, _ = _prepare_image_data_url(raw_bytes, ext)
        content_parts.append({'type': 'image_url', 'image_url': {'url': data_url}})
    else:
        # Video analysis: try extracting key frames with cv2 if available (universal across all vision models),
        # otherwise send base64 video data URL directly to AISA multimodal models (e.g., Gemini / Qwen-VL).
        frames_added = 0
        try:
            import tempfile
            import cv2  # type: ignore
            with tempfile.NamedTemporaryFile(suffix=ext, delete=False) as tmp:
                tmp.write(raw_bytes)
                tmp_path = tmp.name
            try:
                cap = cv2.VideoCapture(tmp_path)
                total = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
                sample_idxs = sorted(set([0, max(0, total // 4), max(0, total // 2), max(0, (3 * total) // 4)])) if total > 0 else [0]
                for fi in sample_idxs[:4]:
                    cap.set(cv2.CAP_PROP_POS_FRAMES, fi)
                    ok, frame = cap.read()
                    if ok and frame is not None:
                        ok_enc, buf = cv2.imencode('.jpg', frame, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
                        if ok_enc:
                            fb64 = base64.b64encode(buf.tobytes()).decode('ascii')
                            content_parts.append({'type': 'image_url', 'image_url': {'url': f'data:image/jpeg;base64,{fb64}'}})
                            frames_added += 1
                cap.release()
            finally:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
        except Exception:
            pass

        if frames_added == 0:
            mime = mimetypes.types_map.get(ext, 'video/mp4')
            if len(raw_bytes) <= 12 * 1024 * 1024:
                vb64 = base64.b64encode(raw_bytes).decode('ascii')
                content_parts.append({'type': 'video_url', 'video_url': {'url': f'data:{mime};base64,{vb64}'}})
            else:
                return {'success': False, 'reason': 'Video exceeds 12MB direct-upload limit without local frame extractor.'}

    models = _discover_aisa_vision_models(api_key)
    endpoint = f"{_get_aisa_base_url()}/chat/completions"
    headers = {
        'Authorization': f'Bearer {api_key}',
        'Content-Type': 'application/json',
    }

    try:
        import requests
    except ImportError:
        return {'success': False, 'reason': 'requests library unavailable'}

    for model_id in models[:4]:
        payload = {
            'model': model_id,
            'messages': [
                {
                    'role': 'system',
                    'content': 'You are Aevoryn Pulse AI Vision & Video Analyst. Provide accurate, structured, factual visual analysis without inventing unseen details.',
                },
                {'role': 'user', 'content': content_parts},
            ],
            'max_tokens': 1200,
            'temperature': 0.2,
        }
        try:
            resp = requests.post(endpoint, headers=headers, json=payload, timeout=35)
            if resp.status_code != 200:
                logger.debug('AISA vision attempt (%s) returned HTTP %s', model_id, resp.status_code)
                continue
            body = resp.json() or {}
            choices = body.get('choices') or []
            if choices:
                msg_content = ((choices[0].get('message') or {}).get('content') or '').strip()
                if msg_content:
                    return {
                        'success': True,
                        'analysis': msg_content[:MAX_EXTRACTED_CHARS],
                        'media_kind': media_kind,
                    }
        except Exception as exc:
            logger.debug('AISA vision attempt (%s) failed: %s', model_id, exc)
            continue

    return {'success': False, 'reason': 'AISA vision/video endpoint did not return an analysis.'}


def analyze_uploaded_bytes(filename: str, raw_bytes: bytes, user_prompt: str = '') -> dict:
    """
    Validate and extract structured context from an uploaded file.
    - Images & Videos automatically invoke AISA.one multimodal analysis (only when media is uploaded).
    - Excel, CSV, PDF, JSON, TXT, MD, LOG are parsed locally.
    """
    safe_name = _safe_filename(filename)
    ext = Path(safe_name).suffix.lower()
    if ext not in ALLOWED_EXTENSIONS:
        return {
            'success': False,
            'error': f"Unsupported file type '{ext}'. Allowed: PDF, XLSX, CSV, TXT, MD, JSON, PNG, JPG, WEBP, GIF, MP4, MOV, WEBM."
        }
    if not raw_bytes:
        return {'success': False, 'error': 'Uploaded file is empty.'}
    if len(raw_bytes) > MAX_ATTACHMENT_BYTES:
        return {'success': False, 'error': 'File exceeds the 25 MB attachment limit.'}

    try:
        if ext == '.xlsx':
            import openpyxl
            wb = openpyxl.load_workbook(io.BytesIO(raw_bytes), data_only=True, read_only=True)
            parts = [f"Excel Workbook: {safe_name} ({len(wb.sheetnames)} sheets: {', '.join(wb.sheetnames)})"]
            total_rows = 0
            for sname in wb.sheetnames[:6]:
                ws = wb[sname]
                rows = []
                for idx, row in enumerate(ws.iter_rows(values_only=True)):
                    if idx >= 60:
                        break
                    vals = [str(v) if v is not None else '' for v in row]
                    if any(v.strip() for v in vals):
                        rows.append(' | '.join(vals[:14]))
                total_rows += len(rows)
                parts.append(f"\n[Sheet: {sname} — showing up to {len(rows)} rows]\n" + '\n'.join(rows))
            wb.close()
            extracted = '\n'.join(parts)[:MAX_EXTRACTED_CHARS]
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'excel',
                'size_bytes': len(raw_bytes),
                'summary': f"{len(wb.sheetnames)} sheet(s), {total_rows} preview rows extracted",
                'extracted_text': extracted,
            }

        if ext == '.csv':
            text = raw_bytes.decode('utf-8-sig', errors='replace')
            reader = list(csv.reader(io.StringIO(text)))
            row_count = len(reader)
            preview = [' | '.join(r[:14]) for r in reader[:80]]
            extracted = f"CSV File: {safe_name} ({row_count} rows)\n" + '\n'.join(preview)
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'csv',
                'size_bytes': len(raw_bytes),
                'summary': f"{row_count} CSV rows extracted",
                'extracted_text': extracted[:MAX_EXTRACTED_CHARS],
            }

        if ext == '.pdf':
            extracted_pages = []
            for mod_name in ('pypdf', 'PyPDF2'):
                try:
                    mod = __import__(mod_name)
                    reader = mod.PdfReader(io.BytesIO(raw_bytes))
                    for i, page in enumerate(reader.pages[:15], 1):
                        ptxt = (page.extract_text() or '').strip()
                        if ptxt:
                            extracted_pages.append(f"[Page {i}]\n{ptxt}")
                    break
                except Exception:
                    continue
            if not extracted_pages:
                return {
                    'success': True,
                    'filename': safe_name,
                    'file_type': 'pdf',
                    'size_bytes': len(raw_bytes),
                    'summary': f"PDF uploaded ({len(raw_bytes) // 1024} KB)",
                    'extracted_text': f"PDF Document attached: {safe_name} ({len(raw_bytes)} bytes). No embedded text layer extracted.",
                }
            full_pdf = f"PDF Document: {safe_name} ({len(extracted_pages)} pages extracted)\n" + '\n\n'.join(extracted_pages)
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'pdf',
                'size_bytes': len(raw_bytes),
                'summary': f"{len(extracted_pages)} PDF page(s) extracted",
                'extracted_text': full_pdf[:MAX_EXTRACTED_CHARS],
            }

        if ext == '.json':
            parsed = json.loads(raw_bytes.decode('utf-8', errors='replace'))
            pretty = json.dumps(parsed, indent=2, ensure_ascii=False)[:MAX_EXTRACTED_CHARS]
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'json',
                'size_bytes': len(raw_bytes),
                'summary': f"Valid JSON ({len(raw_bytes)} bytes)",
                'extracted_text': f"JSON File: {safe_name}\n{pretty}",
            }

        if ext in ('.txt', '.md', '.log'):
            txt = raw_bytes.decode('utf-8', errors='replace')[:MAX_EXTRACTED_CHARS]
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'text',
                'size_bytes': len(raw_bytes),
                'summary': f"{len(txt)} characters extracted",
                'extracted_text': f"Document: {safe_name}\n{txt}",
            }

        if ext in IMAGE_EXTENSIONS:
            _, w, h, mode = _prepare_image_data_url(raw_bytes, ext)
            meta = f"Attached Image: {safe_name} — Resolution {w}x{h}px, Format {ext.lstrip('.').upper()}, Color Mode {mode}."
            vision = analyze_media_with_aisa(safe_name, raw_bytes, media_kind='image', user_prompt=user_prompt)
            if vision.get('success') and vision.get('analysis'):
                return {
                    'success': True,
                    'filename': safe_name,
                    'file_type': 'image',
                    'size_bytes': len(raw_bytes),
                    'vision_analyzed': True,
                    'summary': f"Image {w}x{h} · Visual AI Analysis Ready",
                    'extracted_text': f"{meta}\n\n[VISUAL ANALYSIS]\n{vision['analysis']}"[:MAX_EXTRACTED_CHARS],
                }
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'image',
                'size_bytes': len(raw_bytes),
                'vision_analyzed': False,
                'summary': f"Image {w}x{h} ({mode})",
                'extracted_text': meta,
            }

        if ext in VIDEO_EXTENSIONS:
            size_mb = round(len(raw_bytes) / (1024 * 1024), 2)
            meta = f"Attached Video: {safe_name} — Format {ext.lstrip('.').upper()}, Size {size_mb} MB."
            vision = analyze_media_with_aisa(safe_name, raw_bytes, media_kind='video', user_prompt=user_prompt)
            if vision.get('success') and vision.get('analysis'):
                return {
                    'success': True,
                    'filename': safe_name,
                    'file_type': 'video',
                    'size_bytes': len(raw_bytes),
                    'vision_analyzed': True,
                    'summary': f"Video ({size_mb} MB) · Visual AI Analysis Ready",
                    'extracted_text': f"{meta}\n\n[VIDEO ANALYSIS]\n{vision['analysis']}"[:MAX_EXTRACTED_CHARS],
                }
            return {
                'success': True,
                'filename': safe_name,
                'file_type': 'video',
                'size_bytes': len(raw_bytes),
                'vision_analyzed': False,
                'summary': f"Video ({size_mb} MB) attached",
                'extracted_text': meta,
            }

    except Exception as exc:
        return {'success': False, 'error': f"Failed to parse '{safe_name}': {exc}"}

    return {'success': False, 'error': 'Unable to process attachment.'}
