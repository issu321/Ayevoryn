"""
AEVORYN PULSE AI — VERIFIED AGENTIC ROUTE & TOOL-CALLING REGISTRY
Supports BOTH:
  1. Native LLM Tool / Function Calling (OpenAI / NVIDIA NIM `tools` schema: navigate_to_page, jump_registration_stage, toggle_theme)
  2. Structured <<<AGENT_ACTION>>>{...}<<<END_ACTION>>> blocks
Strictly whitelists every target URL against real Flask routes so the AI agent NEVER navigates to a 404 or external site.
"""

import json
import re
from typing import Optional

PUBLIC_ROUTES = [
    {"url": "/", "label": "Home Page", "description": "Main public landing page and platform overview"},
    {"url": "/features", "label": "Features", "description": "Platform capabilities, dashboards, and modules tour"},
    {"url": "/architecture", "label": "Architecture", "description": "Technical architecture and multi-tenant security overview"},
    {"url": "/decision-models", "label": "Decision Models", "description": "Financial modeling and scenario simulation showcase"},
    {"url": "/dependency-intelligence", "label": "Dependency Graph", "description": "Department relationships and impact propagation overview"},
    {"url": "/setup", "label": "Register Organization", "description": "6-stage organization registration and company creation wizard"},
    {"url": "/register", "label": "Register Operator Account", "description": "Join an existing company workspace as a team member"},
    {"url": "/login", "label": "Sign In", "description": "Sign in to your Aevoryn executive workspace"},
    {"url": "/privacy", "label": "Privacy Policy", "description": "USMANIA TECHS PVT LTD privacy and data handling policy"},
    {"url": "/terms", "label": "Terms of Service", "description": "Ayevoryn terms of service"},
]

APP_ROUTES = [
    {"url": "/dashboard", "label": "Executive Dashboard", "description": "Main company KPIs, health score, revenue, profit, and runway overview"},
    {"url": "/pulse-ai/", "label": "Pulse AI Workspace", "description": "Full-screen conversational AI analyst workspace"},
    {"url": "/pulse-ai/automations", "label": "AI Automations Studio", "description": "Visual linked-node AI automations, upcoming schedules, and autonomous Pulse AI workflows"},
    {"url": "/ai-insights/", "label": "AI Insights", "description": "Decision intelligence alerts and live AI strategic advisor"},
    {"url": "/command-center/", "label": "Command Center", "description": "Real-time executive command center and operational telemetry"},
    {"url": "/business-twin/", "label": "Business Twin Overview", "description": "Unified overview of all company data tables"},
    {"url": "/business-twin/departments", "label": "Departments", "description": "Manage departments, budgets, and department heads"},
    {"url": "/business-twin/revenue", "label": "Revenue Ledger", "description": "View, add, and import company revenue records"},
    {"url": "/business-twin/expenses", "label": "Expenses Ledger", "description": "View, add, and import company expense records"},
    {"url": "/business-twin/payments", "label": "Treasury & Bank Accounts", "description": "Bank accounts, cash reserves, balances, and payment rails"},
    {"url": "/business-twin/customers", "label": "Customers (CRM)", "description": "Customer directory, LTV, retention, and churn records"},
    {"url": "/business-twin/employees", "label": "Employees & Payroll", "description": "Workforce roster, headcount, roles, and payroll"},
    {"url": "/business-twin/suppliers", "label": "Suppliers", "description": "Vendor directory, lead times, and supplier reliability"},
    {"url": "/business-twin/inventory", "label": "Inventory & Warehouse", "description": "SKUs, stock levels, valuation, and reorder alerts"},
    {"url": "/business-twin/custom-twins", "label": "Custom Twins", "description": "Custom company data modules and schemas"},
    {"url": "/analytics/", "label": "Analytics Overview", "description": "Cross-company visual analytics hub"},
    {"url": "/analytics/revenue", "label": "Revenue Analytics", "description": "Revenue trends, velocity, and breakdowns"},
    {"url": "/analytics/expenses", "label": "Expense Analytics", "description": "Expense categories, burn rate, and cost trends"},
    {"url": "/analytics/profit", "label": "Profit Analytics", "description": "Operating profit and margin analysis"},
    {"url": "/analytics/growth", "label": "Growth Analytics", "description": "Company growth trajectory and expansion metrics"},
    {"url": "/analytics/departments", "label": "Department Analytics", "description": "Department spend, efficiency, and headcount charts"},
    {"url": "/analytics/customers", "label": "Customer Analytics", "description": "Customer acquisition, LTV, and cohort charts"},
    {"url": "/analytics/employees", "label": "Employee Analytics", "description": "Workforce distribution and compensation analytics"},
    {"url": "/analytics/supply-chain", "label": "Supply Chain Analytics", "description": "Procurement, vendor, and inventory analytics"},
    {"url": "/simulation/", "label": "Simulation Center", "description": "Run what-if stress tests, pricing, hiring, and recession simulations"},
    {"url": "/forecasting/", "label": "Forecasting Lab", "description": "6-to-12 month revenue and financial projections"},
    {"url": "/risk/", "label": "Risk Engine", "description": "Enterprise risk scores, alerts, and mitigation tracking"},
    {"url": "/risk/heatmap", "label": "Risk Heatmap", "description": "Visual severity vs probability risk heatmap"},
    {"url": "/scenario/", "label": "Scenario Builder", "description": "Compare and branch strategic business scenarios"},
    {"url": "/financial/", "label": "Financial Modeling", "description": "P&L modeling, investment, and expansion calculators"},
    {"url": "/market/", "label": "Market Intelligence", "description": "Industry benchmarks and market signals"},
    {"url": "/competition/", "label": "Competition Analysis", "description": "Competitor tracking and positioning"},
    {"url": "/reports/", "label": "Report Center", "description": "Generate and download executive financial reports"},
    {"url": "/documents/", "label": "Document Center", "description": "Manage uploaded company documents"},
    {"url": "/data-lake/", "label": "Data Lake", "description": "Unified data ingestion and dataset explorer"},
    {"url": "/twin-graph/", "label": "Dependency Graph", "description": "Interactive department and entity dependency graph"},
    {"url": "/temporal/", "label": "Temporal Twin", "description": "Historical snapshots and time-travel comparisons"},
    {"url": "/audit/", "label": "Audit Trail", "description": "Immutable security and change audit log"},
    {"url": "/jobs/", "label": "Background Jobs", "description": "Monitor async tasks and imports"},
    {"url": "/settings/", "label": "Workspace Settings", "description": "Company profile, branding, currency, theme, and account settings"},
]


class PulseAgenticRouter:
    """Native LLM Tool-Calling & Structured Action Router with strict URL whitelisting."""

    ACTION_TAG_RE = re.compile(r'<<<AGENT_ACTION>>>\s*(\{.*?\})\s*<<<END_ACTION>>>', re.DOTALL)

    @staticmethod
    def get_allowed_routes(scope: str = 'app') -> list:
        if scope == 'public':
            return PUBLIC_ROUTES
        return APP_ROUTES + PUBLIC_ROUTES

    @staticmethod
    def build_openai_tools(scope: str = 'app', allow_wizard_stages: bool = False) -> list:
        """
        Return native OpenAI/NVIDIA NIM function-calling tool definitions so the LLM
        directly calls `navigate_to_page` with 100% accuracy for ANY natural user phrasing.
        """
        routes = PulseAgenticRouter.get_allowed_routes(scope)
        url_enum = [r['url'] for r in routes]
        route_desc = "; ".join(f"{r['url']} ({r['label']})" for r in routes)

        tools = [
            {
                "type": "function",
                "function": {
                    "name": "navigate_to_page",
                    "description": (
                        "Navigate the user's browser directly to a page inside Aevoryn with an animated loading screen. "
                        "Call this whenever the user asks to go to, open, visit, switch to, or be taken to any page, module, dashboard, login, or registration screen. "
                        f"Available routes: {route_desc}"
                    ),
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "url": {
                                "type": "string",
                                "enum": url_enum,
                                "description": "Exact target route URL from the verified list."
                            },
                            "label": {
                                "type": "string",
                                "description": "Human-readable destination page title."
                            },
                            "loading_message": {
                                "type": "string",
                                "description": "Short friendly loading message shown during navigation."
                            }
                        },
                        "required": ["url"]
                    }
                }
            },
            {
                "type": "function",
                "function": {
                    "name": "toggle_theme",
                    "description": "Switch the user interface between dark mode and light mode.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "theme": {
                                "type": "string",
                                "enum": ["dark", "light", "toggle"]
                            }
                        },
                        "required": ["theme"]
                    }
                }
            }
        ]

        if allow_wizard_stages:
            tools.append({
                "type": "function",
                "function": {
                    "name": "jump_registration_stage",
                    "description": "Jump directly to a specific stage (1 to 6) of the Organization Registration Wizard.",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "stage": {
                                "type": "integer",
                                "minimum": 1,
                                "maximum": 6,
                                "description": "1=Identity, 2=Profile, 3=Treasury, 4=Departments, 5=Governance, 6=Review"
                            },
                            "label": {"type": "string"}
                        },
                        "required": ["stage"]
                    }
                }
            })

        return tools

    @staticmethod
    def validate_tool_call(tool_name: str, args: dict, scope: str = 'app') -> Optional[dict]:
        """Validate a native LLM tool_call against the route whitelist and return a clean agent_action dict."""
        if not isinstance(args, dict):
            return None
        allowed_map = {r['url']: r for r in PulseAgenticRouter.get_allowed_routes(scope)}

        if tool_name == 'navigate_to_page':
            raw_dest = (args.get('url') or args.get('destination') or '').strip()
            url = raw_dest
            if url not in allowed_map and (url + '/') in allowed_map:
                url = url + '/'
            elif url not in allowed_map and url.endswith('/') and url[:-1] in allowed_map:
                url = url[:-1]
            if url in allowed_map:
                info = allowed_map[url]
                label = (args.get('label') or info['label']).strip()
                msg = (args.get('loading_message') or f"Opening {label}...").strip()
                return {'type': 'navigate', 'url': url, 'label': label, 'loading_message': msg}
            # Fuzzy match natural destination name against verified route labels & keywords
            low = raw_dest.lower()
            for r in PulseAgenticRouter.get_allowed_routes(scope):
                if low and (low == r['label'].lower() or low in r['label'].lower() or low in r['url'].lower()):
                    return {'type': 'navigate', 'url': r['url'], 'label': r['label'], 'loading_message': f"Opening {r['label']}..."}
            fb = PulseAgenticRouter.infer_fallback_action(f"go to {raw_dest}", scope=scope)
            if fb and fb.get('type') == 'navigate':
                return fb
            return None

        if tool_name == 'jump_registration_stage':
            try:
                stage = int(args.get('stage'))
                if 1 <= stage <= 6:
                    label = (args.get('label') or f"Stage {stage}").strip()
                    return {
                        'type': 'jump_stage',
                        'stage': stage,
                        'label': label,
                        'loading_message': f"Opening {label}...",
                    }
            except (TypeError, ValueError):
                return None

        if tool_name == 'toggle_theme':
            theme = (args.get('theme') or 'toggle').strip().lower()
            if theme not in ('dark', 'light', 'toggle'):
                theme = 'toggle'
            return {
                'type': 'toggle_theme',
                'theme': theme,
                'label': f"{theme.title()} Mode" if theme != 'toggle' else "Switch Theme",
                'loading_message': "Updating interface theme...",
            }
        return None

    @staticmethod
    def build_agentic_prompt_instructions(scope: str = 'app', allow_wizard_stages: bool = False) -> str:
        routes = PulseAgenticRouter.get_allowed_routes(scope)
        route_lines = "\n".join(f"  - `{r['url']}` -> {r['label']}: {r['description']}" for r in routes)

        wizard_block = ""
        if allow_wizard_stages:
            wizard_block = (
                "- On the registration page, to switch wizard steps (1..6), call `jump_registration_stage` OR emit:\n"
                "  <<<AGENT_ACTION>>>{\"type\":\"jump_stage\",\"stage\":3,\"label\":\"Stage 3: Treasury\"}<<<END_ACTION>>>\n"
            )

        return (
            "\n\nAGENTIC NAVIGATION & ACTION CAPABILITIES:\n"
            "You are an active AI Agent that controls navigation inside Aevoryn.\n"
            "Whenever the user asks to go to, open, visit, navigate to, show a page/screen, register, sign in, or switch theme:\n"
            "- Call the `navigate_to_page` tool (preferred) OR append:\n"
            "  <<<AGENT_ACTION>>>{\"type\":\"navigate\",\"url\":\"/exact-route\",\"label\":\"Page Name\",\"loading_message\":\"Opening Page Name...\"}<<<END_ACTION>>>\n"
            + wizard_block
            + "- For analytical or data questions (e.g. asking about revenue, profit, customers, risks, strategy), answer directly using the real database numbers and do NOT navigate unless asked.\n"
            "- Verified routes:\n"
            f"{route_lines}\n"
        )

    @staticmethod
    def extract_agent_action(raw_text: str, scope: str = 'app') -> tuple:
        if not raw_text:
            return '', None
        match = PulseAgenticRouter.ACTION_TAG_RE.search(raw_text)
        if not match:
            return raw_text.strip(), None
        clean_text = PulseAgenticRouter.ACTION_TAG_RE.sub('', raw_text).strip()
        try:
            action = json.loads(match.group(1))
        except Exception:
            return clean_text, None
        if not isinstance(action, dict):
            return clean_text, None
        a_type = (action.get('type') or '').strip().lower()
        if a_type == 'navigate':
            validated = PulseAgenticRouter.validate_tool_call('navigate_to_page', action, scope=scope)
            if validated:
                return clean_text or f"Taking you to **{validated['label']}** now.", validated
            return clean_text, None
        if a_type == 'jump_stage':
            validated = PulseAgenticRouter.validate_tool_call('jump_registration_stage', action, scope=scope)
            if validated:
                return clean_text or f"Moving to **{validated['label']}** now.", validated
            return clean_text, None
        if a_type == 'toggle_theme':
            validated = PulseAgenticRouter.validate_tool_call('toggle_theme', action, scope=scope)
            if validated:
                return clean_text or "Updating your interface theme now.", validated
            return clean_text, None
        return clean_text, None

    @staticmethod
    def infer_fallback_action(prompt: str, scope: str = 'app', current_page: str = '') -> Optional[dict]:
        """Safety-net resolver ONLY if the LLM neither called a tool nor emitted <<<AGENT_ACTION>>> on an explicit navigation prompt."""
        p = (prompt or '').strip().lower()
        if not p:
            return None

        if current_page == 'register':
            m = re.search(r'\b(?:stage|step)\s*([1-6])\b', p)
            if m:
                stage = int(m.group(1))
                return {
                    'type': 'jump_stage',
                    'stage': stage,
                    'label': f'Stage {stage}',
                    'loading_message': f'Opening Stage {stage}...'
                }

        nav_triggers = (
            'take me', 'go to', 'goto', 'open ', 'navigate', 'bring me', 'redirect',
            'switch to', 'show me the ', 'head to', 'move to', 'jump to', 'visit ',
            'launch ', 'i want to register', 'i want to sign in', 'i want to login',
            'go back', 'page', 'screen', 'tab'
        )
        if not any(t in p for t in nav_triggers):
            return None

        # Avoid hijacking analytical questions like "what is our revenue on the dashboard page?"
        if any(q in p for q in ('what is', 'how much', 'how many', 'why ', 'compare ', 'analyze ', 'explain ', 'summarize ')):
            if not any(t in p for t in ('take me', 'take us', 'go to', 'goto', 'open ', 'navigate', 'bring me', 'redirect', 'switch to', 'visit ', 'show me the ', 'move to ')):
                return None

        keyword_routes = [
            (['register', 'sign up', 'signup', 'create org', 'create company', 'new company', 'setup', 'onboarding'], '/setup', 'Register Organization'),
            (['login', 'sign in', 'signin'], '/login', 'Sign In'),
            (['features', 'capabilities'], '/features', 'Features'),
            (['architecture'], '/architecture', 'Architecture'),
            (['decision model'], '/decision-models', 'Decision Models'),
            (['dependency intelligence'], '/dependency-intelligence', 'Dependency Graph'),
            (['home', 'index', 'landing'], '/', 'Home Page'),
        ]
        if scope != 'public':
            keyword_routes = [
                (['risk heatmap', 'heatmap'], '/risk/heatmap', 'Risk Heatmap'),
                (['risk'], '/risk/', 'Risk Engine'),
                (['revenue analytics'], '/analytics/revenue', 'Revenue Analytics'),
                (['expense analytics'], '/analytics/expenses', 'Expense Analytics'),
                (['profit analytics'], '/analytics/profit', 'Profit Analytics'),
                (['growth analytics'], '/analytics/growth', 'Growth Analytics'),
                (['department analytics'], '/analytics/departments', 'Department Analytics'),
                (['customer analytics'], '/analytics/customers', 'Customer Analytics'),
                (['employee analytics'], '/analytics/employees', 'Employee Analytics'),
                (['supply chain analytics'], '/analytics/supply-chain', 'Supply Chain Analytics'),
                (['analytics'], '/analytics/', 'Analytics Overview'),
                (['department'], '/business-twin/departments', 'Departments'),
                (['revenue', 'sales'], '/business-twin/revenue', 'Revenue Ledger'),
                (['expense'], '/business-twin/expenses', 'Expenses Ledger'),
                (['bank', 'treasury', 'payment', 'account'], '/business-twin/payments', 'Treasury & Bank Accounts'),
                (['customer', 'crm', 'client'], '/business-twin/customers', 'Customers (CRM)'),
                (['employee', 'staff', 'payroll', 'workforce'], '/business-twin/employees', 'Employees & Payroll'),
                (['supplier', 'vendor'], '/business-twin/suppliers', 'Suppliers'),
                (['inventory', 'warehouse', 'stock', 'sku'], '/business-twin/inventory', 'Inventory & Warehouse'),
                (['custom twin'], '/business-twin/custom-twins', 'Custom Twins'),
                (['business twin'], '/business-twin/', 'Business Twin Overview'),
                (['simulation', 'simulate', 'stress test'], '/simulation/', 'Simulation Center'),
                (['forecast'], '/forecasting/', 'Forecasting Lab'),
                (['scenario'], '/scenario/', 'Scenario Builder'),
                (['financial model', 'financials'], '/financial/', 'Financial Modeling'),
                (['market'], '/market/', 'Market Intelligence'),
                (['competit'], '/competition/', 'Competition Analysis'),
                (['report'], '/reports/', 'Report Center'),
                (['document'], '/documents/', 'Document Center'),
                (['data lake'], '/data-lake/', 'Data Lake'),
                (['dependency', 'twin graph', 'graph'], '/twin-graph/', 'Dependency Graph'),
                (['temporal', 'snapshot'], '/temporal/', 'Temporal Twin'),
                (['audit'], '/audit/', 'Audit Trail'),
                (['job'], '/jobs/', 'Background Jobs'),
                (['setting', 'profile', 'branding'], '/settings/', 'Workspace Settings'),
                (['ai insight', 'insight'], '/ai-insights/', 'AI Insights'),
                (['command center'], '/command-center/', 'Command Center'),
                (['pulse ai'], '/pulse-ai/', 'Pulse AI Workspace'),
                (['dashboard', 'overview'], '/dashboard', 'Executive Dashboard'),
            ] + keyword_routes

        for kws, url, label in keyword_routes:
            if any(kw in p for kw in kws):
                return {
                    'type': 'navigate',
                    'url': url,
                    'label': label,
                    'loading_message': f'Opening {label}...'
                }
        return None
