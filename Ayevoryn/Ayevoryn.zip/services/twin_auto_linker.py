"""
AEVORYN — AUTOMATED TWIN <-> DEPARTMENT SMART LINKING ENGINE
Automatically links:
  1. Newly created Custom Twins -> matching/selected Company Departments (via TwinDependency)
  2. Newly created Departments -> matching/selected Custom Twins + Core Financial/Operational Graph Nodes
Ensures zero orphaned twins or disconnected departments in the Dependency Graph & Impact Engine.
"""

import json
from database.db import db
from database.models.department import Department
from database.models.custom_twin import CustomTwin
from database.models.twin_dependency import TwinDependency, DependencyType


SEMANTIC_DOMAIN_MAP = {
    'it': ['it', 'tech', 'software', 'server', 'cloud', 'infra', 'devops', 'security', 'cyber', 'device', 'laptop', 'hardware', 'system', 'network', 'api', 'data', 'ai'],
    'engineering': ['engineering', 'product', 'dev', 'build', 'code', 'qa', 'platform', 'r&d', 'research', 'hardware', 'sensor', 'iot'],
    'finance': ['finance', 'accounting', 'invoice', 'billing', 'tax', 'audit', 'payroll', 'treasury', 'bank', 'budget', 'expense', 'revenue', 'asset', 'loan', 'investment'],
    'sales': ['sales', 'crm', 'deal', 'lead', 'pipeline', 'client', 'customer', 'account', 'contract', 'order', 'subscription'],
    'marketing': ['marketing', 'campaign', 'brand', 'ad', 'seo', 'social', 'growth', 'event', 'content', 'lead'],
    'operations': ['operations', 'ops', 'fleet', 'vehicle', 'transport', 'logistics', 'warehouse', 'inventory', 'supply', 'vendor', 'supplier', 'delivery', 'shipment', 'facility', 'equipment', 'manufacturing'],
    'hr': ['hr', 'human', 'people', 'recruit', 'hiring', 'candidate', 'training', 'leave', 'attendance', 'employee', 'staff', 'talent'],
}


def _match_domains(text: str) -> set:
    t = (text or '').lower()
    matched = set()
    for domain, kws in SEMANTIC_DOMAIN_MAP.items():
        if any(kw in t for kw in kws):
            matched.add(domain)
    return matched


def _upsert_dependency(company_id: int, source_type: str, source_id: str, target_type: str, target_id: str, description: str, strength: float = 0.85, user_id: int = None) -> bool:
    existing = TwinDependency.query.filter_by(
        company_id=int(company_id),
        source_type=source_type,
        source_id=str(source_id),
        target_type=target_type,
        target_id=str(target_id),
        is_active=True
    ).first()
    if existing:
        return False
    dep = TwinDependency(
        company_id=int(company_id),
        source_type=source_type,
        source_id=str(source_id),
        target_type=target_type,
        target_id=str(target_id),
        dependency_type=DependencyType.CONFIGURED,
        strength=float(strength),
        description=description[:255],
        metadata_json=json.dumps({'auto_linked': True}),
        is_active=True,
        created_by=user_id
    )
    db.session.add(dep)
    return True


def auto_link_custom_twin_to_departments(company_id: int, twin: CustomTwin, user_id: int = None, explicit_dept_ids: list = None) -> list:
    """
    Automatically link a newly created CustomTwin to explicit and/or semantically matching Departments.
    Returns list of linked department dicts: [{'id': ..., 'name': ..., 'reason': ...}].
    """
    cid = int(company_id)
    depts = Department.query.filter_by(company_id=cid).all()
    if not depts:
        return []

    linked = []
    chosen_ids = set()

    # 1. Explicit department IDs chosen by user or AI agent
    for raw_id in (explicit_dept_ids or []):
        try:
            chosen_ids.add(int(raw_id))
        except (TypeError, ValueError):
            pass

    if getattr(twin, 'linked_entity_type', None) == 'department' and getattr(twin, 'linked_entity_id', None):
        chosen_ids.add(int(twin.linked_entity_id))

    # 2. Semantic matching between twin name/description and department names/descriptions
    twin_text = f"{twin.name or ''} {twin.description or ''}"
    twin_domains = _match_domains(twin_text)

    for d in depts:
        dept_text = f"{d.name or ''} {d.description or ''}"
        dept_domains = _match_domains(dept_text)
        is_explicit = d.id in chosen_ids
        is_semantic = bool(twin_domains & dept_domains) or (d.name and d.name.lower() in twin_text.lower())

        if is_explicit or is_semantic:
            reason = 'Selected link' if is_explicit else 'Auto-matched by domain'
            created = _upsert_dependency(
                company_id=cid,
                source_type='custom_twin',
                source_id=str(twin.id),
                target_type='department',
                target_id=str(d.id),
                description=f"Linked Custom Twin '{twin.name}' -> Department '{d.name}' ({reason})",
                strength=0.9 if is_explicit else 0.78,
                user_id=user_id
            )
            linked.append({'id': d.id, 'name': d.name, 'reason': reason, 'created': created})

    # 3. Guarantee zero orphaned twins: if nothing matched, link to primary Operations/first department
    if not linked and depts:
        fallback_dept = next((d for d in depts if 'operat' in (d.name or '').lower()), depts[0])
        created = _upsert_dependency(
            company_id=cid,
            source_type='custom_twin',
            source_id=str(twin.id),
            target_type='department',
            target_id=str(fallback_dept.id),
            description=f"Default operational link: Custom Twin '{twin.name}' -> Department '{fallback_dept.name}'",
            strength=0.65,
            user_id=user_id
        )
        linked.append({'id': fallback_dept.id, 'name': fallback_dept.name, 'reason': 'Default operational link', 'created': created})

    # Update twin primary link if unset
    if linked and (not twin.linked_entity_id or twin.linked_entity_type == 'custom'):
        twin.linked_entity_type = 'department'
        twin.linked_entity_id = linked[0]['id']

    db.session.commit()
    return linked


def auto_link_department_to_twins(company_id: int, dept: Department, user_id: int = None, explicit_twin_ids: list = None) -> list:
    """
    Automatically link a newly created Department to matching/selected Custom Twins
    AND core financial/operational graph nodes so it immediately participates in impact propagation.
    Returns list of linked twin dicts.
    """
    cid = int(company_id)
    linked = []

    # 1. Always connect new department to the company's core financial budget node
    _upsert_dependency(
        company_id=cid,
        source_type='department',
        source_id=str(dept.id),
        target_type='financial',
        target_id='operating_expenses',
        description=f"Department '{dept.name}' budget & payroll feeds Operating Expenses",
        strength=0.85,
        user_id=user_id
    )

    # 2. Link to explicit or semantically matching Custom Twins
    twins = CustomTwin.query.filter_by(company_id=cid, is_active=True).all()
    explicit_set = set()
    for raw_id in (explicit_twin_ids or []):
        try:
            explicit_set.add(int(raw_id))
        except (TypeError, ValueError):
            pass

    dept_text = f"{dept.name or ''} {dept.description or ''}"
    dept_domains = _match_domains(dept_text)

    for t in twins:
        twin_text = f"{t.name or ''} {t.description or ''}"
        twin_domains = _match_domains(twin_text)
        is_explicit = t.id in explicit_set
        is_direct = (t.linked_entity_type == 'department' and t.linked_entity_id == dept.id)
        is_semantic = bool(dept_domains & twin_domains) or (dept.name and dept.name.lower() in twin_text.lower())

        if is_explicit or is_direct or is_semantic:
            reason = 'Direct department twin' if is_direct else ('Selected link' if is_explicit else 'Auto-matched by domain')
            created = _upsert_dependency(
                company_id=cid,
                source_type='custom_twin',
                source_id=str(t.id),
                target_type='department',
                target_id=str(dept.id),
                description=f"Linked Custom Twin '{t.name}' -> Department '{dept.name}' ({reason})",
                strength=0.9 if (is_direct or is_explicit) else 0.78,
                user_id=user_id
            )
            linked.append({'id': t.id, 'name': t.name, 'slug': t.slug, 'reason': reason, 'created': created})

    db.session.commit()
    return linked
