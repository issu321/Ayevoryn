"""
Ayevoryn Global Superadmin Pulse AI & Autonomous Orchestration Engine (USMANIA TECHS PVT LTD)
Provides 100% real, cross-tenant Global Superadmin AI intelligence, live SQL/module tools,
real dynamic PDF/Excel/CSV global reports, persistent conversation memory, and a 3-second
background daemon executing custom seconds/minutes/hours/days Superadmin automations
with immutable per-run history (Run #1, #2, #3, ...).
"""
from datetime import datetime, timedelta
import json
import re
import threading
import time
from sqlalchemy import inspect, text

from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.employee import Employee
from database.models.financial import FinancialRecord
from database.models.inventory import Inventory
from database.models.customer import Customer
from database.models.risk import Risk
from database.models.superadmin import GlobalAuditLog, PlatformSetting, UserSessionRecord
from database.models.superadmin_pulse import (
    SuperadminConversation,
    SuperadminMessage,
    SuperadminAutomation,
    SuperadminAutomationRun,
    ensure_superadmin_pulse_tables,
)
from services.pulse_ai_engine import PulseAIProviderManager
from services.superadmin_db_service import SuperadminDBService
from services.superadmin_service import SuperadminService

_SA_WORKER_THREAD = None
_SA_RUN_LOCK = threading.Lock()

SUPERADMIN_ROUTES = [
    {'url': '/superadmin/dashboard', 'label': 'Control Center Overview', 'keywords': ['dashboard', 'overview', 'home', 'control center']},
    {'url': '/superadmin/companies', 'label': 'Global Organizations', 'keywords': ['companies', 'organizations', 'tenants', 'company']},
    {'url': '/superadmin/users', 'label': 'Global Users & Roles', 'keywords': ['users', 'roles', 'accounts', 'operators']},
    {'url': '/superadmin/pulse-ai', 'label': 'Superadmin Pulse AI', 'keywords': ['pulse ai', 'ai workspace', 'assistant', 'chat']},
    {'url': '/superadmin/automations', 'label': 'Superadmin AI Automations', 'keywords': ['automations', 'automation', 'schedules', 'workflows', 'nodes']},
    {'url': '/superadmin/database', 'label': 'Database Administration', 'keywords': ['database', 'db', 'sql', 'tables', 'backup', 'schema']},
    {'url': '/superadmin/platform', 'label': 'Global Platform Control', 'keywords': ['platform', 'settings', 'maintenance', 'control']},
    {'url': '/superadmin/audit', 'label': 'Immutable Audit Trail', 'keywords': ['audit', 'logs', 'trail', 'security logs']},
    {'url': '/superadmin/profile', 'label': 'Superadmin Profile & MFA', 'keywords': ['profile', 'mfa', 'account', 'password']},
]


def build_superadmin_tools() -> list:
    return [
        {
            'type': 'function',
            'function': {
                'name': 'query_global_platform',
                'description': (
                    'Query LIVE global platform data across ALL organizations, users, audit logs, platform settings, '
                    'database tables, or any specific company\'s financials, departments, employees, inventory, customers, or risks.'
                ),
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'module': {
                            'type': 'string',
                            'enum': [
                                'platform_summary', 'companies', 'users', 'audit_logs', 'platform_settings',
                                'database_overview', 'company_financials', 'company_departments',
                                'company_employees', 'company_inventory', 'company_customers', 'company_risks'
                            ],
                        },
                        'company_id': {'type': 'integer', 'description': 'Optional company ID to scope a company_* query.'},
                        'search': {'type': 'string', 'description': 'Optional search keyword.'},
                        'limit': {'type': 'integer', 'description': 'Max rows (default 50).'},
                    },
                    'required': ['module'],
                },
            },
        },
        {
            'type': 'function',
            'function': {
                'name': 'execute_readonly_sql',
                'description': 'Execute a real read-only SQL query (SELECT / PRAGMA) against the live platform database to answer any custom analytics or DBA question.',
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'sql': {'type': 'string', 'description': 'Valid SQLite SELECT or PRAGMA query.'},
                    },
                    'required': ['sql'],
                },
            },
        },
        {
            'type': 'function',
            'function': {
                'name': 'manage_platform_entity',
                'description': 'Perform real Superadmin governance actions: suspend/activate a company or user, revoke user sessions, create an online DB backup, or run DB integrity_check/analyze/vacuum.',
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'action': {
                            'type': 'string',
                            'enum': ['suspend_company', 'activate_company', 'suspend_user', 'activate_user', 'revoke_user_sessions', 'create_db_backup', 'db_maintenance'],
                        },
                        'target_id': {'type': 'integer', 'description': 'Company ID or User ID.'},
                        'maintenance_action': {'type': 'string', 'enum': ['integrity_check', 'analyze', 'vacuum']},
                    },
                    'required': ['action'],
                },
            },
        },
        {
            'type': 'function',
            'function': {
                'name': 'generate_global_report',
                'description': 'Generate a REAL downloadable PDF, Excel (.xlsx), or CSV report from live global platform data (companies, users, audit_logs, database_tables, or any company dataset).',
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'format_type': {'type': 'string', 'enum': ['pdf', 'excel', 'csv']},
                        'target': {
                            'type': 'string',
                            'enum': ['all', 'companies', 'users', 'audit_logs', 'database_tables', 'company_financials', 'company_inventory', 'company_employees'],
                        },
                        'title': {'type': 'string'},
                        'company_id': {'type': 'integer'},
                    },
                    'required': ['format_type', 'target'],
                },
            },
        },
        {
            'type': 'function',
            'function': {
                'name': 'manage_superadmin_automations',
                'description': 'Create, list, run, pause/resume, or delete real recurring Superadmin automations supporting custom seconds (min 5s), minutes, hours, or days.',
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'action': {'type': 'string', 'enum': ['create', 'list', 'run_now', 'toggle', 'delete']},
                        'name': {'type': 'string'},
                        'prompt': {'type': 'string'},
                        'interval_seconds': {'type': 'integer'},
                        'interval_minutes': {'type': 'number'},
                        'interval_hours': {'type': 'number'},
                        'interval_days': {'type': 'number'},
                        'automation_id': {'type': 'integer'},
                        'run_immediately': {'type': 'boolean'},
                    },
                    'required': ['action'],
                },
            },
        },
        {
            'type': 'function',
            'function': {
                'name': 'navigate_superadmin_page',
                'description': 'Navigate the Superadmin browser ONLY when the user explicitly asks to open or go to a Superadmin page.',
                'parameters': {
                    'type': 'object',
                    'properties': {
                        'destination': {'type': 'string'},
                    },
                    'required': ['destination'],
                },
            },
        },
    ]


def _resolve_sa_navigation(dest: str) -> dict | None:
    low = (dest or '').strip().lower()
    if not low:
        return None
    for r in SUPERADMIN_ROUTES:
        if low == r['url'].lower() or low == r['label'].lower() or any(k in low for k in r['keywords']):
            return {'type': 'navigate', 'url': r['url'], 'label': r['label'], 'loading_message': f"Opening {r['label']}..."}
    return None


def _execute_superadmin_tool(fn_name: str, args: dict, user_id: int, action_box: dict, downloads_out: list) -> dict:
    args = args if isinstance(args, dict) else {}

    if fn_name == 'navigate_superadmin_page':
        nav = _resolve_sa_navigation(args.get('destination') or '')
        if nav:
            action_box['action'] = nav
            return {'success': True, 'navigated': nav['url'], 'label': nav['label']}
        return {'success': False, 'error': 'Unknown Superadmin destination.'}

    if fn_name == 'execute_readonly_sql':
        return SuperadminDBService.execute_sql_query(args.get('sql') or '', allow_write=False, max_rows=100)

    if fn_name == 'query_global_platform':
        mod = (args.get('module') or 'platform_summary').strip().lower()
        cid = args.get('company_id')
        search = (args.get('search') or '').strip().lower()
        lim = max(1, min(100, int(args.get('limit') or 50)))

        if mod == 'platform_summary':
            db_ov = SuperadminDBService.get_database_overview()
            return {
                'total_companies': Company.query.count(),
                'total_users': User.query.count(),
                'total_departments': Department.query.count(),
                'total_employees': Employee.query.count(),
                'total_financial_records': FinancialRecord.query.count(),
                'total_inventory_skus': Inventory.query.count(),
                'total_customers': Customer.query.count(),
                'total_risks': Risk.query.count(),
                'total_audit_logs': GlobalAuditLog.query.count(),
                'database_tables': db_ov.get('table_count'),
                'database_total_rows': db_ov.get('total_rows'),
                'database_size_mb': (db_ov.get('engine_info') or {}).get('file_size_mb'),
            }

        if mod == 'database_overview':
            return SuperadminDBService.get_database_overview()

        if mod == 'companies':
            rows = Company.query.order_by(Company.id.asc()).limit(lim).all()
            out = []
            for c in rows:
                if search and search not in (c.company_name or '').lower():
                    continue
                out.append({
                    'id': c.id,
                    'name': c.company_name,
                    'industry': getattr(c, 'industry', ''),
                    'currency': getattr(c, 'currency', 'USD'),
                    'status': getattr(c, 'effective_status', getattr(c, 'status', 'active')),
                    'plan_tier': getattr(c, 'plan_tier', 'enterprise'),
                    'user_count': User.query.filter_by(company_id=c.id).count(),
                })
            return {'count': len(out), 'companies': out}

        if mod == 'users':
            rows = User.query.order_by(User.id.asc()).limit(lim).all()
            out = []
            for u in rows:
                if search and search not in (u.username or '').lower() and search not in (u.email or '').lower():
                    continue
                out.append({
                    'id': u.id,
                    'username': u.username,
                    'email': u.email,
                    'role': u.role,
                    'company_id': u.company_id,
                    'is_active': bool(u.is_active),
                    'status': getattr(u, 'account_status', 'active'),
                    'last_login': str(u.last_login) if u.last_login else None,
                })
            return {'count': len(out), 'users': out}

        if mod == 'audit_logs':
            logs = GlobalAuditLog.query.order_by(GlobalAuditLog.id.desc()).limit(lim).all()
            return {
                'count': len(logs),
                'logs': [
                    {
                        'id': l.id,
                        'action': l.action,
                        'category': l.category,
                        'actor': getattr(l, 'actor_username', ''),
                        'details': (l.details or '')[:220],
                        'created_at': str(l.created_at),
                    }
                    for l in logs
                ],
            }

        if mod == 'platform_settings':
            settings = PlatformSetting.query.order_by(PlatformSetting.key.asc()).limit(lim).all()
            return {
                'count': len(settings),
                'settings': [
                    {'key': s.key, 'value': '[REDACTED]' if any(k in (s.key or '').lower() for k in ('key', 'secret', 'pass', 'token')) else s.value}
                    for s in settings
                ],
            }

        # Cross-company module inspection
        if mod == 'company_financials':
            q = FinancialRecord.query
            if cid:
                q = q.filter_by(company_id=int(cid))
            recs = q.order_by(FinancialRecord.id.desc()).limit(lim).all()
            return {
                'count': q.count(),
                'records': [{'id': r.id, 'company_id': r.company_id, 'date': str(r.transaction_date), 'type': r.transaction_type, 'category': r.category, 'amount': float(r.amount or 0)} for r in recs],
            }
        if mod == 'company_departments':
            q = Department.query
            if cid:
                q = q.filter_by(company_id=int(cid))
            rows = q.limit(lim).all()
            return {'count': len(rows), 'departments': [{'id': d.id, 'company_id': d.company_id, 'name': d.name, 'budget': float(d.budget or 0), 'spent': float(d.spent or 0)} for d in rows]}
        if mod == 'company_employees':
            q = Employee.query
            if cid:
                q = q.filter_by(company_id=int(cid))
            rows = q.limit(lim).all()
            return {'count': q.count(), 'employees': [{'id': e.id, 'company_id': e.company_id, 'name': f"{e.first_name or ''} {e.last_name or ''}".strip(), 'job_title': e.job_title, 'salary': float(e.salary or 0)} for e in rows]}
        if mod == 'company_inventory':
            q = Inventory.query
            if cid:
                q = q.filter_by(company_id=int(cid))
            rows = q.limit(lim).all()
            return {'count': q.count(), 'items': [{'sku': i.sku, 'company_id': i.company_id, 'name': i.name, 'on_hand': int(i.quantity_on_hand or 0), 'unit_cost': float(i.unit_cost or 0)} for i in rows]}
        if mod == 'company_customers':
            q = Customer.query
            if cid:
                q = q.filter_by(company_id=int(cid))
            rows = q.limit(lim).all()
            return {'count': q.count(), 'customers': [{'id': c.id, 'company_id': c.company_id, 'company_name': c.company_name, 'ltv': float(c.lifetime_value or 0)} for c in rows]}
        if mod == 'company_risks':
            q = Risk.query
            if cid:
                q = q.filter_by(company_id=int(cid))
            rows = q.limit(lim).all()
            return {'count': q.count(), 'risks': [{'id': r.id, 'company_id': r.company_id, 'name': r.name, 'level': r.risk_level, 'status': r.status} for r in rows]}

        return {'error': f"Unknown module '{mod}'"}

    if fn_name == 'manage_platform_entity':
        act = (args.get('action') or '').strip().lower()
        tid = args.get('target_id')
        actor = db.session.get(User, int(user_id)) if user_id else None
        if act == 'create_db_backup':
            res = SuperadminDBService.create_backup(actor_user=actor)
            if res.get('success') and res.get('download_url'):
                downloads_out.append({'title': res['filename'], 'format': 'DB', 'url': res['download_url']})
            return res
        if act == 'db_maintenance':
            return SuperadminDBService.run_maintenance(args.get('maintenance_action') or 'integrity_check', actor_user=actor)
        if act in ('suspend_company', 'activate_company') and tid:
            comp = db.session.get(Company, int(tid))
            if not comp:
                return {'success': False, 'error': 'Company not found.'}
            new_st = 'suspended' if act == 'suspend_company' else 'active'
            if hasattr(comp, 'status'):
                comp.status = new_st
            db.session.commit()
            return {'success': True, 'company_id': comp.id, 'company_name': comp.company_name, 'status': new_st}
        if act in ('suspend_user', 'activate_user') and tid:
            u = db.session.get(User, int(tid))
            if not u:
                return {'success': False, 'error': 'User not found.'}
            u.is_active = (act == 'activate_user')
            u.account_status = 'active' if u.is_active else 'suspended'
            db.session.commit()
            return {'success': True, 'user_id': u.id, 'username': u.username, 'status': u.account_status}
        if act == 'revoke_user_sessions' and tid:
            u = db.session.get(User, int(tid))
            if not u:
                return {'success': False, 'error': 'User not found.'}
            u.session_version = (u.session_version or 1) + 1
            db.session.commit()
            return {'success': True, 'user_id': u.id, 'username': u.username, 'message': 'All active sessions revoked.'}
        return {'success': False, 'error': f"Unsupported or incomplete action '{act}'"}

    if fn_name == 'generate_global_report':
        from services.agent_export_service import generate_custom_pdf_report, generate_multi_sheet_excel, generate_csv_export
        fmt = (args.get('format_type') or 'pdf').strip().lower()
        target = (args.get('target') or 'all').strip().lower()
        title = (args.get('title') or f"Global Superadmin {target.replace('_', ' ').title()} Report").strip()
        cid = args.get('company_id')

        def _ds(name):
            if name == 'companies':
                rows = Company.query.order_by(Company.id.asc()).all()
                return {'headers': ['ID', 'Organization', 'Industry', 'Currency', 'Plan', 'Users'], 'rows': [[c.id, c.company_name, getattr(c, 'industry', ''), getattr(c, 'currency', 'USD'), getattr(c, 'plan_tier', 'enterprise'), User.query.filter_by(company_id=c.id).count()] for c in rows]}
            if name == 'users':
                rows = User.query.order_by(User.id.asc()).all()
                return {'headers': ['ID', 'Username', 'Email', 'Role', 'Company ID', 'Status'], 'rows': [[u.id, u.username, u.email, u.role, u.company_id or 'GLOBAL', 'Active' if u.is_active else 'Inactive'] for u in rows]}
            if name == 'audit_logs':
                rows = GlobalAuditLog.query.order_by(GlobalAuditLog.id.desc()).limit(200).all()
                return {'headers': ['ID', 'Action', 'Category', 'Details', 'Timestamp'], 'rows': [[l.id, l.action, l.category, (l.details or '')[:120], str(l.created_at)] for l in rows]}
            if name == 'database_tables':
                ov = SuperadminDBService.get_database_overview()
                return {'headers': ['Table Name', 'Row Count', 'Columns'], 'rows': [[t['name'], t['row_count'], t['column_count']] for t in ov.get('tables') or []]}
            if name == 'company_inventory':
                q = Inventory.query.filter_by(company_id=int(cid)) if cid else Inventory.query
                return {'headers': ['Company ID', 'SKU', 'Item Name', 'On Hand', 'Unit Cost'], 'rows': [[i.company_id, i.sku, i.name, int(i.quantity_on_hand or 0), float(i.unit_cost or 0)] for i in q.limit(500).all()]}
            if name == 'company_employees':
                q = Employee.query.filter_by(company_id=int(cid)) if cid else Employee.query
                return {'headers': ['Company ID', 'Name', 'Job Title', 'Salary'], 'rows': [[e.company_id, f"{e.first_name or ''} {e.last_name or ''}".strip(), e.job_title or '', float(e.salary or 0)] for e in q.limit(500).all()]}
            if name == 'company_financials':
                q = FinancialRecord.query.filter_by(company_id=int(cid)) if cid else FinancialRecord.query
                return {'headers': ['Company ID', 'Date', 'Type', 'Category', 'Amount'], 'rows': [[r.company_id, str(r.transaction_date), r.transaction_type, r.category or '', float(r.amount or 0)] for r in q.order_by(FinancialRecord.id.desc()).limit(500).all()]}
            return _ds('companies')

        if target == 'all':
            sheets = {'Organizations': _ds('companies'), 'Global Users': _ds('users'), 'Database Tables': _ds('database_tables'), 'Recent Audit Logs': _ds('audit_logs')}
        else:
            sheets = {target.replace('_', ' ').title(): _ds(target)}

        if fmt == 'csv':
            first_spec = next(iter(sheets.values()))
            out = generate_csv_export(0, first_spec['headers'], first_spec['rows'], title=title)
        elif fmt == 'excel':
            out = generate_multi_sheet_excel('Ayevoryn Global Control Plane', 0, '$', sheets, title=title)
        else:
            out = generate_custom_pdf_report('Ayevoryn Global Control Plane', 0, '$', sheets, title=title)

        if out.get('export_uid'):
            out['download_url'] = f"/superadmin/api/exports/{out['export_uid']}"
            downloads_out.append({'title': title, 'format': fmt.upper(), 'url': out['download_url']})
        return out

    if fn_name == 'manage_superadmin_automations':
        act = (args.get('action') or 'list').strip().lower()
        if act == 'list':
            return {'automations': SuperadminPulseService.list_automations()}
        if act == 'create':
            return SuperadminPulseService.create_automation(
                user_id=user_id,
                name=args.get('name') or 'Superadmin Global Automation',
                task_type='custom_agent_prompt',
                prompt=args.get('prompt') or '',
                interval_seconds=args.get('interval_seconds'),
                interval_minutes=args.get('interval_minutes'),
                interval_hours=args.get('interval_hours'),
                interval_days=args.get('interval_days'),
                run_immediately=bool(args.get('run_immediately', True)),
            )
        aid = int(args.get('automation_id') or 0)
        if act == 'run_now':
            return SuperadminPulseService.run_automation_now(aid)
        if act == 'toggle':
            return SuperadminPulseService.toggle_automation(aid)
        if act == 'delete':
            return SuperadminPulseService.delete_automation(aid)
        return {'success': False, 'error': f"Unknown automation action '{act}'"}

    return {'error': f"Unknown Superadmin tool '{fn_name}'"}


class SuperadminPulseService:

    @staticmethod
    def list_conversations(user_id: int) -> list:
        ensure_superadmin_pulse_tables()
        rows = SuperadminConversation.query.filter_by(user_id=int(user_id)).order_by(SuperadminConversation.updated_at.desc()).limit(50).all()
        return [r.to_dict() for r in rows]

    @staticmethod
    def create_conversation(user_id: int, title: str = 'Global Control Plane Session') -> dict:
        ensure_superadmin_pulse_tables()
        c = SuperadminConversation(user_id=int(user_id), title=(title or 'Global Control Plane Session').strip()[:200])
        db.session.add(c)
        db.session.commit()
        return c.to_dict()

    @staticmethod
    def get_conversation(conv_id: int, user_id: int) -> dict | None:
        ensure_superadmin_pulse_tables()
        c = SuperadminConversation.query.filter_by(id=int(conv_id), user_id=int(user_id)).first()
        if not c:
            return None
        msgs = SuperadminMessage.query.filter_by(conversation_id=c.id).order_by(SuperadminMessage.id.asc()).all()
        return {'success': True, 'conversation': c.to_dict(), 'messages': [m.to_dict() for m in msgs]}

    @staticmethod
    def delete_conversation(conv_id: int, user_id: int) -> dict:
        ensure_superadmin_pulse_tables()
        c = SuperadminConversation.query.filter_by(id=int(conv_id), user_id=int(user_id)).first()
        if not c:
            return {'success': False, 'error': 'Conversation not found'}
        SuperadminMessage.query.filter_by(conversation_id=c.id).delete()
        db.session.delete(c)
        db.session.commit()
        return {'success': True}

    @staticmethod
    def process_turn(user_id: int, prompt: str, conversation_id=None, save_to_memory: bool = True) -> dict:
        ensure_superadmin_pulse_tables()
        clean_prompt = (prompt or '').strip()
        if not clean_prompt:
            return {'success': False, 'error': 'Please enter a prompt.'}

        conv = None
        if save_to_memory:
            if conversation_id:
                conv = SuperadminConversation.query.filter_by(id=int(conversation_id), user_id=int(user_id)).first()
            if not conv:
                conv = SuperadminConversation(user_id=int(user_id), title=clean_prompt[:64])
                db.session.add(conv)
                db.session.commit()
            db.session.add(SuperadminMessage(conversation_id=conv.id, role='user', content=clean_prompt))
            conv.updated_at = datetime.utcnow()
            db.session.commit()

        # Build bounded conversation history
        history_msgs = []
        if conv:
            prior = SuperadminMessage.query.filter_by(conversation_id=conv.id).order_by(SuperadminMessage.id.desc()).limit(10).all()
            for m in reversed(prior):
                history_msgs.append({'role': m.role, 'content': m.content})
        else:
            history_msgs = [{'role': 'user', 'content': clean_prompt}]

        # Live global snapshot for grounded context
        db_ov = SuperadminDBService.get_database_overview()
        global_snapshot = {
            'total_companies': Company.query.count(),
            'total_users': User.query.count(),
            'total_audit_logs': GlobalAuditLog.query.count(),
            'database_tables': db_ov.get('table_count'),
            'database_total_rows': db_ov.get('total_rows'),
            'database_size_mb': (db_ov.get('engine_info') or {}).get('file_size_mb'),
            'companies': [{'id': c.id, 'name': c.company_name} for c in Company.query.limit(20).all()],
        }

        system_prompt = (
            "You are Aevoryn Global Superadmin Pulse AI — the omniscient platform-wide AI agent for USMANIA TECHS PVT LTD.\n"
            "You have 100% live access to ALL organizations, global users, audit logs, database tables, SQL queries, online backups, global reports, and Superadmin automations.\n"
            "RULES:\n"
            "1. ALWAYS call your live tools (`query_global_platform`, `execute_readonly_sql`, `manage_platform_entity`, `generate_global_report`, `manage_superadmin_automations`, `navigate_superadmin_page`) to fetch exact real numbers. Never hallucinate data or URLs.\n"
            "2. Whenever the user asks for a PDF, Excel, or CSV report, ALWAYS call `generate_global_report` and return the real download link.\n"
            "3. Only call `navigate_superadmin_page` if the user explicitly asks to go to or open a page.\n"
            "4. If the user message includes `[ATTACHED FILE ANALYSIS`, analyze the attached document/image/video thoroughly.\n"
            f"LIVE PLATFORM SNAPSHOT: {json.dumps(global_snapshot)}"
        )

        tools = build_superadmin_tools()
        action_box = {}
        downloads_out = []
        tools_used = []

        def _exec(fn_name, fn_args):
            return _execute_superadmin_tool(fn_name, fn_args, user_id, action_box, downloads_out)

        cloud_text, provider_used, model_used, tokens, notice = PulseAIProviderManager.call_cloud_llm_if_configured(
            system_prompt=system_prompt,
            messages=history_msgs,
            timeout=35,
            max_tokens=2400,
            tools=tools,
            scope='app',
            action_out=action_box,
            tool_executor=_exec,
            tools_used_out=tools_used,
        )

        # Fallback real live summary if offline
        if not cloud_text:
            low = clean_prompt.lower()
            if any(k in low for k in ('take me', 'go to', 'open ', 'navigate')):
                nav = _resolve_sa_navigation(low)
                if nav:
                    action_box['action'] = nav
                    cloud_text = f"Navigating to **{nav['label']}** now."
            if not cloud_text:
                cloud_text = (
                    f"### Global Control Plane Live Snapshot\n"
                    f"- **Organizations:** {global_snapshot['total_companies']}\n"
                    f"- **Global Users:** {global_snapshot['total_users']}\n"
                    f"- **Database Tables:** {global_snapshot['database_tables']} ({global_snapshot['database_total_rows']:,} total rows, {global_snapshot['database_size_mb']} MB)\n"
                    f"- **Audit Trail Entries:** {global_snapshot['total_audit_logs']}\n"
                )

        if downloads_out:
            missing = [d for d in downloads_out if d['url'] not in cloud_text]
            if missing:
                links = '\n'.join(f"- **[Download {d['title']} ({d['format']})]({d['url']})**" for d in missing)
                cloud_text = cloud_text.rstrip() + f"\n\n#### Ready Downloads\n{links}"

        asst_dict = {'role': 'assistant', 'content': cloud_text, 'tool_calls': tools_used, 'downloads': downloads_out}
        if conv:
            am = SuperadminMessage(
                conversation_id=conv.id,
                role='assistant',
                content=cloud_text,
                tool_calls_json=json.dumps(tools_used),
                downloads_json=json.dumps(downloads_out),
            )
            db.session.add(am)
            conv.updated_at = datetime.utcnow()
            db.session.commit()
            asst_dict = am.to_dict()

        return {
            'success': True,
            'conversation': conv.to_dict() if conv else None,
            'conversation_id': conv.id if conv else None,
            'assistant_message': asst_dict,
            'markdown': cloud_text,
            'response': cloud_text,
            'tool_calls': tools_used,
            'downloads': downloads_out,
            'download_url': downloads_out[0]['url'] if downloads_out else None,
            'agent_action': action_box.get('action'),
            'navigation_action': action_box.get('action') if (action_box.get('action') or {}).get('type') == 'navigate' else None,
        }

    # ─── Superadmin Global Automations (Seconds / Minutes / Hours / Days + Per-Run History) ───
    @staticmethod
    def list_automations() -> list:
        ensure_superadmin_pulse_tables()
        rows = SuperadminAutomation.query.order_by(SuperadminAutomation.is_active.desc(), SuperadminAutomation.created_at.desc()).all()
        return [r.to_dict() for r in rows]

    @staticmethod
    def list_automation_runs(automation_id: int, limit: int = 50) -> list:
        ensure_superadmin_pulse_tables()
        rows = SuperadminAutomationRun.query.filter_by(automation_id=int(automation_id)).order_by(
            SuperadminAutomationRun.run_number.desc(), SuperadminAutomationRun.id.desc()
        ).limit(limit).all()
        return [r.to_dict() for r in rows]

    @staticmethod
    def create_automation(
        user_id: int,
        name: str,
        task_type: str = 'custom_agent_prompt',
        prompt: str = '',
        interval_seconds=None,
        interval_minutes=None,
        interval_hours=None,
        interval_days=None,
        run_immediately: bool = False,
    ) -> dict:
        ensure_superadmin_pulse_tables()
        try:
            if interval_seconds is not None and float(interval_seconds) > 0:
                secs = max(5, int(round(float(interval_seconds))))
            elif interval_minutes is not None and float(interval_minutes) > 0:
                secs = max(5, int(round(float(interval_minutes) * 60)))
            elif interval_hours is not None and float(interval_hours) > 0:
                secs = max(5, int(round(float(interval_hours) * 3600)))
            elif interval_days is not None and float(interval_days) > 0:
                secs = max(5, int(round(float(interval_days) * 86400)))
            else:
                secs = 3600
        except (TypeError, ValueError):
            secs = 3600

        now = datetime.utcnow()
        auto = SuperadminAutomation(
            user_id=int(user_id or 1),
            name=(name or 'Superadmin Global Automation').strip()[:200],
            task_type=(task_type or 'custom_agent_prompt').strip().lower(),
            prompt=(prompt or '').strip(),
            interval_seconds=secs,
            is_active=True,
            run_count=0,
            next_run_at=now + timedelta(seconds=secs),
            last_status='scheduled',
            last_result_summary=f"Scheduled every {secs} second(s).",
        )
        db.session.add(auto)
        db.session.commit()

        if run_immediately:
            return SuperadminPulseService.run_automation_now(auto.id)
        return {'success': True, 'automation': auto.to_dict()}

    @staticmethod
    def run_automation_now(automation_id: int) -> dict:
        ensure_superadmin_pulse_tables()
        auto = db.session.get(SuperadminAutomation, int(automation_id))
        if not auto:
            return {'success': False, 'error': 'Automation not found'}

        now = datetime.utcnow()
        started = time.monotonic()
        next_num = (auto.run_count or 0) + 1
        dl_url = None
        try:
            if auto.task_type == 'db_health_backup':
                ov = SuperadminDBService.get_database_overview()
                chk = SuperadminDBService.run_maintenance('integrity_check')
                bkp = SuperadminDBService.create_backup()
                dl_url = bkp.get('download_url')
                output_md = (
                    f"#### Global Run #{next_num} — {now.strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n"
                    f"- **Tables:** {ov.get('table_count')} | **Total Rows:** {ov.get('total_rows'):,}\n"
                    f"- **Integrity Check:** {chk.get('message', 'ok')}\n"
                    f"- **Online Backup:** {bkp.get('filename', 'Created')} ({bkp.get('size_mb', 0)} MB)\n"
                )
            else:
                agent_prompt = (auto.prompt or auto.name or 'Audit all organizations, global users, and database health.').strip()
                res = SuperadminPulseService.process_turn(
                    user_id=auto.user_id,
                    prompt=f"[GLOBAL AUTOMATION RUN #{next_num}: {auto.name}] {agent_prompt}",
                    save_to_memory=False,
                )
                dl_url = res.get('download_url')
                raw_md = (res.get('markdown') or 'Global automation completed.').strip()
                output_md = f"#### Global Run #{next_num} — {now.strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n{raw_md}"[:15000]

            auto.run_count = next_num
            auto.last_status = 'success'
            auto.last_run_at = now
            auto.next_run_at = now + timedelta(seconds=max(5, int(auto.interval_seconds or 3600)))
            auto.last_result_summary = output_md
            if dl_url:
                auto.last_download_url = dl_url

            db.session.add(SuperadminAutomationRun(
                automation_id=auto.id,
                run_number=next_num,
                status='success',
                duration_ms=max(1, int((time.monotonic() - started) * 1000)),
                output_markdown=output_md,
                download_url=dl_url,
                executed_at=now,
            ))
            db.session.commit()
            return {'success': True, 'automation': auto.to_dict()}
        except Exception as exc:
            err_md = f"#### Global Run #{next_num} Error — {now.strftime('%Y-%m-%d %H:%M:%S UTC')}\n\n{str(exc)[:600]}"
            auto.run_count = next_num
            auto.last_status = 'error'
            auto.last_run_at = now
            auto.next_run_at = now + timedelta(seconds=max(5, int(auto.interval_seconds or 3600)))
            auto.last_result_summary = err_md
            db.session.add(SuperadminAutomationRun(
                automation_id=auto.id,
                run_number=next_num,
                status='error',
                duration_ms=max(1, int((time.monotonic() - started) * 1000)),
                output_markdown=err_md,
                executed_at=now,
            ))
            db.session.commit()
            return {'success': False, 'error': str(exc), 'automation': auto.to_dict()}

    @staticmethod
    def toggle_automation(automation_id: int) -> dict:
        ensure_superadmin_pulse_tables()
        auto = db.session.get(SuperadminAutomation, int(automation_id))
        if not auto:
            return {'success': False, 'error': 'Automation not found'}
        auto.is_active = not bool(auto.is_active)
        if auto.is_active and (not auto.next_run_at or auto.next_run_at <= datetime.utcnow()):
            auto.next_run_at = datetime.utcnow() + timedelta(seconds=max(5, int(auto.interval_seconds or 3600)))
        db.session.commit()
        return {'success': True, 'automation': auto.to_dict()}

    @staticmethod
    def delete_automation(automation_id: int) -> dict:
        ensure_superadmin_pulse_tables()
        auto = db.session.get(SuperadminAutomation, int(automation_id))
        if not auto:
            return {'success': False, 'error': 'Automation not found'}
        SuperadminAutomationRun.query.filter_by(automation_id=auto.id).delete()
        db.session.delete(auto)
        db.session.commit()
        return {'success': True}

    @staticmethod
    def run_due_automations(app):
        if not _SA_RUN_LOCK.acquire(blocking=False):
            return
        try:
            with app.app_context():
                try:
                    ensure_superadmin_pulse_tables()
                    now = datetime.utcnow()
                    due = SuperadminAutomation.query.filter(
                        SuperadminAutomation.is_active == True,  # noqa: E712
                        SuperadminAutomation.next_run_at <= now,
                    ).all()
                    for auto in due:
                        SuperadminPulseService.run_automation_now(auto.id)
                except Exception:
                    db.session.rollback()
        finally:
            _SA_RUN_LOCK.release()

    @staticmethod
    def start_superadmin_automation_scheduler(app):
        global _SA_WORKER_THREAD
        if app.config.get('TESTING'):
            return
        if _SA_WORKER_THREAD is not None and _SA_WORKER_THREAD.is_alive():
            return

        def _loop():
            while True:
                time.sleep(3)
                try:
                    SuperadminPulseService.run_due_automations(app)
                except Exception:
                    pass

        t = threading.Thread(target=_loop, name='ayevoryn-superadmin-automations', daemon=True)
        t.start()
        _SA_WORKER_THREAD = t
