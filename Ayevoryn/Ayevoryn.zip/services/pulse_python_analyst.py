"""
AEVORYN PULSE AI — AUTONOMOUS PYTHON DATA ANALYST & CHART ENGINE (Cline-Style Code Interpreter)
Allows Pulse AI to write and execute safe, AST-validated Python scripts directly against the
authenticated company's LIVE tenant-isolated database snapshot (`data`) to compute any custom
metrics, statistical analyses, forecasts, matplotlib charts (PNG), multi-sheet Excel (.xlsx),
PDF reports, and CSV exports — with zero hardcoded chart templates and strict sandbox security.
"""

import ast
import collections
import datetime
import io
import json
import math
import statistics
import traceback
import uuid
from contextlib import redirect_stdout

from services.agent_export_service import (
    _safe_company_dir,
    cleanup_expired_exports,
    generate_csv_export,
    generate_custom_pdf_report,
    generate_multi_sheet_excel,
)

# Forbidden AST nodes, function calls, and dunder attributes for strict sandbox safety
_FORBIDDEN_IMPORTS = {
    'os', 'sys', 'subprocess', 'shutil', 'socket', 'http', 'urllib', 'requests',
    'pathlib', 'glob', 'tempfile', 'ctypes', 'importlib', 'builtins', 'inspect',
    'pickle', 'marshal', 'signal', 'multiprocessing', 'threading', 'pty', 'fcntl',
    'resource', 'sqlite3', 'sqlalchemy', 'flask', 'werkzeug',
}
_FORBIDDEN_CALLS = {
    'eval', 'exec', 'compile', 'open', '__import__', 'input', 'breakpoint',
    'globals', 'locals', 'vars', 'dir', 'getattr', 'setattr', 'delattr', 'memoryview',
}


def validate_python_code_ast(code: str):
    """Parse and validate Python code AST strictly before execution. Returns (tree, error_str)."""
    src = (code or '').strip()
    if not src:
        return None, 'Python code cannot be empty.'
    if len(src) > 12000:
        return None, 'Python code exceeds maximum length (12,000 chars).'
    try:
        tree = ast.parse(src, mode='exec')
    except SyntaxError as se:
        return None, f'SyntaxError at line {se.lineno}: {se.msg}'

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root_mod = (alias.name or '').split('.')[0]
                if root_mod in _FORBIDDEN_IMPORTS or root_mod not in ('math', 'statistics', 'datetime', 'collections', 'json', 're', 'itertools', 'functools'):
                    return None, f"Forbidden import '{alias.name}'. Use pre-loaded `data`, `plt`, `np`, `math`, `statistics`, `save_chart`, `save_excel`, `save_pdf`, `save_csv`."
        elif isinstance(node, ast.ImportFrom):
            root_mod = (node.module or '').split('.')[0]
            if root_mod in _FORBIDDEN_IMPORTS or root_mod not in ('math', 'statistics', 'datetime', 'collections', 'json', 're', 'itertools', 'functools'):
                return None, f"Forbidden import from '{node.module}'."
        elif isinstance(node, ast.Attribute):
            if (node.attr or '').startswith('__') and (node.attr or '').endswith('__'):
                return None, f"Access to dunder attribute '{node.attr}' is forbidden in sandbox."
        elif isinstance(node, ast.Name):
            if (node.id or '').startswith('__') and (node.id or '').endswith('__'):
                return None, f"Access to dunder identifier '{node.id}' is forbidden in sandbox."
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name) and node.func.id in _FORBIDDEN_CALLS:
                return None, f"Calling '{node.func.id}()' is forbidden in sandbox."
    return tree, None



def _load_forecasts(cid: int) -> list:
    try:
        from database.models.forecast import Forecast
        rows = Forecast.query.filter_by(company_id=cid).order_by(Forecast.id.desc()).limit(20).all()
        return [{'id': f.id, 'name': f.name, 'type': f.forecast_type, 'horizon_days': f.horizon_days, 'r2': f.accuracy_r2} for f in rows]
    except Exception:
        return []

def _load_simulations(cid: int) -> list:
    try:
        from database.models.simulation import Simulation
        rows = Simulation.query.filter_by(company_id=cid).order_by(Simulation.id.desc()).limit(20).all()
        return [{'id': s.id, 'name': s.name, 'revenue_before': float(s.revenue_before or 0), 'revenue_after': float(s.revenue_after or 0), 'profit_before': float(s.profit_before or 0), 'profit_after': float(s.profit_after or 0)} for s in rows]
    except Exception:
        return []

def _load_payments(cid: int) -> dict:
    try:
        from database.models.company_payments import CompanyPayments
        p = CompanyPayments.query.filter_by(company_id=cid).first()
        if not p:
            return {}
        return {'upi_id': p.upi_id or '', 'bank_name': p.bank_name or '', 'payment_terms': p.payment_terms or '', 'verification_status': p.upi_verification_status or ''}
    except Exception:
        return {}

def load_live_company_data_snapshot(company_id: int) -> dict:
    """Load 100% live, strictly company_id-scoped Python dicts for every company module."""
    from sqlalchemy import func
    from database.db import db
    from database.models.company import Company
    from database.models.department import Department
    from database.models.department_budget import DepartmentBudget
    from database.models.employee import Employee
    from database.models.financial import FinancialRecord, FinancialAccount
    from database.models.inventory import Inventory
    from database.models.customer import Customer
    from database.models.supplier import Supplier
    from database.models.risk import Risk
    from database.models.project import Project
    from config.constants import CURRENCY_SYMBOLS

    try:
        db.session.expire_all()
    except Exception:
        pass
    cid = int(company_id)
    comp = db.session.get(Company, cid)
    sym = CURRENCY_SYMBOLS.get((comp.currency if comp else 'USD') or 'USD', '$')

    depts = Department.query.filter_by(company_id=cid, is_active=True).order_by(Department.name.asc()).all()
    dept_map = {d.id: d.name for d in depts}
    active_budgets = {
        b.department_id: float(b.allocated_amount)
        for b in DepartmentBudget.query.filter_by(company_id=cid, status='active').all()
        if b.allocated_amount is not None
    }
    dept_exp_rows = (
        db.session.query(
            FinancialRecord.department_id,
            func.coalesce(func.sum(FinancialRecord.amount), 0.0).label('spent'),
            func.count(FinancialRecord.id).label('cnt'),
        )
        .filter(
            FinancialRecord.company_id == cid,
            FinancialRecord.transaction_type.in_(['expense', 'payroll', 'withdrawal', 'transfer_out']),
        )
        .group_by(FinancialRecord.department_id)
        .all()
    )
    live_spend = {r.department_id: float(r.spent or 0.0) for r in dept_exp_rows}
    live_tx_cnt = {r.department_id: int(r.cnt or 0) for r in dept_exp_rows}

    emps = Employee.query.filter_by(company_id=cid).order_by(Employee.id.asc()).all()
    emp_cnt_by_dept = collections.Counter(e.department_id for e in emps)

    departments_data = []
    for d in depts:
        alloc = float(active_budgets.get(d.id, d.budget or 0.0) or 0.0)
        spent = float(live_spend.get(d.id, 0.0))
        util = round((spent / alloc) * 100.0, 2) if alloc > 0 else (100.0 if spent > 0 else 0.0)
        departments_data.append({
            'id': d.id,
            'name': d.name,
            'code': d.code or '',
            'head_name': d.head_name or 'Unassigned',
            'budget': round(alloc, 2),
            'live_spent': round(spent, 2),
            'remaining': round(alloc - spent, 2),
            'utilization_pct': util,
            'tx_count': live_tx_cnt.get(d.id, 0),
            'employee_count': emp_cnt_by_dept.get(d.id, 0),
        })

    employees_data = [
        {
            'id': e.id,
            'employee_id': e.employee_id or str(e.id),
            'name': f"{e.first_name or ''} {e.last_name or ''}".strip() or f"Employee #{e.id}",
            'department_id': e.department_id,
            'department': dept_map.get(e.department_id, 'Unassigned'),
            'job_title': e.job_title or '',
            'email': e.email or '',
            'salary': round(float(e.salary or 0.0), 2),
            'status': (e.status or 'active').lower(),
        }
        for e in emps
    ]

    fin_rows = FinancialRecord.query.filter_by(company_id=cid).order_by(FinancialRecord.transaction_date.asc()).all()
    financials_data = [
        {
            'id': r.id,
            'date': r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '',
            'month': r.transaction_date.strftime('%Y-%m') if r.transaction_date else '',
            'type': (r.transaction_type or '').lower(),
            'category': r.category or 'General',
            'amount': round(float(r.amount or 0.0), 2),
            'department_id': r.department_id,
            'department': dept_map.get(r.department_id, 'Unassigned') if r.department_id else 'Unassigned',
            'description': r.description or '',
        }
        for r in fin_rows
    ]

    accounts_data = [
        {
            'id': a.id,
            'name': a.account_name,
            'type': a.account_type or '',
            'balance': round(float(a.current_balance or 0.0), 2),
            'is_active': bool(a.is_active),
        }
        for a in FinancialAccount.query.filter_by(company_id=cid).all()
    ]

    inventory_data = [
        {
            'sku': i.sku or '',
            'name': i.name or '',
            'category': i.category or 'General',
            'quantity': int(i.quantity_on_hand or 0),
            'reorder_point': int(i.reorder_point or 0),
            'unit_cost': round(float(i.unit_cost or 0.0), 2),
            'price': round(float(i.selling_price or 0.0), 2),
            'stock_value': round(int(i.quantity_on_hand or 0) * float(i.unit_cost or 0.0), 2),
        }
        for i in Inventory.query.filter_by(company_id=cid).all()
    ]

    customers_data = [
        {
            'id': c.id,
            'company': c.company_name or '',
            'name': f"{c.first_name or ''} {c.last_name or ''}".strip() or (c.company_name or ''),
            'segment': c.segment or 'General',
            'ltv': round(float(c.lifetime_value or 0.0), 2),
        }
        for c in Customer.query.filter_by(company_id=cid).all()
    ]

    suppliers_data = [
        {
            'id': s.id,
            'name': s.name or '',
            'category': s.category or 'General',
            'lead_time_days': int(s.lead_time_days or 0),
            'rating': round(float(s.rating or 0.0), 2),
        }
        for s in Supplier.query.filter_by(company_id=cid).all()
    ]

    risks_data = [
        {
            'id': rk.id,
            'name': rk.name or '',
            'category': rk.category or 'Operational',
            'level': (rk.risk_level or 'medium').lower(),
            'probability': float(rk.probability or 0.5),
            'impact': float(rk.impact or 0.5),
            'score': round(float(rk.risk_score or 0.0), 2),
            'status': (rk.status or 'active').lower(),
        }
        for rk in Risk.query.filter_by(company_id=cid).all()
    ]

    projects_data = [
        {
            'id': p.id,
            'name': p.name or '',
            'status': (p.status or '').lower(),
            'budget': round(float(p.budget or 0.0), 2),
            'spent': round(float(p.spent or 0.0), 2),
            'progress': round(float(p.progress or 0.0), 1),
        }
        for p in Project.query.filter_by(company_id=cid).all()
    ]

    tot_rev = sum(r['amount'] for r in financials_data if r['type'] in ('revenue', 'income', 'deposit'))
    tot_exp = sum(r['amount'] for r in financials_data if r['type'] in ('expense', 'payroll', 'withdrawal', 'transfer_out'))

    return {
        'company': {
            'id': cid,
            'name': comp.company_name if comp else 'Organization',
            'currency': (comp.currency if comp else 'USD') or 'USD',
            'symbol': sym,
            'annual_revenue': round(float(comp.annual_revenue or 0.0), 2) if comp else 0.0,
            'total_revenue': round(tot_rev, 2),
            'total_expenses': round(tot_exp, 2),
            'net_profit': round(tot_rev - tot_exp, 2),
            'total_cash': round(sum(a['balance'] for a in accounts_data if a['is_active']), 2),
        },
        'departments': departments_data,
        'employees': employees_data,
        'financials': financials_data,
        'accounts': accounts_data,
        'inventory': inventory_data,
        'customers': customers_data,
        'suppliers': suppliers_data,
        'risks': risks_data,
        'projects': projects_data,
        'forecasts': _load_forecasts(cid),
        'simulations': _load_simulations(cid),
        'payments_config': _load_payments(cid),
    }


def execute_python_data_analysis(company_id: int, code: str, data_snapshot: dict = None) -> dict:
    """
    Execute AST-validated Python data analysis & chart/report code against live company data.
    Returns stdout, computed result summary, and all generated PNG/PDF/XLSX/CSV download links.
    """
    tree, err = validate_python_code_ast(code)
    if err:
        return {'success': False, 'error': err}

    cid = int(company_id)
    data = data_snapshot if isinstance(data_snapshot, dict) else load_live_company_data_snapshot(cid)
    comp_name = data.get('company', {}).get('name', 'Organization')
    sym = data.get('company', {}).get('symbol', '$')

    plt = None
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as _plt
        _plt.close('all')
        _plt.rcParams.update({
            'figure.facecolor': '#FFFFFF',
            'axes.facecolor': '#F8FAFC',
            'axes.edgecolor': '#CBD5E1',
            'axes.labelcolor': '#1E293B',
            'axes.titleweight': 'bold',
            'axes.titlesize': 12,
            'axes.grid': True,
            'grid.color': '#94A3B8',
            'grid.linestyle': '--',
            'grid.alpha': 0.35,
            'xtick.color': '#334155',
            'ytick.color': '#334155',
            'font.size': 9,
            'figure.dpi': 200,
        })
        plt = _plt
    except Exception:
        plt = None

    np = None
    try:
        import numpy as _np
        np = _np
    except Exception:
        np = None

    generated_files = []

    def save_chart(fig=None, title='Ayevoryn Live Chart'):
        if plt is None:
            raise RuntimeError('matplotlib is not available on this host.')
        target_fig = fig if fig is not None else plt.gcf()
        uid = uuid.uuid4().hex[:16]
        out_path = _safe_company_dir(cid) / f"{uid}.png"
        target_fig.savefig(str(out_path), format='png', dpi=200, bbox_inches='tight', facecolor='#FFFFFF')
        plt.close(target_fig)
        cleanup_expired_exports()
        url = f"/pulse-ai/api/exports/{uid}"
        entry = {
            'title': str(title),
            'format': 'PNG',
            'url': url,
            'download_url': url,
            'markdown_image': f"![{title}]({url})",
        }
        generated_files.append(entry)
        return entry

    def save_excel(sheets_dict, charts_list=None, title='Custom Excel Report'):
        res = generate_multi_sheet_excel(comp_name, cid, sym, sheets_dict, title=str(title), charts=charts_list)
        if res.get('success'):
            generated_files.append({
                'title': res['title'],
                'format': 'XLSX',
                'url': res['download_url'],
                'download_url': res['download_url'],
            })
        return res

    def save_pdf(datasets_dict, charts_list=None, title='Custom PDF Report', summary='', recommendations=None, kpi_summary=None):
        res = generate_custom_pdf_report(
            comp_name, cid, sym, datasets_dict,
            title=str(title), charts=charts_list,
            kpi_summary=kpi_summary, executive_summary=summary,
            recommendations=recommendations,
        )
        if res.get('success'):
            generated_files.append({
                'title': res['title'],
                'format': 'PDF',
                'url': res['download_url'],
                'download_url': res['download_url'],
            })
        return res

    def save_csv(headers, rows, title='Custom CSV Export'):
        res = generate_csv_export(cid, headers, rows, title=str(title))
        if res.get('success'):
            generated_files.append({
                'title': res['title'],
                'format': 'CSV',
                'url': res['download_url'],
                'download_url': res['download_url'],
            })
        return res

    safe_builtins = {
        'abs': abs, 'all': all, 'any': any, 'bool': bool, 'dict': dict, 'enumerate': enumerate,
        'filter': filter, 'float': float, 'int': int, 'isinstance': isinstance, 'len': len,
        'list': list, 'map': map, 'max': max, 'min': min, 'pow': pow, 'print': print,
        'range': range, 'reversed': reversed, 'round': round, 'set': set, 'slice': slice,
        'sorted': sorted, 'str': str, 'sum': sum, 'tuple': tuple, 'zip': zip,
    }
    exec_globals = {
        '__builtins__': safe_builtins,
        'data': data,
        'plt': plt,
        'np': np,
        'math': math,
        'statistics': statistics,
        'datetime': datetime,
        'collections': collections,
        'json': json,
        'save_chart': save_chart,
        'save_excel': save_excel,
        'save_pdf': save_pdf,
        'save_csv': save_csv,
        'query_sql': lambda sql, max_rows=250: __import__('services.pulse_agent_tools', fromlist=['_execute_tenant_safe_sql'])._execute_tenant_safe_sql(cid, sql, max_rows=max_rows),
    }

    stdout_buf = io.StringIO()
    try:
        with redirect_stdout(stdout_buf):
            exec(compile(tree, '<pulse_python_analyst>', 'exec'), exec_globals, exec_globals)
        # Auto-capture any unclosed matplotlib figure if the LLM called plt.plot() without save_chart()
        if plt is not None and plt.get_fignums():
            save_chart(plt.gcf(), title=f"{comp_name} — Live Python Analytics Chart")
    except Exception as ex:
        if plt is not None:
            try:
                plt.close('all')
            except Exception:
                pass
        return {
            'success': False,
            'error': f'{type(ex).__name__}: {str(ex)[:350]}',
            'stdout': stdout_buf.getvalue()[:2000],
            'hint': 'Inspect the error and retry with corrected Python code using `data` keys: company, departments, employees, financials, accounts, inventory, customers, suppliers, risks, projects.',
        }

    primary_dl = generated_files[-1]['url'] if generated_files else None
    primary_fmt = generated_files[-1]['format'] if generated_files else None
    primary_title = generated_files[-1]['title'] if generated_files else None
    return {
        'success': True,
        'stdout': stdout_buf.getvalue()[:3000],
        'generated_files': generated_files,
        'download_url': primary_dl,
        'format': primary_fmt,
        'title': primary_title,
    }
