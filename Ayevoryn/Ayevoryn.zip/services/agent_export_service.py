"""
AEVORYN — SECURE AGENTIC EXCEL (.xlsx), CSV & LIVE-CHART PDF EXPORT SERVICE
Generates real, validated, tenant-scoped Excel workbooks (with Live Charts tab + native openpyxl charts),
RFC-4180 CSV files, and executive PDF reports with live matplotlib/vector charts, KPI strips,
executive summaries, and actionable recommendations.
Files are stored under instance/secure_exports/<company_id>/<uid>.<ext> and served ONLY via
authenticated, tenant-verified download endpoints (preventing IDOR and path traversal).
"""

import csv
import io
import os
import time
import uuid
from datetime import datetime
from pathlib import Path

EXPORT_TTL_HOURS = int(os.environ.get('AYEVORYN_EXPORT_TTL_HOURS', '24'))


def _get_export_root() -> Path:
    env_dir = os.environ.get('AYEVORYN_EXPORT_DIR', '').strip()
    if env_dir:
        root = Path(env_dir).expanduser().resolve() / 'secure_exports'
        root.mkdir(parents=True, exist_ok=True)
        return root
    try:
        from flask import current_app
        inst = Path(current_app.instance_path)
    except Exception:
        inst = Path('instance')
    root = inst / 'secure_exports'
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_company_dir(company_id: int) -> Path:
    d = _get_export_root() / f"company_{int(company_id)}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def cleanup_expired_exports(max_age_hours: int = None) -> int:
    """Delete expired export files older than max_age_hours safely inside secure_exports root."""
    ttl_hours = EXPORT_TTL_HOURS if max_age_hours is None else max_age_hours
    if ttl_hours <= 0:
        return 0
    cutoff = time.time() - (ttl_hours * 3600)
    root = _get_export_root().resolve()
    removed = 0
    for item in root.rglob('*'):
        try:
            resolved = item.resolve()
            if root not in resolved.parents:
                continue
            if resolved.is_file() and resolved.suffix.lower() in ('.xlsx', '.csv', '.pdf', '.png'):
                if resolved.stat().st_mtime < cutoff:
                    resolved.unlink(missing_ok=True)
                    removed += 1
        except Exception:
            continue
    return removed


def resolve_secure_export_file(company_id: int, export_uid: str, max_age_hours: int = None):
    """
    Strictly locate a generated export inside the authenticated user's company directory.
    Prevents path traversal, cross-tenant IDOR, and enforces TTL expiration.
    Returns (Path, mimetype, download_name) or (None, None, None).
    """
    clean_uid = ''.join(c for c in (export_uid or '') if c.isalnum() or c in ('-', '_'))
    if not clean_uid or len(clean_uid) < 8:
        return None, None, None
    ttl_hours = EXPORT_TTL_HOURS if max_age_hours is None else max_age_hours
    cutoff = time.time() - (ttl_hours * 3600) if ttl_hours and ttl_hours > 0 else 0
    cdir = _safe_company_dir(company_id)
    for ext, mime in (
        ('.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
        ('.csv', 'text/csv; charset=utf-8'),
        ('.pdf', 'application/pdf'),
        ('.png', 'image/png'),
    ):
        candidate = (cdir / f"{clean_uid}{ext}").resolve()
        if candidate.parent == cdir.resolve() and candidate.exists() and candidate.stat().st_size > 0:
            if cutoff and candidate.stat().st_mtime < cutoff:
                try:
                    candidate.unlink(missing_ok=True)
                except Exception:
                    pass
                return None, None, None
            return candidate, mime, f"Ayevoryn_Export_{clean_uid[:8]}{ext}"
    return None, None, None


def _render_live_chart_png(chart_spec: dict):
    """
    Render a real, high-DPI (180 DPI) matplotlib PNG chart strictly from live DB values.
    Supports chart_type: 'line', 'pie' / 'donut', 'bar'.
    Returns io.BytesIO PNG buffer or None if matplotlib is unavailable or no data points exist.
    """
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
    except Exception:
        return None

    ctype = (chart_spec.get('chart_type') or 'bar').strip().lower()
    title = str(chart_spec.get('title') or 'Live Analytics')
    labels = list(chart_spec.get('labels') or [])
    y_label = str(chart_spec.get('y_label') or '')
    palette = ['#0284C7', '#10B981', '#6366F1', '#F59E0B', '#EF4444', '#14B8A6', '#8B5CF6', '#EC4899']

    fig, ax = plt.subplots(figsize=(7.2, 3.4), dpi=180)
    fig.patch.set_facecolor('#FFFFFF')
    ax.set_facecolor('#F8FAFC')

    try:
        if ctype == 'line':
            series = chart_spec.get('series') or []
            if not labels or not series:
                plt.close(fig)
                return None
            x = list(range(len(labels)))
            for idx, s in enumerate(series):
                vals = [float(v or 0.0) for v in (s.get('values') or [])]
                if not vals:
                    continue
                col = s.get('color') or palette[idx % len(palette)]
                ax.plot(x[:len(vals)], vals, marker='o', linewidth=2.3, markersize=4.5, color=col, label=str(s.get('name') or f'Series {idx+1}'))
                ax.fill_between(x[:len(vals)], vals, alpha=0.10, color=col)
            ax.set_xticks(x)
            step = max(1, len(labels) // 8)
            ax.set_xticklabels([lbl if (i % step == 0 or i == len(labels) - 1) else '' for i, lbl in enumerate(labels)], fontsize=8, color='#334155', rotation=20, ha='right')
            if y_label:
                ax.set_ylabel(y_label, fontsize=8.5, color='#334155', fontweight='bold')
            ax.grid(True, linestyle='--', alpha=0.35, color='#94A3B8')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.legend(frameon=True, facecolor='#FFFFFF', edgecolor='#E2E8F0', fontsize=8, loc='upper left')
            ax.set_title(title, fontsize=11, fontweight='bold', color='#0F172A', pad=10)

        elif ctype in ('pie', 'donut'):
            values = [max(0.0, float(v or 0.0)) for v in (chart_spec.get('values') or [])]
            pairs = [(str(l)[:26], v) for l, v in zip(labels, values) if v > 0]
            if not pairs:
                plt.close(fig)
                return None
            pairs.sort(key=lambda kv: kv[1], reverse=True)
            if len(pairs) > 7:
                top = pairs[:6]
                pairs = top + [('Other', sum(v for _, v in pairs[6:]))]
            p_labels = [p[0] for p in pairs]
            p_vals = [p[1] for p in pairs]
            cols = [palette[i % len(palette)] for i in range(len(p_vals))]
            wedges, texts, autotexts = ax.pie(
                p_vals,
                labels=None,
                autopct=lambda pct: f'{pct:.1f}%' if pct >= 4 else '',
                startangle=130,
                colors=cols,
                pctdistance=0.76,
                wedgeprops=dict(width=0.46 if ctype == 'donut' else 1.0, edgecolor='#FFFFFF', linewidth=1.6),
            )
            for at in autotexts:
                at.set_color('#FFFFFF')
                at.set_fontsize(7.5)
                at.set_fontweight('bold')
            total_v = sum(p_vals)
            legend_labels = [f"{lbl} ({(val / total_v * 100):.1f}%)" for lbl, val in zip(p_labels, p_vals)]
            ax.legend(wedges, legend_labels, loc='center left', bbox_to_anchor=(1.02, 0.5), frameon=False, fontsize=8)
            ax.set_title(title, fontsize=11, fontweight='bold', color='#0F172A', pad=10)
            ax.axis('equal')

        elif ctype == 'heatmap':
            matrix = chart_spec.get('matrix') or []
            x_labels = chart_spec.get('x_labels') or ['Very Low', 'Low', 'Medium', 'High', 'Critical']
            y_labels = chart_spec.get('y_labels') or ['Very Low', 'Low', 'Medium', 'High', 'Critical']
            if not matrix:
                plt.close(fig)
                return None
            import numpy as np
            arr = np.array(matrix, dtype=float)
            # Color grid by risk severity zone (row+col intensity) + actual risk counts inside cells
            zone = np.zeros_like(arr)
            rows_n, cols_n = arr.shape
            for r_i in range(rows_n):
                for c_i in range(cols_n):
                    zone[r_i, c_i] = (r_i + 1) * (c_i + 1)
            ax.imshow(zone, cmap='RdYlGn_r', origin='lower', aspect='auto', alpha=0.82)
            cell_texts = chart_spec.get('cell_texts') or []
            for r_i in range(rows_n):
                for c_i in range(cols_n):
                    cnt = int(arr[r_i, c_i])
                    sub = ''
                    if r_i < len(cell_texts) and c_i < len(cell_texts[r_i]) and cell_texts[r_i][c_i]:
                        sub = f"\n{str(cell_texts[r_i][c_i])[:18]}"
                    lbl_txt = f"{cnt} risk{'s' if cnt != 1 else ''}{sub}" if cnt > 0 else '0'
                    ax.text(c_i, r_i, lbl_txt, ha='center', va='center', fontsize=7.5, fontweight='bold' if cnt > 0 else 'normal', color='#0F172A')
            ax.set_xticks(range(len(x_labels)))
            ax.set_xticklabels(x_labels, fontsize=8, color='#0F172A', fontweight='bold')
            ax.set_yticks(range(len(y_labels)))
            ax.set_yticklabels(y_labels, fontsize=8, color='#0F172A', fontweight='bold')
            ax.set_xlabel(chart_spec.get('x_title') or 'Impact Severity', fontsize=8.5, fontweight='bold', color='#334155')
            ax.set_ylabel(chart_spec.get('y_title') or 'Likelihood / Probability', fontsize=8.5, fontweight='bold', color='#334155')
            ax.set_title(title, fontsize=11, fontweight='bold', color='#0F172A', pad=10)

        else:
            series = chart_spec.get('series')
            if series:
                if not labels:
                    plt.close(fig)
                    return None
                n_s = len(series)
                x = list(range(len(labels)))
                width = 0.72 / max(1, n_s)
                for idx, s in enumerate(series):
                    vals = [float(v or 0.0) for v in (s.get('values') or [])]
                    col = s.get('color') or palette[idx % len(palette)]
                    offsets = [xi - 0.36 + (idx + 0.5) * width for xi in x[:len(vals)]]
                    ax.bar(offsets, vals, width=width * 0.92, color=col, label=str(s.get('name') or f'Series {idx+1}'))
                ax.set_xticks(x)
                ax.set_xticklabels([str(l)[:18] for l in labels], fontsize=8, color='#334155', rotation=20, ha='right')
                ax.legend(frameon=True, facecolor='#FFFFFF', edgecolor='#E2E8F0', fontsize=8)
            else:
                values = [float(v or 0.0) for v in (chart_spec.get('values') or [])]
                if not labels or not values:
                    plt.close(fig)
                    return None
                x = list(range(len(labels)))
                cols = [palette[i % len(palette)] for i in range(len(values))]
                bars = ax.bar(x, values, width=0.58, color=cols)
                ax.set_xticks(x)
                ax.set_xticklabels([str(l)[:18] for l in labels], fontsize=8, color='#334155', rotation=20, ha='right')
                for b, v in zip(bars, values):
                    ax.text(b.get_x() + b.get_width() / 2.0, b.get_height(), f"{v:,.1f}", ha='center', va='bottom', fontsize=7.5, color='#0F172A')
            if y_label:
                ax.set_ylabel(y_label, fontsize=8.5, color='#334155', fontweight='bold')
            ax.grid(True, axis='y', linestyle='--', alpha=0.35, color='#94A3B8')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.set_title(title, fontsize=11, fontweight='bold', color='#0F172A', pad=10)

        plt.tight_layout()
        buf = io.BytesIO()
        fig.savefig(buf, format='png', dpi=180, bbox_inches='tight', facecolor='#FFFFFF')
        plt.close(fig)
        buf.seek(0)
        return buf
    except Exception:
        plt.close(fig)
        return None


def _build_reportlab_vector_chart(chart_spec: dict, width: float = 460.0, height: float = 205.0):
    """
    Pure-ReportLab native vector chart builder (Line, Pie, Bar) requiring ZERO external
    plotting libraries. Guarantees crisp live-data charts inside every PDF on every OS.
    """
    try:
        from reportlab.lib import colors
        from reportlab.graphics.shapes import Drawing, String
        from reportlab.graphics.charts.linecharts import HorizontalLineChart
        from reportlab.graphics.charts.barcharts import VerticalBarChart
        from reportlab.graphics.charts.piecharts import Pie
        from reportlab.graphics.charts.legends import Legend
    except Exception:
        return None

    ctype = (chart_spec.get('chart_type') or 'bar').strip().lower()
    title = str(chart_spec.get('title') or 'Live Analytics')
    labels = [str(l)[:18] for l in (chart_spec.get('labels') or [])]
    palette = [
        colors.HexColor('#0284C7'),
        colors.HexColor('#10B981'),
        colors.HexColor('#6366F1'),
        colors.HexColor('#F59E0B'),
        colors.HexColor('#EF4444'),
        colors.HexColor('#14B8A6'),
        colors.HexColor('#8B5CF6'),
    ]

    d = Drawing(width, height)
    d.add(String(10, height - 15, title, fontName='Helvetica-Bold', fontSize=10, fillColor=colors.HexColor('#0F172A')))

    try:
        if ctype in ('pie', 'donut'):
            raw_vals = [max(0.0, float(v or 0.0)) for v in (chart_spec.get('values') or [])]
            pairs = [(l, v) for l, v in zip(labels, raw_vals) if v > 0]
            if not pairs:
                return None
            pairs.sort(key=lambda kv: kv[1], reverse=True)
            if len(pairs) > 6:
                pairs = pairs[:5] + [('Other', sum(v for _, v in pairs[5:]))]
            total_v = sum(v for _, v in pairs) or 1.0

            pie = Pie()
            pie.x = 24
            pie.y = 22
            pie.width = min(145, height - 50)
            pie.height = min(145, height - 50)
            pie.data = [v for _, v in pairs]
            pie.labels = [f"{(v / total_v * 100):.0f}%" for _, v in pairs]
            pie.sideLabels = False
            pie.simpleLabels = False
            for idx in range(len(pairs)):
                pie.slices[idx].fillColor = palette[idx % len(palette)]
                pie.slices[idx].strokeColor = colors.white
                pie.slices[idx].strokeWidth = 1.2
                pie.slices[idx].fontSize = 7.5
            d.add(pie)

            leg = Legend()
            leg.x = pie.x + pie.width + 24
            leg.y = height - 42
            leg.fontName = 'Helvetica'
            leg.fontSize = 8
            leg.dy = 12
            leg.deltay = 14
            leg.alignment = 'right'
            leg.columnMaximum = 7
            leg.colorNamePairs = [
                (palette[i % len(palette)], f"{lbl} ({(val / total_v * 100):.1f}%)")
                for i, (lbl, val) in enumerate(pairs)
            ]
            d.add(leg)
            return d

        elif ctype == 'line':
            series = chart_spec.get('series') or []
            data_rows, names = [], []
            for s in series:
                vals = [float(v or 0.0) for v in (s.get('values') or [])]
                if vals:
                    data_rows.append(vals)
                    names.append(str(s.get('name') or 'Series'))
            if not labels or not data_rows:
                return None
            lc = HorizontalLineChart()
            lc.x = 48
            lc.y = 32
            lc.width = width - 70
            lc.height = height - 68
            lc.data = data_rows
            lc.categoryAxis.categoryNames = labels
            lc.categoryAxis.labels.fontSize = 7
            lc.categoryAxis.labels.angle = 20
            lc.valueAxis.labels.fontSize = 7.5
            lc.valueAxis.valueMin = 0
            for idx in range(len(data_rows)):
                lc.lines[idx].strokeColor = palette[idx % len(palette)]
                lc.lines[idx].strokeWidth = 2.0
            d.add(lc)
            leg = Legend()
            leg.x = 52
            leg.y = height - 28
            leg.fontName = 'Helvetica-Bold'
            leg.fontSize = 7.5
            leg.dx = 8
            leg.dy = 6
            leg.deltax = 120
            leg.columnMaximum = 1
            leg.colorNamePairs = [(palette[i % len(palette)], names[i]) for i in range(len(names))]
            d.add(leg)
            return d

        elif ctype == 'heatmap':
            from reportlab.graphics.shapes import Rect
            matrix = chart_spec.get('matrix') or []
            x_labels = chart_spec.get('x_labels') or ['1', '2', '3', '4', '5']
            y_labels = chart_spec.get('y_labels') or ['1', '2', '3', '4', '5']
            if not matrix:
                return None
            rows_n = len(matrix)
            cols_n = len(matrix[0]) if rows_n else 0
            ox, oy = 62, 28
            gw = (width - 80) / max(1, cols_n)
            gh = (height - 58) / max(1, rows_n)
            for r_i in range(rows_n):
                d.add(String(8, oy + r_i * gh + gh * 0.35, str(y_labels[r_i])[:10], fontSize=7, fillColor=colors.HexColor('#334155')))
                for c_i in range(cols_n):
                    z = (r_i + 1) * (c_i + 1)
                    fill_hex = '#FCA5A5' if z >= 15 else ('#FDE68A' if z >= 8 else '#BBF7D0')
                    d.add(Rect(ox + c_i * gw, oy + r_i * gh, gw - 2, gh - 2, fillColor=colors.HexColor(fill_hex), strokeColor=colors.white, strokeWidth=1))
                    cnt = int(matrix[r_i][c_i])
                    d.add(String(ox + c_i * gw + gw * 0.38, oy + r_i * gh + gh * 0.36, str(cnt), fontName='Helvetica-Bold' if cnt > 0 else 'Helvetica', fontSize=8, fillColor=colors.HexColor('#0F172A')))
            for c_i in range(cols_n):
                d.add(String(ox + c_i * gw + 4, 12, str(x_labels[c_i])[:10], fontSize=7, fillColor=colors.HexColor('#334155')))
            return d

        else:
            series = chart_spec.get('series')
            data_rows, names = [], []
            if series:
                for s in series:
                    vals = [float(v or 0.0) for v in (s.get('values') or [])]
                    if vals:
                        data_rows.append(vals)
                        names.append(str(s.get('name') or 'Series'))
            else:
                vals = [float(v or 0.0) for v in (chart_spec.get('values') or [])]
                if vals:
                    data_rows.append(vals)
                    names.append(title[:24])
            if not labels or not data_rows:
                return None
            bc = VerticalBarChart()
            bc.x = 48
            bc.y = 34
            bc.width = width - 70
            bc.height = height - 70
            bc.data = data_rows
            bc.categoryAxis.categoryNames = labels
            bc.categoryAxis.labels.fontSize = 7
            bc.categoryAxis.labels.angle = 18
            bc.valueAxis.labels.fontSize = 7.5
            bc.valueAxis.valueMin = 0
            for idx in range(len(data_rows)):
                bc.bars[idx].fillColor = palette[idx % len(palette)]
            d.add(bc)
            if len(names) > 1:
                leg = Legend()
                leg.x = 52
                leg.y = height - 28
                leg.fontName = 'Helvetica-Bold'
                leg.fontSize = 7.5
                leg.deltax = 115
                leg.columnMaximum = 1
                leg.colorNamePairs = [(palette[i % len(palette)], names[i]) for i in range(len(names))]
                d.add(leg)
            return d
    except Exception:
        return None


def generate_multi_sheet_excel(company_name: str, company_id: int, currency_symbol: str, datasets: dict, title: str = 'Company Performance Workbook', charts: list = None) -> dict:
    """
    Generate a styled multi-sheet Excel (.xlsx) workbook from real company datasets,
    with an optional first-tab 'Live Charts' sheet containing native openpyxl charts.
    """
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    wb.properties.creator = 'Ayevoryn by USMANIA TECHS PVT LTD'
    wb.properties.title = title
    wb.properties.subject = f'{company_name} — Verified Export'

    default_ws = wb.active
    added_any = False

    header_fill = PatternFill(start_color='0F172A', end_color='0F172A', fill_type='solid')
    header_font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    title_font = Font(name='Calibri', size=14, bold=True, color='0F172A')
    sub_font = Font(name='Calibri', size=10, italic=True, color='475569')
    thin_border = Border(
        bottom=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='E2E8F0'),
        left=Side(style='thin', color='E2E8F0'),
        right=Side(style='thin', color='E2E8F0'),
    )
    zebra_fill = PatternFill(start_color='F8FAFC', end_color='F8FAFC', fill_type='solid')

    total_rows = 0
    sheet_names = []

    for sheet_name, spec in (datasets or {}).items():
        headers = spec.get('headers') or []
        rows = spec.get('rows') or []
        if not headers:
            continue
        safe_sheet = ''.join(c for c in str(sheet_name) if c not in r'[]:*?/\\')[:31] or 'Sheet'
        ws = wb.create_sheet(title=safe_sheet)
        added_any = True
        sheet_names.append(safe_sheet)
        total_rows += len(rows)

        ws['A1'] = f"{company_name} — {sheet_name}"
        ws['A1'].font = title_font
        ws['A2'] = f"Generated by Ayevoryn (USMANIA TECHS PVT LTD) on {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} | Currency: {currency_symbol}"
        ws['A2'].font = sub_font

        for col_idx, h in enumerate(headers, start=1):
            cell = ws.cell(row=4, column=col_idx, value=str(h))
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='left', vertical='center')
            cell.border = thin_border
        ws.row_dimensions[4].height = 24

        for r_idx, row_vals in enumerate(rows, start=5):
            for c_idx, val in enumerate(row_vals, start=1):
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                cell.border = thin_border
                if r_idx % 2 == 1:
                    cell.fill = zebra_fill
                if isinstance(val, (int, float)):
                    cell.alignment = Alignment(horizontal='right', vertical='center')
                else:
                    cell.alignment = Alignment(horizontal='left', vertical='center')

        for col_idx, h in enumerate(headers, start=1):
            max_len = len(str(h))
            for row_vals in rows[:200]:
                if col_idx - 1 < len(row_vals):
                    max_len = max(max_len, len(str(row_vals[col_idx - 1] or '')))
            ws.column_dimensions[get_column_letter(col_idx)].width = min(44, max(12, max_len + 4))

        ws.freeze_panes = 'A5'
        last_col = get_column_letter(len(headers))
        last_row = max(4, 4 + len(rows))
        ws.auto_filter.ref = f"A4:{last_col}{last_row}"

    charts_rendered = []
    if charts:
        from openpyxl.chart import LineChart, PieChart, BarChart, Reference
        cws = wb.create_sheet(title='Live Charts', index=0)
        added_any = True
        sheet_names.insert(0, 'Live Charts')
        row_cursor = 1
        for cspec in charts[:6]:
            ctype = (cspec.get('chart_type') or 'bar').strip().lower()
            ctitle = str(cspec.get('title') or 'Live Chart')
            labels = list(cspec.get('labels') or [])
            if not labels:
                continue
            start_r = row_cursor
            if cspec.get('series'):
                series_list = cspec['series']
                cws.cell(row=row_cursor, column=1, value=ctitle).font = header_font
                cws.cell(row=row_cursor, column=1).fill = header_fill
                for s_idx, s in enumerate(series_list, start=2):
                    c = cws.cell(row=row_cursor, column=s_idx, value=str(s.get('name') or f'Series {s_idx-1}'))
                    c.font = header_font
                    c.fill = header_fill
                row_cursor += 1
                for i, lbl in enumerate(labels):
                    cws.cell(row=row_cursor, column=1, value=str(lbl))
                    for s_idx, s in enumerate(series_list, start=2):
                        vals = s.get('values') or []
                        cws.cell(row=row_cursor, column=s_idx, value=float(vals[i]) if i < len(vals) else 0.0)
                    row_cursor += 1
                end_r = row_cursor - 1
                ch = LineChart() if ctype == 'line' else BarChart()
                ch.title = ctitle
                ch.style = 10
                ch.width = 18
                ch.height = 9
                data_ref = Reference(cws, min_col=2, max_col=1 + len(series_list), min_row=start_r, max_row=end_r)
                cats_ref = Reference(cws, min_col=1, min_row=start_r + 1, max_row=end_r)
                ch.add_data(data_ref, titles_from_data=True)
                ch.set_categories(cats_ref)
                cws.add_chart(ch, f"F{start_r}")
                charts_rendered.append(ctitle)
            elif cspec.get('values'):
                vals = [float(v or 0.0) for v in cspec['values']]
                cws.cell(row=row_cursor, column=1, value='Category').font = header_font
                cws.cell(row=row_cursor, column=1).fill = header_fill
                cws.cell(row=row_cursor, column=2, value=ctitle).font = header_font
                cws.cell(row=row_cursor, column=2).fill = header_fill
                row_cursor += 1
                for lbl, val in zip(labels, vals):
                    cws.cell(row=row_cursor, column=1, value=str(lbl))
                    cws.cell(row=row_cursor, column=2, value=val)
                    row_cursor += 1
                end_r = row_cursor - 1
                ch = PieChart() if ctype in ('pie', 'donut') else BarChart()
                ch.title = ctitle
                ch.width = 16
                ch.height = 9
                data_ref = Reference(cws, min_col=2, min_row=start_r, max_row=end_r)
                cats_ref = Reference(cws, min_col=1, min_row=start_r + 1, max_row=end_r)
                ch.add_data(data_ref, titles_from_data=True)
                ch.set_categories(cats_ref)
                cws.add_chart(ch, f"F{start_r}")
                charts_rendered.append(ctitle)
            row_cursor += 15

    if added_any:
        wb.remove(default_ws)
    else:
        default_ws.title = 'Summary'
        default_ws['A1'] = f"{company_name} — No records available for export."

    uid = uuid.uuid4().hex[:16]
    out_path = _safe_company_dir(company_id) / f"{uid}.xlsx"
    wb.save(str(out_path))
    cleanup_expired_exports()

    return {
        'success': True,
        'export_uid': uid,
        'title': title,
        'format': 'XLSX',
        'sheets': sheet_names,
        'charts_rendered': charts_rendered,
        'row_count': total_rows,
        'file_size_bytes': out_path.stat().st_size,
        'download_url': f"/pulse-ai/api/exports/{uid}",
    }


def generate_csv_export(company_id: int, headers: list, rows: list, title: str = 'Company Data Export') -> dict:
    """Generate a real RFC-4180 CSV file stored under tenant-isolated secure_exports."""
    uid = uuid.uuid4().hex[:16]
    out_path = _safe_company_dir(company_id) / f"{uid}.csv"
    with open(out_path, 'w', newline='', encoding='utf-8') as f:
        writer = csv.writer(f)
        if headers:
            writer.writerow([str(h) for h in headers])
        for r in (rows or []):
            writer.writerow([v if v is not None else '' for v in r])
    cleanup_expired_exports()
    return {
        'success': True,
        'export_uid': uid,
        'title': title,
        'format': 'CSV',
        'row_count': len(rows or []),
        'file_size_bytes': out_path.stat().st_size,
        'download_url': f"/pulse-ai/api/exports/{uid}",
    }


def generate_custom_pdf_report(
    company_name: str,
    company_id: int,
    currency_symbol: str,
    datasets: dict,
    title: str = 'Ayevoryn Live Data Report',
    charts: list = None,
    kpi_summary: list = None,
    executive_summary: str = None,
    recommendations: list = None,
) -> dict:
    """
    Generate a real, multi-section, styled PDF report from ANY live company dataset(s)
    with embedded live-data Line/Pie/Bar charts (matplotlib PNG with pure-ReportLab native
    vector fallback), Executive Summary, KPI Strip, and Actionable Recommendations.
    """
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import landscape, letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image as RLImage

    uid = uuid.uuid4().hex[:16]
    cdir = _safe_company_dir(company_id)
    out_path = cdir / f"{uid}.pdf"

    doc = SimpleDocTemplate(
        str(out_path),
        pagesize=landscape(letter),
        leftMargin=0.45 * inch,
        rightMargin=0.45 * inch,
        topMargin=0.5 * inch,
        bottomMargin=0.5 * inch,
        title=title,
        author='Ayevoryn by USMANIA TECHS PVT LTD',
    )
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(
        'AyevTitle', parent=styles['Title'], fontSize=18, leading=22,
        textColor=colors.HexColor('#0F172A'), alignment=0, spaceAfter=4
    )
    sub_style = ParagraphStyle(
        'AyevSub', parent=styles['Normal'], fontSize=9.5, leading=13,
        textColor=colors.HexColor('#475569'), spaceAfter=10
    )
    sec_style = ParagraphStyle(
        'AyevSec', parent=styles['Heading2'], fontSize=12.5, leading=16,
        textColor=colors.HexColor('#0284C7'), spaceBefore=10, spaceAfter=6
    )
    cell_style = ParagraphStyle(
        'AyevCell', parent=styles['Normal'], fontSize=8.5, leading=11.5,
        textColor=colors.HexColor('#1E293B')
    )
    hdr_style = ParagraphStyle(
        'AyevHdr', parent=styles['Normal'], fontSize=8.5, leading=11,
        textColor=colors.white, fontName='Helvetica-Bold'
    )

    story = [
        Paragraph(f"{company_name} — {title}", title_style),
        Paragraph(
            f"Generated live by Ayevoryn Pulse AI (USMANIA TECHS PVT LTD) &bull; "
            f"{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} &bull; Currency: {currency_symbol}",
            sub_style
        ),
    ]

    avail_w = landscape(letter)[0] - 0.9 * inch

    if kpi_summary:
        kpi_cells = []
        for k in kpi_summary[:5]:
            kpi_cells.append(
                Paragraph(
                    f"<font size='7.5' color='#64748B'><b>{k.get('label', '')}</b></font><br/>"
                    f"<font size='12' color='#0F172A'><b>{k.get('value', '')}</b></font>",
                    cell_style,
                )
            )
        if kpi_cells:
            ktbl = Table([kpi_cells], colWidths=[avail_w / len(kpi_cells)] * len(kpi_cells))
            ktbl.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F1F5F9')),
                ('BOX', (0, 0), (-1, -1), 0.6, colors.HexColor('#CBD5E1')),
                ('INNERGRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#E2E8F0')),
                ('TOPPADDING', (0, 0), (-1, -1), 8),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
                ('LEFTPADDING', (0, 0), (-1, -1), 10),
                ('RIGHTPADDING', (0, 0), (-1, -1), 10),
            ]))
            story.append(ktbl)
            story.append(Spacer(1, 10))

    if executive_summary:
        story.append(Paragraph("Executive Summary", sec_style))
        story.append(Paragraph(str(executive_summary).replace('\n', '<br/>'), cell_style))
        story.append(Spacer(1, 8))

    charts_rendered = []
    if charts:
        rendered_flowables = []
        for cspec in charts[:6]:
            ctitle = str(cspec.get('title') or cspec.get('chart_type') or 'Live Chart')
            buf = _render_live_chart_png(cspec)
            if buf is not None:
                charts_rendered.append(ctitle)
                rendered_flowables.append((cspec, 'img', buf))
            else:
                vec = _build_reportlab_vector_chart(cspec, width=455.0, height=205.0)
                if vec is not None:
                    charts_rendered.append(ctitle)
                    rendered_flowables.append((cspec, 'vec', vec))

        if rendered_flowables:
            story.append(Paragraph("Live Visual Analytics (Generated from Real Company Database Records)", sec_style))
            idx_c = 0
            while idx_c < len(rendered_flowables):
                c1, k1, obj1 = rendered_flowables[idx_c]
                if idx_c + 1 < len(rendered_flowables):
                    c2, k2, obj2 = rendered_flowables[idx_c + 1]
                    f1 = RLImage(obj1, width=4.85 * inch, height=2.45 * inch) if k1 == 'img' else _build_reportlab_vector_chart(c1, width=340.0, height=185.0)
                    f2 = RLImage(obj2, width=4.85 * inch, height=2.45 * inch) if k2 == 'img' else _build_reportlab_vector_chart(c2, width=340.0, height=185.0)
                    row_tbl = Table([[f1, f2]], colWidths=[5.0 * inch, 5.0 * inch])
                    row_tbl.setStyle(TableStyle([('VALIGN', (0, 0), (-1, -1), 'MIDDLE'), ('LEFTPADDING', (0, 0), (-1, -1), 2), ('RIGHTPADDING', (0, 0), (-1, -1), 2)]))
                    story.append(row_tbl)
                    story.append(Spacer(1, 8))
                    idx_c += 2
                else:
                    f1 = RLImage(obj1, width=9.4 * inch, height=4.0 * inch) if k1 == 'img' else _build_reportlab_vector_chart(c1, width=660.0, height=240.0)
                    story.append(f1)
                    story.append(Spacer(1, 10))
                    idx_c += 1

    if recommendations:
        story.append(Paragraph("Actionable Recommendations & Risk Mitigation Tips", sec_style))
        for rec in recommendations[:8]:
            story.append(Paragraph(f"&bull; {str(rec)}", cell_style))
        story.append(Spacer(1, 8))

    total_rows = 0
    sections_included = []
    for sec_name, spec in (datasets or {}).items():
        headers = spec.get('headers') or []
        rows = spec.get('rows') or []
        if not headers:
            continue
        sections_included.append(sec_name)
        total_rows += len(rows)
        story.append(Paragraph(f"{sec_name} ({len(rows)} record{'s' if len(rows) != 1 else ''})", sec_style))

        if not rows:
            story.append(Paragraph("No records currently stored in this module.", sub_style))
            continue

        table_data = [[Paragraph(str(h), hdr_style) for h in headers]]
        for r in rows[:250]:
            table_data.append([Paragraph(str(v if v is not None else ''), cell_style) for v in r[:len(headers)]])

        col_w = avail_w / max(1, len(headers))
        tbl = Table(table_data, colWidths=[col_w] * len(headers), repeatRows=1)
        tbl.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0F172A')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
            ('GRID', (0, 0), (-1, -1), 0.4, colors.HexColor('#CBD5E1')),
            ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
            ('TOPPADDING', (0, 0), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
            ('LEFTPADDING', (0, 0), (-1, -1), 6),
            ('RIGHTPADDING', (0, 0), (-1, -1), 6),
        ]))
        story.append(tbl)
        story.append(Spacer(1, 10))

    if not sections_included:
        story.append(Paragraph("No matching live records were found for the requested scope.", sub_style))

    story.append(Spacer(1, 8))
    story.append(Paragraph(
        "&copy; 2026 USMANIA TECHS PVT LTD &middot; Ayevoryn Enterprise Digital Twin &amp; Financial Intelligence",
        ParagraphStyle('AyevFoot', parent=styles['Normal'], fontSize=8, textColor=colors.HexColor('#64748B'))
    ))

    doc.build(story)
    cleanup_expired_exports()
    return {
        'success': True,
        'export_uid': uid,
        'title': title,
        'format': 'PDF',
        'sections': sections_included,
        'charts_rendered': charts_rendered,
        'row_count': total_rows,
        'file_size_bytes': out_path.stat().st_size,
        'download_url': f"/pulse-ai/api/exports/{uid}",
    }



def generate_live_chart_image(company_name: str, company_id: int, chart_spec: dict, title: str = 'Ayevoryn Live Chart') -> dict:
    """Render a live-data chart to a tenant-isolated PNG image for inline display and download."""
    buf = _render_live_chart_png(chart_spec)
    if buf is None:
        return {'success': False, 'error': 'Insufficient live database records to plot the requested chart.'}
    uid = uuid.uuid4().hex[:16]
    out_path = _safe_company_dir(company_id) / f"{uid}.png"
    out_path.write_bytes(buf.getvalue())
    cleanup_expired_exports()
    url = f"/pulse-ai/api/exports/{uid}"
    return {
        'success': True,
        'export_uid': uid,
        'title': title,
        'format': 'PNG',
        'file_size_bytes': out_path.stat().st_size,
        'image_url': url,
        'download_url': url,
        'markdown_image': f"![{title}]({url})",
        'instructions': f"Embed this exact image inline in your reply: ![{title}]({url})",
    }
