"""
AEVORYN — SECURE AGENTIC EXCEL (.xlsx) & CSV EXPORT SERVICE
Generates real, validated, tenant-scoped Excel workbooks (with multiple sheets,
styled headers, currency formatting, frozen panes, auto-filters, and USMANIA TECHS PVT LTD metadata)
and RFC-4180 CSV files for authorized company users.
Files are stored under instance/secure_exports/<company_id>/<uid>.<ext> and served ONLY via
authenticated, tenant-verified download endpoints (preventing IDOR and path traversal).
"""

import csv
import io
import os
import time
import uuid
from datetime import datetime
from pathlib import Path

EXPORT_TTL_HOURS = int(os.environ.get('AYEVORYN_EXPORT_TTL_HOURS', '24'))


def _get_export_root() -> Path:
    env_dir = os.environ.get('AYEVORYN_EXPORT_DIR', '').strip()
    if env_dir:
        root = Path(env_dir).expanduser().resolve() / 'secure_exports'
        root.mkdir(parents=True, exist_ok=True)
        return root
    try:
        from flask import current_app
        inst = Path(current_app.instance_path)
    except Exception:
        inst = Path('instance')
    root = inst / 'secure_exports'
    root.mkdir(parents=True, exist_ok=True)
    return root


def _safe_company_dir(company_id: int) -> Path:
    d = _get_export_root() / f"company_{int(company_id)}"
    d.mkdir(parents=True, exist_ok=True)
    return d


def cleanup_expired_exports(max_age_hours: int = None) -> int:
    """Delete expired export files older than max_age_hours safely inside secure_exports root."""
    ttl_hours = EXPORT_TTL_HOURS if max_age_hours is None else max_age_hours
    if ttl_hours <= 0:
        return 0
    cutoff = time.time() - (ttl_hours * 3600)
    root = _get_export_root().resolve()
    removed = 0
    for item in root.rglob('*'):
        try:
            resolved = item.resolve()
            if root not in resolved.parents:
                continue
            if resolved.is_file() and resolved.suffix.lower() in ('.xlsx', '.csv', '.pdf'):
                if resolved.stat().st_mtime < cutoff:
                    resolved.unlink(missing_ok=True)
                    removed += 1
        except Exception:
            continue
    return removed


def resolve_secure_export_file(company_id: int, export_uid: str, max_age_hours: int = None):
    """
    Strictly locate a generated export inside the authenticated user's company directory.
    Prevents path traversal, cross-tenant IDOR, and enforces TTL expiration.
    Returns (Path, mimetype, download_name) or (None, None, None).
    """
    clean_uid = ''.join(c for c in (export_uid or '') if c.isalnum() or c in ('-', '_'))
    if not clean_uid or len(clean_uid) < 8:
        return None, None, None
    ttl_hours = EXPORT_TTL_HOURS if max_age_hours is None else max_age_hours
    cutoff = time.time() - (ttl_hours * 3600) if ttl_hours and ttl_hours > 0 else 0
    cdir = _safe_company_dir(company_id)
    for ext, mime in (
        ('.xlsx', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
        ('.csv', 'text/csv; charset=utf-8'),
        ('.pdf', 'application/pdf'),
    ):
        candidate = (cdir / f"{clean_uid}{ext}").resolve()
        if candidate.parent == cdir.resolve() and candidate.exists() and candidate.stat().st_size > 0:
            if cutoff and candidate.stat().st_mtime < cutoff:
                try:
                    candidate.unlink(missing_ok=True)
                except Exception:
                    pass
                return None, None, None
            return candidate, mime, f"Ayevoryn_Export_{clean_uid[:8]}{ext}"
    return None, None, None


def generate_multi_sheet_excel(company_name: str, company_id: int, currency_symbol: str, datasets: dict, title: str = 'Company Performance Workbook') -> dict:
    """
    Generate a styled multi-sheet Excel (.xlsx) workbook from real company datasets.
    `datasets`: dict mapping sheet_name -> {'headers': [...], 'rows': [[...], ...]}
    """
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    wb.properties.creator = 'Ayevoryn by USMANIA TECHS PVT LTD'
    wb.properties.title = title
    wb.properties.subject = f'{company_name} — Verified Export'

    # Remove default sheet once we add real sheets
    default_ws = wb.active
    added_any = False

    header_fill = PatternFill(start_color='0F172A', end_color='0F172A', fill_type='solid')
    header_font = Font(name='Calibri', size=11, bold=True, color='FFFFFF')
    title_font = Font(name='Calibri', size=14, bold=True, color='0F172A')
    sub_font = Font(name='Calibri', size=10, italic=True, color='475569')
    thin_border = Border(
        bottom=Side(style='thin', color='CBD5E1'),
        top=Side(style='thin', color='E2E8F0'),
        left=Side(style='thin', color='E2E8F0'),
        right=Side(style='thin', color='E2E8F0'),
    )
    zebra_fill = PatternFill(start_color='F8FAFC', end_color='F8FAFC', fill_type='solid')

    for sheet_name, spec in (datasets or {}).items():
        headers = spec.get('headers') or []
        rows = spec.get('rows') or []
        if not headers:
            continue
        safe_sheet = ''.join(c for c in str(sheet_name) if c not in r'[]:*?/\\')[:31] or 'Sheet'
        ws = wb.create_sheet(title=safe_sheet)
        added_any = True

        # Title block
        ws['A1'] = f"{company_name} — {sheet_name}"
        ws['A1'].font = title_font
        ws['A2'] = f"Generated by Ayevoryn (USMANIA TECHS PVT LTD) on {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} | Currency: {currency_symbol}"
        ws['A2'].font = sub_font

        # Header row at row 4
        for col_idx, h in enumerate(headers, start=1):
            cell = ws.cell(row=4, column=col_idx, value=str(h))
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='left', vertical='center')
            cell.border = thin_border
        ws.row_dimensions[4].height = 24

        # Data rows
        for r_idx, row_vals in enumerate(rows, start=5):
            for c_idx, val in enumerate(row_vals, start=1):
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                cell.border = thin_border
                if r_idx % 2 == 1:
                    cell.fill = zebra_fill
                if isinstance(val, (int, float)):
                    cell.alignment = Alignment(horizontal='right', vertical='center')
                else:
                    cell.alignment = Alignment(horizontal='left', vertical='center')

        # Auto-fit column widths + freeze header + autofilter
        for col_idx, h in enumerate(headers, start=1):
            max_len = len(str(h))
            for row_vals in rows[:200]:
                if col_idx - 1 < len(row_vals):
                    max_len = max(max_len, len(str(row_vals[col_idx - 1] or '')))
            ws.column_dimensions[get_column_letter(col_idx)].width = min(44, max(12, max_len + 4))

        ws.freeze_panes = 'A5'
        last_col = get_column_letter(len(headers))
        last_row = max(4, 4 + len(rows))
        ws.auto_filter.ref = f"A4:{last_col}{last_row}"

    if added_any:
        wb.remove(default_ws)
    else:
        default_ws.title = 'Summary'
        default_ws['A1'] = f"{company_name} — No records available for export."

    uid = uuid.uuid4().hex[:16]
    out_path = _safe_company_dir(company_id) / f"{uid}.xlsx"
    wb.save(str(out_path))
    size_bytes = out_path.stat().st_size if out_path.exists() else 0
    if size_bytes == 0:
        return {'success': False, 'error': 'Generated Excel file is empty.'}

    return {
        'success': True,
        'export_uid': uid,
        'format': 'XLSX',
        'sheets': wb.sheetnames,
        'size_bytes': size_bytes,
        'download_url': f"/pulse-ai/api/exports/{uid}",
        'title': title,
    }


def generate_csv_export(company_id: int, headers: list, rows: list, title: str = 'Company Data Export') -> dict:
    """Generate a real UTF-8 CSV file with proper quoting and validate non-zero size."""
    uid = uuid.uuid4().hex[:16]
    out_path = _safe_company_dir(company_id) / f"{uid}.csv"
    with open(out_path, 'w', encoding='utf-8-sig', newline='') as f:
        writer = csv.writer(f)
        writer.writerow(headers)
        for r in rows:
            writer.writerow(r)

    size_bytes = out_path.stat().st_size if out_path.exists() else 0
    if size_bytes == 0:
        return {'success': False, 'error': 'Generated CSV file is empty.'}

    return {
        'success': True,
        'export_uid': uid,
        'format': 'CSV',
        'row_count': len(rows),
        'size_bytes': size_bytes,
        'download_url': f"/pulse-ai/api/exports/{uid}",
        'title': title,
    }
