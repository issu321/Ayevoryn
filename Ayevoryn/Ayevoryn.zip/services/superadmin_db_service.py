"""
Ayevoryn Global Superadmin Database Administration Service (USMANIA TECHS PVT LTD)
Provides 100% real, live DevOps & DBA capabilities with zero hardcoded data:
  - Live engine telemetry, SQLite file size, PRAGMA stats, integrity check
  - Live table explorer, schema inspector (columns, types, PKs, FKs, indexes), paginated row browser & search
  - Interactive SQL Query Console (Read-Only safe default + explicit Write Mode with GlobalAuditLog trail)
  - Online SQLite Backup creation, listing, download, VACUUM, and ANALYZE
  - One-click CSV & Excel export of any real table
"""
from datetime import datetime
import os
import re
import sqlite3
import time
from pathlib import Path
from sqlalchemy import inspect, text

from database.db import db
from services.superadmin_service import SuperadminService

READ_ONLY_PREFIXES = ('select', 'pragma', 'explain', 'with', 'show', 'describe')


def _get_sqlite_file_path() -> Path | None:
    try:
        url = db.engine.url
        if url.get_backend_name() == 'sqlite' and url.database and url.database != ':memory:':
            return Path(url.database).resolve()
    except Exception:
        pass
    return None


def _get_backup_dir() -> Path:
    db_path = _get_sqlite_file_path()
    base = db_path.parent if db_path else Path('instance').resolve()
    bdir = base / 'backups' / 'db_admin'
    bdir.mkdir(parents=True, exist_ok=True)
    return bdir


def _quote_ident(name: str) -> str:
    return '"' + str(name).replace('"', '""') + '"'


class SuperadminDBService:

    @staticmethod
    def get_database_overview() -> dict:
        insp = inspect(db.engine)
        dialect = db.engine.dialect.name
        table_names = sorted(insp.get_table_names())
        tables_meta = []
        total_rows = 0

        with db.engine.connect() as conn:
            for tname in table_names:
                try:
                    cnt = conn.execute(text(f"SELECT COUNT(*) FROM {_quote_ident(tname)}")).scalar() or 0
                except Exception:
                    cnt = 0
                try:
                    cols = insp.get_columns(tname)
                except Exception:
                    cols = []
                total_rows += int(cnt)
                tables_meta.append({
                    'name': tname,
                    'row_count': int(cnt),
                    'column_count': len(cols),
                })

            sqlite_info = {}
            db_path = _get_sqlite_file_path()
            if dialect == 'sqlite':
                try:
                    sqlite_info['sqlite_version'] = conn.execute(text("SELECT sqlite_version()")).scalar()
                    sqlite_info['journal_mode'] = conn.execute(text("PRAGMA journal_mode")).scalar()
                    sqlite_info['page_size'] = conn.execute(text("PRAGMA page_size")).scalar()
                    sqlite_info['page_count'] = conn.execute(text("PRAGMA page_count")).scalar()
                    sqlite_info['foreign_keys'] = conn.execute(text("PRAGMA foreign_keys")).scalar()
                except Exception:
                    pass
                if db_path and db_path.exists():
                    st = db_path.stat()
                    sqlite_info['file_path'] = str(db_path)
                    sqlite_info['file_size_bytes'] = st.st_size
                    sqlite_info['file_size_mb'] = round(st.st_size / (1024 * 1024), 2)
                    sqlite_info['last_modified'] = datetime.utcfromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S UTC')

        tables_meta.sort(key=lambda x: (-x['row_count'], x['name']))
        return {
            'success': True,
            'dialect': dialect,
            'table_count': len(tables_meta),
            'total_rows': total_rows,
            'engine_info': sqlite_info,
            'tables': tables_meta,
            'backups': SuperadminDBService.list_backups(),
        }

    @staticmethod
    def get_table_details(table_name: str, page: int = 1, per_page: int = 50, search: str = '') -> dict:
        insp = inspect(db.engine)
        valid_tables = set(insp.get_table_names())
        if table_name not in valid_tables:
            return {'success': False, 'error': f"Table '{table_name}' does not exist."}

        page = max(1, int(page or 1))
        per_page = max(10, min(200, int(per_page or 50)))
        offset = (page - 1) * per_page

        cols = insp.get_columns(table_name)
        pk = insp.get_pk_constraint(table_name) or {}
        pk_cols = set(pk.get('constrained_columns') or [])
        fks = insp.get_foreign_keys(table_name) or []
        indexes = insp.get_indexes(table_name) or []

        col_meta = [
            {
                'name': c['name'],
                'type': str(c['type']),
                'nullable': bool(c.get('nullable', True)),
                'primary_key': c['name'] in pk_cols,
                'default': str(c.get('default')) if c.get('default') is not None else '',
            }
            for c in cols
        ]
        col_names = [c['name'] for c in cols]
        qtable = _quote_ident(table_name)

        where_sql = ''
        params = {'limit': per_page, 'offset': offset}
        clean_search = (search or '').strip()
        if clean_search and col_names:
            clauses = [f"CAST({_quote_ident(cn)} AS TEXT) LIKE :q" for cn in col_names[:16]]
            where_sql = ' WHERE ' + ' OR '.join(clauses)
            params['q'] = f"%{clean_search}%"

        with db.engine.connect() as conn:
            total = int(conn.execute(text(f"SELECT COUNT(*) FROM {qtable}{where_sql}"), params).scalar() or 0)
            res = conn.execute(text(f"SELECT * FROM {qtable}{where_sql} LIMIT :limit OFFSET :offset"), params)
            rows = []
            for row in res.fetchall():
                safe_row = []
                for val in row:
                    if isinstance(val, (bytes, bytearray)):
                        safe_row.append(f"<BLOB {len(val)} bytes>")
                    elif val is None:
                        safe_row.append(None)
                    else:
                        s = str(val)
                        safe_row.append(s[:220] + ('...' if len(s) > 220 else ''))
                rows.append(safe_row)

        return {
            'success': True,
            'table': table_name,
            'columns': col_meta,
            'column_names': col_names,
            'foreign_keys': [
                {
                    'columns': fk.get('constrained_columns') or [],
                    'referred_table': fk.get('referred_table'),
                    'referred_columns': fk.get('referred_columns') or [],
                }
                for fk in fks
            ],
            'indexes': [
                {
                    'name': ix.get('name'),
                    'columns': ix.get('column_names') or [],
                    'unique': bool(ix.get('unique', False)),
                }
                for ix in indexes
            ],
            'total_rows': total,
            'page': page,
            'per_page': per_page,
            'total_pages': max(1, (total + per_page - 1) // per_page),
            'rows': rows,
        }

    @staticmethod
    def execute_sql_query(sql_text: str, allow_write: bool = False, actor_user=None, max_rows: int = 500) -> dict:
        raw = (sql_text or '').strip()
        if not raw:
            return {'success': False, 'error': 'Please enter a SQL query to execute.'}

        # Strip leading comments and inspect first SQL keyword
        cleaned = re.sub(r'^(\s*--[^\n]*\n|\s*/\*[\s\S]*?\*/\s*)+', '', raw).strip()
        first_word = (cleaned.split(None, 1)[0] if cleaned else '').lower().rstrip(';')
        is_readonly = first_word in READ_ONLY_PREFIXES

        if not is_readonly and not allow_write:
            return {
                'success': False,
                'error': f"Write/DDL statement '{first_word.upper()}' blocked in Read-Only mode. Enable 'Allow Write SQL' toggle first to execute modifying queries.",
                'requires_write_mode': True,
            }

        t0 = time.monotonic()
        try:
            if is_readonly:
                with db.engine.connect() as conn:
                    res = conn.execute(text(raw))
                    keys = list(res.keys()) if res.returns_rows else []
                    fetched = res.fetchmany(max_rows + 1) if res.returns_rows else []
                    truncated = len(fetched) > max_rows
                    if truncated:
                        fetched = fetched[:max_rows]
                    rows = []
                    for r in fetched:
                        rows.append([
                            f"<BLOB {len(v)} bytes>" if isinstance(v, (bytes, bytearray)) else (None if v is None else str(v)[:400])
                            for v in r
                        ])
                ms = round((time.monotonic() - t0) * 1000.0, 2)
                return {
                    'success': True,
                    'mode': 'read',
                    'columns': keys,
                    'rows': rows,
                    'row_count': len(rows),
                    'truncated': truncated,
                    'duration_ms': ms,
                }
            else:
                with db.engine.begin() as conn:
                    res = conn.execute(text(raw))
                    affected = res.rowcount if res.rowcount is not None else 0
                ms = round((time.monotonic() - t0) * 1000.0, 2)
                try:
                    SuperadminService.record_audit(
                        action='SUPERADMIN_SQL_WRITE',
                        category='DATABASE',
                        details=f"Executed SQL ({first_word.upper()}), rows affected: {affected}. Query: {raw[:240]}",
                        actor_user=actor_user,
                    )
                except Exception:
                    pass
                return {
                    'success': True,
                    'mode': 'write',
                    'columns': ['Status', 'Rows Affected', 'Duration (ms)'],
                    'rows': [[f"{first_word.upper()} executed successfully", affected, ms]],
                    'row_count': 1,
                    'rows_affected': affected,
                    'duration_ms': ms,
                }
        except Exception as exc:
            return {'success': False, 'error': str(exc), 'duration_ms': round((time.monotonic() - t0) * 1000.0, 2)}

    @staticmethod
    def create_backup(actor_user=None) -> dict:
        db_path = _get_sqlite_file_path()
        if not db_path or not db_path.exists():
            return {'success': False, 'error': 'Online file backup is only supported for SQLite databases.'}

        bdir = _get_backup_dir()
        ts = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
        fname = f"ayevoryn_backup_{ts}.db"
        dest = bdir / fname

        src_conn = sqlite3.connect(str(db_path))
        dst_conn = sqlite3.connect(str(dest))
        try:
            src_conn.backup(dst_conn)
        finally:
            dst_conn.close()
            src_conn.close()

        size_bytes = dest.stat().st_size
        try:
            SuperadminService.record_audit(
                action='SUPERADMIN_DB_BACKUP',
                category='DATABASE',
                details=f"Created online SQLite backup {fname} ({round(size_bytes / (1024 * 1024), 2)} MB).",
                actor_user=actor_user,
            )
        except Exception:
            pass
        return {
            'success': True,
            'filename': fname,
            'size_mb': round(size_bytes / (1024 * 1024), 2),
            'download_url': f"/superadmin/api/database/backups/{fname}",
            'created_at': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S UTC'),
        }

    @staticmethod
    def list_backups() -> list:
        bdir = _get_backup_dir()
        items = []
        for f in sorted(bdir.glob('*.db'), key=lambda p: p.stat().st_mtime, reverse=True)[:25]:
            st = f.stat()
            items.append({
                'filename': f.name,
                'size_mb': round(st.st_size / (1024 * 1024), 2),
                'created_at': datetime.utcfromtimestamp(st.st_mtime).strftime('%Y-%m-%d %H:%M:%S UTC'),
                'download_url': f"/superadmin/api/database/backups/{f.name}",
            })
        return items

    @staticmethod
    def resolve_backup_path(filename: str) -> Path | None:
        safe = Path(str(filename or '')).name
        if not safe.endswith('.db') or '/' in safe or '\\' in safe or '..' in safe:
            return None
        bdir = _get_backup_dir().resolve()
        cand = (bdir / safe).resolve()
        if cand.parent == bdir and cand.is_file():
            return cand
        return None

    @staticmethod
    def run_maintenance(action: str, actor_user=None) -> dict:
        act = (action or '').strip().lower()
        if act not in ('integrity_check', 'analyze', 'vacuum'):
            return {'success': False, 'error': "Unsupported maintenance action. Use 'integrity_check', 'analyze', or 'vacuum'."}
        t0 = time.monotonic()
        try:
            if act == 'integrity_check':
                with db.engine.connect() as conn:
                    rows = [r[0] for r in conn.execute(text("PRAGMA integrity_check")).fetchall()]
                msg = ', '.join(str(x) for x in rows)
            elif act == 'analyze':
                with db.engine.begin() as conn:
                    conn.execute(text("ANALYZE"))
                msg = 'SQLite query planner statistics updated (ANALYZE complete).'
            else:
                db_path = _get_sqlite_file_path()
                if db_path and db_path.exists():
                    conn = sqlite3.connect(str(db_path))
                    try:
                        conn.execute("VACUUM")
                    finally:
                        conn.close()
                    msg = f"Database compacted via VACUUM (new size: {round(db_path.stat().st_size / (1024 * 1024), 2)} MB)."
                else:
                    msg = 'VACUUM skipped (non-SQLite engine).'
            ms = round((time.monotonic() - t0) * 1000.0, 2)
            try:
                SuperadminService.record_audit(
                    action=f'SUPERADMIN_DB_{act.upper()}',
                    category='DATABASE',
                    details=f"{msg} ({ms} ms)",
                    actor_user=actor_user,
                )
            except Exception:
                pass
            return {'success': True, 'action': act, 'message': msg, 'duration_ms': ms}
        except Exception as exc:
            return {'success': False, 'error': str(exc)}

    @staticmethod
    def export_table(table_name: str, fmt: str = 'csv') -> dict:
        insp = inspect(db.engine)
        if table_name not in set(insp.get_table_names()):
            return {'success': False, 'error': f"Table '{table_name}' not found."}
        with db.engine.connect() as conn:
            res = conn.execute(text(f"SELECT * FROM {_quote_ident(table_name)} LIMIT 5000"))
            headers = list(res.keys())
            rows = [
                [f"<BLOB {len(v)}b>" if isinstance(v, (bytes, bytearray)) else ('' if v is None else v) for v in r]
                for r in res.fetchall()
            ]
        from services.agent_export_service import generate_csv_export, generate_multi_sheet_excel, generate_custom_pdf_report
        fmt_l = (fmt or 'csv').strip().lower()
        if fmt_l == 'excel' or fmt_l == 'xlsx':
            out = generate_multi_sheet_excel('Global Control Plane', 0, '$', {table_name[:31]: {'headers': headers, 'rows': rows}}, title=f"DB Table Export — {table_name}")
        elif fmt_l == 'pdf':
            out = generate_custom_pdf_report('Global Control Plane', 0, '$', {table_name: {'headers': headers, 'rows': rows}}, title=f"DB Table Report — {table_name}")
        else:
            out = generate_csv_export(0, headers, rows, title=f"DB_Table_{table_name}")
        if out.get('export_uid'):
            out['download_url'] = f"/superadmin/api/exports/{out['export_uid']}"
        return out
