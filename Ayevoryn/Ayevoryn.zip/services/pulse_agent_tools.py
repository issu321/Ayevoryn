"""
AEVORYN PULSE AI — COMPACT 7-TOOL FULL-PLATFORM AUTONOMOUS AGENT SUITE
Consolidates all 38+ enterprise operations across every Ayevoryn module into 7 compact,
high-reliability OpenAI/NVIDIA NIM function-calling tools (<3.5 KB schema total) so compact
fast models like `nvidia/nemotron-3.5-bolt-e4b` execute tool calls with maximum accuracy
and never fail with HTTP 400/422 schema-overflow errors.
"""

import json
import re
from datetime import date, datetime
from sqlalchemy import or_
from database.db import db
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.risk import Risk
from database.models.project import Project
from database.models.simulation import Simulation
from database.models.forecast import Forecast
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.notification import Notification
from config.constants import CURRENCY_SYMBOLS
from services.pulse_agentic_router import PulseAgenticRouter


def build_full_agent_tools() -> list:
    """Return 7 compact, high-accuracy tool definitions covering every A-Z module, write action, export, automation, and navigation."""
    return [
        {
            "type": "function",
            "function": {
                "name": "query_company_module",
                "description": (
                    "Query LIVE records from ANY company module in the database. Use this for exact lists, names, "
                    "counts, balances, budgets, or details (e.g. employees in IT, departments, customers, financials, "
                    "bank_accounts, inventory, suppliers, risks, projects, simulations_forecasts, custom_twins, "
                    "branches_campaigns, loans_investments, market_competitors, documents_reports, audit_logs, twin_links)."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "module": {
                            "type": "string",
                            "enum": [
                                "employees", "departments", "customers", "financials", "bank_accounts",
                                "inventory", "suppliers", "risks", "projects", "simulations_forecasts",
                                "custom_twins", "branches_campaigns", "loans_investments",
                                "market_competitors", "documents_reports", "audit_logs", "twin_links"
                            ]
                        },
                        "filter_department": {"type": "string", "description": "Optional department filter (e.g. 'IT')."},
                        "search": {"type": "string", "description": "Optional text search."},
                        "low_stock_only": {"type": "boolean"},
                        "limit": {"type": "integer"}
                    },
                    "required": ["module"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "modify_company_record",
                "description": (
                    "Full CRUD (Create, Update, Delete) on real company records across all modules and Twin-to-Department linking. "
                    "For any delete_* action, pass confirmed=true ONLY after the user explicitly confirms deletion."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "add_department", "update_department_budget", "update_department", "delete_department",
                                "add_employee", "update_employee", "delete_employee",
                                "add_financial_record", "update_financial_record", "delete_financial_record",
                                "add_customer", "update_customer", "delete_customer",
                                "add_supplier", "update_supplier", "delete_supplier",
                                "add_or_update_inventory", "delete_inventory",
                                "add_risk", "update_risk", "delete_risk",
                                "add_project", "update_project", "delete_project",
                                "create_custom_twin_and_link", "link_twin_to_departments", "delete_custom_twin",
                                "send_notification"
                            ]
                        },
                        "data": {
                            "type": "object",
                            "description": "Fields for the action (e.g. id, name, budget, spent, head_name, department, first_name, last_name, salary, job_title, status, amount, transaction_type, category, sku, quantity_on_hand, risk_level, mitigation_plan, twin_name, department_names, title, message)."
                        },
                        "confirmed": {
                            "type": "boolean",
                            "description": "Set true only when the user has explicitly confirmed a destructive delete action."
                        }
                    },
                    "required": ["action", "data"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "run_analysis_or_simulation",
                "description": "Run a real what-if financial simulation (revenue/expense % change) or a full Decision Intelligence & Risk Scan.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["what_if_simulation", "decision_scan", "autonomous_monitor"]},
                        "name": {"type": "string"},
                        "revenue_change_pct": {"type": "number"},
                        "expense_change_pct": {"type": "number"}
                    },
                    "required": ["action"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "generate_or_export_file",
                "description": "Generate a REAL downloadable PDF report, multi-sheet Excel (.xlsx) workbook, or CSV file from live company data.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "format_type": {"type": "string", "enum": ["pdf", "xlsx", "csv"]},
                        "target": {
                            "type": "string",
                            "description": "Report/dataset type: executive, financial, board, risk, department, forecast, company_performance, departments, employees, financials, customers, inventory, suppliers, risks."
                        },
                        "department": {"type": "string"},
                        "title": {"type": "string"}
                    },
                    "required": ["format_type", "target"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "manage_automations",
                "description": (
                    "Create, list, run, pause/resume, or delete REAL recurring background automations (e.g. 'generate report every 3 days', "
                    "'check low stock every 6 hours and alert me'). Supports interval_days OR interval_hours."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["create", "list", "run_now", "toggle", "delete"]},
                        "name": {"type": "string"},
                        "task_type": {"type": "string", "enum": ["custom_agent_prompt", "generate_report", "risk_scan", "ai_briefing"]},
                        "prompt": {"type": "string"},
                        "interval_days": {"type": "number"},
                        "interval_hours": {"type": "number"},
                        "report_type": {"type": "string"},
                        "format_type": {"type": "string", "enum": ["pdf", "excel"]},
                        "automation_id": {"type": "integer"},
                        "run_immediately": {"type": "boolean"}
                    },
                    "required": ["action"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "navigate_to_page",
                "description": (
                    "Navigate the user's browser directly to ANY page inside Ayevoryn with a smooth loading transition. "
                    "Pass the page name or route in `destination` (e.g. 'dashboard', 'departments', 'employees', 'revenue', "
                    "'expenses', 'customers', 'inventory', 'suppliers', 'payments', 'custom twins', 'revenue analytics', "
                    "'risk heatmap', 'simulation', 'forecasting', 'reports', 'documents', 'settings', 'dependency graph', 'ai insights', 'register', 'login', 'home')."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "destination": {"type": "string", "description": "Page name or exact URL path to open."}
                    },
                    "required": ["destination"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "toggle_theme",
                "description": "Switch the user interface between dark and light mode.",
                "parameters": {
                    "type": "object",
                    "properties": {"theme": {"type": "string", "enum": ["dark", "light", "toggle"]}},
                    "required": ["theme"]
                }
            }
        }
    ]


def _verify_write_permission(user_id: int, company_id: int, action_label: str):
    try:
        from database.models.user import User
        actor = db.session.get(User, int(user_id))
        if actor:
            role = (getattr(actor, 'role', '') or '').lower()
            if role in ('viewer', 'readonly', 'guest'):
                return f"Permission denied: role '{role}' cannot execute '{action_label}'."
            if getattr(actor, 'company_id', None) and int(actor.company_id) != int(company_id) and not getattr(actor, 'is_superadmin', False):
                return "Tenant isolation violation: user does not belong to target organization."
    except Exception:
        pass
    return None



# ── AI SECURITY: RISK CLASSIFICATION, CONFIRMATION GATE & PROMPT-INJECTION DEFENSE (Phases 13 & 18) ──
TOOL_RISK_CLASSIFICATION = {
    'query_company_module': 'read',
    'modify_company_record': 'write',
    'run_business_intelligence': 'read',
    'generate_business_export': 'read',
    'manage_automation': 'write',
    'navigate_to_page': 'read',
    'change_ui_theme': 'read',
}

DESTRUCTIVE_SUBACTIONS = {
    'delete_financial_record', 'delete_customer', 'delete_supplier', 'delete_inventory', 'delete_risk', 'delete_project',
    'delete_department', 'delete_employee', 'delete_record', 'delete_automation',
    'delete_custom_twin', 'bulk_delete', 'purge', 'reset_budgets',
}

_INJECTION_PATTERNS = [
    re.compile(r'(?i)ignore\s+(?:all\s+|any\s+)?(?:previous|prior|above|system)\s+instructions?'),
    re.compile(r'(?i)(?:reveal|print|dump|output|show)\s+(?:your\s+)?(?:system\s+prompt|api[\s_-]?key|secret[\s_-]?key|env(?:ironment)?\s+variables?|\.env)'),
    re.compile(r'(?i)(?:bypass|override|disable)\s+(?:rbac|permissions?|tenant\s+isolation|security|authentication)'),
    re.compile(r'(?i)(?:os\.system|subprocess|__import__|exec\(|eval\(|rm\s+-rf|drop\s+table)'),
]


def detect_prompt_injection(text: str) -> dict:
    """Detect common prompt-injection, secret-exfiltration, or tenant-bypass attempts."""
    s = str(text or '')
    matched = []
    for pat in _INJECTION_PATTERNS:
        m = pat.search(s)
        if m:
            matched.append(m.group(0)[:80])
    return {'flagged': bool(matched), 'matches': matched}


def sanitize_untrusted_text(text: str, max_len: int = 4000) -> str:
    """Neutralize control characters and prompt-injection markers in untrusted text."""
    s = str(text or '')[:max_len]
    s = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', s)
    return s.strip()


def classify_tool_risk(tool_name: str, args: dict = None) -> str:
    """Return 'read', 'write', or 'destructive' for a given tool call."""
    args = args or {}
    sub = str(args.get('action') or args.get('operation') or '').strip().lower()
    if sub in DESTRUCTIVE_SUBACTIONS or sub.startswith('delete_'):
        return 'destructive'
    return TOOL_RISK_CLASSIFICATION.get(tool_name, 'write')


def execute_agent_tool(tool_name: str, args: dict, company_id: int, user_id: int) -> dict:
    args = args if isinstance(args, dict) else {}
    risk_level = classify_tool_risk(tool_name, args)
    if risk_level == 'destructive' and not bool(args.get('confirmed')):
        _d = args.get('data') if isinstance(args.get('data'), dict) else {}
        target = _d.get('name') or _d.get('department_name') or _d.get('company_name') or _d.get('sku') or _d.get('id') or args.get('name') or args.get('automation_id') or 'selected record'
        return {
            'success': False,
            'requires_confirmation': True,
            'risk_level': 'destructive',
            'tool_name': tool_name,
            'target': str(target),
            'error': f'Confirmation required before executing destructive action ({args.get("action") or tool_name}) on {target}.',
            'message': f'This action ({args.get("action") or tool_name}) on "{target}" is destructive. Please confirm explicitly before I proceed.',
        }

    """Execute any of the compact meta-tools against the live tenant-scoped SQLAlchemy database."""
    args = args if isinstance(args, dict) else {}
    cid = int(company_id)
    uid = int(user_id or 1)
    company = db.session.get(Company, cid)
    sym = CURRENCY_SYMBOLS.get((company.currency if company else 'USD') or 'USD', '$')

    # ─── 1. QUERY ANY MODULE ───
    if tool_name == 'query_company_module':
        mod = (args.get('module') or '').strip().lower()
        dept_filter = (args.get('filter_department') or '').strip()
        search = (args.get('search') or '').strip()
        low_only = bool(args.get('low_stock_only'))
        limit = min(150, max(1, int(args.get('limit') or 50)))

        if mod == 'employees':
            dept_map = {d.id: d.name for d in Department.query.filter_by(company_id=cid).all()}
            q = Employee.query.filter(Employee.company_id == cid)
            if dept_filter:
                mids = [did for did, dn in dept_map.items() if dept_filter.lower() in (dn or '').lower()]
                if not mids:
                    return {'total_matching': 0, 'department_filter': dept_filter, 'available_departments': list(dept_map.values()), 'employees': []}
                q = q.filter(Employee.department_id.in_(mids))
            if search:
                like = f"%{search}%"
                q = q.filter(or_(Employee.first_name.ilike(like), Employee.last_name.ilike(like), Employee.email.ilike(like), Employee.job_title.ilike(like)))
            total = q.count()
            rows = q.order_by(Employee.id.asc()).limit(limit).all()
            return {
                'total_matching': total, 'returned_count': len(rows), 'currency_symbol': sym,
                'employees': [{'id': e.id, 'employee_id': e.employee_id, 'name': f"{e.first_name or ''} {e.last_name or ''}".strip(), 'email': e.email or '', 'department': dept_map.get(e.department_id, 'Unassigned'), 'job_title': e.job_title or '', 'salary': float(e.salary or 0.0), 'status': e.status or 'active'} for e in rows]
            }

        if mod == 'departments':
            q = Department.query.filter_by(company_id=cid)
            if search:
                q = q.filter(Department.name.ilike(f"%{search}%"))
            depts = q.order_by(Department.name.asc()).all()
            return {'count': len(depts), 'currency_symbol': sym, 'departments': [{'id': d.id, 'name': d.name, 'code': d.code, 'head_name': d.head_name or '', 'budget': float(d.budget or 0.0), 'spent': float(d.spent or 0.0), 'actual_employee_count': Employee.query.filter_by(company_id=cid, department_id=d.id).count()} for d in depts]}

        if mod == 'customers':
            q = Customer.query.filter_by(company_id=cid)
            if search:
                like = f"%{search}%"
                q = q.filter(or_(Customer.first_name.ilike(like), Customer.last_name.ilike(like), Customer.company_name.ilike(like), Customer.email.ilike(like)))
            rows = q.order_by(Customer.lifetime_value.desc()).limit(limit).all()
            return {'total_matching': q.count(), 'currency_symbol': sym, 'customers': [{'id': c.id, 'name': f"{c.first_name or ''} {c.last_name or ''}".strip() or c.company_name, 'company_name': c.company_name or '', 'email': c.email or '', 'segment': c.segment or '', 'lifetime_value': float(c.lifetime_value or 0.0)} for c in rows]}

        if mod == 'financials':
            q = FinancialRecord.query.filter_by(company_id=cid)
            if search:
                q = q.filter(or_(FinancialRecord.category.ilike(f"%{search}%"), FinancialRecord.description.ilike(f"%{search}%"), FinancialRecord.transaction_type.ilike(f"%{search}%")))
            rows = q.order_by(FinancialRecord.transaction_date.desc(), FinancialRecord.id.desc()).limit(limit).all()
            return {'total_matching': q.count(), 'returned_sum': sum(float(r.amount or 0.0) for r in rows), 'currency_symbol': sym, 'records': [{'id': r.id, 'date': r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '', 'type': r.transaction_type, 'category': r.category or '', 'amount': float(r.amount or 0.0), 'description': r.description or ''} for r in rows]}

        if mod == 'bank_accounts':
            accs = FinancialAccount.query.filter_by(company_id=cid).order_by(FinancialAccount.current_balance.desc()).all()
            return {'count': len(accs), 'currency_symbol': sym, 'total_balance': sum(float(a.current_balance or 0.0) for a in accs), 'accounts': [{'id': a.id, 'name': a.account_name, 'type': a.account_type, 'balance': float(a.current_balance or 0.0), 'is_active': bool(a.is_active)} for a in accs]}

        if mod == 'inventory':
            q = Inventory.query.filter_by(company_id=cid)
            if search:
                q = q.filter(or_(Inventory.sku.ilike(f"%{search}%"), Inventory.name.ilike(f"%{search}%")))
            if low_only:
                q = q.filter(Inventory.quantity_on_hand <= Inventory.reorder_point)
            rows = q.order_by(Inventory.quantity_on_hand.asc()).limit(limit).all()
            return {'total_matching': q.count(), 'currency_symbol': sym, 'items': [{'sku': i.sku, 'name': i.name, 'quantity_on_hand': int(i.quantity_on_hand or 0), 'reorder_point': int(i.reorder_point or 0), 'unit_cost': float(i.unit_cost or 0.0), 'selling_price': float(i.selling_price or 0.0)} for i in rows]}

        if mod == 'suppliers':
            q = Supplier.query.filter_by(company_id=cid)
            if search:
                q = q.filter(or_(Supplier.name.ilike(f"%{search}%"), Supplier.category.ilike(f"%{search}%")))
            rows = q.order_by(Supplier.rating.desc()).limit(limit).all()
            return {'count': len(rows), 'suppliers': [{'name': s.name, 'category': s.category or '', 'contact_person': s.contact_person or '', 'lead_time_days': int(s.lead_time_days or 0), 'rating': float(s.rating or 0.0)} for s in rows]}

        if mod == 'risks':
            rows = Risk.query.filter_by(company_id=cid).order_by(Risk.risk_score.desc()).limit(limit).all()
            return {'count': len(rows), 'risks': [{'name': r.name, 'category': r.category, 'risk_level': r.risk_level, 'risk_score': float(r.risk_score or 0.0), 'status': r.status, 'mitigation_plan': r.mitigation_plan or ''} for r in rows]}

        if mod == 'projects':
            rows = Project.query.filter_by(company_id=cid).order_by(Project.created_at.desc()).limit(limit).all()
            return {'count': len(rows), 'currency_symbol': sym, 'projects': [{'name': p.name, 'status': p.status, 'priority': p.priority, 'budget': float(p.budget or 0.0), 'spent': float(p.spent or 0.0), 'progress': float(p.progress or 0.0)} for p in rows]}

        if mod == 'simulations_forecasts':
            sims = Simulation.query.filter_by(company_id=cid).order_by(Simulation.id.desc()).limit(10).all()
            fcs = Forecast.query.filter_by(company_id=cid).order_by(Forecast.id.desc()).limit(10).all()
            return {'currency_symbol': sym, 'simulations': [{'id': s.id, 'name': s.name, 'profit_before': float(s.profit_before or 0.0), 'profit_after': float(s.profit_after or 0.0)} for s in sims], 'forecasts': [{'id': f.id, 'name': f.name, 'type': f.forecast_type, 'horizon_days': f.horizon_days, 'r2': f.accuracy_r2} for f in fcs]}

        if mod == 'custom_twins':
            twins = CustomTwin.query.filter_by(company_id=cid, is_active=True).all()
            return {'count': len(twins), 'custom_twins': [{'id': t.id, 'name': t.name, 'slug': t.slug, 'record_count': CustomTwinRecord.query.filter_by(company_id=cid, twin_id=t.id).count()} for t in twins]}

        if mod == 'branches_campaigns':
            from database.models.branch import Branch
            from database.models.marketing_campaign import MarketingCampaign
            return {
                'branches': [{'id': b.id, 'name': getattr(b, 'name', ''), 'city': getattr(b, 'city', '')} for b in Branch.query.filter_by(company_id=cid).all()],
                'campaigns': [{'id': c.id, 'name': getattr(c, 'name', ''), 'budget': float(getattr(c, 'budget', 0) or 0), 'status': getattr(c, 'status', '')} for c in MarketingCampaign.query.filter_by(company_id=cid).all()]
            }

        if mod == 'loans_investments':
            from database.models.loan import Loan
            from database.models.investment import Investment
            return {
                'currency_symbol': sym,
                'loans': [{'id': l.id, 'name': getattr(l, 'name', getattr(l, 'lender', 'Loan')), 'amount': float(getattr(l, 'principal_amount', getattr(l, 'amount', 0)) or 0)} for l in Loan.query.filter_by(company_id=cid).all()],
                'investments': [{'id': iv.id, 'name': getattr(iv, 'name', 'Investment'), 'amount': float(getattr(iv, 'amount', 0) or 0)} for iv in Investment.query.filter_by(company_id=cid).all()]
            }

        if mod == 'market_competitors':
            from database.models.competitor import Competitor
            from database.models.market_data import MarketData
            return {
                'competitors': [{'name': c.name, 'market_share': getattr(c, 'market_share', None)} for c in Competitor.query.filter_by(company_id=cid).all()],
                'market_data': [{'metric': getattr(m, 'metric_name', getattr(m, 'category', '')), 'value': getattr(m, 'value', None)} for m in MarketData.query.filter_by(company_id=cid).limit(20).all()]
            }

        if mod == 'documents_reports':
            from database.models.document import Document
            from database.models.report import Report
            return {
                'documents': [{'id': d.id, 'title': getattr(d, 'title', getattr(d, 'filename', 'Document')), 'download_url': f'/documents/download/{d.id}'} for d in Document.query.filter_by(company_id=cid).order_by(Document.id.desc()).limit(15).all()],
                'reports': [{'id': r.id, 'name': getattr(r, 'name', 'Report'), 'type': getattr(r, 'report_type', ''), 'download_url': f'/reports/download/{r.id}'} for r in Report.query.filter_by(company_id=cid).order_by(Report.id.desc()).limit(15).all()]
            }

        if mod == 'audit_logs':
            from database.models.audit_log import AuditLog
            logs = AuditLog.query.filter_by(company_id=cid).order_by(AuditLog.id.desc()).limit(25).all()
            return {'count': len(logs), 'logs': [{'action': getattr(l, 'action', ''), 'entity': getattr(l, 'entity_type', ''), 'timestamp': str(getattr(l, 'created_at', ''))} for l in logs]}

        if mod == 'twin_links':
            from database.models.twin_dependency import TwinDependency
            deps = TwinDependency.query.filter_by(company_id=cid, is_active=True).all()
            return {'count': len(deps), 'links': [{'source': f"{d.source_type}:{d.source_id}", 'target': f"{d.target_type}:{d.target_id}", 'strength': d.strength, 'description': d.description or ''} for d in deps]}

        return {'error': f"Unsupported module '{mod}'"}

    # ─── 2. MODIFY COMPANY RECORDS & TWIN LINKING ───
    if tool_name == 'modify_company_record':
        act = (args.get('action') or '').strip().lower()
        data = args.get('data') if isinstance(args.get('data'), dict) else {}
        perm_err = _verify_write_permission(uid, cid, act)
        if perm_err:
            return {'success': False, 'error': perm_err}

        if act == 'add_department':
            name = (data.get('name') or '').strip()
            if not name:
                return {'success': False, 'error': 'Department name is required'}
            dept = Department(company_id=cid, name=name[:200], code=''.join(c for c in name.upper() if c.isalnum())[:6] or 'DEPT', budget=float(data.get('budget') or 0.0), head_name=(data.get('head_name') or '').strip()[:200], description=(data.get('description') or 'Created by Aevoryn Pulse AI').strip())
            db.session.add(dept)
            db.session.commit()
            from services.twin_auto_linker import auto_link_department_to_twins
            linked = auto_link_department_to_twins(cid, dept, user_id=uid)
            return {'success': True, 'department_id': dept.id, 'name': dept.name, 'budget': dept.budget, 'currency_symbol': sym, 'auto_linked_twins': linked}

        if act == 'update_department_budget':
            dname = (data.get('department_name') or data.get('name') or '').strip()
            d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{dname}%")).first()
            if not d:
                return {'success': False, 'error': f"Department '{dname}' not found."}
            if data.get('new_budget') is not None or data.get('budget') is not None:
                d.budget = float(data.get('new_budget') if data.get('new_budget') is not None else data.get('budget'))
            if data.get('spent') is not None:
                d.spent = float(data['spent'])
            db.session.commit()
            return {'success': True, 'department': d.name, 'budget': d.budget, 'spent': d.spent, 'currency_symbol': sym}

        if act == 'add_employee':
            dept_id = None
            if data.get('department'):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(data['department']).strip()}%")).first()
                if d:
                    dept_id = d.id
            emp = Employee(company_id=cid, first_name=(data.get('first_name') or 'New').strip()[:100], last_name=(data.get('last_name') or 'Employee').strip()[:100], department_id=dept_id, job_title=(data.get('job_title') or 'Team Member').strip()[:200], salary=float(data.get('salary') or 0.0), email=(data.get('email') or '').strip()[:120], status='active', hire_date=date.today())
            db.session.add(emp)
            db.session.commit()
            return {'success': True, 'employee_id': emp.id, 'name': f"{emp.first_name} {emp.last_name}", 'salary': emp.salary, 'currency_symbol': sym}

        if act == 'add_financial_record':
            tx_type = (data.get('transaction_type') or 'expense').strip().lower()
            rec = FinancialRecord(company_id=cid, transaction_type=tx_type if tx_type in ('revenue', 'expense') else 'expense', amount=float(data.get('amount') or 0.0), category=(data.get('category') or 'General').strip()[:100], description=(data.get('description') or 'Logged by Aevoryn Pulse AI').strip()[:500], transaction_date=date.today())
            db.session.add(rec)
            db.session.commit()
            return {'success': True, 'record_id': rec.id, 'type': rec.transaction_type, 'amount': rec.amount, 'currency_symbol': sym}

        if act == 'add_customer':
            cust = Customer(company_id=cid, company_name=(data.get('company_name') or data.get('name') or 'New Client').strip()[:200], first_name=(data.get('first_name') or '').strip()[:100], last_name=(data.get('last_name') or '').strip()[:100], email=(data.get('email') or '').strip()[:120], segment=(data.get('segment') or 'Enterprise').strip()[:50], lifetime_value=float(data.get('lifetime_value') or 0.0), acquisition_date=date.today())
            db.session.add(cust)
            db.session.commit()
            return {'success': True, 'customer_id': cust.id, 'company_name': cust.company_name}

        if act == 'add_supplier':
            sup = Supplier(company_id=cid, name=(data.get('name') or 'New Supplier').strip()[:200], category=(data.get('category') or 'General').strip()[:100], contact_person=(data.get('contact_person') or '').strip()[:200], email=(data.get('email') or '').strip()[:120], lead_time_days=int(data.get('lead_time_days') or 7), rating=float(data.get('rating') or 4.0))
            db.session.add(sup)
            db.session.commit()
            return {'success': True, 'supplier_id': sup.id, 'name': sup.name}

        if act == 'add_or_update_inventory':
            sku = (data.get('sku') or '').strip()
            existing = Inventory.query.filter_by(company_id=cid, sku=sku).first() if sku else None
            if existing:
                existing.quantity_on_hand = int(data.get('quantity_on_hand', existing.quantity_on_hand))
                db.session.commit()
                return {'success': True, 'action': 'updated', 'sku': existing.sku, 'quantity_on_hand': existing.quantity_on_hand}
            item = Inventory(company_id=cid, sku=sku or f"SKU-{int(datetime.utcnow().timestamp()) % 100000}", name=(data.get('name') or 'New Item').strip()[:200], quantity_on_hand=int(data.get('quantity_on_hand') or 0), quantity_available=int(data.get('quantity_on_hand') or 0), reorder_point=int(data.get('reorder_point') or 10), unit_cost=float(data.get('unit_cost') or 0.0), selling_price=float(data.get('selling_price') or 0.0), category=(data.get('category') or 'General').strip()[:100])
            db.session.add(item)
            db.session.commit()
            return {'success': True, 'action': 'created', 'sku': item.sku, 'name': item.name}

        if act == 'add_risk':
            prob = min(1.0, max(0.05, float(data.get('probability') or 0.5)))
            imp = min(1.0, max(0.05, float(data.get('impact') or 0.6)))
            rk = Risk(company_id=cid, name=(data.get('name') or 'Operational Risk').strip()[:200], category=(data.get('category') or 'operational').strip()[:50], risk_level=(data.get('risk_level') or 'medium').strip().lower(), probability=prob, impact=imp, risk_score=round(prob * imp * 100.0, 1), status='active', mitigation_plan=(data.get('mitigation_plan') or '').strip())
            db.session.add(rk)
            db.session.commit()
            return {'success': True, 'risk_id': rk.id, 'name': rk.name, 'risk_score': rk.risk_score}

        if act == 'add_project':
            dept_id = None
            if data.get('department'):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(data['department']).strip()}%")).first()
                if d:
                    dept_id = d.id
            proj = Project(company_id=cid, name=(data.get('name') or 'New Project').strip()[:200], department_id=dept_id, budget=float(data.get('budget') or 0.0), priority=(data.get('priority') or 'medium').strip().lower(), status=(data.get('status') or 'planning').strip().lower())
            db.session.add(proj)
            db.session.commit()
            return {'success': True, 'project_id': proj.id, 'name': proj.name}

        if act == 'create_custom_twin_and_link':
            from services.twin_auto_linker import auto_link_custom_twin_to_departments
            tname = (data.get('name') or '').strip()
            if not tname:
                return {'success': False, 'error': 'Twin name is required'}
            slug = re.sub(r'[^a-z0-9]+', '-', tname.lower()).strip('-') or 'custom-twin'
            if CustomTwin.query.filter_by(company_id=cid, slug=slug).first():
                slug = f"{slug}-{int(datetime.utcnow().timestamp()) % 10000}"
            twin = CustomTwin(company_id=cid, name=tname[:100], slug=slug[:100], description=(data.get('description') or '').strip(), created_by=uid)
            db.session.add(twin)
            db.session.commit()
            dept_ids = []
            for dn in (data.get('department_names') or []):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(dn).strip()}%")).first()
                if d:
                    dept_ids.append(d.id)
            linked = auto_link_custom_twin_to_departments(cid, twin, user_id=uid, explicit_dept_ids=dept_ids)
            return {'success': True, 'twin_id': twin.id, 'name': twin.name, 'url': f'/business-twin/custom-twins/{twin.slug}', 'auto_linked_departments': linked}

        if act == 'link_twin_to_departments':
            from services.twin_auto_linker import auto_link_custom_twin_to_departments
            tname = (data.get('twin_name') or data.get('name') or '').strip()
            twin = CustomTwin.query.filter(CustomTwin.company_id == cid, CustomTwin.name.ilike(f"%{tname}%")).first()
            if not twin:
                return {'success': False, 'error': f"Custom twin '{tname}' not found."}
            dept_ids = []
            for dn in (data.get('department_names') or []):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(dn).strip()}%")).first()
                if d:
                    dept_ids.append(d.id)
            linked = auto_link_custom_twin_to_departments(cid, twin, user_id=uid, explicit_dept_ids=dept_ids)
            return {'success': True, 'twin': twin.name, 'linked_departments': linked}

        if act == 'send_notification':
            n = Notification(company_id=cid, user_id=uid, title=(data.get('title') or 'Pulse AI Alert').strip()[:200], message=(data.get('message') or '').strip()[:1000], notification_type='info', module='pulse_ai', action_link=(data.get('action_link') or '/pulse-ai/').strip()[:500], action_text='View')
            db.session.add(n)
            db.session.commit()
            return {'success': True, 'notification_id': n.id, 'title': n.title}

        if act == 'update_department':
            did = data.get('id')
            dname = (data.get('department_name') or data.get('name') or '').strip()
            d = Department.query.filter_by(company_id=cid, id=int(did)).first() if did else Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{dname}%")).first()
            if not d:
                return {'success': False, 'error': f"Department '{dname or did}' not found."}
            if data.get('new_name'): d.name = str(data['new_name']).strip()[:200]
            if data.get('budget') is not None: d.budget = float(data['budget'])
            if data.get('spent') is not None: d.spent = float(data['spent'])
            if data.get('head_name') is not None: d.head_name = str(data['head_name']).strip()[:200]
            if data.get('description') is not None: d.description = str(data['description']).strip()
            db.session.commit()
            return {'success': True, 'updated': 'department', 'id': d.id, 'name': d.name, 'budget': d.budget, 'spent': d.spent, 'currency_symbol': sym}

        if act == 'delete_department':
            did = data.get('id')
            dname = (data.get('department_name') or data.get('name') or '').strip()
            d = Department.query.filter_by(company_id=cid, id=int(did)).first() if did else Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{dname}%")).first()
            if not d:
                return {'success': False, 'error': f"Department '{dname or did}' not found."}
            removed_name, removed_id = d.name, d.id
            db.session.delete(d)
            db.session.commit()
            return {'success': True, 'deleted': 'department', 'id': removed_id, 'name': removed_name}

        if act == 'update_employee':
            eid = data.get('id')
            ename = (data.get('name') or data.get('first_name') or '').strip()
            emp = Employee.query.filter_by(company_id=cid, id=int(eid)).first() if eid else Employee.query.filter(Employee.company_id == cid, or_(Employee.first_name.ilike(f"%{ename}%"), Employee.last_name.ilike(f"%{ename}%"), Employee.email.ilike(f"%{ename}%"))).first()
            if not emp:
                return {'success': False, 'error': f"Employee '{ename or eid}' not found."}
            if data.get('salary') is not None: emp.salary = float(data['salary'])
            if data.get('job_title'): emp.job_title = str(data['job_title']).strip()[:200]
            if data.get('status'): emp.status = str(data['status']).strip().lower()[:30]
            if data.get('email'): emp.email = str(data['email']).strip()[:120]
            if data.get('department'):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(data['department']).strip()}%")).first()
                if d: emp.department_id = d.id
            db.session.commit()
            return {'success': True, 'updated': 'employee', 'id': emp.id, 'name': f"{emp.first_name} {emp.last_name}", 'salary': emp.salary, 'job_title': emp.job_title, 'status': emp.status, 'currency_symbol': sym}

        if act == 'delete_employee':
            eid = data.get('id')
            ename = (data.get('name') or data.get('first_name') or '').strip()
            emp = Employee.query.filter_by(company_id=cid, id=int(eid)).first() if eid else Employee.query.filter(Employee.company_id == cid, or_(Employee.first_name.ilike(f"%{ename}%"), Employee.last_name.ilike(f"%{ename}%"), Employee.email.ilike(f"%{ename}%"))).first()
            if not emp:
                return {'success': False, 'error': f"Employee '{ename or eid}' not found."}
            removed_name, removed_id = f"{emp.first_name} {emp.last_name}", emp.id
            db.session.delete(emp)
            db.session.commit()
            return {'success': True, 'deleted': 'employee', 'id': removed_id, 'name': removed_name}

        if act == 'update_financial_record':
            rid = data.get('id')
            if not rid:
                return {'success': False, 'error': 'Financial record id is required to update.'}
            rec = FinancialRecord.query.filter_by(company_id=cid, id=int(rid)).first()
            if not rec:
                return {'success': False, 'error': f"Financial record #{rid} not found."}
            if data.get('amount') is not None: rec.amount = float(data['amount'])
            if data.get('category'): rec.category = str(data['category']).strip()[:100]
            if data.get('description'): rec.description = str(data['description']).strip()[:500]
            db.session.commit()
            return {'success': True, 'updated': 'financial_record', 'id': rec.id, 'amount': rec.amount, 'category': rec.category, 'currency_symbol': sym}

        if act == 'delete_financial_record':
            rid = data.get('id')
            if not rid:
                return {'success': False, 'error': 'Financial record id is required to delete.'}
            rec = FinancialRecord.query.filter_by(company_id=cid, id=int(rid)).first()
            if not rec:
                return {'success': False, 'error': f"Financial record #{rid} not found."}
            db.session.delete(rec)
            db.session.commit()
            return {'success': True, 'deleted': 'financial_record', 'id': int(rid)}

        if act == 'update_customer':
            cid_rec = data.get('id')
            cname = (data.get('company_name') or data.get('name') or '').strip()
            cust = Customer.query.filter_by(company_id=cid, id=int(cid_rec)).first() if cid_rec else Customer.query.filter(Customer.company_id == cid, Customer.company_name.ilike(f"%{cname}%")).first()
            if not cust:
                return {'success': False, 'error': f"Customer '{cname or cid_rec}' not found."}
            if data.get('segment'): cust.segment = str(data['segment']).strip()[:50]
            if data.get('lifetime_value') is not None: cust.lifetime_value = float(data['lifetime_value'])
            if data.get('email'): cust.email = str(data['email']).strip()[:120]
            db.session.commit()
            return {'success': True, 'updated': 'customer', 'id': cust.id, 'company_name': cust.company_name, 'lifetime_value': cust.lifetime_value}

        if act == 'delete_customer':
            cid_rec = data.get('id')
            cname = (data.get('company_name') or data.get('name') or '').strip()
            cust = Customer.query.filter_by(company_id=cid, id=int(cid_rec)).first() if cid_rec else Customer.query.filter(Customer.company_id == cid, Customer.company_name.ilike(f"%{cname}%")).first()
            if not cust:
                return {'success': False, 'error': f"Customer '{cname or cid_rec}' not found."}
            removed = cust.company_name
            db.session.delete(cust)
            db.session.commit()
            return {'success': True, 'deleted': 'customer', 'company_name': removed}

        if act == 'update_supplier':
            sid = data.get('id')
            sname = (data.get('name') or '').strip()
            sup = Supplier.query.filter_by(company_id=cid, id=int(sid)).first() if sid else Supplier.query.filter(Supplier.company_id == cid, Supplier.name.ilike(f"%{sname}%")).first()
            if not sup:
                return {'success': False, 'error': f"Supplier '{sname or sid}' not found."}
            if data.get('rating') is not None: sup.rating = float(data['rating'])
            if data.get('lead_time_days') is not None: sup.lead_time_days = int(data['lead_time_days'])
            if data.get('category'): sup.category = str(data['category']).strip()[:100]
            db.session.commit()
            return {'success': True, 'updated': 'supplier', 'id': sup.id, 'name': sup.name, 'rating': sup.rating}

        if act == 'delete_supplier':
            sid = data.get('id')
            sname = (data.get('name') or '').strip()
            sup = Supplier.query.filter_by(company_id=cid, id=int(sid)).first() if sid else Supplier.query.filter(Supplier.company_id == cid, Supplier.name.ilike(f"%{sname}%")).first()
            if not sup:
                return {'success': False, 'error': f"Supplier '{sname or sid}' not found."}
            removed = sup.name
            db.session.delete(sup)
            db.session.commit()
            return {'success': True, 'deleted': 'supplier', 'name': removed}

        if act == 'delete_inventory':
            sku = (data.get('sku') or '').strip()
            iid = data.get('id')
            item = Inventory.query.filter_by(company_id=cid, id=int(iid)).first() if iid else Inventory.query.filter(Inventory.company_id == cid, or_(Inventory.sku.ilike(sku), Inventory.name.ilike(f"%{data.get('name') or sku}%"))).first()
            if not item:
                return {'success': False, 'error': f"Inventory item '{sku or iid}' not found."}
            removed = item.sku or item.name
            db.session.delete(item)
            db.session.commit()
            return {'success': True, 'deleted': 'inventory', 'item': removed}

        if act == 'update_risk':
            rid = data.get('id')
            rname = (data.get('name') or '').strip()
            rk = Risk.query.filter_by(company_id=cid, id=int(rid)).first() if rid else Risk.query.filter(Risk.company_id == cid, Risk.name.ilike(f"%{rname}%")).first()
            if not rk:
                return {'success': False, 'error': f"Risk '{rname or rid}' not found."}
            if data.get('status'): rk.status = str(data['status']).strip().lower()[:30]
            if data.get('risk_level'): rk.risk_level = str(data['risk_level']).strip().lower()[:30]
            if data.get('mitigation_plan'): rk.mitigation_plan = str(data['mitigation_plan']).strip()
            db.session.commit()
            return {'success': True, 'updated': 'risk', 'id': rk.id, 'name': rk.name, 'status': rk.status}

        if act == 'delete_risk':
            rid = data.get('id')
            rname = (data.get('name') or '').strip()
            rk = Risk.query.filter_by(company_id=cid, id=int(rid)).first() if rid else Risk.query.filter(Risk.company_id == cid, Risk.name.ilike(f"%{rname}%")).first()
            if not rk:
                return {'success': False, 'error': f"Risk '{rname or rid}' not found."}
            removed = rk.name
            db.session.delete(rk)
            db.session.commit()
            return {'success': True, 'deleted': 'risk', 'name': removed}

        if act == 'update_project':
            pid = data.get('id')
            pname = (data.get('name') or '').strip()
            proj = Project.query.filter_by(company_id=cid, id=int(pid)).first() if pid else Project.query.filter(Project.company_id == cid, Project.name.ilike(f"%{pname}%")).first()
            if not proj:
                return {'success': False, 'error': f"Project '{pname or pid}' not found."}
            if data.get('status'): proj.status = str(data['status']).strip().lower()[:40]
            if data.get('priority'): proj.priority = str(data['priority']).strip().lower()[:30]
            if data.get('budget') is not None: proj.budget = float(data['budget'])
            db.session.commit()
            return {'success': True, 'updated': 'project', 'id': proj.id, 'name': proj.name, 'status': proj.status}

        if act == 'delete_project':
            pid = data.get('id')
            pname = (data.get('name') or '').strip()
            proj = Project.query.filter_by(company_id=cid, id=int(pid)).first() if pid else Project.query.filter(Project.company_id == cid, Project.name.ilike(f"%{pname}%")).first()
            if not proj:
                return {'success': False, 'error': f"Project '{pname or pid}' not found."}
            removed = proj.name
            db.session.delete(proj)
            db.session.commit()
            return {'success': True, 'deleted': 'project', 'name': removed}

        if act == 'delete_custom_twin':
            tid = data.get('id')
            tname = (data.get('twin_name') or data.get('name') or '').strip()
            twin = CustomTwin.query.filter_by(company_id=cid, id=int(tid)).first() if tid else CustomTwin.query.filter(CustomTwin.company_id == cid, CustomTwin.name.ilike(f"%{tname}%")).first()
            if not twin:
                return {'success': False, 'error': f"Custom twin '{tname or tid}' not found."}
            removed = twin.name
            db.session.delete(twin)
            db.session.commit()
            return {'success': True, 'deleted': 'custom_twin', 'name': removed}

        return {'success': False, 'error': f"Unknown action '{act}'"}

    # ─── 3. SIMULATIONS & DECISION SCANS ───
    if tool_name == 'run_analysis_or_simulation':
        act = (args.get('action') or 'what_if_simulation').strip().lower()
        if act == 'decision_scan':
            from services.decision_intelligence_service import DecisionIntelligenceService
            return DecisionIntelligenceService.run_decision_scan(company_id=cid, actor_user_id=uid, publish_events=True)
        from services.analytics_service import AnalyticsService
        summary = AnalyticsService.get_executive_summary(cid)
        rev_b = float(summary.get('revenue_30d') or 0.0)
        prof_b = float(summary.get('profit_30d') or 0.0)
        cost_b = max(0.0, rev_b - prof_b)
        rp = float(args.get('revenue_change_pct') or 0.0)
        ep = float(args.get('expense_change_pct') or 0.0)
        rev_a = round(rev_b * (1.0 + rp / 100.0), 2)
        cost_a = round(cost_b * (1.0 + ep / 100.0), 2)
        prof_a = round(rev_a - cost_a, 2)
        sim = Simulation(company_id=cid, user_id=uid, name=(args.get('name') or f"What-If ({rp:+.0f}% Rev / {ep:+.0f}% Exp)").strip()[:200], sim_type='agent_what_if', status='completed', parameters=json.dumps({'revenue_change_pct': rp, 'expense_change_pct': ep}), results=json.dumps({'revenue_after': rev_a, 'cost_after': cost_a, 'profit_after': prof_a}), revenue_before=rev_b, revenue_after=rev_a, cost_before=cost_b, cost_after=cost_a, profit_before=prof_b, profit_after=prof_a)
        db.session.add(sim)
        db.session.commit()
        return {'success': True, 'simulation_id': sim.id, 'name': sim.name, 'currency_symbol': sym, 'revenue_before': rev_b, 'revenue_after': rev_a, 'profit_before': prof_b, 'profit_after': prof_a, 'profit_delta': round(prof_a - prof_b, 2), 'view_url': f"/simulation/results/{sim.id}"}

    # ─── 4. PDF / EXCEL / CSV GENERATION ───
    if tool_name == 'generate_or_export_file':
        perm_err = _verify_write_permission(uid, cid, 'generate_or_export_file')
        if perm_err:
            return {'success': False, 'error': perm_err}
        fmt = (args.get('format_type') or 'pdf').strip().lower()
        target = (args.get('target') or 'executive').strip().lower()
        dept_filter = (args.get('department') or '').strip()
        title = (args.get('title') or f"Ayevoryn {target.replace('_', ' ').title()} Report").strip()

        if fmt == 'pdf':
            from services.report_service import ReportService
            rep_type = target if target in ('executive', 'financial', 'board', 'investor', 'risk', 'growth', 'forecast', 'operational', 'department') else 'executive'
            report = ReportService.generate_report(company_id=cid, user_id=uid, report_type=rep_type, name=title, format_type='pdf', currency_symbol=sym)
            rep_id = getattr(report, 'id', None)
            return {'success': True, 'report_id': rep_id, 'title': title, 'format': 'PDF', 'download_url': f"/reports/download/{rep_id}" if rep_id else "/reports/"}

        from services.agent_export_service import generate_multi_sheet_excel, generate_csv_export
        comp_name = company.company_name if company else 'Organization'

        def _sheet(ds):
            if ds in ('departments', 'department'):
                depts = Department.query.filter_by(company_id=cid).order_by(Department.name.asc()).all()
                return {'headers': ['Department', 'Code', 'Head', f'Budget ({sym})', f'Spent ({sym})', f'Variance ({sym})', 'Employees'], 'rows': [[d.name, d.code or '', d.head_name or '', float(d.budget or 0), float(d.spent or 0), round(float(d.budget or 0) - float(d.spent or 0), 2), Employee.query.filter_by(company_id=cid, department_id=d.id).count()] for d in depts]}
            if ds == 'employees':
                dmap = {d.id: d.name for d in Department.query.filter_by(company_id=cid).all()}
                q = Employee.query.filter_by(company_id=cid)
                if dept_filter:
                    mids = [did for did, dn in dmap.items() if dept_filter.lower() in (dn or '').lower()]
                    q = q.filter(Employee.department_id.in_(mids)) if mids else q.filter(Employee.id == -1)
                return {'headers': ['ID', 'Name', 'Department', 'Job Title', 'Email', f'Salary ({sym})', 'Status'], 'rows': [[e.employee_id or e.id, f"{e.first_name or ''} {e.last_name or ''}".strip(), dmap.get(e.department_id, 'Unassigned'), e.job_title or '', e.email or '', float(e.salary or 0), e.status or 'active'] for e in q.order_by(Employee.id.asc()).limit(1000).all()]}
            if ds in ('financials', 'financial'):
                recs = FinancialRecord.query.filter_by(company_id=cid).order_by(FinancialRecord.transaction_date.desc()).limit(1000).all()
                return {'headers': ['Date', 'Type', 'Category', f'Amount ({sym})', 'Description'], 'rows': [[r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '', r.transaction_type, r.category or '', float(r.amount or 0), r.description or ''] for r in recs]}
            if ds == 'customers':
                return {'headers': ['Company', 'Contact', 'Email', 'Segment', f'LTV ({sym})'], 'rows': [[c.company_name or '', f"{c.first_name or ''} {c.last_name or ''}".strip(), c.email or '', c.segment or '', float(c.lifetime_value or 0)] for c in Customer.query.filter_by(company_id=cid).order_by(Customer.lifetime_value.desc()).limit(1000).all()]}
            if ds == 'inventory':
                return {'headers': ['SKU', 'Name', 'On Hand', 'Reorder Point', f'Unit Cost ({sym})', f'Price ({sym})'], 'rows': [[i.sku, i.name, int(i.quantity_on_hand or 0), int(i.reorder_point or 0), float(i.unit_cost or 0), float(i.selling_price or 0)] for i in Inventory.query.filter_by(company_id=cid).limit(1000).all()]}
            if ds == 'suppliers':
                return {'headers': ['Supplier', 'Category', 'Contact', 'Lead Time (d)', 'Rating'], 'rows': [[s.name, s.category or '', s.contact_person or '', int(s.lead_time_days or 0), float(s.rating or 0)] for s in Supplier.query.filter_by(company_id=cid).limit(500).all()]}
            if ds in ('risks', 'risk'):
                return {'headers': ['Risk', 'Category', 'Level', 'Score', 'Status', 'Mitigation'], 'rows': [[r.name, r.category, r.risk_level, float(r.risk_score or 0), r.status, r.mitigation_plan or ''] for r in Risk.query.filter_by(company_id=cid).limit(500).all()]}
            return _sheet('departments')

        if fmt == 'csv':
            s = _sheet(target)
            return generate_csv_export(cid, s['headers'], s['rows'], title=title)
        if target in ('company_performance', 'executive', 'all'):
            sheets = {'Departments': _sheet('departments'), 'Financials': _sheet('financials'), 'Employees': _sheet('employees'), 'Risks': _sheet('risks')}
        else:
            sheets = {target.title(): _sheet(target)}
        return generate_multi_sheet_excel(comp_name, cid, sym, sheets, title=title)

    # ─── 5. UNIVERSAL AUTOMATIONS ───
    if tool_name == 'manage_automations':
        from services.pulse_automation_service import PulseAutomationService
        act = (args.get('action') or 'list').strip().lower()
        if act == 'list':
            items = PulseAutomationService.list_automations(cid)
            return {'count': len(items), 'automations': items}
        perm_err = _verify_write_permission(uid, cid, f'automation:{act}')
        if perm_err:
            return {'success': False, 'error': perm_err}
        if act == 'create':
            return PulseAutomationService.create_automation(
                company_id=cid, user_id=uid,
                name=args.get('name') or 'Scheduled Pulse AI Task',
                task_type=args.get('task_type') or ('generate_report' if args.get('report_type') else 'custom_agent_prompt'),
                interval_days=args.get('interval_days'),
                interval_hours=args.get('interval_hours'),
                report_type=args.get('report_type') or 'executive',
                format_type=args.get('format_type') or 'pdf',
                prompt=args.get('prompt') or '',
                run_immediately=bool(args.get('run_immediately', False))
            )
        aid = int(args.get('automation_id') or 0)
        if act == 'run_now':
            return PulseAutomationService.run_automation_now(aid, cid)
        if act == 'toggle':
            return PulseAutomationService.toggle_automation(aid, cid)
        if act == 'delete':
            return PulseAutomationService.delete_automation(aid, cid)
        return {'success': False, 'error': f"Unsupported automation action '{act}'"}

    return {'error': f"Unknown tool '{tool_name}'"}
