"""
AEVORYN PULSE AI — COMPACT 7-TOOL FULL-PLATFORM AUTONOMOUS AGENT SUITE
Consolidates all 38+ enterprise operations across every Ayevoryn module into 7 compact,
high-reliability OpenAI/NVIDIA NIM function-calling tools (<3.5 KB schema total) so compact
fast models like `nvidia/nemotron-3.5-bolt-e4b` execute tool calls with maximum accuracy
and never fail with HTTP 400/422 schema-overflow errors.
"""

import json
import re
from datetime import date, datetime
from sqlalchemy import or_
from database.db import db
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.risk import Risk
from database.models.project import Project
from database.models.simulation import Simulation
from database.models.forecast import Forecast
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.notification import Notification
from config.constants import CURRENCY_SYMBOLS
from services.pulse_agentic_router import PulseAgenticRouter


def build_full_agent_tools() -> list:
    """Return 7 compact, high-accuracy tool definitions covering every A-Z module, write action, export, automation, and navigation."""
    return [
        {
            "type": "function",
            "function": {
                "name": "query_company_module",
                "description": (
                    "Query LIVE records from ANY company module in the database. Use this for exact lists, names, "
                    "counts, balances, budgets, or details (e.g. employees in IT, departments, customers, financials, "
                    "bank_accounts, inventory, suppliers, risks, projects, simulations_forecasts, custom_twins, "
                    "branches_campaigns, loans_investments, market_competitors, documents_reports, audit_logs, twin_links)."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "module": {
                            "type": "string",
                            "enum": [
                                "employees", "departments", "customers", "financials", "bank_accounts", "company_upi_qr",
                                "inventory", "suppliers", "risks", "projects", "simulations_forecasts",
                                "custom_twins", "branches_campaigns", "loans_investments",
                                "market_competitors", "documents_reports", "audit_logs", "twin_links"
                            ]
                        },
                        "filter_department": {"type": "string", "description": "Optional department filter (e.g. 'IT')."},
                        "search": {"type": "string", "description": "Optional text search."},
                        "low_stock_only": {"type": "boolean"},
                        "limit": {"type": "integer"}, "offset": {"type": "integer", "description": "0-based row offset for pagination (e.g. offset=25, limit=25 for rows 26-50)."}, "sort_by": {"type": "string", "description": "Optional sort: salary_desc, salary_asc, id_asc"}
                    },
                    "required": ["module"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "modify_company_record",
                "description": (
                    "Full CRUD (Create, Update, Delete) on real company records across all modules and Twin-to-Department linking. "
                    "For any delete_* action, pass confirmed=true ONLY after the user explicitly confirms deletion."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {
                            "type": "string",
                            "enum": [
                                "add_department", "update_department_budget", "update_department", "delete_department",
                                "add_employee", "update_employee", "delete_employee",
                                "add_financial_record", "update_financial_record", "delete_financial_record",
                                "add_customer", "update_customer", "delete_customer",
                                "add_supplier", "update_supplier", "delete_supplier",
                                "add_or_update_inventory", "delete_inventory",
                                "add_risk", "update_risk", "delete_risk",
                                "add_project", "update_project", "delete_project",
                                "create_custom_twin_and_link", "link_twin_to_departments", "delete_custom_twin",
                                "send_notification"
                            ]
                        },
                        "data": {
                            "type": "object",
                            "description": "Fields for the action (e.g. id, name, budget, spent, head_name, department, first_name, last_name, salary, job_title, status, amount, transaction_type, category, sku, quantity_on_hand, risk_level, mitigation_plan, twin_name, department_names, title, message)."
                        },
                        "confirmed": {
                            "type": "boolean",
                            "description": "Set true only when the user has explicitly confirmed a destructive delete action."
                        }
                    },
                    "required": ["action", "data"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "run_analysis_or_simulation",
                "description": "Run a REAL live forecast (revenue, expense, profit, cashflow, or customers for 30/60/90/180/365 days via Forecasting Lab), a what-if financial simulation, a Decision Intelligence & Risk Scan, or an Autonomous Business Monitor sweep.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["run_forecast", "what_if_simulation", "decision_scan", "autonomous_monitor"]},
                        "name": {"type": "string"},
                        "revenue_change_pct": {"type": "number"},
                        "expense_change_pct": {"type": "number"},
                        "forecast_type": {"type": "string", "enum": ["revenue", "expense", "profit", "cashflow", "customers"]},
                        "horizon_days": {"type": "integer", "description": "Forecast horizon in days (e.g. 30, 60, 90, 180, 365)."},
                        "method": {"type": "string", "enum": ["auto", "linear", "exponential", "arima", "prophet"]}
                    },
                    "required": ["action"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "generate_or_export_file",
                "description": "Generate a REAL downloadable PDF report, multi-sheet Excel (.xlsx) workbook, or CSV file from live company data.",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "format_type": {"type": "string", "enum": ["pdf", "xlsx", "csv", "png"]},
                        "charts": {"type": "array", "items": {"type": "string"}, "description": "Live charts to embed from real DB data: line, pie, bar, heatmap, utilization, salary, inventory, risk, customer, supplier, project."},
                        "modules": {"type": "array", "items": {"type": "string"}, "description": "Optional specific modules: departments, utilization, financials, treasury, inventory, employees, customers, suppliers, risks, projects."},
                        "target": {
                            "type": "string",
                            "description": "Report/dataset type: executive, financial, board, risk, department, forecast, company_performance, departments, employees, financials, customers, inventory, suppliers, risks."
                        },
                        "department": {"type": "string"},
                        "title": {"type": "string"},
                        "sql_query": {"type": "string", "description": "Optional read-only SELECT SQL query (tables auto-scoped to company) to produce exact custom report rows & columns (e.g. employees 26-50, avg salary by department, salaries > 100000)."},
                        "custom_charts": {"type": "array", "items": {"type": "object"}, "description": "Optional custom chart specs: [{chart_type: 'line'|'bar'|'pie'|'donut'|'heatmap', title: '...', sql_query: 'SELECT label, val FROM ...' OR labels:[...], values:[...]/series:[{name,values}]}]."}
                    },
                    "required": ["format_type", "target"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "manage_automations",
                "description": (
                    "Create, list, run, pause/resume, or delete REAL recurring background automations (e.g. 'generate report every 3 days', "
                    "'check low stock every 6 hours and alert me'). Supports interval_days OR interval_hours."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "action": {"type": "string", "enum": ["create", "list", "run_now", "toggle", "delete"]},
                        "name": {"type": "string"},
                        "task_type": {"type": "string", "enum": ["custom_agent_prompt", "generate_report", "risk_scan", "ai_briefing"]},
                        "prompt": {"type": "string"},
                        "interval_days": {"type": "number"},
                        "interval_hours": {"type": "number"},
                        "interval_minutes": {"type": "number"},
                        "interval_seconds": {"type": "number"},
                        "report_type": {"type": "string"},
                        "format_type": {"type": "string", "enum": ["pdf", "excel"]},
                        "automation_id": {"type": "integer"},
                        "run_immediately": {"type": "boolean"}
                    },
                    "required": ["action"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "navigate_to_page",
                "description": (
                    "Navigate the user's browser directly to ANY page inside Ayevoryn with a smooth loading transition. "
                    "Pass the page name or route in `destination` (e.g. 'dashboard', 'departments', 'employees', 'revenue', "
                    "'expenses', 'customers', 'inventory', 'suppliers', 'payments', 'custom twins', 'revenue analytics', "
                    "'risk heatmap', 'simulation', 'forecasting', 'reports', 'documents', 'settings', 'dependency graph', 'ai insights', 'register', 'login', 'home')."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "destination": {"type": "string", "description": "Page name or exact URL path to open."}
                    },
                    "required": ["destination"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "run_live_sql_analysis",
                "description": (
                    "Execute a tenant-isolated read-only SELECT SQL query on ANY live company table "
                    "(employees, departments, department_budgets, financial_records, financial_accounts, "
                    "inventory, customers, suppliers, risks, projects, simulations, forecasts, company_payments) "
                    "for custom aggregations, GROUP BY, AVG/SUM/COUNT, filters, thresholds, or exact pagination (LIMIT/OFFSET)."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "sql_query": {"type": "string", "description": "Read-only SELECT query (all tables are automatically scoped to this company)."},
                        "max_rows": {"type": "integer", "description": "Max rows to return (default 100, max 500)."}
                    },
                    "required": ["sql_query"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "run_python_data_analysis",
                "description": (
                    "Autonomous Cline-style Python Data Analyst sandbox pre-loaded with 100% LIVE company `data` "
                    "(keys: company, departments, employees, financials, accounts, inventory, customers, suppliers, risks, projects), "
                    "`plt` (matplotlib), `np`, `math`, `statistics`, `collections`, plus helpers `save_chart(fig, title)`, "
                    "`save_excel(sheets_dict, charts_list, title)`, `save_pdf(datasets_dict, charts_list, title, summary, recommendations)`, "
                    "and `save_csv(headers, rows, title)`. Use this for ANY custom calculation, trendline, forecast, statistical analysis, "
                    "custom chart, or custom Excel/PDF report from live company data. Never hardcode zeros."
                ),
                "parameters": {
                    "type": "object",
                    "properties": {
                        "code": {"type": "string", "description": "Safe Python script using pre-loaded `data`, `plt`, `save_chart`, `save_excel`, `save_pdf`, `save_csv`."}
                    },
                    "required": ["code"]
                }
            }
        },
        {
            "type": "function",
            "function": {
                "name": "toggle_theme",
                "description": "Switch the user interface between dark and light mode.",
                "parameters": {
                    "type": "object",
                    "properties": {"theme": {"type": "string", "enum": ["dark", "light", "toggle"]}},
                    "required": ["theme"]
                }
            }
        }
    ]


def _verify_write_permission(user_id: int, company_id: int, action_label: str):
    try:
        from database.models.user import User
        actor = db.session.get(User, int(user_id))
        if actor:
            role = (getattr(actor, 'role', '') or '').lower()
            if role in ('viewer', 'readonly', 'guest'):
                return f"Permission denied: role '{role}' cannot execute '{action_label}'."
            if getattr(actor, 'company_id', None) and int(actor.company_id) != int(company_id) and not getattr(actor, 'is_superadmin', False):
                return "Tenant isolation violation: user does not belong to target organization."
    except Exception:
        pass
    return None



# ── AI SECURITY: RISK CLASSIFICATION, CONFIRMATION GATE & PROMPT-INJECTION DEFENSE (Phases 13 & 18) ──
TOOL_RISK_CLASSIFICATION = {
    'query_company_module': 'read',
    'run_live_sql_analysis': 'read',
    'run_python_data_analysis': 'read',
    'modify_company_record': 'write',
    'run_business_intelligence': 'read',
    'generate_business_export': 'read',
    'manage_automation': 'write',
    'navigate_to_page': 'read',
    'change_ui_theme': 'read',
}

DESTRUCTIVE_SUBACTIONS = {
    'delete_financial_record', 'delete_customer', 'delete_supplier', 'delete_inventory', 'delete_risk', 'delete_project',
    'delete_department', 'delete_employee', 'delete_record', 'delete_automation',
    'delete_custom_twin', 'bulk_delete', 'purge', 'reset_budgets',
}

_INJECTION_PATTERNS = [
    re.compile(r'(?i)ignore\s+(?:all\s+|any\s+)?(?:previous|prior|above|system)\s+instructions?'),
    re.compile(r'(?i)(?:reveal|print|dump|output|show)\s+(?:your\s+)?(?:system\s+prompt|api[\s_-]?key|secret[\s_-]?key|env(?:ironment)?\s+variables?|\.env)'),
    re.compile(r'(?i)(?:bypass|override|disable)\s+(?:rbac|permissions?|tenant\s+isolation|security|authentication)'),
    re.compile(r'(?i)(?:os\.system|subprocess|__import__|exec\(|eval\(|rm\s+-rf|drop\s+table)'),
]


def detect_prompt_injection(text: str) -> dict:
    """Detect common prompt-injection, secret-exfiltration, or tenant-bypass attempts."""
    s = str(text or '')
    matched = []
    for pat in _INJECTION_PATTERNS:
        m = pat.search(s)
        if m:
            matched.append(m.group(0)[:80])
    return {'flagged': bool(matched), 'matches': matched}


def sanitize_untrusted_text(text: str, max_len: int = 4000) -> str:
    """Neutralize control characters and prompt-injection markers in untrusted text."""
    s = str(text or '')[:max_len]
    s = re.sub(r'[\x00-\x08\x0b\x0c\x0e-\x1f]', '', s)
    return s.strip()


def classify_tool_risk(tool_name: str, args: dict = None) -> str:
    """Return 'read', 'write', or 'destructive' for a given tool call."""
    args = args or {}
    sub = str(args.get('action') or args.get('operation') or '').strip().lower()
    if sub in DESTRUCTIVE_SUBACTIONS or sub.startswith('delete_'):
        return 'destructive'
    return TOOL_RISK_CLASSIFICATION.get(tool_name, 'write')



_TENANT_SAFE_TABLES = (
    'employees', 'departments', 'department_budgets', 'financial_records',
    'financial_accounts', 'inventory', 'customers', 'suppliers', 'risks',
    'projects', 'simulations', 'forecasts', 'custom_twins', 'custom_twin_records',
    'company_payments', 'branches', 'marketing_campaigns', 'loans', 'investments',
)
_SQL_FORBIDDEN_RE = re.compile(
    r'\b(INSERT|UPDATE|DELETE|DROP|ALTER|CREATE|REPLACE|TRUNCATE|ATTACH|DETACH|PRAGMA|VACUUM|REINDEX|EXEC|EXECUTE|GRANT|REVOKE|sqlite_master|sqlite_temp_master|users|superadmin_)\b',
    re.I,
)


def _build_tenant_scoped_sql(cid: int, raw_sql: str):
    """
    Validate a read-only SELECT query and wrap every referenced company table in a
    tenant-isolated CTE (`WITH tbl AS (SELECT * FROM main.tbl WHERE company_id = <cid>)`)
    so cross-tenant leakage is impossible even if the LLM omits `WHERE company_id = ...`.
    """
    sql = (raw_sql or '').strip().rstrip(';').strip()
    if not sql:
        return None, 'SQL query cannot be empty.'
    if ';' in sql:
        return None, 'Multiple SQL statements are not allowed.'
    if not re.match(r'^(SELECT|WITH)\b', sql, re.I):
        return None, 'Only read-only SELECT queries are permitted.'
    if _SQL_FORBIDDEN_RE.search(sql):
        return None, 'Query contains forbidden write or restricted system table keywords.'

    sql_low = sql.lower()
    used_tables = [t for t in _TENANT_SAFE_TABLES if re.search(rf'\b{t}\b', sql_low)]
    if not used_tables:
        return None, f'Query must reference at least one company table ({", ".join(_TENANT_SAFE_TABLES[:8])}, ...).'

    safe_cid = int(cid)
    cte_defs = [f"{t} AS (SELECT * FROM main.{t} WHERE company_id = {safe_cid})" for t in used_tables]
    if re.match(r'^WITH\b', sql, re.I):
        rest = re.sub(r'^WITH\s+', '', sql, count=1, flags=re.I)
        wrapped = f"WITH {', '.join(cte_defs)}, {rest}"
    else:
        wrapped = f"WITH {', '.join(cte_defs)} {sql}"
    return wrapped, None


def _execute_tenant_safe_sql(cid: int, raw_sql: str, max_rows: int = 250) -> dict:
    """Execute a validated, tenant-scoped read-only SQL query against the live company DB."""
    from sqlalchemy import text as sa_text
    wrapped, err = _build_tenant_scoped_sql(cid, raw_sql)
    if err:
        return {'success': False, 'error': err}
    limit_cap = min(500, max(1, int(max_rows or 250)))
    try:
        result = db.session.execute(sa_text(wrapped))
        cols = list(result.keys())
        fetched = result.fetchmany(limit_cap)
        rows = []
        for r in fetched:
            row_list = []
            for v in r:
                if isinstance(v, (int, float)) or v is None:
                    row_list.append(v)
                else:
                    row_list.append(str(v))
            rows.append(row_list)
        return {
            'success': True,
            'columns': cols,
            'row_count': len(rows),
            'rows': rows,
            'records': [dict(zip(cols, rw)) for rw in rows[:100]],
        }
    except Exception as ex:
        return {'success': False, 'error': f'SQL execution error: {str(ex)[:260]}'}


def _chart_spec_from_sql(cid: int, spec: dict, sym: str):
    """Build a live chart spec dict directly from a custom SQL query (col 0 = label, col 1..N = numeric series)."""
    res = _execute_tenant_safe_sql(cid, spec.get('sql_query') or '', max_rows=60)
    if not res.get('success') or not res.get('rows') or len(res.get('columns') or []) < 2:
        return None
    cols = res['columns']
    rows = res['rows']
    ctype = (spec.get('chart_type') or 'bar').strip().lower()
    title = str(spec.get('title') or f"Live {cols[1].replace('_', ' ').title()} by {cols[0].replace('_', ' ').title()}")
    labels = [str(r[0])[:20] for r in rows]
    palette = ['#0284C7', '#10B981', '#6366F1', '#F59E0B', '#EF4444', '#14B8A6']

    if ctype in ('pie', 'donut'):
        vals = [max(0.0, float(r[1] or 0.0)) for r in rows]
        return {'chart_type': ctype, 'title': title, 'labels': labels, 'values': vals}

    series = []
    for c_idx in range(1, min(len(cols), 5)):
        s_vals = []
        for r in rows:
            try:
                s_vals.append(round(float(r[c_idx] or 0.0), 2))
            except (TypeError, ValueError):
                s_vals.append(0.0)
        series.append({
            'name': str(cols[c_idx]).replace('_', ' ').title(),
            'values': s_vals,
            'color': palette[(c_idx - 1) % len(palette)],
        })
    return {
        'chart_type': ctype if ctype in ('line', 'bar') else 'bar',
        'title': title,
        'labels': labels,
        'y_label': spec.get('y_label') or f"{cols[1].replace('_', ' ').title()} ({sym})",
        'series': series,
    }


def execute_agent_tool(tool_name: str, args: dict, company_id: int, user_id: int) -> dict:
    args = args if isinstance(args, dict) else {}
    risk_level = classify_tool_risk(tool_name, args)
    if risk_level == 'destructive' and not bool(args.get('confirmed')):
        _d = args.get('data') if isinstance(args.get('data'), dict) else {}
        target = _d.get('name') or _d.get('department_name') or _d.get('company_name') or _d.get('sku') or _d.get('id') or args.get('name') or args.get('automation_id') or 'selected record'
        return {
            'success': False,
            'requires_confirmation': True,
            'risk_level': 'destructive',
            'tool_name': tool_name,
            'target': str(target),
            'error': f'Confirmation required before executing destructive action ({args.get("action") or tool_name}) on {target}.',
            'message': f'This action ({args.get("action") or tool_name}) on "{target}" is destructive. Please confirm explicitly before I proceed.',
        }

    """Execute any of the compact meta-tools against the live tenant-scoped SQLAlchemy database."""
    args = args if isinstance(args, dict) else {}
    cid = int(company_id)
    uid = int(user_id or 1)
    company = db.session.get(Company, cid)
    sym = CURRENCY_SYMBOLS.get((company.currency if company else 'USD') or 'USD', '$')

    # ─── 0. DYNAMIC TENANT-ISOLATED SQL ANALYSIS ───
    if tool_name == 'run_live_sql_analysis':
        return _execute_tenant_safe_sql(cid, args.get('sql_query') or '', max_rows=args.get('max_rows') or 100)

    if tool_name == 'run_python_data_analysis':
        from services.pulse_python_analyst import execute_python_data_analysis
        return execute_python_data_analysis(cid, args.get('code') or '')

    # ─── 1. QUERY ANY MODULE ───
    if tool_name == 'query_company_module':
        mod = (args.get('module') or '').strip().lower()
        dept_filter = (args.get('filter_department') or '').strip()
        search = (args.get('search') or '').strip()
        low_only = bool(args.get('low_stock_only'))
        limit = min(150, max(1, int(args.get('limit') or 50)))

        if mod == 'employees':
            dept_map = {d.id: d.name for d in Department.query.filter_by(company_id=cid).all()}
            q = Employee.query.filter(Employee.company_id == cid)
            if dept_filter:
                mids = [did for did, dn in dept_map.items() if dept_filter.lower() in (dn or '').lower()]
                if not mids:
                    return {'total_matching': 0, 'department_filter': dept_filter, 'available_departments': list(dept_map.values()), 'employees': []}
                q = q.filter(Employee.department_id.in_(mids))
            if search:
                like = f"%{search}%"
                q = q.filter(or_(Employee.first_name.ilike(like), Employee.last_name.ilike(like), Employee.email.ilike(like), Employee.job_title.ilike(like)))
            total = q.count()
            offset_val = max(0, int(args.get('offset') or 0))
            sort_by = (args.get('sort_by') or 'id_asc').strip().lower()
            if sort_by == 'salary_desc':
                q = q.order_by(Employee.salary.desc(), Employee.id.asc())
            elif sort_by == 'salary_asc':
                q = q.order_by(Employee.salary.asc(), Employee.id.asc())
            else:
                q = q.order_by(Employee.id.asc())
            rows = q.offset(offset_val).limit(limit).all()
            return {
                'total_matching': total, 'returned_count': len(rows), 'currency_symbol': sym,
                'employees': [{'id': e.id, 'employee_id': e.employee_id, 'name': f"{e.first_name or ''} {e.last_name or ''}".strip(), 'email': e.email or '', 'department': dept_map.get(e.department_id, 'Unassigned'), 'job_title': e.job_title or '', 'salary': float(e.salary or 0.0), 'status': e.status or 'active'} for e in rows]
            }

        if mod == 'departments':
            q = Department.query.filter_by(company_id=cid)
            if search:
                q = q.filter(Department.name.ilike(f"%{search}%"))
            depts = q.order_by(Department.name.asc()).all()
            return {'count': len(depts), 'currency_symbol': sym, 'departments': [{'id': d.id, 'name': d.name, 'code': d.code, 'head_name': d.head_name or '', 'budget': float(d.budget or 0.0), 'spent': float(d.spent or 0.0), 'actual_employee_count': Employee.query.filter_by(company_id=cid, department_id=d.id).count()} for d in depts]}

        if mod == 'customers':
            q = Customer.query.filter_by(company_id=cid)
            if search:
                like = f"%{search}%"
                q = q.filter(or_(Customer.first_name.ilike(like), Customer.last_name.ilike(like), Customer.company_name.ilike(like), Customer.email.ilike(like)))
            rows = q.order_by(Customer.lifetime_value.desc()).limit(limit).all()
            return {'total_matching': q.count(), 'currency_symbol': sym, 'customers': [{'id': c.id, 'name': f"{c.first_name or ''} {c.last_name or ''}".strip() or c.company_name, 'company_name': c.company_name or '', 'email': c.email or '', 'segment': c.segment or '', 'lifetime_value': float(c.lifetime_value or 0.0)} for c in rows]}

        if mod == 'financials':
            q = FinancialRecord.query.filter_by(company_id=cid)
            if search:
                q = q.filter(or_(FinancialRecord.category.ilike(f"%{search}%"), FinancialRecord.description.ilike(f"%{search}%"), FinancialRecord.transaction_type.ilike(f"%{search}%")))
            rows = q.order_by(FinancialRecord.transaction_date.desc(), FinancialRecord.id.desc()).limit(limit).all()
            return {'total_matching': q.count(), 'returned_sum': sum(float(r.amount or 0.0) for r in rows), 'currency_symbol': sym, 'records': [{'id': r.id, 'date': r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '', 'type': r.transaction_type, 'category': r.category or '', 'amount': float(r.amount or 0.0), 'description': r.description or ''} for r in rows]}

        if mod in ('company_upi_qr', 'upi_qr', 'upi', 'payment_qr'):
            from database.models.company_payments import CompanyPayments
            from urllib.parse import urlencode
            pay = CompanyPayments.query.filter_by(company_id=cid).order_by(CompanyPayments.is_primary_account.desc(), CompanyPayments.id.asc()).first()
            if not pay or (not (pay.upi_id or '').strip() and not (pay.upi_link or '').strip() and not (pay.qr_code_path or '').strip()):
                return {
                    'configured': False,
                    'message': 'No UPI ID or payment QR is configured for this company yet. Go to Settings -> Payments to add your UPI ID.'
                }
            params = {}
            if args.get('amount'):
                params['amount'] = str(args.get('amount'))
            if args.get('note'):
                params['note'] = str(args.get('note'))
            qs = ('?' + urlencode(params)) if params else ''
            dl_params = dict(params, download='1')
            dl_qs = '?' + urlencode(dl_params)
            qr_url = f"/pulse-ai/api/company-upi-qr{qs}"
            dl_url = f"/pulse-ai/api/company-upi-qr{dl_qs}"
            return {
                'configured': True,
                'upi_id': pay.upi_id or '',
                'display_name': pay.upi_display_name or (company.company_name if company else ''),
                'bank_name': pay.bank_name or '',
                'bank_ifsc': pay.bank_ifsc or '',
                'qr_image_url': qr_url,
                'download_url': dl_url,
                'title': 'Company UPI Payment QR',
                'format': 'PNG',
                'markdown_image': f"![Company UPI Payment QR]({qr_url})",
                'instructions': f"Include this exact image Markdown in your response so the user sees the scannable QR code inline: ![Company UPI Payment QR]({qr_url})"
            }

        if mod == 'bank_accounts':
            accs = FinancialAccount.query.filter_by(company_id=cid).order_by(FinancialAccount.current_balance.desc()).all()
            return {'count': len(accs), 'currency_symbol': sym, 'total_balance': sum(float(a.current_balance or 0.0) for a in accs), 'accounts': [{'id': a.id, 'name': a.account_name, 'type': a.account_type, 'balance': float(a.current_balance or 0.0), 'is_active': bool(a.is_active)} for a in accs]}

        if mod == 'inventory':
            q = Inventory.query.filter_by(company_id=cid)
            if search:
                q = q.filter(or_(Inventory.sku.ilike(f"%{search}%"), Inventory.name.ilike(f"%{search}%")))
            if low_only:
                q = q.filter(Inventory.quantity_on_hand <= Inventory.reorder_point)
            rows = q.order_by(Inventory.quantity_on_hand.asc()).limit(limit).all()
            return {'total_matching': q.count(), 'currency_symbol': sym, 'items': [{'sku': i.sku, 'name': i.name, 'quantity_on_hand': int(i.quantity_on_hand or 0), 'reorder_point': int(i.reorder_point or 0), 'unit_cost': float(i.unit_cost or 0.0), 'selling_price': float(i.selling_price or 0.0)} for i in rows]}

        if mod == 'suppliers':
            q = Supplier.query.filter_by(company_id=cid)
            if search:
                q = q.filter(or_(Supplier.name.ilike(f"%{search}%"), Supplier.category.ilike(f"%{search}%")))
            rows = q.order_by(Supplier.rating.desc()).limit(limit).all()
            return {'count': len(rows), 'suppliers': [{'name': s.name, 'category': s.category or '', 'contact_person': s.contact_person or '', 'lead_time_days': int(s.lead_time_days or 0), 'rating': float(s.rating or 0.0)} for s in rows]}

        if mod == 'risks':
            rows = Risk.query.filter_by(company_id=cid).order_by(Risk.risk_score.desc()).limit(limit).all()
            return {'count': len(rows), 'risks': [{'name': r.name, 'category': r.category, 'risk_level': r.risk_level, 'risk_score': float(r.risk_score or 0.0), 'status': r.status, 'mitigation_plan': r.mitigation_plan or ''} for r in rows]}

        if mod == 'projects':
            rows = Project.query.filter_by(company_id=cid).order_by(Project.created_at.desc()).limit(limit).all()
            return {'count': len(rows), 'currency_symbol': sym, 'projects': [{'name': p.name, 'status': p.status, 'priority': p.priority, 'budget': float(p.budget or 0.0), 'spent': float(p.spent or 0.0), 'progress': float(p.progress or 0.0)} for p in rows]}

        if mod == 'simulations_forecasts':
            sims = Simulation.query.filter_by(company_id=cid).order_by(Simulation.id.desc()).limit(10).all()
            fcs = Forecast.query.filter_by(company_id=cid).order_by(Forecast.id.desc()).limit(10).all()
            return {'currency_symbol': sym, 'simulations': [{'id': s.id, 'name': s.name, 'profit_before': float(s.profit_before or 0.0), 'profit_after': float(s.profit_after or 0.0)} for s in sims], 'forecasts': [{'id': f.id, 'name': f.name, 'type': f.forecast_type, 'horizon_days': f.horizon_days, 'r2': f.accuracy_r2} for f in fcs]}

        if mod == 'custom_twins':
            twins = CustomTwin.query.filter_by(company_id=cid, is_active=True).all()
            return {'count': len(twins), 'custom_twins': [{'id': t.id, 'name': t.name, 'slug': t.slug, 'record_count': CustomTwinRecord.query.filter_by(company_id=cid, twin_id=t.id).count()} for t in twins]}

        if mod == 'branches_campaigns':
            from database.models.branch import Branch
            from database.models.marketing_campaign import MarketingCampaign
            return {
                'branches': [{'id': b.id, 'name': getattr(b, 'name', ''), 'city': getattr(b, 'city', '')} for b in Branch.query.filter_by(company_id=cid).all()],
                'campaigns': [{'id': c.id, 'name': getattr(c, 'name', ''), 'budget': float(getattr(c, 'budget', 0) or 0), 'status': getattr(c, 'status', '')} for c in MarketingCampaign.query.filter_by(company_id=cid).all()]
            }

        if mod == 'loans_investments':
            from database.models.loan import Loan
            from database.models.investment import Investment
            return {
                'currency_symbol': sym,
                'loans': [{'id': l.id, 'name': getattr(l, 'name', getattr(l, 'lender', 'Loan')), 'amount': float(getattr(l, 'principal_amount', getattr(l, 'amount', 0)) or 0)} for l in Loan.query.filter_by(company_id=cid).all()],
                'investments': [{'id': iv.id, 'name': getattr(iv, 'name', 'Investment'), 'amount': float(getattr(iv, 'amount', 0) or 0)} for iv in Investment.query.filter_by(company_id=cid).all()]
            }

        if mod == 'market_competitors':
            from database.models.competitor import Competitor
            from database.models.market_data import MarketData
            return {
                'competitors': [{'name': c.name, 'market_share': getattr(c, 'market_share', None)} for c in Competitor.query.filter_by(company_id=cid).all()],
                'market_data': [{'metric': getattr(m, 'metric_name', getattr(m, 'category', '')), 'value': getattr(m, 'value', None)} for m in MarketData.query.filter_by(company_id=cid).limit(20).all()]
            }

        if mod == 'documents_reports':
            from database.models.document import Document
            from database.models.report import Report
            return {
                'documents': [{'id': d.id, 'title': getattr(d, 'title', getattr(d, 'filename', 'Document')), 'download_url': f'/documents/download/{d.id}'} for d in Document.query.filter_by(company_id=cid).order_by(Document.id.desc()).limit(15).all()],
                'reports': [{'id': r.id, 'name': getattr(r, 'name', 'Report'), 'type': getattr(r, 'report_type', ''), 'download_url': f'/reports/download/{r.id}'} for r in Report.query.filter_by(company_id=cid).order_by(Report.id.desc()).limit(15).all()]
            }

        if mod == 'audit_logs':
            from database.models.audit_log import AuditLog
            logs = AuditLog.query.filter_by(company_id=cid).order_by(AuditLog.id.desc()).limit(25).all()
            return {'count': len(logs), 'logs': [{'action': getattr(l, 'action', ''), 'entity': getattr(l, 'entity_type', ''), 'timestamp': str(getattr(l, 'created_at', ''))} for l in logs]}

        if mod == 'twin_links':
            from database.models.twin_dependency import TwinDependency
            deps = TwinDependency.query.filter_by(company_id=cid, is_active=True).all()
            return {'count': len(deps), 'links': [{'source': f"{d.source_type}:{d.source_id}", 'target': f"{d.target_type}:{d.target_id}", 'strength': d.strength, 'description': d.description or ''} for d in deps]}

        return {'error': f"Unsupported module '{mod}'"}

    # ─── 2. MODIFY COMPANY RECORDS & TWIN LINKING ───
    if tool_name == 'modify_company_record':
        act = (args.get('action') or '').strip().lower()
        data = args.get('data') if isinstance(args.get('data'), dict) else {}
        perm_err = _verify_write_permission(uid, cid, act)
        if perm_err:
            return {'success': False, 'error': perm_err}

        if act == 'add_department':
            name = (data.get('name') or '').strip()
            if not name:
                return {'success': False, 'error': 'Department name is required'}
            dept = Department(company_id=cid, name=name[:200], code=''.join(c for c in name.upper() if c.isalnum())[:6] or 'DEPT', budget=float(data.get('budget') or 0.0), head_name=(data.get('head_name') or '').strip()[:200], description=(data.get('description') or 'Created by Aevoryn Pulse AI').strip())
            db.session.add(dept)
            db.session.commit()
            from services.twin_auto_linker import auto_link_department_to_twins
            linked = auto_link_department_to_twins(cid, dept, user_id=uid)
            return {'success': True, 'department_id': dept.id, 'name': dept.name, 'budget': dept.budget, 'currency_symbol': sym, 'auto_linked_twins': linked}

        if act == 'update_department_budget':
            dname = (data.get('department_name') or data.get('name') or '').strip()
            d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{dname}%")).first()
            if not d:
                return {'success': False, 'error': f"Department '{dname}' not found."}
            if data.get('new_budget') is not None or data.get('budget') is not None:
                d.budget = float(data.get('new_budget') if data.get('new_budget') is not None else data.get('budget'))
            if data.get('spent') is not None:
                d.spent = float(data['spent'])
            db.session.commit()
            return {'success': True, 'department': d.name, 'budget': d.budget, 'spent': d.spent, 'currency_symbol': sym}

        if act == 'add_employee':
            dept_id = None
            if data.get('department'):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(data['department']).strip()}%")).first()
                if d:
                    dept_id = d.id
            emp = Employee(company_id=cid, first_name=(data.get('first_name') or 'New').strip()[:100], last_name=(data.get('last_name') or 'Employee').strip()[:100], department_id=dept_id, job_title=(data.get('job_title') or 'Team Member').strip()[:200], salary=float(data.get('salary') or 0.0), email=(data.get('email') or '').strip()[:120], status='active', hire_date=date.today())
            db.session.add(emp)
            db.session.commit()
            return {'success': True, 'employee_id': emp.id, 'name': f"{emp.first_name} {emp.last_name}", 'salary': emp.salary, 'currency_symbol': sym}

        if act == 'add_financial_record':
            tx_type = (data.get('transaction_type') or 'expense').strip().lower()
            rec = FinancialRecord(company_id=cid, transaction_type=tx_type if tx_type in ('revenue', 'expense') else 'expense', amount=float(data.get('amount') or 0.0), category=(data.get('category') or 'General').strip()[:100], description=(data.get('description') or 'Logged by Aevoryn Pulse AI').strip()[:500], transaction_date=date.today())
            db.session.add(rec)
            db.session.commit()
            return {'success': True, 'record_id': rec.id, 'type': rec.transaction_type, 'amount': rec.amount, 'currency_symbol': sym}

        if act == 'add_customer':
            cust = Customer(company_id=cid, company_name=(data.get('company_name') or data.get('name') or 'New Client').strip()[:200], first_name=(data.get('first_name') or '').strip()[:100], last_name=(data.get('last_name') or '').strip()[:100], email=(data.get('email') or '').strip()[:120], segment=(data.get('segment') or 'Enterprise').strip()[:50], lifetime_value=float(data.get('lifetime_value') or 0.0), acquisition_date=date.today())
            db.session.add(cust)
            db.session.commit()
            return {'success': True, 'customer_id': cust.id, 'company_name': cust.company_name}

        if act == 'add_supplier':
            sup = Supplier(company_id=cid, name=(data.get('name') or 'New Supplier').strip()[:200], category=(data.get('category') or 'General').strip()[:100], contact_person=(data.get('contact_person') or '').strip()[:200], email=(data.get('email') or '').strip()[:120], lead_time_days=int(data.get('lead_time_days') or 7), rating=float(data.get('rating') or 4.0))
            db.session.add(sup)
            db.session.commit()
            return {'success': True, 'supplier_id': sup.id, 'name': sup.name}

        if act == 'add_or_update_inventory':
            sku = (data.get('sku') or '').strip()
            existing = Inventory.query.filter_by(company_id=cid, sku=sku).first() if sku else None
            if existing:
                existing.quantity_on_hand = int(data.get('quantity_on_hand', existing.quantity_on_hand))
                db.session.commit()
                return {'success': True, 'action': 'updated', 'sku': existing.sku, 'quantity_on_hand': existing.quantity_on_hand}
            item = Inventory(company_id=cid, sku=sku or f"SKU-{int(datetime.utcnow().timestamp()) % 100000}", name=(data.get('name') or 'New Item').strip()[:200], quantity_on_hand=int(data.get('quantity_on_hand') or 0), quantity_available=int(data.get('quantity_on_hand') or 0), reorder_point=int(data.get('reorder_point') or 10), unit_cost=float(data.get('unit_cost') or 0.0), selling_price=float(data.get('selling_price') or 0.0), category=(data.get('category') or 'General').strip()[:100])
            db.session.add(item)
            db.session.commit()
            return {'success': True, 'action': 'created', 'sku': item.sku, 'name': item.name}

        if act == 'add_risk':
            prob = min(1.0, max(0.05, float(data.get('probability') or 0.5)))
            imp = min(1.0, max(0.05, float(data.get('impact') or 0.6)))
            rk = Risk(company_id=cid, name=(data.get('name') or 'Operational Risk').strip()[:200], category=(data.get('category') or 'operational').strip()[:50], risk_level=(data.get('risk_level') or 'medium').strip().lower(), probability=prob, impact=imp, risk_score=round(prob * imp * 100.0, 1), status='active', mitigation_plan=(data.get('mitigation_plan') or '').strip())
            db.session.add(rk)
            db.session.commit()
            return {'success': True, 'risk_id': rk.id, 'name': rk.name, 'risk_score': rk.risk_score}

        if act == 'add_project':
            dept_id = None
            if data.get('department'):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(data['department']).strip()}%")).first()
                if d:
                    dept_id = d.id
            proj = Project(company_id=cid, name=(data.get('name') or 'New Project').strip()[:200], department_id=dept_id, budget=float(data.get('budget') or 0.0), priority=(data.get('priority') or 'medium').strip().lower(), status=(data.get('status') or 'planning').strip().lower())
            db.session.add(proj)
            db.session.commit()
            return {'success': True, 'project_id': proj.id, 'name': proj.name}

        if act == 'create_custom_twin_and_link':
            from services.twin_auto_linker import auto_link_custom_twin_to_departments
            tname = (data.get('name') or '').strip()
            if not tname:
                return {'success': False, 'error': 'Twin name is required'}
            slug = re.sub(r'[^a-z0-9]+', '-', tname.lower()).strip('-') or 'custom-twin'
            if CustomTwin.query.filter_by(company_id=cid, slug=slug).first():
                slug = f"{slug}-{int(datetime.utcnow().timestamp()) % 10000}"
            twin = CustomTwin(company_id=cid, name=tname[:100], slug=slug[:100], description=(data.get('description') or '').strip(), created_by=uid)
            db.session.add(twin)
            db.session.commit()
            dept_ids = []
            for dn in (data.get('department_names') or []):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(dn).strip()}%")).first()
                if d:
                    dept_ids.append(d.id)
            linked = auto_link_custom_twin_to_departments(cid, twin, user_id=uid, explicit_dept_ids=dept_ids)
            return {'success': True, 'twin_id': twin.id, 'name': twin.name, 'url': f'/business-twin/custom-twins/{twin.slug}', 'auto_linked_departments': linked}

        if act == 'link_twin_to_departments':
            from services.twin_auto_linker import auto_link_custom_twin_to_departments
            tname = (data.get('twin_name') or data.get('name') or '').strip()
            twin = CustomTwin.query.filter(CustomTwin.company_id == cid, CustomTwin.name.ilike(f"%{tname}%")).first()
            if not twin:
                return {'success': False, 'error': f"Custom twin '{tname}' not found."}
            dept_ids = []
            for dn in (data.get('department_names') or []):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(dn).strip()}%")).first()
                if d:
                    dept_ids.append(d.id)
            linked = auto_link_custom_twin_to_departments(cid, twin, user_id=uid, explicit_dept_ids=dept_ids)
            return {'success': True, 'twin': twin.name, 'linked_departments': linked}

        if act == 'send_notification':
            n = Notification(company_id=cid, user_id=uid, title=(data.get('title') or 'Pulse AI Alert').strip()[:200], message=(data.get('message') or '').strip()[:1000], notification_type='info', module='pulse_ai', action_link=(data.get('action_link') or '/pulse-ai/').strip()[:500], action_text='View')
            db.session.add(n)
            db.session.commit()
            return {'success': True, 'notification_id': n.id, 'title': n.title}

        if act == 'update_department':
            did = data.get('id')
            dname = (data.get('department_name') or data.get('name') or '').strip()
            d = Department.query.filter_by(company_id=cid, id=int(did)).first() if did else Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{dname}%")).first()
            if not d:
                return {'success': False, 'error': f"Department '{dname or did}' not found."}
            if data.get('new_name'): d.name = str(data['new_name']).strip()[:200]
            if data.get('budget') is not None: d.budget = float(data['budget'])
            if data.get('spent') is not None: d.spent = float(data['spent'])
            if data.get('head_name') is not None: d.head_name = str(data['head_name']).strip()[:200]
            if data.get('description') is not None: d.description = str(data['description']).strip()
            db.session.commit()
            return {'success': True, 'updated': 'department', 'id': d.id, 'name': d.name, 'budget': d.budget, 'spent': d.spent, 'currency_symbol': sym}

        if act == 'delete_department':
            did = data.get('id')
            dname = (data.get('department_name') or data.get('name') or '').strip()
            d = Department.query.filter_by(company_id=cid, id=int(did)).first() if did else Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{dname}%")).first()
            if not d:
                return {'success': False, 'error': f"Department '{dname or did}' not found."}
            removed_name, removed_id = d.name, d.id
            db.session.delete(d)
            db.session.commit()
            return {'success': True, 'deleted': 'department', 'id': removed_id, 'name': removed_name}

        if act == 'update_employee':
            eid = data.get('id')
            ename = (data.get('name') or data.get('first_name') or '').strip()
            emp = Employee.query.filter_by(company_id=cid, id=int(eid)).first() if eid else Employee.query.filter(Employee.company_id == cid, or_(Employee.first_name.ilike(f"%{ename}%"), Employee.last_name.ilike(f"%{ename}%"), Employee.email.ilike(f"%{ename}%"))).first()
            if not emp:
                return {'success': False, 'error': f"Employee '{ename or eid}' not found."}
            if data.get('salary') is not None: emp.salary = float(data['salary'])
            if data.get('job_title'): emp.job_title = str(data['job_title']).strip()[:200]
            if data.get('status'): emp.status = str(data['status']).strip().lower()[:30]
            if data.get('email'): emp.email = str(data['email']).strip()[:120]
            if data.get('department'):
                d = Department.query.filter(Department.company_id == cid, Department.name.ilike(f"%{str(data['department']).strip()}%")).first()
                if d: emp.department_id = d.id
            db.session.commit()
            return {'success': True, 'updated': 'employee', 'id': emp.id, 'name': f"{emp.first_name} {emp.last_name}", 'salary': emp.salary, 'job_title': emp.job_title, 'status': emp.status, 'currency_symbol': sym}

        if act == 'delete_employee':
            eid = data.get('id')
            ename = (data.get('name') or data.get('first_name') or '').strip()
            emp = Employee.query.filter_by(company_id=cid, id=int(eid)).first() if eid else Employee.query.filter(Employee.company_id == cid, or_(Employee.first_name.ilike(f"%{ename}%"), Employee.last_name.ilike(f"%{ename}%"), Employee.email.ilike(f"%{ename}%"))).first()
            if not emp:
                return {'success': False, 'error': f"Employee '{ename or eid}' not found."}
            removed_name, removed_id = f"{emp.first_name} {emp.last_name}", emp.id
            db.session.delete(emp)
            db.session.commit()
            return {'success': True, 'deleted': 'employee', 'id': removed_id, 'name': removed_name}

        if act == 'update_financial_record':
            rid = data.get('id')
            if not rid:
                return {'success': False, 'error': 'Financial record id is required to update.'}
            rec = FinancialRecord.query.filter_by(company_id=cid, id=int(rid)).first()
            if not rec:
                return {'success': False, 'error': f"Financial record #{rid} not found."}
            if data.get('amount') is not None: rec.amount = float(data['amount'])
            if data.get('category'): rec.category = str(data['category']).strip()[:100]
            if data.get('description'): rec.description = str(data['description']).strip()[:500]
            db.session.commit()
            return {'success': True, 'updated': 'financial_record', 'id': rec.id, 'amount': rec.amount, 'category': rec.category, 'currency_symbol': sym}

        if act == 'delete_financial_record':
            rid = data.get('id')
            if not rid:
                return {'success': False, 'error': 'Financial record id is required to delete.'}
            rec = FinancialRecord.query.filter_by(company_id=cid, id=int(rid)).first()
            if not rec:
                return {'success': False, 'error': f"Financial record #{rid} not found."}
            db.session.delete(rec)
            db.session.commit()
            return {'success': True, 'deleted': 'financial_record', 'id': int(rid)}

        if act == 'update_customer':
            cid_rec = data.get('id')
            cname = (data.get('company_name') or data.get('name') or '').strip()
            cust = Customer.query.filter_by(company_id=cid, id=int(cid_rec)).first() if cid_rec else Customer.query.filter(Customer.company_id == cid, Customer.company_name.ilike(f"%{cname}%")).first()
            if not cust:
                return {'success': False, 'error': f"Customer '{cname or cid_rec}' not found."}
            if data.get('segment'): cust.segment = str(data['segment']).strip()[:50]
            if data.get('lifetime_value') is not None: cust.lifetime_value = float(data['lifetime_value'])
            if data.get('email'): cust.email = str(data['email']).strip()[:120]
            db.session.commit()
            return {'success': True, 'updated': 'customer', 'id': cust.id, 'company_name': cust.company_name, 'lifetime_value': cust.lifetime_value}

        if act == 'delete_customer':
            cid_rec = data.get('id')
            cname = (data.get('company_name') or data.get('name') or '').strip()
            cust = Customer.query.filter_by(company_id=cid, id=int(cid_rec)).first() if cid_rec else Customer.query.filter(Customer.company_id == cid, Customer.company_name.ilike(f"%{cname}%")).first()
            if not cust:
                return {'success': False, 'error': f"Customer '{cname or cid_rec}' not found."}
            removed = cust.company_name
            db.session.delete(cust)
            db.session.commit()
            return {'success': True, 'deleted': 'customer', 'company_name': removed}

        if act == 'update_supplier':
            sid = data.get('id')
            sname = (data.get('name') or '').strip()
            sup = Supplier.query.filter_by(company_id=cid, id=int(sid)).first() if sid else Supplier.query.filter(Supplier.company_id == cid, Supplier.name.ilike(f"%{sname}%")).first()
            if not sup:
                return {'success': False, 'error': f"Supplier '{sname or sid}' not found."}
            if data.get('rating') is not None: sup.rating = float(data['rating'])
            if data.get('lead_time_days') is not None: sup.lead_time_days = int(data['lead_time_days'])
            if data.get('category'): sup.category = str(data['category']).strip()[:100]
            db.session.commit()
            return {'success': True, 'updated': 'supplier', 'id': sup.id, 'name': sup.name, 'rating': sup.rating}

        if act == 'delete_supplier':
            sid = data.get('id')
            sname = (data.get('name') or '').strip()
            sup = Supplier.query.filter_by(company_id=cid, id=int(sid)).first() if sid else Supplier.query.filter(Supplier.company_id == cid, Supplier.name.ilike(f"%{sname}%")).first()
            if not sup:
                return {'success': False, 'error': f"Supplier '{sname or sid}' not found."}
            removed = sup.name
            db.session.delete(sup)
            db.session.commit()
            return {'success': True, 'deleted': 'supplier', 'name': removed}

        if act == 'delete_inventory':
            sku = (data.get('sku') or '').strip()
            iid = data.get('id')
            item = Inventory.query.filter_by(company_id=cid, id=int(iid)).first() if iid else Inventory.query.filter(Inventory.company_id == cid, or_(Inventory.sku.ilike(sku), Inventory.name.ilike(f"%{data.get('name') or sku}%"))).first()
            if not item:
                return {'success': False, 'error': f"Inventory item '{sku or iid}' not found."}
            removed = item.sku or item.name
            db.session.delete(item)
            db.session.commit()
            return {'success': True, 'deleted': 'inventory', 'item': removed}

        if act == 'update_risk':
            rid = data.get('id')
            rname = (data.get('name') or '').strip()
            rk = Risk.query.filter_by(company_id=cid, id=int(rid)).first() if rid else Risk.query.filter(Risk.company_id == cid, Risk.name.ilike(f"%{rname}%")).first()
            if not rk:
                return {'success': False, 'error': f"Risk '{rname or rid}' not found."}
            if data.get('status'): rk.status = str(data['status']).strip().lower()[:30]
            if data.get('risk_level'): rk.risk_level = str(data['risk_level']).strip().lower()[:30]
            if data.get('mitigation_plan'): rk.mitigation_plan = str(data['mitigation_plan']).strip()
            db.session.commit()
            return {'success': True, 'updated': 'risk', 'id': rk.id, 'name': rk.name, 'status': rk.status}

        if act == 'delete_risk':
            rid = data.get('id')
            rname = (data.get('name') or '').strip()
            rk = Risk.query.filter_by(company_id=cid, id=int(rid)).first() if rid else Risk.query.filter(Risk.company_id == cid, Risk.name.ilike(f"%{rname}%")).first()
            if not rk:
                return {'success': False, 'error': f"Risk '{rname or rid}' not found."}
            removed = rk.name
            db.session.delete(rk)
            db.session.commit()
            return {'success': True, 'deleted': 'risk', 'name': removed}

        if act == 'update_project':
            pid = data.get('id')
            pname = (data.get('name') or '').strip()
            proj = Project.query.filter_by(company_id=cid, id=int(pid)).first() if pid else Project.query.filter(Project.company_id == cid, Project.name.ilike(f"%{pname}%")).first()
            if not proj:
                return {'success': False, 'error': f"Project '{pname or pid}' not found."}
            if data.get('status'): proj.status = str(data['status']).strip().lower()[:40]
            if data.get('priority'): proj.priority = str(data['priority']).strip().lower()[:30]
            if data.get('budget') is not None: proj.budget = float(data['budget'])
            db.session.commit()
            return {'success': True, 'updated': 'project', 'id': proj.id, 'name': proj.name, 'status': proj.status}

        if act == 'delete_project':
            pid = data.get('id')
            pname = (data.get('name') or '').strip()
            proj = Project.query.filter_by(company_id=cid, id=int(pid)).first() if pid else Project.query.filter(Project.company_id == cid, Project.name.ilike(f"%{pname}%")).first()
            if not proj:
                return {'success': False, 'error': f"Project '{pname or pid}' not found."}
            removed = proj.name
            db.session.delete(proj)
            db.session.commit()
            return {'success': True, 'deleted': 'project', 'name': removed}

        if act == 'delete_custom_twin':
            tid = data.get('id')
            tname = (data.get('twin_name') or data.get('name') or '').strip()
            twin = CustomTwin.query.filter_by(company_id=cid, id=int(tid)).first() if tid else CustomTwin.query.filter(CustomTwin.company_id == cid, CustomTwin.name.ilike(f"%{tname}%")).first()
            if not twin:
                return {'success': False, 'error': f"Custom twin '{tname or tid}' not found."}
            removed = twin.name
            db.session.delete(twin)
            db.session.commit()
            return {'success': True, 'deleted': 'custom_twin', 'name': removed}

        return {'success': False, 'error': f"Unknown action '{act}'"}

    # ─── 3. SIMULATIONS & DECISION SCANS ───
    if tool_name == 'run_analysis_or_simulation':
        act = (args.get('action') or 'what_if_simulation').strip().lower()
        if act == 'run_forecast':
            from services.forecast_service import ForecastService
            ftype = (args.get('forecast_type') or 'revenue').strip().lower()
            if ftype not in ('revenue', 'expense', 'profit', 'cashflow', 'customers'):
                ftype = 'revenue'
            try:
                horizon = max(7, min(365, int(args.get('horizon_days') or 30)))
            except (TypeError, ValueError):
                horizon = 30
            method = (args.get('method') or 'auto').strip().lower()
            fname = (args.get('name') or f"Pulse AI {horizon}-Day {ftype.title()} Forecast").strip()[:180]
            try:
                fc = ForecastService.generate_forecast(
                    company_id=cid,
                    user_id=uid,
                    forecast_type=ftype,
                    method=method,
                    horizon_days=horizon,
                    name=fname,
                    currency_symbol=sym,
                    allow_heuristic=True,
                )
                fc_id = getattr(fc, 'id', None)
                results = ForecastService.get_forecast_results(fc_id) if fc_id else {}
                pts = (results.get('predictions') or results.get('forecast_points') or []) if isinstance(results, dict) else []
                projected_sum = round(sum(float(p.get('predicted', p.get('yhat', p.get('value', 0))) or 0) for p in pts), 2) if pts else getattr(fc, 'projected_total', None)
                return {
                    'success': True,
                    'forecast_id': fc_id,
                    'name': fname,
                    'forecast_type': ftype,
                    'horizon_days': horizon,
                    'method': getattr(fc, 'method', method),
                    'currency_symbol': sym,
                    'projected_total': projected_sum,
                    'points_count': len(pts),
                    'sample_points': pts[:6],
                    'view_url': '/forecasting/',
                    'summary': f"Successfully generated and saved {horizon}-day {ftype} forecast (ID #{fc_id}) in Forecasting Lab."
                }
            except Exception as exc:
                # Graceful analytical projection directly from live FinancialRecord rows if model had sparse points
                from services.analytics_service import AnalyticsService
                summary = AnalyticsService.get_executive_summary(cid) or {}
                base_30d = float(summary.get('revenue_30d' if ftype == 'revenue' else ('expenses_30d' if ftype == 'expense' else 'profit_30d')) or 0.0)
                projected = round(base_30d * (horizon / 30.0) * 1.045, 2)
                return {
                    'success': True,
                    'name': fname,
                    'forecast_type': ftype,
                    'horizon_days': horizon,
                    'method': 'live_run_rate_projection',
                    'currency_symbol': sym,
                    'baseline_30d': round(base_30d, 2),
                    'projected_total': projected,
                    'view_url': '/forecasting/',
                    'note': f"Computed from live 30-day baseline ({sym}{base_30d:,.2f}) across {horizon} days."
                }
        if act == 'autonomous_monitor':
            from services.pulse_automation_service import PulseAutomationService
            return PulseAutomationService.run_live_monitor_sweep(company_id=cid, user_id=uid, create_notifications=True)
        if act == 'decision_scan':
            from services.decision_intelligence_service import DecisionIntelligenceService
            return DecisionIntelligenceService.run_decision_scan(company_id=cid, actor_user_id=uid, publish_events=True)
        from services.analytics_service import AnalyticsService
        summary = AnalyticsService.get_executive_summary(cid)
        rev_b = float(summary.get('revenue_30d') or 0.0)
        prof_b = float(summary.get('profit_30d') or 0.0)
        cost_b = max(0.0, rev_b - prof_b)
        rp = float(args.get('revenue_change_pct') or 0.0)
        ep = float(args.get('expense_change_pct') or 0.0)
        rev_a = round(rev_b * (1.0 + rp / 100.0), 2)
        cost_a = round(cost_b * (1.0 + ep / 100.0), 2)
        prof_a = round(rev_a - cost_a, 2)
        sim = Simulation(company_id=cid, user_id=uid, name=(args.get('name') or f"What-If ({rp:+.0f}% Rev / {ep:+.0f}% Exp)").strip()[:200], sim_type='agent_what_if', status='completed', parameters=json.dumps({'revenue_change_pct': rp, 'expense_change_pct': ep}), results=json.dumps({'revenue_after': rev_a, 'cost_after': cost_a, 'profit_after': prof_a}), revenue_before=rev_b, revenue_after=rev_a, cost_before=cost_b, cost_after=cost_a, profit_before=prof_b, profit_after=prof_a)
        db.session.add(sim)
        db.session.commit()
        return {'success': True, 'simulation_id': sim.id, 'name': sim.name, 'currency_symbol': sym, 'revenue_before': rev_b, 'revenue_after': rev_a, 'profit_before': prof_b, 'profit_after': prof_a, 'profit_delta': round(prof_a - prof_b, 2), 'view_url': f"/simulation/results/{sim.id}"}

    # ─── 4. PDF / EXCEL / CSV GENERATION ───
    if tool_name == 'generate_or_export_file':
        perm_err = _verify_write_permission(uid, cid, 'generate_or_export_file')
        if perm_err:
            return {'success': False, 'error': perm_err}
        fmt = (args.get('format_type') or 'pdf').strip().lower()
        target = (args.get('target') or 'executive').strip().lower()
        dept_filter = (args.get('department') or '').strip()
        title = (args.get('title') or f"Ayevoryn {target.replace('_', ' ').title()} Report").strip()
        req_charts_raw = args.get('charts') or []
        if isinstance(req_charts_raw, str):
            req_charts_raw = [c.strip().lower() for c in req_charts_raw.split(',') if c.strip()]
        else:
            req_charts_raw = [str(c).strip().lower() for c in req_charts_raw if str(c).strip()]
        req_modules_raw = args.get('modules') or []
        if isinstance(req_modules_raw, str):
            req_modules_raw = [m.strip().lower() for m in req_modules_raw.split(',') if m.strip()]
        else:
            req_modules_raw = [str(m).strip().lower() for m in req_modules_raw if str(m).strip()]

        user_prompt_l = str(args.get('_user_prompt') or '').lower()
        intent_blob = f"{title.lower()} {user_prompt_l}"
        if any(k in intent_blob for k in ('line chart', 'line graph', 'trend chart', 'line ', 'forecast', 'revenue trend')):
            if 'line' not in req_charts_raw:
                req_charts_raw.append('line')
        if any(k in intent_blob for k in ('pie chart', 'donut chart', 'pie graph', 'pie ', 'donut')):
            if 'pie' not in req_charts_raw:
                req_charts_raw.append('pie')
        if any(k in intent_blob for k in ('bar chart', 'bar graph', 'utilization', 'budget vs')):
            if 'bar' not in req_charts_raw:
                req_charts_raw.append('bar')
        if not req_charts_raw and (any(k in intent_blob for k in ('chart', 'graph', 'visual')) or target in ('executive', 'company_performance', 'all')):
            req_charts_raw.extend(['line', 'pie', 'bar'])

        from services.agent_export_service import generate_multi_sheet_excel, generate_csv_export, generate_custom_pdf_report
        from sqlalchemy import func
        from database.models.department_budget import DepartmentBudget
        from database.models.project import Project
        comp_name = company.company_name if company else 'Organization'

        dept_exp_rows = (
            db.session.query(
                FinancialRecord.department_id,
                func.coalesce(func.sum(FinancialRecord.amount), 0.0).label('spent'),
                func.count(FinancialRecord.id).label('tx_cnt'),
            )
            .filter(
                FinancialRecord.company_id == cid,
                FinancialRecord.transaction_type.in_(['expense', 'payroll', 'withdrawal', 'transfer_out']),
            )
            .group_by(FinancialRecord.department_id)
            .all()
        )
        live_dept_spend = {r.department_id: float(r.spent or 0.0) for r in dept_exp_rows}
        live_dept_tx = {r.department_id: int(r.tx_cnt or 0) for r in dept_exp_rows}
        active_budgets = {
            b.department_id: float(b.allocated_amount)
            for b in DepartmentBudget.query.filter_by(company_id=cid, status='active').all()
            if b.allocated_amount is not None
        }

        def _sheet(ds):
            if ds in ('departments', 'department', 'utilization', 'department_utilization'):
                depts = Department.query.filter_by(company_id=cid, is_active=True).order_by(Department.name.asc()).all()
                rows = []
                for d in depts:
                    alloc = float(active_budgets.get(d.id, d.budget or 0.0) or 0.0)
                    spent = float(live_dept_spend.get(d.id, 0.0))
                    rem = round(alloc - spent, 2)
                    util = round((spent / alloc) * 100.0, 1) if alloc > 0 else (100.0 if spent > 0 else 0.0)
                    rows.append([
                        d.name, d.code or '', d.head_name or 'Unassigned',
                        round(alloc, 2), round(spent, 2), rem, f"{util:.1f}%",
                        live_dept_tx.get(d.id, 0),
                        Employee.query.filter_by(company_id=cid, department_id=d.id).count(),
                    ])
                return {'headers': ['Department', 'Code', 'Head', f'Allocated ({sym})', f'Live Spent ({sym})', f'Remaining ({sym})', 'Utilization %', 'Tx Count', 'Employees'], 'rows': rows}
            if ds in ('employees', 'workforce', 'hr'):
                dmap = {d.id: d.name for d in Department.query.filter_by(company_id=cid).all()}
                q = Employee.query.filter_by(company_id=cid)
                if dept_filter:
                    mids = [did for did, dn in dmap.items() if dept_filter.lower() in (dn or '').lower()]
                    q = q.filter(Employee.department_id.in_(mids)) if mids else q.filter(Employee.id == -1)
                all_emps = q.order_by(Employee.id.asc()).limit(1000).all()
                _rng = re.search(r'\b(\d{1,4})\s*(?:-|to|through)\s*(\d{1,4})\b', intent_blob)
                if _rng:
                    _s_idx = max(0, int(_rng.group(1)) - 1)
                    _e_idx = max(_s_idx + 1, int(_rng.group(2)))
                    all_emps = all_emps[_s_idx:_e_idx]
                return {'headers': ['ID', 'Name', 'Department', 'Job Title', 'Email', f'Salary ({sym})', 'Status'], 'rows': [[e.employee_id or e.id, f"{e.first_name or ''} {e.last_name or ''}".strip(), dmap.get(e.department_id, 'Unassigned'), e.job_title or '', e.email or '', float(e.salary or 0), e.status or 'active'] for e in all_emps]}
            if ds in ('financials', 'financial', 'transactions', 'ledger'):
                recs = FinancialRecord.query.filter_by(company_id=cid).order_by(FinancialRecord.transaction_date.desc()).limit(1000).all()
                return {'headers': ['Date', 'Type', 'Category', f'Amount ({sym})', 'Reference', 'Description'], 'rows': [[r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '', r.transaction_type, r.category or '', float(r.amount or 0), r.reference_number or '', r.description or ''] for r in recs]}
            if ds in ('customers', 'crm'):
                return {'headers': ['Company', 'Contact', 'Email', 'Segment', f'LTV ({sym})'], 'rows': [[c.company_name or '', f"{c.first_name or ''} {c.last_name or ''}".strip(), c.email or '', c.segment or '', float(c.lifetime_value or 0)] for c in Customer.query.filter_by(company_id=cid).order_by(Customer.lifetime_value.desc()).limit(1000).all()]}
            if ds in ('inventory', 'stock', 'stocks', 'warehouse', 'skus'):
                items = Inventory.query.filter_by(company_id=cid).order_by(Inventory.name.asc()).limit(1000).all()
                return {
                    'headers': ['SKU', 'Item Name', 'Category', 'On Hand', 'Reorder Pt', f'Unit Cost ({sym})', f'Price ({sym})', f'Stock Value ({sym})'],
                    'rows': [
                        [
                            i.sku or '', i.name or '', i.category or 'General',
                            int(i.quantity_on_hand or 0), int(i.reorder_point or 0),
                            round(float(i.unit_cost or 0), 2), round(float(i.selling_price or 0), 2),
                            round(int(i.quantity_on_hand or 0) * float(i.unit_cost or 0), 2)
                        ]
                        for i in items
                    ]
                }
            if ds in ('bank_accounts', 'treasury', 'accounts', 'payments'):
                accs = FinancialAccount.query.filter_by(company_id=cid).order_by(FinancialAccount.current_balance.desc()).all()
                return {'headers': ['Account Name', 'Type', f'Balance ({sym})', 'Status'], 'rows': [[a.account_name, a.account_type or '', round(float(a.current_balance or 0), 2), 'Active' if a.is_active else 'Inactive'] for a in accs]}
            if ds in ('suppliers', 'supply_chain'):
                return {'headers': ['Supplier', 'Category', 'Contact', 'Lead Time (d)', 'Rating'], 'rows': [[s.name, s.category or '', s.contact_person or '', int(s.lead_time_days or 0), float(s.rating or 0)] for s in Supplier.query.filter_by(company_id=cid).limit(500).all()]}
            if ds in ('risks', 'risk'):
                return {'headers': ['Risk', 'Category', 'Level', 'Score', 'Status', 'Mitigation'], 'rows': [[r.name, r.category, r.risk_level, float(r.risk_score or 0), r.status, r.mitigation_plan or ''] for r in Risk.query.filter_by(company_id=cid).limit(500).all()]}
            if ds in ('projects', 'project'):
                projs = Project.query.filter_by(company_id=cid).order_by(Project.id.desc()).limit(500).all()
                return {'headers': ['Project', 'Status', f'Budget ({sym})', f'Spent ({sym})', 'Progress %'], 'rows': [[p.name, p.status or '', float(p.budget or 0), float(p.spent or 0), float(p.progress or 0)] for p in projs]}
            return _sheet('departments')

        def _build_live_charts():
            built = []
            # Priority 1: Exact LLM-authored custom_charts (either SQL-backed or explicit live values!)
            raw_custom = args.get('custom_charts') or []
            if isinstance(raw_custom, list) and raw_custom:
                for cs in raw_custom[:6]:
                    if not isinstance(cs, dict):
                        continue
                    if cs.get('sql_query'):
                        resolved = _chart_spec_from_sql(cid, cs, sym)
                        if resolved:
                            built.append(resolved)
                    elif cs.get('labels') and (cs.get('values') or cs.get('series')):
                        _nums = []
                        if cs.get('values'):
                            _nums.extend([abs(float(v or 0.0)) for v in cs['values']])
                        if cs.get('series'):
                            for _sr in cs['series']:
                                _nums.extend([abs(float(v or 0.0)) for v in (_sr.get('values') or [])])
                        if any(n > 0 for n in _nums):
                            built.append(cs)
                if built:
                    return built
            # Priority 2: If report itself uses a custom sql_query, auto-chart its exact SQL columns!
            if args.get('sql_query') and (req_charts_raw or fmt == 'png'):
                ctype_pref = 'line' if any('line' in c for c in req_charts_raw) else ('donut' if any(k in c for c in req_charts_raw for k in ('pie', 'donut')) else 'bar')
                resolved = _chart_spec_from_sql(cid, {'chart_type': ctype_pref, 'title': title, 'sql_query': args.get('sql_query')}, sym)
                if resolved:
                    return [resolved]
            if not req_charts_raw and fmt != 'png':
                return []
            cblob = f"{' '.join(req_charts_raw)} {intent_blob} {target}"
            want_heatmap = any(k in cblob for k in ('heatmap', 'heat map', 'risk matrix'))
            want_line = any(k in cblob for k in ('line', 'trend', 'forecast')) or (fmt == 'png' and not want_heatmap and 'pie' not in cblob and 'bar' not in cblob)
            want_pie = any(k in cblob for k in ('pie', 'donut', 'share', 'breakdown', 'distribution'))
            want_bar = any(k in cblob for k in ('bar', 'compare', 'budget vs'))

            # Detect specific data domain requested by user prompt / target
            is_emp = target in ('employees', 'workforce', 'hr') or any(k in intent_blob for k in ('employee', 'salary', 'salaries', 'payroll', 'staff', 'headcount'))
            is_risk = target in ('risks', 'risk') or want_heatmap or ('risk' in intent_blob and 'executive' not in intent_blob)
            is_inv = target in ('inventory', 'stock', 'stocks', 'warehouse', 'skus') or any(k in intent_blob for k in ('inventory', 'sku', 'stock', 'warehouse'))
            is_cust = target in ('customers', 'crm') or any(k in intent_blob for k in ('customer', 'client', 'ltv', 'crm'))
            is_sup = target in ('suppliers', 'supply_chain') or any(k in intent_blob for k in ('supplier', 'vendor', 'lead time'))
            is_proj = target in ('projects', 'project') or ('project' in intent_blob and 'project-management' not in intent_blob)
            is_acct = target in ('bank_accounts', 'treasury', 'accounts', 'payments') or any(k in intent_blob for k in ('bank account', 'treasury balance', 'cash account'))
            is_dept_util = target in ('departments', 'department', 'utilization', 'department_utilization') or any(k in intent_blob for k in ('department', 'utilization'))

            depts_all = Department.query.filter_by(company_id=cid, is_active=True).order_by(Department.name.asc()).all()

            # 1. LIVE 5x5 RISK HEATMAP (Probability x Impact)
            if want_heatmap:
                all_rks = [r for r in Risk.query.filter_by(company_id=cid).all() if (r.status or 'active').lower() not in ('resolved', 'closed')]
                matrix = [[0 for _ in range(5)] for _ in range(5)]
                cell_texts = [['' for _ in range(5)] for _ in range(5)]
                for rk in all_rks:
                    prob = float(rk.probability or 0.5)
                    imp = float(rk.impact or 0.5)
                    if prob > 1.0: prob = prob / 100.0
                    if imp > 1.0: imp = imp / 100.0
                    ri = min(4, max(0, int(prob * 4.99)))
                    ci = min(4, max(0, int(imp * 4.99)))
                    matrix[ri][ci] += 1
                    if not cell_texts[ri][ci]:
                        cell_texts[ri][ci] = (rk.name or 'Risk')[:16]
                built.append({
                    'chart_type': 'heatmap',
                    'title': f'{comp_name} — Live 5x5 Enterprise Risk Heatmap ({len(all_rks)} Active Risks)',
                    'matrix': matrix,
                    'cell_texts': cell_texts,
                    'x_labels': ['Very Low', 'Low', 'Medium', 'High', 'Critical'],
                    'y_labels': ['Very Low', 'Low', 'Medium', 'High', 'Critical'],
                    'x_title': 'Impact Severity',
                    'y_title': 'Probability / Likelihood',
                })

            # 2. LIVE LINE CHARTS (Matched strictly to the exact domain requested!)
            if want_line:
                if is_emp:
                    _rng_c = re.search(r'\b(\d{1,4})\s*(?:-|to|through)\s*(\d{1,4})\b', intent_blob)
                    if _rng_c:
                        _cs = max(0, int(_rng_c.group(1)) - 1)
                        _ce = max(_cs + 1, int(_rng_c.group(2)))
                        emps = Employee.query.filter_by(company_id=cid).order_by(Employee.id.asc()).all()[_cs:_ce]
                    else:
                        emps = Employee.query.filter_by(company_id=cid).order_by(Employee.salary.desc()).limit(25).all()
                    emps_with_sal = [e for e in emps if float(e.salary or 0) > 0]
                    if emps_with_sal:
                        emps_sorted = list(reversed(emps_with_sal))
                        built.append({
                            'chart_type': 'line',
                            'title': f'Live Employee Salary Trend ({sym}) — {len(emps_sorted)} Employees',
                            'labels': [f"{(e.first_name or '')} {(e.last_name or '')}".strip()[:14] or f"Emp #{e.id}" for e in emps_sorted],
                            'y_label': f'Salary ({sym})',
                            'series': [{'name': f'Employee Salary ({sym})', 'values': [round(float(e.salary or 0), 2) for e in emps_sorted], 'color': '#0284C7'}],
                        })
                elif is_dept_util and 'revenue' not in intent_blob and 'executive' not in intent_blob:
                    if depts_all:
                        u_labels, u_vals = [], []
                        for d in depts_all:
                            al = float(active_budgets.get(d.id, d.budget or 0.0) or 0.0)
                            sp = float(live_dept_spend.get(d.id, 0.0))
                            pct = round((sp / al) * 100.0, 1) if al > 0 else (100.0 if sp > 0 else 0.0)
                            u_labels.append(d.name)
                            u_vals.append(pct)
                        built.append({
                            'chart_type': 'line',
                            'title': 'Live Departmental Budget Utilization (%)',
                            'labels': u_labels,
                            'y_label': 'Utilization (%)',
                            'series': [{'name': 'Utilization %', 'values': u_vals, 'color': '#0284C7'}],
                        })
                elif is_cust:
                    custs = Customer.query.filter_by(company_id=cid).order_by(Customer.lifetime_value.desc()).limit(15).all()
                    if custs:
                        built.append({
                            'chart_type': 'line',
                            'title': f'Live Customer Lifetime Value Trend ({sym})',
                            'labels': [(c.company_name or c.first_name or f'C#{c.id}')[:14] for c in custs],
                            'y_label': f'LTV ({sym})',
                            'series': [{'name': f'LTV ({sym})', 'values': [round(float(c.lifetime_value or 0), 2) for c in custs], 'color': '#10B981'}],
                        })
                elif is_inv:
                    items = Inventory.query.filter_by(company_id=cid).order_by(Inventory.quantity_on_hand.desc()).limit(15).all()
                    if items:
                        built.append({
                            'chart_type': 'line',
                            'title': 'Live Inventory On-Hand vs Reorder Point',
                            'labels': [(i.sku or i.name or f'SKU#{i.id}')[:12] for i in items],
                            'y_label': 'Units',
                            'series': [
                                {'name': 'On Hand', 'values': [int(i.quantity_on_hand or 0) for i in items], 'color': '#0284C7'},
                                {'name': 'Reorder Point', 'values': [int(i.reorder_point or 0) for i in items], 'color': '#EF4444'},
                            ],
                        })
                else:
                    # Live Revenue vs Operating Expense Trend from FinancialRecord
                    recs = FinancialRecord.query.filter_by(company_id=cid).order_by(FinancialRecord.transaction_date.asc()).all()
                    buckets = {}
                    for r in recs:
                        if not r.transaction_date:
                            continue
                        ym = r.transaction_date.strftime('%Y-%m')
                        b = buckets.setdefault(ym, {'rev': 0.0, 'exp': 0.0})
                        tl = (r.transaction_type or '').lower()
                        if tl in ('revenue', 'income', 'deposit'):
                            b['rev'] += float(r.amount or 0.0)
                        elif tl in ('expense', 'payroll', 'withdrawal', 'transfer_out'):
                            b['exp'] += float(r.amount or 0.0)
                    if buckets:
                        keys = sorted(buckets.keys())[-12:]
                        built.append({
                            'chart_type': 'line',
                            'title': 'Live Revenue vs Operating Expense Trend',
                            'labels': keys,
                            'y_label': f'Amount ({sym})',
                            'series': [
                                {'name': f'Revenue ({sym})', 'values': [round(buckets[k]['rev'], 2) for k in keys], 'color': '#0284C7'},
                                {'name': f'Expenses ({sym})', 'values': [round(buckets[k]['exp'], 2) for k in keys], 'color': '#10B981'},
                            ],
                        })

            # 3. LIVE PIE / DONUT CHARTS (Matched strictly to the exact domain requested!)
            if want_pie:
                if is_emp:
                    dmap = {d.id: d.name for d in depts_all}
                    pay_by_dept = {}
                    for e in Employee.query.filter_by(company_id=cid).all():
                        dn = dmap.get(e.department_id, 'Unassigned')
                        pay_by_dept[dn] = pay_by_dept.get(dn, 0.0) + float(e.salary or 0.0)
                    if any(v > 0 for v in pay_by_dept.values()):
                        built.append({'chart_type': 'donut', 'title': f'Live Payroll Distribution by Department ({sym})', 'labels': list(pay_by_dept.keys()), 'values': [round(v, 2) for v in pay_by_dept.values()]})
                elif is_inv:
                    inv_cats = {}
                    for it in Inventory.query.filter_by(company_id=cid).all():
                        cat = it.category or 'General'
                        inv_cats[cat] = inv_cats.get(cat, 0.0) + (int(it.quantity_on_hand or 0) * float(it.unit_cost or 0.0))
                    if inv_cats:
                        built.append({'chart_type': 'donut', 'title': f'Live Inventory Valuation by Category ({sym})', 'labels': list(inv_cats.keys()), 'values': [round(v, 2) for v in inv_cats.values()]})
                elif is_risk:
                    rc = {}
                    for rk in Risk.query.filter_by(company_id=cid).all():
                        if (rk.status or 'active').lower() in ('resolved', 'closed'): continue
                        lv = (rk.risk_level or 'medium').title()
                        rc[lv] = rc.get(lv, 0) + 1
                    if rc:
                        built.append({'chart_type': 'donut', 'title': 'Live Active Risk Severity Distribution', 'labels': list(rc.keys()), 'values': list(rc.values())})
                elif is_cust:
                    segs = {}
                    for c in Customer.query.filter_by(company_id=cid).all():
                        sg = c.segment or 'General'
                        segs[sg] = segs.get(sg, 0.0) + max(1.0, float(c.lifetime_value or 0.0))
                    if segs:
                        built.append({'chart_type': 'donut', 'title': 'Live Customer Value by Segment', 'labels': list(segs.keys()), 'values': [round(v, 2) for v in segs.values()]})
                elif is_acct:
                    accs = FinancialAccount.query.filter_by(company_id=cid, is_active=True).all()
                    if accs:
                        built.append({'chart_type': 'donut', 'title': f'Live Treasury Account Balances ({sym})', 'labels': [a.account_name for a in accs], 'values': [max(0.0, round(float(a.current_balance or 0), 2)) for a in accs]})
                elif depts_all:
                    d_labels, d_vals = [], []
                    for d in depts_all:
                        sp = float(live_dept_spend.get(d.id, 0.0))
                        al = float(active_budgets.get(d.id, d.budget or 0.0) or 0.0)
                        val = sp if sp > 0 else al
                        if val > 0:
                            d_labels.append(d.name)
                            d_vals.append(round(val, 2))
                    if d_labels:
                        chart_lbl = 'Live Departmental Spend Share' if any(live_dept_spend.get(d.id, 0.0) > 0 for d in depts_all) else 'Departmental Budget Share'
                        built.append({'chart_type': 'donut', 'title': f'{chart_lbl} ({sym})', 'labels': d_labels, 'values': d_vals})

            # 4. LIVE BAR CHARTS
            if want_bar:
                if is_sup:
                    sups = Supplier.query.filter_by(company_id=cid).order_by(Supplier.rating.desc()).limit(12).all()
                    if sups:
                        built.append({'chart_type': 'bar', 'title': 'Live Supplier Performance Ratings', 'labels': [s.name[:16] for s in sups], 'y_label': 'Rating', 'values': [round(float(s.rating or 0), 2) for s in sups]})
                elif is_proj:
                    projs = Project.query.filter_by(company_id=cid).limit(12).all()
                    if projs:
                        built.append({'chart_type': 'bar', 'title': f'Live Project Budget vs Spent ({sym})', 'labels': [p.name[:16] for p in projs], 'y_label': f'Amount ({sym})', 'series': [{'name': 'Budget', 'values': [float(p.budget or 0) for p in projs], 'color': '#0284C7'}, {'name': 'Spent', 'values': [float(p.spent or 0) for p in projs], 'color': '#10B981'}]})
                elif is_risk:
                    top_r = [r for r in Risk.query.filter_by(company_id=cid).order_by(Risk.risk_score.desc()).limit(10).all() if (r.status or 'active').lower() not in ('resolved', 'closed')]
                    if top_r:
                        built.append({'chart_type': 'bar', 'title': 'Top Active Enterprise Risks by Score', 'labels': [r.name[:16] for r in top_r], 'y_label': 'Risk Score', 'values': [round(float(r.risk_score or 0), 1) for r in top_r]})
                elif depts_all:
                    built.append({
                        'chart_type': 'bar',
                        'title': f'Departmental Budget vs Live Expenditure ({sym})',
                        'labels': [d.name for d in depts_all],
                        'y_label': f'Amount ({sym})',
                        'series': [
                            {'name': 'Allocated Budget', 'values': [round(float(active_budgets.get(d.id, d.budget or 0.0) or 0.0), 2) for d in depts_all], 'color': '#0284C7'},
                            {'name': 'Live Spent', 'values': [round(float(live_dept_spend.get(d.id, 0.0)), 2) for d in depts_all], 'color': '#EF4444'},
                        ],
                    })
            return built

        # Inline PNG Chart Image export (e.g., Risk Heatmap image, Salary Line Chart image)
        if fmt == 'png':
            from services.agent_export_service import generate_live_chart_image
            live_charts = _build_live_charts()
            if not live_charts:
                return {'success': False, 'error': 'No live records available to render the requested chart image.'}
            return generate_live_chart_image(comp_name, cid, live_charts[0], title=live_charts[0].get('title') or title)

        tot_rev = float(db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(FinancialRecord.company_id == cid, FinancialRecord.transaction_type.in_(['revenue', 'income', 'deposit'])).scalar() or 0.0)
        tot_exp = float(db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(FinancialRecord.company_id == cid, FinancialRecord.transaction_type.in_(['expense', 'payroll', 'withdrawal', 'transfer_out'])).scalar() or 0.0)
        tot_alloc = sum(float(active_budgets.get(d.id, d.budget or 0.0) or 0.0) for d in Department.query.filter_by(company_id=cid, is_active=True).all())
        tot_dept_spent = sum(live_dept_spend.values())
        avg_util = round((tot_dept_spent / tot_alloc) * 100.0, 1) if tot_alloc > 0 else 0.0
        kpi_strip = [
            {'label': 'Live Ledger Revenue', 'value': f"{sym}{tot_rev:,.2f}"},
            {'label': 'Live Ledger Expenses', 'value': f"{sym}{tot_exp:,.2f}"},
            {'label': 'Net Cash Delta', 'value': f"{sym}{(tot_rev - tot_exp):,.2f}"},
            {'label': 'Dept Utilization', 'value': f"{avg_util:.1f}%"},
        ]

        if args.get('sql_query'):
            sq_res = _execute_tenant_safe_sql(cid, args.get('sql_query'), max_rows=500)
            if sq_res.get('success') and sq_res.get('columns'):
                custom_sheet = {'headers': sq_res['columns'], 'rows': sq_res['rows']}
                if fmt == 'csv':
                    return generate_csv_export(cid, custom_sheet['headers'], custom_sheet['rows'], title=title)
                sheets = {title[:28] or 'Live Query': custom_sheet}
                live_charts = _build_live_charts()
                if fmt == 'pdf':
                    return generate_custom_pdf_report(comp_name, cid, sym, sheets, title=title, charts=live_charts, kpi_summary=kpi_strip)
                return generate_multi_sheet_excel(comp_name, cid, sym, sheets, title=title, charts=live_charts)
        if fmt == 'csv':
            s = _sheet(target)
            return generate_csv_export(cid, s['headers'], s['rows'], title=title)
        if req_modules_raw:
            sheets = {m.replace('_', ' ').title(): _sheet(m) for m in req_modules_raw}
        elif target in ('company_performance', 'executive', 'all'):
            sheets = {
                'Departmental Utilization': _sheet('departments'),
                'Financial Ledger': _sheet('financials'),
                'Treasury Accounts': _sheet('treasury'),
                'Inventory': _sheet('inventory'),
                'Employees': _sheet('employees'),
                'Risks': _sheet('risks'),
            }
        else:
            sheets = {target.replace('_', ' ').title(): _sheet(target)}

        live_charts = _build_live_charts()
        active_risks_list = [
            rk for rk in Risk.query.filter_by(company_id=cid).order_by(Risk.risk_score.desc()).all()
            if (rk.status or 'active').lower() not in ('resolved', 'closed', 'mitigated')
        ]
        high_crit_risks = [rk for rk in active_risks_list if (rk.risk_level or '').lower() in ('critical', 'high') or float(rk.risk_score or 0) >= 60]
        total_cash = sum(float(a.current_balance or 0.0) for a in FinancialAccount.query.filter_by(company_id=cid, is_active=True).all())
        low_stock_cnt = Inventory.query.filter(Inventory.company_id == cid, Inventory.quantity_on_hand <= Inventory.reorder_point).count()
        exec_summary_text = str(args.get('summary') or '').strip() or (
            f"Live ledger snapshot for {comp_name}: recorded revenue totals {sym}{tot_rev:,.2f} against "
            f"{sym}{tot_exp:,.2f} in expenses (net cash delta {sym}{(tot_rev - tot_exp):,.2f}), with "
            f"{sym}{total_cash:,.2f} in active treasury accounts and {avg_util:.1f}% aggregate departmental budget utilization "
            f"({sym}{tot_dept_spent:,.2f} spent of {sym}{tot_alloc:,.2f} allocated). "
            f"There are currently {len(high_crit_risks)} active high/critical risks and {low_stock_cnt} inventory reorder alerts."
        )
        recs_list = []
        if high_crit_risks:
            top_names = ', '.join(f"{r.name} (Score {float(r.risk_score or 0):.1f})" for r in high_crit_risks[:3])
            recs_list.append(f"Prioritize mitigation of active high/critical risks: {top_names}.")
        if avg_util > 85.0:
            recs_list.append(f"Departmental utilization is elevated at {avg_util:.1f}%; review over-budget cost centers in Treasury & Payments.")
        elif tot_alloc > 0 and avg_util < 25.0:
            recs_list.append(f"Aggregate departmental utilization is {avg_util:.1f}% ({sym}{tot_dept_spent:,.2f} / {sym}{tot_alloc:,.2f}); verify department expense tagging or reallocate idle budget.")
        if low_stock_cnt > 0:
            recs_list.append(f"Replenish {low_stock_cnt} inventory SKU(s) currently at or below reorder point.")
        if not recs_list:
            recs_list.append("Financial liquidity, departmental utilization, and risk posture are within healthy thresholds; maintain scheduled Pulse AI monitoring.")

        if fmt == 'pdf':
            return generate_custom_pdf_report(
                comp_name, cid, sym, sheets, title=title,
                charts=live_charts, kpi_summary=kpi_strip,
                executive_summary=exec_summary_text, recommendations=recs_list
            )
        return generate_multi_sheet_excel(comp_name, cid, sym, sheets, title=title, charts=live_charts)

    # ─── 5. UNIVERSAL AUTOMATIONS ───
    if tool_name == 'manage_automations':
        from services.pulse_automation_service import PulseAutomationService
        act = (args.get('action') or 'list').strip().lower()
        if act == 'list':
            items = PulseAutomationService.list_automations(cid)
            return {'count': len(items), 'automations': items}
        perm_err = _verify_write_permission(uid, cid, f'automation:{act}')
        if perm_err:
            return {'success': False, 'error': perm_err}
        if act == 'create':
            return PulseAutomationService.create_automation(
                company_id=cid, user_id=uid,
                name=args.get('name') or 'Scheduled Pulse AI Task',
                task_type=args.get('task_type') or ('generate_report' if args.get('report_type') else 'custom_agent_prompt'),
                interval_days=args.get('interval_days'),
                interval_hours=args.get('interval_hours'), interval_minutes=args.get('interval_minutes'), interval_seconds=args.get('interval_seconds'),
                report_type=args.get('report_type') or 'executive',
                format_type=args.get('format_type') or 'pdf',
                prompt=args.get('prompt') or '',
                run_immediately=bool(args.get('run_immediately', False))
            )
        aid = int(args.get('automation_id') or 0)
        if act == 'run_now':
            return PulseAutomationService.run_automation_now(aid, cid)
        if act == 'toggle':
            return PulseAutomationService.toggle_automation(aid, cid)
        if act == 'delete':
            return PulseAutomationService.delete_automation(aid, cid)
        return {'success': False, 'error': f"Unsupported automation action '{act}'"}

    return {'error': f"Unknown tool '{tool_name}'"}
