"""
Ayevoryn Global Superadmin Pulse AI & Automation Models (USMANIA TECHS PVT LTD)
Isolated from tenant tables (no company_id FK required) and auto-created via checkfirst=True.
"""
from datetime import datetime
import json
from database.db import db


class SuperadminConversation(db.Model):
    __tablename__ = 'superadmin_conversations'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False, index=True)
    title = db.Column(db.String(220), nullable=False, default='Global Control Plane Session')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'title': self.title,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.created_at else None,
            'updated_at': self.updated_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.updated_at else None,
        }


class SuperadminMessage(db.Model):
    __tablename__ = 'superadmin_messages'

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('superadmin_conversations.id', ondelete='CASCADE'), nullable=False, index=True)
    role = db.Column(db.String(20), nullable=False)  # user | assistant
    content = db.Column(db.Text, nullable=False, default='')
    tool_calls_json = db.Column(db.Text, default='[]')
    downloads_json = db.Column(db.Text, default='[]')
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        try:
            tools = json.loads(self.tool_calls_json or '[]')
        except Exception:
            tools = []
        try:
            downloads = json.loads(self.downloads_json or '[]')
        except Exception:
            downloads = []
        return {
            'id': self.id,
            'conversation_id': self.conversation_id,
            'role': self.role,
            'content': self.content or '',
            'tool_calls': tools if isinstance(tools, list) else [],
            'downloads': downloads if isinstance(downloads, list) else [],
            'download_url': downloads[0]['url'] if downloads and isinstance(downloads[0], dict) else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.created_at else None,
        }


class SuperadminAutomation(db.Model):
    __tablename__ = 'superadmin_automations'

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, nullable=False, index=True)
    name = db.Column(db.String(220), nullable=False)
    task_type = db.Column(db.String(60), nullable=False, default='custom_agent_prompt')
    prompt = db.Column(db.Text, default='')
    interval_seconds = db.Column(db.Integer, nullable=False, default=3600)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    run_count = db.Column(db.Integer, default=0, nullable=False)
    last_run_at = db.Column(db.DateTime, nullable=True)
    next_run_at = db.Column(db.DateTime, nullable=True)
    last_status = db.Column(db.String(40), default='scheduled')
    last_result_summary = db.Column(db.Text, default='')
    last_download_url = db.Column(db.String(500), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    def to_dict(self):
        secs = max(5, int(self.interval_seconds or 3600))
        return {
            'id': self.id,
            'user_id': self.user_id,
            'name': self.name,
            'task_type': self.task_type,
            'prompt': self.prompt or '',
            'interval_seconds': secs,
            'interval_days': secs / 86400.0,
            'is_active': bool(self.is_active),
            'run_count': self.run_count or 0,
            'last_run_at': self.last_run_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.last_run_at else None,
            'next_run_at': self.next_run_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.next_run_at else None,
            'last_status': self.last_status or 'scheduled',
            'last_result_summary': self.last_result_summary or '',
            'last_download_url': self.last_download_url,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.created_at else None,
        }


class SuperadminAutomationRun(db.Model):
    __tablename__ = 'superadmin_automation_runs'

    id = db.Column(db.Integer, primary_key=True)
    automation_id = db.Column(db.Integer, db.ForeignKey('superadmin_automations.id', ondelete='CASCADE'), nullable=False, index=True)
    run_number = db.Column(db.Integer, nullable=False, default=1)
    status = db.Column(db.String(40), nullable=False, default='success')
    duration_ms = db.Column(db.Integer, nullable=True)
    output_markdown = db.Column(db.Text, default='')
    download_url = db.Column(db.String(500), nullable=True)
    executed_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'automation_id': self.automation_id,
            'run_number': self.run_number,
            'status': self.status or 'success',
            'duration_ms': self.duration_ms,
            'output_markdown': self.output_markdown or '',
            'download_url': self.download_url,
            'executed_at': self.executed_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.executed_at else None,
        }


def ensure_superadmin_pulse_tables():
    """Idempotently create all Superadmin Pulse AI & Automation tables on live DB."""
    try:
        for mdl in (SuperadminConversation, SuperadminMessage, SuperadminAutomation, SuperadminAutomationRun):
            mdl.__table__.create(db.engine, checkfirst=True)
    except Exception:
        pass
