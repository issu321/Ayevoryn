from datetime import datetime, timedelta
from database.db import db


class PulseAutomation(db.Model):
    """Persistent scheduled AI agent automations (recurring reports, risk scans, executive briefings)."""
    __tablename__ = 'pulse_automations'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    task_type = db.Column(db.String(50), nullable=False, default='generate_report')  # generate_report | risk_scan | ai_briefing
    report_type = db.Column(db.String(50), default='executive')  # executive | financial | board | investor | risk | growth | forecast | operational | department
    format_type = db.Column(db.String(20), default='pdf')  # pdf | excel
    prompt = db.Column(db.Text, default='')
    interval_days = db.Column(db.Float, nullable=False, default=3.0)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    run_count = db.Column(db.Integer, default=0, nullable=False)
    last_run_at = db.Column(db.DateTime, nullable=True)
    next_run_at = db.Column(db.DateTime, nullable=True)
    last_status = db.Column(db.String(40), default='scheduled')  # scheduled | success | error
    last_result_summary = db.Column(db.Text, default='')
    last_report_id = db.Column(db.Integer, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'name': self.name,
            'task_type': self.task_type,
            'report_type': self.report_type,
            'format_type': self.format_type,
            'prompt': self.prompt or '',
            'interval_days': self.interval_days,
            'interval_seconds': max(5, int(round(float(self.interval_days or 3.0) * 86400.0))),
            'is_active': bool(self.is_active),
            'run_count': self.run_count or 0,
            'last_run_at': self.last_run_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.last_run_at else None,
            'next_run_at': self.next_run_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.next_run_at else None,
            'last_status': self.last_status or 'scheduled',
            'last_result_summary': self.last_result_summary or '',
            'last_report_id': self.last_report_id,
            'last_download_url': f'/reports/download/{self.last_report_id}' if self.last_report_id else None,
            'created_at': self.created_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.created_at else None,
        }


class PulseAutomationRun(db.Model):
    """Immutable per-run execution history storing exact output for Run #1, #2, #3, ... of each automation."""
    __tablename__ = 'pulse_automation_runs'

    id = db.Column(db.Integer, primary_key=True)
    automation_id = db.Column(db.Integer, db.ForeignKey('pulse_automations.id', ondelete='CASCADE'), nullable=False, index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    run_number = db.Column(db.Integer, nullable=False, default=1)
    status = db.Column(db.String(40), nullable=False, default='success')
    duration_ms = db.Column(db.Integer, nullable=True)
    output_markdown = db.Column(db.Text, default='')
    download_url = db.Column(db.String(500), nullable=True)
    executed_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    def to_dict(self):
        return {
            'id': self.id,
            'automation_id': self.automation_id,
            'company_id': self.company_id,
            'run_number': self.run_number,
            'status': self.status or 'success',
            'duration_ms': self.duration_ms,
            'output_markdown': self.output_markdown or '',
            'download_url': self.download_url,
            'executed_at': self.executed_at.strftime('%Y-%m-%d %H:%M:%S UTC') if self.executed_at else None,
        }
