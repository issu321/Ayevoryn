# -*- mode: python ; coding: utf-8 -*-
"""
PyInstaller Production Specification for Ayevoryn.exe (USMANIA TECHS PVT LTD).
Uses a clean one-folder (onedir) bundle wrapped by Inno Setup (Ayevoryn_Setup.exe) for:
  - Fast startup without temp _MEI unpacking overhead
  - Lower Windows Defender false-positive rate
  - Clean separation of read-only binaries from persistent %LOCALAPPDATA%\\UsmaniaTechs\\Ayevoryn\\ data
Explicitly excludes development databases (*.db), .env secrets, tests, scratch, and archive folders.
"""
import os
from pathlib import Path
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

SPEC_DIR = Path(SPECPATH).resolve()
PROJECT_ROOT = SPEC_DIR.parent

block_cipher = None

# Read-only runtime resources bundled into the packaged application
datas = [
    (str(PROJECT_ROOT / 'templates'), 'templates'),
    (str(PROJECT_ROOT / 'static'), 'static'),
    (str(PROJECT_ROOT / 'packaging' / 'assets'), os.path.join('packaging', 'assets')),
]
if (PROJECT_ROOT / 'migrations').exists():
    datas.append((str(PROJECT_ROOT / 'migrations'), 'migrations'))

# Collect package data files needed at runtime
for pkg in ('webview', 'reportlab', 'openpyxl', 'certifi'):
    try:
        datas += collect_data_files(pkg)
    except Exception:
        pass

hiddenimports = [
    # Local WSGI & Native Desktop Window
    'waitress',
    'webview',
    'webview.platforms.edgechromium',
    'webview.platforms.winforms',
    'clr_loader',
    'pythonnet',
    # Flask & Extensions
    'flask',
    'flask_sqlalchemy',
    'flask_login',
    'flask_wtf',
    'flask_wtf.csrf',
    'flask_migrate',
    'flask_mail',
    'flask_caching',
    'wtforms',
    'jinja2',
    'werkzeug',
    'itsdangerous',
    'markupsafe',
    # Database & Migrations
    'sqlalchemy',
    'sqlalchemy.dialects.sqlite',
    'sqlalchemy.sql.default_comparator',
    'alembic',
    # Security, Auth & Scheduling
    'bcrypt',
    'jwt',
    'bleach',
    'apscheduler',
    'apscheduler.schedulers.background',
    'apscheduler.triggers.interval',
    'apscheduler.triggers.cron',
    # Exports, PDF & Analytics
    'openpyxl',
    'xlsxwriter',
    'reportlab',
    'reportlab.graphics',
    'reportlab.platypus',
    'PIL',
    'requests',
    'dotenv',
    'qrcode',
    'dateutil',
]

# Automatically include all Ayevoryn application submodules
for local_pkg in ('desktop', 'routes', 'services', 'database', 'security', 'config'):
    try:
        hiddenimports += collect_submodules(local_pkg)
    except Exception:
        pass

excludes = [
    'pytest',
    'unittest',
    'tkinter',
    'matplotlib.tests',
    'numpy.testing',
    'IPython',
    'jupyter',
    'notebook',
    'gunicorn',
]

a = Analysis(
    [str(PROJECT_ROOT / 'desktop' / 'entry.py')],
    pathex=[str(PROJECT_ROOT)],
    binaries=[],
    datas=datas,
    hiddenimports=sorted(set(hiddenimports)),
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=excludes,
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name='Ayevoryn',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=str(PROJECT_ROOT / 'packaging' / 'assets' / 'Ayevoryn.ico'),
    version=str(PROJECT_ROOT / 'packaging' / 'version_info.txt'),
)

coll = COLLECT(
    exe,
    a.binaries,
    a.zipfiles,
    a.datas,
    strip=False,
    upx=False,
    upx_exclude=[],
    name='Ayevoryn',
)
