; Ayevoryn Windows Desktop Installer Script (Inno Setup 6)
; Product: Ayevoryn | Publisher: USMANIA TECHS PVT LTD
; Produces: dist_release\Ayevoryn_Setup.exe
;
; User Data Guarantee:
;   Application binaries install to {autopf}\UsmaniaTechs\Ayevoryn
;   Persistent SQLite DB, uploads, reports, logs, and settings live in %LOCALAPPDATA%\UsmaniaTechs\Ayevoryn
;   Upgrades and uninstallation NEVER delete user business data in %LOCALAPPDATA%\UsmaniaTechs\Ayevoryn.

#define MyAppName "Ayevoryn"
#define MyAppVersion "2.0.0"
#define MyAppPublisher "USMANIA TECHS PVT LTD"
#define MyAppExeName "Ayevoryn.exe"
#define MyAppId "{{E7B4A912-8C3D-4F21-9A5E-6D1F0B2C8E47}"

[Setup]
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\UsmaniaTechs\{#MyAppName}
DefaultGroupName={#MyAppName}
AllowNoIcons=yes
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=..\dist_release
OutputBaseFilename=Ayevoryn_Setup
SetupIconFile=assets\Ayevoryn.ico
UninstallDisplayIcon={app}\{#MyAppExeName}
UninstallDisplayName={#MyAppName} ({#MyAppPublisher})
WizardStyle=modern
WizardImageFile=assets\wizard_sidebar.bmp
WizardSmallImageFile=assets\wizard_small.bmp
Compression=lzma2/max
SolidCompression=yes
CloseApplications=yes
RestartApplications=no
VersionInfoVersion=2.0.0.0
VersionInfoCompany={#MyAppPublisher}
VersionInfoProductName={#MyAppName}
VersionInfoDescription={#MyAppName} Windows Desktop Setup

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"; Flags: unchecked

[Files]
Source: "..\dist\Ayevoryn\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\packaging\assets\Ayevoryn.ico"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; IconFilename: "{app}\packaging\assets\Ayevoryn.ico"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "{cm:LaunchProgram,{#StringChange(MyAppName, '&', '&&')}}"; Flags: nowait postinstall skipifsilent

[UninstallDelete]
; Only clean up compiled bytecode caches inside the installation folder.
; Persistent user data in %LOCALAPPDATA%\UsmaniaTechs\Ayevoryn is intentionally preserved.
Type: filesandordirs; Name: "{app}\__pycache__"
