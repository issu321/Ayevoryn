@echo off
setlocal
REM Ayevoryn Windows Build Verification Script (USMANIA TECHS PVT LTD)

set "ROOT_DIR=%~dp0.."
set "DIST_DIR=%ROOT_DIR%\dist\Ayevoryn"

if not exist "%DIST_DIR%\Ayevoryn.exe" (
    echo [FAIL] Missing "%DIST_DIR%\Ayevoryn.exe"
    exit /b 1
)
echo [OK] Found Ayevoryn.exe

if not exist "%DIST_DIR%\_internal\templates\base.html" (
    if not exist "%DIST_DIR%\templates\base.html" (
        echo [FAIL] Missing bundled templates\base.html
        exit /b 1
    )
)
echo [OK] Verified bundled templates

if not exist "%DIST_DIR%\_internal\static\favicon.ico" (
    if not exist "%DIST_DIR%\static\favicon.ico" (
        echo [FAIL] Missing bundled static\favicon.ico
        exit /b 1
    )
)
echo [OK] Verified bundled static assets

REM Security check: ensure no dev database or .env secret file was bundled
for /r "%DIST_DIR%" %%f in (*.db .env) do (
    echo [FAIL] Forbidden development file bundled in release: %%f
    exit /b 1
)
echo [OK] Verified zero development .db or .env files in packaged output

exit /b 0
