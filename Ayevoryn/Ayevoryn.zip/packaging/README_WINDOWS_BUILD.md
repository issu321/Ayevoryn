# Ayevoryn Windows Desktop Build & Release Guide

**Product:** Ayevoryn (`Ayevoryn.exe`)  
**Installer:** `Ayevoryn_Setup.exe`  
**Publisher:** USMANIA TECHS PVT LTD  
**Target OS:** Windows 10 & Windows 11 (64-bit)

## Architecture Overview

Ayevoryn Desktop packages the complete existing Flask enterprise application into a standalone Windows desktop app:

- **Native Window:** `pywebview` (Microsoft Edge WebView2 on Windows 10/11) with custom `Ayevoryn.ico`, branded loading splash screen, and graceful shutdown hooks (`desktop/window.py`).
- **Managed Local Server:** `waitress` production WSGI server bound strictly to loopback `127.0.0.1` on an available port, verified via `/health`, and cleanly stopped when the window closes (`desktop/server.py`).
- **Single-Instance Guard:** Windows named mutex (`Local\UsmaniaTechs_Ayevoryn_Desktop_Mutex_v2`) prevents conflicting duplicate instances (`desktop/single_instance.py`).
- **Persistent User Data:** Stored strictly outside Program Files under `%LOCALAPPDATA%\UsmaniaTechs\Ayevoryn\` (`data/ayevoryn.db`, `uploads/`, `exports/`, `reports/`, `logs/`, `backups/`, `config/`) so records survive restarts, upgrades, and uninstalls (`desktop/paths.py`).
- **Packaging:** PyInstaller one-folder build (`packaging/Ayevoryn.spec`) wrapped in a branded Inno Setup 6 installer (`packaging/installer.iss`). No development `.db` files or `.env` secrets are ever bundled.

## Prerequisites on Windows 10/11 (64-bit)

1. **Python 3.11 (64-bit)** installed and available on `PATH`.
2. **Inno Setup 6** (https://jrsoftware.org/isinfo.php) installed to build `Ayevoryn_Setup.exe`.
3. **Microsoft Edge WebView2 Runtime** (pre-installed on Windows 11 and updated Windows 10 systems).

## One-Command Build

From the project root directory in Command Prompt or PowerShell:

```bat
build_windows.bat
```

Outputs created:
- `dist\Ayevoryn\Ayevoryn.exe` — Standalone packaged Windows executable bundle.
- `dist_release\Ayevoryn_Setup.exe` — Branded Windows installer wizard.
- `dist_release\Ayevoryn.ico` & `dist_release\Ayevoryn_master_1024.png` — Application icon assets.

## Upgrade & Uninstall Behavior

- **Upgrades:** Running a newer `Ayevoryn_Setup.exe` replaces binaries in `{autopf}\UsmaniaTechs\Ayevoryn` and preserves `%LOCALAPPDATA%\UsmaniaTechs\Ayevoryn\`. On launch, Ayevoryn creates an automatic SQLite backup in `backups\` before running schema checks.
- **Uninstall:** Standard Windows uninstall removes binaries and Start Menu / Desktop shortcuts while preserving `%LOCALAPPDATA%\UsmaniaTechs\Ayevoryn\`. To completely remove all local business data after uninstalling, manually delete `%LOCALAPPDATA%\UsmaniaTechs\Ayevoryn\`.

## Recommended Production Release Checklist (Windows)

1. Sign `Ayevoryn.exe` and `Ayevoryn_Setup.exe` with an Authenticode code-signing certificate (`signtool.exe`) to eliminate Windows SmartScreen warnings.
2. Run `Ayevoryn_Setup.exe` on a clean Windows 10/11 standard (non-admin) user account.
3. Verify launch from Start Menu & Desktop shortcut, login/registration, persistent database across close/reopen, PDF/Excel/CSV downloads, AI assistant (when API key configured), upgrade over existing install, and uninstall data preservation.
