# AEVORYN / INSIGHT-PULSE
# ENTERPRISE SECURITY, MULTI-TENANCY & COMPLIANCE SPECIFICATION

## 1. Multi-Tenant Data Isolation (P0 Zero-Trust)
AEVORYN enforces multi-tenant boundary isolation at every tier of the application lifecycle:

- **Entity Scoping:** Every domain table (`companies`, `users`, `departments`, `employees`, `customers`, `suppliers`, `inventory`, `financial_records`, `custom_twins`, `scenarios`, `background_jobs`, etc.) includes a non-nullable `company_id` foreign key.
- **Session Context Pinning:** The application enforces session pinning. During request authentication, `session['company_id']` is strictly synchronized to `current_user.company_id`. Any manual attempt to manipulate the session tenant ID is rejected by `enforce_tenant_context()` middleware.
- **IDOR Prevention:** All route handlers, API endpoints, and service lookups enforce dual-key filtering:
  ```python
  record = Entity.query.filter_by(id=entity_id, company_id=company_id).first_or_404()
  ```
  Cross-tenant read or mutation attempts return strict HTTP 404/403 responses.

---

## 2. Role-Based Access Control (RBAC)
The platform defines an enterprise role hierarchy with granular, principle-of-least-privilege permissions:

| Role | Hierarchy Weight | Description | Permissions Matrix |
| :--- | :--- | :--- | :--- |
| **Owner** | 100 | Corporate account executive | All permissions: `company:manage`, `user:manage`, `data:write`, `data:delete`, `simulation:run`, `report:export`, `audit:view`, `dashboard:view` |
| **Admin** | 80 | System administrator | Full operational management: `company:manage`, `user:manage`, `data:write`, `data:delete`, `simulation:run`, `report:export`, `audit:view`, `dashboard:view` |
| **Manager** | 60 | Department / operational lead | Operational write: `data:write`, `data:delete`, `simulation:run`, `report:export`, `dashboard:view` |
| **Analyst** | 40 | Financial / data analyst | Analytical write: `data:write`, `simulation:run`, `report:export`, `dashboard:view` |
| **Auditor** | 20 | Compliance / external auditor | Read-only audit inspection: `audit:view`, `report:export`, `dashboard:view` |
| **Viewer** | 10 | Executive observer | Read-only dashboard view: `report:export`, `dashboard:view` |

Route handlers enforce authorization via declarative decorators:
- `@roles_required('Owner', 'Admin')`
- `@permission_required(Permission.DATA_WRITE)`

---

## 3. Cryptographic Security & Authentication Hardening
- **Password Protection:** User passwords are encrypted using Scrypt / PBKDF2 with SHA-256 via Werkzeug Security.
- **Salted Challenge Answers:** Security challenge answers are normalized (trimmed, lowercase) and salted using an application-level secret (`insight_sa_`) with SHA-256 digests. Legacy plaintext challenge answers are transparently upgraded upon successful verification.
- **Account Recovery Sliding Window:** `/auth/recover-account` enforces sliding-window rate limiting (maximum 5 attempts per 10 minutes) preventing dictionary attacks.
- **Password Rotation Verification:** Changing credentials via profile settings requires verification of the current password prior to rotation.

---

## 4. Cross-Site Request Forgery (CSRF) & Web Defenses
- **Global CSRF Protection:** `flask_wtf.csrf.CSRFProtect` is enabled across all state-mutating HTTP methods (`POST`, `PUT`, `PATCH`, `DELETE`).
- **AJAX & SPA Interceptors:** A global client-side interceptor reads `<meta name="csrf-token">` and dynamically attaches `X-CSRFToken` headers to all asynchronous fetch and XMLHttpRequest operations.
- **Path Traversal Sandboxing:** File upload and download routes strictly utilize `werkzeug.security.safe_join()` within bounded storage roots, rejecting directory traversal (`..`), absolute paths, and blacklisted system extensions (`.env`, `.db`, `.py`, `.key`).
- **Subresource Integrity (SRI):** External CDN dependencies (FontAwesome, Chart.js, Tailwind) incorporate cryptographic SRI SHA-384 hashes.

---

## 5. SOC 2 Type II Audit Readiness
- **Append-Only Domain Event Ledger:** All business mutations produce immutable records in `business_events` with actor attribution, timestamps, and state diff payloads.
- **Auditable Security Logs:** Failed authentication attempts, password recoveries, role adjustments, and tenant configurations are recorded in `audit_logs` and `activity_logs`.\n