# AEVORYN / INSIGHT-PULSE
# PRODUCTION OPERATIONAL RUNBOOK & SRE GUIDE

## 1. Environment Configuration Dictionary
Production deployments require the following environment variables configured in `/app/.env` or container orchestration secrets:

| Variable | Type | Default / Example | Purpose |
| :--- | :--- | :--- | :--- |
| `SECRET_KEY` | string | `(cryptographic 64-char string)` | Flask session and CSRF signing key. Must be unique per deployment. |
| `DATABASE_URL` | string | `postgresql://aev:secret@db:5432/aevoryn_prod` | Primary database URI. Supports SQLite (`sqlite:///...`) and PostgreSQL (`postgresql://...`). |
| `FLASK_ENV` | string | `production` | Enables production security mode and disables Werkzeug debug console. |
| `UPLOAD_FOLDER` | string | `/app/uploads` | Bounded directory for user document and CSV asset storage. |
| `MAX_CONTENT_LENGTH`| int | `16777216` (16MB) | Maximum HTTP multipart request body limit. |
| `LOG_LEVEL` | string | `INFO` | Logging verbosity (`DEBUG`, `INFO`, `WARNING`, `ERROR`). |
| `GUNICORN_WORKERS` | int | `4` | Number of WSGI worker processes (Formula: `2 * CPU_CORES + 1`). |
| `GUNICORN_THREADS` | int | `2` | Number of worker threads per process for I/O concurrency. |

---

## 2. Containerized Deployment (Docker & Compose)

### 2.1 Starting Services via Docker Compose
```bash
# Build multi-stage production images and launch stack in daemon mode
docker-compose up -d --build

# Verify container running state
docker-compose ps
```

### 2.2 Executing Migrations in Container
```bash
docker-compose exec web flask db upgrade
```

---

## 3. High-Availability Health Probes

### 3.1 Kubernetes Liveness Probe (`/healthz`)
- **Endpoint:** `GET /healthz`
- **Expected Status:** HTTP 200
- **Behavior:** Lightweight probe confirming WSGI event loop responsiveness.
- **K8s Spec:**
  ```yaml
  livenessProbe:
    httpGet:
      path: /healthz
      port: 5000
    initialDelaySeconds: 10
    periodSeconds: 10
    timeoutSeconds: 3
    failureThreshold: 3
  ```

### 3.2 Kubernetes Readiness Probe (`/readiness`)
- **Endpoint:** `GET /readiness`
- **Expected Status:** HTTP 200
- **Behavior:** Deep probe executing database connectivity test (`SELECT 1`), writable file storage verification, and worker pool availability check.
- **K8s Spec:**
  ```yaml
  readinessProbe:
    httpGet:
      path: /readiness
      port: 5000
    initialDelaySeconds: 15
    periodSeconds: 15
    timeoutSeconds: 5
    failureThreshold: 2
  ```

### 3.3 Runtime Telemetry & Observability (`/health/metrics`)
- **Endpoint:** `GET /health/metrics`
- **Payload:** System uptime seconds, registered job handlers, database engine backend, active worker thread counts.

---

## 4. Backup & Disaster Recovery Procedures

### 4.1 SQLite Live Database Backup
```bash
# Safely snapshot live SQLite database using VACUUM INTO
sqlite3 instance/business_simulator.db "VACUUM INTO 'instance/backups/manual_snapshot_$(date +%Y%m%d_%H%M%S).db';"
```

### 4.2 PostgreSQL Hot Backup
```bash
pg_dump -U aevoryn -h db -d aevoryn_prod -F c -b -v -f /backups/aevoryn_$(date +%Y%m%d_%H%M%S).dump
```

### 4.3 Database Restoration
```bash
pg_restore -U aevoryn -h db -d aevoryn_prod -v --clean /backups/target_snapshot.dump
```\n