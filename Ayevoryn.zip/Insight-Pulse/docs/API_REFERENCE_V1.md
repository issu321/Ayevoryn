# AEVORYN / INSIGHT-PULSE
# REST API V1 SPECIFICATION & INTEGRATION GUIDE

## 1. API Architecture & Conventions
The AEVORYN REST API (`/api/v1/`) provides tenant-isolated programmatic integration for enterprise ERP, CRM, and financial systems.

### 1.1 Base URL
```
https://api.aevoryn.enterprise.internal/api/v1
```

### 1.2 Authentication
All requests must include one of the following authentication headers:
- **API Key:** `X-API-Key: ak_live_xxxxxxxxxxxxxxxxxxxxxxxx`
- **Bearer JWT:** `Authorization: Bearer eyJhbGciOi...`

### 1.3 Standard Response Envelope
All API responses return a uniform JSON envelope:
```json
{
  "success": true,
  "data": {},
  "meta": {
    "timestamp": "2026-09-19T02:50:00Z",
    "request_id": "req_84f9a1b2c3d4",
    "company_id": 1
  },
  "error": null
}
```

---

## 2. Core Endpoints Catalog

### 2.1 System Health
- **`GET /api/v1/health`**
  - Returns API service availability and database connectivity.
  - Response: `{"status": "ok", "version": "1.0.0"}`

### 2.2 Canonical Business State
- **`GET /api/v1/state/canonical`**
  - Retrieves authoritative canonical metrics with full data provenance.
  - Query Params: None.
  - Response Data:
    - `revenue_30d`: `{ "value": 85000.0, "provenance": "OBSERVED" }`
    - `expense_30d`: `{ "value": 35000.0, "provenance": "OBSERVED" }`
    - `cash_balance`: `{ "value": 150000.0, "provenance": "OBSERVED" }`
    - `cash_runway`: `{ "value": 1.5, "unit": "months" }`

### 2.3 Custom Digital Twins
- **`GET /api/v1/twins`**
  - List all active custom digital twins for the tenant.
- **`GET /api/v1/twins/<id>`**
  - Retrieve twin schema definition, fields, and stats config.
- **`POST /api/v1/twins/<id>/records`**
  - Ingest dynamic record into a custom twin.
  - Request Body: `{"name": "Alpha-1", "data": {"status": "operational"}}`

### 2.4 Digital Twin Dependency Graph
- **`GET /api/v1/graph`**
  - Assemble directed dependency graph with nodes, edges, and topological metadata.
  - Query Params: `include_types=DIRECT,DERIVED,CONFIGURED,ESTIMATED`

### 2.5 Domain Events Ledger
- **`POST /api/v1/events`**
  - Ingest an external domain mutation into the event bus.
  - Request Body:
    ```json
    {
      "event_type": "external.invoice.settled",
      "aggregate_type": "financial_record",
      "aggregate_id": "inv_9021",
      "payload": {"amount": 42000.0}
    }
    ```

### 2.6 Background Job Management
- **`POST /api/v1/jobs`**
  - Submit asynchronous processing job (`simulation_monte_carlo`, `batch_import`, `data_quality_scan`).
  - Request Body:
    ```json
    {
      "job_type": "batch_import",
      "payload": {"domain": "customer", "records": [{"name": "Acme Corp"}]}
    }
    ```
- **`GET /api/v1/jobs/<id>`**
  - Poll status, progress (0-100%), and execution results of a background job.

### 2.7 Webhooks Engine
- **`POST /api/v1/webhooks`**
  - Register webhook subscription for specific event topics.
  - Webhooks dispatch signed POST requests with `X-Aevoryn-Signature` (HMAC SHA-256).\n