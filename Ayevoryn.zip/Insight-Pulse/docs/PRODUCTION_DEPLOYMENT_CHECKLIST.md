# AEVORYN / INSIGHT-PULSE
# PRODUCTION SECURITY & DEPLOYMENT CHECKLIST

This checklist represents the mandatory quality and security gate that must be validated prior to exposing the AEVORYN platform to public production traffic.

---

## 1. Secrets & Credentials Management
- [ ] **Secret Key Rotation:** Generate a cryptographically random 64-character string for `SECRET_KEY` (e.g. `openssl rand -hex 32`). Never use default fallback keys.
- [ ] **Database Credentials:** Ensure PostgreSQL passwords exceed 24 characters with mixed entropy. Store in AWS Secrets Manager, GCP Secret Manager, or HashiCorp Vault.
- [ ] **API Key Secret Seeds:** Verify that outbound webhook signing secrets and API keys are stored only as hashes.
- [ ] **No Secrets in Images:** Verify `.dockerignore` prevents accidental packaging of `.env` or certificates.

## 2. Infrastructure & Network Security
- [ ] **TLS/HTTPS Termination:** Enforce TLS 1.3 across all public endpoints via Cloudflare, AWS ALB, Nginx, or Caddy.
- [ ] **HSTS (HTTP Strict Transport Security):** Ensure `Strict-Transport-Security: max-age=63072000; includeSubDomains; preload` is sent by reverse proxy.
- [ ] **Firewall / Security Groups:** Database port (5432) must NOT be publicly reachable. Only accept connections from application container subnet.
- [ ] **Container User Privileges:** Ensure container runtime executes as non-root user (`aevoryn`, UID 10001).

## 3. Database & Disaster Recovery
- [ ] **Database Migrations:** Run `flask db upgrade` in pre-deployment job to ensure schema matches latest revision.
- [ ] **Automated Backups:** Enable automated point-in-time recovery (PITR) with minimum 14-day retention in managed database.
- [ ] **Disaster Recovery Drills:** Verify database restoration playbook from backup snapshot.
- [ ] **Connection Pooling:** Configure PgBouncer if deploying more than 5 application replica pods.

## 4. Observability & Monitoring
- [ ] **Liveness Probe:** Point container orchestrator to `GET /healthz` (initial delay: 10s, period: 30s).
- [ ] **Readiness Probe:** Point container orchestrator to `GET /readiness` (initial delay: 5s, period: 10s).
- [ ] **Centralized Logging:** Configure log forwarder to consume structured JSON lines from container stdout.
- [ ] **Alerting Rules:**
  - Alert on HTTP 5xx rate > 1% over 5 minutes.
  - Alert on `/readiness` returning HTTP 503.
  - Alert on average response latency > 500ms.
  - Alert on worker pool failure events (`job.failed`).

## 5. Pre-Flight Smoke Test
- [ ] Run container smoke test:
  ```bash
  docker compose up -d
  curl -i http://localhost:5000/healthz
  curl -i http://localhost:5000/readiness
  docker compose down
  ```
