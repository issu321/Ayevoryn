# AEVORYN / INSIGHT-PULSE
# ENTERPRISE SYSTEM ARCHITECTURE SPECIFICATION

## 1. Architectural Overview
AEVORYN (Insight-Pulse) is an enterprise-grade Digital Twin and Decision Intelligence platform designed to model, simulate, and optimize complex operational and financial systems in real time. The platform provides bidirectional operational state tracking across seven core organizational dimensions, supports dynamic user-defined custom twins, orchestrates causal blast-radius propagation across dependency graphs, and executes stochastic Monte Carlo simulations without mutating live operational ledgers.

```mermaid
graph TD
    Client[Enterprise Web Client / REST API Client] --> Gateway[WSGI / Gunicorn Gateway]
    Gateway --> AppFactory[Flask Application Factory: app.py]
    AppFactory --> SecurityMiddleware[Tenant Context & RBAC Middleware]
    SecurityMiddleware --> TelemetryMiddleware[Structured JSON Telemetry & X-Request-ID]
    
    TelemetryMiddleware --> Blueprints[30 Modular Domain Blueprints]
    
    subgraph Core Services
        StateService[BusinessStateService: Canonical State & Provenance]
        EventBus[EventBus: In-Process Domain Event Dispatcher]
        GraphService[TwinDependencyService: Multi-Layer Dependency Engine]
        ImpactEngine[ImpactEngine: Causal Blast Radius & Risk Triggers]
        TemporalService[TemporalService: Point-in-Time Historical Reconstruction]
        ScenarioService[ScenarioBranchingService: Sandbox Isolation & Merge Governance]
        SimService[SimulationService: Stochastic Monte Carlo Engine]
        JobService[JobService: Multi-Tenant Worker Pool]
    end
    
    Blueprints --> StateService
    Blueprints --> EventBus
    Blueprints --> GraphService
    Blueprints --> ScenarioService
    Blueprints --> JobService
    
    EventBus --> ImpactEngine
    EventBus --> BusinessEvent[(business_events: Immutable Ledger)]
    EventBus --> ActivityLog[(activity_logs: Synchronized Audit Trail)]
    
    StateService --> ORM[SQLAlchemy ORM Layer]
    JobService --> WorkerPool[ThreadPoolExecutor: Asynchronous Workers]
    
    ORM --> Database[(SQLite / PostgreSQL Engine)]
```

---

## 2. Seven-Pillar Digital Twin Ontology
The enterprise platform models corporate reality across seven fundamental relational pillars, supplemented by extensible custom twin schemas:

1. **Financial Ledger:** Income and expense transactions (`financial_records`), treasury accounts (`financial_accounts`), and historical trailing cash flows.
2. **Organization / Department:** Departmental hierarchies (`departments`), budget allocations, and functional cost centers.
3. **Human Resources:** Workforce records (`employees`), department assignments, compensation structures, and active employment statuses.
4. **Supply Chain / Procurement:** Strategic vendors (`suppliers`), tier categories, performance ratings, and cumulative spend metrics.
5. **Inventory & Logistics:** Stock items (`inventory`), SKUs, real-time stock levels, reorder thresholds, and warehouse valuation.
6. **Customer Operations:** Client accounts (`customers`), customer acquisition costs (CAC), lifetime values (LTV), satisfaction metrics, and churn tracking.
7. **Custom Digital Twins:** Dynamic entity modeling (`custom_twins`, `custom_twin_records`, `twin_links`) enabling bespoke domain extensions (e.g., Satellite Constellations, Fleet Assets, Data Centers).

---

## 3. Event-Driven Architecture & Causal Lineage
Every state mutation within the platform triggers a structured `DomainEvent` dispatched through `EventBus`:
- **Immutability:** Events are persisted append-only to `business_events` with UUID correlation IDs, causation IDs, and JSON state diffs.
- **Audit Synchronization:** The `EventBus` automatically synchronizes human-readable operational narratives into `activity_logs`.
- **Impact Propagation:** The `ImpactEngine` intercepts domain events, walks downstream dependency edges via `TwinDependencyService.get_blast_radius()`, applies attenuation factors, flags operational/financial risks, and records explainable `ImpactTrace` records.
- **Recursion Guard:** Correlation tracing and event prefix filters prevent cascading infinite event loops.

---

## 4. Multi-Tenant Sandbox Scenario Branching
AEVORYN implements a "Git for Business" branching architecture:
- **Baseline Freezing:** `TemporalService.create_snapshot()` freezes current operational metrics, entity counts, and graph topology into immutable `twin_snapshots`.
- **Branch Sandboxes:** `ScenarioBranchingService.branch_scenario()` forks an isolated sandbox (`scenarios`, `scenario_steps`) referencing the baseline snapshot.
- **Forward Simulation:** Hypothetical deltas (e.g., +30% revenue, -10% expenses, +5 headcount) are projected forward without altering a single live database record.
- **Merge Governance:** Scenarios undergo multi-dimensional variance analysis (ROI, payback period, risk scoring) and require executive sign-off before merging approved parameters into operational plans.\n