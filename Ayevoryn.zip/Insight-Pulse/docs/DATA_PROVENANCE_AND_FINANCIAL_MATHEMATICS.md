# AEVORYN / INSIGHT-PULSE
# DATA PROVENANCE, FINANCIAL MATHEMATICS & SIMULATION SPECIFICATION

## 1. Canonical Business State & Provenance Architecture
AEVORYN eliminates conflicting metrics across executive dashboards through `BusinessStateService`, establishing an authoritative, single source of truth:

Every computed metric is encapsulated in a `MetricResult` object containing:
- `name`: Unique metric identifier (e.g., `cash_runway`, `revenue_30d`).
- `value`: Evaluated numeric value.
- `unit`: Unit of measurement (`USD`, `months`, `ratio`, `percentage`).
- `provenance`: Rigorous classification of data lineage:
  - `OBSERVED`: Derived directly from transactional records (e.g. verified bank/expense ledger rows).
  - `DERIVED`: Computed deterministically from observed metrics via arithmetic formulas.
  - `DECLARED`: Explicitly configured targets or parameters provided by operators.
  - `ESTIMATED`: Empirically extrapolated or statistical estimates.
  - `SYNTHETIC`: Generated via stochastic Monte Carlo simulation or scenario deltas.
- `confidence`: Statistical certainty index (0.0 to 1.0).
- `metadata`: Comprehensive calculation context and audit trail.

---

## 2. Core Financial Mathematics & Calculation Formulas

### 2.1 Cash Runway Formula (Permanent 30x Math Bug Fix)
Prior to Stage 6 remediation, legacy code calculated cash runway by dividing cash reserves by daily burn (`expense_30d / 30.0`) while assigning the result to monthly runway, exaggerating runway by ~30x.

The canonical formula implemented in `BusinessStateService.get_runway()`:

$$\text{Monthly Net Burn} = \max(0, \text{Expense}_{30d} - \text{Revenue}_{30d})$$

$$\text{Runway (Months)} = \begin{cases} 
\infty \text{ (Sustainable)}, & \text{if } \text{Monthly Net Burn} \le 0 \\
\frac{\text{Liquid Cash Reserves}}{\text{Monthly Net Burn}}, & \text{if } \text{Monthly Net Burn} > 0 
\end{cases}$$

### 2.2 Profit & Margin Computations
$$\text{Operating Profit} = \text{Revenue}_{30d} - \text{Expense}_{30d}$$

$$\text{Operating Margin (\%)} = \left( \frac{\text{Operating Profit}}{\text{Revenue}_{30d}} \right) \times 100$$

### 2.3 Unit Economics & Workforce Metrics
$$\text{Customer Acquisition Cost (CAC)} = \frac{\sum \text{Acquisition Cost}}{\text{Active Customers Count}}$$

$$\text{Customer Lifetime Value (LTV)} = \frac{\sum \text{Lifetime Value}}{\text{Active Customers Count}}$$

$$\text{LTV : CAC Ratio} = \frac{\text{Average LTV}}{\text{Average CAC}}$$

$$\text{Annualized Revenue per Employee (ARR/FTE)} = \frac{\text{Revenue}_{30d} \times 12}{\text{Active Headcount}}$$

### 2.4 EBIT / Operating Income (Double-Deduction Elimination)
In `services/enterprise_service.py`, COGS (Cost of Goods Sold) and Operating Expenses (OpEx) are strictly segregated to avoid double-deductions:

$$\text{Gross Profit} = \text{Gross Revenue} - \text{COGS}$$

$$\text{EBIT} = \text{Gross Profit} - \text{OpEx}$$

---

## 3. Stochastic Simulation Engine (Monte Carlo)
`SimulationService.run_monte_carlo()` executes stochastic forward simulations:
- **Sampling Distributions:** Normal distributions parameterized by empirical volatility $\sigma$ and drift $\mu$.
- **Correlated Shocks:** Revenue variability is propagated to proportional variable cost vectors.
- **Percentile Scoring:** Computes true non-parametric percentiles:
  - **P10 (Conservative / Downside):** 10th percentile outcome.
  - **P50 (Median / Expected):** 50th percentile outcome.
  - **P90 (Optimistic / Upside):** 90th percentile outcome.
- **Deterministic Replay:** Supports optional seed parameters for reproducible executive audits.

---

## 4. Forecasting Honesty & Data Readiness Tiers
The forecasting engine (`services/forecast_service.py`) rejects deceptive synthetic accuracy claims in favor of data-grounded readiness tiers:
- **Tier 1 (< 30 historical data points):** Naive Drift / Moving Average only.
- **Tier 2 (30 - 90 historical data points):** Holt-Winters Exponential Smoothing with trend detection.
- **Tier 3 (> 90 historical data points):** Multi-seasonal autoregressive decomposition.
- **Out-of-Sample Backtesting:** Backtests models against the most recent 20% holdout window to compute Mean Absolute Percentage Error (MAPE).\n