"""001_initial_schema

Revision ID: 001_initial_schema
Revises: 
Create Date: 2026-09-19 00:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '001_initial_schema'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    """Create all baseline tables, columns, indexes, and constraints from SQLAlchemy models."""
    bind = op.get_bind()
    from database.db import db
    import database.models
    db.metadata.create_all(bind=bind)


def downgrade():
    """Drop all tables."""
    bind = op.get_bind()
    from database.db import db
    import database.models
    db.metadata.drop_all(bind=bind)
