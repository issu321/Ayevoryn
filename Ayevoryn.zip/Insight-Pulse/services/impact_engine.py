"""
AEVORYN / INSIGHT-PULSE
IMPACT PROPAGATION ENGINE (STAGE 12)
Orchestrates causal blast-radius propagation, multi-hop attenuation, explainable causal traces,
and automated operational/financial risk triggers resulting from digital twin mutations.
Guards against infinite cascading recursion using correlation IDs and visited cycle sets.
"""

import logging
from typing import Dict, Any, List, Optional, Set
from datetime import datetime
from sqlalchemy import func

from database.db import db
from database.models.company import Company
from database.models.department import Department
from database.models.inventory import Inventory
from database.models.customer import Customer
from database.models.financial import FinancialRecord
from database.models.risk import Risk
from database.models.twin_dependency import DependencyType
from database.models.impact_trace import ImpactTrace, ImpactSeverity
from services.events import DomainEvent, EventBus, EventTypes
from services.twin_dependency_service import TwinDependencyService
from services.business_state_service import BusinessStateService

logger = logging.getLogger(__name__)


class ImpactEngine:
    """Enterprise Causal Impact Propagation and Explainable Trace Engine."""

    MAX_PROPAGATION_DEPTH = 5

    @classmethod
    def propagate_event(cls, event: DomainEvent, dry_run: bool = False) -> Optional[Any]:
        """
        Evaluate an incoming domain event, trace its downstream blast radius,
        evaluate business rules (budget breaches, liquidity drops, stockouts),
        trigger operational risks, and persist explainable causal traces.
        """
        # Recursion Guard: Do not propagate impact-internal events to prevent infinite cascade
        if event.event_type.startswith("twin.impact."):
            return None

        if not event.company_id:
            return None

        company_id = int(event.company_id)
        root_type = str(event.aggregate_type or 'unknown')
        root_id = str(event.aggregate_id or '')
        root_node_id = f"{root_type}:{root_id}" if root_id else root_type

        # Track causal hops and severity
        causal_steps: List[Dict[str, Any]] = []
        current_severity = ImpactSeverity.LOW

        def bump_severity(new_sev: str):
            nonlocal current_severity
            order = {ImpactSeverity.LOW: 1, ImpactSeverity.MEDIUM: 2, ImpactSeverity.HIGH: 3, ImpactSeverity.CRITICAL: 4}
            if order.get(new_sev, 1) > order.get(current_severity, 1):
                current_severity = new_sev

        # 1. Record Root Ingestion Step
        causal_steps.append({
            'step_index': 1,
            'source_id': 'mutation.trigger',
            'target_id': root_node_id,
            'dependency_type': 'TRIGGER',
            'attenuated_strength': 1.0,
            'description': f"Primary mutation event '{event.event_type}' on {root_type} #{root_id}",
            'metadata': event.payload or {}
        })

        # 2. Domain Rule Evaluation: Department Budget Utilization
        dept_id_target = None
        if root_type == 'department' and root_id.isdigit():
            dept_id_target = int(root_id)
        elif event.payload and event.payload.get('department_id'):
            try:
                dept_id_target = int(event.payload.get('department_id'))
            except (ValueError, TypeError):
                dept_id_target = None

        if dept_id_target:
            dept = Department.query.filter_by(id=dept_id_target, company_id=company_id).first()
            if dept and dept.budget and float(dept.budget) > 0:
                dept_budget = float(dept.budget)
                total_spent = db.session.query(func.sum(FinancialRecord.amount)).filter(
                    FinancialRecord.company_id == company_id,
                    FinancialRecord.department_id == dept.id,
                    FinancialRecord.transaction_type == 'expense'
                ).scalar() or 0.0

                utilization = (float(total_spent) / dept_budget) * 100.0
                if utilization > 100.0:
                    over_amount = float(total_spent) - dept_budget
                    bump_severity(ImpactSeverity.HIGH if utilization <= 120.0 else ImpactSeverity.CRITICAL)
                    step_msg = (
                        f"Department Budget Breach: '{dept.name}' spending (${total_spent:,.2f}) "
                        f"exceeded budget (${dept_budget:,.2f}) by ${over_amount:,.2f} ({utilization:.1f}% utilization)."
                    )
                    causal_steps.append({
                        'step_index': len(causal_steps) + 1,
                        'source_id': root_node_id,
                        'target_id': f"department:{dept.id}",
                        'dependency_type': DependencyType.DERIVED,
                        'attenuated_strength': 1.0,
                        'description': step_msg,
                        'metadata': {
                            'department_id': dept.id,
                            'budget': dept_budget,
                            'total_spent': float(total_spent),
                            'utilization': round(utilization, 2)
                        }
                    })
                    if not dry_run:
                        cls._record_or_update_risk(
                            company_id=company_id,
                            name=f"Budget Breach: {dept.name}",
                            category="Financial",
                            description=step_msg,
                            probability=0.9,
                            impact=0.85 if utilization > 120.0 else 0.7,
                            correlation_id=event.correlation_id
                        )

        # 3. Domain Rule Evaluation: Liquidity & Cash Runway Drop
        if root_type in ['financial_record', 'financial_account', 'company'] or event.event_type.startswith("financial."):
            try:
                runway_res = BusinessStateService.get_runway(company_id)
                runway_val = runway_res.value
                if runway_val is not None and isinstance(runway_val, (int, float)):
                    if runway_val <= 0.0:
                        bump_severity(ImpactSeverity.CRITICAL)
                        step_msg = "Zero Liquid Runway Alert: Company has exhausted liquid cash reserves or is operating at immediate deficit."
                        causal_steps.append({
                            'step_index': len(causal_steps) + 1,
                            'source_id': root_node_id,
                            'target_id': 'metric:cash_runway',
                            'dependency_type': DependencyType.DERIVED,
                            'attenuated_strength': 1.0,
                            'description': step_msg,
                            'metadata': {'runway_months': 0.0}
                        })
                        if not dry_run:
                            cls._record_or_update_risk(
                                company_id=company_id,
                                name="Critical Liquidity Deficit",
                                category="Financial",
                                description=step_msg,
                                probability=0.99,
                                impact=0.99,
                                correlation_id=event.correlation_id
                            )
                    elif runway_val < 3.0:
                        bump_severity(ImpactSeverity.CRITICAL)
                        step_msg = f"Critical Runway Depletion: Cash runway dropped to {runway_val:.1f} months (< 3.0 months emergency threshold)."
                        causal_steps.append({
                            'step_index': len(causal_steps) + 1,
                            'source_id': root_node_id,
                            'target_id': 'metric:cash_runway',
                            'dependency_type': DependencyType.DERIVED,
                            'attenuated_strength': 1.0,
                            'description': step_msg,
                            'metadata': {'runway_months': round(float(runway_val), 2)}
                        })
                        if not dry_run:
                            cls._record_or_update_risk(
                                company_id=company_id,
                                name="Critical Cash Runway Depletion",
                                category="Financial",
                                description=step_msg,
                                probability=0.92,
                                impact=0.90,
                                correlation_id=event.correlation_id
                            )
            except Exception as runway_err:
                logger.debug(f"Runway evaluation skipped during impact propagation: {runway_err}")

        # 4. Domain Rule Evaluation: Inventory Stockout / Low Stock
        if root_type == 'inventory' or event.event_type.startswith("inventory."):
            item_id = int(root_id) if root_id.isdigit() else event.payload.get('item_id')
            if item_id:
                item = Inventory.query.filter_by(id=item_id, company_id=company_id).first()
                if item:
                    qty = getattr(item, 'quantity_on_hand', 0) or 0
                    reorder = getattr(item, 'reorder_point', 10) or 10
                    sku = getattr(item, 'sku', f"SKU-{item.id}")
                    if qty <= 0:
                        bump_severity(ImpactSeverity.CRITICAL)
                        step_msg = f"Stockout Alert: Item '{item.name}' ({sku}) is completely stocked out (0 units on hand). Fulfillment stalled."
                        causal_steps.append({
                            'step_index': len(causal_steps) + 1,
                            'source_id': root_node_id,
                            'target_id': f"inventory:{item.id}",
                            'dependency_type': DependencyType.DIRECT,
                            'attenuated_strength': 1.0,
                            'description': step_msg,
                            'metadata': {'sku': sku, 'quantity': 0}
                        })
                        if not dry_run:
                            cls._record_or_update_risk(
                                company_id=company_id,
                                name=f"Inventory Stockout: {item.name}",
                                category="Operational",
                                description=step_msg,
                                probability=0.95,
                                impact=0.90,
                                correlation_id=event.correlation_id
                            )
                    elif qty <= reorder:
                        bump_severity(ImpactSeverity.MEDIUM)
                        step_msg = f"Low Stock Warning: Item '{item.name}' ({sku}) has {qty} units on hand, at or below reorder threshold ({reorder})."
                        causal_steps.append({
                            'step_index': len(causal_steps) + 1,
                            'source_id': root_node_id,
                            'target_id': f"inventory:{item.id}",
                            'dependency_type': DependencyType.DIRECT,
                            'attenuated_strength': 0.7,
                            'description': step_msg,
                            'metadata': {'sku': sku, 'quantity': qty, 'reorder_point': reorder}
                        })

        # 5. Domain Rule Evaluation: Customer Churn / Termination
        if root_type == 'customer' or event.event_type.startswith("customer."):
            is_deleted = (event.event_type == EventTypes.CUSTOMER_DELETED)
            status_churned = str(event.payload.get('status', '')).lower() in ['churned', 'inactive', 'lost']
            if is_deleted or status_churned:
                cust_name = event.payload.get('name') or f"Customer #{root_id}"
                bump_severity(ImpactSeverity.MEDIUM)
                step_msg = f"Customer Churn: Customer '{cust_name}' marked inactive or removed. Impact on active recurring revenue stream."
                causal_steps.append({
                    'step_index': len(causal_steps) + 1,
                    'source_id': root_node_id,
                    'target_id': 'metric:total_revenue',
                    'dependency_type': DependencyType.DERIVED,
                    'attenuated_strength': 0.8,
                    'description': step_msg,
                    'metadata': {'customer_id': root_id, 'customer_name': cust_name}
                })

        # 6. Graph Downstream Blast-Radius Traversal & Attenuation
        max_depth_reached = 1
        try:
            blast = TwinDependencyService.get_blast_radius(
                company_id=company_id,
                node_id=root_node_id,
                max_depth=cls.MAX_PROPAGATION_DEPTH
            )
            if blast and blast.get('affected_nodes'):
                max_depth_reached = max(max_depth_reached, blast.get('max_depth_reached', 1))
                existing_targets = {s.get('target_id') for s in causal_steps}
                for aff in blast['affected_nodes']:
                    node = aff.get('node', {})
                    t_id = node.get('id')
                    if t_id and t_id not in existing_targets:
                        existing_targets.add(t_id)
                        path = aff.get('causal_path', [])
                        src_id = path[-2] if len(path) > 1 else root_node_id
                        cum_factor = aff.get('attenuated_impact', 1.0)
                        
                        causal_steps.append({
                            'step_index': len(causal_steps) + 1,
                            'source_id': src_id,
                            'target_id': t_id,
                            'dependency_type': aff.get('dependency_type', DependencyType.CONFIGURED),
                            'attenuated_strength': cum_factor,
                            'description': (
                                f"Attenuated downstream ripple to '{node.get('label', t_id)}' "
                                f"({node.get('type', 'node')}) via {aff.get('dependency_type', 'LINK')} "
                                f"[impact factor: {cum_factor:.1%}]"
                            ),
                            'metadata': {
                                'depth': aff.get('depth', 1),
                                'category': node.get('category', ''),
                                'causal_path': path
                            }
                        })
                        if cum_factor >= 0.75 and current_severity == ImpactSeverity.LOW:
                            bump_severity(ImpactSeverity.MEDIUM)
        except Exception as blast_err:
            logger.debug(f"Blast radius traversal skipped during impact propagation: {blast_err}")

        # Summary computation
        affected_unique_nodes = {s.get('target_id') for s in causal_steps if s.get('target_id') != root_node_id}
        summary_text = (
            f"{current_severity} Impact: {len(causal_steps)} causal chain transitions detected across "
            f"{len(affected_unique_nodes)} connected entities from {root_type} #{root_id}."
        )

        if dry_run:
            return {
                'simulated': True,
                'company_id': company_id,
                'trigger_type': event.event_type,
                'root_node_id': root_node_id,
                'root_entity_type': root_type,
                'root_entity_id': root_id,
                'severity': current_severity,
                'affected_nodes_count': len(affected_unique_nodes),
                'max_depth': max_depth_reached,
                'causal_steps': causal_steps,
                'summary_text': summary_text,
                'created_at': datetime.utcnow().isoformat()
            }

        # 7. Persist Permanent Trace
        try:
            trace = ImpactTrace(
                company_id=company_id,
                trigger_event_id=event.event_id,
                correlation_id=event.correlation_id,
                trigger_type=event.event_type,
                root_entity_type=root_type,
                root_entity_id=root_id,
                severity=current_severity,
                affected_nodes_count=len(affected_unique_nodes),
                max_depth=max_depth_reached,
                summary_text=summary_text
            )
            trace.set_causal_steps(causal_steps)
            db.session.add(trace)
            db.session.commit()

            # 8. Emit TWIN_IMPACT_PROPAGATED domain event
            try:
                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.TWIN_IMPACT_PROPAGATED,
                    company_id=company_id,
                    aggregate_type='impact_trace',
                    aggregate_id=trace.trace_id,
                    actor_name='ImpactEngine',
                    correlation_id=event.correlation_id,
                    payload=trace.to_dict()
                ), commit=True)
            except Exception as ev_err:
                logger.error(f"Failed to publish TWIN_IMPACT_PROPAGATED event: {ev_err}")

            return trace
        except Exception as db_err:
            db.session.rollback()
            logger.error(f"Failed to persist ImpactTrace: {db_err}", exc_info=True)
            return None

    @classmethod
    def simulate_impact(
        cls,
        company_id: int,
        root_type: str,
        root_id: str,
        delta_payload: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Execute an uncommitted what-if impact simulation on a candidate twin entity.
        Returns explainable causal chain without modifying live state or creating permanent records.
        """
        mock_event = DomainEvent.create(
            event_type=f"{root_type}.simulated_mutation",
            company_id=company_id,
            aggregate_type=root_type,
            aggregate_id=root_id,
            actor_name='Simulation',
            payload=delta_payload or {}
        )
        return cls.propagate_event(mock_event, dry_run=True)

    @classmethod
    def get_recent_traces(
        cls,
        company_id: int,
        limit: int = 25,
        severity: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Retrieve recent explainable impact traces for a tenant."""
        query = ImpactTrace.query.filter_by(company_id=company_id)
        if severity:
            query = query.filter_by(severity=severity)
        traces = query.order_by(ImpactTrace.created_at.desc()).limit(limit).all()
        return [t.to_dict() for t in traces]

    @classmethod
    def get_trace_by_id(cls, company_id: int, trace_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a specific explainable impact trace by UUID with multi-tenant scoping."""
        trace = ImpactTrace.query.filter_by(company_id=company_id, trace_id=trace_id).first()
        return trace.to_dict() if trace else None

    @classmethod
    def on_domain_event(cls, event: DomainEvent) -> None:
        """
        EventBus subscriber hook. Filters out internal impact events to prevent
        circular cascades and executes causal propagation.
        """
        if event.event_type.startswith("twin.impact.") or event.event_type.startswith("risk."):
            return
        try:
            cls.propagate_event(event, dry_run=False)
        except Exception as e:
            logger.error(f"Error in ImpactEngine domain event listener: {e}", exc_info=True)

    @classmethod
    def _record_or_update_risk(
        cls,
        company_id: int,
        name: str,
        category: str,
        description: str,
        probability: float,
        impact: float,
        correlation_id: Optional[str] = None
    ) -> None:
        """
        Automated Risk Engine trigger: records or updates active operational/financial risks
        resulting from causal threshold violations. Emits TWIN_IMPACT_RISK_TRIGGERED.
        """
        try:
            risk = Risk.query.filter_by(company_id=company_id, name=name).first()
            if not risk:
                risk = Risk(
                    company_id=company_id,
                    name=name,
                    category=category,
                    description=description,
                    probability=probability,
                    impact=impact,
                    status='active'
                )
                risk.calculate_score()
                db.session.add(risk)
                db.session.flush()
            else:
                risk.description = description
                risk.probability = max(float(risk.probability or 0.5), probability)
                risk.impact = max(float(risk.impact or 0.5), impact)
                risk.status = 'active'
                risk.calculate_score()
                db.session.flush()

            # Emit TWIN_IMPACT_RISK_TRIGGERED event
            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.TWIN_IMPACT_RISK_TRIGGERED,
                company_id=company_id,
                aggregate_type='risk',
                aggregate_id=str(risk.id),
                actor_name='ImpactEngine',
                correlation_id=correlation_id,
                payload={
                    'risk_id': risk.id,
                    'name': risk.name,
                    'category': risk.category,
                    'risk_level': risk.risk_level,
                    'risk_score': risk.risk_score,
                    'description': risk.description
                }
            ), commit=False)
        except Exception as risk_err:
            logger.error(f"Failed to record automated risk trigger: {risk_err}", exc_info=True)
