"""
AEVORYN / INSIGHT-PULSE
STAGE 21: DATA QUALITY & LINEAGE SERVICE
Authoritative evaluation of data health, statistical anomalies, and end-to-end lineage DAGs across all 7 digital twin pillars.
"""

import re
import math
from datetime import datetime, date, timedelta
from typing import Dict, Any, List, Optional
from database.db import db
from database.models.company import Company
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.customer import Customer
from database.models.employee import Employee
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.department import Department
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.import_history import ImportHistory
from database.models.business_event import BusinessEvent
from database.models.activity_log import ActivityLog
from services.events import EventBus, DomainEvent, EventTypes


EMAIL_REGEX = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")


class DataQualityService:
    """
    Enterprise Data Quality & Lineage Engine.
    Provides deterministic multi-dimensional data quality scoring, statistical anomaly detection,
    and end-to-end provenance and lineage graphs.
    """

    # Dimension weights (must sum to 1.0)
    WEIGHTS = {
        'completeness': 0.25,
        'freshness': 0.20,
        'consistency': 0.20,
        'uniqueness': 0.15,
        'integrity': 0.10,
        'coverage': 0.10,
    }

    # =========================================================================
    # 1. QUALITY SCORING & AUDITABLE RULES
    # =========================================================================

    @classmethod
    def evaluate_quality(cls, company_id: int, user_id: Optional[int] = None) -> Dict[str, Any]:
        """
        Evaluate comprehensive data health across 6 dimensions and 7 digital twin domains.
        Dispatches DATA_QUALITY_EVALUATED domain event.
        """
        co = Company.query.get(company_id)
        if not co:
            raise ValueError(f"Company {company_id} not found")

        # Gather domain records
        financials = FinancialRecord.query.filter_by(company_id=company_id).all()
        customers = Customer.query.filter_by(company_id=company_id).all()
        employees = Employee.query.filter_by(company_id=company_id).all()
        suppliers = Supplier.query.filter_by(company_id=company_id).all()
        inventory = Inventory.query.filter_by(company_id=company_id).all()
        departments = Department.query.filter_by(company_id=company_id).all()
        custom_twins = CustomTwin.query.filter_by(company_id=company_id).all()

        dept_ids = {d.id for d in departments}
        supplier_ids = {s.id for s in suppliers}

        rules = []

        # ---------------------------------------------------------------------
        # Dimension 1: Completeness (Weight: 25%)
        # ---------------------------------------------------------------------
        comp_checks = 0
        comp_passes = 0

        # Customer completeness
        for c in customers:
            comp_checks += 2
            if c.full_name():
                comp_passes += 1
            if c.email or c.phone:
                comp_passes += 1

        # Employee completeness
        for e in employees:
            comp_checks += 3
            if e.first_name and e.last_name:
                comp_passes += 1
            if e.salary is not None and e.salary > 0:
                comp_passes += 1
            if e.email:
                comp_passes += 1

        # Inventory completeness
        for inv in inventory:
            comp_checks += 3
            if inv.sku:
                comp_passes += 1
            if inv.name:
                comp_passes += 1
            if inv.unit_cost is not None and inv.unit_cost >= 0:
                comp_passes += 1

        # Financial completeness
        for f in financials:
            comp_checks += 3
            if f.amount is not None and f.amount != 0:
                comp_passes += 1
            if f.transaction_type in ('revenue', 'expense'):
                comp_passes += 1
            if f.transaction_date:
                comp_passes += 1

        # Supplier completeness
        for s in suppliers:
            comp_checks += 2
            if s.name:
                comp_passes += 1
            if s.email or s.phone:
                comp_passes += 1

        completeness_score = round((comp_passes / comp_checks * 100.0), 1) if comp_checks > 0 else 0.0

        # ---------------------------------------------------------------------
        # Dimension 2: Freshness / Timeliness (Weight: 20%)
        # ---------------------------------------------------------------------
        all_dates = []
        now_date = date.today()

        for f in financials:
            if f.transaction_date:
                all_dates.append(f.transaction_date)
        for c in customers:
            if c.created_at:
                all_dates.append(c.created_at.date())
        for e in employees:
            if e.created_at:
                all_dates.append(e.created_at.date())
        for inv in inventory:
            if inv.created_at:
                all_dates.append(inv.created_at.date())

        if not all_dates:
            freshness_score = 0.0
            days_since_latest = 999
        else:
            latest_date = max(all_dates)
            days_since_latest = max(0, (now_date - latest_date).days)
            if days_since_latest <= 7:
                freshness_score = 100.0
            elif days_since_latest <= 30:
                freshness_score = 85.0
            elif days_since_latest <= 60:
                freshness_score = 65.0
            elif days_since_latest <= 90:
                freshness_score = 40.0
            elif days_since_latest <= 180:
                freshness_score = 20.0
            else:
                freshness_score = 5.0

        # ---------------------------------------------------------------------
        # Dimension 3: Consistency & Validity (Weight: 20%)
        # ---------------------------------------------------------------------
        valid_checks = 0
        valid_passes = 0

        # Rule FIN_001: Future transaction dates
        failing_fin_future = [f.id for f in financials if f.transaction_date and f.transaction_date > now_date]
        rules.append({
            'rule_id': 'FIN_001',
            'rule_name': 'No Future Transaction Dates',
            'domain': 'financial',
            'severity': 'CRITICAL',
            'passed': len(failing_fin_future) == 0,
            'message': f"Found {len(failing_fin_future)} financial transactions with dates in the future." if failing_fin_future else "All financial transactions have valid historical or current dates.",
            'failing_count': len(failing_fin_future),
            'sample_ids': failing_fin_future[:5]
        })
        valid_checks += len(financials)
        valid_passes += (len(financials) - len(failing_fin_future))

        # Rule FIN_002: Zero or negative transaction amounts
        failing_fin_zero = [f.id for f in financials if f.amount is None or f.amount <= 0]
        rules.append({
            'rule_id': 'FIN_002',
            'rule_name': 'Positive Transaction Amounts',
            'domain': 'financial',
            'severity': 'WARNING',
            'passed': len(failing_fin_zero) == 0,
            'message': f"Found {len(failing_fin_zero)} financial records with zero or negative amounts." if failing_fin_zero else "All financial records have positive transaction amounts.",
            'failing_count': len(failing_fin_zero),
            'sample_ids': failing_fin_zero[:5]
        })
        valid_checks += len(financials)
        valid_passes += (len(financials) - len(failing_fin_zero))

        # Rule INV_001: Negative inventory on hand
        failing_inv_neg = [inv.id for inv in inventory if inv.quantity_on_hand is not None and inv.quantity_on_hand < 0]
        rules.append({
            'rule_id': 'INV_001',
            'rule_name': 'Non-Negative Inventory On-Hand',
            'domain': 'inventory',
            'severity': 'CRITICAL',
            'passed': len(failing_inv_neg) == 0,
            'message': f"Found {len(failing_inv_neg)} inventory items with negative quantity on hand." if failing_inv_neg else "All inventory stock quantities are non-negative.",
            'failing_count': len(failing_inv_neg),
            'sample_ids': failing_inv_neg[:5]
        })
        valid_checks += len(inventory)
        valid_passes += (len(inventory) - len(failing_inv_neg))

        # Rule EMP_001: Active employees must have positive salary
        failing_emp_salary = [e.id for e in employees if e.status == 'active' and (e.salary is None or e.salary <= 0)]
        rules.append({
            'rule_id': 'EMP_001',
            'rule_name': 'Active Employee Salary Threshold',
            'domain': 'employees',
            'severity': 'WARNING',
            'passed': len(failing_emp_salary) == 0,
            'message': f"Found {len(failing_emp_salary)} active employees with zero or missing salary." if failing_emp_salary else "All active employees have positive compensation records.",
            'failing_count': len(failing_emp_salary),
            'sample_ids': failing_emp_salary[:5]
        })
        valid_checks += len(employees)
        valid_passes += (len(employees) - len(failing_emp_salary))

        # Email syntax validity (Customers & Employees)
        cust_invalid_email = [c.id for c in customers if c.email and not EMAIL_REGEX.match(c.email.strip())]
        emp_invalid_email = [e.id for e in employees if e.email and not EMAIL_REGEX.match(e.email.strip())]
        valid_checks += (len(customers) + len(employees))
        valid_passes += ((len(customers) - len(cust_invalid_email)) + (len(employees) - len(emp_invalid_email)))

        consistency_score = round((valid_passes / valid_checks * 100.0), 1) if valid_checks > 0 else 100.0

        # ---------------------------------------------------------------------
        # Dimension 4: Uniqueness & Deduplication (Weight: 15%)
        # ---------------------------------------------------------------------
        uniq_checks = 0
        uniq_passes = 0

        # Rule INV_002: Duplicate SKUs
        sku_map = {}
        for inv in inventory:
            if inv.sku:
                s = inv.sku.strip().upper()
                sku_map.setdefault(s, []).append(inv.id)
        dup_skus = {k: v for k, v in sku_map.items() if len(v) > 1}
        failing_sku_ids = [i for ids in dup_skus.values() for i in ids]
        rules.append({
            'rule_id': 'INV_002',
            'rule_name': 'Unique Inventory SKUs',
            'domain': 'inventory',
            'severity': 'CRITICAL',
            'passed': len(dup_skus) == 0,
            'message': f"Found {len(dup_skus)} duplicate SKUs across {len(failing_sku_ids)} items." if dup_skus else "All inventory item SKUs are unique.",
            'failing_count': len(failing_sku_ids),
            'sample_ids': failing_sku_ids[:5]
        })
        uniq_checks += len(inventory)
        uniq_passes += (len(inventory) - len(failing_sku_ids))

        # Rule CUST_002: Duplicate Customer Emails
        cust_email_map = {}
        for c in customers:
            if c.email:
                em = c.email.strip().lower()
                cust_email_map.setdefault(em, []).append(c.id)
        dup_cust_emails = {k: v for k, v in cust_email_map.items() if len(v) > 1}
        failing_cust_email_ids = [i for ids in dup_cust_emails.values() for i in ids]
        rules.append({
            'rule_id': 'CUST_002',
            'rule_name': 'Unique Customer Emails',
            'domain': 'customers',
            'severity': 'WARNING',
            'passed': len(dup_cust_emails) == 0,
            'message': f"Found {len(dup_cust_emails)} duplicate customer emails across {len(failing_cust_email_ids)} records." if dup_cust_emails else "All customer emails are unique.",
            'failing_count': len(failing_cust_email_ids),
            'sample_ids': failing_cust_email_ids[:5]
        })
        uniq_checks += len(customers)
        uniq_passes += (len(customers) - len(failing_cust_email_ids))

        # Rule EMP_002: Duplicate Employee Emails
        emp_email_map = {}
        for e in employees:
            if e.email:
                em = e.email.strip().lower()
                emp_email_map.setdefault(em, []).append(e.id)
        dup_emp_emails = {k: v for k, v in emp_email_map.items() if len(v) > 1}
        failing_emp_email_ids = [i for ids in dup_emp_emails.values() for i in ids]
        rules.append({
            'rule_id': 'EMP_002',
            'rule_name': 'Unique Employee Emails',
            'domain': 'employees',
            'severity': 'WARNING',
            'passed': len(dup_emp_emails) == 0,
            'message': f"Found {len(dup_emp_emails)} duplicate employee emails." if dup_emp_emails else "All employee emails are unique.",
            'failing_count': len(failing_emp_email_ids),
            'sample_ids': failing_emp_email_ids[:5]
        })
        uniq_checks += len(employees)
        uniq_passes += (len(employees) - len(failing_emp_email_ids))

        uniqueness_score = round((uniq_passes / uniq_checks * 100.0), 1) if uniq_checks > 0 else 100.0

        # ---------------------------------------------------------------------
        # Dimension 5: Relational Integrity (Weight: 10%)
        # ---------------------------------------------------------------------
        integ_checks = 0
        integ_passes = 0

        # Rule REL_001: Employee Department Reference
        orphaned_emps = [e.id for e in employees if e.department_id and e.department_id not in dept_ids]
        rules.append({
            'rule_id': 'REL_001',
            'rule_name': 'Valid Department Reference',
            'domain': 'employees',
            'severity': 'CRITICAL',
            'passed': len(orphaned_emps) == 0,
            'message': f"Found {len(orphaned_emps)} employees assigned to non-existent departments." if orphaned_emps else "All employee department foreign keys are valid.",
            'failing_count': len(orphaned_emps),
            'sample_ids': orphaned_emps[:5]
        })
        integ_checks += len(employees)
        integ_passes += (len(employees) - len(orphaned_emps))

        # Rule REL_002: Inventory Supplier Reference
        orphaned_inv = [inv.id for inv in inventory if inv.supplier_id and inv.supplier_id not in supplier_ids]
        rules.append({
            'rule_id': 'REL_002',
            'rule_name': 'Valid Supplier Reference',
            'domain': 'inventory',
            'severity': 'WARNING',
            'passed': len(orphaned_inv) == 0,
            'message': f"Found {len(orphaned_inv)} inventory items assigned to non-existent suppliers." if orphaned_inv else "All inventory supplier foreign keys are valid.",
            'failing_count': len(orphaned_inv),
            'sample_ids': orphaned_inv[:5]
        })
        integ_checks += len(inventory)
        integ_passes += (len(inventory) - len(orphaned_inv))

        integrity_score = round((integ_passes / integ_checks * 100.0), 1) if integ_checks > 0 else 100.0

        # ---------------------------------------------------------------------
        # Dimension 6: Domain Coverage (Weight: 10%)
        # ---------------------------------------------------------------------
        active_domains = 0
        domain_counts = {
            'financial': len(financials),
            'customers': len(customers),
            'employees': len(employees),
            'suppliers': len(suppliers),
            'inventory': len(inventory),
            'departments': len(departments),
            'custom_twins': len(custom_twins),
        }
        for d_name, cnt in domain_counts.items():
            if cnt > 0:
                active_domains += 1

        coverage_score = round((active_domains / 7.0 * 100.0), 1)

        # ---------------------------------------------------------------------
        # Composite Quality Score
        # ---------------------------------------------------------------------
        composite_score = round(
            (completeness_score * cls.WEIGHTS['completeness']) +
            (freshness_score * cls.WEIGHTS['freshness']) +
            (consistency_score * cls.WEIGHTS['consistency']) +
            (uniqueness_score * cls.WEIGHTS['uniqueness']) +
            (integrity_score * cls.WEIGHTS['integrity']) +
            (coverage_score * cls.WEIGHTS['coverage']),
            1
        )

        # Domain specific sub-scores
        domain_scores = {
            'financial': round(100.0 - (len(failing_fin_future) + len(failing_fin_zero)) * 25.0, 1) if financials else 0.0,
            'customers': round(100.0 - len(failing_cust_email_ids) * 20.0, 1) if customers else 0.0,
            'employees': round(100.0 - (len(failing_emp_salary) + len(orphaned_emps)) * 20.0, 1) if employees else 0.0,
            'inventory': round(100.0 - (len(failing_inv_neg) + len(failing_sku_ids)) * 20.0, 1) if inventory else 0.0,
            'suppliers': 100.0 if suppliers else 0.0,
            'departments': 100.0 if departments else 0.0,
            'custom_twins': 100.0 if custom_twins else 0.0
        }
        for k in domain_scores:
            domain_scores[k] = max(0.0, min(100.0, domain_scores[k]))

        # Run Anomaly Detection
        anomalies = cls.detect_anomalies(company_id)

        # Log and EventBus dispatch
        try:
            EventBus.publish(DomainEvent.create(
                company_id=company_id,
                event_type=EventTypes.DATA_QUALITY_EVALUATED,
                aggregate_type='data_quality',
                aggregate_id=str(company_id),
                actor_id=user_id,
                payload={
                    'score': composite_score,
                    'dimensions': {
                        'completeness': completeness_score,
                        'freshness': freshness_score,
                        'consistency': consistency_score,
                        'uniqueness': uniqueness_score,
                        'integrity': integrity_score,
                        'coverage': coverage_score
                    },
                    'anomalies_count': len(anomalies)
                }
            ))
        except Exception:
            pass

        return {
            'company_id': company_id,
            'composite_score': composite_score,
            'rating': 'EXCELLENT' if composite_score >= 85 else ('GOOD' if composite_score >= 70 else ('FAIR' if composite_score >= 50 else 'POOR')),
            'days_since_latest_record': days_since_latest,
            'dimensions': {
                'completeness': completeness_score,
                'freshness': freshness_score,
                'consistency': consistency_score,
                'uniqueness': uniqueness_score,
                'integrity': integrity_score,
                'coverage': coverage_score,
            },
            'weights': cls.WEIGHTS,
            'domain_counts': domain_counts,
            'domain_scores': domain_scores,
            'rules': rules,
            'rules_passed': sum(1 for r in rules if r['passed']),
            'rules_failed': sum(1 for r in rules if not r['passed']),
            'anomalies_count': len(anomalies),
            'evaluated_at': datetime.utcnow().isoformat()
        }

    # =========================================================================
    # 2. STATISTICAL ANOMALY DETECTION
    # =========================================================================

    @classmethod
    def detect_anomalies(cls, company_id: int) -> List[Dict[str, Any]]:
        """
        Detect statistical outliers across financial transactions, employee compensation,
        and inventory metrics using standard deviation and IQR bounds.
        """
        anomalies = []

        # 1. Financial Transaction Outliers
        for tx_type in ('revenue', 'expense'):
            records = FinancialRecord.query.filter_by(
                company_id=company_id,
                transaction_type=tx_type
            ).all()

            amounts = [r.amount for r in records if r.amount is not None and r.amount > 0]
            if len(amounts) >= 4:
                mean_amt = sum(amounts) / len(amounts)
                variance = sum((x - mean_amt) ** 2 for x in amounts) / (len(amounts) - 1)
                std_dev = math.sqrt(variance)

                sorted_amt = sorted(amounts)
                med_amt = sorted_amt[len(sorted_amt) // 2]

                for r in records:
                    if r.amount is None:
                        continue
                    # 3-sigma rule or 10x median extreme
                    is_3sigma = std_dev > 0 and (abs(r.amount - mean_amt) > 3.0 * std_dev)
                    is_10x_med = med_amt > 0 and r.amount >= 10.0 * med_amt

                    if is_3sigma or is_10x_med:
                        z_score = round((r.amount - mean_amt) / std_dev, 2) if std_dev > 0 else 0.0
                        anomalies.append({
                            'id': f"fin_{r.id}",
                            'domain': 'financial',
                            'anomaly_type': f"extreme_{tx_type}_spike",
                            'severity': 'HIGH' if abs(z_score) >= 4.0 else 'MEDIUM',
                            'record_id': r.id,
                            'field_name': 'amount',
                            'observed_value': r.amount,
                            'expected_range': f"Mean: ${mean_amt:,.2f} ± 3σ [0 - ${mean_amt + 3*std_dev:,.2f}]",
                            'z_score': z_score,
                            'message': f"Unusually large {tx_type} transaction of ${r.amount:,.2f} (Z-Score: {z_score}).",
                            'detected_at': datetime.utcnow().isoformat()
                        })

        # 2. Employee Salary Outliers (IQR Method)
        employees = Employee.query.filter_by(company_id=company_id, status='active').all()
        salaries = [e.salary for e in employees if e.salary is not None and e.salary > 0]
        if len(salaries) >= 4:
            salaries.sort()
            n = len(salaries)
            q1 = salaries[n // 4]
            q3 = salaries[(3 * n) // 4]
            iqr = q3 - q1
            upper_bound = q3 + (3.0 * iqr)
            lower_bound = max(0.0, q1 - (1.5 * iqr))

            for e in employees:
                if e.salary is not None and e.salary > 0 and (e.salary > upper_bound or e.salary < lower_bound):
                    anomalies.append({
                        'id': f"emp_{e.id}",
                        'domain': 'employees',
                        'anomaly_type': 'extreme_compensation_outlier',
                        'severity': 'HIGH' if e.salary > (q3 + 5.0 * iqr) else 'MEDIUM',
                        'record_id': e.id,
                        'field_name': 'salary',
                        'observed_value': e.salary,
                        'expected_range': f"${lower_bound:,.2f} - ${upper_bound:,.2f}",
                        'message': f"Compensation outlier for {e.full_name()}: ${e.salary:,.2f} outside IQR bounds (${lower_bound:,.2f} - ${upper_bound:,.2f}).",
                        'detected_at': datetime.utcnow().isoformat()
                    })

        # 3. Inventory Outliers (Unit Cost & Negative Quantity)
        inventory = Inventory.query.filter_by(company_id=company_id).all()
        for inv in inventory:
            if inv.quantity_on_hand is not None and inv.quantity_on_hand < 0:
                anomalies.append({
                    'id': f"inv_neg_{inv.id}",
                    'domain': 'inventory',
                    'anomaly_type': 'negative_stock_anomaly',
                    'severity': 'HIGH',
                    'record_id': inv.id,
                    'field_name': 'quantity_on_hand',
                    'observed_value': inv.quantity_on_hand,
                    'expected_range': ">= 0",
                    'message': f"Stock count violation: SKU {inv.sku} has negative quantity ({inv.quantity_on_hand}).",
                    'detected_at': datetime.utcnow().isoformat()
                })

        return anomalies

    # =========================================================================
    # 3. METRIC & ENTITY DATA LINEAGE TRACING
    # =========================================================================

    @classmethod
    def get_metric_lineage(cls, company_id: int, metric_name: str) -> Dict[str, Any]:
        """
        Construct directed acyclic graph (DAG) mapping the pin-to-pin derivation of a canonical metric.
        Nodes: Source Origin -> Raw Tables -> Filtering & Aggregation -> Canonical State -> Downstream Consumers.
        """
        co = Company.query.get(company_id)
        if not co:
            raise ValueError(f"Company {company_id} not found")

        metric = metric_name.lower().strip()

        if metric in ('revenue', 'revenue_30d'):
            return {
                'metric': 'revenue_30d',
                'title': '30-Day Observed Revenue',
                'description': 'Trailing 30-day recognized operational revenue from ledger.',
                'nodes': [
                    {'id': 'src_1', 'label': 'Invoices / Payment Gateway / CSV Import', 'type': 'source', 'layer': 0},
                    {'id': 'tbl_1', 'label': 'financial_records (SQL)', 'type': 'table', 'layer': 1, 'table': 'financial_records'},
                    {'id': 'filter_1', 'label': "Filter: transaction_type='revenue' AND date >= now - 30d", 'type': 'transform', 'layer': 2},
                    {'id': 'agg_1', 'label': 'Aggregation: SUM(amount)', 'type': 'transform', 'layer': 3},
                    {'id': 'metric_node', 'label': 'BusinessStateService.get_canonical_state().revenue', 'type': 'canonical_metric', 'layer': 4},
                    {'id': 'c_1', 'label': 'Executive Command Center (KPI)', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_2', 'label': 'Forecasting Engine (ARIMA / Trend)', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_3', 'label': 'Decision Intelligence (Margin Scans)', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_4', 'label': 'Executive Board PDF / Excel Export', 'type': 'consumer', 'layer': 5},
                ],
                'edges': [
                    {'from': 'src_1', 'to': 'tbl_1', 'label': 'insert / sync'},
                    {'from': 'tbl_1', 'to': 'filter_1', 'label': 'query'},
                    {'from': 'filter_1', 'to': 'agg_1', 'label': 'aggregate'},
                    {'from': 'agg_1', 'to': 'metric_node', 'label': 'derive'},
                    {'from': 'metric_node', 'to': 'c_1', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_2', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_3', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_4', 'label': 'consumes'},
                ]
            }

        elif metric in ('expenses', 'expenses_30d', 'burn_rate'):
            return {
                'metric': 'expenses_30d',
                'title': '30-Day Operating Expenses & Monthly Burn',
                'description': 'Sum of operational costs recorded in financial ledger.',
                'nodes': [
                    {'id': 'src_1', 'label': 'Accounts Payable / Payroll / Manual Entry', 'type': 'source', 'layer': 0},
                    {'id': 'tbl_1', 'label': 'financial_records (SQL)', 'type': 'table', 'layer': 1, 'table': 'financial_records'},
                    {'id': 'filter_1', 'label': "Filter: transaction_type='expense' AND date >= now - 30d", 'type': 'transform', 'layer': 2},
                    {'id': 'agg_1', 'label': 'Aggregation: SUM(amount)', 'type': 'transform', 'layer': 3},
                    {'id': 'metric_node', 'label': 'BusinessStateService.get_canonical_state().expenses', 'type': 'canonical_metric', 'layer': 4},
                    {'id': 'c_1', 'label': 'Command Center (Monthly Burn Card)', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_2', 'label': 'Risk Engine (Cash Exhaustion Trigger)', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_3', 'label': 'Financial Runway Model', 'type': 'consumer', 'layer': 5},
                ],
                'edges': [
                    {'from': 'src_1', 'to': 'tbl_1', 'label': 'record'},
                    {'from': 'tbl_1', 'to': 'filter_1', 'label': 'query'},
                    {'from': 'filter_1', 'to': 'agg_1', 'label': 'aggregate'},
                    {'from': 'agg_1', 'to': 'metric_node', 'label': 'derive'},
                    {'from': 'metric_node', 'to': 'c_1', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_2', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_3', 'label': 'consumes'},
                ]
            }

        elif metric in ('runway', 'cash_runway', 'runway_months'):
            return {
                'metric': 'runway_months',
                'title': 'Cash Runway (Months)',
                'description': 'Deterministic solvency ratio: Cash Balance divided by Net Monthly Burn.',
                'nodes': [
                    {'id': 'src_cash', 'label': 'financial_accounts (Asset Balance)', 'type': 'table', 'layer': 0},
                    {'id': 'src_exp', 'label': 'financial_records (Expenses 30d)', 'type': 'table', 'layer': 0},
                    {'id': 'src_rev', 'label': 'financial_records (Revenue 30d)', 'type': 'table', 'layer': 0},
                    {'id': 'calc_burn', 'label': 'Net Burn: Expenses - Revenue', 'type': 'transform', 'layer': 1},
                    {'id': 'calc_runway', 'label': 'Ratio: Cash / Net Monthly Burn', 'type': 'transform', 'layer': 2},
                    {'id': 'metric_node', 'label': 'BusinessStateService.get_canonical_state().runway', 'type': 'canonical_metric', 'layer': 3},
                    {'id': 'c_1', 'label': 'Executive Command Center', 'type': 'consumer', 'layer': 4},
                    {'id': 'c_2', 'label': 'Risk Engine (Liquidity Horizon)', 'type': 'consumer', 'layer': 4},
                    {'id': 'c_3', 'label': 'Decision Intelligence (Cash Warnings)', 'type': 'consumer', 'layer': 4},
                ],
                'edges': [
                    {'from': 'src_exp', 'to': 'calc_burn', 'label': 'input'},
                    {'from': 'src_rev', 'to': 'calc_burn', 'label': 'input'},
                    {'from': 'src_cash', 'to': 'calc_runway', 'label': 'cash_balance'},
                    {'from': 'calc_burn', 'to': 'calc_runway', 'label': 'monthly_burn'},
                    {'from': 'calc_runway', 'to': 'metric_node', 'label': 'derive'},
                    {'from': 'metric_node', 'to': 'c_1', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_2', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_3', 'label': 'consumes'},
                ]
            }

        elif metric in ('inventory_value', 'inventory'):
            return {
                'metric': 'inventory_value',
                'title': 'Inventory Stock Valuation',
                'description': 'Aggregate dollar valuation of current on-hand active catalog inventory.',
                'nodes': [
                    {'id': 'src_1', 'label': 'Warehouse Inbound / Purchase Orders', 'type': 'source', 'layer': 0},
                    {'id': 'tbl_1', 'label': 'inventory (SQL Table)', 'type': 'table', 'layer': 1},
                    {'id': 'filter_1', 'label': 'Filter: is_active == True', 'type': 'transform', 'layer': 2},
                    {'id': 'agg_1', 'label': 'Formula: SUM(quantity_on_hand * unit_cost)', 'type': 'transform', 'layer': 3},
                    {'id': 'metric_node', 'label': 'BusinessStateService.summary.inventory_value', 'type': 'canonical_metric', 'layer': 4},
                    {'id': 'c_1', 'label': 'Supply Chain Digital Twin', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_2', 'label': 'Risk Engine (Stockout & Reorder Alerts)', 'type': 'consumer', 'layer': 5},
                    {'id': 'c_3', 'label': 'Executive Command Center', 'type': 'consumer', 'layer': 5},
                ],
                'edges': [
                    {'from': 'src_1', 'to': 'tbl_1', 'label': 'record'},
                    {'from': 'tbl_1', 'to': 'filter_1', 'label': 'query'},
                    {'from': 'filter_1', 'to': 'agg_1', 'label': 'compute'},
                    {'from': 'agg_1', 'to': 'metric_node', 'label': 'derive'},
                    {'from': 'metric_node', 'to': 'c_1', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_2', 'label': 'consumes'},
                    {'from': 'metric_node', 'to': 'c_3', 'label': 'consumes'},
                ]
            }

        else:
            # Generic Metric Fallback
            return {
                'metric': metric,
                'title': f"{metric.replace('_', ' ').title()}",
                'description': f"Data lineage for canonical metric: {metric}",
                'nodes': [
                    {'id': 'tbl_1', 'label': f"{metric} domain table", 'type': 'table', 'layer': 0},
                    {'id': 'metric_node', 'label': f"Canonical Metric: {metric}", 'type': 'canonical_metric', 'layer': 1},
                    {'id': 'c_1', 'label': 'Executive Command Center', 'type': 'consumer', 'layer': 2}
                ],
                'edges': [
                    {'from': 'tbl_1', 'to': 'metric_node', 'label': 'aggregate'},
                    {'from': 'metric_node', 'to': 'c_1', 'label': 'consumes'}
                ]
            }

    @classmethod
    def get_entity_lineage(cls, company_id: int, entity_type: str, entity_id: int) -> Dict[str, Any]:
        """
        Construct directed acyclic graph (DAG) tracing origin, actor attribution, mutation events,
        and downstream consumers for a specific database entity instance.
        """
        co = Company.query.get(company_id)
        if not co:
            raise ValueError(f"Company {company_id} not found")

        e_type = entity_type.lower().strip()
        nodes = []
        edges = []

        # Find matching business events for this entity
        events = BusinessEvent.query.filter_by(
            company_id=company_id,
            aggregate_id=str(entity_id)
        ).order_by(BusinessEvent.occurred_at.asc()).all()

        # Origin Node
        if events:
            ev_init = events[0]
            actor = ev_init.actor_name or (f"User #{ev_init.actor_id}" if ev_init.actor_id else "System")
            origin_label = f"Event: {ev_init.event_type} by {actor}"
            nodes.append({'id': 'origin', 'label': origin_label, 'type': 'source', 'layer': 0, 'timestamp': ev_init.occurred_at.isoformat()})
        else:
            nodes.append({'id': 'origin', 'label': 'Direct Database Record Insertion', 'type': 'source', 'layer': 0})

        # Entity Node
        entity_label = f"{entity_type.title()} #{entity_id}"
        nodes.append({'id': 'entity', 'label': entity_label, 'type': 'entity', 'layer': 1, 'entity_type': e_type, 'entity_id': entity_id})
        edges.append({'from': 'origin', 'to': 'entity', 'label': 'created'})

        # Mutation Event Nodes
        prev_node = 'entity'
        for idx, ev in enumerate(events[1:], 1):
            nid = f"event_{idx}"
            nodes.append({
                'id': nid,
                'label': f"Mutation: {ev.event_type} ({ev.occurred_at.strftime('%Y-%m-%d %H:%M')})",
                'type': 'event',
                'layer': 2,
                'actor': ev.actor_name or 'User'
            })
            edges.append({'from': prev_node, 'to': nid, 'label': 'modified'})
            prev_node = nid

        # Downstream Consumers Node
        if e_type in ('financial', 'financial_record', 'revenue', 'expense'):
            nodes.append({'id': 'cons_1', 'label': 'Canonical Business State (Financials)', 'type': 'consumer', 'layer': 3})
            nodes.append({'id': 'cons_2', 'label': 'Risk Engine & Decision Intelligence', 'type': 'consumer', 'layer': 3})
            edges.append({'from': prev_node, 'to': 'cons_1', 'label': 'aggregated into'})
            edges.append({'from': prev_node, 'to': 'cons_2', 'label': 'analyzed by'})
        elif e_type in ('employee', 'employees'):
            nodes.append({'id': 'cons_1', 'label': 'Department Headcount & Payroll', 'type': 'consumer', 'layer': 3})
            edges.append({'from': prev_node, 'to': 'cons_1', 'label': 'allocated to'})
        elif e_type in ('inventory', 'inventory_item'):
            nodes.append({'id': 'cons_1', 'label': 'Supply Chain Valuation & Stockouts', 'type': 'consumer', 'layer': 3})
            edges.append({'from': prev_node, 'to': 'cons_1', 'label': 'monitored by'})
        else:
            nodes.append({'id': 'cons_1', 'label': 'Executive Command Center', 'type': 'consumer', 'layer': 3})
            edges.append({'from': prev_node, 'to': 'cons_1', 'label': 'displayed in'})

        return {
            'company_id': company_id,
            'entity_type': entity_type,
            'entity_id': entity_id,
            'nodes': nodes,
            'edges': edges,
            'events_count': len(events)
        }
