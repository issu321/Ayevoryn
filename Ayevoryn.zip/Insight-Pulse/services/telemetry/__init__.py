"""
AEVORYN / INSIGHT-PULSE
STAGE 25: OBSERVABILITY & TELEMETRY PACKAGE
Structured JSON logging, correlation IDs, and runtime telemetry.
"""
from services.telemetry.logger import configure_logging, JSONLogFormatter
from services.telemetry.middleware import init_telemetry_middleware
