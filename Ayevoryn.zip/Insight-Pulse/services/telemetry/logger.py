"""
AEVORYN / INSIGHT-PULSE
STAGE 25: STRUCTURED JSON LOGGING
Formats log records as JSON lines with standardized request tracing keys.
"""

import os
import json
import logging
import traceback
from datetime import datetime
from flask import has_request_context, g, session, request
from flask_login import current_user


class JSONLogFormatter(logging.Formatter):
    """Formats log records into machine-readable JSON lines for Datadog, CloudWatch, and Loki."""

    def format(self, record: logging.LogRecord) -> str:
        log_payload = {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "line": record.lineno,
        }

        # Inject request context if available
        if has_request_context():
            log_payload["request_id"] = getattr(g, "request_id", None)
            log_payload["method"] = request.method
            log_payload["path"] = request.path
            
            # Tenant context
            comp_id = getattr(g, "company_id", None) or session.get("company_id")
            if comp_id is not None:
                log_payload["company_id"] = comp_id

            # User context
            try:
                if current_user and current_user.is_authenticated:
                    log_payload["user_id"] = current_user.id
            except Exception:
                pass

        # Extra metadata attached to record
        if hasattr(record, "extra_fields") and isinstance(record.extra_fields, dict):
            log_payload.update(record.extra_fields)

        # Exception traceback formatting
        if record.exc_info:
            log_payload["exception"] = {
                "type": record.exc_info[0].__name__ if record.exc_info[0] else None,
                "message": str(record.exc_info[1]),
                "stacktrace": traceback.format_exception(*record.exc_info)
            }

        return json.dumps(log_payload, default=str)


def configure_logging(app):
    """Configure structured JSON logging based on environment configuration."""
    log_format = app.config.get('LOG_FORMAT') or os.environ.get('LOG_FORMAT', '').lower()
    is_prod = app.config.get('IS_PRODUCTION', False)

    if log_format == 'json' or is_prod:
        import sys
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JSONLogFormatter())
        
        # Configure root and app loggers
        app.logger.handlers.clear()
        app.logger.addHandler(handler)
        app.logger.setLevel(logging.INFO)
        
        # Don't propagate to avoid duplicate unformatted logs
        app.logger.propagate = False
