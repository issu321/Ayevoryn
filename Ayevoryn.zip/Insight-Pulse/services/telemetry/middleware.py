"""
AEVORYN / INSIGHT-PULSE
STAGE 25: TELEMETRY & TRACING MIDDLEWARE
Injects X-Request-ID, tracks latency, and emits structured access logs.
"""

import time
import uuid
import logging
from flask import request, g
from datetime import datetime

logger = logging.getLogger('access')


def init_telemetry_middleware(app):
    """Attach correlation ID and latency tracking hooks to the Flask app."""
    if not hasattr(app, 'start_time'):
        app.start_time = datetime.utcnow()

    @app.before_request
    def before_request_telemetry():
        # 1. Extract or generate correlation ID
        req_id = request.headers.get('X-Request-ID') or str(uuid.uuid4())
        g.request_id = req_id
        g.request_start_time = time.time()

    @app.after_request
    def after_request_telemetry(response):
        # 1. Compute duration
        start = getattr(g, 'request_start_time', None)
        duration_ms = round((time.time() - start) * 1000, 2) if start else 0.0

        # 2. Add header to response
        req_id = getattr(g, 'request_id', '')
        if req_id:
            response.headers['X-Request-ID'] = req_id

        # 3. Emit access log line (skipping static assets)
        if not request.path.startswith('/static/'):
            record = logger.makeRecord(
                name='access',
                level=logging.INFO,
                fn='',
                lno=0,
                msg=f"{request.method} {request.path} {response.status_code} ({duration_ms}ms)",
                args=(),
                exc_info=None
            )
            record.extra_fields = {
                "http_method": request.method,
                "http_path": request.path,
                "http_status": response.status_code,
                "latency_ms": duration_ms
            }
            logger.handle(record)

        return response
