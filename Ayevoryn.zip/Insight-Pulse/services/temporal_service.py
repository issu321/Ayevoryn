"""
AEVORYN / INSIGHT-PULSE
TEMPORAL DIGITAL TWIN SERVICE (STAGE 13)
Provides point-in-time historical state reconstruction, snapshot creation/management,
and multi-dimensional temporal variance diff analysis across digital twin pillars.
"""

import logging
from typing import Dict, Any, List, Optional
from datetime import datetime, date, timedelta
from sqlalchemy import func

from database.db import db
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.risk import Risk
from database.models.custom_twin import CustomTwinRecord
from database.models.twin_dependency import TwinDependency
from database.models.twin_snapshot import TwinSnapshot, SnapshotType
from services.events import DomainEvent, EventBus, EventTypes

logger = logging.getLogger(__name__)


class TemporalService:
    """Enterprise Temporal Digital Twin & State Reconstruction Engine."""

    # =========================================================================
    # 1. POINT-IN-TIME HISTORICAL STATE RECONSTRUCTION
    # =========================================================================

    @classmethod
    def reconstruct_state_as_of(cls, company_id: int, as_of: datetime) -> Dict[str, Any]:
        """
        Reconstruct the exact digital twin state as it existed at a historical timestamp.
        Filters transactional ledgers and creation timestamps up to `as_of`.
        """
        company = Company.query.get(company_id)
        if not company:
            raise ValueError(f"Company #{company_id} not found")

        as_of_date = as_of.date() if isinstance(as_of, datetime) else as_of
        window_start_date = as_of_date - timedelta(days=30)

        # ---------------------------------------------------------------------
        # Financial Reconstruction (Trailing 30 Days & Cumulative)
        # ---------------------------------------------------------------------
        # Trailing 30-day window metrics
        rev_30d = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= window_start_date,
            FinancialRecord.transaction_date <= as_of_date
        ).scalar() or 0.0

        exp_30d = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= window_start_date,
            FinancialRecord.transaction_date <= as_of_date
        ).scalar() or 0.0

        profit_30d = float(rev_30d) - float(exp_30d)
        margin_pct = (profit_30d / float(rev_30d) * 100.0) if float(rev_30d) > 0 else 0.0
        monthly_burn = float(exp_30d)

        # Cumulative ledger totals up to as_of_date
        cum_rev = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date <= as_of_date
        ).scalar() or 0.0

        cum_exp = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date <= as_of_date
        ).scalar() or 0.0

        # Estimated liquid cash reserve: starting equity + cumulative revenue - cumulative expenses
        starting_equity = float(company.total_equity or 0.0)
        cash_balance = max(0.0, starting_equity + float(cum_rev) - float(cum_exp))

        # Cash runway in months
        runway_months = None
        if monthly_burn > 0 and cash_balance > 0:
            runway_months = round(cash_balance / monthly_burn, 1)
        elif cash_balance <= 0:
            runway_months = 0.0

        # ---------------------------------------------------------------------
        # Operational Entity Counts as of `as_of`
        # ---------------------------------------------------------------------
        dept_count = Department.query.filter(
            Department.company_id == company_id,
            Department.created_at <= as_of
        ).count()

        emp_count = Employee.query.filter(
            Employee.company_id == company_id,
            (Employee.hire_date <= as_of_date) | (Employee.created_at <= as_of)
        ).count()

        cust_count = Customer.query.filter(
            Customer.company_id == company_id,
            (Customer.acquisition_date <= as_of_date) | (Customer.created_at <= as_of)
        ).count()

        sup_count = Supplier.query.filter(
            Supplier.company_id == company_id,
            Supplier.created_at <= as_of
        ).count()

        inv_count = Inventory.query.filter(
            Inventory.company_id == company_id,
            Inventory.created_at <= as_of
        ).count()

        custom_rec_count = CustomTwinRecord.query.filter(
            CustomTwinRecord.company_id == company_id,
            CustomTwinRecord.created_at <= as_of
        ).count()

        risk_count = Risk.query.filter(
            Risk.company_id == company_id,
            Risk.created_at <= as_of,
            Risk.status == 'active'
        ).count()

        # ---------------------------------------------------------------------
        # Graph Topology Summary as of `as_of`
        # ---------------------------------------------------------------------
        total_nodes = dept_count + emp_count + cust_count + sup_count + inv_count
        edge_count = TwinDependency.query.filter(
            TwinDependency.company_id == company_id,
            TwinDependency.created_at <= as_of,
            TwinDependency.is_active == True
        ).count()

        density = 0.0
        if total_nodes > 1:
            possible_edges = total_nodes * (total_nodes - 1)
            density = round(edge_count / possible_edges, 4) if possible_edges > 0 else 0.0

        return {
            'company_id': company_id,
            'as_of': as_of.isoformat(),
            'metrics': {
                'revenue_30d': round(float(rev_30d), 2),
                'expense_30d': round(float(exp_30d), 2),
                'net_profit_30d': round(profit_30d, 2),
                'margin_pct': round(margin_pct, 2),
                'monthly_burn': round(monthly_burn, 2),
                'cash_balance': round(cash_balance, 2),
                'runway_months': runway_months,
                'cumulative_revenue': round(float(cum_rev), 2),
                'cumulative_expenses': round(float(cum_exp), 2)
            },
            'entity_counts': {
                'departments': dept_count,
                'employees': emp_count,
                'customers': cust_count,
                'suppliers': sup_count,
                'inventory_items': inv_count,
                'custom_records': custom_rec_count,
                'active_risks': risk_count
            },
            'graph_topology': {
                'total_nodes': total_nodes,
                'total_edges': edge_count,
                'density': density
            }
        }

    # =========================================================================
    # 2. SNAPSHOT CREATION & MANAGEMENT
    # =========================================================================

    @classmethod
    def create_snapshot(
        cls,
        company_id: int,
        name: str,
        snapshot_type: str = SnapshotType.MANUAL,
        as_of: Optional[datetime] = None,
        description: str = '',
        user_id: Optional[int] = None,
        actor_name: Optional[str] = None
    ) -> TwinSnapshot:
        """
        Capture and freeze the digital twin's state into an immutable historical snapshot.
        Emits TWIN_SNAPSHOT_CREATED domain event.
        """
        if not name or not name.strip():
            raise ValueError("Snapshot name cannot be empty")

        as_of_ts = as_of or datetime.utcnow()
        state = cls.reconstruct_state_as_of(company_id, as_of_ts)

        snapshot = TwinSnapshot(
            company_id=company_id,
            name=name.strip(),
            snapshot_type=snapshot_type if snapshot_type in SnapshotType.ALL else SnapshotType.MANUAL,
            as_of_timestamp=as_of_ts,
            description=description.strip() if description else '',
            created_by=user_id,
            creator_name=actor_name or 'System'
        )
        snapshot.set_metrics(state['metrics'])
        snapshot.set_entity_counts(state['entity_counts'])
        snapshot.set_graph_topology(state['graph_topology'])

        db.session.add(snapshot)
        db.session.commit()

        # Emit domain event
        try:
            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.TWIN_SNAPSHOT_CREATED,
                company_id=company_id,
                aggregate_type='twin_snapshot',
                aggregate_id=snapshot.snapshot_id,
                actor_id=user_id,
                actor_name=actor_name or 'System',
                payload={
                    'snapshot_id': snapshot.snapshot_id,
                    'name': snapshot.name,
                    'snapshot_type': snapshot.snapshot_type,
                    'as_of_timestamp': snapshot.as_of_timestamp.isoformat()
                }
            ), commit=True)
        except Exception as ev_err:
            logger.error(f"Failed to emit TWIN_SNAPSHOT_CREATED event: {ev_err}")

        return snapshot

    @classmethod
    def get_snapshots(
        cls,
        company_id: int,
        limit: int = 50,
        snapshot_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Retrieve historical snapshots for a tenant in descending chronological order."""
        query = TwinSnapshot.query.filter_by(company_id=company_id)
        if snapshot_type and snapshot_type in SnapshotType.ALL:
            query = query.filter_by(snapshot_type=snapshot_type)
        snapshots = query.order_by(TwinSnapshot.as_of_timestamp.desc()).limit(limit).all()
        return [s.to_dict() for s in snapshots]

    @classmethod
    def get_snapshot_by_id(cls, company_id: int, snapshot_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve a specific snapshot by UUID with tenant scoping."""
        snap = TwinSnapshot.query.filter_by(company_id=company_id, snapshot_id=snapshot_id).first()
        return snap.to_dict() if snap else None

    @classmethod
    def delete_snapshot(
        cls,
        company_id: int,
        snapshot_id: str,
        actor_id: Optional[int] = None,
        actor_name: Optional[str] = None
    ) -> bool:
        """Delete a snapshot and emit TWIN_SNAPSHOT_DELETED domain event."""
        snap = TwinSnapshot.query.filter_by(company_id=company_id, snapshot_id=snapshot_id).first()
        if not snap:
            return False

        snap_name = snap.name
        db.session.delete(snap)
        db.session.commit()

        try:
            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.TWIN_SNAPSHOT_DELETED,
                company_id=company_id,
                aggregate_type='twin_snapshot',
                aggregate_id=snapshot_id,
                actor_id=actor_id,
                actor_name=actor_name or 'System',
                payload={'snapshot_id': snapshot_id, 'name': snap_name}
            ), commit=True)
        except Exception as ev_err:
            logger.error(f"Failed to emit TWIN_SNAPSHOT_DELETED event: {ev_err}")

        return True

    # =========================================================================
    # 3. TEMPORAL VARIANCE & PERIOD DIFF ANALYSIS
    # =========================================================================

    @classmethod
    def compare_states(cls, base_state: Dict[str, Any], target_state: Dict[str, Any]) -> Dict[str, Any]:
        """
        Perform a comprehensive multi-dimensional variance analysis between two digital twin states.
        Calculates absolute delta, percentage variance, and qualitative business direction.
        """
        base_metrics = base_state.get('metrics', {})
        target_metrics = target_state.get('metrics', {})

        metric_keys = [
            ('revenue_30d', 'Revenue (30d)', 'higher_is_better'),
            ('expense_30d', 'Expenses (30d)', 'lower_is_better'),
            ('net_profit_30d', 'Net Profit (30d)', 'higher_is_better'),
            ('margin_pct', 'Operating Margin (%)', 'higher_is_better'),
            ('monthly_burn', 'Monthly Burn', 'lower_is_better'),
            ('cash_balance', 'Liquid Cash Balance', 'higher_is_better'),
            ('runway_months', 'Cash Runway (Months)', 'higher_is_better')
        ]

        financial_variances = []
        for key, label, direction in metric_keys:
            b_val = base_metrics.get(key)
            t_val = target_metrics.get(key)

            delta = None
            pct_change = None
            signal = 'NEUTRAL'

            if b_val is not None and t_val is not None and isinstance(b_val, (int, float)) and isinstance(t_val, (int, float)):
                delta = round(float(t_val) - float(b_val), 2)
                if abs(float(b_val)) > 0:
                    pct_change = round((delta / abs(float(b_val))) * 100.0, 1)

                if delta > 0:
                    signal = 'FAVORABLE' if direction == 'higher_is_better' else 'UNFAVORABLE'
                elif delta < 0:
                    signal = 'UNFAVORABLE' if direction == 'higher_is_better' else 'FAVORABLE'

            financial_variances.append({
                'metric_key': key,
                'label': label,
                'base_value': b_val,
                'target_value': t_val,
                'delta': delta,
                'pct_change': pct_change,
                'signal': signal
            })

        # Operational Entity Count Variances
        base_counts = base_state.get('entity_counts', {})
        target_counts = target_state.get('entity_counts', {})
        entity_keys = ['departments', 'employees', 'customers', 'suppliers', 'inventory_items', 'custom_records', 'active_risks']

        entity_variances = {}
        for ek in entity_keys:
            b_c = base_counts.get(ek, 0)
            t_c = target_counts.get(ek, 0)
            entity_variances[ek] = {
                'base': b_c,
                'target': t_c,
                'delta': t_c - b_c
            }

        # Topology Variances
        base_topo = base_state.get('graph_topology', {})
        target_topo = target_state.get('graph_topology', {})
        topo_variances = {
            'nodes': {
                'base': base_topo.get('total_nodes', 0),
                'target': target_topo.get('total_nodes', 0),
                'delta': target_topo.get('total_nodes', 0) - base_topo.get('total_nodes', 0)
            },
            'edges': {
                'base': base_topo.get('total_edges', 0),
                'target': target_topo.get('total_edges', 0),
                'delta': target_topo.get('total_edges', 0) - base_topo.get('total_edges', 0)
            }
        }

        # Human-readable summary
        rev_var = next((f for f in financial_variances if f['metric_key'] == 'revenue_30d'), None)
        prof_var = next((f for f in financial_variances if f['metric_key'] == 'net_profit_30d'), None)
        emp_delta = entity_variances.get('employees', {}).get('delta', 0)
        cust_delta = entity_variances.get('customers', {}).get('delta', 0)

        summary_parts = []
        if rev_var and rev_var['delta'] is not None:
            rev_sign = '+' if rev_var['delta'] >= 0 else ''
            summary_parts.append(f"Revenue shifted by {rev_sign}${rev_var['delta']:,.2f}")
        if prof_var and prof_var['delta'] is not None:
            prof_sign = '+' if prof_var['delta'] >= 0 else ''
            summary_parts.append(f"Net profit shifted by {prof_sign}${prof_var['delta']:,.2f}")
        if emp_delta != 0:
            summary_parts.append(f"Headcount {'+' if emp_delta > 0 else ''}{emp_delta}")
        if cust_delta != 0:
            summary_parts.append(f"Customer base {'+' if cust_delta > 0 else ''}{cust_delta}")

        summary_text = ". ".join(summary_parts) + "." if summary_parts else "Zero variance detected across monitored parameters."

        return {
            'financial_variances': financial_variances,
            'entity_variances': entity_variances,
            'topology_variances': topo_variances,
            'summary_text': summary_text
        }

    @classmethod
    def compare_snapshots(cls, company_id: int, base_snapshot_id: str, target_snapshot_id: str) -> Optional[Dict[str, Any]]:
        """Compare two stored digital twin snapshots by UUID."""
        base_snap = TwinSnapshot.query.filter_by(company_id=company_id, snapshot_id=base_snapshot_id).first()
        target_snap = TwinSnapshot.query.filter_by(company_id=company_id, snapshot_id=target_snapshot_id).first()

        if not base_snap or not target_snap:
            return None

        diff = cls.compare_states(
            {'metrics': base_snap.get_metrics(), 'entity_counts': base_snap.get_entity_counts(), 'graph_topology': base_snap.get_graph_topology()},
            {'metrics': target_snap.get_metrics(), 'entity_counts': target_snap.get_entity_counts(), 'graph_topology': target_snap.get_graph_topology()}
        )

        diff['base_snapshot'] = {
            'snapshot_id': base_snap.snapshot_id,
            'name': base_snap.name,
            'as_of_timestamp': base_snap.as_of_timestamp.isoformat()
        }
        diff['target_snapshot'] = {
            'snapshot_id': target_snap.snapshot_id,
            'name': target_snap.name,
            'as_of_timestamp': target_snap.as_of_timestamp.isoformat()
        }
        return diff

    @classmethod
    def compare_historical_dates(cls, company_id: int, date_a: datetime, date_b: datetime) -> Dict[str, Any]:
        """Reconstruct states at two arbitrary historical timestamps and compute comparative variance."""
        state_a = cls.reconstruct_state_as_of(company_id, date_a)
        state_b = cls.reconstruct_state_as_of(company_id, date_b)

        diff = cls.compare_states(state_a, state_b)
        diff['date_a'] = date_a.isoformat()
        diff['date_b'] = date_b.isoformat()
        return diff
