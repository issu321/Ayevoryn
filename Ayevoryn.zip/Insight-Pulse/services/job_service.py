import atexit
"""
AEVORYN / INSIGHT-PULSE
STAGE 23: BACKGROUND JOB SERVICE & WORKER POOL
Multi-tenant asynchronous execution engine with thread pool workers,
lifecycle telemetry, progress callbacks, and EventBus domain events.
"""

from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import time
import logging
from typing import Optional, Dict, Any, List, Callable
from flask import current_app

from database.db import db
from database.models.job import BackgroundJob
from database.models.company import Company
from services.events import EventBus, DomainEvent
from services.events.types import EventTypes

logger = logging.getLogger(__name__)


class JobCancelledException(Exception):
    """Raised when an executing job detects cancellation."""
    pass


class JobService:
    """Enterprise Background Job Manager with ThreadPoolExecutor and Flask context binding."""

    _executor: Optional[ThreadPoolExecutor] = None
    _app = None
    _handlers: Dict[str, Callable] = {}
    _cancelled_jobs: set = set()

    @classmethod
    def init_app(cls, app, max_workers: int = 4):
        """Initialize the background job thread pool with application reference."""
        cls._app = app
        if cls._executor is None:
            cls._executor = ThreadPoolExecutor(max_workers=max_workers, thread_name_prefix="aev_worker")
            atexit.register(cls.shutdown_executor)
            logger.info(f"[JOB ENGINE] Initialized ThreadPoolExecutor with {max_workers} workers.")

    @classmethod
    def shutdown_executor(cls):
        if cls._executor is not None:
            try:
                cls._executor.shutdown(wait=False, cancel_futures=True)
            except Exception:
                pass
            cls._executor = None

    @classmethod
    def get_executor(cls) -> ThreadPoolExecutor:
        """Ensure thread pool is initialized and return executor."""
        if cls._executor is None:
            cls._executor = ThreadPoolExecutor(max_workers=4, thread_name_prefix="aev_worker")
        return cls._executor

    @classmethod
    def register_handler(cls, job_type: str):
        """Decorator to register a worker function for a specific job_type."""
        def decorator(fn: Callable):
            cls._handlers[job_type] = fn
            return fn
        return decorator

    @classmethod
    def submit_job(cls, company_id: int, user_id: Optional[int], job_type: str,
                   payload: Optional[Dict[str, Any]] = None,
                   priority: int = 5,
                   max_retries: int = 3,
                   synchronous: bool = False) -> BackgroundJob:
        """
        Enqueue a new background job.
        Strictly scopes job to company_id.
        Dispatches JOB_ENQUEUED domain event.
        """
        company = Company.query.get(company_id)
        if not company:
            raise ValueError(f"Company {company_id} not found.")

        if job_type not in cls._handlers:
            raise ValueError(f"Unregistered job type '{job_type}'. Registered: {list(cls._handlers.keys())}")

        job = BackgroundJob(
            company_id=company_id,
            user_id=user_id,
            job_type=job_type,
            priority=priority,
            max_retries=max_retries,
            status='pending',
            progress=0,
            stage_message='Queued in background worker pool',
            created_at=datetime.utcnow()
        )
        job.set_payload(payload or {})
        db.session.add(job)
        db.session.commit()

        # Emit JOB_ENQUEUED
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.JOB_ENQUEUED,
            company_id=company_id,
            aggregate_type="BackgroundJob",
            aggregate_id=job.id,
            actor_id=user_id,
            payload={"job_id": job.id, "job_type": job.job_type}
        ))

        # Resolve active app reference (prefer current_app if within request/app context)
        app_obj = None
        try:
            app_obj = current_app._get_current_object()
        except Exception:
            app_obj = cls._app

        if app_obj is not None:
            cls._app = app_obj

        if synchronous:
            cls._worker_run(job.id, app_obj)
            db.session.refresh(job)
        else:
            cls.get_executor().submit(cls._worker_run, job.id, app_obj)

        return job

    @classmethod
    def enqueue_job(cls, job_type: str, company_id: int,
                    payload: Optional[Dict[str, Any]] = None,
                    user_id: Optional[int] = None,
                    priority: int = 5,
                    max_retries: int = 3,
                    synchronous: bool = False) -> BackgroundJob:
        """Alias for submit_job with flexible keyword arguments."""
        return cls.submit_job(
            company_id=company_id,
            user_id=user_id,
            job_type=job_type,
            payload=payload,
            priority=priority,
            max_retries=max_retries,
            synchronous=synchronous
        )

    @classmethod
    def _worker_run(cls, job_id: str, app_obj=None):
        """Worker thread entrypoint. Wraps execution inside Flask application context."""
        def _run():
            db.session.remove()
            job = db.session.get(BackgroundJob, job_id)
            if not job:
                logger.error(f"[JOB ENGINE] Job {job_id} not found.")
                return

            if job_id in cls._cancelled_jobs:
                cls._cancelled_jobs.discard(job_id)
                job.status = 'cancelled'
                job.stage_message = 'Cancelled prior to execution'
                job.completed_at = datetime.utcnow()
                db.session.commit()
                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.JOB_CANCELLED,
                    company_id=job.company_id,
                    aggregate_type="BackgroundJob",
                    aggregate_id=job.id,
                    payload={"job_id": job.id, "reason": "Cancelled before start"}
                ))
                return

            # Transition to RUNNING
            start_time = datetime.utcnow()
            job.status = 'running'
            job.started_at = start_time
            job.stage_message = 'Execution started'
            db.session.commit()

            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.JOB_STARTED,
                company_id=job.company_id,
                aggregate_type="BackgroundJob",
                aggregate_id=job.id,
                actor_id=job.user_id,
                payload={"job_id": job.id, "job_type": job.job_type}
            ))

            def progress_callback(pct: int, message: str = None):
                """Callback passed to handler to report incremental progress."""
                if job_id in cls._cancelled_jobs:
                    raise JobCancelledException("Job was cancelled by user request.")

                job.progress = max(0, min(100, int(pct)))
                if message:
                    job.stage_message = str(message)[:250]
                db.session.commit()

                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.JOB_PROGRESS,
                    company_id=job.company_id,
                    aggregate_type="BackgroundJob",
                    aggregate_id=job.id,
                    payload={"job_id": job.id, "progress": job.progress, "stage": job.stage_message}
                ))

            handler = cls._handlers.get(job.job_type)
            try:
                result_data = handler(job, job.get_payload(), progress_callback)
                
                # Mark COMPLETED
                end_time = datetime.utcnow()
                job.status = 'completed'
                job.progress = 100
                job.stage_message = 'Completed successfully'
                job.completed_at = end_time
                job.duration_ms = int((end_time - start_time).total_seconds() * 1000)
                job.set_result(result_data)
                db.session.commit()

                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.JOB_COMPLETED,
                    company_id=job.company_id,
                    aggregate_type="BackgroundJob",
                    aggregate_id=job.id,
                    actor_id=job.user_id,
                    payload={
                        "job_id": job.id,
                        "job_type": job.job_type,
                        "duration_ms": job.duration_ms,
                        "status": "completed"
                    }
                ))

            except JobCancelledException as jce:
                cls._cancelled_jobs.discard(job_id)
                end_time = datetime.utcnow()
                job.status = 'cancelled'
                job.stage_message = str(jce)
                job.completed_at = end_time
                job.duration_ms = int((end_time - start_time).total_seconds() * 1000)
                db.session.commit()

                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.JOB_CANCELLED,
                    company_id=job.company_id,
                    aggregate_type="BackgroundJob",
                    aggregate_id=job.id,
                    actor_id=job.user_id,
                    payload={"job_id": job.id, "reason": str(jce)}
                ))

            except Exception as ex:
                logger.exception(f"[JOB ENGINE] Job {job_id} failed: {ex}")
                end_time = datetime.utcnow()
                job.status = 'failed'
                job.error_message = str(ex)
                job.stage_message = f"Failed: {str(ex)[:100]}"
                job.completed_at = end_time
                job.duration_ms = int((end_time - start_time).total_seconds() * 1000)
                db.session.commit()

                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.JOB_FAILED,
                    company_id=job.company_id,
                    aggregate_type="BackgroundJob",
                    aggregate_id=job.id,
                    actor_id=job.user_id,
                    payload={"job_id": job.id, "error": str(ex)}
                ))
            finally:
                db.session.remove()

        if app_obj:
            with app_obj.app_context():
                _run()
        else:
            _run()

    @classmethod
    def cancel_job(cls, job_id: str, company_id: int, user_id: Optional[int] = None) -> Optional[BackgroundJob]:
        """Request cancellation of a pending or running job under tenant validation."""
        job = BackgroundJob.query.filter_by(id=job_id, company_id=company_id).first()
        if not job:
            return None

        if job.status in ('completed', 'failed', 'cancelled'):
            return None

        cls._cancelled_jobs.add(job_id)

        if job.status == 'pending':
            job.status = 'cancelled'
            job.stage_message = 'Cancelled by user'
            job.completed_at = datetime.utcnow()
            db.session.commit()

            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.JOB_CANCELLED,
                company_id=company_id,
                aggregate_type="BackgroundJob",
                aggregate_id=job.id,
                actor_id=user_id,
                payload={"job_id": job.id}
            ))
            return job

        job.stage_message = 'Cancellation requested...'
        db.session.commit()
        return job

    @classmethod
    def get_job(cls, job_id: str, company_id: int) -> Optional[BackgroundJob]:
        """Retrieve single background job verifying tenant isolation."""
        return BackgroundJob.query.filter_by(id=job_id, company_id=company_id).first()

    @classmethod
    def list_jobs(cls, company_id: int, status: Optional[str] = None,
                  job_type: Optional[str] = None, page: int = 1,
                  per_page: int = 20, limit: Optional[int] = None) -> List[BackgroundJob]:
        """List jobs for a company with optional filters."""
        query = BackgroundJob.query.filter_by(company_id=company_id)
        if status:
            query = query.filter_by(status=status.lower())
        if job_type:
            query = query.filter_by(job_type=job_type)
        query = query.order_by(BackgroundJob.created_at.desc())
        if limit is not None:
            return query.limit(limit).all()
        return query.paginate(page=page, per_page=per_page, error_out=False).items

    @classmethod
    def get_job_stats(cls, company_id: int) -> Dict[str, int]:
        """Aggregate count of jobs by status for a tenant."""
        from sqlalchemy import func
        rows = db.session.query(
            BackgroundJob.status, func.count(BackgroundJob.id)
        ).filter_by(company_id=company_id).group_by(BackgroundJob.status).all()
        stats = {status: count for status, count in rows}
        return {
            "pending": stats.get('pending', 0),
            "running": stats.get('running', 0),
            "completed": stats.get('completed', 0),
            "failed": stats.get('failed', 0),
            "cancelled": stats.get('cancelled', 0),
            "total": sum(stats.values())
        }

    @classmethod
    def get_registered_job_types(cls) -> List[Dict[str, Any]]:
        """Return list of registered job types with descriptive metadata."""
        metadata = {
            "simulation_monte_carlo": "Empirical stochastic Monte Carlo simulation across revenue and cost distributions.",
            "data_quality_scan": "Multi-dimensional data completeness, relational integrity, and statistical anomaly detection.",
            "batch_import": "High-throughput asynchronous bulk record ingestion and validation."
        }
        return [
            {
                "type": k,
                "description": metadata.get(k, "Registered background task handler.")
            }
            for k in cls._handlers.keys()
        ]


# ==================== BUILT-IN JOB HANDLERS ====================

@JobService.register_handler("simulation_monte_carlo")
def handle_simulation_monte_carlo(job: BackgroundJob, payload: Dict[str, Any], progress_cb: Callable):
    """Execute stochastic Monte Carlo simulation in background."""
    from services.simulation_service import SimulationService

    progress_cb(10, "Initializing distribution distributions and parameters")
    time.sleep(0.05)

    rev_before = float(payload.get('revenue_before', 100000))
    cost_before = float(payload.get('cost_before', 60000))
    rev_after = float(payload.get('revenue_after', 125000))
    cost_after = float(payload.get('cost_after', 75000))
    iterations = int(payload.get('iterations', 1000))
    volatility = float(payload.get('volatility', 0.15))
    seed = payload.get('seed')

    progress_cb(35, f"Sampling {iterations} stochastic revenue shocks")
    time.sleep(0.05)

    progress_cb(65, "Computing cost correlation and net operating profit vectors")
    time.sleep(0.05)

    results = SimulationService.run_monte_carlo(
        revenue_before=rev_before,
        cost_before=cost_before,
        revenue_after=rev_after,
        cost_after=cost_after,
        iterations=iterations,
        volatility=volatility,
        seed=seed
    )

    progress_cb(90, "Calculating percentiles (P10, P50, P90) and confidence intervals")
    time.sleep(0.05)

    return results


@JobService.register_handler("data_quality_scan")
def handle_data_quality_scan(job: BackgroundJob, payload: Dict[str, Any], progress_cb: Callable):
    """Execute comprehensive data quality evaluation and statistical anomaly detection."""
    from services.data_quality_service import DataQualityService

    progress_cb(15, "Auditing data completeness across customer, employee, and financial records")
    time.sleep(0.05)

    progress_cb(40, "Verifying relational integrity and uniqueness constraints")
    time.sleep(0.05)

    summary = DataQualityService.evaluate_quality(job.company_id)

    progress_cb(75, "Running statistical 3-sigma and IQR anomaly detection")
    time.sleep(0.05)

    anomalies = DataQualityService.detect_anomalies(job.company_id)

    progress_cb(95, "Compiling multi-dimensional quality scorecard")
    return {
        "summary": summary,
        "anomalies_count": len(anomalies),
        "anomalies": anomalies[:25]
    }


@JobService.register_handler("batch_import")
def handle_batch_import(job: BackgroundJob, payload: Dict[str, Any], progress_cb: Callable):
    """Simulate asynchronous batch file ingestion."""
    domain = payload.get('domain', 'general')
    records = payload.get('records', [])
    total = len(records) or 100

    progress_cb(10, f"Validating schema for {total} {domain} rows")
    time.sleep(0.05)

    progress_cb(50, f"Inserting rows 1 to {total // 2} into {domain} ledger")
    time.sleep(0.05)

    progress_cb(85, f"Committing remaining rows and syncing activity log")
    time.sleep(0.05)

    return {
        "domain": domain,
        "total_records_processed": total,
        "success_count": total,
        "failure_count": 0
    }
