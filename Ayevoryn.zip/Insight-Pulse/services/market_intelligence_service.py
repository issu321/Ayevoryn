from typing import List, Dict, Any, Optional
from datetime import datetime
from database.db import db
from database.models.market_data import MarketData
from database.models.company import Company
from services.auth_service import AuthService
from services.events import EventBus, EventTypes, DomainEvent


class MarketIntelligenceService:
    """
    Auto-generates and manages market intelligence data for a company.
    Zero silent synthetic seeding: reading market summary or data NEVER inserts
    randomized records into the database.
    """

    # Industry benchmark profiles (realistic, deterministic baseline standards)
    INDUSTRY_PROFILES = {
        'Technology': {
            'tam': 850_000_000_000, 'tam_growth': 12.5, 'sam_pct': 0.8,
            'avg_competitor_revenue': 50_000_000, 'cac_benchmark': 850,
            'ltv_benchmark': 12_000, 'competitive_density': 45,
            'hhi_index': 1850, 'digital_adoption': 78.0, 'regulatory_risk': 35.0, 'avg_gross_margin': 58.0
        },
        'Manufacturing': {
            'tam': 800_000_000_000, 'tam_growth': 4.2, 'sam_pct': 0.6,
            'avg_competitor_revenue': 120_000_000, 'cac_benchmark': 2_500,
            'ltv_benchmark': 45_000, 'competitive_density': 28,
            'hhi_index': 2100, 'digital_adoption': 52.0, 'regulatory_risk': 48.0, 'avg_gross_margin': 32.0
        },
        'Retail': {
            'tam': 1_200_000_000_000, 'tam_growth': 3.5, 'sam_pct': 0.9,
            'avg_competitor_revenue': 200_000_000, 'cac_benchmark': 35,
            'ltv_benchmark': 800, 'competitive_density': 120,
            'hhi_index': 1400, 'digital_adoption': 65.0, 'regulatory_risk': 25.0, 'avg_gross_margin': 28.0
        },
        'E-Commerce': {
            'tam': 650_000_000_000, 'tam_growth': 14.8, 'sam_pct': 0.85,
            'avg_competitor_revenue': 15_000_000, 'cac_benchmark': 45,
            'ltv_benchmark': 650, 'competitive_density': 85,
            'hhi_index': 1650, 'digital_adoption': 92.0, 'regulatory_risk': 30.0, 'avg_gross_margin': 42.0
        },
        'Logistics': {
            'tam': 550_000_000_000, 'tam_growth': 6.1, 'sam_pct': 0.7,
            'avg_competitor_revenue': 80_000_000, 'cac_benchmark': 1_200,
            'ltv_benchmark': 18_000, 'competitive_density': 35,
            'hhi_index': 2250, 'digital_adoption': 58.0, 'regulatory_risk': 42.0, 'avg_gross_margin': 22.0
        },
        'Healthcare': {
            'tam': 4_500_000_000_000, 'tam_growth': 8.3, 'sam_pct': 0.5,
            'avg_competitor_revenue': 300_000_000, 'cac_benchmark': 4_500,
            'ltv_benchmark': 85_000, 'competitive_density': 22,
            'hhi_index': 2400, 'digital_adoption': 48.0, 'regulatory_risk': 62.0, 'avg_gross_margin': 45.0
        },
        'Finance': {
            'tam': 2_100_000_000_000, 'tam_growth': 6.5, 'sam_pct': 0.75,
            'avg_competitor_revenue': 180_000_000, 'cac_benchmark': 320,
            'ltv_benchmark': 4_500, 'competitive_density': 55,
            'hhi_index': 1950, 'digital_adoption': 85.0, 'regulatory_risk': 55.0, 'avg_gross_margin': 65.0
        },
        'Education': {
            'tam': 350_000_000_000, 'tam_growth': 9.2, 'sam_pct': 0.65,
            'avg_competitor_revenue': 8_000_000, 'cac_benchmark': 180,
            'ltv_benchmark': 2_400, 'competitive_density': 40,
            'hhi_index': 1500, 'digital_adoption': 72.0, 'regulatory_risk': 38.0, 'avg_gross_margin': 52.0
        },
        'Consulting': {
            'tam': 250_000_000_000, 'tam_growth': 5.8, 'sam_pct': 0.8,
            'avg_competitor_revenue': 12_000_000, 'cac_benchmark': 2_800,
            'ltv_benchmark': 55_000, 'competitive_density': 60,
            'hhi_index': 1350, 'digital_adoption': 68.0, 'regulatory_risk': 22.0, 'avg_gross_margin': 48.0
        },
        'Food & Beverage': {
            'tam': 900_000_000_000, 'tam_growth': 4.5, 'sam_pct': 0.9,
            'avg_competitor_revenue': 45_000_000, 'cac_benchmark': 28,
            'ltv_benchmark': 450, 'competitive_density': 95,
            'hhi_index': 1750, 'digital_adoption': 54.0, 'regulatory_risk': 45.0, 'avg_gross_margin': 35.0
        },
        'Real Estate': {
            'tam': 400_000_000_000, 'tam_growth': 3.8, 'sam_pct': 0.7,
            'avg_competitor_revenue': 25_000_000, 'cac_benchmark': 850,
            'ltv_benchmark': 15_000, 'competitive_density': 50,
            'hhi_index': 1600, 'digital_adoption': 42.0, 'regulatory_risk': 40.0, 'avg_gross_margin': 38.0
        },
        'Energy': {
            'tam': 700_000_000_000, 'tam_growth': 5.2, 'sam_pct': 0.6,
            'avg_competitor_revenue': 250_000_000, 'cac_benchmark': 5_500,
            'ltv_benchmark': 120_000, 'competitive_density': 18,
            'hhi_index': 2600, 'digital_adoption': 45.0, 'regulatory_risk': 58.0, 'avg_gross_margin': 26.0
        },
        'Agriculture': {
            'tam': 300_000_000_000, 'tam_growth': 3.2, 'sam_pct': 0.8,
            'avg_competitor_revenue': 15_000_000, 'cac_benchmark': 450,
            'ltv_benchmark': 8_500, 'competitive_density': 32,
            'hhi_index': 1450, 'digital_adoption': 38.0, 'regulatory_risk': 35.0, 'avg_gross_margin': 24.0
        }
    }

    DEFAULT_PROFILE = {
        'tam': 100_000_000_000, 'tam_growth': 5.0, 'sam_pct': 0.7,
        'avg_competitor_revenue': 25_000_000, 'cac_benchmark': 500,
        'ltv_benchmark': 5_000, 'competitive_density': 40,
        'hhi_index': 1800, 'digital_adoption': 60.0, 'regulatory_risk': 35.0, 'avg_gross_margin': 40.0
    }

    @staticmethod
    def _fmt_money(amount: float, currency_symbol: str = '$') -> str:
        """Format a monetary amount with the given currency symbol."""
        return f"{currency_symbol}{abs(amount):,.0f}"

    @staticmethod
    def get_market_data(company_id: int) -> List[MarketData]:
        """
        Fetch existing market data records strictly from the database.
        Zero silent background auto-seeding.
        """
        return MarketData.query.filter_by(company_id=company_id).order_by(
            MarketData.created_at.desc(), MarketData.id.desc()
        ).limit(100).all()

    @staticmethod
    def get_or_create_market_data(company_id: int, currency_code: str = 'USD') -> List[MarketData]:
        """
        Backward-compatible alias for get_market_data.
        Does NOT silently seed or mutate the database.
        """
        return MarketIntelligenceService.get_market_data(company_id)

    @staticmethod
    def load_industry_benchmarks(
        company_id: int,
        currency_code: str = 'USD',
        actor_user_id: Optional[int] = None
    ) -> List[MarketData]:
        """
        Explicit user action to load reference benchmark records for the company's industry.
        Stamped with is_benchmark=True, provenance='INDUSTRY_REFERENCE'.
        """
        company = Company.query.get(company_id)
        industry = (company.industry or 'Other') if company else 'Other'
        region = (company.country or 'Global') if company else 'Global'

        profile = MarketIntelligenceService.INDUSTRY_PROFILES.get(
            industry, MarketIntelligenceService.DEFAULT_PROFILE
        )

        tam = profile['tam']
        sam = tam * profile['sam_pct']
        som = sam * 0.005  # Deterministic 0.5% slice for SOM

        year = datetime.utcnow().year
        metrics = [
            ('Total Addressable Market (TAM)', tam, 'USD'),
            ('Serviceable Addressable Market (SAM)', sam, 'USD'),
            ('Serviceable Obtainable Market (SOM)', som, 'USD'),
            ('Market Growth Rate (YoY)', profile['tam_growth'], 'PERCENT'),
            ('Average Competitor Revenue', profile['avg_competitor_revenue'], 'USD'),
            ('Industry Avg Customer Acquisition Cost', profile['cac_benchmark'], 'USD'),
            ('Industry Avg Customer Lifetime Value', profile['ltv_benchmark'], 'USD'),
            ('Competitive Density Index', profile['competitive_density'], 'INDEX'),
            ('Market Concentration (HHI Est.)', profile.get('hhi_index', 1800), 'INDEX'),
            ('Digital Adoption Rate', profile.get('digital_adoption', 60.0), 'PERCENT'),
            ('Regulatory Risk Score', profile.get('regulatory_risk', 35.0), 'SCORE'),
            ('Average Gross Margin (Industry)', profile.get('avg_gross_margin', 40.0), 'PERCENT'),
        ]

        created = []
        for name, value, unit in metrics:
            md = MarketData(
                company_id=company_id,
                market_name=f"{industry} Market",
                industry=industry,
                region=region,
                metric_name=name,
                metric_value=round(float(value), 2),
                currency=currency_code if unit == 'USD' else None,
                period=f'FY {year}',
                year=year,
                quarter=None,
                source='Industry Reference Benchmark',
                is_benchmark=True,
                provenance='INDUSTRY_REFERENCE',
                notes=f'Standard benchmark for {industry} sector in {region}. Verified reference data.'
            )
            db.session.add(md)
            created.append(md)

        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'market_benchmarks_loaded',
                f"Loaded {len(created)} industry benchmarks for company {company_id}"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.MARKET_BENCHMARK_LOADED,
            company_id=company_id,
            aggregate_type='market_data',
            aggregate_id=f'mkt-bench-{company_id}',
            payload={'benchmarks_count': len(created), 'industry': industry},
            actor_id=actor_user_id
        ))

        return created

    @staticmethod
    def create_market_datum(
        company_id: int,
        data: Dict[str, Any],
        actor_user_id: Optional[int] = None
    ) -> MarketData:
        """
        Create a custom market intelligence metric record.
        """
        metric_name = str(data.get('metric_name', '')).strip()
        if not metric_name:
            raise ValueError("Metric name is required.")

        company = Company.query.get(company_id)
        industry = data.get('industry') or (company.industry if company else 'General')
        region = data.get('region') or (company.country if company else 'Global')

        md = MarketData(
            company_id=company_id,
            market_name=data.get('market_name') or f"{industry} Market",
            industry=industry,
            region=region,
            metric_name=metric_name,
            metric_value=float(data.get('metric_value', 0.0) or 0.0),
            currency=data.get('currency', 'USD'),
            period=data.get('period') or f'FY {datetime.utcnow().year}',
            year=int(data.get('year') or datetime.utcnow().year),
            quarter=int(data['quarter']) if data.get('quarter') else None,
            source=data.get('source') or 'User Entry',
            is_benchmark=False,
            provenance='USER_ENTERED',
            notes=data.get('notes')
        )
        db.session.add(md)
        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'market_metric_created',
                f"Created market metric '{metric_name}' ({md.metric_value})"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.MARKET_DATA_UPDATED,
            company_id=company_id,
            aggregate_type='market_data',
            aggregate_id=f'mkt-{md.id}',
            payload=md.to_dict(),
            actor_id=actor_user_id
        ))

        return md

    @staticmethod
    def delete_market_datum(
        company_id: int,
        datum_id: int,
        actor_user_id: Optional[int] = None
    ) -> bool:
        """
        Delete a market datum with strict tenant isolation.
        """
        md = MarketData.query.filter_by(id=datum_id, company_id=company_id).first()
        if not md:
            return False

        name = md.metric_name
        db.session.delete(md)
        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'market_metric_deleted',
                f"Deleted market metric '{name}' (id: {datum_id})"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.MARKET_DATA_UPDATED,
            company_id=company_id,
            aggregate_type='market_data',
            aggregate_id=f'mkt-{datum_id}',
            payload={'action': 'deleted', 'id': datum_id, 'metric_name': name},
            actor_id=actor_user_id
        ))

        return True

    @staticmethod
    def import_market_data(
        company_id: int,
        records_list: List[Dict[str, Any]],
        actor_user_id: Optional[int] = None
    ) -> List[MarketData]:
        """
        Bulk import market data records with validation.
        """
        created = []
        for rec in records_list:
            metric_name = str(rec.get('metric_name', '')).strip()
            if not metric_name:
                continue

            md = MarketData(
                company_id=company_id,
                market_name=rec.get('market_name', 'Custom Market'),
                industry=rec.get('industry'),
                region=rec.get('region'),
                metric_name=metric_name,
                metric_value=float(rec.get('metric_value', 0.0) or 0.0),
                currency=rec.get('currency', 'USD'),
                period=rec.get('period'),
                year=int(rec.get('year')) if rec.get('year') else datetime.utcnow().year,
                quarter=int(rec.get('quarter')) if rec.get('quarter') else None,
                source=rec.get('source', 'User Import'),
                is_benchmark=False,
                provenance='IMPORT',
                notes=rec.get('notes')
            )
            db.session.add(md)
            created.append(md)

        if created:
            db.session.commit()

            if actor_user_id:
                AuthService.log_action(
                    actor_user_id,
                    'market_data_imported',
                    f"Imported {len(created)} market data records"
                )

            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.MARKET_DATA_UPDATED,
                company_id=company_id,
                aggregate_type='market_data',
                aggregate_id=f'mkt-import-{company_id}',
                payload={'imported_count': len(created)},
                actor_id=actor_user_id
            ))

        return created

    @staticmethod
    def refresh_market_data(company_id: int, currency_code: str = 'USD') -> List[MarketData]:
        """
        Delete old benchmark data and reload fresh deterministic industry benchmarks.
        """
        MarketData.query.filter_by(company_id=company_id, is_benchmark=True).delete()
        db.session.commit()
        return MarketIntelligenceService.load_industry_benchmarks(company_id, currency_code=currency_code)

    @staticmethod
    def get_market_summary(company_id: int, currency_code: str = 'USD') -> Optional[Dict[str, Any]]:
        """
        Build market intelligence summary.
        If custom database records exist, grounded in them.
        If no database records exist, provides a transparent unseeded reference baseline
        WITHOUT inserting rows into the database.
        """
        company = Company.query.get(company_id)
        if not company:
            return None

        data = MarketIntelligenceService.get_market_data(company_id)
        industry = (company.industry or 'Other')
        region = (company.country or 'Global')
        annual_revenue = float(company.annual_revenue or 0.0)

        profile = MarketIntelligenceService.INDUSTRY_PROFILES.get(
            industry, MarketIntelligenceService.DEFAULT_PROFILE
        )

        has_custom_data = bool(data)

        if has_custom_data:
            metrics = {d.metric_name: float(d.metric_value or 0.0) for d in data}
            tam = metrics.get('Total Addressable Market (TAM)', profile['tam'])
            sam = metrics.get('Serviceable Addressable Market (SAM)', tam * profile['sam_pct'])
            som = metrics.get('Serviceable Obtainable Market (SOM)', sam * 0.005)
            growth = metrics.get('Market Growth Rate (YoY)', profile['tam_growth'])
            cac = metrics.get('Industry Avg Customer Acquisition Cost', profile['cac_benchmark'])
            ltv = metrics.get('Industry Avg Customer Lifetime Value', profile['ltv_benchmark'])
            density = metrics.get('Competitive Density Index', profile['competitive_density'])
            avg_comp_rev = metrics.get('Average Competitor Revenue', profile['avg_competitor_revenue'])
        else:
            # Deterministic, unseeded reference baseline
            metrics = {}
            tam = float(profile['tam'])
            sam = float(tam * profile['sam_pct'])
            som = float(sam * 0.005)
            growth = float(profile['tam_growth'])
            cac = float(profile['cac_benchmark'])
            ltv = float(profile['ltv_benchmark'])
            density = float(profile['competitive_density'])
            avg_comp_rev = float(profile['avg_competitor_revenue'])

        market_share_pct = (annual_revenue / tam * 100.0) if tam > 0 else 0.0
        sam_share_pct = (annual_revenue / sam * 100.0) if sam > 0 else 0.0
        ltv_cac_ratio = ltv / max(cac, 1.0)
        vs_competitor_pct = (annual_revenue / max(avg_comp_rev, 1.0) * 100.0)

        if market_share_pct < 0.001:
            position = "Nascent Entrant"
            position_desc = "Your revenue represents an initial slice of total market ceiling, with significant headroom for expansion."
        elif market_share_pct < 0.01:
            position = "Emerging Player"
            position_desc = "Meaningful initial market presence established. Focus on segment retention before multi-vertical expansion."
        elif market_share_pct < 0.1:
            position = "Established Participant"
            position_desc = "Substantial market footprint. Defend core customer accounts while targeting adjacent market segments."
        else:
            position = "Market Leader"
            position_desc = "Major market share footprint. Prioritize margin preservation and customer ecosystem lock-in."

        if growth > 10.0:
            growth_opportunity = "High-growth sector trajectory. Customer acquisition velocity yields outsized compounded returns."
        elif growth > 5.0:
            growth_opportunity = "Steady expansion pace. Balance customer acquisition expenditure with net revenue retention."
        else:
            growth_opportunity = "Mature market dynamics. Growth is primarily driven by direct customer displacement and differentiation."

        if density > 70.0:
            competition_level = "Hyper-Competitive"
            competition_desc = "Dense competitive saturation. Price discipline and defensible value propositions are critical."
        elif density > 40.0:
            competition_level = "Competitive"
            competition_desc = "Moderate competitive density. Focus on differentiated customer experience and product capabilities."
        else:
            competition_level = "Consolidated"
            competition_desc = "Market dominated by concentrated incumbents. High barriers to entry protect prevailing margins."

        return {
            'metrics': metrics,
            'data': data,
            'has_custom_data': has_custom_data,
            'industry': industry,
            'region': region,
            'annual_revenue': annual_revenue,
            'market_share_pct': market_share_pct,
            'sam_share_pct': sam_share_pct,
            'ltv_cac_ratio': ltv_cac_ratio,
            'vs_competitor_pct': vs_competitor_pct,
            'position': position,
            'position_desc': position_desc,
            'growth_opportunity': growth_opportunity,
            'competition_level': competition_level,
            'competition_desc': competition_desc,
            'tam': tam,
            'sam': sam,
            'som': som,
            'growth_rate': growth,
            'generated_at': datetime.utcnow().strftime('%B %d, %Y')
        }
