from database.db import db
from database.models.financial import FinancialRecord
from database.models.company import Company
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.inventory import Inventory
from sqlalchemy import func, extract
from datetime import datetime, timedelta

def _fmt_money(amount, currency_symbol='$'):
    return f"{currency_symbol}{abs(amount):,.0f}"

class AnalyticsService:
    @staticmethod
    def get_executive_summary(company_id):
        # Auto-correct company_size based on employee_count if mismatch
        from services.company_service import CompanyService
        company = CompanyService.get_company(company_id)
        if company and company.employee_count:
            correct_size = AnalyticsService._get_company_size_from_employees(company.employee_count)
            if company.company_size != correct_size:
                company.company_size = correct_size
                db.session.commit()

        from services.business_state_service import BusinessStateService
        state = BusinessStateService.get_canonical_state(company_id)
        return state['summary']


    @staticmethod
    def _setup_completion(company, roster_active, customer_rows, sku_count, has_ledger):
        steps = [
            bool(company),
            roster_active > 0,
            customer_rows > 0,
            sku_count > 0,
            bool(has_ledger),
        ]
        return sum(1 for x in steps if x) / len(steps) * 100

    @staticmethod
    def _get_company_size_from_employees(employee_count):
        """Get correct company size string based on employee count."""
        if employee_count <= 10:
            return '1-10'
        elif employee_count <= 50:
            return '11-50'
        elif employee_count <= 200:
            return '51-200'
        elif employee_count <= 500:
            return '201-500'
        elif employee_count <= 1000:
            return '501-1000'
        else:
            return '1000+'
    
    @staticmethod
    def _estimate_customers(company):
        """Estimate customer count based on company size and revenue for realistic data."""
        if not company:
            return 0
        
        # FIX: First check employee_count to determine correct size category
        if company.employee_count:
            if company.employee_count >= 1000:
                return 50000
            elif company.employee_count >= 501:
                return 15000
            elif company.employee_count >= 201:
                return 5000
            elif company.employee_count >= 51:
                return 1000
            elif company.employee_count >= 11:
                return 200
            else:
                return 50
        
        # Fallback: Use company_size string
        size_map = {
            '1-10': 50,
            '11-50': 200,
            '51-200': 1000,
            '201-500': 5000,
            '501-1000': 15000,
            '1000+': 50000
        }
        
        if company.company_size and company.company_size in size_map:
            return size_map[company.company_size]
        
        # Fallback based on annual revenue
        if company.annual_revenue:
            revenue = float(company.annual_revenue)
            if revenue < 100000:
                return 50
            elif revenue < 1000000:
                return 500
            elif revenue < 10000000:
                return 5000
            elif revenue < 100000000:
                return 50000
            else:
                return 200000
        
        return 1000  # Default fallback
    
    @staticmethod
    def _calculate_health_score(margin, churn_rate, low_stock, total_skus):
        margin_score = min(max(margin / 20 * 25, 0), 25)
        churn_score = max(0, 25 - churn_rate / 4 * 25)
        stock_score = max(0, 25 - (low_stock / max(total_skus, 1) * 100) / 20 * 25)
        diversity_score = min(total_skus / 50 * 25, 25)
        return min(100, margin_score + churn_score + stock_score + diversity_score)
    
    @staticmethod
    def get_trend_data(company_id, days=90, granularity='auto'):
        """
        Produces authoritative financial velocity data for corporate dashboards.
        Supports both executive monthly aggregation (for 6M/12M/macro views) and
        granular daily tracking (for 30D micro views).
        """
        from datetime import date
        end_date = datetime.utcnow().date()
        
        # Determine whether to aggregate monthly or daily
        is_monthly = (granularity == 'monthly') or (granularity == 'auto' and days >= 60)
        
        if is_monthly:
            # Multi-month executive view (6 months default for 90-180D, 12 months for 365D)
            num_months = 12 if days >= 300 else (6 if days <= 180 else 12)
            cur_year, cur_month = end_date.year, end_date.month
            
            ym_list = []
            for i in range(num_months - 1, -1, -1):
                y = cur_year
                m = cur_month - i
                while m <= 0:
                    m += 12
                    y -= 1
                ym_list.append((y, m))
            
            start_date = date(ym_list[0][0], ym_list[0][1], 1)
            
            rows = db.session.query(
                extract('year', FinancialRecord.transaction_date).label('y'),
                extract('month', FinancialRecord.transaction_date).label('m'),
                FinancialRecord.transaction_type,
                func.sum(FinancialRecord.amount).label('total')
            ).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_date >= start_date
            ).group_by(
                'y', 'm', FinancialRecord.transaction_type
            ).all()
            
            monthly_map = {}
            for y, m, t_type, total in rows:
                monthly_map[(int(y), int(m), t_type)] = float(total or 0.0)
            
            month_names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
            dates_out = []
            labels_out = []
            rev_out = []
            exp_out = []
            profit_out = []
            margins_out = []
            
            for y, m in ym_list:
                label = f"{month_names[m-1]} {y}"
                r = monthly_map.get((y, m, 'revenue'), 0.0)
                e = monthly_map.get((y, m, 'expense'), 0.0)
                p = round(r - e, 2)
                margin = round((p / r * 100.0), 1) if r > 0 else 0.0
                
                dates_out.append(label)
                labels_out.append(label)
                rev_out.append(round(r, 2))
                exp_out.append(round(e, 2))
                profit_out.append(p)
                margins_out.append(margin)
            
            return {
                'dates': dates_out,
                'labels': labels_out,
                'revenue': rev_out,
                'expenses': exp_out,
                'profit': profit_out,
                'margins': margins_out,
                'granularity': 'monthly'
            }
        else:
            # Daily granular view for short periods (<= 30 days)
            start_date = end_date - timedelta(days=days)
            data = db.session.query(
                FinancialRecord.transaction_date,
                FinancialRecord.transaction_type,
                func.sum(FinancialRecord.amount).label('total')
            ).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_date >= start_date
            ).group_by(
                FinancialRecord.transaction_date,
                FinancialRecord.transaction_type
            ).order_by(FinancialRecord.transaction_date).all()
            
            daily = {}
            for transaction_date, transaction_type, total in data:
                daily.setdefault(transaction_date, {'revenue': 0.0, 'expense': 0.0})
                daily[transaction_date][transaction_type] = float(total or 0)

            dates = [start_date + timedelta(days=i) for i in range(days + 1)]
            revenue = [daily.get(d, {}).get('revenue', 0.0) for d in dates]
            expenses = [daily.get(d, {}).get('expense', 0.0) for d in dates]
            profit = [round(r - e, 2) for r, e in zip(revenue, expenses)]
            margins = [round((p / r * 100.0), 1) if r > 0 else 0.0 for p, r in zip(profit, revenue)]
            
            return {
                'dates': [d.isoformat() for d in dates],
                'labels': [d.strftime('%b %d') for d in dates],
                'revenue': revenue,
                'expenses': expenses,
                'profit': profit,
                'margins': margins,
                'granularity': 'daily'
            }
    
    @staticmethod
    def _generate_sample_trend(days, company_id=None):
        """Generate realistic sample trend data based on company settings."""
        company = None
        if company_id:
            from services.company_service import CompanyService
            company = CompanyService.get_company(company_id)
        
        # Kept for backwards compatibility with older callers. It now returns
        # an explicit empty series instead of a fabricated business history.
        dates = [(datetime.utcnow().date() - timedelta(days=i)) for i in range(days, -1, -1)]
        return {'dates': [d.isoformat() for d in dates],
                'revenue': [0.0] * len(dates),
                'expenses': [0.0] * len(dates),
                'profit': [0.0] * len(dates)}
    
    @staticmethod
    def _department_live_totals(company_id):
        """LIVE per-department aggregates computed fresh from the DB on every
        call — no stored snapshots, nothing written back during a GET.

        budget = SUM(projects.budget) for the department (falls back to the
                 department's own budget field when it has no projects)
        spent  = SUM(projects.spent) + SUM(expense FinancialRecords attributed
                 to the department)
        Returns {department_id: {'budget': float, 'spent': float}}.
        """
        from database.models.department import Department
        from database.models.project import Project

        proj_rows = db.session.query(
            Project.department_id,
            func.coalesce(func.sum(Project.budget), 0.0),
            func.coalesce(func.sum(Project.spent), 0.0)
        ).filter(
            Project.company_id == company_id,
            Project.department_id.isnot(None)
        ).group_by(Project.department_id).all()

        fin_rows = db.session.query(
            FinancialRecord.department_id,
            func.coalesce(func.sum(FinancialRecord.amount), 0.0)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.department_id.isnot(None)
        ).group_by(FinancialRecord.department_id).all()

        proj_budget = {row[0]: float(row[1] or 0) for row in proj_rows}
        proj_spent = {row[0]: float(row[2] or 0) for row in proj_rows}
        fin_spent = {row[0]: float(row[1] or 0) for row in fin_rows}

        totals = {}
        for d in Department.query.filter_by(company_id=company_id, is_active=True).all():
            budget = proj_budget[d.id] if d.id in proj_budget else float(d.budget or 0)
            spent = proj_spent.get(d.id, 0.0) + fin_spent.get(d.id, 0.0)
            totals[d.id] = {'budget': budget, 'spent': spent}
        return totals

    @staticmethod
    def get_department_performance(company_id):
        """LIVE department performance — SUM(project budgets), SUM(actual spend)
        and expense records are aggregated from the DB on every request.
        Utilization = spent/budget; Variance = budget - spent."""
        from database.models.department import Department

        depts = Department.query.filter_by(company_id=company_id, is_active=True).all()

        if not depts:
            return []

        live_totals = AnalyticsService._department_live_totals(company_id)

        result = []
        for d in depts:
            live = live_totals.get(d.id, {'budget': float(d.budget or 0), 'spent': 0.0})
            budget = live['budget']
            spent = live['spent']

            utilization = round((spent / budget * 100), 2) if budget > 0 else 0
            variance = round(budget - spent, 2)

            result.append({
                'id': d.id,
                'name': d.name,
                'code': d.code,
                'budget': budget,
                'spent': spent,
                'remaining': variance,
                'utilization': utilization,
                'employee_count': d.employee_count or 0,
                'color': d.color or '#2563EB',
                'variance': variance
            })

        return result