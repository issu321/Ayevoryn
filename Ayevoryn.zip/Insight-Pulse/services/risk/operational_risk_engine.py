"""
AEVORYN / INSIGHT-PULSE
OPERATIONAL RISK ENGINE (STAGE 17)
Connects the Risk Engine directly to live digital twin operational states and event streams.
Evaluates canonical metrics against operational thresholds to detect, escalate, and resolve risks with auditable evidence.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta

from database.db import db
from database.models.company import Company
from database.models.financial import FinancialRecord
from database.models.inventory import Inventory
from database.models.supplier import Supplier
from database.models.customer import Customer
from database.models.department import Department
from database.models.employee import Employee
from database.models.impact_trace import ImpactTrace, ImpactSeverity
from database.models.risk import Risk, RiskSource, RiskStatus
from services.business_state_service import BusinessStateService, ProvenanceType


@dataclass
class ThresholdEvaluation:
    """Represents the evaluation result of an operational threshold rule."""
    rule_id: str
    name: str
    category: str
    description: str
    trigger_metric: str
    threshold_value: float
    observed_value: float
    is_breached: bool
    probability: float
    impact: float
    evidence: Dict[str, Any]
    suggested_mitigation: str

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


class OperationalRiskEngine:
    """
    Evaluates real operational state of a tenant against standard enterprise risk thresholds.
    Generates verifiable evidence, severity levels, and automated recovery actions.
    """

    @classmethod
    def evaluate_all(cls, company_id: int) -> List[ThresholdEvaluation]:
        """Runs all operational threshold rules for a company."""
        evaluations: List[ThresholdEvaluation] = []

        # 1. Financial Liquidity Runway (Severe <1m & Contraction <3m)
        evaluations.extend(cls._evaluate_liquidity_runway(company_id))

        # 2. Operating Margin & Profitability Erosion
        eval_margin = cls._evaluate_operating_margin(company_id)
        if eval_margin:
            evaluations.append(eval_margin)

        # 3. Inventory Stockouts & Reorder Level Breaches
        evaluations.extend(cls._evaluate_inventory(company_id))

        # 4. Supplier Spend Concentration
        eval_supp = cls._evaluate_supplier_concentration(company_id)
        if eval_supp:
            evaluations.append(eval_supp)

        # 5. Customer Revenue Concentration
        eval_cust = cls._evaluate_customer_concentration(company_id)
        if eval_cust:
            evaluations.append(eval_cust)

        # 6. Departmental Budget Overrun
        eval_dept_overrun = cls._evaluate_department_budget_overruns(company_id)
        if eval_dept_overrun:
            evaluations.append(eval_dept_overrun)

        # 7. Unstaffed Operational Departments
        eval_unstaffed = cls._evaluate_unstaffed_departments(company_id)
        if eval_unstaffed:
            evaluations.append(eval_unstaffed)

        # 8. Systemic Digital Twin Impact Cascade
        eval_cascade = cls._evaluate_systemic_impact_cascade(company_id)
        if eval_cascade:
            evaluations.append(eval_cascade)

        return evaluations

    @classmethod
    def _evaluate_liquidity_runway(cls, company_id: int) -> List[ThresholdEvaluation]:
        """Check cash runway against 1.0m (Critical) and 3.0m (High) thresholds."""
        results = []
        cash_res = BusinessStateService.get_cash_balance(company_id)
        burn_res = BusinessStateService.get_burn_rate(company_id, period_days=30)
        runway_res = BusinessStateService.get_runway(company_id, period_days=30, burn_type='net')

        cash_val = float(cash_res.value)
        net_monthly_burn = float(burn_res.metadata.get('net_monthly_burn', 0.0))
        runway_val = runway_res.value  # float months or None (self-sustaining)

        is_burning = net_monthly_burn > 0

        # Case A: Severe Insolvent Distress (< 1.0 month)
        is_severe = is_burning and (runway_val is not None and runway_val < 1.0)
        results.append(ThresholdEvaluation(
            rule_id="LIQUIDITY_SEVERE",
            name="Severe Liquidity Distress (< 1mo Runway)",
            category="cashflow",
            description="Company is burning cash with under 30 days of operating cash reserves remaining. Solvency at risk.",
            trigger_metric="runway_months_severe",
            threshold_value=1.0,
            observed_value=round(runway_val if runway_val is not None else 999.0, 2),
            is_breached=bool(is_severe),
            probability=0.95,
            impact=0.95,
            evidence={
                "metric": "cash_runway_months",
                "observed_runway": runway_val,
                "cash_reserves": cash_val,
                "net_monthly_burn": net_monthly_burn,
                "provenance": runway_res.provenance.value if hasattr(runway_res.provenance, 'value') else str(runway_res.provenance)
            },
            suggested_mitigation="Initiate emergency cash conservation: freeze non-essential OPEX, accelerate receivables collection, and draw backup credit facilities."
        ))

        # Case B: Working Capital Contraction (< 3.0 months, when >= 1.0m)
        is_warning = is_burning and (runway_val is not None and 1.0 <= runway_val < 3.0)
        results.append(ThresholdEvaluation(
            rule_id="LIQUIDITY_WARNING",
            name="Working Capital Contraction (< 3mo Runway)",
            category="financial",
            description="Cash runway is below the 90-day liquidity buffer threshold. Working capital planning required.",
            trigger_metric="runway_months_warning",
            threshold_value=3.0,
            observed_value=round(runway_val if runway_val is not None else 999.0, 2),
            is_breached=bool(is_warning),
            probability=0.75,
            impact=0.80,
            evidence={
                "metric": "cash_runway_months",
                "observed_runway": runway_val,
                "cash_reserves": cash_val,
                "net_monthly_burn": net_monthly_burn,
                "provenance": runway_res.provenance.value if hasattr(runway_res.provenance, 'value') else str(runway_res.provenance)
            },
            suggested_mitigation="Review trailing discretionary vendor contracts and adjust 90-day cash outflow forecasts."
        ))

        return results

    @classmethod
    def _evaluate_operating_margin(cls, company_id: int) -> Optional[ThresholdEvaluation]:
        """Check operating margin against -10% threshold."""
        margin_res = BusinessStateService.get_gross_margin(company_id, period_days=30)
        margin_pct = float(margin_res.value)
        revenue_val = float(margin_res.metadata.get('revenue', 0.0))
        profit_val = float(margin_res.metadata.get('profit', 0.0))

        # Only evaluate if revenue exists
        if revenue_val <= 0:
            return None

        is_breached = margin_pct < -10.0
        return ThresholdEvaluation(
            rule_id="MARGIN_EROSION",
            name="Severe Operating Deficit (Margin < -10%)",
            category="financial",
            description="Trailing 30-day operating margin is severely negative, indicating structural cost overruns relative to sales.",
            trigger_metric="operating_margin_pct",
            threshold_value=-10.0,
            observed_value=round(margin_pct, 2),
            is_breached=is_breached,
            probability=0.70,
            impact=0.75,
            evidence={
                "operating_margin_pct": margin_pct,
                "trailing_revenue": revenue_val,
                "trailing_profit": profit_val,
                "trailing_period_days": 30
            },
            suggested_mitigation="Perform product unit-economics audit and renegotiate variable costs to restore positive margin contribution."
        )

    @classmethod
    def _evaluate_inventory(cls, company_id: int) -> List[ThresholdEvaluation]:
        """Check inventory for active stockouts (QOH <= 0) and reorder breaches."""
        results = []
        active_items = Inventory.query.filter_by(company_id=company_id, is_active=True).all()
        if not active_items:
            return results

        stockouts = [it for it in active_items if (it.quantity_on_hand or 0) <= 0]
        reorder_breaches = [
            it for it in active_items 
            if 0 < (it.quantity_on_hand or 0) <= (it.reorder_point or 0) and (it.reorder_point or 0) > 0
        ]

        # Stockouts
        is_stockout = len(stockouts) > 0
        results.append(ThresholdEvaluation(
            rule_id="INVENTORY_STOCKOUT",
            name="Critical Inventory Stockouts",
            category="inventory",
            description="One or more active SKUs have depleted inventory on hand, risking lost sales and fulfillment delays.",
            trigger_metric="inventory_stockout_count",
            threshold_value=0.0,
            observed_value=float(len(stockouts)),
            is_breached=is_stockout,
            probability=0.90,
            impact=0.70,
            evidence={
                "stockout_count": len(stockouts),
                "total_active_skus": len(active_items),
                "stockout_skus": [f"{it.sku} ({it.name})" for it in stockouts[:5]],
                "estimated_unrealized_revenue": sum(float(it.selling_price or 0.0) for it in stockouts)
            },
            suggested_mitigation="Expedite purchase orders with primary suppliers and notify sales channels of temporary backorders."
        ))

        # Reorder Level Breach
        is_reorder = len(reorder_breaches) > 0
        results.append(ThresholdEvaluation(
            rule_id="INVENTORY_REORDER_BREACH",
            name="Reorder Level Threshold Breach",
            category="inventory",
            description="Active inventory items have fallen below safety reorder levels, nearing stockout status.",
            trigger_metric="inventory_reorder_breach_count",
            threshold_value=0.0,
            observed_value=float(len(reorder_breaches)),
            is_breached=is_reorder,
            probability=0.60,
            impact=0.50,
            evidence={
                "breach_count": len(reorder_breaches),
                "breached_skus": [
                    f"{it.sku} ({it.name}, QOH: {it.quantity_on_hand}, Reorder Point: {it.reorder_point})"
                    for it in reorder_breaches[:5]
                ]
            },
            suggested_mitigation="Trigger standard replenishment orders to maintain minimum safety stock buffer."
        ))

        return results

    @classmethod
    def _evaluate_supplier_concentration(cls, company_id: int) -> Optional[ThresholdEvaluation]:
        """Check for single-supplier dependency (>60% total spend or single supplier)."""
        suppliers = Supplier.query.filter_by(company_id=company_id).all()
        if not suppliers:
            return None

        total_spend = sum(float(s.total_spend or 0.0) for s in suppliers)
        if total_spend <= 0 and len(suppliers) > 1:
            return None

        if len(suppliers) == 1 and total_spend > 0:
            return ThresholdEvaluation(
                rule_id="SUPPLIER_SINGLE_SOURCE",
                name="Single-Source Supplier Concentration",
                category="supply_chain",
                description="Entire procurement is concentrated with a single vendor, creating high vulnerability to delivery failure.",
                trigger_metric="supplier_concentration_pct",
                threshold_value=60.0,
                observed_value=100.0,
                is_breached=True,
                probability=0.70,
                impact=0.75,
                evidence={
                    "supplier_count": 1,
                    "top_supplier": suppliers[0].name,
                    "concentration_pct": 100.0,
                    "total_spend": total_spend
                },
                suggested_mitigation="Qualify secondary backup suppliers in alternate geographic regions to mitigate disruption."
            )

        if total_spend > 0:
            top_sup = max(suppliers, key=lambda s: float(s.total_spend or 0.0))
            top_spend = float(top_sup.total_spend or 0.0)
            ratio = (top_spend / total_spend) * 100.0

            is_breached = ratio > 60.0
            return ThresholdEvaluation(
                rule_id="SUPPLIER_CONCENTRATION",
                name="High Supplier Spend Concentration (>60%)",
                category="supply_chain",
                description="A single supplier commands over 60% of total company procurement spend.",
                trigger_metric="supplier_concentration_pct",
                threshold_value=60.0,
                observed_value=round(ratio, 1),
                is_breached=is_breached,
                probability=0.65,
                impact=0.70,
                evidence={
                    "supplier_count": len(suppliers),
                    "top_supplier": top_sup.name,
                    "concentration_pct": round(ratio, 1),
                    "top_supplier_spend": top_spend,
                    "total_procurement_spend": total_spend
                },
                suggested_mitigation="Distribute volume across secondary suppliers and negotiate tiered volume discounts."
            )

        return None

    @classmethod
    def _evaluate_customer_concentration(cls, company_id: int) -> Optional[ThresholdEvaluation]:
        """Check for revenue concentration in a single customer (>40% total spent)."""
        customers = Customer.query.filter_by(company_id=company_id, status='active').all()
        if len(customers) < 2:
            return None

        total_spent = sum(float(c.total_spent or 0.0) for c in customers)
        if total_spent <= 0:
            return None

        top_cust = max(customers, key=lambda c: float(c.total_spent or 0.0))
        top_spent = float(top_cust.total_spent or 0.0)
        ratio = (top_spent / total_spent) * 100.0

        is_breached = ratio > 40.0
        return ThresholdEvaluation(
            rule_id="CUSTOMER_CONCENTRATION",
            name="High Customer Revenue Concentration (>40%)",
            category="market",
            description="A single key customer accounts for over 40% of historical customer revenue, exposing business to churn shocks.",
            trigger_metric="customer_concentration_pct",
            threshold_value=40.0,
            observed_value=round(ratio, 1),
            is_breached=is_breached,
            probability=0.60,
            impact=0.70,
            evidence={
                "customer_count": len(customers),
                "top_customer": top_cust.full_name(),
                "concentration_pct": round(ratio, 1),
                "top_customer_spent": top_spent,
                "total_customer_revenue": total_spent
            },
            suggested_mitigation="Diversify marketing channels and expand pipeline into secondary industry segments."
        )

    @classmethod
    def _evaluate_department_budget_overruns(cls, company_id: int) -> Optional[ThresholdEvaluation]:
        """Check if any active department has spent more than its assigned budget."""
        depts = Department.query.filter_by(company_id=company_id, is_active=True).all()
        if not depts:
            return None

        overruns = [d for d in depts if float(d.budget or 0.0) > 0 and float(d.spent or 0.0) > float(d.budget or 0.0)]
        is_breached = len(overruns) > 0

        max_overrun_pct = 0.0
        if overruns:
            max_overrun_pct = max(((float(d.spent) - float(d.budget)) / float(d.budget)) * 100.0 for d in overruns)

        return ThresholdEvaluation(
            rule_id="DEPARTMENT_OVERRUN",
            name="Departmental Budget Overrun",
            category="operational",
            description="One or more operational departments have exceeded their authorized expenditure budget.",
            trigger_metric="department_budget_overrun_count",
            threshold_value=0.0,
            observed_value=float(len(overruns)),
            is_breached=is_breached,
            probability=0.80,
            impact=0.60,
            evidence={
                "overrun_departments_count": len(overruns),
                "max_overrun_pct": round(max_overrun_pct, 1),
                "departments": [
                    f"{d.name} (Budget: ${float(d.budget):,.0f}, Spent: ${float(d.spent):,.0f}, Variance: +{((float(d.spent)-float(d.budget))/float(d.budget))*100:.1f}%)"
                    for d in overruns
                ]
            },
            suggested_mitigation="Implement department expenditure freeze and require CFO approval for unbudgeted purchase orders."
        )

    @classmethod
    def _evaluate_unstaffed_departments(cls, company_id: int) -> Optional[ThresholdEvaluation]:
        """Check for active departments with zero active personnel."""
        depts = Department.query.filter_by(company_id=company_id, is_active=True).all()
        if not depts:
            return None

        unstaffed = [
            d for d in depts 
            if (int(d.employee_count or 0) == 0 and d.employees.count() == 0)
        ]
        is_breached = len(unstaffed) > 0

        return ThresholdEvaluation(
            rule_id="UNSTAFFED_DEPARTMENT",
            name="Unstaffed Operational Department",
            category="operational",
            description="Active business department has zero assigned personnel, creating execution bottlenecks and single points of failure.",
            trigger_metric="unstaffed_department_count",
            threshold_value=0.0,
            observed_value=float(len(unstaffed)),
            is_breached=is_breached,
            probability=0.70,
            impact=0.60,
            evidence={
                "unstaffed_count": len(unstaffed),
                "unstaffed_departments": [d.name for d in unstaffed]
            },
            suggested_mitigation="Reassign cross-functional internal staff or open headcount requisition for critical vacant roles."
        )

    @classmethod
    def _evaluate_systemic_impact_cascade(cls, company_id: int) -> Optional[ThresholdEvaluation]:
        """Check for recent CRITICAL or HIGH impact traces from digital twin mutations."""
        cutoff = datetime.utcnow() - timedelta(days=7)
        recent_trace = ImpactTrace.query.filter(
            ImpactTrace.company_id == company_id,
            ImpactTrace.severity.in_([ImpactSeverity.CRITICAL, ImpactSeverity.HIGH]),
            ImpactTrace.created_at >= cutoff
        ).order_by(ImpactTrace.created_at.desc()).first()

        is_breached = recent_trace is not None
        observed_val = float(recent_trace.affected_nodes_count) if recent_trace else 0.0

        return ThresholdEvaluation(
            rule_id="SYSTEMIC_IMPACT_CASCADE",
            name="Cross-Domain Systemic Impact Cascade",
            category="operational",
            description="A recent operational mutation triggered a high-severity causal cascade across the digital twin dependency graph.",
            trigger_metric="systemic_impact_nodes_affected",
            threshold_value=0.0,
            observed_value=observed_val,
            is_breached=is_breached,
            probability=0.85,
            impact=0.85,
            evidence={
                "trace_id": recent_trace.trace_id if recent_trace else None,
                "severity": recent_trace.severity if recent_trace else "NONE",
                "root_entity": f"{recent_trace.root_entity_type}:{recent_trace.root_entity_id}" if recent_trace else None,
                "affected_nodes_count": recent_trace.affected_nodes_count if recent_trace else 0,
                "max_depth": recent_trace.max_depth if recent_trace else 0,
                "summary": recent_trace.summary_text if recent_trace else "No critical cascades detected in trailing 7 days."
            },
            suggested_mitigation="Inspect the twin dependency blast radius and review recent mutations triggering operational warnings."
        )
