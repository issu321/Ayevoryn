"""BUSINESS AGENT SERVICE v3.1.0

Autonomous agent that aggregates company data, computes KPIs,
generates insights, alerts, recommendations, executive briefings,
and the "What Changed?" event delta feed.
Authoritative consumer of canonical business state.
"""
from database.db import db
from database.models.company import Company
from database.models.financial import FinancialRecord
from database.models.inventory import Inventory
from database.models.project import Project
from database.models.customer import Customer
from database.models.notification import Notification
from database.models.activity_log import ActivityLog
from sqlalchemy import func
from datetime import datetime, timedelta


def _pct_change(current, previous):
    if not previous:
        return 0.0
    return round((current - previous) / abs(previous) * 100, 1)


class BusinessAgent:
    """Autonomous Business Agent & Executive Command Center Engine."""

    # ─────────────────────────── STATUS ───────────────────────────

    @staticmethod
    def get_agent_status(cid):
        co = Company.query.get(cid)
        if not co:
            return None
        now = datetime.utcnow()
        lf = FinancialRecord.query.filter_by(company_id=cid).order_by(
            FinancialRecord.created_at.desc()).first()
        la = ActivityLog.query.filter_by(company_id=cid).order_by(
            ActivityLog.created_at.desc()).first()
        return {
            "agent_name": f"{co.company_name} Business Agent",
            "status": "active", "version": "3.1.0", "uptime": "99.9%",
            "last_scan": now.isoformat(),
            "data_freshness": {
                "financial_data": lf.created_at.isoformat() if lf else None,
                "last_activity": la.created_at.isoformat() if la else None},
            "active_alerts": Notification.query.filter_by(
                company_id=cid, is_read=False).count()}

    # ──────────────────────── COMMAND CENTER ──────────────────────

    @staticmethod
    def get_command_center(cid):
        """Aggregate everything the command center dashboard needs from canonical state."""
        from services.analytics_service import AnalyticsService
        summary = AnalyticsService.get_executive_summary(cid)
        now = datetime.utcnow()

        revenue_30d = float(summary.get('revenue_30d', 0.0) or 0.0)
        revenue_prev = float(summary.get('revenue_prev_30d', 0.0) or 0.0)
        revenue_growth = _pct_change(revenue_30d, revenue_prev)

        active_projects = Project.query.filter(
            Project.company_id == cid,
            Project.status.in_(['active', 'in_progress', 'planning'])
        ).count()

        inventory_value = db.session.query(
            func.coalesce(func.sum(Inventory.quantity_on_hand * Inventory.unit_cost), 0)
        ).filter(Inventory.company_id == cid, Inventory.is_active == True).scalar()

        clv = db.session.query(func.avg(Customer.lifetime_value)).filter(
            Customer.company_id == cid).scalar() or 0

        kpis = {
            'revenue_30d': round(revenue_30d, 2),
            'revenue_growth': revenue_growth,
            'profit_30d': float(summary.get('profit_30d', 0.0) or 0.0),
            'margin': float(summary.get('margin', 0.0) or 0.0),
            'total_employees': int(summary.get('total_employees', 0) or 0),
            'active_projects': active_projects,
            'total_customers': int(summary.get('total_customers', 0) or 0),
            'churn_rate': float(summary.get('churn_rate', 0.0) or 0.0),
            'inventory_value': round(float(inventory_value), 2),
            'low_stock_items': int(summary.get('low_stock', 0) or 0),
            'revenue_per_employee': round(
                revenue_30d / max(summary.get('total_employees', 1), 1), 2),
            'customer_lifetime_value': round(float(clv), 2),
            'cash_balance': float(summary.get('cash_balance', 0.0) or 0.0),
            'runway_months': summary.get('runway_months'),
            'monthly_burn': float(summary.get('monthly_burn', 0.0) or 0.0),
            'setup_progress_pct': float(summary.get('setup_progress_pct', 0.0) or 0.0),
        }

        insights = BusinessAgent._generate_insights(kpis)
        alerts = BusinessAgent._generate_alerts(kpis)
        health = BusinessAgent._health_breakdown(cid, kpis)
        what_changed = BusinessAgent.get_what_changed(cid, period='30d', limit=10)

        return {
            'generated_at': now.isoformat(),
            'kpis': kpis,
            'insights': insights,
            'alerts': alerts,
            'health': health,
            'provenance': summary.get('provenance', {}),
            'data_quality': summary.get('data_quality', {}),
            'what_changed': what_changed,
        }

    # ──────────────────────── WHAT CHANGED? ───────────────────────

    @staticmethod
    def get_what_changed(cid, period='30d', limit=20):
        """
        Computes period-over-period metric variance and returns chronological domain events.
        Powers the executive 'What Changed?' delta feed.
        """
        from database.models.business_event import BusinessEvent
        from services.analytics_service import AnalyticsService

        now = datetime.utcnow()
        if period == '24h':
            since = now - timedelta(hours=24)
            period_label = 'Past 24 Hours'
        elif period == '7d':
            since = now - timedelta(days=7)
            period_label = 'Past 7 Days'
        else:
            period = '30d'
            since = now - timedelta(days=30)
            period_label = 'Past 30 Days'

        # 1. Metric Deltas from Canonical State
        summary = AnalyticsService.get_executive_summary(cid)
        rev = float(summary.get('revenue_30d', 0.0) or 0.0)
        rev_prev = float(summary.get('revenue_prev_30d', 0.0) or 0.0)
        exp = float(summary.get('expense_30d', 0.0) or 0.0)
        exp_prev = float(summary.get('expense_prev_30d', 0.0) or 0.0)
        profit = float(summary.get('profit_30d', 0.0) or 0.0)
        profit_prev = float(summary.get('profit_prev_30d', 0.0) or 0.0)
        margin = float(summary.get('margin', 0.0) or 0.0)
        margin_prev = float(summary.get('margin_prev', 0.0) or 0.0)
        employees = int(summary.get('total_employees', 0) or 0)
        plan_emp = int(summary.get('plan_headcount', 0) or 0)
        cust = int(summary.get('total_customers', 0) or 0)
        churn = float(summary.get('churn_rate', 0.0) or 0.0)

        metric_deltas = [
            {
                'metric': 'Revenue',
                'current': rev,
                'previous': rev_prev,
                'delta': round(rev - rev_prev, 2),
                'delta_pct': _pct_change(rev, rev_prev),
                'direction': 'positive' if rev > rev_prev else ('negative' if rev < rev_prev else 'neutral'),
                'unit': 'currency',
                'label': f"{'+' if rev >= rev_prev else ''}{round(rev - rev_prev, 2):,}"
            },
            {
                'metric': 'Operating Expenses',
                'current': exp,
                'previous': exp_prev,
                'delta': round(exp - exp_prev, 2),
                'delta_pct': _pct_change(exp, exp_prev),
                'direction': 'negative' if exp > exp_prev else ('positive' if exp < exp_prev else 'neutral'),
                'unit': 'currency',
                'label': f"{'+' if exp >= exp_prev else ''}{round(exp - exp_prev, 2):,}"
            },
            {
                'metric': 'Operating Profit',
                'current': profit,
                'previous': profit_prev,
                'delta': round(profit - profit_prev, 2),
                'delta_pct': _pct_change(profit, profit_prev),
                'direction': 'positive' if profit > profit_prev else ('negative' if profit < profit_prev else 'neutral'),
                'unit': 'currency',
                'label': f"{'+' if profit >= profit_prev else ''}{round(profit - profit_prev, 2):,}"
            },
            {
                'metric': 'Operating Margin',
                'current': margin,
                'previous': margin_prev,
                'delta': round(margin - margin_prev, 1),
                'delta_pct': None,
                'direction': 'positive' if margin > margin_prev else ('negative' if margin < margin_prev else 'neutral'),
                'unit': 'pts',
                'label': f"{'+' if margin >= margin_prev else ''}{round(margin - margin_prev, 1)} pts"
            },
            {
                'metric': 'Active Headcount',
                'current': employees,
                'previous': plan_emp if plan_emp else employees,
                'delta': employees - plan_emp if plan_emp else 0,
                'delta_pct': None,
                'direction': 'neutral',
                'unit': 'count',
                'label': f"{employees} active"
            },
            {
                'metric': 'Customer Retention',
                'current': round(100.0 - churn, 1),
                'previous': 100.0,
                'delta': -round(churn, 1),
                'delta_pct': None,
                'direction': 'negative' if churn > 10 else 'positive',
                'unit': 'pct',
                'label': f"{round(100.0 - churn, 1)}% retained"
            }
        ]

        # 2. Chronological Business Events
        events_q = BusinessEvent.query.filter(
            BusinessEvent.company_id == cid,
            BusinessEvent.occurred_at >= since
        ).order_by(BusinessEvent.occurred_at.desc()).limit(limit).all()

        formatted_events = []
        for ev in events_q:
            formatted_events.append({
                'id': ev.id,
                'event_id': ev.event_id,
                'event_type': ev.event_type,
                'aggregate_type': ev.aggregate_type,
                'aggregate_id': ev.aggregate_id,
                'actor_id': ev.actor_id,
                'actor_name': ev.actor_name or 'System Engine',
                'occurred_at': ev.occurred_at.isoformat() if ev.occurred_at else None,
                'title': BusinessAgent._format_event_title(ev),
                'category': BusinessAgent._categorize_event(ev.event_type),
                'payload': ev.get_payload()
            })

        # Fallback to recent events if none in strict time window
        if not formatted_events:
            fallback_events = BusinessEvent.query.filter(
                BusinessEvent.company_id == cid
            ).order_by(BusinessEvent.occurred_at.desc()).limit(limit).all()
            for ev in fallback_events:
                formatted_events.append({
                    'id': ev.id,
                    'event_id': ev.event_id,
                    'event_type': ev.event_type,
                    'aggregate_type': ev.aggregate_type,
                    'aggregate_id': ev.aggregate_id,
                    'actor_id': ev.actor_id,
                    'actor_name': ev.actor_name or 'System Engine',
                    'occurred_at': ev.occurred_at.isoformat() if ev.occurred_at else None,
                    'title': BusinessAgent._format_event_title(ev),
                    'category': BusinessAgent._categorize_event(ev.event_type),
                    'payload': ev.get_payload()
                })

        # Executive summary statement
        if rev > rev_prev:
            summary_statement = f"Business expanded with revenue up {_pct_change(rev, rev_prev):+}% vs previous period."
        elif rev < rev_prev and rev_prev > 0:
            summary_statement = f"Revenue contracted by {abs(_pct_change(rev, rev_prev))}% vs previous period."
        else:
            summary_statement = "Operational and financial metrics are tracking steadily within baseline tolerance."

        return {
            'period': period,
            'period_label': period_label,
            'since': since.isoformat(),
            'summary_statement': summary_statement,
            'metric_deltas': metric_deltas,
            'events_count': len(formatted_events),
            'events': formatted_events
        }

    @staticmethod
    def _categorize_event(event_type):
        if not event_type:
            return 'General'
        et = event_type.lower()
        if et.startswith('financial.'):
            return 'Finance'
        elif et.startswith('employee.'):
            return 'Workforce'
        elif et.startswith('customer.'):
            return 'Customers'
        elif et.startswith('supplier.') or et.startswith('inventory.'):
            return 'Operations'
        elif et.startswith('custom_twin.') or et.startswith('custom_record.') or et.startswith('twin.'):
            return 'Digital Twin'
        elif et.startswith('simulation.') or et.startswith('scenario.'):
            return 'Scenarios'
        elif et.startswith('risk.'):
            return 'Risk & Governance'
        elif et.startswith('decision.'):
            return 'Decision Intelligence'
        elif et.startswith('competitor.') or et.startswith('market.'):
            return 'Market Intelligence'
        elif et.startswith('command_center.'):
            return 'Executive Agent'
        return 'System'

    @staticmethod
    def _format_event_title(ev):
        et = ev.event_type
        payload = ev.get_payload()
        if et == 'financial.transaction.created':
            amt = payload.get('amount')
            ttype = payload.get('transaction_type', 'Transaction')
            return f"Financial {ttype.capitalize()}: ${float(amt):,.2f}" if amt else "Financial Transaction recorded"
        elif et == 'competitor.created':
            return f"Competitor tracked: {payload.get('name', 'New Competitor')}"
        elif et == 'risk.triggered':
            return f"Risk triggered: {payload.get('risk_name', 'Operational Risk')}"
        elif et == 'decision.scan.completed':
            return "Decision Intelligence scan completed"
        elif et == 'command_center.health_checked':
            score = payload.get('health_score')
            return f"Executive Health Check executed (Score: {score}/100)" if score is not None else "Executive Health Check executed"
        elif et == 'scenario.created':
            return f"Scenario created: {payload.get('name', 'Scenario')}"
        elif et == 'scenario.merged':
            return f"Scenario merged into plan: {payload.get('scenario_name', 'Scenario')}"
        elif et == 'twin.snapshot.created':
            return f"Twin snapshot captured: {payload.get('snapshot_name', 'Snapshot')}"
        return et.replace('.', ' ').replace('_', ' ').title()

    # ──────────────────────── INNER LOGIC ─────────────────────────

    @staticmethod
    def _generate_insights(k):
        """Generates honest, explainable insights with statistical variance metrics and explicit provenance."""
        insights = []
        
        # 1. Profitability
        margin = float(k.get('margin', 0.0) or 0.0)
        if margin >= 20:
            insights.append({
                'type': 'success',
                'category': 'Profitability',
                'source': 'STATISTICAL_MODEL',
                'source_label': 'Empirical Margin Analysis',
                'confidence': None,
                'confidence_label': 'Empirical (Observed Margin >= 20%)',
                'title': f"Healthy {margin:.1f}% operating margin",
                'description': 'Operating margin is above the 20% sustainable target. Operating surplus available for reinvestment.',
                'action': 'Explore expansion simulations'
            })
        elif margin < 10:
            insights.append({
                'type': 'warning',
                'category': 'Profitability',
                'source': 'RULE',
                'source_label': 'Deterministic Margin Boundary',
                'confidence': None,
                'confidence_label': 'Deterministic (< 10% Margin Threshold)',
                'title': f"Compressed {margin:.1f}% operating margin",
                'description': 'Expenses are absorbing over 90% of revenue. Review operating expense drivers.',
                'action': 'Run expense analytics'
            })
            
        # 2. Revenue Growth
        growth = float(k.get('revenue_growth', 0.0) or 0.0)
        if growth > 5:
            insights.append({
                'type': 'success',
                'category': 'Growth',
                'source': 'STATISTICAL_MODEL',
                'source_label': 'Trailing Period Delta Model',
                'confidence': None,
                'confidence_label': f'Observed Momentum (+{growth:.1f}% MoM)',
                'title': f"Revenue up {growth:.1f}% month-over-month",
                'description': 'Positive expansion trajectory detected. Acquisition unit economics remain favorable.',
                'action': 'Open marketing simulator'
            })
        elif growth < -5:
            insights.append({
                'type': 'warning',
                'category': 'Growth',
                'source': 'STATISTICAL_MODEL',
                'source_label': 'Trailing Period Delta Model',
                'confidence': None,
                'confidence_label': f'Observed Contraction ({growth:.1f}% MoM)',
                'title': f"Revenue down {abs(growth):.1f}% month-over-month",
                'description': 'Sales contraction detected across trailing 30 days. Review conversion and customer churn.',
                'action': 'Check market intelligence'
            })
            
        # 3. Customer Churn
        churn = float(k.get('churn_rate', 0.0) or 0.0)
        if churn > 10:
            insights.append({
                'type': 'warning',
                'category': 'Customers',
                'source': 'RULE',
                'source_label': 'Deterministic Churn Boundary',
                'confidence': None,
                'confidence_label': f'Deterministic (Churn {churn:.1f}% > 10%)',
                'title': f"Elevated Customer Churn ({churn:.1f}%)",
                'description': 'Customer attrition exceeds the 10% tolerance boundary. Early-warning intervention recommended.',
                'action': 'Open customer simulator'
            })
            
        # 4. Workforce Productivity
        rpe = float(k.get('revenue_per_employee', 0.0) or 0.0)
        if 0 < rpe < 5000:
            insights.append({
                'type': 'info',
                'category': 'Operations',
                'source': 'STATISTICAL_MODEL',
                'source_label': 'Workforce Ratio Assessment',
                'confidence': None,
                'confidence_label': f'Productivity Metric (${rpe:,.0f}/employee)',
                'title': f"Revenue per employee is below median (${rpe:,.0f})",
                'description': 'Output per employee indicates capacity underutilization or high manual overhead.',
                'action': 'Review employee analytics'
            })
            
        # 5. Baseline stability fallback
        if not insights:
            insights.append({
                'type': 'success',
                'category': 'Overall',
                'source': 'RULE',
                'source_label': 'Deterministic Parameter Check',
                'confidence': None,
                'confidence_label': 'Verified Baseline (Zero Breaches)',
                'title': 'All monitored dimensions within target bands',
                'description': 'No threshold violations detected across revenue growth, operating margins, or customer retention.',
                'action': 'Continue monitoring'
            })
            
        return insights

    @staticmethod
    def _generate_alerts(k):
        alerts = []
        if k['low_stock_items'] > 0:
            alerts.append({
                'severity': 'warning' if k['low_stock_items'] < 5 else 'critical',
                'title': f"{k['low_stock_items']} item(s) below reorder point",
                'message': 'Inventory replenishment needed to avoid stockouts.',
                'action': 'Review inventory'})
        if k['churn_rate'] > 10:
            alerts.append({
                'severity': 'critical' if k['churn_rate'] > 20 else 'warning',
                'title': f"High churn rate: {k['churn_rate']}%",
                'message': 'Customer losses are accelerating beyond safe thresholds.',
                'action': 'Launch retention plan'})
        if k['margin'] < 10:
            alerts.append({
                'severity': 'warning',
                'title': f"Margin compressed to {k['margin']}%",
                'message': 'Cost structure needs review to protect profitability.',
                'action': 'Analyze expenses'})
        if k.get('runway_months') is not None and 0 < k.get('runway_months', 99) < 3:
            alerts.append({
                'severity': 'critical',
                'title': f"Cash runway critical: {k['runway_months']} months",
                'message': 'Immediate liquidity review required to avert cash exhaustion.',
                'action': 'View financial runway'})
        if k['active_projects'] == 0:
            alerts.append({
                'severity': 'info',
                'title': 'No active projects',
                'message': 'No strategic initiatives are currently in flight.',
                'action': 'Create a project'})
        return alerts

    @staticmethod
    def _health_breakdown(cid, k):
        profitability = min(30, max(0, round(k['margin'] / 25 * 30)))
        customers = min(25, max(0, round((100 - min(k['churn_rate'], 100)) / 100 * 25)))
        total_skus = Inventory.query.filter_by(company_id=cid, is_active=True).count()
        if total_skus:
            ops = min(25, max(0, round(25 - (k['low_stock_items'] / total_skus * 25))))
        else:
            ops = 20
        stability = 20
        try:
            from services.risk_service import RiskService
            risk = RiskService.get_risk_summary(cid)
            stability = min(20, max(0, round((100 - risk.get('overall_score', 50)) / 100 * 20)))
        except Exception:
            pass
        total = profitability + customers + ops + stability
        rating = ('Excellent' if total >= 80 else
                  'Good' if total >= 60 else
                  'Fair' if total >= 40 else 'At Risk')
        return {
            'total': total,
            'rating': rating,
            'components': {
                'profitability': {'label': 'Profitability', 'score': profitability, 'max': 30},
                'customers': {'label': 'Customers', 'score': customers, 'max': 25},
                'operations': {'label': 'Operations', 'score': ops, 'max': 25},
                'stability': {'label': 'Stability', 'score': stability, 'max': 20},
            },
        }

    # ─────────────────────── RECOMMENDATIONS ──────────────────────

    @staticmethod
    def get_recommendations(cid):
        cc = BusinessAgent.get_command_center(cid)
        k = cc['kpis']
        recs = []

        if k['churn_rate'] > 10:
            recs.append({
                'category': 'Customer Success',
                'expected_impact': f"-{round(k['churn_rate'] / 2, 1)}% churn",
                'title': 'Launch a customer retention program',
                'description': f"Churn is {k['churn_rate']}%. Targeted outreach and loyalty incentives can recover at-risk accounts.",
                'action': 'Open customer simulator'})
        if k['margin'] < 15:
            recs.append({
                'category': 'Finance',
                'expected_impact': f"+{round(20 - k['margin'], 1)} pts margin",
                'title': 'Optimize expense structure',
                'description': f"Margin is {k['margin']}%. Renegotiate supplier terms and trim non-critical spend.",
                'action': 'Run expense analytics'})
        if k['low_stock_items'] > 0:
            recs.append({
                'category': 'Supply Chain', 'expected_impact': 'Avoided stockouts',
                'title': f"Restock {k['low_stock_items']} low-stock item(s)",
                'description': 'Several SKUs are below reorder point and risk losing sales.',
                'action': 'Open supply chain simulator'})
        if k['revenue_growth'] < 0:
            recs.append({
                'category': 'Marketing',
                'expected_impact': f"+{abs(k['revenue_growth'])}% revenue",
                'title': 'Boost demand generation',
                'description': 'Revenue is declining. A targeted campaign can reverse the trend.',
                'action': 'Open marketing simulator'})
        if 0 < k['revenue_per_employee'] < 8000:
            recs.append({
                'category': 'Operations', 'expected_impact': '+10% productivity',
                'title': 'Improve workforce productivity',
                'description': f"Revenue per employee is {k['revenue_per_employee']}. Automation and training could lift output.",
                'action': 'Open employee simulator'})
        if not recs:
            recs.append({
                'category': 'Growth', 'expected_impact': '+15% revenue',
                'title': 'Invest surplus into expansion',
                'description': 'Metrics are healthy. Consider new markets, products or capacity investment.',
                'action': 'Open expansion simulation'})
        return recs

    # ──────────────────── EXECUTIVE BRIEFING ──────────────────────

    @staticmethod
    def generate_executive_briefing(cid, period='daily'):
        cc = BusinessAgent.get_command_center(cid)
        k = cc['kpis']
        days = {'daily': 1, 'weekly': 7, 'monthly': 30}.get(period, 1)
        since = datetime.utcnow() - timedelta(days=days)
        activities = ActivityLog.query.filter(
            ActivityLog.company_id == cid,
            ActivityLog.created_at >= since
        ).order_by(ActivityLog.created_at.desc()).limit(8).all()

        headline = (f"Business is {'growing' if k['revenue_growth'] >= 0 else 'contracting'} "
                    f"— health {cc['health']['total']}/100 ({cc['health']['rating']})")
        return {
            'period': period,
            'generated_at': datetime.utcnow().isoformat(),
            'headline': headline,
            'summary': (
                f"Revenue {k['revenue_30d']:,.0f} ({k['revenue_growth']:+}%), "
                f"margin {k['margin']}%, churn {k['churn_rate']}%. "
                f"{len(cc['alerts'])} active alert(s), "
                f"{k['active_projects']} active project(s)."),
            'highlights': [i['title'] for i in cc['insights'][:4]],
            'alerts': cc['alerts'],
            'health': cc['health'],
            'kpis': k,
            'recent_activity': [a.description for a in activities],
            'what_changed': cc.get('what_changed'),
        }

    # ─────────────────────── HEALTH CHECK ─────────────────────────

    @staticmethod
    def run_health_check(cid, user_id):
        """Run a comprehensive check and create notifications for findings."""
        from services.events import EventBus, DomainEvent, EventTypes
        from database.models.activity_log import ActivityLog

        cc = BusinessAgent.get_command_center(cid)
        k = cc['kpis']
        created = []

        findings = []
        if k['low_stock_items'] > 0:
            findings.append((
                'Low stock warning',
                f"{k['low_stock_items']} item(s) below reorder point.",
                'warning', 'inventory'))
        if k['churn_rate'] > 10:
            findings.append((
                'High customer churn',
                f"Churn rate is {k['churn_rate']}%, above the 10% threshold.",
                'critical', 'customer'))
        if k['margin'] < 10:
            findings.append((
                'Margin pressure',
                f"Profit margin is {k['margin']}%, below the 10% threshold.",
                'warning', 'financial'))
        if k['revenue_growth'] < -5:
            findings.append((
                'Revenue decline',
                f"Revenue changed {k['revenue_growth']}% vs previous period.",
                'critical', 'analytics'))
        if k.get('runway_months') is not None and 0 < k.get('runway_months', 99) < 3:
            findings.append((
                'Critical Runway Warning',
                f"Current cash runway is {k['runway_months']} months under current net burn.",
                'critical', 'financial'))
        if not findings:
            findings.append((
                'Health check passed',
                f"All systems normal — health score {cc['health']['total']}/100.",
                'success', 'system'))

        for title, message, ntype, module in findings:
            n = Notification(
                company_id=cid, user_id=user_id, title=title, message=message,
                notification_type=ntype, module=module, is_read=False)
            db.session.add(n)
            created.append(n)

        # Persist health score on the company
        company = Company.query.get(cid)
        if company:
            company.health_score = cc['health']['total']

        # Log to ActivityLog
        act = ActivityLog(
            company_id=cid,
            user_id=user_id,
            activity_type='command_center.health_check',
            description=f"Executive Health Check executed: score {cc['health']['total']}/100 ({cc['health']['rating']})",
            module='command_center',
            icon='activity'
        )
        db.session.add(act)
        db.session.commit()

        # Publish EventBus domain event
        try:
            EventBus.publish(DomainEvent.create(
                company_id=cid,
                event_type=EventTypes.COMMAND_CENTER_HEALTH_CHECKED,
                aggregate_type='company',
                aggregate_id=str(cid),
                actor_id=user_id,
                payload={
                    'health_score': cc['health']['total'],
                    'rating': cc['health']['rating'],
                    'findings_count': len(findings)
                }
            ))
        except Exception:
            pass

        return created

    @staticmethod
    def mark_notifications_read(cid, user_id):
        """Mark notifications as read and emit domain event."""
        from services.events import EventBus, DomainEvent, EventTypes

        updated_count = Notification.query.filter_by(
            company_id=cid,
            user_id=user_id,
            is_read=False
        ).update({'is_read': True})

        db.session.commit()

        if updated_count > 0:
            try:
                EventBus.publish(DomainEvent.create(
                    company_id=cid,
                    event_type=EventTypes.NOTIFICATIONS_MARKED_READ,
                    aggregate_type='notification',
                    aggregate_id=str(user_id),
                    actor_id=user_id,
                    payload={'notifications_marked_read': updated_count}
                ))
            except Exception:
                pass

        return updated_count
