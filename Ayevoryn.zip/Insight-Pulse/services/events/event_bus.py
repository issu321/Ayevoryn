"""
EVENT BUS - In-Process Domain Event Dispatcher & Persistence Orchestrator.

Provides:
- Standardized DomainEvent dataclass
- Synchronous and asynchronous event dispatching
- Append-only persistence into `business_events`
- Synchronization with `activity_logs` (bringing legacy ActivityLog to life)
- Correlation ID tracking across chained mutations
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Any, List, Callable, Optional, Set
import logging
import uuid
from database.db import db
from database.models.business_event import BusinessEvent
from database.models.activity_log import ActivityLog

logger = logging.getLogger(__name__)


@dataclass
class DomainEvent:
    event_type: str
    company_id: int
    aggregate_type: str
    aggregate_id: Optional[str] = None
    actor_id: Optional[int] = None
    actor_name: Optional[str] = None
    correlation_id: Optional[str] = None
    causation_id: Optional[str] = None
    payload: Dict[str, Any] = field(default_factory=dict)
    occurred_at: datetime = field(default_factory=datetime.utcnow)
    event_id: str = field(default_factory=lambda: str(uuid.uuid4()))

    @classmethod
    def create(
        cls,
        event_type: str,
        company_id: int,
        aggregate_type: str,
        aggregate_id: Optional[Any] = None,
        actor_id: Optional[int] = None,
        actor_name: Optional[str] = None,
        correlation_id: Optional[str] = None,
        causation_id: Optional[str] = None,
        payload: Optional[Dict[str, Any]] = None,
        occurred_at: Optional[datetime] = None
    ) -> 'DomainEvent':
        """Convenience factory ensuring non-null UUIDs and timestamps."""
        return cls(
            event_type=event_type,
            company_id=int(company_id),
            aggregate_type=str(aggregate_type),
            aggregate_id=str(aggregate_id) if aggregate_id is not None else None,
            actor_id=int(actor_id) if actor_id is not None else None,
            actor_name=str(actor_name) if actor_name else 'System',
            correlation_id=str(correlation_id) if correlation_id else str(uuid.uuid4()),
            causation_id=str(causation_id) if causation_id else None,
            payload=payload or {},
            occurred_at=occurred_at or datetime.utcnow(),
            event_id=str(uuid.uuid4())
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            'event_id': self.event_id,
            'event_type': self.event_type,
            'company_id': self.company_id,
            'aggregate_type': self.aggregate_type,
            'aggregate_id': self.aggregate_id,
            'actor_id': self.actor_id,
            'actor_name': self.actor_name,
            'correlation_id': self.correlation_id,
            'causation_id': self.causation_id,
            'payload': self.payload,
            'occurred_at': self.occurred_at.isoformat() if self.occurred_at else None
        }


def _format_event_description(event: DomainEvent) -> str:
    """Generate human-readable summary for activity logs."""
    actor = event.actor_name or 'System'
    parts = event.event_type.split('.')
    action = parts[-1] if parts else 'mutated'
    target = event.aggregate_type.replace('_', ' ')
    
    if event.payload and 'name' in event.payload:
        target_name = f" '{event.payload['name']}'"
    elif event.payload and 'description' in event.payload:
        target_name = f" '{event.payload['description']}'"
    elif event.aggregate_id:
        target_name = f" #{event.aggregate_id}"
    else:
        target_name = ""

    return f"{actor} {action} {target}{target_name}"


def _get_event_icon(aggregate_type: str) -> str:
    """Map aggregate type to UI icon."""
    mapping = {
        'financial_record': 'dollar-sign',
        'employee': 'users',
        'customer': 'user-check',
        'department': 'building',
        'supplier': 'truck',
        'inventory': 'package',
        'custom_twin': 'cube',
        'custom_record': 'table',
        'simulation': 'play-circle',
        'company': 'briefcase'
    }
    return mapping.get(aggregate_type, 'activity')


class EventBus:
    """Central domain event dispatcher."""
    
    _subscribers: Dict[str, List[Callable[[DomainEvent], None]]] = {}

    @classmethod
    def subscribe(cls, event_type: str, handler: Callable[[DomainEvent], None]) -> None:
        """Register an event listener for a specific event type or wildcard ('*')."""
        if event_type not in cls._subscribers:
            cls._subscribers[event_type] = []
        if handler not in cls._subscribers[event_type]:
            cls._subscribers[event_type].append(handler)

    @classmethod
    def unsubscribe(cls, event_type: str, handler: Callable[[DomainEvent], None]) -> None:
        """Unregister an event listener."""
        if event_type in cls._subscribers and handler in cls._subscribers[event_type]:
            cls._subscribers[event_type].remove(handler)

    @classmethod
    def clear_subscribers(cls) -> None:
        """Clear all subscribers (primarily used for test isolation)."""
        cls._subscribers.clear()

    @classmethod
    def publish(cls, event: Any, commit: bool = True, **kwargs) -> BusinessEvent:
        """
        Publishes and records a domain event:
        1. Persists immutable BusinessEvent row
        2. Populates corresponding ActivityLog entry
        3. Invokes registered listeners safely
        Supports both DomainEvent instances and event_type strings with kwargs.
        """
        if isinstance(event, str):
            agg_type = kwargs.get('aggregate_type') or kwargs.get('entity_type') or 'system'
            agg_id = kwargs.get('aggregate_id') or kwargs.get('entity_id')
            actor_id = kwargs.get('actor_id')
            actor_name = kwargs.get('actor_name')
            company_id = kwargs.get('company_id', 1)
            payload = kwargs.get('payload', {})
            event = DomainEvent.create(
                event_type=event,
                company_id=company_id,
                aggregate_type=agg_type,
                aggregate_id=agg_id,
                actor_id=actor_id,
                actor_name=actor_name,
                payload=payload
            )
        try:
            # 1. Persist BusinessEvent
            biz_event = BusinessEvent(
                event_id=event.event_id,
                company_id=event.company_id,
                event_type=event.event_type,
                aggregate_type=event.aggregate_type,
                aggregate_id=event.aggregate_id,
                actor_id=event.actor_id,
                actor_name=event.actor_name,
                correlation_id=event.correlation_id,
                causation_id=event.causation_id,
                occurred_at=event.occurred_at,
                recorded_at=datetime.utcnow()
            )
            biz_event.set_payload(event.payload or {})
            db.session.add(biz_event)

            # 2. Populate ActivityLog (resolving dead ActivityLog finding)
            activity = ActivityLog(
                company_id=event.company_id,
                user_id=event.actor_id,
                user_name=event.actor_name or 'System',
                activity_type=event.event_type,
                description=_format_event_description(event),
                module=event.aggregate_type,
                icon=_get_event_icon(event.aggregate_type),
                created_at=event.occurred_at
            )
            db.session.add(activity)

            if commit:
                db.session.commit()
            else:
                db.session.flush()

        except Exception as persist_error:
            db.session.rollback()
            logger.error(f"Failed to persist BusinessEvent: {persist_error}", exc_info=True)
            raise

        # 3. Dispatch to registered listeners
        cls._dispatch_listeners(event)

        return biz_event

    @classmethod
    def _dispatch_listeners(cls, event: DomainEvent) -> None:
        """Dispatch event to exact match, wildcard, and category listeners."""
        handlers: Set[Callable[[DomainEvent], None]] = set()

        # Exact match
        if event.event_type in cls._subscribers:
            handlers.update(cls._subscribers[event.event_type])

        # Global wildcard '*'
        if '*' in cls._subscribers:
            handlers.update(cls._subscribers['*'])

        # Category prefix wildcard (e.g., 'financial.*')
        parts = event.event_type.split('.')
        if len(parts) > 1:
            category_pattern = f"{parts[0]}.*"
            if category_pattern in cls._subscribers:
                handlers.update(cls._subscribers[category_pattern])

        for handler in handlers:
            try:
                handler(event)
            except Exception as listener_error:
                logger.error(
                    f"Error in event listener {getattr(handler, '__name__', str(handler))} "
                    f"for event {event.event_type}: {listener_error}",
                    exc_info=True
                )

    @classmethod
    def get_recent_events(
        cls,
        company_id: int,
        limit: int = 50,
        event_type: Optional[str] = None,
        aggregate_type: Optional[str] = None
    ) -> List[Dict[str, Any]]:
        """Retrieve recent domain events for a company."""
        query = BusinessEvent.query.filter_by(company_id=company_id)
        if event_type:
            query = query.filter_by(event_type=event_type)
        if aggregate_type:
            query = query.filter_by(aggregate_type=aggregate_type)

        events = query.order_by(BusinessEvent.occurred_at.desc()).limit(limit).all()
        return [e.to_dict() for e in events]

    @classmethod
    def get_event_stream(
        cls,
        company_id: int,
        since: Optional[datetime] = None,
        until: Optional[datetime] = None
    ) -> List[Dict[str, Any]]:
        """Retrieve chronological event stream for temporal reconstruction."""
        query = BusinessEvent.query.filter_by(company_id=company_id)
        if since:
            query = query.filter(BusinessEvent.occurred_at >= since)
        if until:
            query = query.filter(BusinessEvent.occurred_at <= until)

        events = query.order_by(BusinessEvent.occurred_at.asc()).all()
        return [e.to_dict() for e in events]


# Shorthand helper functions
def publish_event(event: DomainEvent, commit: bool = True) -> BusinessEvent:
    return EventBus.publish(event, commit=commit)


def subscribe(event_type: str, handler: Callable[[DomainEvent], None]) -> None:
    EventBus.subscribe(event_type, handler)
