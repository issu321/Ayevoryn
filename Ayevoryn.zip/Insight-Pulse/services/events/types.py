"""
DOMAIN EVENT TYPES - Canonical Enumeration of Enterprise Business Events.
"""

class EventTypes:
    # Financial Ledger Events
    FINANCIAL_TRANSACTION_CREATED = "financial.transaction.created"
    FINANCIAL_TRANSACTION_UPDATED = "financial.transaction.updated"
    FINANCIAL_TRANSACTION_DELETED = "financial.transaction.deleted"
    FINANCIAL_ACCOUNT_CREATED = "financial.account.created"
    FINANCIAL_ACCOUNT_UPDATED = "financial.account.updated"

    # Human Resources / Employee Events
    EMPLOYEE_CREATED = "employee.created"
    EMPLOYEE_UPDATED = "employee.updated"
    EMPLOYEE_DELETED = "employee.deleted"

    # Customer Events
    CUSTOMER_CREATED = "customer.created"
    CUSTOMER_UPDATED = "customer.updated"
    CUSTOMER_DELETED = "customer.deleted"

    # Supplier & Procurement Events
    SUPPLIER_CREATED = "supplier.created"
    SUPPLIER_UPDATED = "supplier.updated"
    SUPPLIER_DELETED = "supplier.deleted"

    # Inventory & Supply Chain Events
    INVENTORY_ITEM_CREATED = "inventory.item.created"
    INVENTORY_ITEM_UPDATED = "inventory.item.updated"
    INVENTORY_ITEM_DELETED = "inventory.item.deleted"
    INVENTORY_MOVEMENT_RECORDED = "inventory.movement.recorded"

    # Department & Organization Events
    DEPARTMENT_CREATED = "department.created"
    DEPARTMENT_UPDATED = "department.updated"
    DEPARTMENT_DELETED = "department.deleted"
    DEPARTMENT_ALL_DELETED = "department.all_deleted"

    # Custom Twin 2.0 Events
    CUSTOM_TWIN_CREATED = "custom_twin.created"
    CUSTOM_TWIN_UPDATED = "custom_twin.updated"
    CUSTOM_TWIN_DELETED = "custom_twin.deleted"
    CUSTOM_RECORD_CREATED = "custom_record.created"
    CUSTOM_RECORD_UPDATED = "custom_record.updated"
    CUSTOM_RECORD_DELETED = "custom_record.deleted"
    CUSTOM_RECORD_ALL_DELETED = "custom_record.all_deleted"

    # Simulation & Scenario Events
    SIMULATION_EXECUTED = "simulation.executed"
    SCENARIO_CREATED = "scenario.created"
    SCENARIO_BRANCHED = "scenario.branched"
    SCENARIO_EVALUATED = "scenario.evaluated"
    SCENARIO_MERGED = "scenario.merged"
    SCENARIO_DELETED = "scenario.deleted"

    # Twin Dependency Graph Events
    TWIN_DEPENDENCY_CREATED = "twin.dependency.created"
    TWIN_DEPENDENCY_UPDATED = "twin.dependency.updated"
    TWIN_DEPENDENCY_DELETED = "twin.dependency.deleted"

    # Forecasting Integrity Events
    FORECAST_GENERATED = "forecast.generated"
    FORECAST_EVALUATED = "forecast.evaluated"
    FORECAST_DELETED = "forecast.deleted"

    # Impact Propagation & Risk Events
    TWIN_IMPACT_PROPAGATED = "twin.impact.propagated"
    TWIN_IMPACT_RISK_TRIGGERED = "twin.impact.risk_triggered"
    RISK_ASSESSMENT_COMPLETED = "risk.assessment.completed"
    RISK_TRIGGERED = "risk.triggered"
    RISK_ESCALATED = "risk.escalated"
    RISK_RESOLVED = "risk.resolved"
    RISK_MUTATED = "risk.mutated"

    # Temporal Digital Twin & Snapshot Events
    TWIN_SNAPSHOT_CREATED = "twin.snapshot.created"
    TWIN_SNAPSHOT_DELETED = "twin.snapshot.deleted"

    # Decision Intelligence & Honest Insights Events
    DECISION_SCAN_COMPLETED = "decision.scan.completed"
    DECISION_INSIGHT_TRIGGERED = "decision.insight.triggered"

    # Market & Competition Events
    COMPETITOR_CREATED = "competitor.created"
    COMPETITOR_UPDATED = "competitor.updated"
    COMPETITOR_DELETED = "competitor.deleted"
    COMPETITOR_TEMPLATES_LOADED = "competitor.templates_loaded"
    MARKET_DATA_UPDATED = "market.data_updated"
    MARKET_BENCHMARK_LOADED = "market.benchmark_loaded"

    # Company & System Events
    COMPANY_CREATED = "company.created"
    COMPANY_UPDATED = "company.updated"
    USER_AUTHENTICATED = "user.authenticated"
    USER_ROLE_CHANGED = "user.role_changed"

    # Executive Command Center Events
    COMMAND_CENTER_HEALTH_CHECKED = "command_center.health_checked"
    NOTIFICATIONS_MARKED_READ = "command_center.notifications_marked_read"

    # Data Quality & Lineage Events
    DATA_QUALITY_EVALUATED = "data_quality.evaluated"
    DATA_ANOMALY_DETECTED = "data_quality.anomaly_detected"

    # Webhook & API Key Events
    WEBHOOK_SUBSCRIPTION_CREATED = "webhook.subscription.created"
    WEBHOOK_SUBSCRIPTION_UPDATED = "webhook.subscription.updated"
    WEBHOOK_SUBSCRIPTION_DELETED = "webhook.subscription.deleted"
    WEBHOOK_DISPATCHED = "webhook.dispatched"
    WEBHOOK_FAILED = "webhook.failed"
    API_KEY_CREATED = "api_key.created"
    API_KEY_REVOKED = "api_key.revoked"

    # Background Job Events
    JOB_ENQUEUED = "job.enqueued"
    JOB_STARTED = "job.started"
    JOB_PROGRESS = "job.progress"
    JOB_COMPLETED = "job.completed"
    JOB_FAILED = "job.failed"
    JOB_CANCELLED = "job.cancelled"

