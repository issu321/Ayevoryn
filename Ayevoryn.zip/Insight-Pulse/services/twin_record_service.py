"""
Twin Record Service — Enterprise Digital Twin Record Processing & Standardization
Handles robust multi-format date parsing, decimal amounts, reference number preservation,
flexible entity resolution (departments & accounts), and atomic upsert operations.
"""

import io
import re
from datetime import datetime, date
from typing import Optional, Tuple, Dict, Any, List

from database import db
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.department import Department
from services.company_service import CompanyService


class TwinRecordService:
    """Standardized service for ingestion, validation, and persistence across Digital Twins."""

    @staticmethod
    def parse_flexible_date(
        val: Any,
        allow_empty: bool = False,
        default_date: Optional[date] = None
    ) -> Tuple[Optional[date], Optional[str]]:
        """
        Parses dates from various input formats without silent failures:
        - datetime.date or datetime.datetime objects
        - ISO format: YYYY-MM-DD, YYYY/MM/DD
        - European/Standard: DD/MM/YYYY, DD-MM-YYYY, DD.MM.YYYY
        - US format: MM/DD/YYYY, MM-DD-YYYY
        - Excel serial numbers: integer/float (e.g. 45000 - 47000)
        - Timestamp strings
        Returns (parsed_date, error_message).
        """
        if val is None or (isinstance(val, str) and not val.strip()):
            if allow_empty:
                return default_date, None
            return None, "Transaction date is required and cannot be empty."

        # Already a date or datetime
        if isinstance(val, datetime):
            return val.date(), None
        if isinstance(val, date):
            return val, None

        # Excel numeric serial
        if isinstance(val, (int, float)):
            try:
                # Valid Excel serial range roughly between 1980 (29221) and 2100 (73415)
                if 20000 <= float(val) <= 90000:
                    from openpyxl.utils.datetime import from_excel
                    dt = from_excel(float(val))
                    return dt.date(), None
            except Exception:
                pass

        val_str = str(val).strip()

        # Handle string that might be an Excel numeric serial
        if re.match(r'^\d+(\.\d+)?$', val_str):
            try:
                num = float(val_str)
                if 20000 <= num <= 90000:
                    from openpyxl.utils.datetime import from_excel
                    dt = from_excel(num)
                    return dt.date(), None
            except Exception:
                pass

        # Try standard datetime strings (strip time component if present)
        clean_str = val_str
        if ' ' in clean_str:
            clean_str = clean_str.split(' ')[0]
        if 'T' in clean_str:
            clean_str = clean_str.split('T')[0]

        formats_to_try = [
            '%Y-%m-%d',
            '%Y/%m/%d',
            '%d/%m/%Y',
            '%d-%m-%Y',
            '%d.%m.%Y',
            '%m/%d/%Y',
            '%m-%d-%Y',
            '%b %d, %Y',
            '%d %b %Y',
            '%B %d, %Y',
        ]

        for fmt in formats_to_try:
            try:
                dt = datetime.strptime(clean_str, fmt)
                return dt.date(), None
            except (ValueError, TypeError):
                continue

        return None, f"Invalid date '{val_str}'. Expected formats: YYYY-MM-DD, DD/MM/YYYY, or MM/DD/YYYY."

    @staticmethod
    def validate_amount(
        val: Any,
        min_val: float = 0.01,
        allow_zero: bool = False,
        allow_negative: bool = False
    ) -> Tuple[Optional[float], Optional[str]]:
        """
        Parses amounts safely:
        Strips currency signs ($ ₹ € £ ¥), thousand commas, whitespace.
        Returns (amount_float, error_message).
        """
        if val is None or (isinstance(val, str) and not val.strip()):
            return None, "Amount is required."

        if isinstance(val, (int, float)):
            f_val = float(val)
        else:
            clean = re.sub(r'[^\d.-]', '', str(val).strip())
            try:
                f_val = float(clean)
            except (ValueError, TypeError):
                return None, f"Invalid numeric amount '{val}'."

        if allow_negative:
            return round(f_val, 2), None
        if allow_zero and f_val >= 0:
            return round(f_val, 2), None
        if f_val < min_val:
            return None, f"Amount must be at least {min_val:,.2f}."

        return round(f_val, 2), None

    @staticmethod
    def clean_reference(val: Any, max_length: int = 120) -> str:
        """Cleans and standardizes reference numbers without truncating necessary data."""
        if val is None:
            return ''
        ref = str(val).strip()
        # Remove trailing .0 from Excel float numbers read as string (e.g. 10023.0 -> 10023, INV-1002.0 -> INV-1002)
        ref = re.sub(r'\.0$', '', ref)
        return ref[:max_length]

    @staticmethod
    def resolve_department(company_id: int, identifier: Any) -> Optional[int]:
        """Resolves department ID by ID, exact name, or code."""
        if identifier is None:
            return None
        val_str = str(identifier).strip()
        if not val_str:
            return None

        # Check direct integer ID
        if val_str.isdigit():
            dept = Department.query.filter_by(company_id=company_id, id=int(val_str)).first()
            if dept:
                return dept.id

        # Case-insensitive name match
        dept = Department.query.filter(
            Department.company_id == company_id,
            db.func.lower(Department.name) == val_str.lower()
        ).first()
        if dept:
            return dept.id

        # Case-insensitive code match
        dept = Department.query.filter(
            Department.company_id == company_id,
            db.func.lower(Department.code) == val_str.lower()
        ).first()
        if dept:
            return dept.id

        # Fuzzy substring match
        depts = Department.query.filter_by(company_id=company_id).all()
        for d in depts:
            if val_str.lower() in d.name.lower() or d.name.lower() in val_str.lower():
                return d.id

        return None

    @staticmethod
    def resolve_account(company_id: int, identifier: Any) -> Optional[int]:
        """Resolves financial account ID by ID, name, or account category."""
        if identifier is None:
            return None
        val_str = str(identifier).strip()
        if not val_str:
            return None

        # Ensure company accounts exist
        CompanyService.ensure_company_financial_accounts(company_id)

        if val_str.isdigit():
            acc = FinancialAccount.query.filter_by(company_id=company_id, id=int(val_str)).first()
            if acc:
                return acc.id

        # Match exact name
        acc = FinancialAccount.query.filter(
            FinancialAccount.company_id == company_id,
            db.func.lower(FinancialAccount.account_name) == val_str.lower()
        ).first()
        if acc:
            return acc.id

        # Substring / partial match on account name
        accounts = FinancialAccount.query.filter_by(company_id=company_id).all()
        for a in accounts:
            if val_str.lower() in a.account_name.lower() or a.account_name.lower() in val_str.lower():
                return a.id

        return None

    @classmethod
    def process_financial_records_import(
        cls,
        company_id: int,
        rows: List[Dict[str, Any]],
        transaction_type: str = 'revenue',
        mode: str = 'upsert'
    ) -> Dict[str, Any]:
        """
        Atomically processes and imports revenue or expense records.
        Modes:
        - 'upsert': If reference_number matches, updates existing row; otherwise inserts new.
        - 'add': Inserts new rows; rejects/skips existing reference_numbers.
        - 'update': Only updates existing reference_numbers; ignores rows with unknown reference.
        """
        # Ensure company accounts exist
        CompanyService.ensure_company_financial_accounts(company_id)

        added_count = 0
        updated_count = 0
        skipped_count = 0
        errors = []

        # Pre-cache departments and accounts for high throughput
        depts_cache = {d.name.lower(): d.id for d in Department.query.filter_by(company_id=company_id).all()}
        accs_cache = {a.account_name.lower(): a.id for a in FinancialAccount.query.filter_by(company_id=company_id).all()}

        # Map existing records by reference_number
        existing_by_ref = {}
        all_existing = FinancialRecord.query.filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == transaction_type,
            FinancialRecord.reference_number != None,
            FinancialRecord.reference_number != ''
        ).all()
        for rec in all_existing:
            if rec.reference_number:
                existing_by_ref[rec.reference_number.strip().lower()] = rec

        for idx, row in enumerate(rows, start=2):
            raw_date = row.get('transaction_date') or row.get('date') or row.get('tx_date')
            tx_date, date_err = cls.parse_flexible_date(raw_date)
            if date_err:
                errors.append(f"Row {idx}: {date_err}")
                continue

            raw_amount = row.get('amount') or row.get('value') or row.get('total')
            amount, amt_err = cls.validate_amount(raw_amount)
            if amt_err:
                errors.append(f"Row {idx}: {amt_err}")
                continue

            ref = cls.clean_reference(
                row.get('reference_number') or row.get('ref_no') or row.get('invoice_no') or row.get('reference') or row.get('ref') or ''
            )

            # Department resolution
            dept_id = None
            dept_raw = row.get('department') or row.get('dept') or row.get('department_name') or row.get('department_id')
            if dept_raw:
                dept_str = str(dept_raw).strip()
                if dept_str.lower() in depts_cache:
                    dept_id = depts_cache[dept_str.lower()]
                else:
                    dept_id = cls.resolve_department(company_id, dept_str)
                    if dept_id:
                        depts_cache[dept_str.lower()] = dept_id

            # Account resolution
            account_id = None
            acc_raw = row.get('account') or row.get('account_name') or row.get('financial_account') or row.get('account_id')
            if acc_raw:
                acc_str = str(acc_raw).strip()
                if acc_str.lower() in accs_cache:
                    account_id = accs_cache[acc_str.lower()]
                else:
                    account_id = cls.resolve_account(company_id, acc_str)
                    if account_id:
                        accs_cache[acc_str.lower()] = account_id

            # Fallback default account for revenue/expense if none specified
            if not account_id:
                if transaction_type == 'revenue':
                    def_acc = FinancialAccount.query.filter_by(company_id=company_id, account_category='Income').first()
                else:
                    def_acc = FinancialAccount.query.filter_by(company_id=company_id, account_category='Expense').first()
                if def_acc:
                    account_id = def_acc.id

            category = (row.get('category') or ('Revenue' if transaction_type == 'revenue' else 'Expense')).strip()
            subcategory = (row.get('subcategory') or row.get('sub_category') or '').strip()
            description = (row.get('description') or row.get('desc') or '').strip()

            rec_val = row.get('is_recurring')
            is_recurring = str(rec_val).strip().lower() in ('yes', 'true', '1', 'on') if rec_val is not None else False
            recurring_frequency = (row.get('recurring_frequency') or row.get('frequency') or '').strip()

            ref_key = ref.lower() if ref else None
            existing = existing_by_ref.get(ref_key) if ref_key else None

            if existing:
                if mode == 'add':
                    skipped_count += 1
                    continue
                # Update existing
                existing.transaction_date = tx_date
                existing.amount = amount
                existing.category = category
                existing.subcategory = subcategory
                existing.description = description
                if dept_id:
                    existing.department_id = dept_id
                if account_id:
                    existing.account_id = account_id
                existing.is_recurring = is_recurring
                existing.recurring_frequency = recurring_frequency
                updated_count += 1
            else:
                if mode == 'update':
                    skipped_count += 1
                    continue
                # Add new record
                new_rec = FinancialRecord(
                    company_id=company_id,
                    transaction_date=tx_date,
                    transaction_type=transaction_type,
                    amount=amount,
                    category=category,
                    subcategory=subcategory,
                    description=description,
                    reference_number=ref or None,
                    department_id=dept_id,
                    account_id=account_id,
                    is_recurring=is_recurring,
                    recurring_frequency=recurring_frequency
                )
                db.session.add(new_rec)
                if ref_key:
                    existing_by_ref[ref_key] = new_rec
                added_count += 1

        db.session.commit()

        # Recalculate metrics
        try:
            from services.twin_service import recalculate_company_metrics
            recalculate_company_metrics(company_id)
        except Exception:
            pass

        return {
            'success': True,
            'added': added_count,
            'inserted': added_count,
            'updated': updated_count,
            'skipped': skipped_count,
            'errors': errors,
            'total_processed': added_count + updated_count + skipped_count,
            'message': f"Import complete: {added_count} created, {updated_count} updated" + (f", {len(errors)} error(s)" if errors else "")
        }
