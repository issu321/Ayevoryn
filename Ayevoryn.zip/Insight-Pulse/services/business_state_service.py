"""
Business State Service - Canonical Business State & Metric Provenance Engine
Insight-Pulse / AEVORYN Enterprise Platform

Provides a single source of truth for core business and financial metrics,
attaching explicit provenance metadata (OBSERVED, DECLARED, SYNTHESIZED, SIMULATED)
to every computed metric. Eliminates divergent heuristics and ungrounded fabrications.
"""

from enum import Enum
from dataclasses import dataclass, field, asdict
from typing import Optional, Any, Dict, List, Union
from datetime import datetime, date, timedelta
from sqlalchemy import func

from database.db import db
from database.models.company import Company
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.inventory import Inventory
from database.models.department import Department


class ProvenanceType(str, Enum):
    """Classification of metric provenance and computational origin."""
    OBSERVED = "OBSERVED"        # Derived directly from transactional database records
    DECLARED = "DECLARED"        # Configured by user/executive in profile/settings (targets, plans)
    SYNTHESIZED = "SYNTHESIZED"  # Algorithmic estimate or proxy when observed data is absent
    SIMULATED = "SIMULATED"      # Output of a scenario or simulation engine model


@dataclass
class MetricResult:
    """
    Standardized enterprise metric container with complete provenance and confidence metadata.
    """
    name: str
    value: Any
    unit: str
    provenance: ProvenanceType
    source_description: str
    confidence: float = 1.0
    calculated_at: datetime = field(default_factory=datetime.utcnow)
    is_synthetic: bool = False
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        """Serialize MetricResult to a JSON-compatible dictionary."""
        d = asdict(self)
        d['provenance'] = self.provenance.value if isinstance(self.provenance, ProvenanceType) else str(self.provenance)
        d['calculated_at'] = self.calculated_at.isoformat() if self.calculated_at else None
        return d

    @property
    def is_observed(self) -> bool:
        return self.provenance == ProvenanceType.OBSERVED

    @property
    def is_declared(self) -> bool:
        return self.provenance == ProvenanceType.DECLARED


class BusinessStateService:
    """
    Canonical State Resolver for Enterprise Digital Twin.
    Guarantees consistent, explainable, and verifiable metrics across all UI views,
    APIs, simulators, and executive reporting modules.
    """

    @classmethod
    def get_revenue(cls, company_id: int, period_days: int = 30) -> MetricResult:
        """
        Calculates trailing revenue strictly from FinancialRecord transactions.
        If no ledger records exist, falls back cleanly to 0.0 with target context in metadata.
        """
        company = Company.query.get(company_id)
        start_date = (datetime.utcnow() - timedelta(days=period_days)).date()

        rev_query = db.session.query(
            func.coalesce(func.sum(FinancialRecord.amount), 0.0),
            func.count(FinancialRecord.id)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= start_date
        ).first()

        amount = float(rev_query[0] or 0.0)
        record_count = int(rev_query[1] or 0)

        annual_target = float(getattr(company, 'annual_revenue', 0) or 0.0) if company else 0.0

        if record_count > 0:
            return MetricResult(
                name=f"revenue_{period_days}d",
                value=round(amount, 2),
                unit="USD",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Aggregated from {record_count} revenue ledger transactions in trailing {period_days} days.",
                confidence=1.0,
                is_synthetic=False,
                metadata={
                    "record_count": record_count,
                    "period_days": period_days,
                    "annual_target": annual_target
                }
            )
        elif annual_target > 0:
            # Target is declared, but actual recorded revenue is zero
            return MetricResult(
                name=f"revenue_{period_days}d",
                value=0.0,
                unit="USD",
                provenance=ProvenanceType.DECLARED,
                source_description=f"Zero revenue transactions recorded. Annual target of ${annual_target:,.2f} declared in company profile.",
                confidence=0.85,
                is_synthetic=False,
                metadata={
                    "record_count": 0,
                    "period_days": period_days,
                    "annual_target": annual_target,
                    "prorated_target": round(annual_target * (period_days / 365.0), 2)
                }
            )
        else:
            return MetricResult(
                name=f"revenue_{period_days}d",
                value=0.0,
                unit="USD",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Zero revenue records found in ledger for trailing {period_days} days.",
                confidence=1.0,
                is_synthetic=False,
                metadata={"record_count": 0, "period_days": period_days, "annual_target": 0.0}
            )

    @classmethod
    def get_expenses(cls, company_id: int, period_days: int = 30) -> MetricResult:
        """
        Calculates trailing operating expenses strictly from FinancialRecord transactions.
        """
        start_date = (datetime.utcnow() - timedelta(days=period_days)).date()

        exp_query = db.session.query(
            func.coalesce(func.sum(FinancialRecord.amount), 0.0),
            func.count(FinancialRecord.id)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= start_date
        ).first()

        amount = float(exp_query[0] or 0.0)
        record_count = int(exp_query[1] or 0)

        if record_count > 0:
            return MetricResult(
                name=f"expense_{period_days}d",
                value=round(amount, 2),
                unit="USD",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Aggregated from {record_count} expense ledger transactions in trailing {period_days} days.",
                confidence=1.0,
                is_synthetic=False,
                metadata={"record_count": record_count, "period_days": period_days}
            )
        else:
            return MetricResult(
                name=f"expense_{period_days}d",
                value=0.0,
                unit="USD",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Zero expense records found in ledger for trailing {period_days} days.",
                confidence=1.0,
                is_synthetic=False,
                metadata={"record_count": 0, "period_days": period_days}
            )

    @classmethod
    def get_profit(cls, company_id: int, period_days: int = 30, rev: Optional[MetricResult] = None, exp: Optional[MetricResult] = None) -> MetricResult:
        """
        Calculates net operating profit (Revenue - Expense) for trailing period.
        """
        if rev is None:
            rev = cls.get_revenue(company_id, period_days)
        if exp is None:
            exp = cls.get_expenses(company_id, period_days)
        profit_val = round(float(rev.value) - float(exp.value), 2)

        is_observed = rev.is_observed and exp.is_observed
        provenance = ProvenanceType.OBSERVED if is_observed else ProvenanceType.SYNTHESIZED
        confidence = min(rev.confidence, exp.confidence)

        return MetricResult(
            name=f"profit_{period_days}d",
            value=profit_val,
            unit="USD",
            provenance=provenance,
            source_description=f"Net profit: {rev.source_description} minus {exp.source_description}",
            confidence=confidence,
            is_synthetic=not is_observed,
            metadata={
                "revenue": rev.value,
                "expense": exp.value,
                "period_days": period_days
            }
        )

    @classmethod
    def get_gross_margin(cls, company_id: int, period_days: int = 30, rev: Optional[MetricResult] = None, profit: Optional[MetricResult] = None) -> MetricResult:
        """
        Calculates operating margin percentage ((Revenue - Expense) / Revenue * 100).
        """
        if rev is None:
            rev = cls.get_revenue(company_id, period_days)
        if profit is None:
            profit = cls.get_profit(company_id, period_days, rev=rev)

        margin = round((profit.value / rev.value * 100.0), 2) if rev.value > 0 else 0.0

        return MetricResult(
            name=f"margin_{period_days}d",
            value=margin,
            unit="%",
            provenance=profit.provenance,
            source_description=f"Operating margin calculated as ({profit.value:,.2f} / {rev.value:,.2f}) * 100",
            confidence=profit.confidence,
            is_synthetic=profit.is_synthetic,
            metadata={"profit": profit.value, "revenue": rev.value}
        )

    @classmethod
    def get_cash_balance(cls, company_id: int, company: Optional[Company] = None) -> MetricResult:
        """
        Resolves total liquid cash reserves through strict hierarchical provenance:
        1. OBSERVED: Sum of active cash & bank account balances in FinancialAccount.
        2. DECLARED: Company.total_equity if configured and positive.
        3. OBSERVED (Zero): 0.0 if neither accounts nor equity are configured.
        Never fabricates arbitrary reserves.
        """
        if company is None:
            company = Company.query.get(company_id)

        # 1. Check for active cash/bank accounts
        cash_accounts = FinancialAccount.query.filter(
            FinancialAccount.company_id == company_id,
            FinancialAccount.is_active == True,
            func.lower(FinancialAccount.account_type).in_(['cash', 'bank', 'cash_equivalent', 'checking', 'savings'])
        ).all()

        if cash_accounts:
            total_cash = sum(float(acc.current_balance or 0.0) for acc in cash_accounts)
            return MetricResult(
                name="cash_balance",
                value=round(total_cash, 2),
                unit="USD",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Aggregated balance across {len(cash_accounts)} active cash and bank accounts.",
                confidence=1.0,
                is_synthetic=False,
                metadata={
                    "account_count": len(cash_accounts),
                    "accounts": [{"id": a.id, "name": a.account_name, "balance": a.current_balance} for a in cash_accounts]
                }
            )

        # 2. Check declared total_equity in Company model
        declared_equity = float(getattr(company, 'total_equity', 0) or 0.0) if company else 0.0
        if declared_equity > 0:
            return MetricResult(
                name="cash_balance",
                value=round(declared_equity, 2),
                unit="USD",
                provenance=ProvenanceType.DECLARED,
                source_description="Declared total equity / reserve proxy from company profile settings.",
                confidence=0.80,
                is_synthetic=False,
                metadata={"source_field": "company.total_equity"}
            )

        # 3. Explicit zero cash state
        return MetricResult(
            name="cash_balance",
            value=0.0,
            unit="USD",
            provenance=ProvenanceType.OBSERVED,
            source_description="Zero cash accounts registered and zero equity declared in company profile.",
            confidence=1.0,
            is_synthetic=False,
            metadata={"account_count": 0, "total_equity": 0.0}
        )

    @classmethod
    def get_burn_rate(cls, company_id: int, period_days: int = 30, rev: Optional[MetricResult] = None, exp: Optional[MetricResult] = None) -> MetricResult:
        """
        Calculates monthly cash burn rates mathematically correctly:
        - gross_monthly_burn = expenses * (30.0 / period_days)
        - net_monthly_burn = (expenses - revenue) * (30.0 / period_days)
        - daily_gross_burn = expenses / period_days
        - daily_net_burn = (expenses - revenue) / period_days
        """
        if rev is None:
            rev = cls.get_revenue(company_id, period_days)
        if exp is None:
            exp = cls.get_expenses(company_id, period_days)

        period_factor = 30.0 / max(period_days, 1)
        gross_monthly = round(float(exp.value) * period_factor, 2)
        net_monthly = round((float(exp.value) - float(rev.value)) * period_factor, 2)
        daily_gross = round(float(exp.value) / period_days, 2)
        daily_net = round((float(exp.value) - float(rev.value)) / period_days, 2)

        is_burning = net_monthly > 0

        return MetricResult(
            name="monthly_burn",
            value=gross_monthly,
            unit="USD/month",
            provenance=exp.provenance,
            source_description=f"Gross monthly burn calculated over {period_days}-day period (${exp.value:,.2f} normalized to 30 days).",
            confidence=exp.confidence,
            is_synthetic=exp.is_synthetic,
            metadata={
                "gross_monthly_burn": gross_monthly,
                "net_monthly_burn": net_monthly,
                "daily_gross_burn": daily_gross,
                "daily_net_burn": daily_net,
                "is_burning": is_burning,
                "period_days": period_days
            }
        )

    @classmethod
    def get_runway(cls, company_id: int, period_days: int = 30, burn_type: str = 'net', cash: Optional[MetricResult] = None, burn: Optional[MetricResult] = None) -> MetricResult:
        """
        Computes cash runway in months with strict mathematical honesty:
        - If burning cash (burn > 0) and cash > 0: cash_balance / monthly_burn
        - If cash <= 0: runway is 0.0 months
        - If company is cash-flow positive / non-burning: runway is None (Self-Sustaining)
        Never fabricates an arbitrary 99.0 or 999.0 fallback ceiling.
        """
        if cash is None:
            cash = cls.get_cash_balance(company_id)
        if burn is None:
            burn = cls.get_burn_rate(company_id, period_days)

        cash_val = float(cash.value)
        monthly_burn = float(burn.metadata['net_monthly_burn'] if burn_type == 'net' else burn.metadata['gross_monthly_burn'])

        confidence = min(cash.confidence, burn.confidence)
        provenance = cash.provenance if cash.provenance == burn.provenance else ProvenanceType.SYNTHESIZED

        if cash_val <= 0:
            return MetricResult(
                name="runway_months",
                value=0.0,
                unit="months",
                provenance=provenance,
                source_description="Zero cash balance available. Critical insolvency warning.",
                confidence=confidence,
                is_synthetic=False,
                metadata={
                    "cash_balance": cash_val,
                    "monthly_burn": monthly_burn,
                    "burn_type": burn_type,
                    "is_sustainable": False,
                    "status": "depleted"
                }
            )

        if monthly_burn <= 0:
            # Self-sustaining: revenues exceed or equal expenses
            return MetricResult(
                name="runway_months",
                value=None,
                unit="months",
                provenance=provenance,
                source_description="Cash-flow positive / self-sustaining. Operating revenues cover or exceed expenses.",
                confidence=confidence,
                is_synthetic=False,
                metadata={
                    "cash_balance": cash_val,
                    "monthly_burn": monthly_burn,
                    "burn_type": burn_type,
                    "is_sustainable": True,
                    "status": "self_sustaining",
                    "display": "Self-Sustaining"
                }
            )

        # Active cash burn: calculate honest runway in months
        runway_months = round(cash_val / monthly_burn, 1)

        return MetricResult(
            name="runway_months",
            value=runway_months,
            unit="months",
            provenance=provenance,
            source_description=f"Calculated as ${cash_val:,.2f} cash reserve / ${monthly_burn:,.2f} {burn_type} monthly burn.",
            confidence=confidence,
            is_synthetic=False,
            metadata={
                "cash_balance": cash_val,
                "monthly_burn": monthly_burn,
                "burn_type": burn_type,
                "is_sustainable": False,
                "status": "burning",
                "display": f"{runway_months:.1f} Mo"
            }
        )

    @classmethod
    def get_headcount(cls, company_id: int, company: Optional[Company] = None) -> MetricResult:
        """
        Resolves employee headcount strictly:
        - OBSERVED: Active roster rows in Employee table.
        - DECLARED: Company.employee_count targets configured in setup.
        """
        if company is None:
            company = Company.query.get(company_id)
        active_count = Employee.query.filter_by(company_id=company_id, status='active').count()
        total_roster = Employee.query.filter_by(company_id=company_id).count()
        plan_headcount = int(getattr(company, 'employee_count', 0) or 0) if company else 0

        if active_count > 0:
            return MetricResult(
                name="headcount",
                value=active_count,
                unit="employees",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Verified roster of {active_count} active employees in Employee directory.",
                confidence=1.0,
                is_synthetic=False,
                metadata={
                    "active_count": active_count,
                    "total_roster": total_roster,
                    "plan_headcount": plan_headcount,
                    "hiring_attainment_pct": round(active_count / plan_headcount * 100, 1) if plan_headcount > 0 else 0.0
                }
            )
        elif plan_headcount > 0:
            return MetricResult(
                name="headcount",
                value=0,
                unit="employees",
                provenance=ProvenanceType.DECLARED,
                source_description=f"Zero active employees in database roster. Plan target of {plan_headcount} employees declared in company setup.",
                confidence=0.85,
                is_synthetic=False,
                metadata={
                    "active_count": 0,
                    "total_roster": total_roster,
                    "plan_headcount": plan_headcount,
                    "hiring_attainment_pct": 0.0
                }
            )
        else:
            return MetricResult(
                name="headcount",
                value=0,
                unit="employees",
                provenance=ProvenanceType.OBSERVED,
                source_description="Zero employee records configured.",
                confidence=1.0,
                is_synthetic=False,
                metadata={"active_count": 0, "total_roster": 0, "plan_headcount": 0}
            )

    @classmethod
    def get_payroll(cls, company_id: int) -> MetricResult:
        """
        Calculates total annual and monthly payroll from active employee records using SQL aggregations.
        """
        stats = db.session.query(
            func.count(Employee.id),
            func.coalesce(func.sum(Employee.salary), 0.0),
            func.coalesce(func.avg(Employee.salary), 0.0)
        ).filter(
            Employee.company_id == company_id,
            Employee.status == 'active'
        ).first()

        active_count = int(stats[0] or 0)
        annual_payroll = float(stats[1] or 0.0)
        avg_salary = float(stats[2] or 0.0)

        if active_count == 0:
            return MetricResult(
                name="total_payroll",
                value=0.0,
                unit="USD/year",
                provenance=ProvenanceType.OBSERVED,
                source_description="Zero active employees; annual payroll is $0.00.",
                confidence=1.0,
                is_synthetic=False,
                metadata={"annual_payroll": 0.0, "monthly_payroll": 0.0, "avg_salary": 0.0, "headcount": 0}
            )

        return MetricResult(
            name="total_payroll",
            value=round(annual_payroll, 2),
            unit="USD/year",
            provenance=ProvenanceType.OBSERVED,
            source_description=f"Computed from {active_count} active employee salaries.",
            confidence=1.0,
            is_synthetic=False,
            metadata={
                "annual_payroll": round(annual_payroll, 2),
                "monthly_payroll": round(annual_payroll / 12.0, 2),
                "avg_salary": round(avg_salary, 2),
                "headcount": active_count
            }
        )

    @classmethod
    def get_customer_metrics(cls, company_id: int, company: Optional[Company] = None) -> Dict[str, MetricResult]:
        """
        Resolves customer counts, churn rate, Customer Acquisition Cost (CAC), and Lifetime Value (LTV).
        """
        if company is None:
            company = Company.query.get(company_id)
        active_customers = Customer.query.filter_by(company_id=company_id, status='active').count()
        total_customers = Customer.query.filter_by(company_id=company_id).count()
        churned_customers = Customer.query.filter_by(company_id=company_id, is_churned=True).count()
        plan_customers = int(getattr(company, 'customer_count', 0) or 0) if company else 0

        churn_base = active_customers + churned_customers
        churn_rate = round((churned_customers / churn_base * 100.0), 2) if churn_base > 0 else 0.0

        # CAC & LTV aggregated in SQL
        ltv_stats = db.session.query(
            func.count(Customer.id),
            func.coalesce(func.avg(Customer.lifetime_value), 0.0)
        ).filter(
            Customer.company_id == company_id,
            Customer.lifetime_value > 0
        ).first()

        cac_stats = db.session.query(
            func.count(Customer.id),
            func.coalesce(func.avg(Customer.acquisition_cost), 0.0)
        ).filter(
            Customer.company_id == company_id,
            Customer.acquisition_cost > 0
        ).first()

        ltv_count = int(ltv_stats[0] or 0)
        avg_ltv = round(float(ltv_stats[1] or 0.0), 2)

        cac_count = int(cac_stats[0] or 0)
        avg_cac = round(float(cac_stats[1] or 0.0), 2)

        if total_customers > 0:
            count_result = MetricResult(
                name="active_customers",
                value=active_customers,
                unit="customers",
                provenance=ProvenanceType.OBSERVED,
                source_description=f"Aggregated from {total_customers} CRM customer records ({active_customers} active).",
                confidence=1.0,
                is_synthetic=False,
                metadata={
                    "active": active_customers,
                    "total": total_customers,
                    "churned": churned_customers,
                    "plan": plan_customers
                }
            )
        elif plan_customers > 0:
            count_result = MetricResult(
                name="active_customers",
                value=0,
                unit="customers",
                provenance=ProvenanceType.DECLARED,
                source_description=f"Zero customer rows in CRM. Target plan of {plan_customers} customers configured in setup.",
                confidence=0.85,
                is_synthetic=False,
                metadata={"active": 0, "total": 0, "churned": 0, "plan": plan_customers}
            )
        else:
            count_result = MetricResult(
                name="active_customers",
                value=0,
                unit="customers",
                provenance=ProvenanceType.OBSERVED,
                source_description="Zero customer records found in CRM.",
                confidence=1.0,
                is_synthetic=False,
                metadata={"active": 0, "total": 0, "churned": 0, "plan": 0}
            )

        churn_result = MetricResult(
            name="churn_rate",
            value=churn_rate,
            unit="%",
            provenance=ProvenanceType.OBSERVED if total_customers > 0 else ProvenanceType.OBSERVED,
            source_description=f"Computed as ({churned_customers} churned / {churn_base} total baseline customers) * 100",
            confidence=1.0 if total_customers > 0 else 1.0,
            is_synthetic=False,
            metadata={"churned_count": churned_customers, "active_count": active_customers}
        )

        cac_result = MetricResult(
            name="cac",
            value=avg_cac,
            unit="USD",
            provenance=ProvenanceType.OBSERVED if cac_count > 0 else ProvenanceType.SYNTHESIZED,
            source_description=f"Average acquisition cost from {cac_count} customer profiles." if cac_count > 0 else "No acquisition cost records present.",
            confidence=1.0 if cac_count > 0 else 0.5,
            is_synthetic=not bool(cac_count),
            metadata={"sample_size": cac_count}
        )

        ltv_result = MetricResult(
            name="ltv",
            value=avg_ltv,
            unit="USD",
            provenance=ProvenanceType.OBSERVED if ltv_count > 0 else ProvenanceType.SYNTHESIZED,
            source_description=f"Average customer lifetime value from {ltv_count} customer profiles." if ltv_count > 0 else "No lifetime value records present.",
            confidence=1.0 if ltv_count > 0 else 0.5,
            is_synthetic=not bool(ltv_count),
            metadata={"sample_size": ltv_count}
        )

        return {
            "active_customers": count_result,
            "churn_rate": churn_result,
            "cac": cac_result,
            "ltv": ltv_result
        }

    @classmethod
    def get_canonical_state(cls, company_id: int, period_days: int = 30) -> Dict[str, Any]:
        """
        Produces the authoritative, fully resolved canonical business state for a company.
        Outputs both rich MetricResult objects and flat dictionary formats for full
        backwards-compatibility with legacy templates and service callers.
        """
        company = Company.query.get(company_id)
        now = datetime.utcnow()

        # Core metric resolution with zero query redundancy
        rev = cls.get_revenue(company_id, period_days)
        exp = cls.get_expenses(company_id, period_days)
        profit = cls.get_profit(company_id, period_days, rev=rev, exp=exp)
        margin = cls.get_gross_margin(company_id, period_days, rev=rev, profit=profit)
        cash = cls.get_cash_balance(company_id, company=company)
        burn = cls.get_burn_rate(company_id, period_days, rev=rev, exp=exp)
        net_runway = cls.get_runway(company_id, period_days, burn_type='net', cash=cash, burn=burn)
        gross_runway = cls.get_runway(company_id, period_days, burn_type='gross', cash=cash, burn=burn)
        headcount = cls.get_headcount(company_id, company=company)
        payroll = cls.get_payroll(company_id)
        cust = cls.get_customer_metrics(company_id, company=company)

        # Previous period comparisons (for deltas)
        prev_start = (now - timedelta(days=period_days * 2)).date()
        prev_end = (now - timedelta(days=period_days)).date()

        prev_rev = float(db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= prev_start,
            FinancialRecord.transaction_date < prev_end
        ).scalar() or 0.0)

        prev_exp = float(db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= prev_start,
            FinancialRecord.transaction_date < prev_end
        ).scalar() or 0.0)

        prev_profit = prev_rev - prev_exp
        prev_margin = (prev_profit / prev_rev * 100.0) if prev_rev > 0 else 0.0

        # Inventory metrics via direct SQL aggregation
        total_skus = Inventory.query.filter_by(company_id=company_id, is_active=True).count()
        low_stock = Inventory.query.filter(
            Inventory.company_id == company_id,
            Inventory.is_active == True,
            Inventory.quantity_available <= Inventory.reorder_point
        ).count()

        # Year-to-date figures
        fy_start = date(now.year, 1, 1)
        revenue_ytd = float(db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue',
            FinancialRecord.transaction_date >= fy_start
        ).scalar() or 0.0)

        expense_ytd = float(db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense',
            FinancialRecord.transaction_date >= fy_start
        ).scalar() or 0.0)

        annual_target = float(getattr(company, 'annual_revenue', 0) or 0.0) if company else 0.0
        day_of_year = (now.date() - fy_start).days + 1
        expected_to_date = (annual_target / 365.0) * day_of_year if annual_target else 0.0
        revenue_pacing_gap = round(revenue_ytd - expected_to_date, 2) if annual_target else 0.0

        # Health score (0-100) based on margin, churn, and inventory health
        margin_score = min(max(margin.value / 20.0 * 25.0, 0.0), 25.0)
        churn_score = max(0.0, 25.0 - float(cust['churn_rate'].value) / 4.0 * 25.0)
        stock_score = max(0.0, 25.0 - (low_stock / max(total_skus, 1) * 100.0) / 20.0 * 25.0)
        diversity_score = min(total_skus / 50.0 * 25.0, 25.0)
        health_score = round(min(100.0, margin_score + churn_score + stock_score + diversity_score), 1)

        # High-level provenance audit summary
        provenance_summary = {
            "revenue": rev.provenance.value,
            "expenses": exp.provenance.value,
            "cash": cash.provenance.value,
            "runway": net_runway.provenance.value,
            "headcount": headcount.provenance.value,
            "customers": cust['active_customers'].provenance.value
        }

        # Flat dictionary format fully compliant with existing callers of get_executive_summary()
        summary_flat = {
            'revenue_30d': float(rev.value),
            'revenue_prev_30d': round(prev_rev, 2),
            'expense_30d': float(exp.value),
            'expense_prev_30d': round(prev_exp, 2),
            'profit_30d': float(profit.value),
            'profit_prev_30d': round(prev_profit, 2),
            'margin': float(margin.value),
            'margin_prev': round(prev_margin, 2),
            'total_employees': int(headcount.value),
            'roster_total': headcount.metadata.get('total_roster', 0),
            'plan_headcount': headcount.metadata.get('plan_headcount', 0),
            'hiring_completion': headcount.metadata.get('hiring_attainment_pct', 0.0),
            'avg_salary': payroll.metadata.get('avg_salary', 0.0),
            'total_payroll': float(payroll.value),
            'total_customers': int(cust['active_customers'].value),
            'plan_customers': cust['active_customers'].metadata.get('plan', 0),
            'churn_rate': float(cust['churn_rate'].value),
            'churned_count': cust['churn_rate'].metadata.get('churned_count', 0),
            'total_skus': total_skus,
            'low_stock': low_stock,
            'health_score': health_score,
            'cash_balance': float(cash.value),
            'monthly_burn': float(burn.metadata['net_monthly_burn']),
            'gross_monthly_burn': float(burn.metadata['gross_monthly_burn']),
            'runway_months': net_runway.value,
            'gross_runway_months': gross_runway.value,
            'is_burning': burn.metadata['is_burning'],
            'annual_target': annual_target,
            'revenue_target_label': 'FY Revenue Target' if annual_target else 'No target set',
            'revenue_source': 'records' if rev.is_observed else ('plan' if annual_target else 'no_data'),
            'revenue_status': 'observed' if rev.is_observed else 'no_data',
            'revenue_ytd': round(revenue_ytd, 2),
            'revenue_attainment': round((revenue_ytd / annual_target * 100), 1) if annual_target > 0 else 0.0,
            'revenue_expected_to_date': round(expected_to_date, 2),
            'revenue_pacing_gap': revenue_pacing_gap,
            'expense_ytd': round(expense_ytd, 2),
            'expense_status': 'observed' if exp.is_observed else 'no_data',
            'profit_ytd': round(revenue_ytd - expense_ytd, 2),
            'profit_status': 'observed' if (rev.is_observed or exp.is_observed) else 'insufficient_data',
            'has_activity': bool(rev.is_observed or exp.is_observed),
            'setup_progress_pct': round((sum([bool(company), headcount.value > 0, cust['active_customers'].value > 0, total_skus > 0, bool(rev.is_observed or exp.is_observed)]) / 5.0) * 100.0, 1),
            'burn_multiple': round(float(exp.value) / float(rev.value), 2) if (rev.is_observed or exp.is_observed) and float(exp.value) > float(rev.value) and float(rev.value) > 0 else (0.0 if (rev.is_observed or exp.is_observed) and float(rev.value) >= float(exp.value) else None),
            'financial_complete': rev.is_observed or exp.is_observed,
            'financial_status': 'observed' if (rev.is_observed or exp.is_observed) else 'no_data',
            'data_quality': {
                'financial': 'observed' if (rev.is_observed or exp.is_observed) else 'no_data',
                'profitability': 'observed' if (rev.is_observed or exp.is_observed) else 'insufficient_data',
                'customers': 'records' if cust['active_customers'].metadata.get('total', 0) > 0 else 'no_data',
                'employees': 'records' if headcount.metadata.get('total_roster', 0) > 0 else 'no_data',
                'inventory': 'records' if total_skus > 0 else 'no_data'
            },
            'provenance': provenance_summary
        }

        return {
            "company_id": company_id,
            "period_days": period_days,
            "timestamp": now.isoformat(),
            "metrics": {
                "revenue": rev,
                "expenses": exp,
                "profit": profit,
                "margin": margin,
                "cash_balance": cash,
                "burn_rate": burn,
                "runway": net_runway,
                "gross_runway": gross_runway,
                "headcount": headcount,
                "payroll": payroll,
                **cust
            },
            "summary": summary_flat
        }
