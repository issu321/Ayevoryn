"""
AEVORYN GLOBAL SUPERADMIN CONTROL PLANE SERVICE
Provides:
1. Secure, idempotent one-time bootstrap for Global Superadmin (Mohammed Usman / usman / jaafreeusman@gmail.com).
2. Immutable Global Audit Trail recording and querying.
3. Real database-backed platform telemetry & storage/health diagnostics.
4. Global Companies Management (search, filter, sort, edit, logo upload, status transitions, safe single & bulk deletion, bulk status/tier/export actions, direct provisioning).
5. Global Users Management (cross-tenant inspection, role/company assignment, status control, session revocation, password resets, single & bulk user actions).
6. Global Platform Control (registration toggle, maintenance mode, auth policies, AI provider settings).
7. Superadmin Profile, RFC 6238 TOTP MFA, and Active Session Management.
"""

import os
import io
import csv
import json
import uuid
import time
import hmac
import struct
import base64
import hashlib
import secrets
from datetime import datetime, timedelta
from flask import request, session, current_app
from flask_login import current_user
from sqlalchemy import func, or_

from database.db import db
from database.models.user import User
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.project import Project
from database.models.financial import FinancialRecord
from database.models.audit_log import AuditLog
from database.models.superadmin import GlobalAuditLog, PlatformSetting, UserSessionRecord
from database.models.pulse_ai import AIConversation, AIMessage, AIToolExecution, AIUsageLog
from security.password_hash import hash_password, verify_password
from security.rbac import Role, COMPANY_ROLES


# Pre-computed 600,000-iteration PBKDF2-HMAC-SHA256 digest of the initial bootstrap credential
# Used only during first-time account provisioning if AEVORYN_SUPERADMIN_INITIAL_PASSWORD is not set in env.
_DEFAULT_SUPERADMIN_BOOT_HASH = (
    "pbkdf2:sha256:600000$15f7b3e8ec3388e057ded209fffe80d0$"
    "5c3acb1478e4cff9e2f39b30a3a16066f21694274ea7e30731b3b1e0819e5888"
)


DEFAULT_PLATFORM_SETTINGS = [
    ('platform_name', 'AEVORYN', 'string', 'branding', 'Global SaaS Platform Name'),
    ('platform_tagline', 'Enterprise Digital Twin & Decision Intelligence', 'string', 'branding', 'Global Platform Tagline'),
    ('allow_public_registration', 'true', 'bool', 'registration', 'Allow new organizations and users to self-register'),
    ('allow_company_provisioning', 'true', 'bool', 'registration', 'Allow multi-step enterprise provisioning wizard (/setup)'),
    ('default_plan_tier', 'Enterprise', 'string', 'organization', 'Default subscription tier assigned to newly provisioned companies'),
    ('maintenance_mode', 'false', 'bool', 'operations', 'Place tenant workspaces in read-only maintenance mode (Superadmin remains active)'),
    ('maintenance_message', 'Scheduled platform maintenance is in progress. Operations will resume shortly.', 'string', 'operations', 'Banner message displayed during maintenance mode'),
    ('session_timeout_minutes', '60', 'int', 'security', 'Inactivity timeout for authenticated sessions in minutes'),
    ('max_login_attempts', '5', 'int', 'security', 'Consecutive failed login attempts before 15-minute account lockout'),
    ('require_superadmin_mfa', 'false', 'bool', 'security', 'Require TOTP Multi-Factor Authentication on Global Superadmin sign-in'),
    ('ai_provider', 'auto', 'string', 'ai', 'Configured Pulse AI provider (auto, gemini, openai, anthropic, local_analytical)'),
    ('ai_model_name', 'gemini-2.5-flash', 'string', 'ai', 'Default LLM model identifier for external cloud provider'),
    ('ai_enable_streaming', 'true', 'bool', 'ai', 'Enable progressive Server-Sent Events streaming in Pulse AI'),
    ('ai_enable_tools', 'true', 'bool', 'ai', 'Allow Pulse AI to execute read tools and propose confirmed mutations'),
    ('ai_max_context_messages', '12', 'int', 'ai', 'Maximum historical messages included in multi-turn conversation window'),
]

VALID_PLAN_TIERS = ('Enterprise', 'Global Scale', 'Growth', 'Trial')


class SuperadminService:
    """Core service layer for the Global Superadmin Control Center."""

    # ──────────────────────────────────────────────────────────────────────
    # 1. IDEMPOTENT INITIAL SUPERADMIN BOOTSTRAP
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def bootstrap_superadmin():
        """
        Idempotently provision the initial Global Superadmin account:
          Full Name: Mohammed Usman
          Username:  usman
          Email:     jaafreeusman@gmail.com
          Role:      GLOBAL_SUPERADMIN
        Never logs or exposes the password. Enforces password change on first login.
        """
        try:
            full_name = (os.environ.get('AEVORYN_SUPERADMIN_FULL_NAME') or 'Mohammed Usman').strip()
            username = (os.environ.get('AEVORYN_SUPERADMIN_USERNAME') or 'usman').strip()
            email = (os.environ.get('AEVORYN_SUPERADMIN_EMAIL') or 'jaafreeusman@gmail.com').strip()

            # Check if account already exists by username, email, or GLOBAL_SUPERADMIN role
            existing = User.query.filter(
                or_(
                    func.lower(User.username) == username.lower(),
                    func.lower(User.email) == email.lower(),
                    User.role == Role.GLOBAL_SUPERADMIN
                )
            ).first()

            if existing:
                changed = False
                if existing.role != Role.GLOBAL_SUPERADMIN:
                    existing.role = Role.GLOBAL_SUPERADMIN
                    changed = True
                if not existing.is_admin:
                    existing.is_admin = True
                    changed = True
                if not existing.full_name:
                    existing.full_name = full_name
                    changed = True
                if not existing.first_name:
                    parts = full_name.split(' ', 1)
                    existing.first_name = parts[0]
                    existing.last_name = parts[1] if len(parts) > 1 else ''
                    changed = True
                if not existing.account_status:
                    existing.account_status = 'active'
                    changed = True
                if changed:
                    db.session.commit()
            else:
                raw_env_pw = os.environ.get('AEVORYN_SUPERADMIN_INITIAL_PASSWORD')
                env_pw_hash = os.environ.get('AEVORYN_SUPERADMIN_PASSWORD_HASH')
                if raw_env_pw:
                    pw_hash = hash_password(raw_env_pw)
                elif env_pw_hash:
                    pw_hash = env_pw_hash.strip()
                else:
                    pw_hash = _DEFAULT_SUPERADMIN_BOOT_HASH

                parts = full_name.split(' ', 1)
                first_name = parts[0]
                last_name = parts[1] if len(parts) > 1 else ''

                superadmin = User(
                    username=username,
                    email=email,
                    full_name=full_name,
                    first_name=first_name,
                    last_name=last_name,
                    job_title='Platform Owner & Principal Architect',
                    bio='Global Superadmin governing the Ayevoryn Multi-Tenant Enterprise SaaS Platform.',
                    role=Role.GLOBAL_SUPERADMIN,
                    is_admin=True,
                    is_active=True,
                    account_status='active',
                    must_change_password=True,
                    mfa_enabled=False,
                    session_version=1,
                    company_id=None,
                    password_hash=pw_hash,
                    security_question_1='What is your primary platform role?',
                    security_answer_1='GLOBAL_SUPERADMIN',
                    security_question_2='What is the name of the platform?',
                    security_answer_2='Ayevoryn'
                )
                db.session.add(superadmin)
                db.session.flush()

                audit = GlobalAuditLog(
                    actor_user_id=superadmin.id,
                    actor_username=superadmin.username,
                    actor_role=Role.GLOBAL_SUPERADMIN,
                    action='SUPERADMIN_BOOTSTRAP_INITIALIZED',
                    category='SECURITY',
                    target_user_id=superadmin.id,
                    target_username=superadmin.username,
                    result_status='SUCCESS',
                    details='Initial Global Superadmin account provisioned via idempotent server bootstrap with mandatory first-login password change.'
                )
                db.session.add(audit)
                db.session.commit()

            # Ensure default PlatformSetting rows exist idempotently
            SuperadminService.ensure_default_platform_settings()
            # Ensure all existing companies have org_uid and status populated
            SuperadminService.backfill_company_metadata()

        except Exception as e:
            db.session.rollback()
            print(f"[SUPERADMIN BOOTSTRAP WARNING] {e}")

    @staticmethod
    def ensure_default_platform_settings():
        existing_keys = {s.key for s in PlatformSetting.query.all()}
        added = False
        for key, val, vtype, cat, desc in DEFAULT_PLATFORM_SETTINGS:
            if key not in existing_keys:
                db.session.add(PlatformSetting(
                    key=key,
                    value=val,
                    value_type=vtype,
                    category=cat,
                    description=desc
                ))
                added = True
        if added:
            db.session.commit()

    @staticmethod
    def backfill_company_metadata():
        companies = Company.query.all()
        changed = False
        for c in companies:
            if not c.org_uid:
                c.org_uid = f"ORG-AEV-{int(c.id):04d}"
                changed = True
            if not c.status:
                c.status = 'active' if c.is_active else 'suspended'
                changed = True
            if not c.plan_tier:
                c.plan_tier = 'Enterprise'
                changed = True
        if changed:
            db.session.commit()

    # ──────────────────────────────────────────────────────────────────────
    # 2. IMMUTABLE GLOBAL AUDIT LOGGING
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def record_audit(
        action: str,
        category: str = 'PLATFORM',
        target_company_id: int = None,
        target_company_name: str = None,
        target_user_id: int = None,
        target_username: str = None,
        previous_values: dict = None,
        updated_values: dict = None,
        result_status: str = 'SUCCESS',
        details: str = None,
        actor_user=None
    ):
        """Append an immutable entry to GlobalAuditLog."""
        try:
            actor = actor_user if actor_user is not None else (
                current_user if (current_user and getattr(current_user, 'is_authenticated', False)) else None
            )
            ip_addr = None
            ua = None
            try:
                ip_addr = request.remote_addr
                ua = (request.headers.get('User-Agent') or '')[:250]
            except RuntimeError:
                pass

            entry = GlobalAuditLog(
                correlation_id=str(uuid.uuid4())[:12].upper(),
                actor_user_id=getattr(actor, 'id', None),
                actor_username=getattr(actor, 'username', 'system'),
                actor_role=getattr(actor, 'role', 'SYSTEM'),
                action=action,
                category=category,
                target_company_id=target_company_id,
                target_company_name=target_company_name,
                target_user_id=target_user_id,
                target_username=target_username,
                previous_values=json.dumps(previous_values, default=str) if previous_values else None,
                updated_values=json.dumps(updated_values, default=str) if updated_values else None,
                ip_address=ip_addr,
                user_agent=ua,
                result_status=result_status,
                details=details
            )
            db.session.add(entry)
            db.session.commit()
            return entry
        except Exception as e:
            db.session.rollback()
            print(f"[GLOBAL AUDIT ERROR] {e}")
            return None

    # ──────────────────────────────────────────────────────────────────────
    # 3. PLATFORM SETTINGS HELPER
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def get_setting(key: str, default=None):
        try:
            row = PlatformSetting.query.filter_by(key=key).first()
            if row is not None:
                return row.parsed_value()
        except Exception:
            pass
        return default

    @staticmethod
    def get_all_settings_dict() -> dict:
        SuperadminService.ensure_default_platform_settings()
        rows = PlatformSetting.query.all()
        return {r.key: r.parsed_value() for r in rows}

    # ──────────────────────────────────────────────────────────────────────
    # 4. COMPLETE SUPERADMIN DASHBOARD METRICS (100% REAL DB DATA)
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def get_dashboard_metrics(recent_limit: int = 12) -> dict:
        total_companies = Company.query.count()
        active_companies = Company.query.filter(
            or_(Company.status == 'active', (Company.status.is_(None) & (Company.is_active == True)))
        ).count()
        suspended_companies = Company.query.filter(
            or_(Company.status == 'suspended', (Company.status.is_(None) & (Company.is_active == False)))
        ).count()
        archived_companies = Company.query.filter(Company.status == 'archived').count()

        total_users = User.query.count()
        active_users = User.query.filter(
            User.is_active == True,
            or_(User.account_status == 'active', User.account_status.is_(None))
        ).count()
        inactive_users = total_users - active_users

        total_departments = Department.query.count()
        total_employees = Employee.query.count()
        total_customers = Customer.query.count()
        total_projects = Project.query.count()

        # Recent company registrations
        recent_companies = Company.query.order_by(Company.created_at.desc()).limit(recent_limit).all()

        # Recent platform audit events
        recent_audits = GlobalAuditLog.query.order_by(GlobalAuditLog.created_at.desc()).limit(10).all()

        # Authentication activity
        active_sessions_count = UserSessionRecord.query.filter_by(is_active=True).count()
        locked_users_count = User.query.filter(
            User.locked_until.isnot(None),
            User.locked_until > datetime.utcnow()
        ).count()

        # Pending administrative actions
        pending_ai_confirmations = AIToolExecution.query.filter_by(status='pending_confirmation').count()
        pending_password_resets = User.query.filter_by(must_change_password=True).count()
        pending_actions_total = suspended_companies + locked_users_count + pending_ai_confirmations

        # Storage utilization (actual filesystem calculation)
        storage_info = SuperadminService.calculate_storage_utilization()

        # Aggregate platform financials
        total_platform_arr = db.session.query(func.sum(Company.annual_revenue)).scalar() or 0.0
        avg_company_health = db.session.query(func.avg(Company.health_score)).scalar() or 0.0

        # Enrich recent companies with admin user & counts
        recent_companies_enriched = []
        for c in recent_companies:
            admin_u = User.query.filter_by(company_id=c.id).order_by(User.is_admin.desc(), User.id.asc()).first()
            dept_cnt = Department.query.filter_by(company_id=c.id).count()
            user_cnt = User.query.filter_by(company_id=c.id).count()
            recent_companies_enriched.append({
                'company': c,
                'org_uid': c.organization_code,
                'admin_user': admin_u,
                'admin_name': admin_u.display_name if admin_u else c.owner_name,
                'admin_email': admin_u.email if admin_u else (c.email or '—'),
                'dept_count': dept_cnt,
                'user_count': user_cnt,
                'status': c.effective_status,
                'plan_tier': c.plan_tier or 'Enterprise'
            })

        return {
            'total_companies': total_companies,
            'active_companies': active_companies,
            'suspended_companies': suspended_companies,
            'archived_companies': archived_companies,
            'total_users': total_users,
            'active_users': active_users,
            'inactive_users': inactive_users,
            'total_departments': total_departments,
            'total_employees': total_employees,
            'total_customers': total_customers,
            'total_projects': total_projects,
            'recent_companies': recent_companies_enriched,
            'recent_audits': recent_audits,
            'active_sessions_count': active_sessions_count,
            'locked_users_count': locked_users_count,
            'pending_ai_confirmations': pending_ai_confirmations,
            'pending_password_resets': pending_password_resets,
            'pending_actions_total': pending_actions_total,
            'storage': storage_info,
            'total_platform_arr': float(total_platform_arr),
            'avg_company_health': round(float(avg_company_health), 1),
            'system_health': SuperadminService.get_system_health_summary()
        }

    @staticmethod
    def calculate_storage_utilization() -> dict:
        root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        db_bytes = 0
        try:
            engine_url = str(db.engine.url)
            if 'sqlite' in engine_url:
                db_file = db.engine.url.database
                if db_file and db_file != ':memory:':
                    abs_db = db_file if os.path.isabs(db_file) else os.path.join(current_app.instance_path, db_file)
                    if os.path.exists(abs_db):
                        db_bytes = os.path.getsize(abs_db)
        except Exception:
            pass

        uploads_dir = os.path.join(root_dir, 'uploads')
        static_uploads_dir = os.path.join(root_dir, 'static', 'uploads')
        media_bytes = 0
        media_files = 0
        for folder in (uploads_dir, static_uploads_dir):
            if os.path.exists(folder):
                for r, _, files in os.walk(folder):
                    for f in files:
                        fp = os.path.join(r, f)
                        try:
                            media_bytes += os.path.getsize(fp)
                            media_files += 1
                        except OSError:
                            pass

        # Also count DB-persisted base64 media payloads
        logos_in_db = Company.query.filter(Company.logo_data.isnot(None)).count()
        avatars_in_db = User.query.filter(User.avatar_data.isnot(None)).count()
        total_bytes = db_bytes + media_bytes

        def _fmt_bytes(b: int) -> str:
            if b >= 1024 * 1024:
                return f"{b / (1024 * 1024):.2f} MB"
            if b >= 1024:
                return f"{b / 1024:.1f} KB"
            return f"{b} B"

        return {
            'db_bytes': db_bytes,
            'db_formatted': _fmt_bytes(db_bytes),
            'media_bytes': media_bytes,
            'media_formatted': _fmt_bytes(media_bytes),
            'total_bytes': total_bytes,
            'total_formatted': _fmt_bytes(total_bytes),
            'media_files_count': media_files,
            'logos_in_db': logos_in_db,
            'avatars_in_db': avatars_in_db
        }

    @staticmethod
    def get_system_health_summary() -> dict:
        db_ok = False
        db_backend = 'unknown'
        try:
            db.session.execute(db.text('SELECT 1'))
            db_ok = True
            db_backend = db.engine.url.get_backend_name()
        except Exception:
            pass

        # Honest AI provider detection
        gemini_key = bool(os.environ.get('GEMINI_API_KEY') or os.environ.get('GOOGLE_API_KEY'))
        openai_key = bool(os.environ.get('OPENAI_API_KEY'))
        anthropic_key = bool(os.environ.get('ANTHROPIC_API_KEY'))
        smtp_configured = bool(os.environ.get('MAIL_USERNAME') and os.environ.get('MAIL_PASSWORD'))

        if gemini_key:
            ai_status = 'Connected (Google Gemini Cloud API)'
            ai_connected = True
        elif openai_key:
            ai_status = 'Connected (OpenAI Cloud API)'
            ai_connected = True
        elif anthropic_key:
            ai_status = 'Connected (Anthropic Claude API)'
            ai_connected = True
        else:
            ai_status = 'Local Analytical Twin Engine Active (No External Cloud LLM Key Set)'
            ai_connected = True

        return {
            'status': 'HEALTHY' if db_ok else 'DEGRADED',
            'db_connected': db_ok,
            'db_backend': db_backend.upper(),
            'ai_status': ai_status,
            'ai_cloud_key_configured': (gemini_key or openai_key or anthropic_key),
            'gemini_configured': gemini_key,
            'openai_configured': openai_key,
            'anthropic_configured': anthropic_key,
            'smtp_configured': smtp_configured,
            'maintenance_mode': bool(SuperadminService.get_setting('maintenance_mode', False)),
            'allow_public_registration': bool(SuperadminService.get_setting('allow_public_registration', True)),
        }

    # ──────────────────────────────────────────────────────────────────────
    # 5. GLOBAL COMPANY MANAGEMENT
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def _build_companies_query(search: str = '', status_filter: str = 'all', industry_filter: str = '', tier_filter: str = '', sort_by: str = 'created_desc'):
        query = Company.query

        if search:
            like_q = f"%{search.strip()}%"
            query = query.filter(
                or_(
                    Company.company_name.ilike(like_q),
                    Company.business_name.ilike(like_q),
                    Company.org_uid.ilike(like_q),
                    Company.owner_name.ilike(like_q),
                    Company.ceo_name.ilike(like_q),
                    Company.email.ilike(like_q),
                    Company.country.ilike(like_q),
                    Company.city.ilike(like_q)
                )
            )

        if status_filter and status_filter != 'all':
            if status_filter == 'active':
                query = query.filter(or_(Company.status == 'active', (Company.status.is_(None) & (Company.is_active == True))))
            elif status_filter == 'suspended':
                query = query.filter(or_(Company.status == 'suspended', (Company.status.is_(None) & (Company.is_active == False))))
            elif status_filter == 'archived':
                query = query.filter(Company.status == 'archived')

        if industry_filter:
            query = query.filter(Company.industry == industry_filter)

        if tier_filter:
            query = query.filter(Company.plan_tier == tier_filter)

        if sort_by == 'name_asc':
            query = query.order_by(Company.company_name.asc())
        elif sort_by == 'name_desc':
            query = query.order_by(Company.company_name.desc())
        elif sort_by == 'revenue_desc':
            query = query.order_by(Company.annual_revenue.desc())
        elif sort_by == 'health_desc':
            query = query.order_by(Company.health_score.desc())
        elif sort_by == 'created_asc':
            query = query.order_by(Company.created_at.asc())
        else:
            query = query.order_by(Company.created_at.desc())

        return query

    @staticmethod
    def list_companies(
        search: str = '',
        status_filter: str = 'all',
        industry_filter: str = '',
        tier_filter: str = '',
        sort_by: str = 'created_desc',
        page: int = 1,
        per_page: int = 15
    ):
        query = SuperadminService._build_companies_query(
            search=search,
            status_filter=status_filter,
            industry_filter=industry_filter,
            tier_filter=tier_filter,
            sort_by=sort_by
        )

        total = query.count()
        all_matching_ids = [r[0] for r in query.with_entities(Company.id).all()]

        effective_per_page = total if (per_page <= 0 or per_page >= 5000) else max(1, per_page)
        effective_per_page = max(1, effective_per_page)
        pages = max(1, (total + effective_per_page - 1) // effective_per_page)
        page = max(1, min(page, pages))

        items = query.offset((page - 1) * effective_per_page).limit(effective_per_page).all()

        # Global status summary counts for filter pills
        status_counts = {
            'all': Company.query.count(),
            'active': Company.query.filter(or_(Company.status == 'active', (Company.status.is_(None) & (Company.is_active == True)))).count(),
            'suspended': Company.query.filter(or_(Company.status == 'suspended', (Company.status.is_(None) & (Company.is_active == False)))).count(),
            'archived': Company.query.filter(Company.status == 'archived').count(),
        }

        enriched = []
        for comp in items:
            admin_user = User.query.filter_by(company_id=comp.id).order_by(User.is_admin.desc(), User.id.asc()).first()
            user_count = User.query.filter_by(company_id=comp.id).count()
            dept_count = Department.query.filter_by(company_id=comp.id).count()
            last_audit = AuditLog.query.filter_by(company_id=comp.id).order_by(AuditLog.created_at.desc()).first()
            last_act = comp.last_activity_at or (last_audit.created_at if last_audit else comp.updated_at or comp.created_at)

            enriched.append({
                'company': comp,
                'org_uid': comp.organization_code,
                'admin_user': admin_user,
                'admin_name': admin_user.display_name if admin_user else comp.owner_name,
                'admin_email': admin_user.email if admin_user else (comp.email or '—'),
                'user_count': user_count,
                'dept_count': dept_count,
                'status': comp.effective_status,
                'plan_tier': comp.plan_tier or 'Enterprise',
                'last_activity': last_act
            })

        return {
            'items': enriched,
            'records': enriched,
            'total': total,
            'page': page,
            'per_page': per_page,
            'pages': pages,
            'all_matching_ids': all_matching_ids,
            'status_counts': status_counts
        }

    @staticmethod
    def get_company_detail(company_id: int):
        comp = db.session.get(Company, company_id)
        if not comp:
            return None

        users = User.query.filter_by(company_id=comp.id).order_by(User.is_admin.desc(), User.created_at.asc()).all()
        departments = Department.query.filter_by(company_id=comp.id).order_by(Department.hierarchy_level.asc(), Department.name.asc()).all()
        employees_count = Employee.query.filter_by(company_id=comp.id).count()
        customers_count = Customer.query.filter_by(company_id=comp.id).count()
        projects_count = Project.query.filter_by(company_id=comp.id).count()

        total_rev = db.session.query(func.sum(FinancialRecord.amount)).filter_by(
            company_id=comp.id, transaction_type='revenue'
        ).scalar() or 0.0
        total_exp = db.session.query(func.sum(FinancialRecord.amount)).filter_by(
            company_id=comp.id, transaction_type='expense'
        ).scalar() or 0.0

        company_audits = AuditLog.query.filter_by(company_id=comp.id).order_by(AuditLog.created_at.desc()).limit(25).all()
        global_audits = GlobalAuditLog.query.filter_by(target_company_id=comp.id).order_by(GlobalAuditLog.created_at.desc()).limit(25).all()

        return {
            'company': comp,
            'users': users,
            'departments': departments,
            'employees_count': employees_count,
            'customers_count': customers_count,
            'projects_count': projects_count,
            'ledger_revenue': float(total_rev),
            'ledger_expenses': float(total_exp),
            'ledger_profit': float(total_rev - total_exp),
            'company_audits': company_audits,
            'global_audits': global_audits
        }

    @staticmethod
    def create_company_by_superadmin(form_data: dict, actor_user=None):
        """Provision a new organization directly from the Global Superadmin Control Center."""
        company_name = (form_data.get('company_name') or '').strip()
        if not company_name:
            return False, "Company legal name is required.", None

        business_name = (form_data.get('business_name') or company_name).strip()
        owner_name = (form_data.get('owner_name') or 'Enterprise Owner').strip()
        ceo_name = (form_data.get('ceo_name') or owner_name).strip()
        industry = (form_data.get('industry') or 'Technology').strip()
        plan_tier = (form_data.get('plan_tier') or 'Enterprise').strip()
        if plan_tier not in VALID_PLAN_TIERS:
            plan_tier = 'Enterprise'
        currency = (form_data.get('currency') or 'USD').strip().upper()
        country = (form_data.get('country') or 'United States').strip()
        city = (form_data.get('city') or '').strip()
        email = (form_data.get('email') or '').strip()
        mobile = (form_data.get('mobile') or '').strip()
        website = (form_data.get('website') or '').strip()
        description = (form_data.get('description') or '').strip()
        try:
            annual_revenue = float(form_data.get('annual_revenue') or 0)
        except ValueError:
            annual_revenue = 0.0

        try:
            comp = Company(
                company_name=company_name,
                business_name=business_name,
                owner_name=owner_name,
                ceo_name=ceo_name,
                industry=industry,
                business_type=form_data.get('business_type') or 'B2B Enterprise',
                plan_tier=plan_tier,
                currency=currency,
                country=country,
                city=city,
                email=email,
                mobile=mobile,
                website=website,
                description=description,
                annual_revenue=annual_revenue,
                status='active',
                is_active=True,
                health_score=85.0,
                created_at=datetime.utcnow(),
                updated_at=datetime.utcnow(),
                last_activity_at=datetime.utcnow()
            )
            db.session.add(comp)
            db.session.flush()
            comp.org_uid = f"ORG-AEV-{int(comp.id):04d}"

            # Optional initial admin user creation if admin_username & admin_email provided
            admin_username = (form_data.get('admin_username') or '').strip()
            admin_email = (form_data.get('admin_email') or '').strip()
            admin_password = (form_data.get('admin_password') or '').strip()
            created_admin = None
            if admin_username and admin_email:
                clash = User.query.filter(
                    or_(func.lower(User.username) == admin_username.lower(), func.lower(User.email) == admin_email.lower())
                ).first()
                if not clash:
                    pw_to_hash = admin_password if len(admin_password) >= 6 else 'Welcome@123'
                    created_admin = User(
                        username=admin_username,
                        email=admin_email,
                        full_name=owner_name,
                        first_name=owner_name.split(' ', 1)[0],
                        last_name=owner_name.split(' ', 1)[1] if ' ' in owner_name else '',
                        role=Role.ADMIN,
                        is_admin=True,
                        is_active=True,
                        account_status='active',
                        company_id=comp.id,
                        password_hash=hash_password(pw_to_hash),
                        password_vault=pw_to_hash,
                        must_change_password=True
                    )
                    db.session.add(created_admin)

            db.session.commit()

            SuperadminService.record_audit(
                action='COMPANY_CREATED_BY_SUPERADMIN',
                category='COMPANY',
                target_company_id=comp.id,
                target_company_name=comp.company_name,
                updated_values={
                    'org_uid': comp.org_uid,
                    'company_name': comp.company_name,
                    'plan_tier': comp.plan_tier,
                    'industry': comp.industry,
                    'admin_provisioned': bool(created_admin)
                },
                details=f"Provisioned new organization '{comp.company_name}' ({comp.org_uid}) via Global Superadmin Control Center.",
                actor_user=actor_user
            )
            return True, f"Organization '{comp.company_name}' ({comp.org_uid}) provisioned successfully.", comp
        except Exception as e:
            db.session.rollback()
            return False, f"Failed to provision organization: {e}", None

    @staticmethod
    def update_company(company_id: int, form_data: dict, logo_file=None):
        comp = db.session.get(Company, company_id)
        if not comp:
            return False, "Organization not found."

        prev = {
            'company_name': comp.company_name,
            'business_name': comp.business_name,
            'owner_name': comp.owner_name,
            'ceo_name': comp.ceo_name,
            'industry': comp.industry,
            'currency': comp.currency,
            'country': comp.country,
            'city': comp.city,
            'email': comp.email,
            'mobile': comp.mobile,
            'website': comp.website,
            'plan_tier': comp.plan_tier,
            'annual_revenue': comp.annual_revenue
        }

        if form_data.get('company_name'):
            comp.company_name = form_data['company_name'].strip()
        if form_data.get('business_name'):
            comp.business_name = form_data['business_name'].strip()
        if form_data.get('owner_name'):
            comp.owner_name = form_data['owner_name'].strip()
        if form_data.get('ceo_name'):
            comp.ceo_name = form_data['ceo_name'].strip()
        if 'industry' in form_data and form_data['industry'] is not None:
            comp.industry = form_data['industry'].strip()
        if 'business_type' in form_data and form_data['business_type'] is not None:
            comp.business_type = form_data['business_type'].strip()
        if 'description' in form_data and form_data['description'] is not None:
            comp.description = form_data['description'].strip()
        if 'currency' in form_data and form_data['currency']:
            comp.currency = form_data['currency'].strip().upper()
        if 'country' in form_data and form_data['country'] is not None:
            comp.country = form_data['country'].strip()
        if 'state' in form_data and form_data['state'] is not None:
            comp.state = form_data['state'].strip()
        if 'city' in form_data and form_data['city'] is not None:
            comp.city = form_data['city'].strip()
        if 'timezone' in form_data and form_data['timezone']:
            comp.timezone = form_data['timezone'].strip()
        if 'email' in form_data and form_data['email'] is not None:
            comp.email = form_data['email'].strip()
        if 'mobile' in form_data and form_data['mobile'] is not None:
            comp.mobile = form_data['mobile'].strip()
        if 'website' in form_data and form_data['website'] is not None:
            comp.website = form_data['website'].strip()
        if 'plan_tier' in form_data and form_data['plan_tier']:
            comp.plan_tier = form_data['plan_tier'].strip()
        if 'status' in form_data and form_data['status'] in ('active', 'suspended', 'archived'):
            new_st = form_data['status'].strip().lower()
            comp.status = new_st
            comp.is_active = (new_st == 'active')
        if 'annual_revenue' in form_data and form_data['annual_revenue'] not in (None, ''):
            try:
                comp.annual_revenue = float(form_data['annual_revenue'])
            except ValueError:
                pass

        if logo_file and getattr(logo_file, 'filename', ''):
            from routes.uploads import validate_and_extract_image, persist_image_asset
            raw_bytes, ext, mime_type, err = validate_and_extract_image(logo_file)
            if err:
                return False, f"Logo validation error: {err}"
            rel_path, b64_data = persist_image_asset(raw_bytes, ext, 'logos', f"company_{comp.id}")
            comp.logo_path = rel_path
            comp.logo_data = b64_data
            comp.logo_mime = mime_type
            comp.logo_updated_at = datetime.utcnow()

        comp.updated_at = datetime.utcnow()
        comp.last_activity_at = datetime.utcnow()
        db.session.commit()

        updated = {
            'company_name': comp.company_name,
            'business_name': comp.business_name,
            'owner_name': comp.owner_name,
            'ceo_name': comp.ceo_name,
            'industry': comp.industry,
            'currency': comp.currency,
            'country': comp.country,
            'city': comp.city,
            'email': comp.email,
            'mobile': comp.mobile,
            'website': comp.website,
            'plan_tier': comp.plan_tier,
            'annual_revenue': comp.annual_revenue
        }

        SuperadminService.record_audit(
            action='COMPANY_UPDATED',
            category='COMPANY',
            target_company_id=comp.id,
            target_company_name=comp.company_name,
            previous_values=prev,
            updated_values=updated,
            details=f"Updated organization profile for '{comp.company_name}' ({comp.organization_code})."
        )
        return True, "Organization details updated successfully."

    @staticmethod
    def change_company_status(company_id: int, new_status: str, reason: str = ''):
        comp = db.session.get(Company, company_id)
        if not comp:
            return False, "Organization not found."

        new_status = (new_status or '').strip().lower()
        if new_status not in ('active', 'suspended', 'archived'):
            return False, "Invalid organization status."

        prev_status = comp.effective_status
        comp.status = new_status
        comp.is_active = (new_status == 'active')

        if new_status == 'suspended':
            comp.suspended_at = datetime.utcnow()
            comp.suspended_reason = (reason or 'Suspended by Global Superadmin').strip()
        elif new_status == 'archived':
            comp.archived_at = datetime.utcnow()
            comp.suspended_reason = (reason or 'Archived by Global Superadmin').strip()
        elif new_status == 'active':
            comp.suspended_at = None
            comp.archived_at = None
            comp.suspended_reason = None

        comp.updated_at = datetime.utcnow()
        db.session.commit()

        action_map = {
            'active': 'COMPANY_REACTIVATED',
            'suspended': 'COMPANY_SUSPENDED',
            'archived': 'COMPANY_ARCHIVED'
        }
        SuperadminService.record_audit(
            action=action_map[new_status],
            category='COMPANY',
            target_company_id=comp.id,
            target_company_name=comp.company_name,
            previous_values={'status': prev_status},
            updated_values={'status': new_status, 'reason': reason},
            details=f"Organization '{comp.company_name}' ({comp.organization_code}) status changed from {prev_status} to {new_status}."
        )
        return True, f"Organization '{comp.company_name}' is now {new_status.upper()}."

    @staticmethod
    def _get_schema_info_via_session():
        """
        Read existing table names, columns, and foreign keys to `users` using ONLY `db.session.execute`
        (the current active session connection) so a second connection is NEVER opened on `db.engine`
        and SQLite never encounters `database is locked`.
        """
        backend = db.engine.url.get_backend_name()
        existing_tables = set()
        table_cols = {}
        user_fks = {}

        if backend == 'sqlite':
            rows = db.session.execute(
                db.text("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
            ).fetchall()
            existing_tables = {r[0] for r in rows}
            for tbl in existing_tables:
                c_rows = db.session.execute(db.text(f'PRAGMA table_info("{tbl}")')).fetchall()
                table_cols[tbl] = {r[1]: {'nullable': not bool(r[3])} for r in c_rows}
                fk_rows = db.session.execute(db.text(f'PRAGMA foreign_key_list("{tbl}")')).fetchall()
                user_fks[tbl] = [r[3] for r in fk_rows if r[2] == 'users']
        else:
            for tbl, tbl_obj in db.metadata.tables.items():
                existing_tables.add(tbl)
                table_cols[tbl] = {c.name: {'nullable': c.nullable} for c in tbl_obj.columns}
                user_fks[tbl] = [fk.parent.name for fk in tbl_obj.foreign_keys if fk.column.table.name == 'users']

        return existing_tables, table_cols, user_fks

    @staticmethod
    def _unlink_foreign_keys_to_users_on_session(existing_tables: set, table_cols: dict, user_fks: dict, user_subquery_sql: str):
        """
        Unlink (if nullable) or remove (if non-nullable) any cross-table foreign key references
        to users matching `user_subquery_sql` using ONLY `db.session.execute`.
        """
        for tbl in existing_tables:
            if tbl in ('users', 'companies', 'global_audit_logs', 'platform_settings'):
                continue
            fk_cols = user_fks.get(tbl, [])
            cols_meta = table_cols.get(tbl, {})
            for col_name in fk_cols:
                is_nullable = cols_meta.get(col_name, {}).get('nullable', True)
                if is_nullable:
                    db.session.execute(
                        db.text(f'UPDATE "{tbl}" SET "{col_name}" = NULL WHERE "{col_name}" IN ({user_subquery_sql})')
                    )
                else:
                    if tbl == 'forecasts' and 'forecast_results' in existing_tables:
                        db.session.execute(
                            db.text(f'DELETE FROM forecast_results WHERE forecast_id IN (SELECT id FROM forecasts WHERE "{col_name}" IN ({user_subquery_sql}))')
                        )
                    elif tbl == 'simulations' and 'simulation_params' in existing_tables:
                        db.session.execute(
                            db.text(f'DELETE FROM simulation_params WHERE simulation_id IN (SELECT id FROM simulations WHERE "{col_name}" IN ({user_subquery_sql}))')
                        )
                    elif tbl == 'scenarios' and 'scenario_steps' in existing_tables:
                        db.session.execute(
                            db.text(f'DELETE FROM scenario_steps WHERE scenario_id IN (SELECT id FROM scenarios WHERE "{col_name}" IN ({user_subquery_sql}))')
                        )
                    elif tbl == 'documents':
                        if 'document_tags' in existing_tables:
                            db.session.execute(
                                db.text(f'DELETE FROM document_tags WHERE document_id IN (SELECT id FROM documents WHERE "{col_name}" IN ({user_subquery_sql}))')
                            )
                        if 'document_versions' in existing_tables:
                            db.session.execute(
                                db.text(f'DELETE FROM document_versions WHERE document_id IN (SELECT id FROM documents WHERE "{col_name}" IN ({user_subquery_sql}))')
                            )
                    elif tbl == 'ai_conversations':
                        if 'ai_tool_executions' in existing_tables:
                            db.session.execute(
                                db.text(f'DELETE FROM ai_tool_executions WHERE conversation_id IN (SELECT id FROM ai_conversations WHERE "{col_name}" IN ({user_subquery_sql}))')
                            )
                        if 'ai_messages' in existing_tables:
                            db.session.execute(
                                db.text(f'DELETE FROM ai_messages WHERE conversation_id IN (SELECT id FROM ai_conversations WHERE "{col_name}" IN ({user_subquery_sql}))')
                            )
                    db.session.execute(
                        db.text(f'DELETE FROM "{tbl}" WHERE "{col_name}" IN ({user_subquery_sql})')
                    )

    @staticmethod
    def _purge_companies_batch(company_ids: list):
        """
        Execute a high-speed, single-connection batch purge of one or many companies
        and all dependent tenant records without ever opening a second DB connection.
        Enforces complete topological dependency cascade and SQLite PRAGMA isolation.
        """
        clean_ints = [int(cid) for cid in company_ids]
        if not clean_ints:
            return
        id_csv = ", ".join(str(cid) for cid in clean_ints)

        existing_tables, table_cols, user_fks = SuperadminService._get_schema_info_via_session()
        is_sqlite = db.engine.url.get_backend_name() == 'sqlite'

        if is_sqlite:
            try:
                db.session.commit()
                db.session.execute(db.text("PRAGMA foreign_keys = OFF;"))
                try:
                    raw_conn = db.session.connection().connection
                    raw_conn.execute("PRAGMA foreign_keys = OFF;")
                except Exception:
                    pass
            except Exception:
                pass

        try:
            # 1. Unlink GLOBAL_SUPERADMIN accounts from target companies first
            if 'users' in existing_tables:
                db.session.execute(
                    db.text(f"UPDATE users SET company_id = NULL WHERE company_id IN ({id_csv}) AND role = :sa_role"),
                    {'sa_role': Role.GLOBAL_SUPERADMIN}
                )

            # 2. Nullify all cross-referential foreign key pointers before deletions
            if 'financial_records' in existing_tables:
                try:
                    db.session.execute(db.text(f"UPDATE financial_records SET department_id = NULL, account_id = NULL WHERE company_id IN ({id_csv})"))
                except Exception:
                    pass
            if 'employees' in existing_tables:
                try:
                    db.session.execute(db.text(f"UPDATE employees SET manager_id = NULL, department_id = NULL, branch_id = NULL WHERE company_id IN ({id_csv})"))
                except Exception:
                    pass
            if 'projects' in existing_tables:
                try:
                    db.session.execute(db.text(f"UPDATE projects SET manager_id = NULL, department_id = NULL WHERE company_id IN ({id_csv})"))
                except Exception:
                    pass
            if 'financial_accounts' in existing_tables:
                try:
                    db.session.execute(db.text(f"UPDATE financial_accounts SET parent_account_id = NULL WHERE company_id IN ({id_csv})"))
                except Exception:
                    pass
            if 'custom_twins' in existing_tables:
                try:
                    db.session.execute(db.text(f"UPDATE custom_twins SET parent_twin_id = NULL WHERE company_id IN ({id_csv})"))
                except Exception:
                    pass
            if 'departments' in existing_tables:
                try:
                    db.session.execute(db.text(f"UPDATE departments SET head_id = NULL WHERE company_id IN ({id_csv})"))
                except Exception:
                    pass

            # 3. Child tables without direct company_id or deep child relations
            child_cleanup_sql = [
                ('ai_tool_executions', 'ai_conversations', f"DELETE FROM ai_tool_executions WHERE conversation_id IN (SELECT id FROM ai_conversations WHERE company_id IN ({id_csv}))"),
                ('ai_messages', 'ai_conversations', f"DELETE FROM ai_messages WHERE conversation_id IN (SELECT id FROM ai_conversations WHERE company_id IN ({id_csv}))"),
                ('simulation_params', 'simulations', f"DELETE FROM simulation_params WHERE simulation_id IN (SELECT id FROM simulations WHERE company_id IN ({id_csv}))"),
                ('forecast_results', 'forecasts', f"DELETE FROM forecast_results WHERE forecast_id IN (SELECT id FROM forecasts WHERE company_id IN ({id_csv}))"),
                ('document_tags', 'documents', f"DELETE FROM document_tags WHERE document_id IN (SELECT id FROM documents WHERE company_id IN ({id_csv}))"),
                ('document_versions', 'documents', f"DELETE FROM document_versions WHERE document_id IN (SELECT id FROM documents WHERE company_id IN ({id_csv}))"),
                ('scenario_steps', 'scenarios', f"DELETE FROM scenario_steps WHERE scenario_id IN (SELECT id FROM scenarios WHERE company_id IN ({id_csv}))"),
                ('risk_factors', 'risks', f"DELETE FROM risk_factors WHERE risk_id IN (SELECT id FROM risks WHERE company_id IN ({id_csv}))"),
                ('inventory_movements', 'inventory', f"DELETE FROM inventory_movements WHERE inventory_id IN (SELECT id FROM inventory WHERE company_id IN ({id_csv}))"),
                ('department_budgets', 'departments', f"DELETE FROM department_budgets WHERE department_id IN (SELECT id FROM departments WHERE company_id IN ({id_csv}))"),
                ('department_invitations', 'departments', f"DELETE FROM department_invitations WHERE department_id IN (SELECT id FROM departments WHERE company_id IN ({id_csv}))"),
            ]
            for child_tbl, parent_tbl, sql_stmt in child_cleanup_sql:
                if child_tbl in existing_tables and parent_tbl in existing_tables:
                    try:
                        db.session.execute(db.text(sql_stmt))
                    except Exception:
                        pass

            # 4. Delete from dependent company_id tables in strict topological reverse-dependency order
            priority_tables = [
                # Leaf tables
                'webhook_deliveries',
                'inventory_movements',
                'department_budgets',
                'department_invitations',
                'twin_dependencies',
                'impact_traces',
                'twin_snapshots',
                'twin_links',
                'twin_audit_logs',
                'custom_twin_records',
                'core_twin_extra_records',
                'business_events',
                # Tables referencing departments, projects, branches, suppliers, accounts
                'financial_records',
                'projects',
                'employees',
                'inventory',
                # Parent entities referenced by the above
                'departments',
                'branches',
                'suppliers',
                'financial_accounts',
                'custom_twins',
                'webhook_subscriptions',
                'company_payments',
                'simulations',
                'forecasts',
                'reports',
                'documents',
                'tags',
                'analytics',
                'scenarios',
                'risks',
                'customers',
                'marketing_campaigns',
                'investments',
                'loans',
                'export_history',
                'import_history',
                'custom_metrics',
                'market_data',
                'competitors',
                'themes',
                'notifications',
                'audit_logs',
                'activity_logs',
                'app_config',
                'api_keys',
                'background_jobs',
                'ai_conversations',
            ]
            for pt in priority_tables:
                if pt in existing_tables and 'company_id' in table_cols.get(pt, {}):
                    try:
                        db.session.execute(db.text(f'DELETE FROM "{pt}" WHERE company_id IN ({id_csv})'))
                    except Exception:
                        pass

            # 5. Delete from remaining non-user tables with a company_id column
            for table_name in existing_tables:
                if table_name in ('companies', 'users', 'global_audit_logs', 'platform_settings') or table_name in priority_tables:
                    continue
                if 'company_id' in table_cols.get(table_name, {}):
                    try:
                        db.session.execute(db.text(f'DELETE FROM "{table_name}" WHERE company_id IN ({id_csv})'))
                    except Exception:
                        pass

            # 6. Safely unlink/clean any remaining cross-tenant references to tenant users of these companies, then delete those users
            if 'users' in existing_tables:
                user_subquery = f"SELECT id FROM users WHERE company_id IN ({id_csv}) AND role != '{Role.GLOBAL_SUPERADMIN}'"
                SuperadminService._unlink_foreign_keys_to_users_on_session(
                    existing_tables,
                    table_cols,
                    user_fks,
                    user_subquery
                )
                db.session.execute(
                    db.text(f"DELETE FROM users WHERE company_id IN ({id_csv}) AND role != :sa_role"),
                    {'sa_role': Role.GLOBAL_SUPERADMIN}
                )

            # 7. Delete the Company rows themselves in one batch statement
            db.session.execute(db.text(f"DELETE FROM companies WHERE id IN ({id_csv})"))
            db.session.expire_all()

        finally:
            if is_sqlite:
                try:
                    db.session.execute(db.text("PRAGMA foreign_keys = ON;"))
                except Exception:
                    pass

    @staticmethod
    def delete_company_permanently(
        company_id: int,
        confirmation_name: str = '',
        superadmin_password: str = '',
        actor_user=None,
        require_exact_name: bool = True,
        require_password: bool = True
    ):
        """
        Controlled permanent deletion of a company:
        1. Verifies actor is GLOBAL_SUPERADMIN.
        2. Verifies exact company_name match (when require_exact_name=True).
        3. Re-authenticates Superadmin password (when require_password=True or when password is provided).
        4. Records full audit trail before/after deletion.
        5. Cleans up dependent tenant records in a single-connection transaction.
        """
        comp = db.session.get(Company, company_id)
        if not comp:
            return False, "Organization not found."

        if not actor_user or not actor_user.is_global_superadmin:
            return False, "Global Superadmin authority required."

        if require_exact_name and (confirmation_name or '').strip() != comp.company_name.strip():
            SuperadminService.record_audit(
                action='COMPANY_PERMANENT_DELETE_FAILED',
                category='COMPANY',
                target_company_id=comp.id,
                target_company_name=comp.company_name,
                result_status='FAILED',
                details='Confirmation company name did not match exactly.',
                actor_user=actor_user
            )
            return False, f"Confirmation failed: You must type the exact company name '{comp.company_name}'."

        if require_password or superadmin_password:
            if not superadmin_password or not verify_password(superadmin_password, actor_user.password_hash):
                SuperadminService.record_audit(
                    action='COMPANY_PERMANENT_DELETE_DENIED',
                    category='SECURITY',
                    target_company_id=comp.id,
                    target_company_name=comp.company_name,
                    result_status='DENIED',
                    details='Superadmin reauthentication password check failed during permanent company deletion.',
                    actor_user=actor_user
                )
                return False, "Reauthentication failed: Invalid Global Superadmin password."

        snapshot = {
            'id': comp.id,
            'org_uid': comp.organization_code,
            'company_name': comp.company_name,
            'owner_name': comp.owner_name,
            'industry': comp.industry,
            'status': comp.effective_status,
            'users_count': User.query.filter_by(company_id=comp.id).count(),
            'departments_count': Department.query.filter_by(company_id=comp.id).count()
        }
        comp_name = comp.company_name
        comp_uid = comp.organization_code

        try:
            SuperadminService._purge_companies_batch([comp.id])
            db.session.commit()

            SuperadminService.record_audit(
                action='COMPANY_PERMANENTLY_DELETED',
                category='COMPANY',
                target_company_id=snapshot['id'],
                target_company_name=comp_name,
                previous_values=snapshot,
                updated_values={'deleted': True},
                details=f"Permanently deleted organization '{comp_name}' ({comp_uid}).",
                actor_user=actor_user
            )
            return True, f"Organization '{comp_name}' ({comp_uid}) has been permanently deleted."
        except Exception as e:
            db.session.rollback()
            return False, f"Permanent deletion error: {e}"

    @staticmethod
    def bulk_companies_action(
        company_ids: list,
        action: str,
        actor_user=None,
        reason: str = '',
        plan_tier: str = '',
        superadmin_password: str = ''
    ):
        """
        Execute bulk administrative operations across selected organizations on a single session connection:
        Supported actions:
          - 'activate' / 'reactivate'
          - 'suspend'
          - 'archive'
          - 'set_tier'
          - 'delete' / 'permanent_delete'
        """
        if not actor_user or not getattr(actor_user, 'is_global_superadmin', False):
            return False, "Global Superadmin authority required.", 0

        clean_ids = []
        for raw_id in (company_ids or []):
            try:
                cid = int(raw_id)
                if cid not in clean_ids:
                    clean_ids.append(cid)
            except (ValueError, TypeError):
                continue

        if not clean_ids:
            return False, "No organization records were selected.", 0

        action = (action or '').strip().lower()
        rows = db.session.query(
            Company.id,
            Company.org_uid,
            Company.company_name,
            Company.status,
            Company.is_active
        ).filter(Company.id.in_(clean_ids)).all()

        if not rows:
            return False, "None of the selected organizations could be found.", 0

        found_ids = [r.id for r in rows]
        id_csv = ", ".join(str(int(cid)) for cid in found_ids)
        affected_names = [r.company_name for r in rows]
        affected_codes = [r.org_uid or f"ORG-AEV-{int(r.id):04d}" for r in rows]

        # Optional password check if provided during bulk delete
        if action in ('delete', 'permanent_delete') and superadmin_password:
            if not verify_password(superadmin_password, actor_user.password_hash):
                SuperadminService.record_audit(
                    action='COMPANY_BULK_DELETE_DENIED',
                    category='SECURITY',
                    result_status='DENIED',
                    details=f"Superadmin password verification failed during bulk delete of {len(found_ids)} organization(s).",
                    actor_user=actor_user
                )
                return False, "Reauthentication failed: Invalid Global Superadmin password.", 0

        now = datetime.utcnow()

        try:
            if action in ('activate', 'reactivate'):
                db.session.execute(
                    db.text(f"UPDATE companies SET status = 'active', is_active = 1, suspended_at = NULL, archived_at = NULL, suspended_reason = NULL, updated_at = :now WHERE id IN ({id_csv})"),
                    {'now': now}
                )
                db.session.expire_all()
                db.session.commit()

                SuperadminService.record_audit(
                    action='COMPANY_BULK_REACTIVATED',
                    category='COMPANY',
                    updated_values={'status': 'active', 'count': len(found_ids), 'org_codes': affected_codes[:30]},
                    details=f"Bulk reactivated {len(found_ids)} organization(s): {', '.join(affected_names[:8])}{'...' if len(affected_names) > 8 else ''}.",
                    actor_user=actor_user
                )
                return True, f"Successfully activated {len(found_ids)} organization(s).", len(found_ids)

            elif action == 'suspend':
                susp_reason = (reason or 'Bulk suspended via Global Superadmin Control Center').strip()
                db.session.execute(
                    db.text(f"UPDATE companies SET status = 'suspended', is_active = 0, suspended_at = :now, suspended_reason = :reason, updated_at = :now WHERE id IN ({id_csv})"),
                    {'now': now, 'reason': susp_reason}
                )
                db.session.expire_all()
                db.session.commit()

                SuperadminService.record_audit(
                    action='COMPANY_BULK_SUSPENDED',
                    category='COMPANY',
                    updated_values={'status': 'suspended', 'reason': susp_reason, 'count': len(found_ids), 'org_codes': affected_codes[:30]},
                    details=f"Bulk suspended {len(found_ids)} organization(s): {', '.join(affected_names[:8])}{'...' if len(affected_names) > 8 else ''}.",
                    actor_user=actor_user
                )
                return True, f"Successfully suspended {len(found_ids)} organization(s).", len(found_ids)

            elif action == 'archive':
                arch_reason = (reason or 'Bulk archived via Global Superadmin Control Center').strip()
                db.session.execute(
                    db.text(f"UPDATE companies SET status = 'archived', is_active = 0, archived_at = :now, suspended_reason = :reason, updated_at = :now WHERE id IN ({id_csv})"),
                    {'now': now, 'reason': arch_reason}
                )
                db.session.expire_all()
                db.session.commit()

                SuperadminService.record_audit(
                    action='COMPANY_BULK_ARCHIVED',
                    category='COMPANY',
                    updated_values={'status': 'archived', 'reason': arch_reason, 'count': len(found_ids), 'org_codes': affected_codes[:30]},
                    details=f"Bulk archived {len(found_ids)} organization(s): {', '.join(affected_names[:8])}{'...' if len(affected_names) > 8 else ''}.",
                    actor_user=actor_user
                )
                return True, f"Successfully archived {len(found_ids)} organization(s).", len(found_ids)

            elif action == 'set_tier':
                target_tier = (plan_tier or 'Enterprise').strip()
                if target_tier not in VALID_PLAN_TIERS:
                    return False, f"Invalid subscription plan tier '{target_tier}'.", 0
                db.session.execute(
                    db.text(f"UPDATE companies SET plan_tier = :tier, updated_at = :now WHERE id IN ({id_csv})"),
                    {'tier': target_tier, 'now': now}
                )
                db.session.expire_all()
                db.session.commit()

                SuperadminService.record_audit(
                    action='COMPANY_BULK_TIER_UPDATED',
                    category='COMPANY',
                    updated_values={'plan_tier': target_tier, 'count': len(found_ids), 'org_codes': affected_codes[:30]},
                    details=f"Updated subscription tier to '{target_tier}' for {len(found_ids)} organization(s).",
                    actor_user=actor_user
                )
                return True, f"Updated plan tier to '{target_tier}' for {len(found_ids)} organization(s).", len(found_ids)

            elif action in ('delete', 'permanent_delete'):
                deleted_snapshots = [
                    {
                        'id': r.id,
                        'org_uid': r.org_uid or f"ORG-AEV-{int(r.id):04d}",
                        'company_name': r.company_name,
                        'status': r.status or ('active' if r.is_active else 'suspended')
                    }
                    for r in rows
                ]
                SuperadminService._purge_companies_batch(found_ids)
                db.session.commit()

                SuperadminService.record_audit(
                    action='COMPANY_BULK_DELETED',
                    category='COMPANY',
                    previous_values={'deleted_companies': deleted_snapshots[:30], 'total_deleted': len(deleted_snapshots)},
                    updated_values={'deleted': True, 'count': len(deleted_snapshots)},
                    details=f"Permanently deleted {len(deleted_snapshots)} organization(s): {', '.join(affected_names[:8])}{'...' if len(affected_names) > 8 else ''}.",
                    actor_user=actor_user
                )
                return True, f"Permanently deleted {len(deleted_snapshots)} selected organization(s) and their associated records.", len(deleted_snapshots)

            else:
                return False, f"Unsupported bulk action '{action}'.", 0

        except Exception as e:
            db.session.rollback()
            return False, f"Bulk operation failed: {e}", 0

    @staticmethod
    def export_companies_csv(
        company_ids: list = None,
        search: str = '',
        status_filter: str = 'all',
        industry_filter: str = '',
        tier_filter: str = '',
        sort_by: str = 'created_desc'
    ) -> str:
        """Export selected or filtered company records to a formatted CSV string."""
        if company_ids:
            clean_ids = [int(i) for i in company_ids if str(i).isdigit()]
            companies = Company.query.filter(Company.id.in_(clean_ids)).order_by(Company.id.asc()).all()
        else:
            query = SuperadminService._build_companies_query(
                search=search,
                status_filter=status_filter,
                industry_filter=industry_filter,
                tier_filter=tier_filter,
                sort_by=sort_by
            )
            companies = query.all()

        out = io.StringIO()
        writer = csv.writer(out)
        writer.writerow([
            'Internal ID',
            'Organization ID',
            'Company Name',
            'Operating Business Name',
            'Administrator / Owner',
            'Administrator Email',
            'CEO Name',
            'Industry',
            'Plan Tier',
            'Lifecycle Status',
            'Users Count',
            'Departments Count',
            'Currency',
            'Target Annual Revenue',
            'Health Score',
            'Country',
            'City',
            'Registered Date',
            'Last Activity'
        ])

        for comp in companies:
            admin_user = User.query.filter_by(company_id=comp.id).order_by(User.is_admin.desc(), User.id.asc()).first()
            user_count = User.query.filter_by(company_id=comp.id).count()
            dept_count = Department.query.filter_by(company_id=comp.id).count()
            writer.writerow([
                comp.id,
                comp.organization_code,
                comp.company_name,
                comp.business_name or comp.company_name,
                admin_user.display_name if admin_user else (comp.owner_name or ''),
                admin_user.email if admin_user else (comp.email or ''),
                comp.ceo_name or '',
                comp.industry or 'Enterprise',
                comp.plan_tier or 'Enterprise',
                comp.effective_status,
                user_count,
                dept_count,
                comp.currency or 'USD',
                f"{float(comp.annual_revenue or 0):.2f}",
                f"{float(comp.health_score or 0):.1f}",
                comp.country or '',
                comp.city or '',
                comp.created_at.strftime('%Y-%m-%d %H:%M:%S') if comp.created_at else '',
                comp.updated_at.strftime('%Y-%m-%d %H:%M:%S') if comp.updated_at else ''
            ])

        return out.getvalue()

    # ──────────────────────────────────────────────────────────────────────
    # 6. GLOBAL USER MANAGEMENT
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def list_users(search: str = '', company_id: int = None, role_filter: str = '', status_filter: str = 'all', page: int = 1, per_page: int = 20):
        query = User.query

        if search:
            like_q = f"%{search.strip()}%"
            query = query.filter(
                or_(
                    User.username.ilike(like_q),
                    User.email.ilike(like_q),
                    User.full_name.ilike(like_q),
                    User.first_name.ilike(like_q),
                    User.last_name.ilike(like_q)
                )
            )

        if company_id:
            query = query.filter(User.company_id == company_id)

        if role_filter:
            query = query.filter(User.role == role_filter)

        if status_filter and status_filter != 'all':
            if status_filter == 'active':
                query = query.filter(User.is_active == True, or_(User.account_status == 'active', User.account_status.is_(None)))
            elif status_filter == 'suspended':
                query = query.filter(User.account_status == 'suspended')
            elif status_filter == 'deactivated':
                query = query.filter(or_(User.is_active == False, User.account_status == 'deactivated'))

        query = query.order_by(User.created_at.desc())
        total = query.count()
        all_matching_ids = [r[0] for r in query.with_entities(User.id).all()]

        effective_per_page = total if (per_page <= 0 or per_page >= 5000) else max(1, per_page)
        effective_per_page = max(1, effective_per_page)
        pages = max(1, (total + effective_per_page - 1) // effective_per_page)
        page = max(1, min(page, pages))

        users = query.offset((page - 1) * effective_per_page).limit(effective_per_page).all()

        return {
            'items': users,
            'records': users,
            'total': total,
            'page': page,
            'per_page': per_page,
            'pages': pages,
            'all_matching_ids': all_matching_ids
        }

    @staticmethod
    def update_user_by_superadmin(target_user_id: int, data: dict):
        user = db.session.get(User, target_user_id)
        if not user:
            return False, "User account not found."

        prev = {
            'username': user.username,
            'email': user.email,
            'full_name': user.display_name,
            'role': user.role,
            'company_id': user.company_id,
            'account_status': user.account_status,
            'is_active': user.is_active
        }

        new_username = (data.get('username') or '').strip()
        if new_username and new_username.lower() != user.username.lower():
            clash = User.query.filter(func.lower(User.username) == new_username.lower(), User.id != user.id).first()
            if clash:
                return False, f"Username '{new_username}' is already taken."
            user.username = new_username

        new_email = (data.get('email') or '').strip()
        if new_email and new_email.lower() != user.email.lower():
            if '@' not in new_email:
                return False, "Invalid email address format."
            clash = User.query.filter(func.lower(User.email) == new_email.lower(), User.id != user.id).first()
            if clash:
                return False, f"Email '{new_email}' is already registered to another user."
            user.email = new_email

        if 'full_name' in data and data['full_name'] is not None:
            user.full_name = data['full_name'].strip()
            parts = user.full_name.split(' ', 1)
            user.first_name = parts[0] if parts else ''
            user.last_name = parts[1] if len(parts) > 1 else ''
        else:
            if 'first_name' in data and data['first_name'] is not None:
                user.first_name = data['first_name'].strip()
            if 'last_name' in data and data['last_name'] is not None:
                user.last_name = data['last_name'].strip()

        if 'job_title' in data and data['job_title'] is not None:
            user.job_title = data['job_title'].strip()
        if 'phone' in data and data['phone'] is not None:
            user.phone = data['phone'].strip()

        if 'company_id' in data and data['company_id'] is not None:
            cid_val = str(data['company_id']).strip()
            if cid_val in ('', 'none', 'null', '0'):
                user.company_id = None
            else:
                try:
                    comp = db.session.get(Company, int(cid_val))
                    if comp:
                        user.company_id = comp.id
                except ValueError:
                    pass

        if 'role' in data and data['role']:
            requested_role = data['role'].strip()
            # Prevent accidentally stripping the sole GLOBAL_SUPERADMIN role
            if user.is_global_superadmin and requested_role != Role.GLOBAL_SUPERADMIN:
                other_sa = User.query.filter(User.role == Role.GLOBAL_SUPERADMIN, User.id != user.id).count()
                if other_sa == 0:
                    return False, "Cannot demote the primary Global Superadmin account."
            if requested_role in COMPANY_ROLES:
                user.role = requested_role
                user.is_admin = requested_role in (Role.OWNER, Role.ADMIN)

        user.updated_at = datetime.utcnow()
        db.session.commit()

        updated = {
            'username': user.username,
            'email': user.email,
            'full_name': user.display_name,
            'role': user.role,
            'company_id': user.company_id,
            'account_status': user.account_status,
            'is_active': user.is_active
        }

        SuperadminService.record_audit(
            action='USER_PROFILE_UPDATED',
            category='USER',
            target_company_id=user.company_id,
            target_company_name=user.company.company_name if user.company else None,
            target_user_id=user.id,
            target_username=user.username,
            previous_values=prev,
            updated_values=updated,
            details=f"Updated user account '{user.username}'."
        )
        return True, f"User '{user.username}' updated successfully."

    @staticmethod
    def change_user_status(target_user_id: int, new_status: str):
        user = db.session.get(User, target_user_id)
        if not user:
            return False, "User not found."

        new_status = (new_status or '').strip().lower()
        if new_status not in ('active', 'suspended', 'deactivated'):
            return False, "Invalid account status."

        if user.is_global_superadmin and new_status != 'active':
            return False, "Cannot suspend or deactivate the Global Superadmin account."

        prev_status = user.account_status or ('active' if user.is_active else 'deactivated')
        user.account_status = new_status
        user.is_active = (new_status == 'active')
        if new_status != 'active':
            user.session_version = (user.session_version or 1) + 1
            UserSessionRecord.query.filter_by(user_id=user.id, is_active=True).update({
                'is_active': False,
                'revoked_at': datetime.utcnow(),
                'revoked_reason': f'Account {new_status} by Global Superadmin'
            })
        else:
            user.locked_until = None
            user.login_attempts = 0

        db.session.commit()

        SuperadminService.record_audit(
            action=f'USER_ACCOUNT_{new_status.upper()}',
            category='USER',
            target_company_id=user.company_id,
            target_company_name=user.company.company_name if user.company else None,
            target_user_id=user.id,
            target_username=user.username,
            previous_values={'account_status': prev_status},
            updated_values={'account_status': new_status},
            details=f"Changed account status for '{user.username}' from {prev_status} to {new_status}."
        )
        return True, f"User '{user.username}' is now {new_status.upper()}."

    @staticmethod
    def delete_user_by_superadmin(target_user_id: int, actor_user=None):
        """Permanently delete a non-superadmin user account and clean up their session/theme records on a single connection."""
        user = db.session.get(User, target_user_id)
        if not user:
            return False, "User not found."

        if user.is_global_superadmin or user.role == Role.GLOBAL_SUPERADMIN:
            return False, "Cannot delete a Global Superadmin account."

        uid = int(user.id)
        uname = user.username
        uemail = user.email
        comp_id = user.company_id
        comp_name = user.company.company_name if user.company else None

        try:
            existing_tables, table_cols, user_fks = SuperadminService._get_schema_info_via_session()
            SuperadminService._unlink_foreign_keys_to_users_on_session(
                existing_tables,
                table_cols,
                user_fks,
                f"SELECT {uid}"
            )
            db.session.execute(db.text(f"DELETE FROM users WHERE id = {uid} AND role != :sa_role"), {'sa_role': Role.GLOBAL_SUPERADMIN})
            db.session.expire_all()
            db.session.commit()

            SuperadminService.record_audit(
                action='USER_ACCOUNT_DELETED',
                category='USER',
                target_company_id=comp_id,
                target_company_name=comp_name,
                target_user_id=target_user_id,
                target_username=uname,
                previous_values={'username': uname, 'email': uemail, 'company_id': comp_id},
                updated_values={'deleted': True},
                details=f"Permanently deleted user account '{uname}' ({uemail}).",
                actor_user=actor_user
            )
            return True, f"User account '{uname}' has been permanently deleted."
        except Exception as e:
            db.session.rollback()
            return False, f"Failed to delete user account: {e}"

    @staticmethod
    def bulk_users_action(user_ids: list, action: str, actor_user=None, role: str = ''):
        """
        Execute bulk administrative operations across selected user accounts on a single connection:
          - 'activate'
          - 'suspend'
          - 'deactivate'
          - 'revoke_sessions'
          - 'set_role'
          - 'delete'
        """
        if not actor_user or not getattr(actor_user, 'is_global_superadmin', False):
            return False, "Global Superadmin authority required.", 0

        clean_ids = []
        for raw_id in (user_ids or []):
            try:
                uid = int(raw_id)
                if uid not in clean_ids:
                    clean_ids.append(uid)
            except (ValueError, TypeError):
                continue

        if not clean_ids:
            return False, "No user accounts were selected.", 0

        action = (action or '').strip().lower()
        users = User.query.filter(User.id.in_(clean_ids)).all()
        if not users:
            return False, "None of the selected user accounts could be found.", 0

        now = datetime.utcnow()
        affected_usernames = []
        skipped_superadmins = 0

        try:
            if action in ('activate', 'suspend', 'deactivate'):
                target_status = 'active' if action == 'activate' else ('suspended' if action == 'suspend' else 'deactivated')
                for u in users:
                    if u.is_global_superadmin and target_status != 'active':
                        skipped_superadmins += 1
                        continue
                    u.account_status = target_status
                    u.is_active = (target_status == 'active')
                    if target_status != 'active':
                        u.session_version = (u.session_version or 1) + 1
                        UserSessionRecord.query.filter_by(user_id=u.id, is_active=True).update({
                            'is_active': False,
                            'revoked_at': now,
                            'revoked_reason': f'Bulk {target_status} by Global Superadmin'
                        })
                    else:
                        u.locked_until = None
                        u.login_attempts = 0
                    u.updated_at = now
                    affected_usernames.append(u.username)

                db.session.commit()
                SuperadminService.record_audit(
                    action=f'USER_BULK_{target_status.upper()}',
                    category='USER',
                    updated_values={'status': target_status, 'count': len(affected_usernames), 'users': affected_usernames[:30]},
                    details=f"Bulk updated {len(affected_usernames)} user account(s) to {target_status.upper()}.",
                    actor_user=actor_user
                )
                msg = f"Updated {len(affected_usernames)} user account(s) to {target_status.upper()}."
                if skipped_superadmins:
                    msg += f" (Protected {skipped_superadmins} Global Superadmin account)."
                return True, msg, len(affected_usernames)

            elif action == 'revoke_sessions':
                for u in users:
                    u.session_version = (u.session_version or 1) + 1
                    UserSessionRecord.query.filter_by(user_id=u.id, is_active=True).update({
                        'is_active': False,
                        'revoked_at': now,
                        'revoked_reason': 'Bulk session revocation by Global Superadmin'
                    })
                    affected_usernames.append(u.username)
                db.session.commit()
                SuperadminService.record_audit(
                    action='USER_BULK_SESSIONS_REVOKED',
                    category='SECURITY',
                    updated_values={'count': len(affected_usernames), 'users': affected_usernames[:30]},
                    details=f"Revoked active sessions for {len(affected_usernames)} user account(s).",
                    actor_user=actor_user
                )
                return True, f"Revoked active sessions for {len(affected_usernames)} user(s).", len(affected_usernames)

            elif action == 'set_role':
                target_role = (role or '').strip()
                if target_role not in COMPANY_ROLES:
                    return False, f"Invalid role '{target_role}'.", 0
                for u in users:
                    if u.is_global_superadmin:
                        skipped_superadmins += 1
                        continue
                    u.role = target_role
                    u.is_admin = target_role in (Role.OWNER, Role.ADMIN)
                    u.updated_at = now
                    affected_usernames.append(u.username)
                db.session.commit()
                SuperadminService.record_audit(
                    action='USER_BULK_ROLE_UPDATED',
                    category='USER',
                    updated_values={'role': target_role, 'count': len(affected_usernames), 'users': affected_usernames[:30]},
                    details=f"Assigned role '{target_role}' to {len(affected_usernames)} user account(s).",
                    actor_user=actor_user
                )
                return True, f"Updated role to '{target_role}' for {len(affected_usernames)} user(s).", len(affected_usernames)

            elif action in ('delete', 'permanent_delete'):
                deletable_ids = []
                for u in users:
                    if u.is_global_superadmin or u.role == Role.GLOBAL_SUPERADMIN:
                        skipped_superadmins += 1
                        continue
                    affected_usernames.append(u.username)
                    deletable_ids.append(int(u.id))

                if deletable_ids:
                    uid_csv = ", ".join(str(uid) for uid in deletable_ids)
                    existing_tables, table_cols, user_fks = SuperadminService._get_schema_info_via_session()
                    SuperadminService._unlink_foreign_keys_to_users_on_session(
                        existing_tables,
                        table_cols,
                        user_fks,
                        f"SELECT id FROM users WHERE id IN ({uid_csv}) AND role != '{Role.GLOBAL_SUPERADMIN}'"
                    )
                    db.session.execute(
                        db.text(f"DELETE FROM users WHERE id IN ({uid_csv}) AND role != :sa_role"),
                        {'sa_role': Role.GLOBAL_SUPERADMIN}
                    )
                    db.session.expire_all()
                db.session.commit()

                SuperadminService.record_audit(
                    action='USER_BULK_DELETED',
                    category='USER',
                    updated_values={'deleted_count': len(affected_usernames), 'users': affected_usernames[:30]},
                    details=f"Permanently deleted {len(affected_usernames)} user account(s): {', '.join(affected_usernames[:8])}{'...' if len(affected_usernames) > 8 else ''}.",
                    actor_user=actor_user
                )
                msg = f"Permanently deleted {len(affected_usernames)} user account(s)."
                if skipped_superadmins:
                    msg += f" (Protected {skipped_superadmins} Global Superadmin account)."
                return True, msg, len(affected_usernames)

            else:
                return False, f"Unsupported bulk user action '{action}'.", 0

        except Exception as e:
            db.session.rollback()
            return False, f"Bulk user operation failed: {e}", 0

    @staticmethod
    def revoke_user_sessions(target_user_id: int, reason: str = 'Revoked by Global Superadmin'):
        user = db.session.get(User, target_user_id)
        if not user:
            return False, "User not found."

        user.session_version = (user.session_version or 1) + 1
        active_rows = UserSessionRecord.query.filter_by(user_id=user.id, is_active=True).all()
        for row in active_rows:
            row.is_active = False
            row.revoked_at = datetime.utcnow()
            row.revoked_reason = reason
        db.session.commit()

        SuperadminService.record_audit(
            action='USER_SESSIONS_REVOKED',
            category='SECURITY',
            target_company_id=user.company_id,
            target_user_id=user.id,
            target_username=user.username,
            updated_values={'session_version': user.session_version, 'revoked_sessions': len(active_rows)},
            details=f"Revoked all active sessions for user '{user.username}'."
        )
        return True, f"Revoked all active sessions for '{user.username}'."

    @staticmethod
    def set_temporary_password_by_superadmin(target_user_id: int, temp_password: str, superadmin_password: str = '', actor_user=None, force_change: bool = False):
        """
        Administrator password update and vault storage:
        - Allows Global Superadmin to set or reset a company user's password directly.
        - Updates both password_hash and the reversible password_vault.
        - Optionally toggles must_change_password and updates audit records.
        """
        user = db.session.get(User, target_user_id)
        if not user:
            return False, "Target user not found."

        if not actor_user or not getattr(actor_user, 'is_global_superadmin', False):
            return False, "Global Superadmin authority required."

        if superadmin_password and not verify_password(superadmin_password, actor_user.password_hash):
            SuperadminService.record_audit(
                action='USER_PASSWORD_RESET_DENIED',
                category='SECURITY',
                target_user_id=user.id,
                target_username=user.username,
                result_status='DENIED',
                details='Superadmin reauthentication failed during administrator password reset.'
            )
            return False, "Reauthentication failed: Invalid Global Superadmin password."

        clean_temp = (temp_password or '').strip()
        if len(clean_temp) < 6:
            return False, "Password must be at least 6 characters long."

        user.set_password(clean_temp)
        user.must_change_password = bool(force_change)
        user.login_attempts = 0
        user.locked_until = None
        user.session_version = (user.session_version or 1) + 1
        UserSessionRecord.query.filter_by(user_id=user.id, is_active=True).update({
            'is_active': False,
            'revoked_at': datetime.utcnow(),
            'revoked_reason': 'Administrator password update'
        })
        db.session.commit()

        SuperadminService.record_audit(
            action='USER_PASSWORD_VAULT_UPDATED',
            category='SECURITY',
            target_company_id=user.company_id,
            target_user_id=user.id,
            target_username=user.username,
            updated_values={'must_change_password': user.must_change_password, 'session_version': user.session_version},
            details=f"Global Superadmin updated password credentials for '{user.username}'."
        )
        return True, f"Credentials updated successfully for '{user.username}'."

    # ──────────────────────────────────────────────────────────────────────
    # 7. RFC 6238 TOTP MFA & SESSION TRACKING
    # ──────────────────────────────────────────────────────────────────────
    @staticmethod
    def generate_totp_secret() -> str:
        return base64.b32encode(secrets.token_bytes(20)).decode('ascii').rstrip('=')

    @staticmethod
    def compute_totp_code(secret: str, timestamp: int = None) -> str:
        if not secret:
            return ''
        pad = '=' * (-len(secret) % 8)
        key = base64.b32decode((secret.upper() + pad).encode('ascii'), casefold=True)
        counter = int((timestamp or time.time()) // 30)
        msg = struct.pack('>Q', counter)
        digest = hmac.new(key, msg, hashlib.sha1).digest()
        offset = digest[-1] & 0x0F
        code = (struct.unpack('>I', digest[offset:offset + 4])[0] & 0x7FFFFFFF) % 1000000
        return f"{code:06d}"

    @staticmethod
    def verify_totp_code(secret: str, candidate: str) -> bool:
        clean = (candidate or '').strip().replace(' ', '')
        if not secret or len(clean) != 6 or not clean.isdigit():
            return False
        now = int(time.time())
        for drift in (-30, 0, 30):
            if hmac.compare_digest(SuperadminService.compute_totp_code(secret, now + drift), clean):
                return True
        return False

    @staticmethod
    def record_login_session(user: User, ip_address: str = None, user_agent: str = None) -> str:
        token = secrets.token_hex(24)
        ua_str = (user_agent or '')[:250]
        device = 'Desktop Browser'
        if 'Mobile' in ua_str or 'Android' in ua_str or 'iPhone' in ua_str:
            device = 'Mobile Browser'
        elif 'Macintosh' in ua_str:
            device = 'macOS Workstation'
        elif 'Windows' in ua_str:
            device = 'Windows Workstation'
        elif 'Linux' in ua_str:
            device = 'Linux Workstation'

        rec = UserSessionRecord(
            session_token=token,
            user_id=user.id,
            company_id=user.company_id,
            ip_address=ip_address,
            user_agent=ua_str,
            device_label=device,
            is_active=True
        )
        db.session.add(rec)
        user.last_ip = ip_address
        db.session.commit()
        session['session_record_token'] = token
        session['session_version'] = user.session_version or 1
        return token

    @staticmethod
    def terminate_other_sessions(user: User, current_token: str = None):
        q = UserSessionRecord.query.filter_by(user_id=user.id, is_active=True)
        if current_token:
            q = q.filter(UserSessionRecord.session_token != current_token)
        rows = q.all()
        for r in rows:
            r.is_active = False
            r.revoked_at = datetime.utcnow()
            r.revoked_reason = 'Terminated by account owner'
        user.session_version = (user.session_version or 1) + 1
        session['session_version'] = user.session_version
        db.session.commit()

        SuperadminService.record_audit(
            action='SUPERADMIN_OTHER_SESSIONS_TERMINATED',
            category='SECURITY',
            target_user_id=user.id,
            target_username=user.username,
            updated_values={'terminated_count': len(rows), 'new_session_version': user.session_version},
            details=f"Terminated {len(rows)} other active session(s) for '{user.username}'."
        )
        return len(rows)
