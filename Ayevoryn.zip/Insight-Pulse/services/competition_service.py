from typing import List, Dict, Any, Optional
from datetime import datetime
from database.db import db
from database.models.competitor import Competitor
from database.models.company import Company
from database.models.market_data import MarketData
from services.auth_service import AuthService
from services.events import EventBus, EventTypes, DomainEvent


class CompetitionService:
    """
    Enterprise Competition Service - Honest Competitive Landscape Management.
    Eliminates all silent synthetic DB seeding and randomized fabrications.
    Provides deterministic calculations, full CRUD, CSV/JSON imports, and
    transparent reference benchmark loading.
    """

    COMPETITOR_TEMPLATES = {
        'Technology': [
            {'name': 'NexGen Solutions', 'position': 'Market Leader', 'base_share': 18.5, 'size_mult': 2.5},
            {'name': 'CloudFirst Inc', 'position': 'Challenger', 'base_share': 12.3, 'size_mult': 1.8},
            {'name': 'DevStack Labs', 'position': 'Niche Player', 'base_share': 4.2, 'size_mult': 0.6},
            {'name': 'ByteForge Systems', 'position': 'Emerging', 'base_share': 2.8, 'size_mult': 0.4},
        ],
        'Manufacturing': [
            {'name': 'IndustrialCore Corp', 'position': 'Market Leader', 'base_share': 22.1, 'size_mult': 3.2},
            {'name': 'PrecisionWorks Ltd', 'position': 'Challenger', 'base_share': 14.7, 'size_mult': 2.1},
            {'name': 'EcoMakers Alliance', 'position': 'Niche Player', 'base_share': 5.5, 'size_mult': 0.7},
            {'name': 'RapidFab Industries', 'position': 'Emerging', 'base_share': 3.1, 'size_mult': 0.5},
        ],
        'Retail': [
            {'name': 'MegaMart Global', 'position': 'Market Leader', 'base_share': 28.4, 'size_mult': 4.5},
            {'name': 'ShopDirect Co', 'position': 'Challenger', 'base_share': 15.2, 'size_mult': 2.3},
            {'name': 'BoutiqueHub', 'position': 'Niche Player', 'base_share': 3.8, 'size_mult': 0.5},
            {'name': 'QuickBuy Express', 'position': 'Emerging', 'base_share': 2.4, 'size_mult': 0.4},
        ],
        'E-Commerce': [
            {'name': 'GlobalCart Inc', 'position': 'Market Leader', 'base_share': 25.6, 'size_mult': 3.8},
            {'name': 'SwiftMarket', 'position': 'Challenger', 'base_share': 13.9, 'size_mult': 2.0},
            {'name': 'ShopifyRival', 'position': 'Niche Player', 'base_share': 4.5, 'size_mult': 0.6},
            {'name': 'MicroStore Network', 'position': 'Emerging', 'base_share': 1.9, 'size_mult': 0.3},
        ],
        'Healthcare': [
            {'name': 'MediCare Systems', 'position': 'Market Leader', 'base_share': 19.8, 'size_mult': 2.9},
            {'name': 'HealthFirst Tech', 'position': 'Challenger', 'base_share': 11.4, 'size_mult': 1.7},
            {'name': 'BioNova Labs', 'position': 'Niche Player', 'base_share': 3.9, 'size_mult': 0.5},
            {'name': 'CureFast Inc', 'position': 'Emerging', 'base_share': 2.1, 'size_mult': 0.3},
        ],
        'Finance': [
            {'name': 'CapitalTrust Bank', 'position': 'Market Leader', 'base_share': 21.3, 'size_mult': 3.5},
            {'name': 'FinEdge Partners', 'position': 'Challenger', 'base_share': 12.8, 'size_mult': 1.9},
            {'name': 'MicroLend Pro', 'position': 'Niche Player', 'base_share': 4.1, 'size_mult': 0.6},
            {'name': 'CryptoVault Inc', 'position': 'Emerging', 'base_share': 1.7, 'size_mult': 0.25},
        ],
        'Logistics': [
            {'name': 'FastFreight Global', 'position': 'Market Leader', 'base_share': 17.9, 'size_mult': 2.7},
            {'name': 'RouteMaster Corp', 'position': 'Challenger', 'base_share': 10.5, 'size_mult': 1.6},
            {'name': 'LastMile Pro', 'position': 'Niche Player', 'base_share': 5.2, 'size_mult': 0.7},
            {'name': 'DroneShip Inc', 'position': 'Emerging', 'base_share': 2.6, 'size_mult': 0.4},
        ],
        'Education': [
            {'name': 'EduWorld Global', 'position': 'Market Leader', 'base_share': 16.2, 'size_mult': 2.4},
            {'name': 'LearnFast Academy', 'position': 'Challenger', 'base_share': 9.7, 'size_mult': 1.5},
            {'name': 'SkillForge', 'position': 'Niche Player', 'base_share': 3.5, 'size_mult': 0.5},
            {'name': 'NanoLearn Labs', 'position': 'Emerging', 'base_share': 1.8, 'size_mult': 0.3},
        ],
        'Consulting': [
            {'name': 'StrategyFirst Partners', 'position': 'Market Leader', 'base_share': 15.4, 'size_mult': 2.2},
            {'name': 'AdvisoryCore Inc', 'position': 'Challenger', 'base_share': 8.9, 'size_mult': 1.4},
            {'name': 'NicheConsult Pro', 'position': 'Niche Player', 'base_share': 4.8, 'size_mult': 0.6},
            {'name': 'AgileMinds Group', 'position': 'Emerging', 'base_share': 2.3, 'size_mult': 0.35},
        ],
        'Food & Beverage': [
            {'name': 'GourmetChain Corp', 'position': 'Market Leader', 'base_share': 20.1, 'size_mult': 3.1},
            {'name': 'FreshDirect Co', 'position': 'Challenger', 'base_share': 11.6, 'size_mult': 1.8},
            {'name': 'OrganicEats Ltd', 'position': 'Niche Player', 'base_share': 4.3, 'size_mult': 0.6},
            {'name': 'QuickBite Labs', 'position': 'Emerging', 'base_share': 2.0, 'size_mult': 0.3},
        ],
        'Real Estate': [
            {'name': 'PrimeProperty Group', 'position': 'Market Leader', 'base_share': 14.8, 'size_mult': 2.3},
            {'name': 'UrbanSpace Inc', 'position': 'Challenger', 'base_share': 9.2, 'size_mult': 1.5},
            {'name': 'EcoLiving Dev', 'position': 'Niche Player', 'base_share': 3.7, 'size_mult': 0.5},
            {'name': 'PropTech Ventures', 'position': 'Emerging', 'base_share': 1.6, 'size_mult': 0.25},
        ],
        'Energy': [
            {'name': 'PowerGrid International', 'position': 'Market Leader', 'base_share': 23.5, 'size_mult': 3.6},
            {'name': 'GreenWatt Energy', 'position': 'Challenger', 'base_share': 13.1, 'size_mult': 2.0},
            {'name': 'SolarNova Corp', 'position': 'Niche Player', 'base_share': 5.8, 'size_mult': 0.8},
            {'name': 'FusionFuture Inc', 'position': 'Emerging', 'base_share': 2.2, 'size_mult': 0.3},
        ],
        'Agriculture': [
            {'name': 'AgriGlobal Corp', 'position': 'Market Leader', 'base_share': 18.7, 'size_mult': 2.8},
            {'name': 'CropMax Systems', 'position': 'Challenger', 'base_share': 10.4, 'size_mult': 1.6},
            {'name': 'OrganicHarvest Co', 'position': 'Niche Player', 'base_share': 4.6, 'size_mult': 0.6},
            {'name': 'SmartFarm Tech', 'position': 'Emerging', 'base_share': 2.1, 'size_mult': 0.35},
        ],
    }

    DEFAULT_COMPETITORS = [
        {'name': 'AlphaCorp Industries', 'position': 'Market Leader', 'base_share': 20.0, 'size_mult': 3.0},
        {'name': 'Beta Solutions Ltd', 'position': 'Challenger', 'base_share': 12.0, 'size_mult': 1.8},
        {'name': 'Gamma Ventures', 'position': 'Niche Player', 'base_share': 4.0, 'size_mult': 0.5},
        {'name': 'Delta Innovations', 'position': 'Emerging', 'base_share': 2.0, 'size_mult': 0.3},
    ]

    @staticmethod
    def get_competitors(company_id: int) -> List[Competitor]:
        """
        Fetch existing competitors strictly from the database.
        Zero silent synthetic auto-seeding.
        """
        return Competitor.query.filter_by(company_id=company_id).order_by(
            Competitor.market_share.desc(), Competitor.id.asc()
        ).all()

    @staticmethod
    def get_or_create_competitors(company_id: int) -> List[Competitor]:
        """
        Backward-compatible alias for get_competitors.
        Does NOT silently seed or mutate the database.
        """
        return CompetitionService.get_competitors(company_id)

    @staticmethod
    def create_competitor(
        company_id: int,
        data: Dict[str, Any],
        actor_user_id: Optional[int] = None
    ) -> Competitor:
        """
        Manually create a new verified competitor for a company.
        """
        name = str(data.get('name', '')).strip()
        if not name:
            raise ValueError("Competitor name is required.")

        market_position = data.get('market_position') or 'Challenger'
        strengths = data.get('strengths') or CompetitionService._generate_strengths(market_position)
        weaknesses = data.get('weaknesses') or CompetitionService._generate_weaknesses(market_position)
        pricing = data.get('pricing_strategy') or CompetitionService._generate_pricing(market_position)

        comp = Competitor(
            company_id=company_id,
            name=name,
            website=data.get('website'),
            industry=data.get('industry'),
            market_share=float(data.get('market_share', 0.0) or 0.0),
            revenue_estimate=float(data.get('revenue_estimate', 0.0) or 0.0),
            employee_count=int(data.get('employee_count', 0) or 0),
            strengths=strengths,
            weaknesses=weaknesses,
            pricing_strategy=pricing,
            market_position=market_position,
            threat_level=data.get('threat_level', 'medium'),
            source=data.get('source', 'MANUAL'),
            is_benchmark=bool(data.get('is_benchmark', False)),
            notes=data.get('notes')
        )
        db.session.add(comp)
        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'competitor_created',
                f"Created competitor '{name}' for company {company_id}"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.COMPETITOR_CREATED,
            company_id=company_id,
            aggregate_type='competitor',
            aggregate_id=f'comp-{comp.id}',
            payload=comp.to_dict(),
            actor_id=actor_user_id
        ))

        return comp

    @staticmethod
    def update_competitor(
        company_id: int,
        competitor_id: int,
        data: Dict[str, Any],
        actor_user_id: Optional[int] = None
    ) -> Optional[Competitor]:
        """
        Update an existing competitor with strict tenant isolation.
        """
        comp = Competitor.query.filter_by(id=competitor_id, company_id=company_id).first()
        if not comp:
            return None

        if 'name' in data and data['name']:
            comp.name = str(data['name']).strip()
        if 'website' in data:
            comp.website = data['website']
        if 'industry' in data:
            comp.industry = data['industry']
        if 'market_share' in data and data['market_share'] is not None:
            comp.market_share = float(data['market_share'])
        if 'revenue_estimate' in data and data['revenue_estimate'] is not None:
            comp.revenue_estimate = float(data['revenue_estimate'])
        if 'employee_count' in data and data['employee_count'] is not None:
            comp.employee_count = int(data['employee_count'])
        if 'market_position' in data and data['market_position']:
            comp.market_position = data['market_position']
        if 'threat_level' in data and data['threat_level']:
            comp.threat_level = data['threat_level']
        if 'strengths' in data:
            comp.strengths = data['strengths']
        if 'weaknesses' in data:
            comp.weaknesses = data['weaknesses']
        if 'pricing_strategy' in data:
            comp.pricing_strategy = data['pricing_strategy']
        if 'notes' in data:
            comp.notes = data['notes']

        comp.updated_at = datetime.utcnow()
        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'competitor_updated',
                f"Updated competitor '{comp.name}' (id: {comp.id})"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.COMPETITOR_UPDATED,
            company_id=company_id,
            aggregate_type='competitor',
            aggregate_id=f'comp-{comp.id}',
            payload=comp.to_dict(),
            actor_id=actor_user_id
        ))

        return comp

    @staticmethod
    def delete_competitor(
        company_id: int,
        competitor_id: int,
        actor_user_id: Optional[int] = None
    ) -> bool:
        """
        Delete a competitor with strict tenant isolation.
        """
        comp = Competitor.query.filter_by(id=competitor_id, company_id=company_id).first()
        if not comp:
            return False

        comp_name = comp.name
        db.session.delete(comp)
        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'competitor_deleted',
                f"Deleted competitor '{comp_name}' (id: {competitor_id})"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.COMPETITOR_DELETED,
            company_id=company_id,
            aggregate_type='competitor',
            aggregate_id=f'comp-{competitor_id}',
            payload={'id': competitor_id, 'name': comp_name},
            actor_id=actor_user_id
        ))

        return True

    @staticmethod
    def import_competitors(
        company_id: int,
        records: List[Dict[str, Any]],
        actor_user_id: Optional[int] = None
    ) -> List[Competitor]:
        """
        Bulk import competitors from structured dictionary records.
        """
        created = []
        for rec in records:
            name = str(rec.get('name', '')).strip()
            if not name:
                continue

            market_position = rec.get('market_position') or 'Challenger'
            comp = Competitor(
                company_id=company_id,
                name=name,
                website=rec.get('website'),
                industry=rec.get('industry'),
                market_share=float(rec.get('market_share', 0.0) or 0.0),
                revenue_estimate=float(rec.get('revenue_estimate', 0.0) or 0.0),
                employee_count=int(rec.get('employee_count', 0) or 0),
                strengths=rec.get('strengths') or CompetitionService._generate_strengths(market_position),
                weaknesses=rec.get('weaknesses') or CompetitionService._generate_weaknesses(market_position),
                pricing_strategy=rec.get('pricing_strategy') or CompetitionService._generate_pricing(market_position),
                market_position=market_position,
                threat_level=rec.get('threat_level', 'medium'),
                source='IMPORT',
                is_benchmark=False,
                notes=rec.get('notes')
            )
            db.session.add(comp)
            created.append(comp)

        if created:
            db.session.commit()

            if actor_user_id:
                AuthService.log_action(
                    actor_user_id,
                    'competitors_imported',
                    f"Imported {len(created)} competitors for company {company_id}"
                )

            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.COMPETITOR_CREATED,
                company_id=company_id,
                aggregate_type='competitor',
                aggregate_id=f'comp-import-{company_id}',
                payload={'imported_count': len(created)},
                actor_id=actor_user_id
            ))

        return created

    @staticmethod
    def load_industry_benchmark_templates(
        company_id: int,
        industry: Optional[str] = None,
        actor_user_id: Optional[int] = None
    ) -> List[Competitor]:
        """
        Explicit, user-initiated action to load standard industry reference templates.
        All entries are explicitly labeled source='BENCHMARK_TEMPLATE' and is_benchmark=True.
        Zero silent background seeding.
        """
        company = Company.query.get(company_id)
        if not company:
            return []

        ind = industry or company.industry or 'Other'
        company_revenue = float(company.annual_revenue or 1000000)
        company_employees = int(company.employee_count or 50)

        templates = CompetitionService.COMPETITOR_TEMPLATES.get(
            ind, CompetitionService.DEFAULT_COMPETITORS
        )

        created = []
        for tmpl in templates:
            share = float(tmpl['base_share'])
            revenue = round(company_revenue * float(tmpl['size_mult']), 2)
            employees = max(1, int(company_employees * float(tmpl['size_mult'])))

            revenue_ratio = revenue / max(company_revenue, 1.0)
            if revenue_ratio > 2.0:
                threat = 'high'
            elif revenue_ratio > 0.8:
                threat = 'medium'
            else:
                threat = 'low'

            clean_name = tmpl['name']
            clean_domain = clean_name.lower().replace(' ', '').replace('.', '').replace('&', 'and')

            comp = Competitor(
                company_id=company_id,
                name=clean_name,
                threat_level=threat,
                market_share=share,
                revenue_estimate=revenue,
                employee_count=employees,
                market_position=tmpl['position'],
                industry=ind,
                website=f"https://{clean_domain}.com",
                strengths=CompetitionService._generate_strengths(tmpl['position']),
                weaknesses=CompetitionService._generate_weaknesses(tmpl['position']),
                pricing_strategy=CompetitionService._generate_pricing(tmpl['position']),
                source='BENCHMARK_TEMPLATE',
                is_benchmark=True,
                notes=f"Reference benchmark template for {ind} sector."
            )
            db.session.add(comp)
            created.append(comp)

        db.session.commit()

        if actor_user_id:
            AuthService.log_action(
                actor_user_id,
                'competitor_templates_loaded',
                f"Loaded {len(created)} benchmark competitor templates for industry '{ind}'"
            )

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.COMPETITOR_TEMPLATES_LOADED,
            company_id=company_id,
            aggregate_type='competitor',
            aggregate_id=f'comp-tmpl-{company_id}',
            payload={'templates_count': len(created), 'industry': ind},
            actor_id=actor_user_id
        ))

        return created

    @staticmethod
    def refresh_competitors(company_id: int) -> List[Competitor]:
        """
        Legacy refresh method: Re-initializes benchmark templates deterministically.
        """
        Competitor.query.filter_by(company_id=company_id, is_benchmark=True).delete()
        db.session.commit()
        return CompetitionService.load_industry_benchmark_templates(company_id)

    @staticmethod
    def get_competition_summary(company_id: int) -> Optional[Dict[str, Any]]:
        """
        Build deterministic competitive analysis summary.
        If no competitors exist, returns an honest onboarding summary structure
        without mutating the database.
        """
        company = Company.query.get(company_id)
        if not company:
            return None

        competitors = CompetitionService.get_competitors(company_id)
        company_revenue = float(company.annual_revenue or 1000000)
        company_employees = int(company.employee_count or 50)
        company_name = company.company_name or 'Your Company'

        if not competitors:
            return {
                'competitors': [],
                'has_competitors': False,
                'total_market': round(company_revenue / 0.70, 0),
                'company_revenue': company_revenue,
                'company_employees': company_employees,
                'company_share': 70.0,
                'company_rank': 1,
                'company_name': company_name,
                'total_competitors': 0,
                'high_threats': 0,
                'medium_threats': 0,
                'low_threats': 0,
                'market_leader': None,
                'revenue_gap': 0.0,
                'gap_pct': 0.0,
                'avg_comp_revenue': 0.0,
                'avg_comp_employees': 0.0,
                'avg_comp_share': 0.0,
                'intensity': 'Unassessed',
                'intensity_desc': 'Zero competitors tracked. Add competitors or load industry templates to evaluate market share and competitive intensity.',
                'intensity_color': 'info',
                'position_advice': "Add competitors or load reference benchmark profiles to benchmark your market position.",
                'threat_advice': "No external competitive threats currently configured.",
                'total_tracked_share': 0.0,
                'industry': company.industry or 'Other',
                'generated_at': datetime.utcnow().strftime('%B %d, %Y')
            }

        tam_record = MarketData.query.filter(
            MarketData.company_id == company_id,
            MarketData.metric_name.in_(['Total Addressable Market (TAM)', 'TAM'])
        ).first()

        total_competitor_revenue = sum(float(c.revenue_estimate or 0.0) for c in competitors)
        if tam_record and tam_record.metric_value and float(tam_record.metric_value) > 0:
            total_market = float(tam_record.metric_value)
        else:
            total_market = (company_revenue + total_competitor_revenue) / 0.70

        company_share = (company_revenue / total_market * 100.0) if total_market > 0 else 0.0

        all_revenues = [(c.name, float(c.revenue_estimate or 0.0)) for c in competitors] + [
            (company_name, company_revenue)
        ]
        all_revenues.sort(key=lambda x: (-x[1], x[0]))
        company_rank = next(
            (i + 1 for i, (name, _) in enumerate(all_revenues) if name == company_name),
            len(all_revenues)
        )

        total_competitors = len(competitors)
        high_threats = sum(1 for c in competitors if c.threat_level == 'high')
        medium_threats = sum(1 for c in competitors if c.threat_level == 'medium')
        low_threats = sum(1 for c in competitors if c.threat_level == 'low')

        leader = max(competitors, key=lambda c: float(c.revenue_estimate or 0.0))
        leader_rev = float(leader.revenue_estimate or 0.0)
        revenue_gap = leader_rev - company_revenue
        gap_pct = (revenue_gap / max(company_revenue, 1.0)) * 100.0

        avg_comp_revenue = total_competitor_revenue / total_competitors if total_competitors else 0.0
        avg_comp_employees = (
            sum(c.employee_count or 0 for c in competitors) / total_competitors
        ) if total_competitors else 0.0
        avg_comp_share = (
            sum(float(c.market_share or 0.0) for c in competitors) / total_competitors
        ) if total_competitors else 0.0

        total_tracked_share = sum(float(c.market_share or 0.0) for c in competitors) + company_share

        if total_tracked_share > 80:
            intensity = 'High'
            intensity_desc = 'The market is highly concentrated. Gaining share requires direct capture from established incumbents.'
            intensity_color = 'danger'
        elif total_tracked_share > 50:
            intensity = 'Moderate'
            intensity_desc = 'Fragmented market with room for growth, though key players are actively staking claims.'
            intensity_color = 'warning'
        else:
            intensity = 'Low'
            intensity_desc = 'Highly fragmented market. Growth can be driven by capturing unclaimed demand rather than direct displacement.'
            intensity_color = 'success'

        if company_rank == 1:
            position_advice = "You are the revenue leader in this tracked set. Focus on margin defense and ecosystem retention."
        elif company_rank <= 3:
            position_advice = f"You rank #{company_rank} among tracked competitors. Focus on differentiation to close the gap with the leader."
        else:
            position_advice = f"You rank #{company_rank}. Consider niche specialization or acquisition to accelerate market position."

        if high_threats > 0:
            threat_advice = f"{high_threats} high-threat competitor(s) detected. Monitor their pricing and feature velocity closely."
        elif medium_threats > 0:
            threat_advice = f"{medium_threats} medium-threat competitor(s). Maintain competitive parity while investing in high-margin differentiation."
        else:
            threat_advice = "Low immediate threat from tracked competitors. Favorable window for aggressive growth investment."

        return {
            'competitors': competitors,
            'has_competitors': True,
            'total_market': round(total_market, 0),
            'company_revenue': company_revenue,
            'company_employees': company_employees,
            'company_name': company_name,
            'company_share': round(company_share, 2),
            'company_rank': company_rank,
            'total_competitors': total_competitors,
            'high_threats': high_threats,
            'medium_threats': medium_threats,
            'low_threats': low_threats,
            'market_leader': leader,
            'revenue_gap': round(revenue_gap, 0),
            'gap_pct': round(gap_pct, 1),
            'avg_comp_revenue': round(avg_comp_revenue, 0),
            'avg_comp_employees': round(avg_comp_employees, 0),
            'avg_comp_share': round(avg_comp_share, 1),
            'intensity': intensity,
            'intensity_desc': intensity_desc,
            'intensity_color': intensity_color,
            'position_advice': position_advice,
            'threat_advice': threat_advice,
            'total_tracked_share': round(total_tracked_share, 1),
            'industry': company.industry or 'Other',
            'generated_at': datetime.utcnow().strftime('%B %d, %Y')
        }

    @staticmethod
    def _generate_strengths(position: str) -> str:
        strengths = {
            'Market Leader': 'Brand recognition, economies of scale, established distribution, deep R&D budget',
            'Challenger': 'Aggressive pricing, rapid innovation, strong marketing, expanding market share',
            'Niche Player': 'Specialized expertise, loyal customer base, premium positioning, high margins',
            'Emerging': 'Cutting-edge technology, agile operations, low overhead, disruptive model'
        }
        return strengths.get(position, 'Strong market presence')

    @staticmethod
    def _generate_weaknesses(position: str) -> str:
        weaknesses = {
            'Market Leader': 'Bureaucratic inertia, legacy systems, slow to adapt, high overhead',
            'Challenger': 'Limited resources, brand recognition gaps, dependency on funding, operational strain',
            'Niche Player': 'Limited scale, vulnerability to market shifts, narrow product range',
            'Emerging': 'Unproven track record, limited capital, high burn rate, customer acquisition costs'
        }
        return weaknesses.get(position, 'Scaling challenges')

    @staticmethod
    def _generate_pricing(position: str) -> str:
        pricing = {
            'Market Leader': 'Premium / Value-based',
            'Challenger': 'Competitive / Penetration',
            'Niche Player': 'Premium / Skimming',
            'Emerging': 'Freemium / Low-margin'
        }
        return pricing.get(position, 'Market-rate')
