"""
CUSTOM TWIN 2.0 SERVICE - Schema Validation, Formula Engine, and Cycle Detection.

Provides:
- Schema validation for custom twin field definitions and record data
- AST-based secure mathematical formula evaluation (strictly sandboxed, no eval)
- Dependency graph construction and circular dependency detection
- Topological sorting of derived formula fields
- Parent-child hierarchy cycle detection
- Integration with TwinService for cross-twin and company impact participation
"""

import ast
import operator
import math
import re
import logging
from typing import Dict, Any, List, Set, Tuple, Optional
from datetime import datetime, date

logger = logging.getLogger(__name__)


class SchemaValidationError(Exception):
    """Raised when custom twin schema or record data fails validation."""
    def __init__(self, message: str, errors: Optional[Dict[str, str]] = None):
        super().__init__(message)
        self.message = message
        self.errors = errors or {}

    def to_dict(self):
        return {
            'success': False,
            'error': self.message,
            'errors': self.errors
        }


class CycleDependencyError(Exception):
    """Raised when circular dependencies are detected in formulas or twin hierarchies."""
    def __init__(self, message: str, cycle_path: Optional[List[str]] = None):
        super().__init__(message)
        self.message = message
        self.cycle_path = cycle_path or []

    def to_dict(self):
        return {
            'success': False,
            'error': self.message,
            'cycle': self.cycle_path
        }


class FormulaEvaluationError(Exception):
    """Raised when a formula fails to evaluate."""
    pass


class SafeASTEvaluator(ast.NodeVisitor):
    """
    Secure AST-based mathematical expression evaluator.
    Strictly whitelists node types and operations to prevent any code execution.
    """
    ALLOWED_OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: lambda a, b: 0.0 if b == 0 else a / b,
        ast.FloorDiv: lambda a, b: 0 if b == 0 else a // b,
        ast.Mod: lambda a, b: 0 if b == 0 else a % b,
        ast.Pow: lambda a, b: 0.0 if abs(b) > 20 else a ** b,
    }

    ALLOWED_UNARY_OPERATORS = {
        ast.UAdd: operator.pos,
        ast.USub: operator.neg,
    }

    ALLOWED_FUNCTIONS = {
        'min': lambda *args: min(args) if args else 0.0,
        'max': lambda *args: max(args) if args else 0.0,
        'abs': abs,
        'round': round,
        'sum': lambda *args: sum(args) if args else 0.0,
        'sqrt': lambda x: 0.0 if x < 0 else math.sqrt(x),
        'avg': lambda *args: sum(args) / len(args) if args else 0.0,
    }

    def __init__(self, context: Dict[str, Any]):
        self.context = context

    def visit_Expression(self, node: ast.Expression) -> Any:
        return self.visit(node.body)

    def visit_Constant(self, node: ast.Constant) -> Any:
        if isinstance(node.value, (int, float, bool)):
            return node.value
        raise FormulaEvaluationError(f"Unsupported constant type: {type(node.value).__name__}")

    def visit_Num(self, node: ast.Num) -> Any:  # compatibility with earlier python ASTs
        return node.n

    def visit_Name(self, node: ast.Name) -> Any:
        name = node.id
        if name in self.context:
            val = self.context[name]
            if val is None or val == '':
                return 0.0
            try:
                return float(val)
            except (ValueError, TypeError):
                return val
        if name in self.ALLOWED_FUNCTIONS:
            return self.ALLOWED_FUNCTIONS[name]
        # Unknown identifier defaults to 0.0 instead of crashing
        return 0.0

    def visit_UnaryOp(self, node: ast.UnaryOp) -> Any:
        op_type = type(node.op)
        if op_type not in self.ALLOWED_UNARY_OPERATORS:
            raise FormulaEvaluationError(f"Disallowed unary operator: {op_type.__name__}")
        operand = self.visit(node.operand)
        return self.ALLOWED_UNARY_OPERATORS[op_type](operand)

    def visit_BinOp(self, node: ast.BinOp) -> Any:
        op_type = type(node.op)
        if op_type not in self.ALLOWED_OPERATORS:
            raise FormulaEvaluationError(f"Disallowed binary operator: {op_type.__name__}")
        left = self.visit(node.left)
        right = self.visit(node.right)
        try:
            return self.ALLOWED_OPERATORS[op_type](left, right)
        except Exception as e:
            logger.warning(f"Error computing binary operation {op_type.__name__}: {e}")
            return 0.0

    def visit_Call(self, node: ast.Call) -> Any:
        if not isinstance(node.func, ast.Name):
            raise FormulaEvaluationError("Complex function calls are not allowed")
        func_name = node.func.id
        if func_name not in self.ALLOWED_FUNCTIONS:
            raise FormulaEvaluationError(f"Disallowed function call: '{func_name}'")
        func = self.ALLOWED_FUNCTIONS[func_name]
        args = [self.visit(arg) for arg in node.args]
        try:
            return func(*args)
        except Exception as e:
            logger.warning(f"Error executing function {func_name}: {e}")
            return 0.0

    def generic_visit(self, node: ast.AST) -> Any:
        raise FormulaEvaluationError(f"Disallowed syntax element in formula: '{type(node).__name__}'")


class TwinFormulaEngine:
    """Mathematical and dependency orchestration engine for custom twin formulas."""

    IDENTIFIER_REGEX = re.compile(r'\{([a-zA-Z_][a-zA-Z0-9_]*)\}')

    @classmethod
    def normalize_formula(cls, formula_str: str) -> str:
        """Convert {field_name} brackets into valid Python identifiers field_name."""
        if not formula_str:
            return ""
        return cls.IDENTIFIER_REGEX.sub(r'\1', formula_str.strip())

    @classmethod
    def extract_dependencies(cls, formula_str: str) -> Set[str]:
        """Extract referenced field names from a formula string."""
        if not formula_str:
            return set()

        # Extract explicit {field} tokens
        bracket_tokens = set(cls.IDENTIFIER_REGEX.findall(formula_str))
        norm_expr = cls.normalize_formula(formula_str)

        try:
            tree = ast.parse(norm_expr, mode='eval')
            ast_names = {
                node.id for node in ast.walk(tree)
                if isinstance(node, ast.Name) and node.id not in SafeASTEvaluator.ALLOWED_FUNCTIONS
            }
            return bracket_tokens | ast_names
        except SyntaxError as e:
            raise FormulaEvaluationError(f"Syntax error in formula '{formula_str}': {e}")

    @classmethod
    def build_dependency_graph(cls, fields: List[Dict[str, Any]]) -> Dict[str, Set[str]]:
        """
        Build adjacency list of field dependencies.
        graph[field_name] = {prerequisite_fields}
        """
        graph: Dict[str, Set[str]] = {}
        all_field_names = {f['name'] for f in fields}

        for field in fields:
            name = field['name']
            if field.get('type') == 'formula' and field.get('formula'):
                deps = cls.extract_dependencies(field['formula'])
                # Only retain dependencies that are part of this twin's schema
                graph[name] = deps.intersection(all_field_names)
            else:
                graph[name] = set()

        return graph

    @classmethod
    def detect_cycles(cls, graph: Dict[str, Set[str]]) -> Optional[List[str]]:
        """
        Detect cycles in dependency graph using DFS with recursion stack.
        Returns the cycle path as a list of field names if a cycle exists, else None.
        """
        visited: Set[str] = set()
        rec_stack: List[str] = []
        rec_set: Set[str] = set()

        def dfs(node: str) -> Optional[List[str]]:
            visited.add(node)
            rec_stack.append(node)
            rec_set.add(node)

            for neighbor in graph.get(node, set()):
                if neighbor in rec_set:
                    idx = rec_stack.index(neighbor)
                    return rec_stack[idx:] + [neighbor]
                if neighbor not in visited:
                    cycle = dfs(neighbor)
                    if cycle:
                        return cycle

            rec_stack.pop()
            rec_set.remove(node)
            return None

        for n in graph:
            if n not in visited:
                cycle = dfs(n)
                if cycle:
                    return cycle
        return None

    @classmethod
    def get_evaluation_order(cls, fields: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Returns formula fields in topologically sorted order for safe sequential evaluation.
        Raises CycleDependencyError if a circular dependency is detected.
        """
        formula_fields = [f for f in fields if f.get('type') == 'formula']
        if not formula_fields:
            return []

        graph = cls.build_dependency_graph(fields)
        cycle = cls.detect_cycles(graph)
        if cycle:
            raise CycleDependencyError(
                f"Circular dependency detected in formula fields: {' -> '.join(cycle)}",
                cycle_path=cycle
            )

        # Topological sort via Kahn's algorithm or post-order DFS
        # We only need order for formula fields
        visited = set()
        ordered_names = []

        def visit(n: str):
            if n in visited:
                return
            visited.add(n)
            for dep in graph.get(n, set()):
                visit(dep)
            ordered_names.append(n)

        for f in formula_fields:
            visit(f['name'])

        field_map = {f['name']: f for f in formula_fields}
        return [field_map[name] for name in ordered_names if name in field_map]

    @classmethod
    def evaluate_expression(cls, formula_str: str, context: Dict[str, Any], raise_on_error: bool = False) -> float:
        """Safely evaluates a single formula against a context dict."""
        if not formula_str or not formula_str.strip():
            return 0.0

        norm_expr = cls.normalize_formula(formula_str)
        try:
            tree = ast.parse(norm_expr, mode='eval')
            evaluator = SafeASTEvaluator(context)
            result = evaluator.visit(tree)
            if isinstance(result, (int, float)):
                return float(result)
            return 0.0
        except ZeroDivisionError:
            return 0.0
        except Exception as e:
            logger.warning(f"Formula evaluation failure for '{formula_str}': {e}")
            if raise_on_error:
                raise FormulaEvaluationError(str(e))
            return 0.0

    @classmethod
    def evaluate_record(cls, fields: List[Dict[str, Any]], record_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Evaluates all formula fields in a record in topological dependency order.
        Returns an updated copy of record_data with calculated values.
        """
        data = dict(record_data)
        ordered_formulas = cls.get_evaluation_order(fields)

        for f in ordered_formulas:
            fname = f['name']
            formula_expr = f.get('formula', '')
            val = cls.evaluate_expression(formula_expr, data)
            data[fname] = round(val, 4) if isinstance(val, float) else val

        return data


class CustomTwinSchemaService:
    """Enterprise schema validator and hierarchy manager for Custom Twins."""

    SUPPORTED_TYPES = {
        'text', 'string', 'number', 'integer', 'int', 'float',
        'boolean', 'bool', 'date', 'select', 'formula'
    }

    FIELD_NAME_REGEX = re.compile(r'^[a-zA-Z_][a-zA-Z0-9_]*$')

    @classmethod
    def validate_field_definitions(cls, fields: List[Dict[str, Any]]) -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
        """
        Validates field definitions for a CustomTwin:
        - Checks field names (valid identifier, unique)
        - Checks supported types
        - Validates formula syntax & detects formula cycles
        """
        errors: Dict[str, str] = {}
        seen_names: Set[str] = set()
        cleaned_fields: List[Dict[str, Any]] = []

        if not isinstance(fields, list):
            errors['field_definitions'] = "Field definitions must be a list."
            return [], errors

        for i, f in enumerate(fields):
            if not isinstance(f, dict):
                errors[f'field_{i}'] = "Field definition must be an object."
                continue

            name = str(f.get('name', '')).strip()
            label = str(f.get('label', '')).strip() or name.replace('_', ' ').title()
            ftype = str(f.get('type', 'text')).strip().lower()

            if not name:
                errors[f'field_{i}_name'] = "Field name cannot be empty."
                continue

            if not cls.FIELD_NAME_REGEX.match(name):
                errors[f'field_{i}_name'] = f"Field name '{name}' is invalid. Must start with a letter/underscore and contain only alphanumeric characters."
                continue

            if name in seen_names:
                errors[f'field_{i}_name'] = f"Duplicate field name '{name}'."
                continue
            seen_names.add(name)

            if ftype not in cls.SUPPORTED_TYPES:
                errors[f'field_{i}_type'] = f"Unsupported field type '{ftype}'."
                continue

            field_obj = {
                'name': name,
                'label': label,
                'type': ftype,
                'required': bool(f.get('required', False)),
                'default': f.get('default', None)
            }

            if ftype == 'select':
                options = f.get('options', [])
                if isinstance(options, str):
                    options = [opt.strip() for opt in options.split(',') if opt.strip()]
                field_obj['options'] = options or []

            if ftype == 'formula':
                formula = str(f.get('formula', '')).strip()
                if not formula:
                    errors[f'field_{i}_formula'] = f"Formula expression required for formula field '{name}'."
                else:
                    try:
                        TwinFormulaEngine.extract_dependencies(formula)
                        field_obj['formula'] = formula
                    except Exception as e:
                        errors[f'field_{i}_formula'] = f"Invalid formula syntax in '{name}': {e}"

            cleaned_fields.append(field_obj)

        # Check for formula cycles across the schema
        if not errors:
            try:
                TwinFormulaEngine.get_evaluation_order(cleaned_fields)
            except CycleDependencyError as e:
                errors['formula_cycle'] = str(e)

        return cleaned_fields, errors

    @classmethod
    def validate_parent_hierarchy(cls, company_id: int, twin_id: Optional[int], parent_twin_id: Optional[int]) -> None:
        """
        Ensures a twin does not create a circular parent-child hierarchy.
        Raises CycleDependencyError if a cycle is detected.
        """
        if not parent_twin_id:
            return

        from database.models.custom_twin import CustomTwin

        if twin_id and int(twin_id) == int(parent_twin_id):
            raise CycleDependencyError(
                "A twin cannot be its own parent.",
                cycle_path=[str(twin_id), str(parent_twin_id)]
            )

        current_id: Optional[int] = parent_twin_id
        visited: Set[int] = {int(twin_id)} if twin_id else set()
        path: List[int] = [int(twin_id)] if twin_id else []

        while current_id:
            if current_id in visited:
                path.append(current_id)
                path_names = [f"Twin #{tid}" for tid in path]
                raise CycleDependencyError(
                    f"Circular parent-child hierarchy detected: {' -> '.join(path_names)}",
                    cycle_path=path_names
                )
            visited.add(current_id)
            path.append(current_id)

            parent = CustomTwin.query.filter_by(id=current_id, company_id=company_id).first()
            if not parent:
                break
            current_id = parent.parent_twin_id

    @classmethod
    def validate_and_clean_record_data(
        cls,
        fields: List[Dict[str, Any]],
        raw_data: Dict[str, Any],
        partial: bool = False
    ) -> Tuple[Dict[str, Any], Dict[str, str]]:
        """
        Validates and coerces user record input against custom twin field definitions.
        Evaluates formula fields automatically.
        """
        errors: Dict[str, str] = {}
        cleaned: Dict[str, Any] = {}

        for field in fields:
            fname = field['name']
            ftype = field.get('type', 'text').lower()
            required = field.get('required', False)
            default = field.get('default')

            # Formula fields are computed automatically, user inputs ignored
            if ftype == 'formula':
                continue

            has_value = fname in raw_data and raw_data[fname] is not None
            raw_val = raw_data.get(fname)

            if not has_value or (isinstance(raw_val, str) and not raw_val.strip()):
                if required and not partial and default is None:
                    errors[fname] = f"Field '{field.get('label', fname)}' is required."
                    continue
                cleaned[fname] = default
                continue

            # Type validation and conversion
            if ftype in ('number', 'float'):
                try:
                    cleaned[fname] = float(raw_val)
                except (ValueError, TypeError):
                    errors[fname] = f"Field '{fname}' must be a valid number."
            elif ftype in ('integer', 'int'):
                try:
                    cleaned[fname] = int(float(raw_val))
                except (ValueError, TypeError):
                    errors[fname] = f"Field '{fname}' must be an integer."
            elif ftype in ('boolean', 'bool'):
                if isinstance(raw_val, bool):
                    cleaned[fname] = raw_val
                else:
                    cleaned[fname] = str(raw_val).strip().lower() in ('true', '1', 'yes', 'on')
            elif ftype == 'date':
                if isinstance(raw_val, (datetime, date)):
                    cleaned[fname] = raw_val.isoformat()[:10]
                else:
                    val_str = str(raw_val).strip()
                    try:
                        cleaned[fname] = datetime.strptime(val_str, '%Y-%m-%d').date().isoformat()
                    except ValueError:
                        errors[fname] = f"Field '{fname}' must be a valid date in YYYY-MM-DD format."
            elif ftype == 'select':
                val_str = str(raw_val).strip()
                allowed_options = field.get('options', [])
                if allowed_options and val_str not in allowed_options:
                    errors[fname] = f"Value '{val_str}' is not a valid option for '{fname}'."
                else:
                    cleaned[fname] = val_str
            else:  # text / string
                cleaned[fname] = str(raw_val).strip()

        # If static fields are valid, compute formula fields
        if not errors:
            try:
                cleaned = TwinFormulaEngine.evaluate_record(fields, cleaned)
            except Exception as e:
                errors['formulas'] = f"Error evaluating formulas: {e}"

        return cleaned, errors
