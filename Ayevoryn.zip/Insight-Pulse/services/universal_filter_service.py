"""
Universal Filter Service — Standardized Server-Side & Client-Side Digital Twin Filtering
Provides schema-aware, SQL-injection safe filtering, sorting, and period bounds for
Financial Records, Core Operational Twins, and Dynamic Custom Twins.
"""

from datetime import datetime, date, timedelta
from typing import Dict, Any, List, Optional, Tuple
from sqlalchemy import func, desc, asc, or_, and_

from database import db
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.department import Department
from database.models.company import Company
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.core_twin_extra import CoreTwinExtraRecord


class UniversalFilterService:
    """Universal search, range, category, and JSON-attribute filtering engine."""

    @staticmethod
    def get_period_bounds(
        period: Optional[str] = '30d',
        custom_from: Optional[Any] = None,
        custom_to: Optional[Any] = None,
        company_id: Optional[int] = None
    ) -> Tuple[Optional[date], Optional[date], str]:
        """
        Computes (start_date, end_date, normalized_period_label).
        Supported periods:
        - 'today'
        - '7d' (trailing 7 days)
        - '30d' (trailing 30 days - default)
        - 'this_month' (current calendar month)
        - 'last_month' (prior calendar month)
        - 'fy' (current fiscal year)
        - 'all_time' (unbounded)
        - 'custom' (uses custom_from and custom_to)
        """
        today = date.today()
        p = (period or '30d').strip().lower()

        if custom_from or custom_to:
            from services.twin_record_service import TwinRecordService
            dt_from, _ = TwinRecordService.parse_flexible_date(custom_from, allow_empty=True)
            dt_to, _ = TwinRecordService.parse_flexible_date(custom_to, allow_empty=True)
            return dt_from, dt_to, 'custom'

        if p == 'today':
            return today, today, 'today'
        elif p == '7d':
            return today - timedelta(days=7), today, '7d'
        elif p == '30d':
            return today - timedelta(days=30), today, '30d'
        elif p == 'this_month':
            first_day = today.replace(day=1)
            return first_day, today, 'this_month'
        elif p == 'last_month':
            first_of_this_month = today.replace(day=1)
            last_day_prev = first_of_this_month - timedelta(days=1)
            first_day_prev = last_day_prev.replace(day=1)
            return first_day_prev, last_day_prev, 'last_month'
        elif p in ('fy', 'fiscal_year', 'ytd'):
            # Determine fiscal year start month from company config
            fy_month = 4  # Default April (India/UK)
            if company_id:
                comp = Company.query.get(company_id)
                if comp and comp.fiscal_year_start:
                    m_str = comp.fiscal_year_start.lower()
                    if 'jan' in m_str:
                        fy_month = 1
                    elif 'apr' in m_str:
                        fy_month = 4
                    elif 'jul' in m_str:
                        fy_month = 7
                    elif 'oct' in m_str:
                        fy_month = 10
            fy_year = today.year if today.month >= fy_month else today.year - 1
            fy_start = date(fy_year, fy_month, 1)
            return fy_start, today, 'fy'
        elif p in ('all', 'all_time', 'alltime'):
            return None, None, 'all_time'

        # Default fallback: trailing 30 days
        return today - timedelta(days=30), today, '30d'

    @classmethod
    def filter_financial_records(
        cls,
        company_id: int,
        transaction_type: str = 'revenue',
        filters: Optional[Dict[str, Any]] = None
    ) -> List[FinancialRecord]:
        """Filters financial revenue or expense records with complete query criteria."""
        filters = filters or {}
        query = FinancialRecord.query.filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == transaction_type
        )

        # 1. Date / Period filtering
        period = filters.get('period')
        date_from = filters.get('date_from') or filters.get('start_date')
        date_to = filters.get('date_to') or filters.get('end_date')

        start_dt, end_dt, _ = cls.get_period_bounds(period, date_from, date_to, company_id=company_id)
        if start_dt:
            query = query.filter(FinancialRecord.transaction_date >= start_dt)
        if end_dt:
            query = query.filter(FinancialRecord.transaction_date <= end_dt)

        # 2. Category / Subcategory
        cat = (filters.get('category') or '').strip()
        if cat and cat.lower() != 'all':
            query = query.filter(func.lower(FinancialRecord.category) == cat.lower())

        subcat = (filters.get('subcategory') or '').strip()
        if subcat and subcat.lower() != 'all':
            query = query.filter(func.lower(FinancialRecord.subcategory) == subcat.lower())

        # 3. Department
        dept_id = filters.get('department_id') or filters.get('department')
        if dept_id and str(dept_id).lower() != 'all':
            try:
                query = query.filter(FinancialRecord.department_id == int(dept_id))
            except (ValueError, TypeError):
                pass

        # 4. Account
        account_id = filters.get('account_id') or filters.get('account')
        if account_id and str(account_id).lower() != 'all':
            try:
                query = query.filter(FinancialRecord.account_id == int(account_id))
            except (ValueError, TypeError):
                pass

        # 5. Amount range
        if filters.get('min_amount') is not None and str(filters.get('min_amount')).strip():
            try:
                query = query.filter(FinancialRecord.amount >= float(filters['min_amount']))
            except (ValueError, TypeError):
                pass

        if filters.get('max_amount') is not None and str(filters.get('max_amount')).strip():
            try:
                query = query.filter(FinancialRecord.amount <= float(filters['max_amount']))
            except (ValueError, TypeError):
                pass

        # 6. Recurring filter
        is_rec = filters.get('is_recurring')
        if is_rec is not None and str(is_rec).strip() and str(is_rec).lower() != 'all':
            rec_bool = str(is_rec).lower() in ('true', '1', 'yes')
            query = query.filter(FinancialRecord.is_recurring == rec_bool)

        # 7. Search keyword
        search_q = (filters.get('q') or filters.get('search') or '').strip()
        if search_q:
            pattern = f"%{search_q}%"
            query = query.filter(
                or_(
                    FinancialRecord.reference_number.ilike(pattern),
                    FinancialRecord.description.ilike(pattern),
                    FinancialRecord.category.ilike(pattern),
                    FinancialRecord.subcategory.ilike(pattern)
                )
            )

        # 8. Sorting
        order_col = filters.get('order_by', 'transaction_date')
        order_dir = filters.get('order_dir', 'desc').lower()

        col_attr = getattr(FinancialRecord, order_col, FinancialRecord.transaction_date)
        if order_dir == 'asc':
            query = query.order_by(asc(col_attr), asc(FinancialRecord.id))
        else:
            query = query.order_by(desc(col_attr), desc(FinancialRecord.id))

        return query.all()

    @classmethod
    def get_financial_summary_metrics(
        cls,
        company_id: int,
        period: str = '30d',
        transaction_type: str = 'revenue',
        start_date: Optional[date] = None,
        end_date: Optional[date] = None
    ) -> Dict[str, Any]:
        """
        Computes period-bounded revenue and expense KPI totals with period profit & margin.
        Guarantees no division by zero.
        """
        start_dt, end_dt, p_label = cls.get_period_bounds(period, start_date, end_date, company_id=company_id)

        # Revenue query
        rev_q = db.session.query(
            func.coalesce(func.sum(FinancialRecord.amount), 0.0),
            func.count(FinancialRecord.id)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue'
        )
        if start_dt:
            rev_q = rev_q.filter(FinancialRecord.transaction_date >= start_dt)
        if end_dt:
            rev_q = rev_q.filter(FinancialRecord.transaction_date <= end_dt)

        rev_res = rev_q.first()
        period_rev = float(rev_res[0] or 0.0)
        period_rev_count = int(rev_res[1] or 0)

        # Period expense query for profit & margin calculation
        exp_q = db.session.query(
            func.coalesce(func.sum(FinancialRecord.amount), 0.0),
            func.count(FinancialRecord.id)
        ).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense'
        )
        if start_dt:
            exp_q = exp_q.filter(FinancialRecord.transaction_date >= start_dt)
        if end_dt:
            exp_q = exp_q.filter(FinancialRecord.transaction_date <= end_dt)

        exp_res = exp_q.first()
        period_exp = float(exp_res[0] or 0.0)
        period_exp_count = int(exp_res[1] or 0)

        # All-time metrics for baseline telemetry
        all_rev = float(db.session.query(
            func.coalesce(func.sum(FinancialRecord.amount), 0.0)
        ).filter_by(company_id=company_id, transaction_type='revenue').scalar() or 0.0)

        all_exp = float(db.session.query(
            func.coalesce(func.sum(FinancialRecord.amount), 0.0)
        ).filter_by(company_id=company_id, transaction_type='expense').scalar() or 0.0)

        all_rev_count = FinancialRecord.query.filter_by(company_id=company_id, transaction_type='revenue').count()
        all_exp_count = FinancialRecord.query.filter_by(company_id=company_id, transaction_type='expense').count()

        period_profit = period_rev - period_exp
        period_margin = round((period_profit / period_rev * 100.0), 1) if period_rev > 0 else 0.0

        all_profit = all_rev - all_exp
        all_margin = round((all_profit / all_rev * 100.0), 1) if all_rev > 0 else 0.0

        from config.constants import CURRENCY_SYMBOLS
        comp = Company.query.get(company_id)
        cur_sym = CURRENCY_SYMBOLS.get(getattr(comp, 'currency', 'USD'), '$')

        return {
            'period': p_label,
            'start_date': start_dt.isoformat() if start_dt else None,
            'end_date': end_dt.isoformat() if end_dt else None,
            'currency_symbol': cur_sym,
            'period_revenue': round(period_rev, 2),
            'period_revenue_formatted': f"{cur_sym}{period_rev:,.2f}",
            'period_revenue_count': period_rev_count,
            'period_expense': round(period_exp, 2),
            'period_expense_formatted': f"{cur_sym}{period_exp:,.2f}",
            'period_expense_count': period_exp_count,
            'period_profit': round(period_profit, 2),
            'period_profit_formatted': f"{cur_sym}{period_profit:,.2f}",
            'period_margin': period_margin,
            'period_margin_formatted': f"{period_margin:.1f}%",
            'margin': period_margin,
            'margin_formatted': f"{period_margin:.1f}%",
            'all_time_revenue': round(all_rev, 2),
            'all_time_revenue_formatted': f"{cur_sym}{all_rev:,.2f}",
            'all_time_revenue_count': all_rev_count,
            'all_time_expense': round(all_exp, 2),
            'all_time_expense_formatted': f"{cur_sym}{all_exp:,.2f}",
            'all_time_profit': round(all_profit, 2),
            'all_time_profit_formatted': f"{cur_sym}{all_profit:,.2f}",
            'all_time_margin': all_margin,
        }

    @classmethod
    def filter_custom_twin_records(
        cls,
        company_id: int,
        twin_id: int,
        filters: Optional[Dict[str, Any]] = None
    ) -> List[CustomTwinRecord]:
        """Schema-aware dynamic JSON filter engine for CustomTwinRecord."""
        filters = filters or {}
        records = CustomTwinRecord.query.filter_by(
            company_id=company_id,
            twin_id=twin_id
        ).order_by(CustomTwinRecord.id.desc()).all()

        search_q = (filters.get('q') or filters.get('search') or '').strip().lower()
        active_filters = {k: str(v).strip().lower() for k, v in filters.items() if k not in ('q', 'search', 'page', 'per_page', 'twin') and v is not None and str(v).strip() and str(v).lower() != 'all'}

        if not search_q and not active_filters:
            return records

        filtered = []
        for rec in records:
            data = rec.data or {}
            # Check JSON attribute filters
            match = True
            for f_key, f_val in active_filters.items():
                rec_val = str(data.get(f_key, '')).strip().lower()
                if f_val not in rec_val:
                    match = False
                    break
            if not match:
                continue

            # Check general text search
            if search_q:
                text_corpus = " ".join([str(v) for v in data.values()]).lower()
                if search_q not in text_corpus:
                    continue

            filtered.append(rec)

        return filtered
