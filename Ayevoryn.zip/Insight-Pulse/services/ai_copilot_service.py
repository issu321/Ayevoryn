"""
AEVORYN ENTERPRISE AI COPILOT & PULSE AI BRIDGE
Routes dashboard Copilot requests through the multi-tenant PulseAIEngine
while preserving full backward compatibility with all existing response keys.
"""

from datetime import datetime
from database.db import db
from database.models.company import Company
from services.pulse_ai_engine import PulseAIEngine
from config.constants import CURRENCY_SYMBOLS


class AICopilotService:
    """Enterprise AI Copilot powered by the Company-Aware PulseAIEngine."""

    @staticmethod
    def process_prompt(company_id, user_id, prompt, agent_mode='auto', conversation_id=None, require_confirmation=True):
        p_clean = (prompt or '').strip()
        p_lower = p_clean.lower()
        company = db.session.get(Company, int(company_id)) if company_id else None
        if not company:
            return {'success': False, 'error': 'Company context not found'}

        # Instant UI Preferences (Theme / Currency)
        if any(kw in p_lower for kw in ['dark mode', 'dark theme', 'light mode', 'light theme', 'switch theme', 'change theme']):
            return AICopilotService._execute_change_theme(user_id, p_lower)

        if any(kw in p_lower for kw in ['change currency', 'set currency', 'switch currency', 'currency to']):
            return AICopilotService._execute_change_currency(company, p_lower)

        # Delegate all business intelligence, simulation, dependency, and controlled mutation requests to PulseAIEngine
        return PulseAIEngine.process_conversation_turn(
            company_id=company.id,
            user_id=user_id or 1,
            prompt=p_clean,
            conversation_id=conversation_id,
            require_confirmation_for_mutations=require_confirmation
        )

    @staticmethod
    def _execute_change_currency(company, p_lower):
        target_curr = 'USD'
        for c in ['eur', 'gbp', 'inr', 'jpy', 'aud', 'cad', 'sgd', 'aed', 'cny', 'usd']:
            if c in p_lower:
                target_curr = c.upper()
                break

        company.currency = target_curr
        db.session.commit()
        sym = CURRENCY_SYMBOLS.get(target_curr, '$')

        return {
            'success': True,
            'is_action': True,
            'action_type': 'change_currency',
            'action_title': f'Operating Currency Switched to {target_curr}',
            'headline': f'Treasury Denomination Converted to {target_curr} ({sym})',
            'explanation': f'Company master ledger, analytics models, and cash runway projections converted to {target_curr}.',
            'details': {
                'ISO Code': target_curr,
                'Currency Symbol': sym,
                'Company': company.company_name
            },
            'refresh': True,
            'timestamp': datetime.utcnow().strftime('%H:%M:%S UTC')
        }

    @staticmethod
    def _execute_change_theme(user_id, p_lower):
        target_theme = 'dark_clay_glass' if 'dark' in p_lower else 'white_clay_glass'
        theme_name = 'Dark Clay Glass' if target_theme == 'dark_clay_glass' else 'Light Clay Glass'

        from database.models.theme_preference import ThemePreference
        if user_id:
            theme_pref = ThemePreference.query.filter_by(user_id=user_id).first()
            if theme_pref:
                theme_pref.theme_id = target_theme
            else:
                db.session.add(ThemePreference(user_id=user_id, theme_id=target_theme))
            db.session.commit()

        return {
            'success': True,
            'is_action': True,
            'action_type': 'change_theme',
            'action_title': f'Visual Theme Updated: {theme_name}',
            'headline': f'Interface Transmuted to {theme_name}',
            'explanation': f'Your executive theme preference was saved to {theme_name}.',
            'details': {
                'Theme ID': target_theme,
                'Display Mode': theme_name,
                'Sync': 'Instant Session & Cloud Storage'
            },
            'target_theme': target_theme,
            'refresh': True,
            'timestamp': datetime.utcnow().strftime('%H:%M:%S UTC')
        }
