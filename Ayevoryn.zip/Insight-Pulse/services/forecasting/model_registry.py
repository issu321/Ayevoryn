"""
FORECAST MODEL REGISTRY - Canonical Inventory of Predictive and Time-Series Algorithms.
Provides honest algorithmic classification, required observation thresholds, mathematical
assumptions, and metadata. Strictly eliminates misleading 'AI Neural Deep Learning' labels.
"""

import logging
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

logger = logging.getLogger(__name__)

# Check backend library availability
try:
    from prophet import Prophet
    PROPHET_AVAILABLE = True
except Exception:
    PROPHET_AVAILABLE = False

try:
    from statsmodels.tsa.arima.model import ARIMA
    ARIMA_AVAILABLE = True
except Exception:
    ARIMA_AVAILABLE = False

try:
    from statsmodels.tsa.holtwinters import ExponentialSmoothing
    EXP_SMOOTH_AVAILABLE = True
except Exception:
    EXP_SMOOTH_AVAILABLE = False


class ForecastModelFamily:
    STATISTICAL_REGRESSION = "STATISTICAL_REGRESSION"
    MOVING_AVERAGE = "MOVING_AVERAGE"
    EXPONENTIAL_SMOOTHING = "EXPONENTIAL_SMOOTHING"
    AUTOREGRESSIVE_INTEGRATED = "AUTOREGRESSIVE_INTEGRATED"
    SEASONAL_DECOMPOSITION = "SEASONAL_DECOMPOSITION"
    ENSEMBLE_BLENDED = "ENSEMBLE_BLENDED"


@dataclass
class ModelDefinition:
    id: str
    name: str
    family: str
    display_family: str
    description: str
    min_observations: int
    complexity: str
    is_available: bool
    assumptions: List[str] = field(default_factory=list)
    strengths: List[str] = field(default_factory=list)
    limitations: List[str] = field(default_factory=list)
    default_params: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self, current_obs: Optional[int] = None) -> Dict[str, Any]:
        eligible = True if current_obs is None else current_obs >= self.min_observations
        return {
            'id': self.id,
            'name': self.name,
            'family': self.family,
            'display_family': self.display_family,
            'description': self.description,
            'min_observations': self.min_observations,
            'complexity': self.complexity,
            'is_available': self.is_available,
            'is_eligible': eligible and self.is_available,
            'assumptions': self.assumptions,
            'strengths': self.strengths,
            'limitations': self.limitations,
            'default_params': self.default_params
        }


class ForecastModelRegistry:
    _REGISTRY: Dict[str, ModelDefinition] = {}

    @classmethod
    def register(cls, model_def: ModelDefinition):
        cls._REGISTRY[model_def.id] = model_def

    @classmethod
    def get_model(cls, model_id: str) -> Optional[ModelDefinition]:
        return cls._REGISTRY.get(model_id)

    @classmethod
    def list_models(cls, available_only: bool = False) -> List[ModelDefinition]:
        models = list(cls._REGISTRY.values())
        if available_only:
            models = [m for m in models if m.is_available]
        return models

    @classmethod
    def get_eligible_models(cls, observation_count: int, available_only: bool = True) -> List[ModelDefinition]:
        models = cls.list_models(available_only=available_only)
        return [m for m in models if observation_count >= m.min_observations]

    @classmethod
    def is_eligible(cls, model_id: str, observation_count: int) -> bool:
        model = cls.get_model(model_id)
        if not model or not model.is_available:
            return False
        return observation_count >= model.min_observations

    @classmethod
    def to_dict(cls, observation_count: Optional[int] = None) -> List[Dict[str, Any]]:
        return [m.to_dict(current_obs=observation_count) for m in cls._REGISTRY.values()]


# Register Canonical Enterprise Models
ForecastModelRegistry.register(ModelDefinition(
    id='linear_regression',
    name='Ordinary Least Squares (OLS) Linear Trend',
    family=ForecastModelFamily.STATISTICAL_REGRESSION,
    display_family='Statistical Regression',
    description='Fits an optimal linear trend line via least-squares polynomial regression, with asymptotic logarithmic dampening over horizons exceeding 90 days to prevent unbounded divergence.',
    min_observations=7,
    complexity='LOW',
    is_available=True,
    assumptions=[
        'Linear relationship between observation date and metric magnitude',
        'Stationary growth velocity across the projection horizon',
        'Residual noise is independent and normally distributed'
    ],
    strengths=[
        'Extremely robust on limited sample sizes (7-29 days)',
        'Zero risk of mathematical instability or overfitting',
        'Transparent deterministic coefficient explanation'
    ],
    limitations=[
        'Cannot model cyclical or non-linear inflection points',
        'Does not capture seasonal weekend or holiday dips'
    ],
    default_params={'degree': 1, 'asymptotic_dampening': True}
))

ForecastModelRegistry.register(ModelDefinition(
    id='moving_average',
    name='Damped Moving Average & Momentum',
    family=ForecastModelFamily.MOVING_AVERAGE,
    display_family='Rolling Window',
    description='Calculates an adaptive rolling window average with exponential momentum decay, projecting smooth mean-reverting baselines suitable for volatile operational series.',
    min_observations=14,
    complexity='LOW',
    is_available=True,
    assumptions=[
        'Recent transaction volume is more representative than historical records',
        'Trend velocity dampens geometrically (decay rate ~0.97 per day)'
    ],
    strengths=[
        'Filters high-frequency daily volatility and erratic one-off spikes',
        'Quickly reflects structural baseline step-ups or step-downs'
    ],
    limitations=[
        'Lags behind rapid inflection changes',
        'Window sizing requires adequate observation density'
    ],
    default_params={'window': 'auto', 'decay': 0.97}
))

ForecastModelRegistry.register(ModelDefinition(
    id='exponential_smoothing',
    name='Holt-Winters Exponential Smoothing',
    family=ForecastModelFamily.EXPONENTIAL_SMOOTHING,
    display_family='Exponential State-Space',
    description='Applies triple or double exponential smoothing with additive level and damped trend velocity via statsmodels. Captures sustained momentum while dampening long-range drift.',
    min_observations=30,
    complexity='MODERATE',
    is_available=EXP_SMOOTH_AVAILABLE,
    assumptions=[
        'Data follows an additive state-space level and trend structure',
        'Geometric discount factor on historic observations'
    ],
    strengths=[
        'Enterprise gold standard for inventory demand and sales velocity',
        'Damped trend feature prevents runaway multi-quarter overshoots'
    ],
    limitations=[
        'Requires continuous observation frequency without long multi-week gaps',
        'Sensitive to extreme outliers in recent periods'
    ],
    default_params={'trend': 'add', 'damped_trend': True}
))

ForecastModelRegistry.register(ModelDefinition(
    id='arima',
    name='Box-Jenkins ARIMA (Autoregressive Integrated Moving Average)',
    family=ForecastModelFamily.AUTOREGRESSIVE_INTEGRATED,
    display_family='Autoregressive Integrated',
    description='Captures temporal autocorrelation and non-stationarity via first-order differencing, autoregressive terms (p), and moving average error innovations (q) via statsmodels.',
    min_observations=30,
    complexity='HIGH',
    is_available=ARIMA_AVAILABLE,
    assumptions=[
        'Differenced series achieves weak stationarity',
        'Errors are white noise innovations with constant variance'
    ],
    strengths=[
        'Statistically rigorous modeling of autocorrelated corporate cashflows',
        'Explicit mathematical error distributions for confidence intervals'
    ],
    limitations=[
        'Computationally sensitive to zero-variance flatlines',
        'Can produce flat asymptotic lines on non-autocorrelated series'
    ],
    default_params={'order': (1, 1, 1)}
))

ForecastModelRegistry.register(ModelDefinition(
    id='prophet',
    name='Additive Seasonal Decomposition (Prophet)',
    family=ForecastModelFamily.SEASONAL_DECOMPOSITION,
    display_family='Generalized Additive',
    description='Decomposes daily historical series into piecewise linear growth trends with automatic changepoint detection, weekly cyclical components, and Bayesian uncertainty intervals.',
    min_observations=60,
    complexity='HIGH',
    is_available=PROPHET_AVAILABLE,
    assumptions=[
        'Time series can be decomposed into trend, weekly seasonality, and error',
        'Seasonality follows Fourier series harmonics'
    ],
    strengths=[
        'Native handling of missing dates and calendar variations',
        'Robust Bayesian credible intervals with high historical coverage'
    ],
    limitations=[
        'Requires at least 60-90 days of daily history for reliable decomposition',
        'Higher computational latency on model fitting'
    ],
    default_params={'interval_width': 0.80, 'weekly_seasonality': True}
))

ForecastModelRegistry.register(ModelDefinition(
    id='weighted_ensemble',
    name='Variance-Weighted Multi-Model Ensemble',
    family=ForecastModelFamily.ENSEMBLE_BLENDED,
    display_family='Ensemble Blend',
    description='Synthesizes projections across all eligible baseline models, weighting each model inversely by its backtested out-of-sample prediction error (w_i proportional to 1/RMSE_i^2).',
    min_observations=30,
    complexity='VERY_HIGH',
    is_available=True,
    assumptions=[
        'Individual model errors are partially uncorrelated',
        'Historical out-of-sample backtest accuracy predicts future accuracy'
    ],
    strengths=[
        'Consistently lower forecast variance than any individual component model',
        'Shields executive planning from single-model catastrophic failure'
    ],
    limitations=[
        'Requires running multiple models and backtests concurrently',
        'Less directly explainable than single linear models'
    ],
))