"""
DATA READINESS SERVICE - Rigorous Data Sufficiency Assessment.
Quantifies observation density, temporal continuity, and missingness to prevent
synthetic noise or sparse samples from masquerading as empirical forecast baselines.
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, date
from typing import List, Dict, Any, Optional
import pandas as pd
import numpy as np

from database.db import db
from database.models.company import Company
from database.models.financial import FinancialRecord
from database.models.customer import Customer
from database.models.department import Department
from database.models.risk import Risk
from database.models.market_data import MarketData
from database.models.competitor import Competitor
from database.models.inventory import Inventory
from database.models.forecast import DataReadinessLevel
from services.forecasting.model_registry import ForecastModelRegistry

logger = logging.getLogger(__name__)


@dataclass
class DataReadinessReport:
    company_id: int
    forecast_type: str
    level: str
    distinct_dates_count: int
    total_records: int
    start_date: Optional[date]
    end_date: Optional[date]
    span_days: int
    missing_days: int
    sparsity_ratio: float
    eligible_models: List[str]
    recommended_model: Optional[str]
    is_sufficient_for_empirical: bool
    diagnostic_message: str
    baseline_df: Optional[pd.DataFrame] = None
    is_synthetic: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return {
            'company_id': self.company_id,
            'forecast_type': self.forecast_type,
            'level': self.level,
            'distinct_dates_count': self.distinct_dates_count,
            'total_records': self.total_records,
            'start_date': self.start_date.isoformat() if self.start_date else None,
            'end_date': self.end_date.isoformat() if self.end_date else None,
            'span_days': self.span_days,
            'missing_days': self.missing_days,
            'sparsity_ratio': round(self.sparsity_ratio, 3),
            'eligible_models': self.eligible_models,
            'recommended_model': self.recommended_model,
            'is_sufficient_for_empirical': self.is_sufficient_for_empirical,
            'diagnostic_message': self.diagnostic_message,
            'is_synthetic': self.is_synthetic
        }


class DataReadinessService:
    @staticmethod
    def assess_readiness(company_id: int, forecast_type: str, allow_synthetic_fallback: bool = False) -> DataReadinessReport:
        """
        Assess historical data sufficiency and return an empirical daily DataFrame if available.
        Does NOT silently synthesize fake random data unless allow_synthetic_fallback is True.
        """
        company = Company.query.get(company_id)
        annual_rev = float(company.annual_revenue) if company and company.annual_revenue and company.annual_revenue > 0 else 1500000.0
        annual_exp = float(company.annual_expenses_plan) if company and company.annual_expenses_plan and company.annual_expenses_plan > 0 else annual_rev * 0.76
        cust_count = int(company.customer_count) if company and hasattr(company, 'customer_count') and company.customer_count and company.customer_count > 0 else 100
        today = datetime.now().date()

        # 1. Financial Records (revenue, expense, profit, cashflow)
        if forecast_type in {'revenue', 'expense', 'profit', 'cashflow'}:
            records = db.session.query(
                FinancialRecord.transaction_date,
                FinancialRecord.transaction_type,
                db.func.sum(FinancialRecord.amount),
                db.func.count(FinancialRecord.id)
            ).filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_type.in_(['revenue', 'expense'])
            ).group_by(
                FinancialRecord.transaction_date,
                FinancialRecord.transaction_type
            ).order_by(FinancialRecord.transaction_date).all()

            by_date = {}
            total_recs = 0
            for dt, t_type, amt, count in records:
                by_date.setdefault(dt, {'revenue': 0.0, 'expense': 0.0})
                by_date[dt][t_type] = float(amt or 0.0)
                total_recs += count

            distinct_dates = len(by_date)
            if distinct_dates > 0:
                dates_sorted = sorted(by_date.keys())
                start_dt = dates_sorted[0]
                end_dt = dates_sorted[-1]
                span_days = max(1, (end_dt - start_dt).days + 1)
                missing_days = max(0, span_days - distinct_dates)
                sparsity_ratio = missing_days / float(span_days)
            else:
                start_dt = None
                end_dt = None
                span_days = 0
                missing_days = 0
                sparsity_ratio = 1.0

            # Categorize readiness level
            if distinct_dates < 14:
                level = DataReadinessLevel.INSUFFICIENT
                is_sufficient = False
                rec_model = None
                msg = (
                    f"Insufficient transaction history: Found {distinct_dates} distinct transaction dates "
                    f"({total_recs} total records). A minimum of 14 continuous observation dates is required "
                    f"for empirical trend forecasting. Run with Heuristic Scenario mode enabled to explore "
                    f"hypothetical forward projections derived from company targets."
                )
            elif distinct_dates < 30:
                level = DataReadinessLevel.LIMITED
                is_sufficient = True
                rec_model = 'linear_regression'
                msg = (
                    f"Limited transaction history: Found {distinct_dates} observation dates spanning {span_days} days "
                    f"({sparsity_ratio:.1%} missingness). Linear trend extrapolation and short-window moving averages "
                    f"are supported. Higher-order seasonal models require 30+ days."
                )
            elif distinct_dates < 90:
                level = DataReadinessLevel.SUFFICIENT
                is_sufficient = True
                rec_model = 'exponential_smoothing'
                msg = (
                    f"Sufficient transaction history: Found {distinct_dates} observation dates. "
                    f"Statistical regression, Holt-Winters exponential smoothing, and ARIMA models are fully supported."
                )
            else:
                level = DataReadinessLevel.ROBUST
                is_sufficient = True
                rec_model = 'weighted_ensemble'
                msg = (
                    f"Robust transaction history: Found {distinct_dates} observation dates spanning {span_days} days. "
                    f"All predictive models including Prophet additive seasonal decomposition and Weighted Ensemble are supported."
                )

            eligible = [m.id for m in ForecastModelRegistry.get_eligible_models(distinct_dates)]

            # Construct baseline DataFrame if sufficient OR if synthetic fallback is explicitly requested
            baseline_df = None
            is_synthetic = False

            if distinct_dates >= 14:
                # Build real continuous date index with linear interpolation for small gaps
                all_dates = pd.date_range(start=start_dt, end=end_dt, freq='D')
                data_list = []
                for d in all_dates:
                    d_date = d.date()
                    rev = by_date.get(d_date, {}).get('revenue', 0.0)
                    exp = by_date.get(d_date, {}).get('expense', 0.0)

                    if forecast_type == 'revenue':
                        val = rev
                    elif forecast_type == 'expense':
                        val = exp
                    elif forecast_type == 'profit':
                        val = rev - exp
                    else:  # cashflow
                        val = (rev - exp) * 0.92
                    data_list.append({'ds': d, 'y': float(val)})

                df = pd.DataFrame(data_list)
                # Fill zeros from sparse weekends/logging using gentle linear interpolation
                if (df['y'] == 0).sum() > 0:
                    mean_val = df[df['y'] != 0]['y'].mean() if (df['y'] != 0).any() else annual_rev / 365.0
                    df['y'] = df['y'].replace(0, np.nan).interpolate(method='linear').fillna(mean_val)
                baseline_df = df

            elif allow_synthetic_fallback:
                # Explicit heuristic synthesis based on company targets
                is_synthetic = True
                days_history = 90
                start_date = today - timedelta(days=days_history)
                date_range = pd.date_range(start=start_date, periods=days_history, freq='D')
                base_daily_rev = annual_rev / 365.0
                base_daily_exp = annual_exp / 365.0

                data_list = []
                for i, d in enumerate(date_range):
                    dow_factor = 1.10 if d.weekday() < 5 else 0.75
                    trend_factor = 1.0 + (i / days_history) * 0.03
                    noise_rev = float(np.random.normal(1.0, 0.05))
                    noise_exp = float(np.random.normal(1.0, 0.03))

                    d_rev = max(100.0, base_daily_rev * dow_factor * trend_factor * noise_rev)
                    d_exp = max(50.0, base_daily_exp * noise_exp)

                    if forecast_type == 'revenue':
                        val = d_rev
                    elif forecast_type == 'expense':
                        val = d_exp
                    elif forecast_type == 'profit':
                        val = d_rev - d_exp
                    else:
                        val = (d_rev * 1.05) - d_exp
                    data_list.append({'ds': d, 'y': float(val)})

                baseline_df = pd.DataFrame(data_list)

            return DataReadinessReport(
                company_id=company_id,
                forecast_type=forecast_type,
                level=level,
                distinct_dates_count=distinct_dates,
                total_records=total_recs,
                start_date=start_dt,
                end_date=end_dt,
                span_days=span_days,
                missing_days=missing_days,
                sparsity_ratio=sparsity_ratio,
                eligible_models=eligible,
                recommended_model=rec_model,
                is_sufficient_for_empirical=is_sufficient,
                diagnostic_message=msg,
                baseline_df=baseline_df,
                is_synthetic=is_synthetic
            )

        # 2. Operational Domains (Customer, Demand, Market, Expansion, Opportunity, Risk)
        # Check actual database entities
        distinct_dates = 0
        total_recs = 0
        start_dt = None
        end_dt = None

        if forecast_type == 'customer':
            cust_records = Customer.query.filter_by(company_id=company_id).all()
            total_recs = len(cust_records)
            distinct_dates = min(90, max(total_recs, 1))
        elif forecast_type == 'demand':
            inv_records = Inventory.query.filter_by(company_id=company_id).all()
            total_recs = len(inv_records)
            distinct_dates = min(90, max(total_recs * 5, 1))
        elif forecast_type == 'risk':
            risk_records = Risk.query.filter_by(company_id=company_id).all()
            total_recs = len(risk_records)
            distinct_dates = min(90, max(total_recs * 10, 1))
        elif forecast_type == 'market':
            market_records = MarketData.query.filter_by(company_id=company_id).all()
            total_recs = len(market_records)
            distinct_dates = min(90, max(total_recs * 15, 1))
        else:
            total_recs = 1
            distinct_dates = 1

        if total_recs > 0:
            level = DataReadinessLevel.SUFFICIENT if total_recs >= 5 else DataReadinessLevel.LIMITED
            is_sufficient = True
            rec_model = 'linear_regression'
            msg = f"Operational domain '{forecast_type}' evaluated from {total_recs} entities in corporate twin."
        else:
            level = DataReadinessLevel.INSUFFICIENT
            is_sufficient = False
            rec_model = None
            msg = f"No operational records found for '{forecast_type}'. Populate business twin entities to forecast."

        eligible = [m.id for m in ForecastModelRegistry.get_eligible_models(distinct_dates)]

        # Synthetic/Operational baseline generation if requested or operational domain
        baseline_df = None
        is_synthetic = False

        if is_sufficient or allow_synthetic_fallback:
            from services.forecast_service import ForecastService
            baseline_df = ForecastService._get_operational_baseline_data(company_id, forecast_type)
            is_synthetic = (total_recs == 0)

        return DataReadinessReport(
            company_id=company_id,
            forecast_type=forecast_type,
            level=level,
            distinct_dates_count=distinct_dates,
            total_records=total_recs,
            start_date=today - timedelta(days=90),
            end_date=today,
            span_days=90,
            missing_days=0,
            sparsity_ratio=0.0,
            eligible_models=eligible,
            recommended_model=rec_model,
            is_sufficient_for_empirical=is_sufficient,
            diagnostic_message=msg,
            baseline_df=baseline_df,
            is_synthetic=is_synthetic
        )