"""
AEVORYN / INSIGHT-PULSE
DECISION INTELLIGENCE SERVICE (STAGE 18)

Provides high-level APIs for orchestrating decision intelligence scans, retrieving explainable
insights, filtering by category/source, and dispatching domain events.
"""

import logging
from typing import List, Dict, Any, Optional
from datetime import datetime

from database.db import db
from database.models.company import Company
from services.decision_intelligence.engine import DecisionIntelligenceEngine
from services.decision_intelligence.types import (
    DecisionInsight, InsightSource, InsightCategory, InsightSeverity
)
from services.events import EventBus, EventTypes, DomainEvent

logger = logging.getLogger(__name__)


class DecisionIntelligenceService:
    """
    High-level facade for enterprise decision intelligence and honest insights.
    """

    @classmethod
    def get_insights(
        cls,
        company_id: int,
        category: Optional[str] = None,
        source: Optional[str] = None
    ) -> List[DecisionInsight]:
        """
        Synthesizes and retrieves active decision insights for a company,
        optionally filtered by category or provenance source.
        """
        insights = DecisionIntelligenceEngine.evaluate_all(company_id)

        if category:
            insights = [i for i in insights if i.category.upper() == category.upper()]
        if source:
            insights = [i for i in insights if i.source.upper() == source.upper()]

        return insights

    @classmethod
    def run_decision_scan(
        cls,
        company_id: int,
        actor_user_id: Optional[int] = None,
        publish_events: bool = True
    ) -> Dict[str, Any]:
        """
        Executes a full decision intelligence scan, calculates summary metrics,
        and publishes DECISION_SCAN_COMPLETED event.
        """
        company = Company.query.get(company_id)
        if not company:
            return {"error": "Company not found", "success": False, "insights": []}

        insights = DecisionIntelligenceEngine.evaluate_all(company_id)

        by_severity = {
            "critical": len([i for i in insights if i.severity == InsightSeverity.CRITICAL]),
            "high": len([i for i in insights if i.severity == InsightSeverity.HIGH]),
            "medium": len([i for i in insights if i.severity == InsightSeverity.MEDIUM]),
            "low": len([i for i in insights if i.severity == InsightSeverity.LOW]),
            "opportunity": len([i for i in insights if i.severity == InsightSeverity.OPPORTUNITY]),
            "info": len([i for i in insights if i.severity == InsightSeverity.INFO])
        }

        by_source = {
            "rule": len([i for i in insights if i.source == InsightSource.RULE]),
            "statistical_model": len([i for i in insights if i.source == InsightSource.STATISTICAL_MODEL]),
            "simulation": len([i for i in insights if i.source == InsightSource.SIMULATION]),
            "systemic_impact": len([i for i in insights if i.source == InsightSource.SYSTEMIC_IMPACT])
        }

        scan_result = {
            "success": True,
            "company_id": company_id,
            "scanned_at": datetime.utcnow().isoformat(),
            "total_insights": len(insights),
            "by_severity": by_severity,
            "by_source": by_source,
            "insights": [i.to_dict() for i in insights]
        }

        if publish_events:
            try:
                EventBus.publish(DomainEvent.create(
                    event_type=EventTypes.DECISION_SCAN_COMPLETED,
                    company_id=company_id,
                    aggregate_type="decision_scan",
                    aggregate_id=f"scan-{company_id}-{int(datetime.utcnow().timestamp())}",
                    actor_id=actor_user_id,
                    payload={
                        "total_insights": len(insights),
                        "critical_count": by_severity["critical"],
                        "high_count": by_severity["high"],
                        "sources": by_source
                    }
                ), commit=True)
            except Exception as ev_err:
                logger.error(f"Failed to publish DECISION_SCAN_COMPLETED event: {ev_err}")

        return scan_result

    @classmethod
    def explain_insight(cls, company_id: int, insight_id: str) -> Optional[Dict[str, Any]]:
        """
        Returns full transparent evidence and explainability details for a specific insight.
        Guarantees tenant isolation: returns None if company_id does not match.
        """
        insights = DecisionIntelligenceEngine.evaluate_all(company_id)
        target = next((i for i in insights if i.id == insight_id), None)
        if not target:
            return None

        return {
            "id": target.id,
            "company_id": company_id,
            "title": target.title,
            "summary": target.summary,
            "detailed_explanation": target.detailed_explanation,
            "source": target.source,
            "source_label": target.source_label,
            "category": target.category,
            "severity": target.severity,
            "evidence": target.evidence,
            "confidence": target.confidence.to_dict(),
            "recommended_action": target.recommended_action,
            "expected_impact": target.expected_impact,
            "created_at": target.created_at.isoformat() if target.created_at else None
        }
