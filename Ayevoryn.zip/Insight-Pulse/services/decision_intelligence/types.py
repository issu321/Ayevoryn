"""
AEVORYN / INSIGHT-PULSE
DECISION INTELLIGENCE OBJECT MODEL (STAGE 18)

Provides canonical types, provenance metadata, and honest statistical confidence structures
for decision intelligence insights, completely eliminating hardcoded confidence percentages.
"""

from dataclasses import dataclass, field, asdict
from typing import Dict, Any, Optional, List
from datetime import datetime
import uuid


class InsightSource:
    RULE = "RULE"
    STATISTICAL_MODEL = "STATISTICAL_MODEL"
    SIMULATION = "SIMULATION"
    SYSTEMIC_IMPACT = "SYSTEMIC_IMPACT"

    ALL = [RULE, STATISTICAL_MODEL, SIMULATION, SYSTEMIC_IMPACT]


class InsightCategory:
    FINANCIAL = "FINANCIAL"
    PROFITABILITY = "PROFITABILITY"
    OPERATIONAL = "OPERATIONAL"
    SUPPLY_CHAIN = "SUPPLY_CHAIN"
    CUSTOMERS = "CUSTOMERS"
    GROWTH = "GROWTH"
    GOVERNANCE = "GOVERNANCE"

    ALL = [FINANCIAL, PROFITABILITY, OPERATIONAL, SUPPLY_CHAIN, CUSTOMERS, GROWTH, GOVERNANCE]


class InsightSeverity:
    CRITICAL = "CRITICAL"
    HIGH = "HIGH"
    MEDIUM = "MEDIUM"
    LOW = "LOW"
    OPPORTUNITY = "OPPORTUNITY"
    INFO = "INFO"

    ALL = [CRITICAL, HIGH, MEDIUM, LOW, OPPORTUNITY, INFO]


@dataclass
class ConfidenceMetric:
    """
    Honest statistical confidence metric based on empirical sample size,
    variance, and methodology. Replaces hardcoded integers.
    """
    methodology: str
    sample_size: int = 0
    variance_metric: Optional[str] = None
    score: Optional[float] = None
    is_heuristic_estimate: bool = False
    label: str = ""

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class DecisionInsight:
    """
    Explainable, auditable insight object with source provenance,
    verifiable evidence, statistical bounds, and actionable mitigation paths.
    """
    id: str
    company_id: int
    source: str
    source_label: str
    category: str
    severity: str
    type: str  # 'warning', 'alert', 'success', 'info', 'opportunity' (UI helper)
    title: str
    summary: str
    detailed_explanation: str
    evidence: Dict[str, Any]
    confidence: ConfidenceMetric
    recommended_action: str
    expected_impact: Optional[str] = None
    created_at: datetime = field(default_factory=datetime.utcnow)

    def to_dict(self) -> Dict[str, Any]:
        data = asdict(self)
        data['created_at'] = self.created_at.isoformat() if self.created_at else None
        # Provide backward-compatible confidence representation
        if self.confidence.score is not None:
            data['confidence_pct'] = round(self.confidence.score * 100, 1)
        else:
            data['confidence_pct'] = None
        data['confidence_label'] = self.confidence.label
        data['action'] = self.recommended_action  # template compatibility
        data['description'] = self.summary  # template compatibility
        return data

    @classmethod
    def create(
        cls,
        company_id: int,
        source: str,
        source_label: str,
        category: str,
        severity: str,
        type_str: str,
        title: str,
        summary: str,
        detailed_explanation: str,
        evidence: Dict[str, Any],
        confidence: ConfidenceMetric,
        recommended_action: str,
        expected_impact: Optional[str] = None,
        insight_id: Optional[str] = None
    ) -> 'DecisionInsight':
        return cls(
            id=insight_id or str(uuid.uuid4()),
            company_id=company_id,
            source=source,
            source_label=source_label,
            category=category,
            severity=severity,
            type=type_str,
            title=title,
            summary=summary,
            detailed_explanation=detailed_explanation,
            evidence=evidence or {},
            confidence=confidence,
            recommended_action=recommended_action,
            expected_impact=expected_impact,
            created_at=datetime.utcnow()
        )
