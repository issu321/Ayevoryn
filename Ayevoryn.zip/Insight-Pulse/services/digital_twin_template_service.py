"""
AEVORYN / INSIGHT-PULSE
DIGITAL TWIN TEMPLATE IMPORT AND EXPORT SYSTEM
Unified service for generating schema-driven Excel and JSON templates,
validating uploaded records (preview-first), executing transactional imports (insert/update/upsert),
and exporting authoritative datasets with multi-tenant isolation and business intelligence synchronization.
"""

import io
import json
import re
from datetime import datetime, date
from typing import Dict, List, Any, Tuple, Optional
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from database.db import db
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.import_history import ImportHistory
from database.models.export_history import ExportHistory
from database.models.audit_log import AuditLog
from services.twin_service import TwinService


# Styling constants for Excel generation
NAVY_HEADER_FILL = PatternFill(start_color="1E293B", end_color="1E293B", fill_type="solid")
ACCENT_HEADER_FILL = PatternFill(start_color="2563EB", end_color="2563EB", fill_type="solid")
MUTED_HEADER_FILL = PatternFill(start_color="334155", end_color="334155", fill_type="solid")
LIGHT_ROW_FILL = PatternFill(start_color="F8FAFC", end_color="F8FAFC", fill_type="solid")
WHITE_FONT = Font(name="Segoe UI", size=10, bold=True, color="FFFFFF")
TITLE_FONT = Font(name="Segoe UI", size=14, bold=True, color="1E293B")
SUBTITLE_FONT = Font(name="Segoe UI", size=10, italic=True, color="64748B")
REGULAR_FONT = Font(name="Segoe UI", size=10, color="0F172A")
BOLD_FONT = Font(name="Segoe UI", size=10, bold=True, color="0F172A")
CODE_FONT = Font(name="Consolas", size=9, color="334155")
THIN_BORDER_SIDE = Side(border_style="thin", color="E2E8F0")
CELL_BORDER = Border(left=THIN_BORDER_SIDE, right=THIN_BORDER_SIDE, top=THIN_BORDER_SIDE, bottom=THIN_BORDER_SIDE)


class DigitalTwinTemplateService:
    """Enterprise service governing digital twin data exchange schemas and workflows."""

    TWIN_SCHEMAS: Dict[str, Dict[str, Any]] = {
        'revenue': {
            'display_name': 'Revenue Streams & Invoices',
            'model_name': 'FinancialRecord (Revenue)',
            'description': 'Authoritative incoming revenue transactions, client billings, and recognized cash flows.',
            'fields': [
                {'key': 'transaction_date', 'label': 'Transaction Date', 'type': 'date', 'required': True, 'desc': 'Date of revenue recognition (YYYY-MM-DD)', 'example': '2026-03-15'},
                {'key': 'category', 'label': 'Revenue Category', 'type': 'string', 'required': True, 'desc': 'High-level category (e.g. Software Subscriptions, Consulting, Enterprise Licenses)', 'example': 'Software Subscriptions'},
                {'key': 'subcategory', 'label': 'Subcategory', 'type': 'string', 'required': False, 'desc': 'Granular segment (e.g. ARR, Professional Services, Overage)', 'example': 'ARR'},
                {'key': 'amount', 'label': 'Amount', 'type': 'float', 'required': True, 'desc': 'Positive monetary amount recognized in company currency', 'example': 25000.00},
                {'key': 'reference_number', 'label': 'Reference / Invoice #', 'type': 'string', 'required': False, 'desc': 'Unique invoice or transaction identifier', 'example': 'INV-2026-0042'},
                {'key': 'department_name', 'label': 'Department', 'type': 'string', 'required': False, 'desc': 'Attributed department name or code', 'example': 'Sales'},
                {'key': 'description', 'label': 'Description', 'type': 'string', 'required': False, 'desc': 'Contextual narrative of the transaction', 'example': 'Annual platform license renewal'},
                {'key': 'is_recurring', 'label': 'Is Recurring (Y/N)', 'type': 'boolean', 'required': False, 'desc': 'Whether this is recurring revenue (Yes/No or Y/N)', 'example': 'Yes'},
                {'key': 'recurring_frequency', 'label': 'Frequency', 'type': 'string', 'required': False, 'desc': 'Monthly, Quarterly, Annual, or One-time', 'example': 'Annual'}
            ]
        },
        'expenses': {
            'display_name': 'Operating Expenses & Opex',
            'model_name': 'FinancialRecord (Expense)',
            'description': 'Authorized company expenditures, departmental disbursements, vendor payments, and operational costs.',
            'fields': [
                {'key': 'transaction_date', 'label': 'Transaction Date', 'type': 'date', 'required': True, 'desc': 'Date of expense disbursement (YYYY-MM-DD)', 'example': '2026-03-18'},
                {'key': 'category', 'label': 'Expense Category', 'type': 'string', 'required': True, 'desc': 'Cost center (e.g. Cloud Infrastructure, Marketing, Payroll, Facilities)', 'example': 'Cloud Infrastructure'},
                {'key': 'subcategory', 'label': 'Subcategory', 'type': 'string', 'required': False, 'desc': 'Granular category (e.g. AWS Servers, SaaS Tooling, Ad Spend)', 'example': 'AWS Servers'},
                {'key': 'amount', 'label': 'Amount', 'type': 'float', 'required': True, 'desc': 'Positive expense amount disbursed', 'example': 4200.50},
                {'key': 'reference_number', 'label': 'Reference / Receipt #', 'type': 'string', 'required': False, 'desc': 'Vendor invoice or purchase order number', 'example': 'PO-7891'},
                {'key': 'department_name', 'label': 'Department', 'type': 'string', 'required': False, 'desc': 'Department responsible for this expense', 'example': 'Engineering'},
                {'key': 'description', 'label': 'Description', 'type': 'string', 'required': False, 'desc': 'Line item explanation', 'example': 'Production cluster compute fees'},
                {'key': 'is_recurring', 'label': 'Is Recurring (Y/N)', 'type': 'boolean', 'required': False, 'desc': 'Whether this is recurring opex (Yes/No)', 'example': 'Yes'},
                {'key': 'recurring_frequency', 'label': 'Frequency', 'type': 'string', 'required': False, 'desc': 'Monthly, Quarterly, Annual', 'example': 'Monthly'}
            ]
        },
        'customers': {
            'display_name': 'Customer Accounts & Client Directory',
            'model_name': 'Customer',
            'description': 'Customer accounts, relationship history, lifetime value metrics, and cohort segmentation.',
            'fields': [
                {'key': 'customer_code', 'label': 'Customer Code', 'type': 'string', 'required': False, 'desc': 'Unique customer ID (e.g. CUST-001). Auto-assigned if omitted.', 'example': 'CUST-1001'},
                {'key': 'first_name', 'label': 'First Name', 'type': 'string', 'required': True, 'desc': 'Primary contact first name', 'example': 'Sarah'},
                {'key': 'last_name', 'label': 'Last Name', 'type': 'string', 'required': True, 'desc': 'Primary contact surname', 'example': 'Jenkins'},
                {'key': 'company_name', 'label': 'Organization / Company', 'type': 'string', 'required': False, 'desc': 'Client legal entity or company name', 'example': 'Pinnacle Capital Partners'},
                {'key': 'email', 'label': 'Email Address', 'type': 'email', 'required': True, 'desc': 'Corporate contact email', 'example': 's.jenkins@pinnacle.com'},
                {'key': 'phone', 'label': 'Phone Number', 'type': 'string', 'required': False, 'desc': 'Direct contact number', 'example': '+1 415 555 0192'},
                {'key': 'city', 'label': 'City', 'type': 'string', 'required': False, 'desc': 'Metropolitan jurisdiction', 'example': 'New York'},
                {'key': 'country', 'label': 'Country', 'type': 'string', 'required': False, 'desc': 'Country of residence or incorporation', 'example': 'United States'},
                {'key': 'segment', 'label': 'Account Segment', 'type': 'string', 'required': False, 'desc': 'Enterprise, Mid-Market, Growth SMB, Emerging', 'example': 'Enterprise'},
                {'key': 'lifetime_value', 'label': 'Lifetime Value (LTV)', 'type': 'float', 'required': False, 'desc': 'Cumulative historical or contract value', 'example': 120000.00},
                {'key': 'acquisition_cost', 'label': 'Acquisition Cost (CAC)', 'type': 'float', 'required': False, 'desc': 'Total customer acquisition cost', 'example': 8500.00},
                {'key': 'status', 'label': 'Account Status', 'type': 'string', 'required': False, 'desc': 'active, churned, dormant, lead', 'example': 'active'}
            ]
        },
        'employees': {
            'display_name': 'Workforce & Department Staffing',
            'model_name': 'Employee',
            'description': 'Personnel records, departmental placement, payroll base, compensation packages, and talent topology.',
            'fields': [
                {'key': 'employee_code', 'label': 'Employee Code', 'type': 'string', 'required': False, 'desc': 'Employee identifier (e.g. EMP-001). Auto-assigned if omitted.', 'example': 'EMP-0105'},
                {'key': 'first_name', 'label': 'First Name', 'type': 'string', 'required': True, 'desc': 'Legal first name', 'example': 'Marcus'},
                {'key': 'last_name', 'label': 'Last Name', 'type': 'string', 'required': True, 'desc': 'Legal surname', 'example': 'Sterling'},
                {'key': 'email', 'label': 'Work Email', 'type': 'email', 'required': True, 'desc': 'Official enterprise work email', 'example': 'm.sterling@company.com'},
                {'key': 'phone', 'label': 'Contact Phone', 'type': 'string', 'required': False, 'desc': 'Work phone number', 'example': '+1 212 555 0147'},
                {'key': 'department_name', 'label': 'Department', 'type': 'string', 'required': False, 'desc': 'Assigned department name or code', 'example': 'Engineering'},
                {'key': 'job_title', 'label': 'Job Title / Designation', 'type': 'string', 'required': True, 'desc': 'Role designation', 'example': 'Principal Systems Architect'},
                {'key': 'employment_type', 'label': 'Employment Type', 'type': 'string', 'required': False, 'desc': 'full_time, part_time, contractor', 'example': 'full_time'},
                {'key': 'salary', 'label': 'Annual Base Salary', 'type': 'float', 'required': True, 'desc': 'Annual base compensation in company currency', 'example': 165000.00},
                {'key': 'benefits_cost', 'label': 'Annual Benefits Cost', 'type': 'float', 'required': False, 'desc': 'Health, retirement, and payroll tax load', 'example': 22000.00},
                {'key': 'hire_date', 'label': 'Hire Date', 'type': 'date', 'required': False, 'desc': 'Date of employment commencement (YYYY-MM-DD)', 'example': '2025-06-01'},
                {'key': 'status', 'label': 'Status', 'type': 'string', 'required': False, 'desc': 'active, on_leave, terminated', 'example': 'active'}
            ]
        },
        'suppliers': {
            'display_name': 'Suppliers & Vendor Network',
            'model_name': 'Supplier',
            'description': 'Supply chain partners, procurement channels, vendor ratings, payment terms, and spend commitments.',
            'fields': [
                {'key': 'supplier_code', 'label': 'Supplier Code', 'type': 'string', 'required': False, 'desc': 'Vendor code (e.g. SUP-001). Auto-assigned if omitted.', 'example': 'SUP-0024'},
                {'key': 'name', 'label': 'Supplier / Vendor Name', 'type': 'string', 'required': True, 'desc': 'Official vendor business name', 'example': 'Apex Global Silicon Corp'},
                {'key': 'contact_person', 'label': 'Contact Person', 'type': 'string', 'required': False, 'desc': 'Account manager or representative', 'example': 'David Lin'},
                {'key': 'email', 'label': 'Vendor Email', 'type': 'email', 'required': False, 'desc': 'Accounts receivable or support email', 'example': 'orders@apexsilicon.com'},
                {'key': 'phone', 'label': 'Phone Number', 'type': 'string', 'required': False, 'desc': 'Vendor telephone', 'example': '+1 408 555 0188'},
                {'key': 'city', 'label': 'City', 'type': 'string', 'required': False, 'desc': 'Headquarter city', 'example': 'San Jose'},
                {'key': 'country', 'label': 'Country', 'type': 'string', 'required': False, 'desc': 'Headquarter country', 'example': 'United States'},
                {'key': 'category', 'label': 'Category', 'type': 'string', 'required': False, 'desc': 'Hardware, Raw Materials, Logistics, Professional Services', 'example': 'Hardware & Parts'},
                {'key': 'payment_terms', 'label': 'Payment Terms', 'type': 'string', 'required': False, 'desc': 'Due on Receipt, Net 15, Net 30, Net 60', 'example': 'Net 30'},
                {'key': 'rating', 'label': 'Performance Rating (1-5)', 'type': 'float', 'required': False, 'desc': 'Vendor reliability score from 1.0 to 5.0', 'example': 4.8},
                {'key': 'status', 'label': 'Status', 'type': 'string', 'required': False, 'desc': 'active, inactive, pending_review', 'example': 'active'}
            ]
        },
        'inventory': {
            'display_name': 'Inventory & Stock Assets',
            'model_name': 'Inventory',
            'description': 'Physical and digital inventory stock, SKUs, reorder thresholds, unit valuation, and storage locations.',
            'fields': [
                {'key': 'sku', 'label': 'SKU / Item Identifier', 'type': 'string', 'required': True, 'desc': 'Unique Stock Keeping Unit (e.g. AEV-HW-001)', 'example': 'AEV-HW-0042'},
                {'key': 'product_name', 'label': 'Product / Asset Name', 'type': 'string', 'required': True, 'desc': 'Descriptive item name', 'example': 'Optic Transceiver Module X2'},
                {'key': 'category', 'label': 'Category', 'type': 'string', 'required': False, 'desc': 'Finished Goods, Raw Materials, Packaging, Hardware', 'example': 'Hardware & Parts'},
                {'key': 'quantity_on_hand', 'label': 'Quantity On Hand', 'type': 'integer', 'required': True, 'desc': 'Current physical units in stock', 'example': 350},
                {'key': 'unit_cost', 'label': 'Unit Cost', 'type': 'float', 'required': True, 'desc': 'Procurement or manufacturing cost per unit', 'example': 84.50},
                {'key': 'selling_price', 'label': 'Selling / List Price', 'type': 'float', 'required': True, 'desc': 'Retail or contract price per unit', 'example': 149.99},
                {'key': 'reorder_point', 'label': 'Reorder Threshold', 'type': 'integer', 'required': False, 'desc': 'Minimum units before reorder triggers', 'example': 50},
                {'key': 'reorder_quantity', 'label': 'Reorder Batch Size', 'type': 'integer', 'required': False, 'desc': 'Standard order batch quantity', 'example': 200},
                {'key': 'location', 'label': 'Warehouse / Location', 'type': 'string', 'required': False, 'desc': 'Storage facility or bin reference', 'example': 'Bay Area Hub - Bin 4A'},
                {'key': 'status', 'label': 'Stock Status', 'type': 'string', 'required': False, 'desc': 'in_stock, low_stock, out_of_stock, discontinued', 'example': 'in_stock'}
            ]
        },
        'departments': {
            'display_name': 'Organizational Structure & Departments',
            'model_name': 'Department',
            'description': 'Organizational divisions, assigned leadership, operating authorities, and budget allocations.',
            'fields': [
                {'key': 'name', 'label': 'Department Name', 'type': 'string', 'required': True, 'desc': 'Official division or department name', 'example': 'Applied AI Research'},
                {'key': 'code', 'label': 'Department Code', 'type': 'string', 'required': False, 'desc': 'Short code (e.g. AI-RES)', 'example': 'AIR'},
                {'key': 'description', 'label': 'Description', 'type': 'string', 'required': False, 'desc': 'Operational mission and scope', 'example': 'Designs and evaluates predictive neural architectures'},
                {'key': 'head_name', 'label': 'Leader Name', 'type': 'string', 'required': False, 'desc': 'Department lead or executive name', 'example': 'Dr. Elena Rostova'},
                {'key': 'head_email', 'label': 'Leader Work Email', 'type': 'email', 'required': False, 'desc': 'Leader email for pending invitation or account binding', 'example': 'elena.r@company.com'},
                {'key': 'head_designation', 'label': 'Leader Designation', 'type': 'string', 'required': False, 'desc': 'Vice President, Director, Head of...', 'example': 'VP of Machine Learning'},
                {'key': 'budget', 'label': 'Operating Budget', 'type': 'float', 'required': False, 'desc': 'Total allocated financial plan amount', 'example': 450000.00},
                {'key': 'budget_period', 'label': 'Budget Period', 'type': 'string', 'required': False, 'desc': 'Annual, Quarterly, Monthly', 'example': 'Annual'},
                {'key': 'responsibilities', 'label': 'Core Responsibilities', 'type': 'string', 'required': False, 'desc': 'Summary of departmental responsibilities', 'example': 'Algorithm training, model benchmarking, inference speedup'},
                {'key': 'team_size', 'label': 'Estimated Headcount', 'type': 'integer', 'required': False, 'desc': 'Planned or actual team members', 'example': 12},
                {'key': 'contact_email', 'label': 'Division Contact Email', 'type': 'email', 'required': False, 'desc': 'General departmental inbox', 'example': 'ai-team@company.com'}
            ]
        }
    }

    @classmethod
    def get_supported_twins(cls) -> List[Dict[str, Any]]:
        """List all digital twin types available for schema export/import."""
        return [
            {
                'key': k,
                'display_name': v['display_name'],
                'model_name': v['model_name'],
                'description': v['description'],
                'field_count': len(v['fields'])
            }
            for k, v in cls.TWIN_SCHEMAS.items()
        ]

    @classmethod
    def get_schema(cls, twin_type: str, custom_twin_id: Optional[int] = None, company_id: Optional[int] = None) -> Optional[Dict[str, Any]]:
        """Retrieve schema dictionary for a core twin or custom twin."""
        if twin_type == 'custom_twin' and custom_twin_id:
            twin = CustomTwin.query.filter_by(id=custom_twin_id, company_id=company_id).first()
            if not twin:
                return None
            schema_fields = twin.get_schema_fields()
            fields = []
            for sf in schema_fields:
                fields.append({
                    'key': sf.get('name'),
                    'label': sf.get('label') or sf.get('name'),
                    'type': sf.get('type', 'string'),
                    'required': bool(sf.get('required')),
                    'desc': sf.get('description', ''),
                    'example': sf.get('default_value') or 'Example Value'
                })
            return {
                'display_name': twin.name,
                'model_name': f"CustomTwin ({twin.slug})",
                'description': twin.description or 'Custom enterprise digital twin dataset.',
                'fields': fields
            }
        return cls.TWIN_SCHEMAS.get(twin_type)

    @classmethod
    def generate_excel_template(cls, twin_type: str, company_id: Optional[int] = None, custom_twin_id: Optional[int] = None) -> Tuple[io.BytesIO, str]:
        """
        Generate an enterprise Excel template with Read Me, Data Records,
        Field Definitions, and Allowed Values reference data.
        """
        schema = cls.get_schema(twin_type, custom_twin_id=custom_twin_id, company_id=company_id)
        if not schema:
            raise ValueError(f"Unknown digital twin model: {twin_type}")

        company = Company.query.get(company_id) if company_id else None
        comp_name = company.company_name if company else "AEVORYN Enterprise"
        wb = openpyxl.Workbook()

        # ==========================================
        # SHEET 1: READ ME
        # ==========================================
        ws_readme = wb.active
        ws_readme.title = "Read Me"
        ws_readme.views.sheetView[0].showGridLines = True

        ws_readme.merge_cells("A1:E1")
        title_cell = ws_readme["A1"]
        title_cell.value = f"{comp_name} — Digital Twin Template: {schema['display_name']}"
        title_cell.font = TITLE_FONT

        ws_readme["A2"] = f"Generated on {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} | Schema Version: 2.4 | Model: {schema['model_name']}"
        ws_readme["A2"].font = SUBTITLE_FONT

        instructions = [
            ("1. Overview", schema['description']),
            ("2. How to Populate", "Enter your organization's verified operational records in the 'Data Records' sheet. Row 4 contains column headers; enter records starting on Row 5."),
            ("3. Required Fields", "Columns marked with an asterisk (*) are strictly required. Rows missing required fields will be rejected during validation."),
            ("4. Date Formats", "All date columns must follow the standard ISO format: YYYY-MM-DD (e.g. 2026-04-15)."),
            ("5. Numeric & Financial Fields", "Enter currency values and numbers without currency symbols ($ or ₹) or comma thousands separators."),
            ("6. Preview-First Guarantee", "When uploaded, Ayevoryn performs a non-destructive dry-run validation preview before committing any records to your live digital twin.")
        ]

        curr_row = 4
        for heading, body in instructions:
            ws_readme.cell(row=curr_row, column=1, value=heading).font = BOLD_FONT
            ws_readme.cell(row=curr_row + 1, column=1, value=body).font = REGULAR_FONT
            curr_row += 3

        ws_readme.column_dimensions["A"].width = 110

        # ==========================================
        # SHEET 2: DATA RECORDS
        # ==========================================
        ws_data = wb.create_sheet(title="Data Records")
        ws_data.views.sheetView[0].showGridLines = True

        # Header titles
        fields = schema['fields']
        for col_idx, fld in enumerate(fields, start=1):
            req_mark = " *" if fld['required'] else ""
            header_cell = ws_data.cell(row=1, column=col_idx, value=f"{fld['label']}{req_mark}")
            header_cell.fill = ACCENT_HEADER_FILL if fld['required'] else NAVY_HEADER_FILL
            header_cell.font = WHITE_FONT
            header_cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            header_cell.border = CELL_BORDER

            # Key sub-header
            key_cell = ws_data.cell(row=2, column=col_idx, value=fld['key'])
            key_cell.fill = MUTED_HEADER_FILL
            key_cell.font = CODE_FONT
            key_cell.alignment = Alignment(horizontal="center", vertical="center")
            key_cell.border = CELL_BORDER

            # Example row
            example_cell = ws_data.cell(row=3, column=col_idx, value=fld.get('example', ''))
            example_cell.fill = LIGHT_ROW_FILL
            example_cell.font = SUBTITLE_FONT
            example_cell.border = CELL_BORDER

            # Auto column width
            header_len = max(len(fld['label']), len(fld['key']), len(str(fld.get('example', ''))))
            col_letter = get_column_letter(col_idx)
            ws_data.column_dimensions[col_letter].width = max(18, header_len + 4)

        ws_data.row_dimensions[1].height = 28
        ws_data.row_dimensions[2].height = 18
        ws_data.row_dimensions[3].height = 20

        # ==========================================
        # SHEET 3: FIELD DEFINITIONS
        # ==========================================
        ws_defs = wb.create_sheet(title="Field Definitions")
        ws_defs.views.sheetView[0].showGridLines = True

        def_headers = ["Field Name", "Technical Key", "Data Type", "Required", "Description", "Example Value"]
        for col_idx, h in enumerate(def_headers, start=1):
            c = ws_defs.cell(row=1, column=col_idx, value=h)
            c.fill = NAVY_HEADER_FILL
            c.font = WHITE_FONT
            c.alignment = Alignment(horizontal="left", vertical="center")
            c.border = CELL_BORDER

        for row_idx, fld in enumerate(fields, start=2):
            ws_defs.cell(row=row_idx, column=1, value=fld['label']).font = BOLD_FONT
            ws_defs.cell(row=row_idx, column=2, value=fld['key']).font = CODE_FONT
            ws_defs.cell(row=row_idx, column=3, value=fld['type'].upper()).font = REGULAR_FONT
            ws_defs.cell(row=row_idx, column=4, value="Yes (Mandatory)" if fld['required'] else "No (Optional)").font = BOLD_FONT if fld['required'] else REGULAR_FONT
            ws_defs.cell(row=row_idx, column=5, value=fld['desc']).font = REGULAR_FONT
            ws_defs.cell(row=row_idx, column=6, value=str(fld.get('example', ''))).font = REGULAR_FONT

            for c_idx in range(1, 7):
                ws_defs.cell(row=row_idx, column=c_idx).border = CELL_BORDER

        ws_defs.column_dimensions["A"].width = 24
        ws_defs.column_dimensions["B"].width = 22
        ws_defs.column_dimensions["C"].width = 16
        ws_defs.column_dimensions["D"].width = 18
        ws_defs.column_dimensions["E"].width = 48
        ws_defs.column_dimensions["F"].width = 24

        # ==========================================
        # SHEET 4: ALLOWED VALUES & REFERENCES
        # ==========================================
        ws_ref = wb.create_sheet(title="Allowed Values")
        ws_ref.views.sheetView[0].showGridLines = True

        ws_ref.cell(row=1, column=1, value="Reference Category").font = WHITE_FONT
        ws_ref.cell(row=1, column=1).fill = NAVY_HEADER_FILL
        ws_ref.cell(row=1, column=2, value="Authoritative Organization Reference Values").font = WHITE_FONT
        ws_ref.cell(row=1, column=2).fill = NAVY_HEADER_FILL

        # Retrieve real company departments for reference
        dept_names = []
        if company_id:
            dept_names = [d.name for d in Department.query.filter_by(company_id=company_id, is_active=True).all()]
        if not dept_names:
            dept_names = ["(No departments configured yet — you can create them dynamically)"]

        ref_data = [
            ("Organization Currency", company.currency if company else "USD"),
            ("Configured Departments", ", ".join(dept_names)),
            ("Standard Customer Segments", "Enterprise, Mid-Market, Growth SMB, Emerging"),
            ("Standard Employment Types", "full_time, part_time, contractor"),
            ("Standard Stock Statuses", "in_stock, low_stock, out_of_stock, discontinued"),
            ("Supported Payment Terms", "Due on Receipt, Net 15, Net 30, Net 60")
        ]

        for r_idx, (cat, val) in enumerate(ref_data, start=2):
            ws_ref.cell(row=r_idx, column=1, value=cat).font = BOLD_FONT
            ws_ref.cell(row=r_idx, column=1).border = CELL_BORDER
            ws_ref.cell(row=r_idx, column=2, value=val).font = REGULAR_FONT
            ws_ref.cell(row=r_idx, column=2).border = CELL_BORDER

        ws_ref.column_dimensions["A"].width = 30
        ws_ref.column_dimensions["B"].width = 70

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        filename = f"{twin_type}_digital_twin_template.xlsx"
        return buf, filename

    @classmethod
    def generate_json_template(cls, twin_type: str, company_id: Optional[int] = None, custom_twin_id: Optional[int] = None) -> Dict[str, Any]:
        """Generate schema-compliant JSON template with field definitions and sample records."""
        schema = cls.get_schema(twin_type, custom_twin_id=custom_twin_id, company_id=company_id)
        if not schema:
            raise ValueError(f"Unknown digital twin model: {twin_type}")

        company = Company.query.get(company_id) if company_id else None
        sample_record = {}
        for fld in schema['fields']:
            val = fld.get('example')
            if fld['type'] == 'integer' and isinstance(val, (int, str)):
                try: val = int(val)
                except Exception: val = 1
            elif fld['type'] == 'float' and isinstance(val, (float, int, str)):
                try: val = float(val)
                except Exception: val = 100.0
            sample_record[fld['key']] = val

        return {
            '$schema': 'https://aevoryn.global/schemas/digital-twin-template-v2.json',
            'schema_version': '2.4',
            'model_type': twin_type,
            'model_name': schema['model_name'],
            'organization': company.company_name if company else 'AEVORYN Organization',
            'organization_currency': company.currency if company else 'USD',
            'generated_at': datetime.utcnow().isoformat() + 'Z',
            'field_definitions': {
                f['key']: {
                    'label': f['label'],
                    'type': f['type'],
                    'required': f['required'],
                    'description': f['desc']
                }
                for f in schema['fields']
            },
            'example_records': [sample_record],
            'records': [sample_record]
        }

    # =========================================================================
    # PREVIEW-FIRST IMPORT VALIDATION
    # =========================================================================

    @classmethod
    def validate_uploaded_data(
        cls,
        twin_type: str,
        file_bytes: bytes,
        filename: str,
        company_id: int,
        custom_twin_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Preview-first validation of uploaded Excel or JSON records.
        Does NOT write to database. Returns full validation diagnostics.
        """
        schema = cls.get_schema(twin_type, custom_twin_id=custom_twin_id, company_id=company_id)
        if not schema:
            return {'success': False, 'error': f"Unknown twin model '{twin_type}'"}

        records = []
        errors = []
        warnings = []

        fn_lower = filename.lower()
        if fn_lower.endswith('.json'):
            try:
                parsed = json.loads(file_bytes.decode('utf-8'))
                if isinstance(parsed, dict) and 'records' in parsed and isinstance(parsed['records'], list):
                    records = parsed['records']
                elif isinstance(parsed, list):
                    records = parsed
                else:
                    return {'success': False, 'error': "Invalid JSON structure. Root element must be an array of records or an object containing a 'records' list."}
            except Exception as e:
                return {'success': False, 'error': f"Malformed JSON file: {str(e)}"}

        elif fn_lower.endswith(('.xlsx', '.xlsm')):
            try:
                wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
                ws = wb["Data Records"] if "Data Records" in wb.sheetnames else wb.active
                
                rows = list(ws.iter_rows(values_only=True))
                if len(rows) < 2:
                    return {'success': False, 'error': "Worksheet is empty. Expected header row and data rows."}

                # Determine if row 1 or row 2 holds the technical keys
                # Our templates store human labels in row 1, technical keys in row 2
                field_keys = {f['key']: f for f in schema['fields']}
                header_row_idx = 0
                key_map = {}

                # Check if row 2 has matching keys
                if len(rows) >= 2 and any(str(cell).strip() in field_keys for cell in rows[1] if cell):
                    header_row_idx = 1
                    for col_idx, cell_val in enumerate(rows[1]):
                        k = str(cell_val).strip() if cell_val else ''
                        if k in field_keys:
                            key_map[col_idx] = k
                else:
                    # Match by label or key in row 1
                    label_map = {re.sub(r'[^a-zA-Z0-9]', '', f['label'].lower()): f['key'] for f in schema['fields']}
                    for col_idx, cell_val in enumerate(rows[0]):
                        raw = str(cell_val).strip() if cell_val else ''
                        clean = re.sub(r'[^a-zA-Z0-9]', '', raw.lower())
                        if raw in field_keys:
                            key_map[col_idx] = raw
                        elif clean in label_map:
                            key_map[col_idx] = label_map[clean]

                if not key_map:
                    return {'success': False, 'error': "Could not identify recognized schema column headers in Excel workbook."}

                # Data rows start after header row (+1 if row 3 was example row)
                start_row = header_row_idx + 1
                if start_row < len(rows) and str(rows[start_row][0] or '').lower().startswith('e.g.'):
                    start_row += 1

                for row_idx in range(start_row, len(rows)):
                    row_vals = rows[row_idx]
                    if not any(row_vals):
                        continue
                    rec = {}
                    for col_idx, k in key_map.items():
                        if col_idx < len(row_vals):
                            val = row_vals[col_idx]
                            if isinstance(val, (datetime, date)):
                                val = val.strftime('%Y-%m-%d')
                            rec[k] = val
                    rec['_excel_row'] = row_idx + 1
                    records.append(rec)

            except Exception as e:
                return {'success': False, 'error': f"Failed to parse Excel file: {str(e)}"}

        else:
            return {'success': False, 'error': "Unsupported file extension. Please upload an Excel workbook (.xlsx) or JSON file (.json)."}

        if not records:
            return {'success': False, 'error': "No data rows detected in uploaded file."}

        # -------------------------------------------------------------
        # Row-level deep validation
        # -------------------------------------------------------------
        fields_cfg = {f['key']: f for f in schema['fields']}
        valid_records = []
        invalid_records = []
        seen_identifiers = set()

        # Build company department lookup for FK validation
        valid_depts = {d.name.lower(): d.id for d in Department.query.filter_by(company_id=company_id, is_active=True).all()}

        for idx, rec in enumerate(records, start=1):
            row_num = rec.get('_excel_row', idx)
            row_errors = []
            clean_rec = {}

            # Check required & type casting
            for key, cfg in fields_cfg.items():
                val = rec.get(key)
                req = cfg['required']
                val_type = cfg['type']

                if val is None or str(val).strip() == '':
                    if req:
                        row_errors.append({
                            'row': row_num,
                            'field': key,
                            'message': f"Required field '{cfg['label']}' is missing or empty.",
                            'value': None
                        })
                    clean_rec[key] = None
                    continue

                # Type specific validation
                if val_type == 'float':
                    try:
                        clean_val = float(str(val).replace('$', '').replace('€', '').replace('₹', '').replace(',', '').strip())
                        clean_rec[key] = clean_val
                    except (ValueError, TypeError):
                        row_errors.append({
                            'row': row_num,
                            'field': key,
                            'message': f"Field '{cfg['label']}' must be a valid number (received: {val}).",
                            'value': str(val)
                        })
                        clean_rec[key] = None

                elif val_type == 'integer':
                    try:
                        clean_val = int(float(str(val).replace(',', '').strip()))
                        clean_rec[key] = clean_val
                    except (ValueError, TypeError):
                        row_errors.append({
                            'row': row_num,
                            'field': key,
                            'message': f"Field '{cfg['label']}' must be a whole integer (received: {val}).",
                            'value': str(val)
                        })
                        clean_rec[key] = None

                elif val_type == 'date':
                    dt_str = str(val).strip()[:10]
                    if not re.match(r'^\d{4}-\d{2}-\d{2}$', dt_str):
                        row_errors.append({
                            'row': row_num,
                            'field': key,
                            'message': f"Field '{cfg['label']}' must be in YYYY-MM-DD date format (received: {val}).",
                            'value': str(val)
                        })
                        clean_rec[key] = None
                    else:
                        clean_rec[key] = dt_str

                elif val_type == 'email':
                    e_str = str(val).strip()
                    if '@' not in e_str or '.' not in e_str:
                        row_errors.append({
                            'row': row_num,
                            'field': key,
                            'message': f"Invalid email format in '{cfg['label']}' (received: {val}).",
                            'value': str(val)
                        })
                    clean_rec[key] = e_str

                elif val_type == 'boolean':
                    b_str = str(val).strip().lower()
                    clean_rec[key] = b_str in ('true', 'yes', 'y', '1')

                else:
                    clean_rec[key] = str(val).strip()

            # Duplicate ID check within file
            id_key = 'sku' if twin_type == 'inventory' else ('customer_code' if twin_type == 'customers' else ('employee_code' if twin_type == 'employees' else None))
            if id_key and clean_rec.get(id_key):
                ident = clean_rec[id_key].lower()
                if ident in seen_identifiers:
                    warnings.append(f"Row {row_num}: Duplicate identifier '{clean_rec[id_key]}' detected in import file.")
                seen_identifiers.add(ident)

            # Department name reference check
            if 'department_name' in clean_rec and clean_rec['department_name']:
                d_name = str(clean_rec['department_name']).strip().lower()
                if valid_depts and d_name not in valid_depts:
                    warnings.append(f"Row {row_num}: Department '{clean_rec['department_name']}' is not currently configured for this organization.")

            clean_rec['_row'] = row_num
            clean_rec['_is_valid'] = len(row_errors) == 0

            if row_errors:
                errors.extend(row_errors)
                invalid_records.append(clean_rec)
            else:
                valid_records.append(clean_rec)

        return {
            'success': True,
            'twin_type': twin_type,
            'model_name': schema['model_name'],
            'total_records': len(records),
            'valid_count': len(valid_records),
            'invalid_count': len(invalid_records),
            'duplicate_count': len(warnings),
            'errors': errors,
            'warnings': warnings,
            'preview_records': records[:10],
            'validated_data': valid_records
        }

    # =========================================================================
    # SAFE TRANSACTIONAL COMMIT IMPORT
    # =========================================================================

    @classmethod
    def execute_import(
        cls,
        twin_type: str,
        valid_records: List[Dict[str, Any]],
        import_mode: str,  # 'insert', 'update', 'upsert'
        company_id: int,
        user_id: Optional[int] = None,
        custom_twin_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """
        Execute atomic database import of validated records with rollback protection.
        Triggers metrics recalculation and records audit history upon completion.
        """
        if not valid_records:
            return {'success': False, 'error': 'No valid records provided for import.'}

        inserted_count = 0
        updated_count = 0
        skipped_count = 0

        # Department lookup
        dept_lookup = {d.name.lower(): d.id for d in Department.query.filter_by(company_id=company_id).all()}

        try:
            if twin_type == 'revenue':
                for r in valid_records:
                    ref_num = r.get('reference_number')
                    existing = FinancialRecord.query.filter_by(
                        company_id=company_id,
                        reference_number=ref_num,
                        transaction_type='revenue'
                    ).first() if ref_num else None

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else FinancialRecord(company_id=company_id, transaction_type='revenue')
                    target.transaction_date = datetime.strptime(r['transaction_date'], '%Y-%m-%d').date()
                    target.category = r.get('category') or 'General Revenue'
                    target.subcategory = r.get('subcategory')
                    target.amount = float(r['amount'])
                    target.reference_number = ref_num
                    target.description = r.get('description')
                    target.is_recurring = bool(r.get('is_recurring'))
                    target.recurring_frequency = r.get('recurring_frequency')

                    d_name = (r.get('department_name') or '').lower()
                    if d_name in dept_lookup:
                        target.department_id = dept_lookup[d_name]

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'expenses':
                for r in valid_records:
                    ref_num = r.get('reference_number')
                    existing = FinancialRecord.query.filter_by(
                        company_id=company_id,
                        reference_number=ref_num,
                        transaction_type='expense'
                    ).first() if ref_num else None

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else FinancialRecord(company_id=company_id, transaction_type='expense')
                    target.transaction_date = datetime.strptime(r['transaction_date'], '%Y-%m-%d').date()
                    target.category = r.get('category') or 'General Expense'
                    target.subcategory = r.get('subcategory')
                    target.amount = float(r['amount'])
                    target.reference_number = ref_num
                    target.description = r.get('description')
                    target.is_recurring = bool(r.get('is_recurring'))
                    target.recurring_frequency = r.get('recurring_frequency')

                    d_name = (r.get('department_name') or '').lower()
                    if d_name in dept_lookup:
                        target.department_id = dept_lookup[d_name]

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'customers':
                for r in valid_records:
                    code = r.get('customer_code')
                    email = r.get('email')
                    existing = None
                    if code:
                        existing = Customer.query.filter_by(company_id=company_id, customer_code=code).first()
                    if not existing and email:
                        existing = Customer.query.filter_by(company_id=company_id, email=email).first()

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else Customer(company_id=company_id)
                    target.customer_code = code or f"CUST-{int(datetime.utcnow().timestamp()) % 100000:05d}"
                    target.first_name = r['first_name']
                    target.last_name = r['last_name']
                    target.company_name = r.get('company_name')
                    target.email = email
                    target.phone = r.get('phone')
                    target.city = r.get('city')
                    target.country = r.get('country')
                    target.segment = r.get('segment') or 'Enterprise'
                    target.lifetime_value = float(r.get('lifetime_value') or 0.0)
                    target.acquisition_cost = float(r.get('acquisition_cost') or 0.0)
                    target.status = r.get('status') or 'active'

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'employees':
                for r in valid_records:
                    code = r.get('employee_code')
                    email = r.get('email')
                    existing = None
                    if code:
                        existing = Employee.query.filter_by(company_id=company_id, employee_code=code).first()
                    if not existing and email:
                        existing = Employee.query.filter_by(company_id=company_id, email=email).first()

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else Employee(company_id=company_id)
                    target.employee_code = code or f"EMP-{int(datetime.utcnow().timestamp()) % 100000:05d}"
                    target.first_name = r['first_name']
                    target.last_name = r['last_name']
                    target.email = email
                    target.phone = r.get('phone')
                    target.job_title = r['job_title']
                    target.employment_type = r.get('employment_type') or 'full_time'
                    target.salary = float(r['salary'])
                    target.benefits_cost = float(r.get('benefits_cost') or 0.0)
                    target.status = r.get('status') or 'active'
                    if r.get('hire_date'):
                        target.hire_date = datetime.strptime(r['hire_date'], '%Y-%m-%d').date()

                    d_name = (r.get('department_name') or '').lower()
                    if d_name in dept_lookup:
                        target.department_id = dept_lookup[d_name]

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'suppliers':
                for r in valid_records:
                    code = r.get('supplier_code')
                    name = r.get('name')
                    existing = None
                    if code:
                        existing = Supplier.query.filter_by(company_id=company_id, supplier_code=code).first()
                    if not existing and name:
                        existing = Supplier.query.filter_by(company_id=company_id, name=name).first()

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else Supplier(company_id=company_id)
                    target.supplier_code = code or f"SUP-{int(datetime.utcnow().timestamp()) % 100000:05d}"
                    target.name = name
                    target.contact_person = r.get('contact_person')
                    target.email = r.get('email')
                    target.phone = r.get('phone')
                    target.city = r.get('city')
                    target.country = r.get('country')
                    target.category = r.get('category')
                    target.payment_terms = r.get('payment_terms') or 'Net 30'
                    target.rating = float(r.get('rating') or 5.0)
                    target.status = r.get('status') or 'active'

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'inventory':
                for r in valid_records:
                    sku = r.get('sku')
                    existing = Inventory.query.filter_by(company_id=company_id, sku=sku).first() if sku else None

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else Inventory(company_id=company_id)
                    target.sku = sku
                    target.product_name = r['product_name']
                    target.category = r.get('category')
                    target.quantity_on_hand = int(r['quantity_on_hand'])
                    target.unit_cost = float(r['unit_cost'])
                    target.selling_price = float(r['selling_price'])
                    target.reorder_point = int(r.get('reorder_point') or 10)
                    target.reorder_quantity = int(r.get('reorder_quantity') or 50)
                    target.location = r.get('location')
                    target.status = r.get('status') or 'in_stock'

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'departments':
                for r in valid_records:
                    name = r.get('name')
                    existing = Department.query.filter_by(company_id=company_id, name=name).first() if name else None

                    if existing and import_mode == 'insert':
                        skipped_count += 1
                        continue

                    target = existing if (existing and import_mode in ('update', 'upsert')) else Department(company_id=company_id)
                    target.name = name
                    target.code = r.get('code') or name[:3].upper()
                    target.description = r.get('description')
                    target.head_name = r.get('head_name')
                    target.head_email = r.get('head_email')
                    target.head_designation = r.get('head_designation')
                    target.budget = float(r.get('budget') or 0.0)
                    target.budget_period = r.get('budget_period') or 'Annual'
                    target.responsibilities = r.get('responsibilities')
                    target.team_size = int(r.get('team_size') or 0)
                    target.contact_email = r.get('contact_email')

                    if existing:
                        updated_count += 1
                    else:
                        db.session.add(target)
                        inserted_count += 1

            elif twin_type == 'custom_twin' and custom_twin_id:
                twin = CustomTwin.query.filter_by(id=custom_twin_id, company_id=company_id).first()
                if not twin:
                    return {'success': False, 'error': 'Custom digital twin not found.'}
                for r in valid_records:
                    # Clean internal metadata keys
                    clean_data = {k: v for k, v in r.items() if not k.startswith('_')}
                    rec = CustomTwinRecord(
                        twin_id=twin.id,
                        company_id=company_id,
                        created_by=user_id,
                        data_json=json.dumps(clean_data)
                    )
                    db.session.add(rec)
                    inserted_count += 1

            # Commit all operations
            db.session.commit()

            # Record audit log
            audit = AuditLog(
                company_id=company_id,
                user_id=user_id,
                action='DIGITAL_TWIN_IMPORT',
                resource_type=twin_type,
                details=f"Imported {inserted_count} new, updated {updated_count}, skipped {skipped_count} records for twin '{twin_type}' (mode: {import_mode})."
            )
            db.session.add(audit)
            db.session.commit()

            # Recalculate derived enterprise metrics immediately
            try:
                TwinService.recalculate_company_metrics(company_id)
            except Exception as e:
                print(f"[RECALC WARNING] {e}")

            return {
                'success': True,
                'twin_type': twin_type,
                'inserted': inserted_count,
                'updated': updated_count,
                'skipped': skipped_count,
                'total_processed': inserted_count + updated_count + skipped_count
            }

        except Exception as e:
            db.session.rollback()
            return {'success': False, 'error': f"Database commit failure during import: {str(e)}"}

    # =========================================================================
    # AUTHORITATIVE DATASET EXPORT (EXCEL & JSON)
    # =========================================================================

    @classmethod
    def export_dataset_excel(cls, twin_type: str, company_id: int, custom_twin_id: Optional[int] = None) -> Tuple[io.BytesIO, str]:
        """Export real company records to a beautifully styled Excel workbook."""
        schema = cls.get_schema(twin_type, custom_twin_id=custom_twin_id, company_id=company_id)
        if not schema:
            raise ValueError(f"Unknown twin model: {twin_type}")

        company = Company.query.get(company_id)
        comp_name = company.company_name if company else "AEVORYN Enterprise"

        records_data = cls._fetch_raw_records(twin_type, company_id, custom_twin_id)

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = schema['display_name'][:30]
        ws.views.sheetView[0].showGridLines = True

        # Header Title
        ws.merge_cells("A1:G1")
        ws["A1"] = f"{comp_name} — {schema['display_name']}"
        ws["A1"].font = TITLE_FONT
        ws["A2"] = f"Exported: {datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')} | Records: {len(records_data)} | System: AEVORYN Digital Twin"
        ws["A2"].font = SUBTITLE_FONT

        # Table Headers
        fields = schema['fields']
        header_row = 4
        for col_idx, fld in enumerate(fields, start=1):
            c = ws.cell(row=header_row, column=col_idx, value=fld['label'])
            c.fill = NAVY_HEADER_FILL
            c.font = WHITE_FONT
            c.alignment = Alignment(horizontal="center", vertical="center")
            c.border = CELL_BORDER

        # Data Rows
        for r_idx, rec in enumerate(records_data, start=5):
            for c_idx, fld in enumerate(fields, start=1):
                val = rec.get(fld['key'])
                cell = ws.cell(row=r_idx, column=c_idx, value=val)
                cell.font = REGULAR_FONT
                cell.border = CELL_BORDER
                if r_idx % 2 == 0:
                    cell.fill = LIGHT_ROW_FILL

        # Auto width
        for c_idx, fld in enumerate(fields, start=1):
            col_letter = get_column_letter(c_idx)
            max_len = max(len(fld['label']), *(len(str(r.get(fld['key'], '') or '')) for r in records_data[:50]), 12)
            ws.column_dimensions[col_letter].width = min(max_len + 4, 45)

        buf = io.BytesIO()
        wb.save(buf)
        buf.seek(0)
        filename = f"{twin_type}_export_{datetime.utcnow().strftime('%Y%m%d_%H%M')}.xlsx"
        return buf, filename

    @classmethod
    def export_dataset_json(cls, twin_type: str, company_id: int, custom_twin_id: Optional[int] = None) -> Dict[str, Any]:
        """Export real company records to a valid, schema-compliant JSON file."""
        schema = cls.get_schema(twin_type, custom_twin_id=custom_twin_id, company_id=company_id)
        if not schema:
            raise ValueError(f"Unknown twin model: {twin_type}")

        company = Company.query.get(company_id)
        records_data = cls._fetch_raw_records(twin_type, company_id, custom_twin_id)

        return {
            'organization': company.company_name if company else 'AEVORYN Organization',
            'company_id': company_id,
            'twin_type': twin_type,
            'model_name': schema['model_name'],
            'exported_at': datetime.utcnow().isoformat() + 'Z',
            'record_count': len(records_data),
            'records': records_data
        }

    @classmethod
    def _fetch_raw_records(cls, twin_type: str, company_id: int, custom_twin_id: Optional[int] = None) -> List[Dict[str, Any]]:
        """Retrieve authoritative live database rows as serializable dictionaries."""
        records = []
        if twin_type == 'revenue':
            rows = FinancialRecord.query.filter_by(company_id=company_id, transaction_type='revenue').order_by(FinancialRecord.transaction_date.desc()).all()
            for r in rows:
                dept_name = r.department.name if r.department else ''
                records.append({
                    'transaction_date': r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '',
                    'category': r.category or '',
                    'subcategory': r.subcategory or '',
                    'amount': float(r.amount or 0.0),
                    'reference_number': r.reference_number or '',
                    'department_name': dept_name,
                    'description': r.description or '',
                    'is_recurring': 'Yes' if r.is_recurring else 'No',
                    'recurring_frequency': r.recurring_frequency or ''
                })

        elif twin_type == 'expenses':
            rows = FinancialRecord.query.filter_by(company_id=company_id, transaction_type='expense').order_by(FinancialRecord.transaction_date.desc()).all()
            for r in rows:
                dept_name = r.department.name if r.department else ''
                records.append({
                    'transaction_date': r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '',
                    'category': r.category or '',
                    'subcategory': r.subcategory or '',
                    'amount': float(r.amount or 0.0),
                    'reference_number': r.reference_number or '',
                    'department_name': dept_name,
                    'description': r.description or '',
                    'is_recurring': 'Yes' if r.is_recurring else 'No',
                    'recurring_frequency': r.recurring_frequency or ''
                })

        elif twin_type == 'customers':
            rows = Customer.query.filter_by(company_id=company_id).order_by(Customer.id.asc()).all()
            for r in rows:
                records.append({
                    'customer_code': r.customer_code or '',
                    'first_name': r.first_name or '',
                    'last_name': r.last_name or '',
                    'company_name': r.company_name or '',
                    'email': r.email or '',
                    'phone': r.phone or '',
                    'city': r.city or '',
                    'country': r.country or '',
                    'segment': r.segment or 'Enterprise',
                    'lifetime_value': float(r.lifetime_value or 0.0),
                    'acquisition_cost': float(r.acquisition_cost or 0.0),
                    'status': r.status or 'active'
                })

        elif twin_type == 'employees':
            rows = Employee.query.filter_by(company_id=company_id).order_by(Employee.id.asc()).all()
            for r in rows:
                dept_name = r.department.name if r.department else ''
                records.append({
                    'employee_code': r.employee_code or '',
                    'first_name': r.first_name or '',
                    'last_name': r.last_name or '',
                    'email': r.email or '',
                    'phone': r.phone or '',
                    'department_name': dept_name,
                    'job_title': r.job_title or '',
                    'employment_type': r.employment_type or 'full_time',
                    'salary': float(r.salary or 0.0),
                    'benefits_cost': float(r.benefits_cost or 0.0),
                    'hire_date': r.hire_date.strftime('%Y-%m-%d') if r.hire_date else '',
                    'status': r.status or 'active'
                })

        elif twin_type == 'suppliers':
            rows = Supplier.query.filter_by(company_id=company_id).order_by(Supplier.id.asc()).all()
            for r in rows:
                records.append({
                    'supplier_code': r.supplier_code or '',
                    'name': r.name or '',
                    'contact_person': r.contact_person or '',
                    'email': r.email or '',
                    'phone': r.phone or '',
                    'city': r.city or '',
                    'country': r.country or '',
                    'category': r.category or '',
                    'payment_terms': r.payment_terms or 'Net 30',
                    'rating': float(r.rating or 5.0),
                    'status': r.status or 'active'
                })

        elif twin_type == 'inventory':
            rows = Inventory.query.filter_by(company_id=company_id).order_by(Inventory.id.asc()).all()
            for r in rows:
                records.append({
                    'sku': r.sku or '',
                    'product_name': r.product_name or '',
                    'category': r.category or '',
                    'quantity_on_hand': int(r.quantity_on_hand or 0),
                    'unit_cost': float(r.unit_cost or 0.0),
                    'selling_price': float(r.selling_price or 0.0),
                    'reorder_point': int(r.reorder_point or 0),
                    'reorder_quantity': int(r.reorder_quantity or 0),
                    'location': r.location or '',
                    'status': r.status or 'in_stock'
                })

        elif twin_type == 'departments':
            rows = Department.query.filter_by(company_id=company_id, is_active=True).order_by(Department.id.asc()).all()
            for r in rows:
                records.append({
                    'name': r.name,
                    'code': r.code or '',
                    'description': r.description or '',
                    'head_name': r.head_name or '',
                    'head_email': getattr(r, 'head_email', '') or '',
                    'head_designation': getattr(r, 'head_designation', '') or '',
                    'budget': float(r.budget or 0.0),
                    'budget_period': getattr(r, 'budget_period', 'Annual') or 'Annual',
                    'responsibilities': r.responsibilities or '',
                    'team_size': int(getattr(r, 'team_size', 0) or r.employee_count or 0),
                    'contact_email': getattr(r, 'contact_email', '') or ''
                })

        elif twin_type == 'custom_twin' and custom_twin_id:
            rows = CustomTwinRecord.query.filter_by(twin_id=custom_twin_id, company_id=company_id, is_active=True).all()
            for r in rows:
                try:
                    data = json.loads(r.data_json) if r.data_json else {}
                    records.append(data)
                except Exception:
                    pass

        return records
