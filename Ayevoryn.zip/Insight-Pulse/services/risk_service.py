"""
AEVORYN / INSIGHT-PULSE
ENTERPRISE RISK SERVICE (STAGE 17)
Connects risk assessments directly to live operational states, canonical business state,
and asynchronous domain events. Provides operational threshold scans, auditable evidence,
and automatic risk escalation/resolution.
"""

from datetime import datetime
import json
import logging
from sqlalchemy import func

from database.db import db
from database.models.risk import Risk, RiskFactor, RiskSource, RiskStatus
from database.models.company import Company
from database.models.financial import FinancialRecord
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.inventory import Inventory
from database.models.supplier import Supplier
from config.constants import RISK_CATEGORIES
from services.risk.operational_risk_engine import OperationalRiskEngine, ThresholdEvaluation
from services.events import EventBus, EventTypes, DomainEvent

logger = logging.getLogger(__name__)


class RiskService:
    @staticmethod
    def assess_all_risks(company_id, run_operational_scan: bool = True):
        """
        Loads all risks for a company. If no risks exist, seeds baseline defaults.
        Optionally triggers an operational threshold scan against live metrics.
        """
        risks = Risk.query.filter_by(company_id=company_id).all()
        if not risks:
            RiskService._generate_default_risks(company_id)
            risks = Risk.query.filter_by(company_id=company_id).all()
        
        if run_operational_scan:
            RiskService.evaluate_operational_risks(company_id, publish_events=False)
            risks = Risk.query.filter_by(company_id=company_id).all()
        else:
            for risk in risks:
                risk.calculate_score()
            db.session.commit()
        
        return risks

    @staticmethod
    def evaluate_operational_risks(company_id: int, actor_user_id: int = None, publish_events: bool = True):
        """
        Evaluates live operational thresholds (runway, margins, stockouts, concentration, overruns).
        Creates, escalates, or auto-resolves automated risks with auditable evidence.
        """
        company = Company.query.get(company_id)
        if not company:
            return {"error": "Company not found", "breached_count": 0}

        evaluations = OperationalRiskEngine.evaluate_all(company_id)
        breached_count = 0
        resolved_count = 0
        escalated_count = 0
        new_count = 0

        for ev in evaluations:
            existing_risk = Risk.query.filter_by(
                company_id=company_id,
                trigger_metric=ev.trigger_metric
            ).first()

            if ev.is_breached:
                breached_count += 1
                if existing_risk:
                    # Update metrics & evidence
                    was_resolved = existing_risk.status == RiskStatus.RESOLVED
                    existing_risk.name = ev.name
                    existing_risk.category = ev.category
                    existing_risk.description = ev.description
                    existing_risk.probability = ev.probability
                    existing_risk.impact = ev.impact
                    existing_risk.threshold_value = ev.threshold_value
                    existing_risk.observed_value = ev.observed_value
                    existing_risk.set_evidence(ev.evidence)
                    existing_risk.last_assessed_at = datetime.utcnow()
                    existing_risk.calculate_score()

                    if was_resolved:
                        existing_risk.status = RiskStatus.ACTIVE
                        existing_risk.resolved_at = None
                        escalated_count += 1
                        if publish_events:
                            EventBus.publish(DomainEvent.create(
                                event_type=EventTypes.RISK_ESCALATED,
                                company_id=company_id,
                                aggregate_type="risk",
                                aggregate_id=str(existing_risk.id),
                                actor_id=actor_user_id,
                                payload={
                                    "risk_id": existing_risk.id,
                                    "name": existing_risk.name,
                                    "metric": ev.trigger_metric,
                                    "observed": ev.observed_value,
                                    "threshold": ev.threshold_value,
                                    "score": existing_risk.risk_score,
                                    "level": existing_risk.risk_level
                                }
                            ), commit=False)
                    else:
                        if publish_events:
                            EventBus.publish(DomainEvent.create(
                                event_type=EventTypes.RISK_MUTATED,
                                company_id=company_id,
                                aggregate_type="risk",
                                aggregate_id=str(existing_risk.id),
                                actor_id=actor_user_id,
                                payload={
                                    "risk_id": existing_risk.id,
                                    "name": existing_risk.name,
                                    "metric": ev.trigger_metric,
                                    "score": existing_risk.risk_score
                                }
                            ), commit=False)
                else:
                    # Create new automated risk
                    new_risk = Risk(
                        company_id=company_id,
                        name=ev.name,
                        category=ev.category,
                        description=ev.description,
                        probability=ev.probability,
                        impact=ev.impact,
                        source=RiskSource.AUTOMATED_THRESHOLD,
                        is_automated=True,
                        trigger_metric=ev.trigger_metric,
                        threshold_value=ev.threshold_value,
                        observed_value=ev.observed_value,
                        mitigation_plan=ev.suggested_mitigation,
                        status=RiskStatus.ACTIVE,
                        owner_id=actor_user_id,
                        last_assessed_at=datetime.utcnow()
                    )
                    new_risk.set_evidence(ev.evidence)
                    new_risk.calculate_score()
                    db.session.add(new_risk)
                    db.session.flush()
                    new_count += 1

                    if publish_events:
                        EventBus.publish(DomainEvent.create(
                            event_type=EventTypes.RISK_TRIGGERED,
                            company_id=company_id,
                            aggregate_type="risk",
                            aggregate_id=str(new_risk.id),
                            actor_id=actor_user_id,
                            payload={
                                "risk_id": new_risk.id,
                                "name": new_risk.name,
                                "metric": ev.trigger_metric,
                                "observed": ev.observed_value,
                                "threshold": ev.threshold_value,
                                "score": new_risk.risk_score,
                                "level": new_risk.risk_level,
                                "evidence": ev.evidence
                            }
                        ), commit=False)
            else:
                # If existing automated risk is active or mitigated, auto-resolve it!
                if existing_risk and existing_risk.status in [RiskStatus.ACTIVE, RiskStatus.MITIGATED]:
                    existing_risk.resolve(f"Operational threshold cleared: observed {ev.observed_value} within threshold {ev.threshold_value}.")
                    existing_risk.last_assessed_at = datetime.utcnow()
                    resolved_count += 1
                    if publish_events:
                        EventBus.publish(DomainEvent.create(
                            event_type=EventTypes.RISK_RESOLVED,
                            company_id=company_id,
                            aggregate_type="risk",
                            aggregate_id=str(existing_risk.id),
                            actor_id=actor_user_id,
                            payload={
                                "risk_id": existing_risk.id,
                                "name": existing_risk.name,
                                "metric": ev.trigger_metric,
                                "observed": ev.observed_value,
                                "threshold": ev.threshold_value
                            }
                        ), commit=False)

        db.session.commit()

        if publish_events:
            EventBus.publish(DomainEvent.create(
                event_type=EventTypes.RISK_ASSESSMENT_COMPLETED,
                company_id=company_id,
                aggregate_type="risk_assessment",
                aggregate_id=f"scan-{company_id}-{int(datetime.utcnow().timestamp())}",
                actor_id=actor_user_id,
                payload={
                    "breached_count": breached_count,
                    "resolved_count": resolved_count,
                    "new_count": new_count,
                    "escalated_count": escalated_count,
                    "total_evaluated": len(evaluations)
                }
            ), commit=True)

        return {
            "success": True,
            "company_id": company_id,
            "total_rules_evaluated": len(evaluations),
            "breached_count": breached_count,
            "resolved_count": resolved_count,
            "new_count": new_count,
            "escalated_count": escalated_count,
            "evaluations": [ev.to_dict() for ev in evaluations]
        }

    @staticmethod
    def create_risk(company_id, name, category, description, probability, impact, mitigation_plan=None, owner_id=None):
        """Create a manual risk with validation and event dispatch."""
        risk = Risk(
            company_id=company_id,
            name=name,
            category=category,
            description=description,
            probability=float(probability),
            impact=float(impact),
            source=RiskSource.MANUAL,
            is_automated=False,
            mitigation_plan=mitigation_plan,
            owner_id=owner_id,
            status=RiskStatus.ACTIVE
        )
        risk.calculate_score()
        db.session.add(risk)
        db.session.commit()

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.RISK_TRIGGERED,
            company_id=company_id,
            aggregate_type="risk",
            aggregate_id=str(risk.id),
            actor_id=owner_id,
            payload={
                "risk_id": risk.id,
                "name": risk.name,
                "category": risk.category,
                "score": risk.risk_score,
                "source": "manual"
            }
        ), commit=True)
        return risk

    @staticmethod
    def update_risk(risk_id, company_id, **kwargs):
        """Update risk status, mitigation plan, or parameters with tenant IDOR check."""
        risk = Risk.query.filter_by(id=risk_id, company_id=company_id).first()
        if not risk:
            return None
        
        if 'name' in kwargs and kwargs['name']:
            risk.name = kwargs['name']
        if 'category' in kwargs and kwargs['category']:
            risk.category = kwargs['category']
        if 'description' in kwargs:
            risk.description = kwargs['description']
        if 'probability' in kwargs and kwargs['probability'] is not None:
            risk.probability = float(kwargs['probability'])
        if 'impact' in kwargs and kwargs['impact'] is not None:
            risk.impact = float(kwargs['impact'])
        if 'mitigation_plan' in kwargs:
            risk.mitigation_plan = kwargs['mitigation_plan']
        if 'status' in kwargs and kwargs['status'] in RiskStatus.ALL:
            old_status = risk.status
            risk.status = kwargs['status']
            if risk.status == RiskStatus.RESOLVED:
                risk.resolved_at = datetime.utcnow()
            elif risk.status == RiskStatus.ACTIVE:
                risk.resolved_at = None
        if 'owner_id' in kwargs:
            risk.owner_id = kwargs['owner_id']

        risk.calculate_score()
        db.session.commit()

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.RISK_MUTATED,
            company_id=company_id,
            aggregate_type="risk",
            aggregate_id=str(risk.id),
            payload={"risk_id": risk.id, "status": risk.status, "score": risk.risk_score}
        ), commit=True)
        return risk

    @staticmethod
    def delete_risk(risk_id, company_id):
        """Delete a risk with tenant IDOR check."""
        risk = Risk.query.filter_by(id=risk_id, company_id=company_id).first()
        if not risk:
            return False
        db.session.delete(risk)
        db.session.commit()
        return True
    
    @staticmethod
    def _generate_default_risks(company_id):
        company = Company.query.get(company_id)
        if not company:
            return
        
        # Pull real financials
        revenue_total = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'revenue'
        ).scalar()
        total_revenue = float(revenue_total or 0)
        
        total_expense = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense'
        ).scalar() or 0
        expense_records = db.session.query(func.count(FinancialRecord.id)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense'
        ).scalar() or 0

        profit = float(total_revenue) - float(total_expense) if expense_records else 0
        margin = profit / float(total_revenue) if total_revenue and expense_records else 0
        
        # Pull operational counts
        employee_records = db.session.query(func.count(Employee.id)).filter(
            Employee.company_id == company_id,
            Employee.status == 'active'
        ).scalar() or 0
        employee_count = employee_records or int(company.employee_count or 0)
        
        customer_records = db.session.query(func.count(Customer.id)).filter(
            Customer.company_id == company_id,
            Customer.status == 'active'
        ).scalar() or 0
        customer_count = customer_records or int(company.customer_count or 0)
        
        supplier_count = db.session.query(func.count(Supplier.id)).filter(
            Supplier.company_id == company_id
        ).scalar() or 0
        
        inventory_items = Inventory.query.filter_by(company_id=company_id, is_active=True).count()
        total_inventory_value = db.session.query(func.sum(Inventory.quantity_on_hand * Inventory.unit_cost)).filter(
            Inventory.company_id == company_id,
            Inventory.is_active == True
        ).scalar() or 0
        
        # Derive baseline probabilities & impacts
        liquidity_prob = 0.25 if profit > 0 else 0.75
        liquidity_impact = 0.5 if margin > 0.15 else 0.85 if margin > 0 else 0.95
        
        credit_prob = 0.35 if customer_count == 0 else min(0.2 + (1000 / customer_count) * 0.01, 0.6)
        credit_impact = 0.45
        
        process_prob = 0.4 if employee_count == 0 else min(0.2 + (50 / employee_count) * 0.1, 0.5)
        process_impact = 0.5 if employee_count > 20 else 0.65
        
        system_prob = 0.25
        system_impact = 0.45
        
        demand_prob = 0.4 if customer_count == 0 else min(0.3 + (500 / customer_count) * 0.05, 0.7)
        demand_impact = 0.55
        
        comp_prob = 0.4 if total_revenue == 0 else min(0.35 + (1000 / total_revenue) * 0.05, 0.7)
        comp_impact = 0.55
        
        supplier_prob = 0.45 if supplier_count == 0 else min(0.3 + (10 / supplier_count) * 0.05, 0.7)
        supplier_impact = 0.6 if supplier_count < 3 else 0.45
        
        logistics_prob = 0.3
        logistics_impact = 0.45
        
        inventory_ratio = float(total_inventory_value) / float(total_revenue) if total_revenue else 0
        overstock_prob = min(0.25 + inventory_ratio * 2, 0.7)
        overstock_impact = 0.4
        
        stockout_prob = 0.45 if inventory_items == 0 else min(0.3 + (1 / inventory_items) * 0.1, 0.6)
        stockout_impact = 0.55
        
        growth_prob = 0.3 if margin > 0.15 else 0.5
        growth_impact = 0.5
        
        talent_prob = 0.45 if employee_count == 0 else min(0.3 + (100 / employee_count) * 0.05, 0.6)
        talent_impact = 0.55
        
        price_prob = 0.35
        price_impact = 0.5
        
        innov_prob = 0.4
        innov_impact = 0.55
        
        recession_prob = 0.3
        recession_impact = 0.75 if margin < 0.1 else 0.6
        
        inflation_prob = 0.45
        inflation_impact = 0.5 if margin > 0.2 else 0.65
        
        wc_prob = 0.35 if profit > 0 else 0.7
        wc_impact = 0.55
        
        bad_debt_prob = 0.3
        bad_debt_impact = 0.45
        
        risk_configs = [
            ('financial', 'Liquidity Risk', 
             'Ability to meet short-term obligations. Tight margins or negative cash flow increase this risk significantly.', 
             liquidity_prob, liquidity_impact),
            ('financial', 'Credit Risk', 
             'Exposure to customer payment defaults. Higher with fewer customers or weak credit controls.', 
             credit_prob, credit_impact),
            ('operational', 'Process Failure Risk', 
             'Breakdown of core business processes. Smaller teams have higher single-point-of-failure exposure.', 
             process_prob, process_impact),
            ('operational', 'System Downtime Risk', 
             'IT infrastructure failure disrupting operations. Critical for digital-dependent businesses.', 
             system_prob, system_impact),
            ('market', 'Demand Fluctuation', 
             'Revenue volatility due to changing customer demand. Higher with concentrated customer base.', 
             demand_prob, demand_impact),
            ('market', 'Competition Risk', 
             'Market share erosion from aggressive competitors. Intensifies in low-margin environments.', 
             comp_prob, comp_impact),
            ('supply_chain', 'Supplier Failure', 
             'Dependency on limited suppliers causing production stoppages. Critical with <3 active suppliers.', 
             supplier_prob, supplier_impact),
            ('supply_chain', 'Logistics Disruption', 
             'Transportation delays or freight cost spikes affecting delivery timelines.', 
             logistics_prob, logistics_impact),
            ('inventory', 'Overstock Risk', 
             'Excess inventory tying up working capital and increasing carrying costs.', 
             overstock_prob, overstock_impact),
            ('inventory', 'Stockout Risk', 
             'Inventory shortages leading to lost sales and customer dissatisfaction.', 
             stockout_prob, stockout_impact),
            ('growth', 'Overexpansion Risk', 
             'Growing operations faster than cash flow or management capacity can support.', 
             growth_prob, growth_impact),
            ('growth', 'Talent Shortage', 
             'Inability to hire or retain skilled employees needed for scaling.', 
             talent_prob, talent_impact),
            ('competition', 'Price War Risk', 
             'Competitors forcing down prices, compressing already thin margins.', 
             price_prob, price_impact),
            ('competition', 'Innovation Gap', 
             'Falling behind competitor product development or technology adoption.', 
             innov_prob, innov_impact),
            ('economic', 'Recession Impact', 
             'Macroeconomic downturn reducing customer spending and contract values.', 
             recession_prob, recession_impact),
            ('economic', 'Inflation Risk', 
             'Rising input costs that cannot be fully passed to customers, squeezing margins.', 
             inflation_prob, inflation_impact),
            ('cashflow', 'Working Capital Crunch', 
             'Insufficient liquid assets to cover payroll, suppliers, and operating expenses.', 
             wc_prob, wc_impact),
            ('cashflow', 'Bad Debt Risk', 
             'Uncollectible accounts receivables writing off expected revenue.', 
             bad_debt_prob, bad_debt_impact),
        ]
        
        for category, name, desc, prob, impact in risk_configs:
            risk = Risk(
                company_id=company_id,
                name=name,
                category=category,
                description=desc,
                probability=round(prob, 2),
                impact=round(impact, 2),
                source=RiskSource.MANUAL,
                is_automated=False,
                status=RiskStatus.ACTIVE
            )
            risk.calculate_score()
            db.session.add(risk)
        
        db.session.commit()
    
    @staticmethod
    def get_risk_summary(company_id):
        """Calculates comprehensive enterprise risk summary metrics and category rollups."""
        risks = Risk.query.filter_by(company_id=company_id).all()
        if not risks:
            risks = RiskService.assess_all_risks(company_id)
        
        category_scores = {}
        category_explanations = {
            'financial': 'Profitability, liquidity, and credit exposure.',
            'operational': 'Internal processes, systems, and workforce stability.',
            'market': 'Customer demand volatility and competitive positioning.',
            'supply_chain': 'Supplier reliability and logistics resilience.',
            'inventory': 'Stock levels, turnover, and carrying cost efficiency.',
            'growth': 'Scaling capacity and talent pipeline sufficiency.',
            'competition': 'Price pressure and innovation velocity vs. rivals.',
            'economic': 'Macroeconomic sensitivity and inflation exposure.',
            'cashflow': 'Short-term liquidity and receivables quality.'
        }
        
        # Only active risks contribute to overall risk score
        active_risks = [r for r in risks if r.status == RiskStatus.ACTIVE]
        
        for cat in RISK_CATEGORIES:
            cat_risks = [r for r in active_risks if r.category == cat]
            all_cat_risks = [r for r in risks if r.category == cat]
            if all_cat_risks:
                scoring_risks = cat_risks if cat_risks else all_cat_risks
                avg_score = sum(r.risk_score for r in scoring_risks) / len(scoring_risks)
                max_score = max(r.risk_score for r in scoring_risks)
                critical = len([r for r in scoring_risks if r.risk_level == 'critical'])
                high = len([r for r in scoring_risks if r.risk_level == 'high'])
                
                if avg_score >= 70:
                    advice = f"Critical exposure in {cat.replace('_', ' ')}. Immediate mitigation required."
                elif avg_score >= 40:
                    advice = f"Elevated {cat.replace('_', ' ')} risk. Monitor closely and prepare contingency plans."
                elif avg_score >= 20:
                    advice = f"Moderate {cat.replace('_', ' ')} risk. Maintain current controls."
                else:
                    advice = f"Low {cat.replace('_', ' ')} risk. Continue standard monitoring."
                
                category_scores[cat] = {
                    'avg_score': round(avg_score, 1),
                    'max_score': round(max_score, 1),
                    'risk_count': len(all_cat_risks),
                    'active_count': len(cat_risks),
                    'critical_count': critical,
                    'high_count': high,
                    'explanation': category_explanations.get(cat, ''),
                    'advice': advice,
                    'risks': [r.to_dict() for r in all_cat_risks]
                }
        
        overall = sum(r.risk_score for r in active_risks) / len(active_risks) if active_risks else 0.0
        company = Company.query.get(company_id)
        from database.models.financial import FinancialRecord
        observed_financial_rows = FinancialRecord.query.filter_by(company_id=company_id).count()
        
        # Top 5 active risks by score
        top_risks = sorted([r.to_dict() for r in active_risks], key=lambda x: x['risk_score'], reverse=True)[:5]
        
        # Overall recommendation
        if overall >= 70:
            overall_advice = "CRITICAL: Your aggregate risk profile is severe. Immediate executive intervention and emergency liquidity/operational controls are required."
        elif overall >= 40:
            overall_advice = "HIGH: Significant risk exposure detected. Prioritize mitigation for top-scoring categories and review operational bottlenecks."
        elif overall >= 20:
            overall_advice = "MODERATE: Balanced risk profile with manageable exposure in key operating dimensions."
        else:
            overall_advice = "LOW: Risk environment is well-controlled. Focus on proactive monitoring and strategic growth."
        
        automated_active = [r for r in active_risks if r.is_automated]
        manual_active = [r for r in active_risks if not r.is_automated]
        
        return {
            'overall_score': round(overall, 1),
            'risk_level': 'critical' if overall >= 70 else 'high' if overall >= 40 else 'medium' if overall >= 20 else 'low',
            'total_risks': len(risks),
            'active_count': len(active_risks),
            'mitigated_count': len([r for r in risks if r.status == RiskStatus.MITIGATED]),
            'resolved_count': len([r for r in risks if r.status == RiskStatus.RESOLVED]),
            'critical_count': len([r for r in active_risks if r.risk_level == 'critical']),
            'high_count': len([r for r in active_risks if r.risk_level == 'high']),
            'medium_count': len([r for r in active_risks if r.risk_level == 'medium']),
            'low_count': len([r for r in active_risks if r.risk_level == 'low']),
            'automated_count': len(automated_active),
            'manual_count': len(manual_active),
            'category_scores': category_scores,
            'top_risks': top_risks,
            'overall_advice': overall_advice,
            'data_quality': {
                'financial_records': observed_financial_rows,
                'employees_registered': int(company.employee_count or 0) if company else 0,
                'customers_registered': int(company.customer_count or 0) if company else 0,
                'is_observed': observed_financial_rows > 0
            }
        }

    @classmethod
    def on_domain_event(cls, event: DomainEvent):
        """
        Listens to domain events across the enterprise twin and executes operational threshold evaluations
        when operational metrics change. Prevents recursion by ignoring 'risk.*' events.
        """
        if not event or not event.company_id:
            return
        if event.event_type.startswith('risk.') or event.event_type.startswith('twin.impact.'):
            return
        
        relevant_prefixes = (
            'financial.',
            'inventory.',
            'supplier.',
            'customer.',
            'department.',
            'simulation.'
        )
        if any(event.event_type.startswith(prefix) for prefix in relevant_prefixes):
            try:
                actor_id = getattr(event, 'actor_id', None) or getattr(event, 'actor_user_id', None)
                cls.evaluate_operational_risks(
                    company_id=event.company_id,
                    actor_user_id=actor_id,
                    publish_events=True
                )
            except Exception as e:
                logger.warning(f"Error evaluating operational risks on event {event.event_type}: {e}")

