import json
from database.db import db
from database.models.company import Company
from database.models.company_payments import CompanyPayments
from database.models.department import Department
from database.models.department_budget import DepartmentBudget
from database.models.department_invitation import DepartmentInvitation
from database.models.twin_dependency import TwinDependency, DependencyType
from database.models.branch import Branch
from database.models.financial import FinancialAccount
from config.constants import DEFAULT_DEPARTMENTS, COUNTRY_DATA, INDUSTRY_BUDGET_ALLOCATIONS, CURRENCY_SYMBOLS
import hashlib
import io
import base64
import qrcode
from urllib.parse import quote

class CompanyService:

    @staticmethod
    def _fmt_money(amount, currency_symbol='$'):
        """Format a monetary amount with the given currency symbol."""
        return f"{currency_symbol}{abs(amount):,.2f}"

    @staticmethod
    def create_company(data):
        annual_revenue = data.get('annual_revenue', 0.0) or 0.0
        # Initial equity proxy: 30% of annual revenue (typical for SMEs)
        # or user-provided value
        initial_equity = data.get('total_equity', annual_revenue * 0.3)
        initial_debt = data.get('total_debt', 0.0)

        owner_name = data.get('owner_name') or data.get('company_name') or 'Corporate Owner'
        ceo_name = data.get('ceo_name') or owner_name

        company = Company(
            company_name=data.get('company_name'),
            business_name=data.get('business_name') or data.get('company_name'),
            owner_name=owner_name,
            ceo_name=ceo_name,
            industry=data.get('industry'),
            business_type=data.get('business_type'),
            description=data.get('description'),
            company_size=data.get('company_size'),
            employee_count=data.get('employee_count', 0),
            annual_revenue=annual_revenue,
            total_equity=initial_equity,
            total_debt=initial_debt,
            currency=data.get('currency', 'USD'),
            country=data.get('country'),
            state=data.get('state'),
            city=data.get('city'),
            registered_address=data.get('registered_address'),
            timezone=data.get('timezone', 'UTC'),
            tax_type=data.get('tax_type'),
            tax_rate=data.get('tax_rate', 0.0),
            fiscal_year_start=data.get('fiscal_year_start', 'January 1'),
            operating_model=data.get('operating_model'),
            primary_activities=data.get('primary_activities'),
            growth_stage=data.get('growth_stage'),
            locations_count=int(data.get('locations_count', 1) or 1),
            operational_objectives=data.get('operational_objectives'),
            revenue_range=data.get('revenue_range'),
            website=data.get('website'),
            email=data.get('email'),
            mobile=data.get('mobile'),
            mobile_country_code=data.get('mobile_country_code', ''),
            whatsapp_number=data.get('whatsapp_number') or data.get('whatsapp'),
            whatsapp=data.get('whatsapp_number') or data.get('whatsapp'),
            telegram=data.get('telegram')
        )
        db.session.add(company)
        db.session.commit()

        # Dynamic user-defined departments (Part 2: NO hardcoded seeding!)
        dept_map = {}
        user_depts = data.get('departments', [])
        for d_info in user_depts:
            if not isinstance(d_info, dict):
                continue
            name = (d_info.get('name') or '').strip()
            if not name:
                continue
            code = (d_info.get('code') or name[:3]).upper().strip()
            try:
                d_budget = float(d_info.get('budget', 0.0) or 0.0)
            except (ValueError, TypeError):
                d_budget = 0.0
            b_period = d_info.get('budget_period', 'Annual')
            b_currency = d_info.get('budget_currency', company.currency or 'USD')

            dept = Department(
                company_id=company.id,
                name=name,
                code=code,
                description=d_info.get('description', ''),
                head_name=d_info.get('head_name') or 'Unassigned',
                head_email=d_info.get('head_email'),
                head_designation=d_info.get('head_designation') or 'Department Head',
                budget=d_budget,
                budget_period=b_period,
                budget_currency=b_currency,
                responsibilities=d_info.get('responsibilities', ''),
                team_size=int(d_info.get('team_size', 0) or 0),
                contact_email=d_info.get('contact_email'),
                contact_phone=d_info.get('contact_phone'),
                color=d_info.get('color', '#2563EB')
            )
            db.session.add(dept)
            db.session.flush()

            dept_map[name.lower()] = dept
            temp_id = d_info.get('temp_id') or d_info.get('id')
            if temp_id is not None:
                dept_map[str(temp_id)] = dept

            # Create DepartmentBudget record
            if d_budget > 0:
                budget_rec = DepartmentBudget(
                    company_id=company.id,
                    department_id=dept.id,
                    period=b_period.lower() if b_period else 'annual',
                    period_name=f"{b_period or 'FY'} Allocation",
                    allocated_amount=d_budget,
                    committed_amount=0.0,
                    actual_spent=0.0,
                    currency=b_currency,
                    status='active'
                )
                db.session.add(budget_rec)

            # Create DepartmentInvitation record if leader email is specified
            head_email = (d_info.get('head_email') or '').strip()
            if head_email:
                inv = DepartmentInvitation(
                    company_id=company.id,
                    department_id=dept.id,
                    department_name=dept.name,
                    name=d_info.get('head_name') or 'Department Head',
                    work_email=head_email,
                    designation=d_info.get('head_designation') or 'Department Head',
                    status='pending'
                )
                db.session.add(inv)

        # Organizational relationships (Part 2: Relationship mapping)
        user_rels = data.get('relationships', [])
        for rel in user_rels:
            if not isinstance(rel, dict):
                continue
            src_key = str(rel.get('source_dept', '')).strip().lower()
            tgt_key = str(rel.get('target_dept', '')).strip().lower()
            src_dept = dept_map.get(src_key)
            tgt_dept = dept_map.get(tgt_key)
            if src_dept and tgt_dept and src_dept.id != tgt_dept.id:
                rel_type = rel.get('relationship_type', 'supports')
                dep = TwinDependency(
                    company_id=company.id,
                    source_type='department',
                    source_id=str(src_dept.id),
                    target_type='department',
                    target_id=str(tgt_dept.id),
                    dependency_type=DependencyType.CONFIGURED,
                    strength=float(rel.get('strength', 1.0) or 1.0),
                    description=f"{src_dept.name} {rel_type} {tgt_dept.name}",
                    metadata_json=json.dumps({
                        'relationship_type': rel_type,
                        'source_name': src_dept.name,
                        'target_name': tgt_dept.name
                    })
                )
                db.session.add(dep)

        # Create main branch
        branch = Branch(
            company_id=company.id,
            name=f"{company.company_name} - Main Office",
            city=company.city,
            country=company.country,
            is_main=True,
            branch_type='headquarters'
        )
        db.session.add(branch)
        db.session.commit()

        # Seed real company chart of accounts immediately
        CompanyService.ensure_company_financial_accounts(company.id)

        return company

    @staticmethod
    def get_company(company_id):
        return Company.query.get(company_id)

    @staticmethod
    def company_exists():
        return Company.query.first() is not None

    @staticmethod
    def save_payments(company_id, data):
        payments = CompanyPayments.query.filter_by(company_id=company_id).first()
        if not payments:
            payments = CompanyPayments(company_id=company_id)
            db.session.add(payments)

        for key, value in data.items():
            if hasattr(payments, key):
                setattr(payments, key, value)

        if payments.bank_account_number:
            payments.masked_account_number = payments.get_masked_account_number()

        # Dynamic QR Code generation & persistence
        if payments.upi_id and payments.upi_id.strip():
            try:
                from flask import current_app
                root_path = current_app.root_path if current_app else ''
            except Exception:
                root_path = ''
            payments.generate_and_save_qr(root_dir=root_path)
            if not payments.upi_verification_status or payments.upi_verification_status == 'Not Configured':
                payments.upi_verification_status = 'Configured'
        elif not payments.upi_id:
            payments.upi_verification_status = 'Not Configured'

        db.session.commit()
        CompanyService.ensure_company_financial_accounts(company_id)
        return payments

    @staticmethod
    def ensure_company_financial_accounts(company_id):
        """
        Guarantee real operational chart of accounts derived directly from
        the company's commercial banking, UPI rails, and corporate registration profile.
        Never leaves the FinancialAccount table empty.
        """
        if not company_id:
            return []
        company = Company.query.get(company_id)
        if not company:
            return []

        existing = FinancialAccount.query.filter_by(company_id=company_id, is_active=True).all()
        payments = CompanyPayments.query.filter_by(company_id=company_id).first()

        # Build bank name & masked account string
        bank_name = (payments.bank_name if payments and payments.bank_name else '').strip() or 'Commercial Operating Bank'
        acc_type = (payments.account_type if payments and payments.account_type else '').strip() or 'Current'
        masked_acc = (payments.masked_account_number if payments and payments.masked_account_number else '').strip() or (payments.get_masked_account_number() if payments else '••••Primary')

        primary_bank_label = f"{bank_name} — {acc_type} ({masked_acc})"
        upi_label = f"UPI Instant Settlement ({payments.upi_id})" if payments and payments.upi_id else None

        if not existing:
            created = []
            curr = company.currency or 'USD'
            initial_reserves = float(company.total_equity or (company.annual_revenue * 0.25) or 100000.0)

            # 1. Primary Operating Bank Account
            acc_bank = FinancialAccount(
                company_id=company.id,
                account_name=primary_bank_label,
                account_type='bank',
                account_category='Asset',
                opening_balance=initial_reserves * 0.65,
                current_balance=initial_reserves * 0.65,
                currency=curr,
                is_active=True,
                description=f"Primary commercial settlement account at {bank_name} (Branch: {payments.bank_branch if payments and payments.bank_branch else 'Main'}, IFSC: {payments.bank_ifsc if payments and payments.bank_ifsc else 'Standard'})"
            )
            created.append(acc_bank)

            # 2. UPI Merchant Settlement Account (if UPI exists)
            if upi_label:
                acc_upi = FinancialAccount(
                    company_id=company.id,
                    account_name=upi_label,
                    account_type='cash_equivalent',
                    account_category='Asset',
                    opening_balance=initial_reserves * 0.15,
                    current_balance=initial_reserves * 0.15,
                    currency=curr,
                    is_active=True,
                    description=f"Real-time NPCI UPI settlement node for {payments.upi_display_name or company.company_name}"
                )
                created.append(acc_upi)

            # 3. Commercial Sales & Enterprise Revenue
            acc_rev = FinancialAccount(
                company_id=company.id,
                account_name="Commercial Sales & Enterprise Revenue",
                account_type='revenue',
                account_category='Income',
                opening_balance=0.0,
                current_balance=0.0,
                currency=curr,
                is_active=True,
                description="Primary operational revenue recognition and client billing ledger"
            )
            created.append(acc_rev)

            # 4. Accounts Receivable (A/R)
            acc_ar = FinancialAccount(
                company_id=company.id,
                account_name=f"{company.company_name} — Accounts Receivable (A/R)",
                account_type='receivable',
                account_category='Asset',
                opening_balance=0.0,
                current_balance=0.0,
                currency=curr,
                is_active=True,
                description="Trade receivables and unpaid client invoices pending clearance"
            )
            created.append(acc_ar)

            # 5. Operating Expense Clearing
            acc_exp = FinancialAccount(
                company_id=company.id,
                account_name="Operational Expenditure & Vendor Clearing",
                account_type='expense',
                account_category='Expense',
                opening_balance=0.0,
                current_balance=0.0,
                currency=curr,
                is_active=True,
                description="Operating expenses, supplier payments, and recurring overhead disbursements"
            )
            created.append(acc_exp)

            # 6. Corporate Treasury Reserves
            acc_treasury = FinancialAccount(
                company_id=company.id,
                account_name="Corporate Treasury Reserves",
                account_type='cash',
                account_category='Asset',
                opening_balance=initial_reserves * 0.20,
                current_balance=initial_reserves * 0.20,
                currency=curr,
                is_active=True,
                description="Liquid cash buffer and strategic working capital reserves"
            )
            created.append(acc_treasury)

            for acc in created:
                db.session.add(acc)
            db.session.commit()
            return created

        # If accounts already exist, ensure the primary bank name is up-to-date with company_payments
        primary_acc = next((a for a in existing if a.account_type == 'bank'), None)
        if primary_acc and payments and payments.bank_name and primary_acc.account_name != primary_bank_label:
            primary_acc.account_name = primary_bank_label
            db.session.commit()

        if upi_label and not any(a.account_type == 'cash_equivalent' or 'UPI' in a.account_name for a in existing):
            acc_upi = FinancialAccount(
                company_id=company.id,
                account_name=upi_label,
                account_type='cash_equivalent',
                account_category='Asset',
                opening_balance=0.0,
                current_balance=0.0,
                currency=company.currency or 'USD',
                is_active=True,
                description=f"Real-time NPCI UPI settlement node for {payments.upi_display_name or company.company_name}"
            )
            db.session.add(acc_upi)
            db.session.commit()
            existing.append(acc_upi)

        return existing

    @staticmethod
    def update_company(company_id, data):
        company = Company.query.get(company_id)
        if not company:
            return None

        for key, value in data.items():
            if hasattr(company, key):
                setattr(company, key, value)

        db.session.commit()
        return company

    @staticmethod
    def update_financials(company_id, equity=None, debt=None):
        """Update company total equity and/or total debt."""
        company = Company.query.get(company_id)
        if not company:
            return None
        if equity is not None:
            company.total_equity = float(equity)
        if debt is not None:
            company.total_debt = float(debt)
        db.session.commit()
        return company

    @staticmethod
    def get_company_financials(company_id):
        """Get equity, debt, and computed ratios for a company."""
        company = Company.query.get(company_id)
        if not company:
            return None
        equity = getattr(company, 'total_equity', 0.0) or 0.0
        debt = getattr(company, 'total_debt', 0.0) or 0.0
        revenue = company.annual_revenue or 0.0
        # Fallback equity proxy if not set
        if equity <= 0 and revenue > 0:
            equity = revenue * 0.3
        if equity <= 0:
            equity = 100000.0
        return {
            'total_equity': equity,
            'total_debt': debt,
            'debt_equity_ratio': round(debt / equity, 4) if equity > 0 else 0.0,
            'annual_revenue': revenue
        }