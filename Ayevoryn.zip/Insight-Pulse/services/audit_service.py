"""
AUDIT SERVICE - Enterprise Immutable Audit Trail & Activity History.

Provides:
- Multi-tenant event querying across BusinessEvent and ActivityLog
- Temporal entity change histories with field diff extraction
- Actor activity breakdowns & module mutation statistics
- Filterable CSV exports for compliance and enterprise audit readiness
"""

import io
import csv
import json
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple
from sqlalchemy import or_, and_, desc, asc, func
from database.db import db
from database.models.business_event import BusinessEvent
from database.models.activity_log import ActivityLog
from database.models.audit_log import AuditLog


class AuditService:
    """Enterprise Audit Query & Timeline Reconstruction Service."""

    @staticmethod
    def get_events(
        company_id: int,
        page: int = 1,
        per_page: int = 25,
        actor_id: Optional[int] = None,
        actor_name: Optional[str] = None,
        aggregate_type: Optional[str] = None,
        aggregate_id: Optional[str] = None,
        event_type: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        search: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Query domain events with multi-tenant isolation, rich filters, and pagination.
        """
        query = BusinessEvent.query.filter(BusinessEvent.company_id == company_id)

        if actor_id is not None:
            query = query.filter(BusinessEvent.actor_id == actor_id)

        if actor_name:
            query = query.filter(BusinessEvent.actor_name.ilike(f"%{actor_name}%"))

        if aggregate_type:
            query = query.filter(BusinessEvent.aggregate_type == aggregate_type)

        if aggregate_id is not None:
            query = query.filter(BusinessEvent.aggregate_id == str(aggregate_id))

        if event_type:
            if '*' in event_type:
                prefix = event_type.replace('*', '')
                query = query.filter(BusinessEvent.event_type.startswith(prefix))
            else:
                query = query.filter(BusinessEvent.event_type == event_type)

        if start_date:
            query = query.filter(BusinessEvent.occurred_at >= start_date)

        if end_date:
            query = query.filter(BusinessEvent.occurred_at <= end_date)

        if search and search.strip():
            term = f"%{search.strip()}%"
            query = query.filter(
                or_(
                    BusinessEvent.event_type.ilike(term),
                    BusinessEvent.aggregate_type.ilike(term),
                    BusinessEvent.aggregate_id.ilike(term),
                    BusinessEvent.actor_name.ilike(term),
                    BusinessEvent.payload_json.ilike(term),
                    BusinessEvent.event_id.ilike(term)
                )
            )

        total_count = query.count()
        per_page = max(1, min(per_page, 200))
        total_pages = max(1, (total_count + per_page - 1) // per_page)
        page = max(1, min(page, total_pages)) if total_count > 0 else 1

        events = (
            query.order_by(BusinessEvent.occurred_at.desc())
            .offset((page - 1) * per_page)
            .limit(per_page)
            .all()
        )

        return {
            'items': [e.to_dict() for e in events],
            'total': total_count,
            'page': page,
            'per_page': per_page,
            'pages': total_pages
        }

    @staticmethod
    def get_entity_timeline(
        company_id: int,
        aggregate_type: str,
        aggregate_id: Any
    ) -> List[Dict[str, Any]]:
        """
        Reconstruct chronological mutation timeline for a specific entity,
        including state snapshots and diff calculation between consecutive events.
        """
        events = (
            BusinessEvent.query.filter_by(
                company_id=company_id,
                aggregate_type=str(aggregate_type),
                aggregate_id=str(aggregate_id)
            )
            .order_by(BusinessEvent.occurred_at.asc())
            .all()
        )

        timeline = []
        previous_payload = {}

        for ev in events:
            current_payload = ev.get_payload()
            diff = {}
            if previous_payload:
                all_keys = set(previous_payload.keys()) | set(current_payload.keys())
                for k in all_keys:
                    old_v = previous_payload.get(k)
                    new_v = current_payload.get(k)
                    if old_v != new_v:
                        diff[k] = {'old': old_v, 'new': new_v}

            item = ev.to_dict()
            item['diff'] = diff
            timeline.append(item)
            previous_payload = current_payload

        return timeline

    @staticmethod
    def get_audit_summary(company_id: int, days: int = 30) -> Dict[str, Any]:
        """
        Compute high-level audit and activity analytics for executive overview.
        """
        since = datetime.utcnow() - timedelta(days=days)
        base_query = BusinessEvent.query.filter(
            BusinessEvent.company_id == company_id,
            BusinessEvent.occurred_at >= since
        )

        total_events = base_query.count()

        # Group by module / aggregate_type
        by_module_rows = (
            db.session.query(
                BusinessEvent.aggregate_type,
                func.count(BusinessEvent.id).label('cnt')
            )
            .filter(
                BusinessEvent.company_id == company_id,
                BusinessEvent.occurred_at >= since
            )
            .group_by(BusinessEvent.aggregate_type)
            .order_by(desc('cnt'))
            .all()
        )
        by_module = [{'module': r[0], 'count': r[1]} for r in by_module_rows]

        # Top active actors
        by_actor_rows = (
            db.session.query(
                BusinessEvent.actor_name,
                func.count(BusinessEvent.id).label('cnt')
            )
            .filter(
                BusinessEvent.company_id == company_id,
                BusinessEvent.occurred_at >= since
            )
            .group_by(BusinessEvent.actor_name)
            .order_by(desc('cnt'))
            .limit(10)
            .all()
        )
        by_actor = [{'actor': r[0] or 'System', 'count': r[1]} for r in by_actor_rows]

        # Security authentication logs
        security_count = AuditLog.query.filter(
            AuditLog.company_id == company_id,
            AuditLog.created_at >= since
        ).count()

        return {
            'days': days,
            'total_events': total_events,
            'active_actors_count': len(by_actor),
            'top_module': by_module[0]['module'] if by_module else 'None',
            'by_module': by_module,
            'by_actor': by_actor,
            'security_events_count': security_count
        }

    @staticmethod
    def export_events_csv(
        company_id: int,
        aggregate_type: Optional[str] = None,
        event_type: Optional[str] = None,
        search: Optional[str] = None,
        limit: int = 5000
    ) -> str:
        """
        Export domain events to a standard RFC 4180 CSV string.
        """
        res = AuditService.get_events(
            company_id=company_id,
            page=1,
            per_page=limit,
            aggregate_type=aggregate_type,
            event_type=event_type,
            search=search
        )
        events = res.get('items', [])

        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow([
            'Event ID', 'Occurred At (UTC)', 'Event Type', 'Aggregate Type',
            'Aggregate ID', 'Actor ID', 'Actor Name', 'Correlation ID', 'Payload'
        ])

        for ev in events:
            writer.writerow([
                ev.get('event_id', ''),
                ev.get('occurred_at', ''),
                ev.get('event_type', ''),
                ev.get('aggregate_type', ''),
                ev.get('aggregate_id', ''),
                ev.get('actor_id', ''),
                ev.get('actor_name', ''),
                ev.get('correlation_id', ''),
                json.dumps(ev.get('payload', {}))
            ])

        return output.getvalue()
