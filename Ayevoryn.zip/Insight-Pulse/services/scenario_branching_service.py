"""
SCENARIO BRANCHING SERVICE
Enterprise multi-scenario sandbox branching, forward evaluation, variance analysis,
and plan merge governance without mutating live observed business ledgers.
"""

from datetime import datetime
import json
from database.db import db
from database.models.scenario import Scenario, ScenarioStep, ScenarioStatus, BranchType
from database.models.company import Company
from database.models.employee import Employee
from database.models.twin_snapshot import TwinSnapshot
from services.analytics_service import AnalyticsService
from services.events import EventBus, EventTypes
from services.audit_service import AuditService

class ScenarioBranchingService:
    
    @staticmethod
    def branch_scenario(company_id, user_id, name, parent_scenario_id=None,
                        baseline_snapshot_id=None, scenario_type='Strategic',
                        branch_type=BranchType.SANDBOX, description='',
                        parameters=None, deltas=None):
        """
        Creates an isolated scenario branch from either live digital twin state,
        a frozen snapshot, or a parent scenario branch.
        """
        company = Company.query.get(company_id)
        if not company:
            raise ValueError(f"Company {company_id} not found")

        parent_scenario = None
        if parent_scenario_id:
            parent_scenario = Scenario.query.filter_by(id=parent_scenario_id, company_id=company_id).first()
            if not parent_scenario:
                raise ValueError(f"Parent scenario {parent_scenario_id} not found for company {company_id}")
            
            # Inherit parent parameters/deltas/snapshot if not overridden
            if parameters is None:
                parameters = parent_scenario.get_parameters()
            if deltas is None:
                deltas = parent_scenario.get_sandbox_deltas()
            if baseline_snapshot_id is None:
                baseline_snapshot_id = parent_scenario.baseline_snapshot_id

        if baseline_snapshot_id:
            snapshot = TwinSnapshot.query.filter_by(snapshot_id=baseline_snapshot_id, company_id=company_id).first()
            if not snapshot:
                raise ValueError(f"Baseline snapshot {baseline_snapshot_id} not found for company {company_id}")

        params = parameters or {
            'revenue_delta_pct': 10.0,
            'expense_delta_pct': -5.0,
            'headcount_delta': 2,
            'capex_investment': 25000.0,
            'duration_months': 12
        }

        scenario = Scenario(
            company_id=company_id,
            user_id=user_id,
            parent_scenario_id=parent_scenario_id,
            baseline_snapshot_id=baseline_snapshot_id,
            name=name.strip(),
            description=description.strip() if description else '',
            scenario_type=scenario_type,
            branch_type=branch_type,
            status=ScenarioStatus.DRAFT,
            is_active=True
        )
        scenario.set_parameters(params)
        scenario.set_sandbox_deltas(deltas or {})

        db.session.add(scenario)
        db.session.flush()

        # Seed standard phased implementation steps
        capex = float(params.get('capex_investment', 0.0))
        headcount = int(params.get('headcount_delta', 0))
        rev_delta = float(params.get('revenue_delta_pct', 0.0))
        exp_delta = float(params.get('expense_delta_pct', 0.0))
        duration = int(params.get('duration_months', 12))

        steps = [
            ScenarioStep(
                scenario_id=scenario.id,
                step_number=1,
                name="Phase 1: Capital & Resource Allocation",
                description=f"Allocate upfront capital of {capex:,.2f} across operational centers.",
                is_completed=False
            ),
            ScenarioStep(
                scenario_id=scenario.id,
                step_number=2,
                name="Phase 2: Organizational Scaling",
                description=f"Adjust workforce capacity by {headcount:+d} positions.",
                is_completed=False
            ),
            ScenarioStep(
                scenario_id=scenario.id,
                step_number=3,
                name="Phase 3: Market Execution & Trajectory",
                description=f"Execute operational adjustments targeting {rev_delta:+0.1f}% top-line and {exp_delta:+0.1f}% expense variances.",
                is_completed=False
            ),
            ScenarioStep(
                scenario_id=scenario.id,
                step_number=4,
                name="Phase 4: ROI Realization & Retrospective",
                description=f"Review terminal performance and evaluate actuals over a {duration}-month lifecycle.",
                is_completed=False
            )
        ]
        for st in steps:
            db.session.add(st)

        db.session.commit()

        # Publish domain event
        try:
            EventBus.publish(
                EventTypes.SCENARIO_BRANCHED,
                company_id=company_id,
                actor_id=user_id,
                entity_type="scenario",
                entity_id=scenario.id,
                payload={
                    "scenario_id": scenario.id,
                    "name": scenario.name,
                    "parent_scenario_id": parent_scenario_id,
                    "baseline_snapshot_id": baseline_snapshot_id,
                    "branch_type": branch_type
                }
            )
        except Exception:
            pass

        return scenario

    @staticmethod
    def evaluate_branch(company_id, scenario_id):
        """
        Evaluates the forward projection of a scenario branch against its baseline
        (live digital twin or frozen snapshot) with ZERO mutation of live records.
        """
        scenario = Scenario.query.filter_by(id=scenario_id, company_id=company_id).first()
        if not scenario:
            raise ValueError(f"Scenario {scenario_id} not found for company {company_id}")

        company = Company.query.get(company_id)
        if not company:
            raise ValueError(f"Company {company_id} not found")

        # 1. Determine baseline state
        baseline_source = "Live Digital Twin"
        if scenario.baseline_snapshot_id:
            snapshot = TwinSnapshot.query.filter_by(snapshot_id=scenario.baseline_snapshot_id, company_id=company_id).first()
            if snapshot:
                metrics = snapshot.get_metrics()
                entity_counts = snapshot.get_entity_counts()
                
                rev_30d = float(metrics.get('revenue_trailing_30d', 0.0) or 0.0)
                exp_30d = float(metrics.get('expense_trailing_30d', 0.0) or 0.0)
                base_rev = (rev_30d * 12.0) if rev_30d > 0 else float(getattr(company, 'annual_revenue', 0.0) or 100000.0)
                base_exp = (exp_30d * 12.0) if exp_30d > 0 else (base_rev * 0.75)
                base_cash = float(metrics.get('liquid_cash_reserves', 0.0) or 0.0)
                base_burn = float(metrics.get('monthly_burn_rate', 0.0) or 0.0)
                base_runway = float(metrics.get('cash_runway_months', 0.0) or 999.0)
                base_headcount = int(entity_counts.get('employees', 0) or getattr(company, 'employee_count', 1))
                baseline_source = f"Snapshot: {snapshot.name} ({snapshot.snapshot_id[:8]})"
            else:
                summary = AnalyticsService.get_executive_summary(company_id)
                rev_30d = float(summary.get('revenue_30d', 0.0) or 0.0)
                exp_30d = float(summary.get('expense_30d', 0.0) or 0.0)
                base_rev = (rev_30d * 12.0) if rev_30d > 0 else float(getattr(company, 'annual_revenue', 0.0) or 100000.0)
                base_exp = (exp_30d * 12.0) if exp_30d > 0 else (base_rev * 0.75)
                base_cash = float(summary.get('cash_balance', 0.0) or 0.0)
                base_burn = float(summary.get('monthly_burn', 0.0) or 0.0)
                base_runway = float(summary.get('runway_months', 0.0) or 999.0)
                base_headcount = Employee.query.filter_by(company_id=company_id, status='active').count() or getattr(company, 'employee_count', 1)
        else:
            summary = AnalyticsService.get_executive_summary(company_id)
            rev_30d = float(summary.get('revenue_30d', 0.0) or 0.0)
            exp_30d = float(summary.get('expense_30d', 0.0) or 0.0)
            base_rev = (rev_30d * 12.0) if rev_30d > 0 else float(getattr(company, 'annual_revenue', 0.0) or 100000.0)
            base_exp = (exp_30d * 12.0) if exp_30d > 0 else (base_rev * 0.75)
            base_cash = float(summary.get('cash_balance', 0.0) or 0.0)
            base_burn = float(summary.get('monthly_burn', 0.0) or 0.0)
            base_runway = float(summary.get('runway_months', 0.0) or 999.0)
            base_headcount = Employee.query.filter_by(company_id=company_id, status='active').count() or getattr(company, 'employee_count', 1)

        base_profit = base_rev - base_exp
        base_margin = (base_profit / base_rev * 100.0) if base_rev else 0.0

        # 2. Extract Scenario Parameters & Deltas
        params = scenario.get_parameters()
        deltas = scenario.get_sandbox_deltas()

        rev_delta_pct = float(deltas.get('revenue_delta_pct', params.get('revenue_delta_pct', 0.0)) or 0.0)
        exp_delta_pct = float(deltas.get('expense_delta_pct', params.get('expense_delta_pct', 0.0)) or 0.0)
        headcount_delta = int(deltas.get('headcount_delta', params.get('headcount_delta', 0)) or 0)
        capex = float(deltas.get('capex_investment', params.get('capex_investment', 0.0)) or 0.0)
        duration_months = int(deltas.get('duration_months', params.get('duration_months', 12)) or 12)

        # 3. Compute Projected Forward Metrics
        proj_rev = round(base_rev * (1.0 + (rev_delta_pct / 100.0)), 2)
        proj_exp = round(base_exp * (1.0 + (exp_delta_pct / 100.0)), 2)
        proj_profit = round(proj_rev - proj_exp, 2)
        proj_margin = round((proj_profit / proj_rev * 100.0) if proj_rev else 0.0, 2)
        proj_headcount = max(0, base_headcount + headcount_delta)

        net_annual_benefit = round(proj_profit - base_profit, 2)
        roi_pct = round((net_annual_benefit / capex * 100.0), 1) if capex > 0 else None
        payback_months = round((capex / (net_annual_benefit / 12.0)), 1) if capex > 0 and net_annual_benefit > 0 else None

        # Cash & Runway Projection
        proj_cash = max(0.0, round(base_cash - capex, 2))
        proj_monthly_burn = max(0.0, round((proj_exp - proj_rev) / 12.0, 2))
        proj_runway_months = round(proj_cash / proj_monthly_burn, 1) if proj_monthly_burn > 0 else 999.0

        # 4. Deterministic Risk Evaluation & Explainability
        risk_reasons = []
        if proj_profit < 0:
            risk_reasons.append(f"Operating loss projected at {proj_profit:,.2f}")
        if proj_margin < 5.0 and proj_profit >= 0:
            risk_reasons.append(f"Thin operating margin ({proj_margin:.1f}%)")
        if proj_runway_months < 6.0:
            risk_reasons.append(f"Cash runway contracts to {proj_runway_months:.1f} months")
        if capex > base_cash and base_cash > 0:
            risk_reasons.append(f"Upfront capex ({capex:,.2f}) exceeds liquid cash reserves ({base_cash:,.2f})")
        if exp_delta_pct > 25.0:
            risk_reasons.append(f"Heavy expense expansion (+{exp_delta_pct:.1f}%)")

        if proj_profit < 0 or proj_runway_months < 3.0:
            risk_level = 'CRITICAL'
            risk_color = '#DC2626'
        elif proj_margin < 5.0 or proj_runway_months < 6.0 or (capex > base_cash and base_cash > 0):
            risk_level = 'HIGH'
            risk_color = '#EF4444'
        elif proj_margin < 15.0 or exp_delta_pct > 15.0:
            risk_level = 'MODERATE'
            risk_color = '#F59E0B'
        else:
            risk_level = 'LOW'
            risk_color = '#10B981'

        evaluation = {
            'evaluated_at': datetime.utcnow().isoformat(),
            'baseline_source': baseline_source,
            'horizon_months': duration_months,
            'baseline': {
                'revenue': round(base_rev, 2),
                'expense': round(base_exp, 2),
                'profit': round(base_profit, 2),
                'margin': round(base_margin, 2),
                'cash': round(base_cash, 2),
                'monthly_burn': round(base_burn, 2),
                'runway_months': round(base_runway, 1),
                'headcount': base_headcount
            },
            'projected': {
                'revenue': proj_rev,
                'expense': proj_exp,
                'profit': proj_profit,
                'margin': proj_margin,
                'cash': proj_cash,
                'monthly_burn': proj_monthly_burn,
                'runway_months': proj_runway_months,
                'headcount': proj_headcount
            },
            'variance': {
                'revenue_delta': round(proj_rev - base_rev, 2),
                'revenue_delta_pct': rev_delta_pct,
                'expense_delta': round(proj_exp - base_exp, 2),
                'expense_delta_pct': exp_delta_pct,
                'profit_delta': net_annual_benefit,
                'margin_delta': round(proj_margin - base_margin, 2),
                'headcount_delta': headcount_delta,
                'net_benefit': net_annual_benefit,
                'roi_pct': roi_pct,
                'payback_months': payback_months
            },
            'risk': {
                'level': risk_level,
                'color': risk_color,
                'reasons': risk_reasons
            }
        }

        # 5. Persist simulation results & update status
        scenario.set_simulation_results(evaluation)
        if scenario.status != ScenarioStatus.MERGED:
            scenario.status = ScenarioStatus.EVALUATED
        scenario.updated_at = datetime.utcnow()
        db.session.commit()

        # Publish domain event
        try:
            EventBus.publish(
                EventTypes.SCENARIO_EVALUATED,
                company_id=company_id,
                actor_id=scenario.user_id,
                entity_type="scenario",
                entity_id=scenario.id,
                payload={
                    "scenario_id": scenario.id,
                    "risk_level": risk_level,
                    "projected_profit": proj_profit,
                    "net_benefit": net_annual_benefit
                }
            )
        except Exception:
            pass

        return evaluation

    @staticmethod
    def compare_branches(company_id, scenario_id_a, scenario_id_b=None):
        """
        Performs multi-dimensional comparative variance analysis between:
        - Scenario A and Baseline (if scenario_id_b is None)
        - Scenario A and Scenario B (if scenario_id_b is provided)
        """
        scen_a = Scenario.query.filter_by(id=scenario_id_a, company_id=company_id).first()
        if not scen_a:
            raise ValueError(f"Scenario {scenario_id_a} not found for company {company_id}")

        res_a = scen_a.get_simulation_results()
        if not res_a:
            res_a = ScenarioBranchingService.evaluate_branch(company_id, scenario_id_a)

        if scenario_id_b is None:
            # Compare A against its baseline
            b = res_a['baseline']
            p = res_a['projected']
            v = res_a['variance']
            return {
                'mode': 'BASELINE_VS_BRANCH',
                'branch_a': {
                    'id': scen_a.id,
                    'name': scen_a.name,
                    'branch_type': scen_a.branch_type,
                    'status': scen_a.status,
                    'metrics': p
                },
                'baseline': b,
                'variance': v,
                'risk': res_a['risk']
            }

        # Compare A against B
        scen_b = Scenario.query.filter_by(id=scenario_id_b, company_id=company_id).first()
        if not scen_b:
            raise ValueError(f"Scenario {scenario_id_b} not found for company {company_id}")

        res_b = scen_b.get_simulation_results()
        if not res_b:
            res_b = ScenarioBranchingService.evaluate_branch(company_id, scenario_id_b)

        p_a = res_a['projected']
        p_b = res_b['projected']

        rev_diff = round(p_a['revenue'] - p_b['revenue'], 2)
        exp_diff = round(p_a['expense'] - p_b['expense'], 2)
        profit_diff = round(p_a['profit'] - p_b['profit'], 2)
        margin_diff = round(p_a['margin'] - p_b['margin'], 2)
        runway_diff = round(p_a['runway_months'] - p_b['runway_months'], 1)
        headcount_diff = p_a['headcount'] - p_b['headcount']

        recommendation = ""
        if profit_diff > 0 and margin_diff >= 0:
            recommendation = f'Branch "{scen_a.name}" outperforms "{scen_b.name}" with +{profit_diff:,.2f} higher operating profit.'
        elif profit_diff < 0:
            recommendation = f'Branch "{scen_b.name}" delivers superior profitability with +{abs(profit_diff):,.2f} over "{scen_a.name}".'
        else:
            recommendation = f'Branches yield comparable bottom-line results with divergent operational footprints.'

        return {
            'mode': 'BRANCH_VS_BRANCH',
            'branch_a': {
                'id': scen_a.id,
                'name': scen_a.name,
                'branch_type': scen_a.branch_type,
                'status': scen_a.status,
                'metrics': p_a,
                'risk': res_a['risk']
            },
            'branch_b': {
                'id': scen_b.id,
                'name': scen_b.name,
                'branch_type': scen_b.branch_type,
                'status': scen_b.status,
                'metrics': p_b,
                'risk': res_b['risk']
            },
            'comparison': {
                'revenue_diff': rev_diff,
                'expense_diff': exp_diff,
                'profit_diff': profit_diff,
                'margin_diff': margin_diff,
                'runway_diff': runway_diff,
                'headcount_diff': headcount_diff,
                'recommendation': recommendation
            }
        }

    @staticmethod
    def merge_to_plan(company_id, scenario_id, user_id, apply_targets=True):
        """
        Merges an evaluated scenario branch into the company\'s official plan targets.
        Strict enterprise invariant: DOES NOT mutate or retroactively falsify historical ledgers.
        Updates canonical declared targets on the Company model.
        """
        scenario = Scenario.query.filter_by(id=scenario_id, company_id=company_id).first()
        if not scenario:
            raise ValueError(f"Scenario {scenario_id} not found for company {company_id}")

        results = scenario.get_simulation_results()
        if not results:
            results = ScenarioBranchingService.evaluate_branch(company_id, scenario_id)

        company = Company.query.get(company_id)
        if not company:
            raise ValueError(f"Company {company_id} not found")

        projected = results.get('projected', {})
        old_rev_target = company.annual_revenue_target
        old_exp_plan = company.annual_expenses_plan

        if apply_targets:
            if 'revenue' in projected:
                company.annual_revenue_target = float(projected['revenue'])
            if 'expense' in projected:
                company.annual_expenses_plan = float(projected['expense'])

        scenario.status = ScenarioStatus.MERGED
        scenario.updated_at = datetime.utcnow()
        db.session.commit()

        # Audit log entry
        try:
            AuditService.log_action(
                company_id=company_id,
                user_id=user_id,
                action="scenario.merged",
                resource_type="scenario",
                resource_id=scenario.id,
                details=f'Scenario "{scenario.name}" merged to official plan. Revenue target set to {company.annual_revenue_target:,.2f}, expense plan to {company.annual_expenses_plan:,.2f}'
            )
        except Exception:
            pass

        # Domain event
        try:
            EventBus.publish(
                EventTypes.SCENARIO_MERGED,
                company_id=company_id,
                actor_id=user_id,
                entity_type="scenario",
                entity_id=scenario.id,
                payload={
                    "scenario_id": scenario.id,
                    "name": scenario.name,
                    "new_revenue_target": company.annual_revenue_target,
                    "new_expenses_plan": company.annual_expenses_plan,
                    "old_revenue_target": old_rev_target,
                    "old_expenses_plan": old_exp_plan
                }
            )
        except Exception:
            pass

        return {
            'success': True,
            'scenario_id': scenario.id,
            'scenario_name': scenario.name,
            'status': scenario.status,
            'annual_revenue_target': company.annual_revenue_target,
            'annual_expenses_plan': company.annual_expenses_plan
        }

    @staticmethod
    def get_branch_lineage_tree(company_id):
        """
        Constructs hierarchical branch lineage tree of all scenarios for a tenant.
        """
        all_scenarios = Scenario.query.filter_by(company_id=company_id).order_by(Scenario.created_at.asc()).all()
        by_id = {s.id: s.to_dict(include_details=True) for s in all_scenarios}
        
        roots = []
        for s in all_scenarios:
            s_dict = by_id[s.id]
            if s.parent_scenario_id and s.parent_scenario_id in by_id:
                parent_dict = by_id[s.parent_scenario_id]
                parent_dict.setdefault('children', []).append(s_dict)
            else:
                roots.append(s_dict)

        return roots

    @staticmethod
    def get_scenarios(company_id, status=None, branch_type=None):
        """
        Returns all scenarios for a tenant with optional filtering.
        """
        q = Scenario.query.filter_by(company_id=company_id)
        if status:
            q = q.filter_by(status=status)
        if branch_type:
            q = q.filter_by(branch_type=branch_type)
        return q.order_by(Scenario.created_at.desc()).all()

    @staticmethod
    def get_scenario_by_id(company_id, scenario_id):
        """
        Tenant-scoped retrieval of single scenario with parsed parameters and simulation results.
        """
        return Scenario.query.filter_by(id=scenario_id, company_id=company_id).first()

    @staticmethod
    def delete_scenario(company_id, scenario_id):
        """
        Tenant-scoped deletion of scenario and all child steps.
        """
        scenario = Scenario.query.filter_by(id=scenario_id, company_id=company_id).first()
        if not scenario:
            return False

        name = scenario.name
        db.session.delete(scenario)
        db.session.commit()

        try:
            EventBus.publish(
                EventTypes.SCENARIO_DELETED,
                company_id=company_id,
                entity_type="scenario",
                entity_id=scenario_id,
                payload={"scenario_id": scenario_id, "name": name}
            )
        except Exception:
            pass

        return True
