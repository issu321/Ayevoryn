"""
AEVORYN / INSIGHT-PULSE
STAGE 22: WEBHOOK DISPATCH & SUBSCRIPTION SERVICE
Enterprise webhook management, cryptographic HMAC-SHA256 signature generation,
and reliable event-driven delivery logging.
"""

from datetime import datetime
import json
import time
import uuid
import logging
from typing import Optional, Dict, Any, List
import requests

from database.db import db
from database.models.webhook import WebhookSubscription, WebhookDelivery
from database.models.company import Company
from services.events.types import EventTypes

logger = logging.getLogger(__name__)


class WebhookService:
    """Service handling webhook subscription lifecycle and secure HTTP delivery."""

    @staticmethod
    def create_subscription(company_id: int, url: str, event_types: str = '*',
                            description: str = None, secret: str = None) -> WebhookSubscription:
        """Register a new outbound webhook subscription for a tenant."""
        if not url or not (url.startswith('http://') or url.startswith('https://')):
            raise ValueError("Webhook URL must be an absolute HTTP or HTTPS URL.")
        
        company = Company.query.get(company_id)
        if not company:
            raise ValueError(f"Company {company_id} not found.")

        sub = WebhookSubscription.create(
            company_id=company_id,
            url=url,
            event_types=event_types,
            description=description,
            secret=secret
        )

        from services.events import EventBus, DomainEvent
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.WEBHOOK_SUBSCRIPTION_CREATED,
            company_id=company_id,
            aggregate_type="WebhookSubscription",
            aggregate_id=str(sub.id),
            payload={"subscription_id": sub.id, "url": sub.url, "event_types": sub.event_types}
        ))
        return sub

    @staticmethod
    def update_subscription(sub_id: int, company_id: int, url: str = None,
                            event_types: str = None, is_active: bool = None,
                            description: str = None) -> Optional[WebhookSubscription]:
        """Update an existing webhook subscription under strict tenant isolation."""
        sub = WebhookSubscription.query.filter_by(id=sub_id, company_id=company_id).first()
        if not sub:
            return None

        if url is not None:
            if not (url.startswith('http://') or url.startswith('https://')):
                raise ValueError("Webhook URL must be an absolute HTTP or HTTPS URL.")
            sub.url = url.strip()

        if event_types is not None:
            if isinstance(event_types, (list, set)):
                sub.event_types = ','.join([str(e).strip() for e in event_types if str(e).strip()])
            else:
                sub.event_types = str(event_types).strip() or '*'

        if is_active is not None:
            sub.is_active = bool(is_active)

        if description is not None:
            sub.description = description.strip() if description else None

        db.session.commit()

        from services.events import EventBus, DomainEvent
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.WEBHOOK_SUBSCRIPTION_UPDATED,
            company_id=company_id,
            aggregate_type="WebhookSubscription",
            aggregate_id=str(sub.id),
            payload={"subscription_id": sub.id, "url": sub.url, "is_active": sub.is_active}
        ))
        return sub

    @staticmethod
    def delete_subscription(sub_id: int, company_id: int) -> bool:
        """Delete a webhook subscription strictly owned by the tenant."""
        sub = WebhookSubscription.query.filter_by(id=sub_id, company_id=company_id).first()
        if not sub:
            return False

        sub_url = sub.url
        db.session.delete(sub)
        db.session.commit()

        from services.events import EventBus, DomainEvent
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.WEBHOOK_SUBSCRIPTION_DELETED,
            company_id=company_id,
            aggregate_type="WebhookSubscription",
            aggregate_id=str(sub_id),
            payload={"subscription_id": sub_id, "url": sub_url}
        ))
        return True

    @staticmethod
    def get_subscription(sub_id: int, company_id: int) -> Optional[WebhookSubscription]:
        """Get a single subscription verifying tenant isolation."""
        return WebhookSubscription.query.filter_by(id=sub_id, company_id=company_id).first()

    @staticmethod
    def list_subscriptions(company_id: int, page: int = 1, per_page: int = 50) -> List[WebhookSubscription]:
        """List all subscriptions for a tenant."""
        return WebhookSubscription.query.filter_by(company_id=company_id).order_by(
            WebhookSubscription.created_at.desc()
        ).paginate(page=page, per_page=per_page, error_out=False).items

    @staticmethod
    def get_deliveries(sub_id: int, company_id: int, limit: int = 50) -> List[WebhookDelivery]:
        """Retrieve recent deliveries for a subscription with tenant validation."""
        sub = WebhookSubscription.query.filter_by(id=sub_id, company_id=company_id).first()
        if not sub:
            return []
        return WebhookDelivery.query.filter_by(subscription_id=sub.id, company_id=company_id).order_by(
            WebhookDelivery.delivered_at.desc()
        ).limit(limit).all()

    @classmethod
    def deliver_payload(cls, sub: WebhookSubscription, event_type: str,
                        payload_data: Dict[str, Any], delivery_id: str = None) -> WebhookDelivery:
        """
        Execute authenticated HTTP delivery of an event payload to a subscriber.
        Computes HMAC-SHA256 signature and records delivery telemetry.
        """
        if not delivery_id:
            delivery_id = f"del_{uuid.uuid4().hex}"

        timestamp_iso = datetime.utcnow().isoformat()
        full_envelope = {
            "id": delivery_id,
            "event": event_type,
            "timestamp": timestamp_iso,
            "tenant_id": sub.company_id,
            "data": payload_data
        }

        payload_bytes = json.dumps(full_envelope, sort_keys=True, default=str).encode('utf-8')
        signature = sub.sign_payload(payload_bytes)

        headers = {
            "Content-Type": "application/json",
            "User-Agent": "Aevoryn-Webhooks/1.0",
            "X-Aevoryn-Delivery": delivery_id,
            "X-Aevoryn-Event": event_type,
            "X-Aevoryn-Signature": f"sha256={signature}",
            "X-Aevoryn-Timestamp": timestamp_iso
        }

        start_time = time.time()
        status_code = None
        success = False
        error_message = None

        try:
            resp = requests.post(sub.url, data=payload_bytes, headers=headers, timeout=5.0)
            status_code = resp.status_code
            elapsed_ms = int((time.time() - start_time) * 1000)
            if 200 <= resp.status_code < 300:
                success = True
                sub.last_triggered_at = datetime.utcnow()
                sub.failure_count = 0
            else:
                success = False
                sub.failure_count = (sub.failure_count or 0) + 1
                error_message = f"HTTP {resp.status_code}: {resp.text[:250]}"
        except requests.RequestException as e:
            elapsed_ms = int((time.time() - start_time) * 1000)
            status_code = None
            success = False
            sub.failure_count = (sub.failure_count or 0) + 1
            error_message = str(e)[:500]

        delivery = WebhookDelivery(
            subscription_id=sub.id,
            company_id=sub.company_id,
            event_type=event_type,
            payload_json=json.dumps(full_envelope, default=str),
            status_code=status_code,
            success=success,
            error_message=error_message,
            delivered_at=datetime.utcnow(),
            response_time_ms=elapsed_ms
        )
        db.session.add(delivery)
        try:
            db.session.commit()
        except Exception:
            db.session.rollback()

        return delivery

    @classmethod
    def dispatch_event(cls, event_type: str, payload: Dict[str, Any], company_id: int) -> List[WebhookDelivery]:
        """
        Locate all matching active webhook subscriptions for this tenant and deliver the payload.
        """
        if not company_id or not event_type:
            return []

        # Recursion guard: never dispatch webhook internal events to prevent infinite cycles
        if event_type.startswith('webhook.'):
            return []

        active_subs = WebhookSubscription.query.filter_by(
            company_id=company_id,
            is_active=True
        ).all()

        deliveries = []
        for sub in active_subs:
            if sub.matches_event(event_type):
                try:
                    deliv = cls.deliver_payload(sub, event_type, payload)
                    deliveries.append(deliv)
                except Exception as ex:
                    logger.error(f"[WEBHOOK] Error delivering to sub {sub.id}: {ex}")

        return deliveries

    @classmethod
    def dispatch_test_ping(cls, sub_id: int, company_id: int) -> Optional[WebhookDelivery]:
        """Send an explicit test ping to verify webhook connectivity."""
        sub = WebhookSubscription.query.filter_by(id=sub_id, company_id=company_id).first()
        if not sub:
            return None

        ping_payload = {
            "test": True,
            "message": "AEVORYN Webhook Connectivity Test Ping",
            "subscription_id": sub.id,
            "timestamp": datetime.utcnow().isoformat(),
            "company_id": company_id
        }
        return cls.deliver_payload(sub, "ping", ping_payload)

    @classmethod
    def on_domain_event(cls, event: Any):
        """
        Global EventBus listener callback. Dispatches events to subscribed webhooks.
        """
        try:
            company_id = getattr(event, 'company_id', None)
            event_type = getattr(event, 'event_type', None)
            if not company_id and isinstance(event, dict):
                company_id = event.get('company_id')
            if not event_type and isinstance(event, dict):
                event_type = event.get('event_type')

            if not company_id or not event_type:
                return

            payload = getattr(event, 'payload', None)
            if payload is None and isinstance(event, dict):
                payload = event.get('payload', {})
            if payload is None:
                payload = {}

            # Add aggregate metadata if available
            agg_type = getattr(event, 'aggregate_type', None)
            agg_id = getattr(event, 'aggregate_id', None)
            enriched_payload = dict(payload)
            if agg_type:
                enriched_payload['_aggregate_type'] = agg_type
            if agg_id:
                enriched_payload['_aggregate_id'] = agg_id

            cls.dispatch_event(event_type, enriched_payload, company_id)
        except Exception as e:
            logger.error(f"[WEBHOOK] EventBus dispatch error: {e}")
