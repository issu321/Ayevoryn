# ==============================================================================
# AEVORYN / INSIGHT-PULSE
# STAGE 26: PRODUCTION GUNICORN CONFIGURATION
# High-concurrency threaded worker pool with graceful lifecycle hooks
# ==============================================================================

import os
import multiprocessing

# Server Socket Binding
bind = f"0.0.0.0:{os.environ.get('PORT', '5000')}"
backlog = 2048

# Worker Process Architecture
cpu_count = multiprocessing.cpu_count()
workers = int(os.environ.get('GUNICORN_WORKERS', max(2, min(8, cpu_count * 2))))
threads = int(os.environ.get('GUNICORN_THREADS', 2))
worker_class = "gthread"
worker_connections = 1000

# Timeouts & Keep-Alive
timeout = int(os.environ.get('GUNICORN_TIMEOUT', 120))
graceful_timeout = int(os.environ.get('GUNICORN_GRACEFUL_TIMEOUT', 30))
keepalive = 5

# Memory Leak Prevention: Periodically restart workers after handling requests
max_requests = 2000
max_requests_jitter = 200

# Logging: Direct stdout and stderr streaming for container log collectors
accesslog = "-"
errorlog = "-"
loglevel = os.environ.get('GUNICORN_LOG_LEVEL', 'info')
access_log_format = '%(h)s %(l)s %(u)s %(t)s "%(r)s" %(s)s %(b)s "%(f)s" "%(a)s" (%(D)s µs)'

# Process Naming
proc_name = "aevoryn_web"


def on_starting(server):
    """Lifecycle hook: Called just before master process starts."""
    server.log.info("[AEVORYN GUNICORN] Starting Aevoryn Enterprise Web Cluster...")


def on_reload(server):
    """Lifecycle hook: Called to reload worker processes."""
    server.log.info("[AEVORYN GUNICORN] Reloading workers...")


def worker_exit(server, worker):
    """Lifecycle hook: Called just after a worker has exited."""
    server.log.info(f"[AEVORYN GUNICORN] Worker {worker.pid} exited cleanly.")
