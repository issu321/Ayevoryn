import os
import sys
import atexit
import logging

# Python 3.14+ Windows fix: prevent _enter_buffered_busy fatal lock error on <stderr>/<stdout>
# at interpreter shutdown when background/Werkzeug threads are active.
logging.raiseExceptions = False
for _stream in (sys.stdout, sys.stderr):
    try:
        if hasattr(_stream, 'reconfigure'):
            _stream.reconfigure(write_through=True)
    except Exception:
        pass
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_login import LoginManager, login_required, current_user, logout_user
from dotenv import load_dotenv
from flask_wtf.csrf import CSRFProtect, CSRFError
from flask_migrate import Migrate

load_dotenv()

csrf = CSRFProtect()
migrate = Migrate()


def create_app(config_override=None):
    app = Flask(__name__,
                template_folder='templates',
                static_folder='static')

    app.config.from_object('config.settings.Config')
    if config_override:
        app.config.update(config_override)

    # Initialize telemetry & observability
    from services.telemetry import configure_logging, init_telemetry_middleware
    configure_logging(app)
    init_telemetry_middleware(app)

    # Initialize CSRF protection globally
    csrf.init_app(app)

    # Initialize extensions
    from database.db import db, init_db
    db.init_app(app)
    migrate.init_app(app, db, render_as_batch=True)

    # CRITICAL: Import ALL models BEFORE db.create_all()
    import database.models  # noqa: F401

    with app.app_context():
        _engine = db.engine
        if _engine.url.get_backend_name() == 'sqlite':
            import sqlite3
            _db_file = _engine.url.database
            if _db_file and _db_file != ':memory:':
                _abs_path = _db_file if os.path.isabs(_db_file) else \
                    os.path.join(app.instance_path, _db_file)
                if os.path.exists(_abs_path) and os.path.getsize(_abs_path) == 0:
                    _engine.dispose()
                    os.remove(_abs_path)
                    print(f"[BOOTSTRAP] Removed invalid empty database: {_abs_path}")
                else:
                    try:
                        conn = sqlite3.connect(_abs_path)
                        conn.execute('SELECT 1')
                        conn.close()
                    except sqlite3.DatabaseError:
                        _engine.dispose()
                        os.remove(_abs_path)
                        print(f"[BOOTSTRAP] Removed corrupt database: {_abs_path}")
        db.create_all()
        from database.db import _heal_schema, _migrate_users_tenancy, ensure_database_ready
        _heal_schema()
        _migrate_users_tenancy()
        try:
            ensure_database_ready()
        except Exception as e:
            print(f"Bootstrap DB warning: {e}")
        try:
            from services.superadmin_service import SuperadminService
            SuperadminService.bootstrap_superadmin()
        except Exception as e:
            print(f"Superadmin bootstrap warning: {e}")

    # Login manager
    login_manager = LoginManager()
    login_manager.init_app(app)
    login_manager.login_view = 'auth.login'
    login_manager.login_message = 'Please log in to access this page.'
    login_manager.login_message_category = 'info'

    @login_manager.user_loader
    def load_user(user_id):
        from database.models.user import User
        try:
            return db.session.get(User, int(user_id))
        except (ValueError, TypeError):
            return None

    @app.before_request
    def enforce_tenant_context():
        """Ensure active database tables exist, enforce session revocation/status, and bind tenant context."""
        if not request.path.startswith('/static'):
            try:
                from database.models.company import Company
                if Company.query.first() is None:
                    from database.db import ensure_database_ready
                    ensure_database_ready()
            except Exception:
                from database.db import ensure_database_ready
                ensure_database_ready()

        if current_user and current_user.is_authenticated and not request.path.startswith('/static'):
            # 1. Enforce account active status & session version revocation
            acct_status = (getattr(current_user, 'account_status', None) or ('active' if current_user.is_active else 'deactivated')).lower()
            sess_ver = session.get('session_version')
            user_ver = getattr(current_user, 'session_version', 1) or 1

            if not current_user.is_active or acct_status in ('suspended', 'deactivated') or (sess_ver is not None and int(sess_ver) != int(user_ver)):
                session.clear()
                logout_user()
                flash('Your session has expired or been revoked by platform security. Please sign in again.', 'warning')
                return redirect(url_for('auth.login'))

            # 2. Enforce mandatory password change if flagged
            exempt_paths = {'/force-password-change', '/superadmin/force-password-change', '/superadmin/mfa-verify', '/logout'}
            if getattr(current_user, 'must_change_password', False) and request.path not in exempt_paths:
                if getattr(current_user, 'is_global_superadmin', False):
                    return redirect(url_for('superadmin.force_password_change'))
                return redirect(url_for('auth.force_user_password_change'))

            # 3. For Global Superadmin, do not force-bind a tenant company unless inspecting a tenant
            if getattr(current_user, 'is_global_superadmin', False):
                session.permanent = True
                if getattr(current_user, 'avatar_path', None):
                    session['user_avatar'] = current_user.avatar_path
                return None

            from security.tenant import get_current_company_id
            from database.models.company import Company
            from config.constants import CURRENCY_SYMBOLS
            session.permanent = True
            cid = get_current_company_id()
            if not cid and getattr(current_user, 'company_id', None):
                cid = current_user.company_id
                session['company_id'] = cid
            if not cid:
                first_comp = Company.query.first()
                if first_comp:
                    cid = first_comp.id
                    session['company_id'] = cid
                    if not getattr(current_user, 'company_id', None):
                        current_user.company_id = cid
                        try:
                            db.session.commit()
                        except Exception:
                            db.session.rollback()
            if cid:
                try:
                    comp = db.session.get(Company, cid)
                    if comp:
                        if comp.effective_status in ('suspended', 'archived') and request.path != '/logout':
                            session.clear()
                            logout_user()
                            flash(f"Your organization ({comp.company_name}) is currently {comp.effective_status}.", 'danger')
                            return redirect(url_for('auth.login'))
                        session['company_name'] = comp.company_name
                        session['company_currency'] = comp.currency or 'USD'
                        session['currency_symbol'] = CURRENCY_SYMBOLS.get(comp.currency or 'USD', '$')
                        session['company_timezone'] = comp.timezone or 'UTC'
                        if comp.logo_path:
                            session['company_logo'] = comp.logo_path
                        else:
                            session.pop('company_logo', None)
                except Exception:
                    pass
            if getattr(current_user, 'avatar_path', None):
                session['user_avatar'] = current_user.avatar_path
            else:
                session.pop('user_avatar', None)

    # ==================== GLOBAL CURRENCY FILTER & CONTEXT ====================
    from config.constants import CURRENCY_SYMBOLS

    @app.template_filter('format_currency')
    def format_currency_filter(value, currency_code=None):
        if value is None:
            return '-'
        try:
            value = float(value)
        except (TypeError, ValueError):
            return str(value)

        if currency_code is None:
            currency_code = session.get('company_currency', 'USD')

        symbol = CURRENCY_SYMBOLS.get(currency_code, '$')
        prefix = '-' if value < 0 else ''
        val_abs = abs(value)
        if val_abs >= 1000000000000:
            return f'{prefix}{symbol}{val_abs/1000000000000:.1f}T'
        elif val_abs >= 1000000000:
            return f'{prefix}{symbol}{val_abs/1000000000:.1f}B'
        elif val_abs >= 1000000:
            return f'{prefix}{symbol}{val_abs/1000000:.1f}M'
        elif val_abs >= 1000:
            return f'{prefix}{symbol}{val_abs:,.0f}'
        else:
            return f'{prefix}{symbol}{val_abs:,.2f}'

    @app.context_processor
    def inject_currency():
        from database.models.company import Company

        company_id = session.get('company_id')
        currency = session.get('company_currency')

        if currency is None and company_id:
            try:
                company = db.session.get(Company, company_id)
                if company and company.currency:
                    currency = company.currency
                    session['company_currency'] = currency
            except Exception:
                pass

        currency = currency or 'USD'
        symbol = CURRENCY_SYMBOLS.get(currency, '$')

        return {
            'company_currency': currency,
            'currency_symbol': symbol,
            'currency_name': currency
        }
    # =======================================================================

    # Register blueprints
    from routes.public import public_bp
    from routes.auth import auth_bp
    from routes.superadmin import superadmin_bp
    from routes.pulse_ai import pulse_ai_bp
    from routes.dashboard import dashboard_bp
    from routes.business_twin import business_twin_bp
    from routes.simulation import simulation_bp
    from routes.forecasting import forecasting_bp
    from routes.risk_engine import risk_engine_bp
    from routes.analytics import analytics_bp
    from routes.reports import reports_bp
    from routes.documents import documents_bp
    from routes.settings import settings_bp
    from routes.scenario_builder import scenario_bp
    from routes.market_intelligence import market_bp
    from routes.financial_modeling import financial_bp
    from routes.customer_simulator import customer_bp
    from routes.employee_simulator import employee_bp
    from routes.supply_chain_simulator import supply_chain_bp
    from routes.operations_simulator import operations_bp
    from routes.ai_insights import ai_insights_bp
    from routes.data_lake import data_lake_bp
    from routes.competition import competition_bp
    from routes.uploads import uploads_bp
    from routes.custom_twin import custom_twin_bp
    from routes.command_center import command_center_bp
    from routes.audit import audit_bp
    from routes.twin_graph import twin_graph_bp
    from routes.temporal import temporal_bp
    from routes.api_v1 import api_v1_bp
    from routes.jobs import jobs_bp
    from routes.health import health_bp
    from routes.twin_data_exchange import twin_data_exchange_bp

    app.register_blueprint(public_bp)
    app.register_blueprint(auth_bp)
    app.register_blueprint(superadmin_bp)
    app.register_blueprint(pulse_ai_bp)
    app.register_blueprint(dashboard_bp)
    app.register_blueprint(business_twin_bp, url_prefix='/business-twin')
    app.register_blueprint(simulation_bp, url_prefix='/simulation')
    app.register_blueprint(forecasting_bp, url_prefix='/forecasting')
    app.register_blueprint(risk_engine_bp, url_prefix='/risk')
    app.register_blueprint(analytics_bp, url_prefix='/analytics')
    app.register_blueprint(reports_bp, url_prefix='/reports')
    app.register_blueprint(documents_bp, url_prefix='/documents')
    app.register_blueprint(settings_bp, url_prefix='/settings')
    app.register_blueprint(scenario_bp, url_prefix='/scenario')
    app.register_blueprint(market_bp, url_prefix='/market')
    app.register_blueprint(financial_bp, url_prefix='/financial')
    app.register_blueprint(customer_bp, url_prefix='/customer')
    app.register_blueprint(employee_bp, url_prefix='/employee')
    app.register_blueprint(supply_chain_bp, url_prefix='/supply-chain')
    app.register_blueprint(operations_bp, url_prefix='/operations')
    app.register_blueprint(ai_insights_bp, url_prefix='/ai-insights')
    app.register_blueprint(data_lake_bp, url_prefix='/data-lake')
    app.register_blueprint(competition_bp, url_prefix='/competition')
    app.register_blueprint(custom_twin_bp, url_prefix='/business-twin')
    app.register_blueprint(command_center_bp, url_prefix='/command-center')
    app.register_blueprint(uploads_bp, url_prefix='/uploads')
    app.register_blueprint(audit_bp, url_prefix='/audit')
    app.register_blueprint(twin_graph_bp, url_prefix='/twin-graph')
    app.register_blueprint(temporal_bp, url_prefix='/temporal')
    app.register_blueprint(twin_data_exchange_bp)
    app.register_blueprint(api_v1_bp, url_prefix='/api/v1')
    csrf.exempt(api_v1_bp)
    app.register_blueprint(jobs_bp)
    app.register_blueprint(health_bp)
    csrf.exempt(health_bp)
    from routes.settings import update_theme, upload_avatar, upload_logo
    csrf.exempt(update_theme)
    csrf.exempt(upload_avatar)
    csrf.exempt(upload_logo)
    from routes.business_twin import edit_revenue, delete_revenue, add_revenue
    csrf.exempt(edit_revenue)
    csrf.exempt(delete_revenue)
    csrf.exempt(add_revenue)

    # Initialize Digital Twin Impact Propagation Listener, Risk Engine Listener, Webhook Dispatcher & Job Worker Pool
    from services.events import EventBus
    from services.impact_engine import ImpactEngine
    from services.risk_service import RiskService
    from services.webhook_service import WebhookService
    from services.job_service import JobService
    EventBus.subscribe('*', ImpactEngine.on_domain_event)
    EventBus.subscribe('*', RiskService.on_domain_event)
    EventBus.subscribe('*', WebhookService.on_domain_event)
    JobService.init_app(app)

    # Context processors
    @app.context_processor
    def inject_globals():
        from config.themes import THEMES, resolve_theme_id
        from config.country_data import render_country_flag
        default_theme_id = app.config.get('DEFAULT_THEME', 'white_clay_glass')
        raw_theme_id = request.cookies.get('aevoryn_theme') or session.get('theme', default_theme_id)
        theme_id = resolve_theme_id(raw_theme_id)
        theme = dict(THEMES.get(theme_id, THEMES['white_clay_glass']))

        theme['color_scheme'] = theme.get('color_scheme', 'light' if 'white' in theme_id else 'dark')

        hexc = (theme.get('accent_primary') or '#2563EB').lstrip('#')
        try:
            rgb = tuple(int(hexc[i:i+2], 16) for i in (0, 2, 4))
            theme['accent_primary_rgb'] = f"{rgb[0]}, {rgb[1]}, {rgb[2]}"
        except Exception:
            theme['accent_primary_rgb'] = '37, 99, 235'

        active_company = None
        company_logo_url = None
        user_avatar_url = None
        if current_user and current_user.is_authenticated:
            try:
                from database.models.company import Company
                cid = session.get('company_id') or getattr(current_user, 'company_id', None)
                if cid:
                    active_company = db.session.get(Company, int(cid))
                if not active_company:
                    active_company = Company.query.first()
                if active_company:
                    company_logo_url = active_company.logo_url
                user_avatar_url = getattr(current_user, 'avatar_url', None)
            except Exception:
                pass

        return {
            'app_name': app.config.get('APP_NAME', 'AEVORYN'),
            'app_tagline': app.config.get('APP_TAGLINE', 'Enterprise Digital Twin & Decision Intelligence'),
            'app_version': app.config.get('APP_VERSION', '2.5.0'),
            'current_year': datetime.now().year,
            'theme': theme,
            'theme_id': theme_id,
            'all_themes': THEMES,
            'company': active_company,
            'company_logo_url': company_logo_url,
            'user_avatar_url': user_avatar_url,
            'user_avatar': getattr(current_user, 'avatar_path', None) or session.get('user_avatar'),
            'render_country_flag': render_country_flag
        }

    @app.after_request
    def sync_theme_cookie(response):
        raw_theme = request.cookies.get('aevoryn_theme') or session.get('theme')
        if raw_theme and request.cookies.get('aevoryn_theme') != raw_theme:
            response.set_cookie('aevoryn_theme', raw_theme, max_age=31536000, path='/', samesite='Lax')

        if not request.path.startswith('/static') and not request.path.startswith('/uploads/media'):
            if (current_user and current_user.is_authenticated) or request.path == '/logout':
                response.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private, max-age=0'
                response.headers['Pragma'] = 'no-cache'
                response.headers['Expires'] = '0'
        return response

    @app.route('/api/v1/realtime/state')
    @login_required
    def realtime_state_sync():
        """Real-time application-wide synchronization state endpoint backed by live database records."""
        from database.models.company import Company
        from database.models.department import Department
        from database.models.employee import Employee
        from database.models.project import Project
        from database.models.notification import Notification
        from security.tenant import get_current_company_id

        cid = get_current_company_id() or getattr(current_user, 'company_id', None)
        comp = db.session.get(Company, cid) if cid else Company.query.first()
        if not comp:
            return jsonify({'success': False, 'error': 'No active organization'}), 404

        depts = Department.query.filter_by(company_id=comp.id, is_active=True).all()
        emp_count = Employee.query.filter_by(company_id=comp.id).count()
        active_projects = Project.query.filter_by(company_id=comp.id).count()
        unread_notifs = Notification.query.filter_by(company_id=comp.id, user_id=current_user.id, is_read=False).order_by(Notification.created_at.desc()).limit(5).all()

        return jsonify({
            'success': True,
            'timestamp': datetime.utcnow().isoformat() + 'Z',
            'company': {
                'id': comp.id,
                'name': comp.company_name,
                'industry': comp.industry,
                'currency': comp.currency,
                'currency_symbol': CURRENCY_SYMBOLS.get(comp.currency or 'USD', '$'),
                'timezone': comp.timezone or 'UTC',
                'logo_url': comp.logo_url,
                'health_score': float(comp.health_score or 0.0),
                'annual_revenue': float(comp.annual_revenue or 0.0)
            },
            'user': {
                'id': current_user.id,
                'username': current_user.username,
                'role': current_user.role,
                'avatar_url': current_user.avatar_url
            },
            'metrics': {
                'department_count': len(depts),
                'total_department_budget': sum(float(d.budget or 0.0) for d in depts),
                'employee_count': emp_count,
                'active_projects': active_projects
            },
            'notifications': [
                {
                    'id': n.id,
                    'title': n.title,
                    'message': n.message,
                    'type': n.notification_type,
                    'created_at': n.created_at.isoformat() if n.created_at else None
                }
                for n in unread_notifs
            ]
        })

    # Error handlers
    @app.errorhandler(403)
    def forbidden_error(error):
        if request.is_json or request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'error': 'Forbidden: Insufficient permissions'}), 403
        return render_template('base.html', error='403 Forbidden — You do not have permission to access this control plane.'), 403

    @app.errorhandler(404)
    def not_found(error):
        return render_template('base.html', error='Page not found'), 404

    @app.errorhandler(500)
    def internal_error(error):
        db.session.rollback()
        return render_template('base.html', error='Internal server error'), 500

    @app.errorhandler(CSRFError)
    def handle_csrf_error(e):
        if request.is_json or request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({
                'success': False,
                'error': 'CSRF Error',
                'message': f'CSRF validation failed: {e.description}'
            }), 400
        flash('Security validation failed (CSRF token missing or expired). Please try again.', 'danger')
        return redirect(request.referrer or url_for('auth.login')), 400

    # Health check
    @app.route('/health')
    def health():
        return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})

    return app


app = create_app()

if __name__ == '__main__':
    use_reloader = os.environ.get('FLASK_USE_RELOADER', '0') == '1'
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True, use_reloader=use_reloader)