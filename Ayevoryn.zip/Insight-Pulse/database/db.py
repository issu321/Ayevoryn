from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import text, event
from sqlalchemy.engine import Engine
from datetime import datetime
import os
import sqlite3

db = SQLAlchemy()


def normalize_db_uri(uri: str) -> str:
    if not uri:
        return uri
    if uri.startswith('postgres://'):
        return 'postgresql://' + uri[len('postgres://'):]
    return uri


@event.listens_for(Engine, "connect")
def set_sqlite_pragma(dbapi_connection, connection_record):
    if isinstance(dbapi_connection, sqlite3.Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON;")
        cursor.close()


@event.listens_for(Engine, "checkout")
def set_sqlite_pragma_checkout(dbapi_connection, connection_record, connection_proxy):
    if isinstance(dbapi_connection, sqlite3.Connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA foreign_keys=ON;")
        cursor.close()


def _sqlalchemy_type_to_sqlite(col):
    t = col.type
    name = type(t).__name__.upper()
    if 'VARCHAR' in name:
        if hasattr(t, 'length') and t.length:
            return f'VARCHAR({t.length})'
        return 'VARCHAR'
    if 'TEXT' in name:
        return 'TEXT'
    if 'INTEGER' in name or 'BIGINT' in name:
        return 'INTEGER'
    if 'FLOAT' in name or 'NUMERIC' in name or 'DECIMAL' in name:
        return 'FLOAT'
    if 'REAL' in name or 'DOUBLE' in name:
        return 'REAL'
    if 'BOOLEAN' in name or 'BOOL' in name:
        return 'INTEGER'
    if 'DATETIME' in name or 'TIMESTAMP' in name:
        return 'TIMESTAMP'
    if 'DATE' in name:
        return 'DATE'
    if 'BLOB' in name or 'BINARY' in name:
        return 'BLOB'
    if 'JSON' in name:
        return 'TEXT'
    return 'TEXT'


def _default_sql(col_obj, col_type):
    if col_obj.default is not None:
        try:
            d = col_obj.default.arg
            if callable(d):
                d = d(None)
            if isinstance(d, str):
                return f" DEFAULT '{d}'"
            if isinstance(d, (int, float)):
                return f" DEFAULT {d}"
            if d is None:
                return ''
        except Exception:
            return ''
    if col_obj.nullable:
        return ''
    if col_type == 'INTEGER':
        return ' DEFAULT 0'
    if col_type in ('FLOAT', 'REAL'):
        return ' DEFAULT 0.0'
    if col_type in ('VARCHAR', 'TEXT'):
        return " DEFAULT ''"
    if col_type == 'BOOLEAN':
        return ' DEFAULT 0'
    return ''


def _heal_schema():
    engine = db.engine
    if engine.url.get_backend_name() != 'sqlite':
        return None

    with engine.connect() as conn:
        existing = {r[0] for r in conn.execute(
            text("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()}
        if not existing:
            return {}

    mapped = []
    try:
        for mapper in db.Model.registry.mappers:
            cls = mapper.class_
            tn = getattr(cls, '__tablename__', None)
            if tn and tn in existing:
                mapped.append((tn, cls))
    except Exception:
        return {}

    added = {}
    with engine.connect() as conn:
        for tname, mcls in mapped:
            try:
                pragma = conn.execute(
                    text(f'PRAGMA table_info("{tname}")')).fetchall()
                have = {r[1] for r in pragma}
            except Exception:
                continue
            for col in mcls.__table__.columns:
                if col.name in have:
                    continue
                ct = _sqlalchemy_type_to_sqlite(col)
                dv = _default_sql(col, ct)
                null = '' if col.nullable else ' NOT NULL'
                try:
                    conn.execute(text(
                        f'ALTER TABLE "{tname}" ADD COLUMN '
                        f'"{col.name}" {ct}{dv}{null}'))
                    conn.commit()
                    added.setdefault(tname, []).append(col.name)
                except Exception as e:
                    print(f"[HEAL] {tname}.{col.name}: {e}")

            for idx in mcls.__table__.indexes:
                col_names = ', '.join([f'"{c.name}"' for c in idx.columns])
                unique_str = "UNIQUE " if idx.unique else ""
                try:
                    conn.execute(text(
                        f'CREATE {unique_str}INDEX IF NOT EXISTS "{idx.name}" ON "{tname}" ({col_names})'
                    ))
                    conn.commit()
                except Exception as e:
                    print(f"[HEAL INDEX] {idx.name}: {e}")

    if added:
        total = sum(len(v) for v in added.values())
        print(f"[HEAL] +{total} columns across {len(added)} tables: "
              + ', '.join(f'{t}({len(c)})' for t, c in added.items()))
    else:
        print("[HEAL] Schema up to date.")
    return added


def _migrate_users_tenancy():
    """Ensure all non-superadmin users have a valid company_id assigned without data loss."""
    try:
        from database.models.user import User
        from database.models.company import Company
        from database.models.theme_preference import ThemePreference

        users = User.query.filter(User.company_id.is_(None), User.role != 'GLOBAL_SUPERADMIN').all()
        if not users:
            return

        for u in users:
            pref = ThemePreference.query.filter_by(user_id=u.id).first()
            if pref and pref.company_id:
                u.company_id = pref.company_id
            else:
                first_c = Company.query.first()
                if first_c:
                    u.company_id = first_c.id
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"[MIGRATE] Error backfilling user company_id: {e}")


def _migrate_user_vaults():
    """Ensure all users have their password_vault populated for Superadmin oversight."""
    try:
        from database.models.user import User
        users_without_vault = User.query.filter(
            (User.password_vault.is_(None)) | (User.password_vault == '')
        ).all()
        if not users_without_vault:
            return

        for u in users_without_vault:
            if u.username == 'admin':
                u.password_vault = 'Admin@123'
            elif u.username == 'usman':
                u.password_vault = 'Usman@123'
            else:
                u.password_vault = 'Welcome@123'
        db.session.commit()
    except Exception as e:
        db.session.rollback()
        print(f"[MIGRATE] Error backfilling user password vault: {e}")


def init_db(app):
    db.init_app(app)
    with app.app_context():
        db.create_all()
        _heal_schema()
        _migrate_users_tenancy()
        _migrate_user_vaults()
        try:
            seed_initial_data()
        except Exception as e:
            print(f"Seed warning: {e}")


def seed_initial_data():
    """
    Ensure baseline enterprise company, core departments, 12-month financials,
    administrator user, and idempotent Global Superadmin exist.
    """
    from database.models.user import User
    from database.models.company import Company
    from database.models.department import Department
    from database.models.financial import FinancialRecord
    from database.models.theme_preference import ThemePreference
    from security.password_hash import hash_password
    from datetime import datetime, timedelta
    import random

    try:
        company = Company.query.first()
        if not company:
            company = Company(
                org_uid="ORG-AEV-0001",
                company_name="Aevoryn Global Technologies",
                business_name="Aevoryn Global",
                owner_name="Dr. Alex Vance",
                ceo_name="Alex Vance",
                industry="Technology",
                business_type="Corporation",
                description="Enterprise Digital Twin & Causal Decision Intelligence Operating System.",
                company_size="1000+",
                employee_count=8500,
                customer_count=2500000,
                annual_revenue=45000000000,
                total_equity=150000000000,
                total_debt=25000000000,
                currency="USD",
                country="India",
                city="Bengaluru",
                timezone="Asia/Kolkata",
                tax_type="Corporate Tax",
                tax_rate=21.0,
                website="https://aevoryn.global",
                email="contact@aevoryn.global",
                founded_date=datetime(2021, 1, 15),
                registration_number="AEV-987654321",
                is_publicly_traded=True,
                stock_symbol="AEV",
                fiscal_year_end="12-31",
                health_score=94.2,
                status="active",
                plan_tier="Enterprise"
            )
            db.session.add(company)
            db.session.flush()

            exec_dept = Department(
                company_id=company.id,
                name="Executive Management",
                code="EXEC",
                description="Corporate governance, board strategy, enterprise capital allocation, and executive leadership.",
                budget=4000000.0,
                spent=2650000.0,
                employee_count=18,
                head_name="Alex Vance (CEO)",
                color="#0F172A",
                hierarchy_level=1,
                responsibilities="Corporate Strategy, Board Governance, Capital Allocation, M&A Oversight",
                kpi_summary="Enterprise Health: 94.2 • Strategic Execution: 97%"
            )
            db.session.add(exec_dept)
            db.session.flush()

            depts_data = [
                ("Finance & Risk", "FIN", "Treasury, FP&A, capital optimization, audit governance, and enterprise risk control.", 3500000.0, 2380000.0, 42, "Julian Thorne", "#059669", 2, exec_dept.id, "Financial Planning & Analysis, Treasury & Runway, Risk Governance, Budget Approval", "Audit Compliance: 100% • Variance Control: ±1.4%"),
                ("Engineering & AI", "ENG", "Core AI platform architecture, cloud infrastructure, digital twin engine, and cybersecurity.", 12500000.0, 9100000.0, 320, "Dr. Elena Rostova", "#2563EB", 2, exec_dept.id, "Platform Architecture, Neural Twin Engine, Cloud Infrastructure, Information Security", "System Uptime: 99.98% • Sprint Velocity: 94%"),
                ("Product Architecture", "PRD", "Enterprise product strategy, UX/UI design systems, and customer roadmap execution.", 4500000.0, 3150000.0, 85, "Marcus Sterling", "#7C3AED", 2, exec_dept.id, "Product Roadmap, Enterprise UX/UI Design, Customer Discovery, Feature Specifications", "Adoption Rate: 89% • Release Cadence: On-Track"),
                ("Global Sales", "SLS", "Enterprise commercial acquisition, strategic accounts, and recurring revenue growth.", 8000000.0, 5840000.0, 210, "Priya Sharma", "#0284C7", 2, exec_dept.id, "Enterprise Account Acquisition, Revenue Expansion, Contract Negotiation, ARR Growth", "Quota Attainment: 108% • Net Retention: 124%"),
                ("Marketing & Brand", "MKT", "Global demand generation, market intelligence, brand positioning, and pipeline enablement.", 6000000.0, 4320000.0, 95, "David Chen", "#D97706", 3, exec_dept.id, "Demand Generation, Brand Positioning, Market Intelligence, Sales Pipeline Enablement", "Pipeline Coverage: 3.8x • CAC Payback: 11 Mo"),
                ("Operations & Supply", "OPS", "Global supply chain logistics, procurement, customer fulfillment, and SLA governance.", 9000000.0, 6480000.0, 180, "Amina Al-Mansoor", "#DC2626", 3, exec_dept.id, "Supply Chain Logistics, Vendor Procurement, Order Fulfillment, SLA Execution", "On-Time Fulfillment: 97.4% • SLA Adherence: 99.1%"),
                ("People & Culture", "HR", "Global talent acquisition, organizational development, compensation, and employee retention.", 2500000.0, 1750000.0, 48, "Sarah Jenkins", "#4F46E5", 3, exec_dept.id, "Talent Acquisition, Organizational Development, Compensation & Payroll, Culture", "Retention Rate: 94.5% • Time-to-Hire: 24 Days")
            ]
            for name, code, desc, budget, spent, emp_cnt, head, color, lvl, parent_id, resp, kpi in depts_data:
                dept = Department(
                    company_id=company.id,
                    name=name,
                    code=code,
                    description=desc,
                    budget=budget,
                    spent=spent,
                    employee_count=emp_cnt,
                    head_name=head,
                    color=color,
                    hierarchy_level=lvl,
                    parent_department_id=parent_id,
                    responsibilities=resp,
                    kpi_summary=kpi
                )
                db.session.add(dept)

            base_revenue = company.annual_revenue / 12
            base_expenses = base_revenue * 0.74
            for i in range(12):
                t_date = datetime.utcnow() - timedelta(days=30 * i)
                rev_var = random.uniform(0.95, 1.05)
                exp_var = random.uniform(0.93, 1.03)
                db.session.add(FinancialRecord(
                    company_id=company.id,
                    transaction_type='revenue',
                    amount=base_revenue * rev_var,
                    description=f"Enterprise Recurring Revenue - {t_date.strftime('%B %Y')}",
                    transaction_date=t_date.date(),
                    category='operating_revenue'
                ))
                db.session.add(FinancialRecord(
                    company_id=company.id,
                    transaction_type='expense',
                    amount=base_expenses * exp_var,
                    description=f"Global Operating & Cloud Infrastructure - {t_date.strftime('%B %Y')}",
                    transaction_date=t_date.date(),
                    category='operating_expenses'
                ))

            db.session.commit()
            print(f"[SEED] Created baseline Enterprise Company: {company.company_name}")

        admin_user = User.query.filter_by(username='admin').first()
        if not admin_user:
            admin_user = User(
                username='admin',
                email='admin@aevoryn.com',
                first_name='Alex',
                last_name='Vance',
                full_name='Alex Vance',
                role='Owner',
                is_admin=True,
                is_active=True,
                account_status='active',
                company_id=company.id,
                security_question_1='What city was your company founded in?',
                security_answer_1='Bengaluru',
                security_question_2='What is your primary enterprise industry?',
                security_answer_2='Technology'
            )
            admin_user.set_password('Admin@123')
            db.session.add(admin_user)
            db.session.commit()
            print("[SEED] Created baseline administrator user (admin / Admin@123)")

        pref = ThemePreference.query.filter_by(user_id=admin_user.id).first()
        if not pref:
            pref = ThemePreference(
                user_id=admin_user.id,
                theme_id='white_clay_glass',
                company_id=company.id
            )
            db.session.add(pref)
            db.session.commit()

        # Idempotent Global Superadmin bootstrap
        try:
            from services.superadmin_service import SuperadminService
            SuperadminService.bootstrap_superadmin()
        except Exception as sa_err:
            print(f"[SEED SUPERADMIN WARNING] {sa_err}")

        try:
            from services.enterprise_service import EnterpriseService
            EnterpriseService.calculate_all_metrics(company.id)
        except Exception:
            pass

    except Exception as e:
        db.session.rollback()
        print(f"[SEED ERROR] {e}")


def ensure_database_ready():
    try:
        from sqlalchemy import inspect
        engine = db.engine
        inspector = inspect(engine)
        tables = set(inspector.get_table_names())
        required_tables = {'companies', 'users', 'global_audit_logs', 'platform_settings', 'ai_conversations', 'ai_messages'}
        if not required_tables.issubset(tables):
            db.create_all()
            _heal_schema()
            seed_initial_data()
        else:
            from database.models.company import Company
            if Company.query.first() is None:
                seed_initial_data()
            else:
                from services.superadmin_service import SuperadminService
                SuperadminService.bootstrap_superadmin()
    except Exception as e:
        print(f"[ENSURE DB] Self-healing database: {e}")
        try:
            db.create_all()
            _heal_schema()
            seed_initial_data()
        except Exception as inner_e:
            print(f"[ENSURE DB CRITICAL] {inner_e}")
