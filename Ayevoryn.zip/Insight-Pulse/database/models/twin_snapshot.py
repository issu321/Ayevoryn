"""
AEVORYN / INSIGHT-PULSE
TWIN SNAPSHOT MODEL (STAGE 13)
Stores immutable point-in-time digital twin state captures, supporting
historical reconstruction, milestone freezing, and temporal variance diffs.
"""

import json
import uuid
from datetime import datetime
from database.db import db


class SnapshotType:
    MANUAL = 'MANUAL'
    SCHEDULED = 'SCHEDULED'
    MILESTONE = 'MILESTONE'
    CLOSE = 'CLOSE'
    SIMULATED = 'SIMULATED'

    ALL = [MANUAL, SCHEDULED, MILESTONE, CLOSE, SIMULATED]


class TwinSnapshot(db.Model):
    """Represents a frozen point-in-time state capture of the digital twin."""
    __tablename__ = 'twin_snapshots'

    id = db.Column(db.Integer, primary_key=True)
    snapshot_id = db.Column(db.String(36), default=lambda: str(uuid.uuid4()), unique=True, nullable=False, index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)

    name = db.Column(db.String(200), nullable=False)
    snapshot_type = db.Column(db.String(50), default=SnapshotType.MANUAL, nullable=False)
    as_of_timestamp = db.Column(db.DateTime, nullable=False, index=True)
    description = db.Column(db.Text, nullable=True)

    # Creator user reference
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    creator_name = db.Column(db.String(100), nullable=True)

    # State payloads serialized as JSON
    metrics_payload_json = db.Column(db.Text, default='{}', nullable=False)
    entity_counts_json = db.Column(db.Text, default='{}', nullable=False)
    graph_topology_json = db.Column(db.Text, default='{}', nullable=False)

    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    __table_args__ = (
        db.Index('idx_twin_snapshot_company_as_of', 'company_id', 'as_of_timestamp'),
        db.Index('idx_twin_snapshot_company_created', 'company_id', 'created_at'),
    )

    def get_metrics(self) -> dict:
        """Parse metrics JSON safely."""
        try:
            return json.loads(self.metrics_payload_json) if self.metrics_payload_json else {}
        except Exception:
            return {}

    def set_metrics(self, metrics: dict):
        """Serialize metrics dictionary to JSON."""
        self.metrics_payload_json = json.dumps(metrics) if metrics else '{}'

    def get_entity_counts(self) -> dict:
        """Parse entity counts JSON safely."""
        try:
            return json.loads(self.entity_counts_json) if self.entity_counts_json else {}
        except Exception:
            return {}

    def set_entity_counts(self, counts: dict):
        """Serialize entity counts dictionary to JSON."""
        self.entity_counts_json = json.dumps(counts) if counts else '{}'

    def get_graph_topology(self) -> dict:
        """Parse graph topology JSON safely."""
        try:
            return json.loads(self.graph_topology_json) if self.graph_topology_json else {}
        except Exception:
            return {}

    def set_graph_topology(self, topology: dict):
        """Serialize graph topology dictionary to JSON."""
        self.graph_topology_json = json.dumps(topology) if topology else '{}'

    def to_dict(self) -> dict:
        """Serialize twin snapshot to a standard dictionary."""
        return {
            'id': self.id,
            'snapshot_id': self.snapshot_id,
            'company_id': self.company_id,
            'name': self.name,
            'snapshot_type': self.snapshot_type,
            'as_of_timestamp': self.as_of_timestamp.isoformat() if self.as_of_timestamp else None,
            'description': self.description or '',
            'created_by': self.created_by,
            'creator_name': self.creator_name or 'System',
            'metrics': self.get_metrics(),
            'entity_counts': self.get_entity_counts(),
            'graph_topology': self.get_graph_topology(),
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
