from database.db import db
from datetime import datetime
import json
import uuid


class AIConversation(db.Model):
    """Persistent, multi-tenant isolated conversation thread for Pulse AI."""
    __tablename__ = 'ai_conversations'

    id = db.Column(db.Integer, primary_key=True)
    conversation_uid = db.Column(db.String(64), unique=True, index=True, default=lambda: f"CONV-{uuid.uuid4().hex[:12].upper()}")
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    title = db.Column(db.String(200), default='New Executive Briefing')
    summary = db.Column(db.Text, nullable=True)
    is_pinned = db.Column(db.Boolean, default=False)
    is_archived = db.Column(db.Boolean, default=False)
    model_provider = db.Column(db.String(50), default='ayevoryn_analytical')
    model_name = db.Column(db.String(80), default='pulse-intelligence-v2')
    message_count = db.Column(db.Integer, default=0)
    total_tokens = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, index=True)

    messages = db.relationship('AIMessage', backref='conversation', lazy='dynamic', cascade='all, delete-orphan')

    def to_dict(self):
        return {
            'id': self.id,
            'conversation_uid': self.conversation_uid,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'title': self.title,
            'summary': self.summary,
            'is_pinned': self.is_pinned,
            'is_archived': self.is_archived,
            'model_provider': self.model_provider,
            'model_name': self.model_name,
            'message_count': self.message_count,
            'total_tokens': self.total_tokens,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }


class AIMessage(db.Model):
    """Individual message within a multi-tenant Pulse AI conversation."""
    __tablename__ = 'ai_messages'

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey('ai_conversations.id'), nullable=False, index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    role = db.Column(db.String(20), nullable=False)  # user, assistant, system, tool
    content = db.Column(db.Text, nullable=False)
    structured_data = db.Column(db.Text, nullable=True)  # JSON dict of tables, metrics, risks, next_steps, provenance
    tool_calls = db.Column(db.Text, nullable=True)       # JSON list of invoked tools
    tokens_used = db.Column(db.Integer, default=0)
    latency_ms = db.Column(db.Float, default=0.0)
    feedback_rating = db.Column(db.String(16), nullable=True)  # up, down
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    def get_structured(self) -> dict:
        if not self.structured_data:
            return {}
        try:
            return json.loads(self.structured_data)
        except Exception:
            return {}

    def get_tools(self) -> list:
        if not self.tool_calls:
            return []
        try:
            return json.loads(self.tool_calls)
        except Exception:
            return []

    def to_dict(self):
        return {
            'id': self.id,
            'conversation_id': self.conversation_id,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'role': self.role,
            'content': self.content,
            'structured_data': self.get_structured(),
            'tool_calls': self.get_tools(),
            'tokens_used': self.tokens_used,
            'latency_ms': self.latency_ms,
            'feedback_rating': self.feedback_rating,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class AIToolExecution(db.Model):
    """
    Audit & confirmation record for Pulse AI tool invocations.
    Mutating operations stay in 'pending_confirmation' until the authenticated user explicitly confirms.
    """
    __tablename__ = 'ai_tool_executions'

    id = db.Column(db.Integer, primary_key=True)
    execution_uid = db.Column(db.String(64), unique=True, index=True, default=lambda: f"EXEC-{uuid.uuid4().hex[:10].upper()}")
    conversation_id = db.Column(db.Integer, db.ForeignKey('ai_conversations.id'), nullable=True, index=True)
    message_id = db.Column(db.Integer, db.ForeignKey('ai_messages.id'), nullable=True, index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    tool_name = db.Column(db.String(80), nullable=False, index=True)
    tool_category = db.Column(db.String(40), default='analysis')  # read, analysis, simulation, mutation
    requires_confirmation = db.Column(db.Boolean, default=False)
    status = db.Column(db.String(32), default='completed', index=True)  # completed, pending_confirmation, confirmed_executed, cancelled, failed
    input_params = db.Column(db.Text, nullable=True)
    affected_records = db.Column(db.Text, nullable=True)
    proposed_changes = db.Column(db.Text, nullable=True)
    output_result = db.Column(db.Text, nullable=True)
    confirmed_by_user_id = db.Column(db.Integer, nullable=True)
    confirmed_at = db.Column(db.DateTime, nullable=True)
    executed_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    def _parse_json(self, raw):
        if not raw:
            return {}
        try:
            return json.loads(raw)
        except Exception:
            return {'raw': raw}

    def to_dict(self):
        return {
            'id': self.id,
            'execution_uid': self.execution_uid,
            'conversation_id': self.conversation_id,
            'message_id': self.message_id,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'tool_name': self.tool_name,
            'tool_category': self.tool_category,
            'requires_confirmation': self.requires_confirmation,
            'status': self.status,
            'input_params': self._parse_json(self.input_params),
            'affected_records': self._parse_json(self.affected_records),
            'proposed_changes': self._parse_json(self.proposed_changes),
            'output_result': self._parse_json(self.output_result),
            'confirmed_at': self.confirmed_at.isoformat() if self.confirmed_at else None,
            'executed_at': self.executed_at.isoformat() if self.executed_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


class AIUsageLog(db.Model):
    """Tracks token consumption, latency, and provider reliability per tenant."""
    __tablename__ = 'ai_usage_logs'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, nullable=False, index=True)
    user_id = db.Column(db.Integer, nullable=False, index=True)
    conversation_id = db.Column(db.Integer, nullable=True, index=True)
    provider = db.Column(db.String(50), nullable=False)
    model_name = db.Column(db.String(80), nullable=False)
    prompt_tokens = db.Column(db.Integer, default=0)
    completion_tokens = db.Column(db.Integer, default=0)
    total_tokens = db.Column(db.Integer, default=0)
    latency_ms = db.Column(db.Float, default=0.0)
    status = db.Column(db.String(30), default='success')
    error_message = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
