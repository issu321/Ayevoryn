"""
AEVORYN / INSIGHT-PULSE
TWIN DEPENDENCY MODEL
Represents topological dependency edges across the enterprise digital twin.
Supports DIRECT, DERIVED, CONFIGURED, and ESTIMATED dependency classifications.
"""

from database.db import db
from datetime import datetime
import json


class DependencyType:
    DIRECT = 'DIRECT'          # Hard relational/foreign key link (e.g. employee -> department)
    DERIVED = 'DERIVED'        # Formulaic/mathematical derivation (e.g. expenses -> runway)
    CONFIGURED = 'CONFIGURED'  # User/admin specified operational link (e.g. vendor -> custom twin)
    ESTIMATED = 'ESTIMATED'    # Statistical elasticity / empirical correlation

    ALL = [DIRECT, DERIVED, CONFIGURED, ESTIMATED]


class TwinDependency(db.Model):
    """Represents a directional dependency edge from source (prerequisite) to target (dependent)."""
    __tablename__ = 'twin_dependencies'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    
    # Source entity (Independent / Influencer / Prerequisite)
    source_type = db.Column(db.String(50), nullable=False)   # department, employee, supplier, customer, inventory, financial, custom_twin, custom_record, metric
    source_id = db.Column(db.String(100), nullable=False)     # String identifier (e.g. '1', 'dept_tech', 'cash_runway')
    
    # Target entity (Dependent / Influenced / Outcome)
    target_type = db.Column(db.String(50), nullable=False)
    target_id = db.Column(db.String(100), nullable=False)
    
    # Classification & Influence
    dependency_type = db.Column(db.String(20), default=DependencyType.CONFIGURED, nullable=False)
    strength = db.Column(db.Float, default=1.0)              # Influence factor or elasticity (0.0 to 1.0)
    
    # Context & Provenance
    description = db.Column(db.String(255), nullable=True)
    metadata_json = db.Column(db.Text, default='{}')
    is_active = db.Column(db.Boolean, default=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    created_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    
    __table_args__ = (
        db.Index('idx_twin_dep_source', 'company_id', 'source_type', 'source_id'),
        db.Index('idx_twin_dep_target', 'company_id', 'target_type', 'target_id'),
        db.Index('idx_twin_dep_type', 'company_id', 'dependency_type'),
    )
    
    def get_metadata(self):
        """Parse metadata JSON safely."""
        try:
            return json.loads(self.metadata_json) if self.metadata_json else {}
        except Exception:
            return {}
            
    def set_metadata(self, data):
        """Serialize metadata dict to JSON."""
        self.metadata_json = json.dumps(data) if data else '{}'
        
    @property
    def source_node_id(self):
        """Canonical global node key for source."""
        return f"{self.source_type}:{self.source_id}"
        
    @property
    def target_node_id(self):
        """Canonical global node key for target."""
        return f"{self.target_type}:{self.target_id}"
        
    def to_dict(self):
        """Serialize dependency edge to dictionary."""
        return {
            'id': self.id,
            'company_id': self.company_id,
            'source_type': self.source_type,
            'source_id': self.source_id,
            'source_node_id': self.source_node_id,
            'target_type': self.target_type,
            'target_id': self.target_id,
            'target_node_id': self.target_node_id,
            'dependency_type': self.dependency_type,
            'strength': float(self.strength) if self.strength is not None else 1.0,
            'description': self.description or '',
            'metadata': self.get_metadata(),
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'created_by': self.created_by
        }
