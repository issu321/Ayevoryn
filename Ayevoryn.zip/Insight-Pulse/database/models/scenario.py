from database.db import db
from datetime import datetime
import json

class ScenarioStatus:
    DRAFT = 'DRAFT'
    EVALUATED = 'EVALUATED'
    MERGED = 'MERGED'
    ARCHIVED = 'ARCHIVED'
    
    ALL = [DRAFT, EVALUATED, MERGED, ARCHIVED]

class BranchType:
    BASELINE = 'BASELINE'
    SANDBOX = 'SANDBOX'
    GROWTH = 'GROWTH'
    DOWNTURN = 'DOWNTURN'
    REORGANIZATION = 'REORGANIZATION'
    STRATEGIC = 'STRATEGIC'
    CAPITAL_PROJECT = 'CAPITAL_PROJECT'
    
    ALL = [BASELINE, SANDBOX, GROWTH, DOWNTURN, REORGANIZATION, STRATEGIC, CAPITAL_PROJECT]

class Scenario(db.Model):
    __tablename__ = 'scenarios'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    parent_scenario_id = db.Column(db.Integer, db.ForeignKey('scenarios.id'), nullable=True, index=True)
    baseline_snapshot_id = db.Column(db.String(36), db.ForeignKey('twin_snapshots.snapshot_id'), nullable=True, index=True)
    name = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    scenario_type = db.Column(db.String(50), default='Strategic')
    branch_type = db.Column(db.String(50), default=BranchType.SANDBOX, nullable=False)
    status = db.Column(db.String(30), default=ScenarioStatus.DRAFT, nullable=False)
    is_active = db.Column(db.Boolean, default=True)
    base_parameters = db.Column(db.Text)
    sandbox_delta_payload_json = db.Column(db.Text, nullable=True)
    simulation_results_json = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Self-referential branch lineage
    parent = db.relationship('Scenario', remote_side=[id], backref=db.backref('children', lazy='dynamic'))
    baseline_snapshot = db.relationship('TwinSnapshot', backref=db.backref('scenarios', lazy='dynamic'))
    steps = db.relationship('ScenarioStep', backref='scenario', lazy='dynamic', cascade='all, delete-orphan')
    
    def get_parameters(self):
        if not self.base_parameters:
            return {}
        try:
            return json.loads(self.base_parameters)
        except Exception:
            return {}
    
    def set_parameters(self, params):
        self.base_parameters = json.dumps(params or {})
        
    def get_sandbox_deltas(self):
        if not self.sandbox_delta_payload_json:
            return {}
        try:
            return json.loads(self.sandbox_delta_payload_json)
        except Exception:
            return {}
            
    def set_sandbox_deltas(self, deltas):
        self.sandbox_delta_payload_json = json.dumps(deltas or {})
        
    def get_simulation_results(self):
        if not self.simulation_results_json:
            return {}
        try:
            return json.loads(self.simulation_results_json)
        except Exception:
            return {}
            
    def set_simulation_results(self, results):
        self.simulation_results_json = json.dumps(results or {})
    
    def to_dict(self, include_details=False):
        d = {
            'id': self.id,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'parent_scenario_id': self.parent_scenario_id,
            'baseline_snapshot_id': self.baseline_snapshot_id,
            'name': self.name,
            'description': self.description,
            'scenario_type': self.scenario_type,
            'branch_type': self.branch_type or BranchType.SANDBOX,
            'status': self.status or ScenarioStatus.DRAFT,
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'params': self.get_parameters(),
            'deltas': self.get_sandbox_deltas(),
            'has_results': bool(self.simulation_results_json)
        }
        if include_details:
            d['results'] = self.get_simulation_results()
            d['step_count'] = self.steps.count()
        return d

class ScenarioStep(db.Model):
    __tablename__ = 'scenario_steps'
    
    id = db.Column(db.Integer, primary_key=True)
    scenario_id = db.Column(db.Integer, db.ForeignKey('scenarios.id'), nullable=False)
    step_number = db.Column(db.Integer, nullable=False)
    name = db.Column(db.String(200))
    description = db.Column(db.Text)
    parameters = db.Column(db.Text)
    expected_outcome = db.Column(db.Text)
    is_completed = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def get_parameters(self):
        if not self.parameters:
            return {}
        try:
            return json.loads(self.parameters)
        except Exception:
            return {}
    
    def set_parameters(self, params):
        self.parameters = json.dumps(params or {})
        
    def to_dict(self):
        return {
            'id': self.id,
            'scenario_id': self.scenario_id,
            'step_number': self.step_number,
            'name': self.name,
            'description': self.description,
            'is_completed': self.is_completed,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
