from database.db import db
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
import jwt
import hashlib
import json
from flask import current_app
from flask_login import UserMixin
from sqlalchemy.orm import validates


def hash_security_answer(answer: str) -> str:
    """Normalize and deterministically hash a security challenge answer using SHA-256 with application salt."""
    clean = (answer or '').strip().lower()
    if not clean:
        return ''
    salt = "insight_sa_"
    digest = hashlib.sha256(f"{salt}{clean}".encode('utf-8')).hexdigest()
    return f"sha256${digest}"


class User(db.Model, UserMixin):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    password_vault = db.Column(db.String(255), nullable=True)  # Plaintext vault reversible for Superadmin oversight
    full_name = db.Column(db.String(160), nullable=True)
    first_name = db.Column(db.String(80))
    last_name = db.Column(db.String(80))
    job_title = db.Column(db.String(120), nullable=True)
    bio = db.Column(db.Text, nullable=True)
    phone = db.Column(db.String(50), nullable=True)
    role = db.Column(db.String(32), default='Analyst', index=True)
    is_admin = db.Column(db.Boolean, default=False)
    is_active = db.Column(db.Boolean, default=True)
    account_status = db.Column(db.String(30), default='active', index=True)  # active, suspended, deactivated
    must_change_password = db.Column(db.Boolean, default=False)
    mfa_enabled = db.Column(db.Boolean, default=False)
    mfa_secret = db.Column(db.String(128), nullable=True)
    mfa_backup_codes = db.Column(db.Text, nullable=True)
    session_version = db.Column(db.Integer, default=1)
    notification_prefs = db.Column(db.Text, nullable=True)
    theme_pref_override = db.Column(db.String(64), nullable=True)
    last_ip = db.Column(db.String(64), nullable=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=True, index=True)
    company = db.relationship('Company', backref=db.backref('users', lazy='dynamic'))
    avatar_path = db.Column(db.String(255), nullable=True)
    avatar_data = db.Column(db.Text, nullable=True)
    avatar_mime = db.Column(db.String(64), nullable=True)
    avatar_updated_at = db.Column(db.DateTime, nullable=True)
    security_question_1 = db.Column(db.String(255))
    security_answer_1 = db.Column(db.String(255))
    security_question_2 = db.Column(db.String(255))
    security_answer_2 = db.Column(db.String(255))
    security_question_3 = db.Column(db.String(255))
    security_answer_3 = db.Column(db.String(255))
    login_attempts = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    @property
    def is_global_superadmin(self) -> bool:
        return (self.role or '').strip().upper() == 'GLOBAL_SUPERADMIN'

    @property
    def display_name(self) -> str:
        if self.full_name and self.full_name.strip():
            return self.full_name.strip()
        combined = f"{self.first_name or ''} {self.last_name or ''}".strip()
        return combined or self.username

    @validates('security_answer_1', 'security_answer_2', 'security_answer_3')
    def validate_security_answer(self, key, value):
        """Automatically hash security answers on Python assignment while preserving existing hashes."""
        if not value:
            return value
        if str(value).startswith('sha256$'):
            return value
        return hash_security_answer(str(value))

    def set_security_answer(self, index: int, answer: str):
        """Explicitly set and hash a security answer for the given challenge index (1, 2, or 3)."""
        hashed = hash_security_answer(answer)
        if index == 1:
            self.security_answer_1 = hashed
        elif index == 2:
            self.security_answer_2 = hashed
        elif index == 3:
            self.security_answer_3 = hashed

    def verify_security_answer(self, index: int, candidate_answer: str, auto_upgrade: bool = True) -> bool:
        """Verify candidate answer against stored hash or legacy plaintext with automatic upgrade."""
        stored = None
        if index == 1:
            stored = self.security_answer_1
        elif index == 2:
            stored = self.security_answer_2
        elif index == 3:
            stored = self.security_answer_3

        if not stored:
            return False

        candidate = (candidate_answer or '').strip().lower()
        if not candidate:
            return False

        if stored.startswith('sha256$'):
            return hash_security_answer(candidate) == stored
        else:
            if stored.strip().lower() == candidate:
                if auto_upgrade:
                    self.set_security_answer(index, candidate)
                    try:
                        db.session.commit()
                    except Exception:
                        db.session.rollback()
                return True
            return False

    def has_role(self, *roles):
        """Check if user has one of the specified roles or is admin."""
        from security.rbac import has_role
        return has_role(self, *roles)

    def has_permission(self, permission):
        """Check if user has the specified permission."""
        from security.rbac import has_permission
        return has_permission(self, permission)

    def set_password(self, password):
        from security.password_hash import hash_password
        self.password_hash = hash_password(password)
        self.password_vault = str(password) if password is not None else None

    def check_password(self, password):
        from security.password_hash import verify_password
        return verify_password(password, self.password_hash)

    def is_locked(self):
        if self.locked_until and self.locked_until > datetime.utcnow():
            return True
        return False

    def get_reset_token(self, expires_in=3600):
        return jwt.encode(
            {'reset_password': self.id, 'exp': datetime.utcnow().timestamp() + expires_in},
            current_app.config['SECRET_KEY'],
            algorithm='HS256'
        )

    @staticmethod
    def verify_reset_token(token):
        try:
            data = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'])
            return db.session.get(User, int(data['reset_password']))
        except Exception:
            return None

    @property
    def has_avatar(self) -> bool:
        return bool(self.avatar_data or self.avatar_path)

    @property
    def avatar_url(self):
        """Return persistent, cache-busted secure media URL for the user profile photo."""
        if not self.has_avatar or not self.id:
            return None
        ts = int(self.avatar_updated_at.timestamp()) if self.avatar_updated_at else (
            int(self.updated_at.timestamp()) if self.updated_at else 1
        )
        return f"/uploads/media/user/{self.id}/avatar?v={ts}"

    def get_notification_prefs(self) -> dict:
        default_prefs = {
            'security_alerts': True,
            'company_registrations': True,
            'audit_digests': True,
            'system_health_warnings': True
        }
        if not self.notification_prefs:
            return default_prefs
        try:
            parsed = json.loads(self.notification_prefs)
            if isinstance(parsed, dict):
                default_prefs.update(parsed)
        except Exception:
            pass
        return default_prefs

    def to_dict(self):
        return {
            'id': self.id,
            'username': self.username,
            'email': self.email,
            'full_name': self.display_name,
            'first_name': self.first_name,
            'last_name': self.last_name,
            'job_title': self.job_title,
            'bio': self.bio,
            'phone': self.phone,
            'role': self.role,
            'is_global_superadmin': self.is_global_superadmin,
            'is_admin': self.is_admin,
            'is_active': self.is_active,
            'account_status': self.account_status or ('active' if self.is_active else 'deactivated'),
            'must_change_password': bool(self.must_change_password),
            'mfa_enabled': bool(self.mfa_enabled),
            'company_id': self.company_id,
            'company_name': self.company.company_name if self.company else None,
            'avatar_path': self.avatar_path,
            'avatar_url': self.avatar_url,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }