from database.db import db
from datetime import datetime


class DepartmentBudget(db.Model):
    """
    Tracks authoritative period-based budget allocations, committed expenditures,
    and actual spending for an organization's departments.
    Distinguishes allocated budget (financial authority) from live actuals.
    """
    __tablename__ = 'department_budgets'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=False, index=True)
    period = db.Column(db.String(30), default='annual')  # annual, quarterly, monthly, custom
    period_name = db.Column(db.String(50), default='FY Current')  # e.g., FY2026, Q1-2026
    allocated_amount = db.Column(db.Float, default=0.0)
    committed_amount = db.Column(db.Float, default=0.0)
    actual_spent = db.Column(db.Float, default=0.0)
    currency = db.Column(db.String(10), default='USD')
    status = db.Column(db.String(30), default='active')  # active, draft, archived, locked
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_dept_budgets_company_dept', 'company_id', 'department_id', 'period'),
    )

    @property
    def remaining_budget(self) -> float:
        return max(0.0, float(self.allocated_amount or 0.0) - float(self.actual_spent or 0.0))

    @property
    def utilization_percentage(self) -> float:
        if not self.allocated_amount or self.allocated_amount <= 0:
            return 0.0
        return round((float(self.actual_spent or 0.0) / float(self.allocated_amount)) * 100, 1)

    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'department_id': self.department_id,
            'period': self.period,
            'period_name': self.period_name,
            'allocated_amount': float(self.allocated_amount or 0.0),
            'committed_amount': float(self.committed_amount or 0.0),
            'actual_spent': float(self.actual_spent or 0.0),
            'remaining_budget': self.remaining_budget,
            'utilization_percentage': self.utilization_percentage,
            'currency': self.currency,
            'status': self.status,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

