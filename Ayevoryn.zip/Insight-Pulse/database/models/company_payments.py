from database.db import db
from datetime import datetime

class CompanyPayments(db.Model):
    __tablename__ = 'company_payments'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    qr_code_path = db.Column(db.String(255))
    upi_link = db.Column(db.String(500))
    upi_id = db.Column(db.String(200))
    upi_display_name = db.Column(db.String(200), nullable=True)
    upi_verification_status = db.Column(db.String(50), default='Not Configured', nullable=True) # Not Configured, Configured, Verification Pending, Verified, Verification Failed
    data_confidence = db.Column(db.String(50), default='User-provided', nullable=True) # User-provided, Imported, Calculated, Estimated
    payment_description = db.Column(db.String(500), nullable=True)
    bank_transfer_details = db.Column(db.Text)
    account_holder_name = db.Column(db.String(200), nullable=True)
    bank_name = db.Column(db.String(200))
    bank_branch = db.Column(db.String(200), nullable=True)
    account_type = db.Column(db.String(50), default='Corporate Current', nullable=True)
    bank_account_number = db.Column(db.String(100))
    masked_account_number = db.Column(db.String(100), nullable=True)
    bank_ifsc = db.Column(db.String(50))
    is_primary_account = db.Column(db.Boolean, default=True)
    default_payment_method = db.Column(db.String(50), default='bank_transfer', nullable=True)
    invoice_payment_instructions = db.Column(db.Text, nullable=True)
    payment_terms = db.Column(db.String(50), default='Net 30', nullable=True)
    payment_gateway_link = db.Column(db.String(500))
    payment_link = db.Column(db.String(500))
    gateway_provider = db.Column(db.String(50), nullable=True)
    merchant_account_id = db.Column(db.String(100), nullable=True)
    gateway_status = db.Column(db.String(50), default='Unverified', nullable=True)
    stripe_key = db.Column(db.String(500))
    paypal_link = db.Column(db.String(500))
    razorpay_key = db.Column(db.String(500))
    whatsapp_business_link = db.Column(db.String(500))
    telegram_business_link = db.Column(db.String(500))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def get_masked_account_number(self) -> str:
        """Returns safe masked account number e.g. ••••••••1234."""
        raw = (self.bank_account_number or '').strip()
        if not raw:
            return ''
        if len(raw) <= 4:
            return raw
        return ('•' * (len(raw) - 4)) + raw[-4:]

    def build_upi_uri(self, amount: float = None, note: str = None) -> str:
        """Construct standard NPCI/UPI payment URI specification."""
        clean_upi = (self.upi_id or '').strip()
        if not clean_upi:
            return ''
        from urllib.parse import quote
        name = quote((self.upi_display_name or self.account_holder_name or 'Enterprise').strip())
        uri = f"upi://pay?pa={clean_upi}&pn={name}&cu=INR"
        if amount and amount > 0:
            uri += f"&am={amount:.2f}"
        tn = (note or self.payment_description or 'Invoice Settlement').strip()
        if tn:
            uri += f"&tn={quote(tn)}"
        return uri

    def generate_and_save_qr(self, root_dir: str = None) -> str:
        """Dynamically generate and persist a high-resolution UPI QR Code image."""
        uri = self.build_upi_uri()
        if not uri:
            return ''
        import os
        import qrcode

        # Determine target output directory
        target_dir = os.path.join(root_dir or '', 'static', 'uploads', 'qrcodes')
        os.makedirs(target_dir, exist_ok=True)
        filename = f"company_{self.company_id}_upi_qr.png"
        filepath = os.path.join(target_dir, filename)

        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=2,
        )
        qr.add_data(uri)
        qr.make(fit=True)
        img = qr.make_image(fill_color="#0F172A", back_color="#FFFFFF")
        img.save(filepath)

        rel_path = f"uploads/qrcodes/{filename}"
        self.qr_code_path = rel_path
        self.upi_link = uri
        if not self.upi_verification_status or self.upi_verification_status == 'Not Configured':
            self.upi_verification_status = 'Configured'
        return rel_path

    def to_dict(self, mask_sensitive=True):
        acct_num = self.get_masked_account_number() if mask_sensitive else self.bank_account_number
        return {
            'id': self.id,
            'company_id': self.company_id,
            'qr_code_path': self.qr_code_path,
            'upi_link': self.upi_link or self.build_upi_uri(),
            'upi_id': self.upi_id or '',
            'upi_display_name': self.upi_display_name or '',
            'upi_verification_status': self.upi_verification_status or ('Configured' if self.upi_id else 'Not Configured'),
            'data_confidence': self.data_confidence or 'User-provided',
            'payment_description': self.payment_description or '',
            'bank_transfer_details': self.bank_transfer_details or '',
            'account_holder_name': self.account_holder_name or '',
            'bank_name': self.bank_name or '',
            'bank_branch': self.bank_branch or '',
            'account_type': self.account_type or 'Corporate Current',
            'bank_account_number': acct_num,
            'masked_account_number': self.get_masked_account_number(),
            'bank_ifsc': self.bank_ifsc or '',
            'is_primary_account': bool(self.is_primary_account),
            'default_payment_method': self.default_payment_method or 'bank_transfer',
            'invoice_payment_instructions': self.invoice_payment_instructions or '',
            'payment_terms': self.payment_terms or 'Net 30',
            'gateway_provider': self.gateway_provider or '',
            'merchant_account_id': self.merchant_account_id or '',
            'gateway_status': self.gateway_status or 'Unverified',
            'payment_gateway_link': self.payment_gateway_link,
            'payment_link': self.payment_link,
            'whatsapp_business_link': self.whatsapp_business_link,
            'telegram_business_link': self.telegram_business_link
        }