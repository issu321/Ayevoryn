from database.db import db
from datetime import datetime
import json

class ForecastModelFamily:
    STATISTICAL_REGRESSION = "STATISTICAL_REGRESSION"
    MOVING_AVERAGE = "MOVING_AVERAGE"
    EXPONENTIAL_SMOOTHING = "EXPONENTIAL_SMOOTHING"
    AUTOREGRESSIVE_INTEGRATED = "AUTOREGRESSIVE_INTEGRATED"
    SEASONAL_DECOMPOSITION = "SEASONAL_DECOMPOSITION"
    ENSEMBLE_BLENDED = "ENSEMBLE_BLENDED"

class DataReadinessLevel:
    INSUFFICIENT = "INSUFFICIENT"
    LIMITED = "LIMITED"
    SUFFICIENT = "SUFFICIENT"
    ROBUST = "ROBUST"

class ForecastStatus:
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    INSUFFICIENT_DATA = "insufficient_data"

class Forecast(db.Model):
    __tablename__ = 'forecasts'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    forecast_type = db.Column(db.String(50), nullable=False)
    method = db.Column(db.String(50), default='prophet')
    model_family = db.Column(db.String(60))
    horizon_days = db.Column(db.Integer, default=90)
    status = db.Column(db.String(30), default='running')
    parameters = db.Column(db.Text)
    accuracy_mae = db.Column(db.Float)
    accuracy_rmse = db.Column(db.Float)
    accuracy_mape = db.Column(db.Float)
    accuracy_r2 = db.Column(db.Float)
    
    # Backtesting & Data Readiness Integrity (Stage 16)
    data_readiness = db.Column(db.String(30), default='ROBUST')
    observation_count = db.Column(db.Integer, default=0)
    is_synthetic_heuristic = db.Column(db.Boolean, default=False)
    is_backtested = db.Column(db.Boolean, default=False)
    backtest_split_days = db.Column(db.Integer)
    backtest_mae = db.Column(db.Float)
    backtest_rmse = db.Column(db.Float)
    backtest_mape = db.Column(db.Float)
    backtest_r2 = db.Column(db.Float)
    backtest_coverage = db.Column(db.Float)
    backtest_directional_accuracy = db.Column(db.Float)
    backtest_results_json = db.Column(db.Text)
    model_metadata_json = db.Column(db.Text)

    summary = db.Column(db.Text)
    is_saved = db.Column(db.Boolean, default=False)
    schedule = db.Column(db.String(20), default='manual')
    last_run = db.Column(db.DateTime)
    next_run = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    user = db.relationship('User', backref='forecasts')
    results = db.relationship('ForecastResult', backref='forecast', lazy='dynamic', cascade='all, delete-orphan')
    
    def get_parameters(self):
        return json.loads(self.parameters) if self.parameters else {}
    
    def set_parameters(self, params):
        self.parameters = json.dumps(params)
    
    def get_backtest_results(self):
        if not self.backtest_results_json:
            return {}
        try:
            return json.loads(self.backtest_results_json)
        except Exception:
            return {}
            
    def set_backtest_results(self, val):
        self.backtest_results_json = json.dumps(val or {})
        
    def get_model_metadata(self):
        if not self.model_metadata_json:
            return {}
        try:
            return json.loads(self.model_metadata_json)
        except Exception:
            return {}
            
    def set_model_metadata(self, val):
        self.model_metadata_json = json.dumps(val or {})
    
    def to_dict(self, include_backtest=False):
        d = {
            'id': self.id,
            'name': self.name,
            'forecast_type': self.forecast_type,
            'method': self.method,
            'model_family': self.model_family,
            'horizon_days': self.horizon_days,
            'status': self.status,
            'data_readiness': self.data_readiness or 'ROBUST',
            'observation_count': self.observation_count or 0,
            'is_synthetic_heuristic': bool(self.is_synthetic_heuristic),
            'is_backtested': bool(self.is_backtested),
            'accuracy_mae': self.accuracy_mae,
            'accuracy_rmse': self.accuracy_rmse,
            'accuracy_mape': self.accuracy_mape,
            'accuracy_r2': self.accuracy_r2,
            'backtest_mae': self.backtest_mae,
            'backtest_rmse': self.backtest_rmse,
            'backtest_mape': self.backtest_mape,
            'backtest_r2': self.backtest_r2,
            'backtest_coverage': self.backtest_coverage,
            'backtest_directional_accuracy': self.backtest_directional_accuracy,
            'summary': self.summary,
            'schedule': self.schedule,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
        if include_backtest:
            d['backtest_details'] = self.get_backtest_results()
            d['model_metadata'] = self.get_model_metadata()
        return d

class ForecastResult(db.Model):
    __tablename__ = 'forecast_results'
    
    id = db.Column(db.Integer, primary_key=True)
    forecast_id = db.Column(db.Integer, db.ForeignKey('forecasts.id'), nullable=False)
    date = db.Column(db.Date, nullable=False)
    value = db.Column(db.Float)
    lower_bound = db.Column(db.Float)
    upper_bound = db.Column(db.Float)
    actual = db.Column(db.Float)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)