"""
AEVORYN / INSIGHT-PULSE
STAGE 23: BACKGROUND JOB MODEL
Persistent asynchronous job tracking, progress telemetry, priority, and tenant isolation.
"""

from datetime import datetime
import json
import uuid
from database.db import db


class BackgroundJob(db.Model):
    __tablename__ = 'background_jobs'

    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    job_type = db.Column(db.String(64), nullable=False, index=True)
    priority = db.Column(db.Integer, default=5, nullable=False)
    max_retries = db.Column(db.Integer, default=3, nullable=False)
    retry_count = db.Column(db.Integer, default=0, nullable=False)
    status = db.Column(db.String(20), nullable=False, default='pending', index=True)
    progress = db.Column(db.Integer, default=0, nullable=False)
    stage_message = db.Column(db.String(255), default='Queued', nullable=False)
    payload_json = db.Column(db.Text, nullable=True)
    result_json = db.Column(db.Text, nullable=True)
    error_message = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    started_at = db.Column(db.DateTime, nullable=True)
    completed_at = db.Column(db.DateTime, nullable=True)
    duration_ms = db.Column(db.Integer, nullable=True)

    # Relationships
    company = db.relationship('Company', backref=db.backref('background_jobs', lazy='dynamic', cascade='all, delete-orphan'))
    user = db.relationship('User', backref=db.backref('background_jobs', lazy='dynamic'))

    __table_args__ = (
        db.Index('idx_jobs_company_status', 'company_id', 'status'),
        db.Index('idx_jobs_company_created', 'company_id', 'created_at'),
    )

    @property
    def duration_seconds(self):
        if self.duration_ms is not None:
            return round(self.duration_ms / 1000.0, 3)
        return None

    @property
    def payload(self):
        return self.get_payload()

    @property
    def result(self):
        return self.get_result()

    def get_payload(self):
        """Parse payload JSON to dict."""
        if not self.payload_json:
            return {}
        try:
            return json.loads(self.payload_json)
        except Exception:
            return {}

    def set_payload(self, payload):
        """Serialize payload dict to JSON."""
        if payload is None:
            self.payload_json = None
        else:
            self.payload_json = json.dumps(payload, default=str)

    def get_result(self):
        """Parse result JSON to dict."""
        if not self.result_json:
            return None
        try:
            return json.loads(self.result_json)
        except Exception:
            return None

    def set_result(self, result):
        """Serialize result dict to JSON."""
        if result is None:
            self.result_json = None
        else:
            self.result_json = json.dumps(result, default=str)

    def to_dict(self):
        """Return standardized JSON representation."""
        return {
            'id': self.id,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'job_type': self.job_type,
            'priority': self.priority,
            'max_retries': self.max_retries,
            'retry_count': self.retry_count,
            'status': self.status,
            'progress': self.progress,
            'stage_message': self.stage_message,
            'payload': self.get_payload(),
            'result': self.get_result(),
            'error_message': self.error_message,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'duration_ms': self.duration_ms,
            'duration_seconds': self.duration_seconds
        }
