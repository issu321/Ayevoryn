from database.db import db
from datetime import datetime
from sqlalchemy import event
import json
import uuid


class GlobalAuditLog(db.Model):
    """
    Immutable Platform-Wide Administrative Audit Log.
    Records every Global Superadmin and platform-level security action.
    Protected by SQLAlchemy event listeners to prevent ordinary ORM updates or deletions.
    """
    __tablename__ = 'global_audit_logs'

    id = db.Column(db.Integer, primary_key=True)
    correlation_id = db.Column(db.String(64), index=True, default=lambda: str(uuid.uuid4())[:12].upper())
    actor_user_id = db.Column(db.Integer, index=True, nullable=True)
    actor_username = db.Column(db.String(80), index=True, nullable=True)
    actor_role = db.Column(db.String(40), nullable=True)
    action = db.Column(db.String(100), nullable=False, index=True)
    category = db.Column(db.String(50), default='PLATFORM', index=True)  # COMPANY, USER, PLATFORM, AUTH, SECURITY, AI
    target_company_id = db.Column(db.Integer, index=True, nullable=True)
    target_company_name = db.Column(db.String(200), nullable=True)
    target_user_id = db.Column(db.Integer, index=True, nullable=True)
    target_username = db.Column(db.String(80), nullable=True)
    previous_values = db.Column(db.Text, nullable=True)  # JSON string
    updated_values = db.Column(db.Text, nullable=True)   # JSON string
    ip_address = db.Column(db.String(64), nullable=True)
    user_agent = db.Column(db.String(255), nullable=True)
    result_status = db.Column(db.String(30), default='SUCCESS', index=True)  # SUCCESS, FAILED, DENIED
    details = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    def get_previous_dict(self):
        if not self.previous_values:
            return {}
        try:
            return json.loads(self.previous_values)
        except Exception:
            return {'raw': self.previous_values}

    def get_updated_dict(self):
        if not self.updated_values:
            return {}
        try:
            return json.loads(self.updated_values)
        except Exception:
            return {'raw': self.updated_values}

    def to_dict(self):
        return {
            'id': self.id,
            'correlation_id': self.correlation_id,
            'actor_user_id': self.actor_user_id,
            'actor_username': self.actor_username,
            'actor_role': self.actor_role,
            'action': self.action,
            'category': self.category,
            'target_company_id': self.target_company_id,
            'target_company_name': self.target_company_name,
            'target_user_id': self.target_user_id,
            'target_username': self.target_username,
            'previous_values': self.get_previous_dict(),
            'updated_values': self.get_updated_dict(),
            'ip_address': self.ip_address,
            'result_status': self.result_status,
            'details': self.details,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }


@event.listens_for(GlobalAuditLog, 'before_update')
def _prevent_global_audit_update(mapper, connection, target):
    raise PermissionError("GlobalAuditLog records are immutable and cannot be modified.")


@event.listens_for(GlobalAuditLog, 'before_delete')
def _prevent_global_audit_delete(mapper, connection, target):
    raise PermissionError("GlobalAuditLog records are immutable and cannot be deleted.")


class PlatformSetting(db.Model):
    """Global Platform Control configuration persisted in the database."""
    __tablename__ = 'platform_settings'

    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False, index=True)
    value = db.Column(db.Text, nullable=True)
    value_type = db.Column(db.String(20), default='string')  # string, bool, int, float, json
    category = db.Column(db.String(50), default='general')
    description = db.Column(db.String(255), nullable=True)
    updated_by_user_id = db.Column(db.Integer, nullable=True)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    def parsed_value(self):
        if self.value is None:
            return None
        if self.value_type == 'bool':
            return str(self.value).lower() in ('true', '1', 'yes', 'on')
        if self.value_type == 'int':
            try:
                return int(self.value)
            except Exception:
                return 0
        if self.value_type == 'float':
            try:
                return float(self.value)
            except Exception:
                return 0.0
        if self.value_type == 'json':
            try:
                return json.loads(self.value)
            except Exception:
                return {}
        return self.value


class UserSessionRecord(db.Model):
    """Tracks active and historical authentication sessions for session revocation and security visibility."""
    __tablename__ = 'user_session_records'

    id = db.Column(db.Integer, primary_key=True)
    session_token = db.Column(db.String(64), unique=True, nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False, index=True)
    company_id = db.Column(db.Integer, nullable=True, index=True)
    ip_address = db.Column(db.String(64), nullable=True)
    user_agent = db.Column(db.String(255), nullable=True)
    device_label = db.Column(db.String(120), nullable=True)
    is_active = db.Column(db.Boolean, default=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_seen_at = db.Column(db.DateTime, default=datetime.utcnow)
    revoked_at = db.Column(db.DateTime, nullable=True)
    revoked_reason = db.Column(db.String(160), nullable=True)

    user = db.relationship('User', backref=db.backref('session_records', lazy='dynamic'))

    def to_dict(self):
        return {
            'id': self.id,
            'session_token': self.session_token,
            'user_id': self.user_id,
            'company_id': self.company_id,
            'ip_address': self.ip_address,
            'user_agent': self.user_agent,
            'device_label': self.device_label or 'Web Browser Session',
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_seen_at': self.last_seen_at.isoformat() if self.last_seen_at else None,
            'revoked_at': self.revoked_at.isoformat() if self.revoked_at else None,
            'revoked_reason': self.revoked_reason
        }
