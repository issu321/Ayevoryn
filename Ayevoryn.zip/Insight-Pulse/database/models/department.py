from database.db import db
from datetime import datetime

class Department(db.Model):
    __tablename__ = 'departments'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    code = db.Column(db.String(50))
    description = db.Column(db.Text)
    head_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    head_name = db.Column(db.String(200))
    head_email = db.Column(db.String(120), nullable=True)
    head_designation = db.Column(db.String(100), nullable=True)
    budget = db.Column(db.Float, default=0.0)
    budget_currency = db.Column(db.String(10), default='USD', nullable=True)
    budget_period = db.Column(db.String(20), default='Annual', nullable=True)
    spent = db.Column(db.Float, default=0.0)
    employee_count = db.Column(db.Integer, default=0)
    team_size = db.Column(db.Integer, default=0, nullable=True)
    contact_email = db.Column(db.String(120), nullable=True)
    contact_phone = db.Column(db.String(50), nullable=True)
    color = db.Column(db.String(20), default='#2563EB')
    parent_department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=True)
    hierarchy_level = db.Column(db.Integer, default=2)  # 1: Executive, 2: Core Division, 3: Operational/Support
    responsibilities = db.Column(db.Text, nullable=True)
    kpi_summary = db.Column(db.String(255), nullable=True)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationship to employees — enables dept.employees query
    employees = db.relationship('Employee', backref='department', lazy='dynamic')

    __table_args__ = (
        db.Index('idx_departments_company_active', 'company_id', 'is_active'),
    )
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'name': self.name,
            'code': self.code or '',
            'description': self.description or '',
            'head_name': self.head_name or 'Unassigned',
            'head_email': self.head_email or '',
            'head_designation': self.head_designation or '',
            'budget': float(self.budget or 0.0),
            'budget_currency': self.budget_currency or 'USD',
            'budget_period': self.budget_period or 'Annual',
            'spent': float(self.spent or 0.0),
            'employee_count': int(self.employee_count or 0),
            'team_size': int(self.team_size or self.employee_count or 0),
            'contact_email': self.contact_email or '',
            'contact_phone': self.contact_phone or '',
            'color': self.color or '#2563EB',
            'parent_department_id': self.parent_department_id,
            'hierarchy_level': int(self.hierarchy_level or 2),
            'responsibilities': self.responsibilities or '',
            'kpi_summary': self.kpi_summary or '',
            'is_active': self.is_active,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
