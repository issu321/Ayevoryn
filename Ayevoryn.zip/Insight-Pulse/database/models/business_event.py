"""
BUSINESS EVENT MODEL - Immutable Domain Event Ledger.

Every state mutation in the enterprise digital twin generates a BusinessEvent.
Powers temporal snapshotting, auditability, twin impact propagation, and executive feeds.
"""

from database.db import db
from datetime import datetime
import json
import uuid


class BusinessEvent(db.Model):
    """
    Append-only domain event ledger.
    """
    __tablename__ = 'business_events'

    id = db.Column(db.Integer, primary_key=True)
    event_id = db.Column(db.String(36), unique=True, nullable=False, default=lambda: str(uuid.uuid4()), index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)

    # Event identification
    event_type = db.Column(db.String(100), nullable=False, index=True)  # e.g., 'financial.transaction.created'
    aggregate_type = db.Column(db.String(50), nullable=False, index=True)  # e.g., 'financial_record', 'employee'
    aggregate_id = db.Column(db.String(100), nullable=True)  # Entity primary key

    # Actor context
    actor_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    actor_name = db.Column(db.String(200), nullable=True)

    # Causality and tracing
    correlation_id = db.Column(db.String(36), nullable=True, index=True)  # Trace ID across cascaded events
    causation_id = db.Column(db.String(36), nullable=True)  # ID of direct predecessor event

    # Event payload / state diff
    payload_json = db.Column(db.Text, default='{}')

    # Timestamps
    occurred_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)
    recorded_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        db.Index('idx_biz_events_company_time', 'company_id', 'occurred_at'),
        db.Index('idx_biz_events_aggregate', 'company_id', 'aggregate_type', 'aggregate_id'),
    )

    def get_payload(self) -> dict:
        try:
            return json.loads(self.payload_json) if self.payload_json else {}
        except Exception:
            return {}

    def set_payload(self, data: dict):
        self.payload_json = json.dumps(data)

    def to_dict(self) -> dict:
        return {
            'id': self.id,
            'event_id': self.event_id,
            'company_id': self.company_id,
            'event_type': self.event_type,
            'aggregate_type': self.aggregate_type,
            'aggregate_id': self.aggregate_id,
            'actor_id': self.actor_id,
            'actor_name': self.actor_name,
            'correlation_id': self.correlation_id,
            'causation_id': self.causation_id,
            'payload': self.get_payload(),
            'occurred_at': self.occurred_at.isoformat() if self.occurred_at else None,
            'recorded_at': self.recorded_at.isoformat() if self.recorded_at else None,
        }

    def __repr__(self):
        return f"<BusinessEvent {self.event_type} id={self.event_id} aggregate={self.aggregate_type}:{self.aggregate_id}>"
