"""
AEVORYN / INSIGHT-PULSE
IMPACT TRACE MODEL
Stores explainable causal propagation traces resulting from digital twin mutations.
Records multi-hop blast radius, delta calculations, and triggered operational risks.
"""

from database.db import db
from datetime import datetime
import json
import uuid


class ImpactSeverity:
    LOW = 'LOW'
    MEDIUM = 'MEDIUM'
    HIGH = 'HIGH'
    CRITICAL = 'CRITICAL'

    ALL = [LOW, MEDIUM, HIGH, CRITICAL]


class ImpactTrace(db.Model):
    """Represents an explainable causal propagation trace triggered by a business event."""
    __tablename__ = 'impact_traces'
    
    id = db.Column(db.Integer, primary_key=True)
    trace_id = db.Column(db.String(36), default=lambda: str(uuid.uuid4()), unique=True, nullable=False, index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    
    # Originating trigger event
    trigger_event_id = db.Column(db.String(36), nullable=True, index=True)
    correlation_id = db.Column(db.String(36), nullable=True, index=True)
    trigger_type = db.Column(db.String(100), nullable=False)
    
    # Root mutation entity
    root_entity_type = db.Column(db.String(50), nullable=False)
    root_entity_id = db.Column(db.String(100), nullable=False)
    
    # Impact metrics & classification
    severity = db.Column(db.String(20), default=ImpactSeverity.LOW, nullable=False)
    affected_nodes_count = db.Column(db.Integer, default=0)
    max_depth = db.Column(db.Integer, default=0)
    
    # Explainable Causal Steps: list of dicts describing each propagation hop
    causal_steps_json = db.Column(db.Text, default='[]')
    summary_text = db.Column(db.Text, nullable=True)
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)
    
    __table_args__ = (
        db.Index('idx_impact_trace_company_created', 'company_id', 'created_at'),
        db.Index('idx_impact_trace_severity', 'company_id', 'severity'),
    )
    
    def get_causal_steps(self):
        """Parse causal steps JSON safely."""
        try:
            return json.loads(self.causal_steps_json) if self.causal_steps_json else []
        except Exception:
            return []
            
    def set_causal_steps(self, steps):
        """Serialize causal steps list to JSON."""
        self.causal_steps_json = json.dumps(steps) if steps else '[]'
        
    def to_dict(self):
        """Serialize impact trace to dictionary."""
        return {
            'id': self.id,
            'trace_id': self.trace_id,
            'company_id': self.company_id,
            'trigger_event_id': self.trigger_event_id,
            'correlation_id': self.correlation_id,
            'trigger_type': self.trigger_type,
            'root_entity_type': self.root_entity_type,
            'root_entity_id': self.root_entity_id,
            'root_node_id': f"{self.root_entity_type}:{self.root_entity_id}",
            'severity': self.severity,
            'affected_nodes_count': self.affected_nodes_count,
            'max_depth': self.max_depth,
            'causal_steps': self.get_causal_steps(),
            'summary_text': self.summary_text or '',
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
