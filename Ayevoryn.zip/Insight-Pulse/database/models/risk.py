from database.db import db
from datetime import datetime
import json

class RiskSource:
    MANUAL = 'manual'
    AUTOMATED_THRESHOLD = 'automated_threshold'
    SIMULATION_SHOCK = 'simulation_shock'
    IMPACT_PROPAGATION = 'impact_propagation'

    ALL = [MANUAL, AUTOMATED_THRESHOLD, SIMULATION_SHOCK, IMPACT_PROPAGATION]


class RiskStatus:
    ACTIVE = 'active'
    MITIGATED = 'mitigated'
    RESOLVED = 'resolved'
    DISMISSED = 'dismissed'

    ALL = [ACTIVE, MITIGATED, RESOLVED, DISMISSED]


class Risk(db.Model):
    __tablename__ = 'risks'
    
    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    name = db.Column(db.String(200), nullable=False)
    category = db.Column(db.String(50), nullable=False, index=True)
    description = db.Column(db.Text)
    probability = db.Column(db.Float, default=0.5)
    impact = db.Column(db.Float, default=0.5)
    risk_score = db.Column(db.Float, default=0.0)
    risk_level = db.Column(db.String(20), default='medium')
    status = db.Column(db.String(20), default='active', index=True)
    mitigation_plan = db.Column(db.Text)
    owner_id = db.Column(db.Integer, db.ForeignKey('users.id'))
    review_date = db.Column(db.Date)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Operational Threshold & Evidence Tracking (Stage 17)
    source = db.Column(db.String(50), default=RiskSource.MANUAL, nullable=False)
    is_automated = db.Column(db.Boolean, default=False, nullable=False)
    trigger_metric = db.Column(db.String(100), nullable=True, index=True)
    threshold_value = db.Column(db.Float, nullable=True)
    observed_value = db.Column(db.Float, nullable=True)
    evidence_json = db.Column(db.Text, default='{}')
    last_assessed_at = db.Column(db.DateTime, default=datetime.utcnow)
    resolved_at = db.Column(db.DateTime, nullable=True)
    
    factors = db.relationship('RiskFactor', backref='risk', lazy='dynamic', cascade='all, delete-orphan')

    __table_args__ = (
        db.Index('idx_risks_company_status_score', 'company_id', 'status', 'risk_score'),
    )
    
    def calculate_score(self):
        self.risk_score = round((self.probability * self.impact) * 100, 1)
        if self.risk_score >= 70:
            self.risk_level = 'critical'
        elif self.risk_score >= 40:
            self.risk_level = 'high'
        elif self.risk_score >= 20:
            self.risk_level = 'medium'
        else:
            self.risk_level = 'low'
        return self.risk_score

    def get_evidence(self):
        """Safely parse evidence JSON string into Python dict."""
        try:
            return json.loads(self.evidence_json) if self.evidence_json else {}
        except Exception:
            return {}

    def set_evidence(self, evidence_dict):
        """Serialize evidence dictionary to evidence_json."""
        self.evidence_json = json.dumps(evidence_dict or {})

    def resolve(self, notes=None):
        """Mark this risk as resolved with timestamp and optional notes."""
        self.status = RiskStatus.RESOLVED
        self.resolved_at = datetime.utcnow()
        if notes:
            ev = self.get_evidence()
            ev['resolution_notes'] = notes
            ev['resolved_at'] = self.resolved_at.isoformat()
            self.set_evidence(ev)

    def mitigate(self, plan=None):
        """Mark this risk as mitigated with updated mitigation plan."""
        self.status = RiskStatus.MITIGATED
        if plan:
            self.mitigation_plan = plan
    
    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'name': self.name,
            'category': self.category,
            'description': self.description,
            'probability': self.probability,
            'impact': self.impact,
            'risk_score': self.risk_score,
            'risk_level': self.risk_level,
            'status': self.status,
            'source': self.source,
            'is_automated': self.is_automated,
            'trigger_metric': self.trigger_metric,
            'threshold_value': self.threshold_value,
            'observed_value': self.observed_value,
            'evidence': self.get_evidence(),
            'mitigation_plan': self.mitigation_plan,
            'owner_id': self.owner_id,
            'review_date': self.review_date.isoformat() if self.review_date else None,
            'last_assessed_at': self.last_assessed_at.isoformat() if self.last_assessed_at else None,
            'resolved_at': self.resolved_at.isoformat() if self.resolved_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

class RiskFactor(db.Model):
    __tablename__ = 'risk_factors'
    
    id = db.Column(db.Integer, primary_key=True)
    risk_id = db.Column(db.Integer, db.ForeignKey('risks.id'), nullable=False)
    factor_name = db.Column(db.String(200), nullable=False)
    weight = db.Column(db.Float, default=1.0)
    score = db.Column(db.Float, default=0.0)
    description = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)