"""
AEVORYN / INSIGHT-PULSE
WEBHOOK MODELS
Enterprise outbound webhook subscriptions and delivery audit log.
"""

from datetime import datetime
import hmac
import hashlib
import json
import secrets
from database.db import db


class WebhookSubscription(db.Model):
    __tablename__ = 'webhook_subscriptions'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    url = db.Column(db.String(500), nullable=False)
    event_types = db.Column(db.String(500), nullable=False, default='*')
    secret = db.Column(db.String(128), nullable=False)
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    description = db.Column(db.String(255), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    last_triggered_at = db.Column(db.DateTime, nullable=True)
    failure_count = db.Column(db.Integer, default=0, nullable=False)

    # Relationships
    company = db.relationship('Company', backref=db.backref('webhook_subscriptions', lazy='dynamic', cascade='all, delete-orphan'))
    deliveries = db.relationship('WebhookDelivery', backref='subscription', lazy='dynamic', cascade='all, delete-orphan')

    @classmethod
    def create(cls, company_id: int, url: str, event_types: str = '*', description: str = None, secret: str = None):
        """Create a new WebhookSubscription with generated or provided secret."""
        if not secret:
            secret = f"whsec_{secrets.token_hex(24)}"
        
        # Clean event_types string
        if isinstance(event_types, (list, set)):
            event_str = ','.join([str(e).strip() for e in event_types if str(e).strip()])
        else:
            event_str = str(event_types).strip() or '*'

        sub = cls(
            company_id=company_id,
            url=url.strip(),
            event_types=event_str,
            secret=secret,
            description=description.strip() if description else None,
            is_active=True,
            created_at=datetime.utcnow()
        )
        db.session.add(sub)
        db.session.commit()
        return sub

    def sign_payload(self, payload_bytes: bytes) -> str:
        """Compute HMAC-SHA256 signature for outgoing payload."""
        return hmac.new(self.secret.encode('utf-8'), payload_bytes, hashlib.sha256).hexdigest()

    def matches_event(self, event_type: str) -> bool:
        """Check whether this subscription matches the given event type."""
        if not self.is_active:
            return False
        
        pattern = self.event_types.strip()
        if pattern == '*' or pattern == '["*"]':
            return True
            
        allowed = [e.strip() for e in pattern.replace(';', ',').split(',') if e.strip()]
        for target in allowed:
            if target == '*' or target == event_type:
                return True
            if target.endswith('.*'):
                prefix = target[:-2]
                if event_type.startswith(prefix + '.'):
                    return True
        return False

    def to_dict(self, include_secret: bool = False):
        """Return safe dictionary representation."""
        data = {
            'id': self.id,
            'company_id': self.company_id,
            'url': self.url,
            'event_types': self.event_types,
            'is_active': self.is_active,
            'description': self.description,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_triggered_at': self.last_triggered_at.isoformat() if self.last_triggered_at else None,
            'failure_count': self.failure_count
        }
        if include_secret:
            data['secret'] = self.secret
        return data


class WebhookDelivery(db.Model):
    __tablename__ = 'webhook_deliveries'

    id = db.Column(db.Integer, primary_key=True)
    subscription_id = db.Column(db.Integer, db.ForeignKey('webhook_subscriptions.id'), nullable=False, index=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    event_type = db.Column(db.String(100), nullable=False, index=True)
    payload_json = db.Column(db.Text, nullable=False)
    status_code = db.Column(db.Integer, nullable=True)
    success = db.Column(db.Boolean, default=False, nullable=False)
    error_message = db.Column(db.Text, nullable=True)
    delivered_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    response_time_ms = db.Column(db.Integer, nullable=True)

    company = db.relationship('Company', backref=db.backref('webhook_deliveries', lazy='dynamic', cascade='all, delete-orphan'))

    def to_dict(self):
        parsed_payload = None
        try:
            parsed_payload = json.loads(self.payload_json)
        except Exception:
            parsed_payload = self.payload_json

        return {
            'id': self.id,
            'subscription_id': self.subscription_id,
            'company_id': self.company_id,
            'event_type': self.event_type,
            'payload': parsed_payload,
            'status_code': self.status_code,
            'success': self.success,
            'error_message': self.error_message,
            'delivered_at': self.delivered_at.isoformat() if self.delivered_at else None,
            'response_time_ms': self.response_time_ms
        }
