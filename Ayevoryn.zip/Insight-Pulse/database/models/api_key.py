"""
AEVORYN / INSIGHT-PULSE
API KEY MODEL
Enterprise API credential management with cryptographic hashing and tenant scoping.
"""

from datetime import datetime, timedelta
import hashlib
import secrets
from database.db import db


class ApiKey(db.Model):
    __tablename__ = 'api_keys'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True, index=True)
    name = db.Column(db.String(100), nullable=False, default='Default API Key')
    key_prefix = db.Column(db.String(16), nullable=False, default='aev_live_')
    key_hash = db.Column(db.String(64), nullable=False, unique=True, index=True)
    role = db.Column(db.String(20), nullable=False, default='Analyst')
    is_active = db.Column(db.Boolean, default=True, nullable=False)
    last_used_at = db.Column(db.DateTime, nullable=True)
    expires_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    revoked_at = db.Column(db.DateTime, nullable=True)

    # Relationships
    company = db.relationship('Company', backref=db.backref('api_keys', lazy='dynamic', cascade='all, delete-orphan'))
    user = db.relationship('User', backref=db.backref('api_keys', lazy='dynamic'))

    @staticmethod
    def hash_key(raw_key: str) -> str:
        """Deterministically generate SHA-256 hex digest of a raw API key."""
        return hashlib.sha256(raw_key.strip().encode('utf-8')).hexdigest()

    @classmethod
    def generate(cls, company_id: int, user_id: int = None, name: str = 'API Key',
                 role: str = 'Analyst', expires_days: int = None):
        """
        Generate a cryptographically secure API key and persist its hash.
        Returns a tuple of (ApiKey instance, raw_secret_key).
        The raw_secret_key is only accessible at generation time.
        """
        raw_secret = f"aev_live_{secrets.token_urlsafe(32)}"
        key_hash = cls.hash_key(raw_secret)
        
        expires_at = None
        if expires_days and expires_days > 0:
            expires_at = datetime.utcnow() + timedelta(days=expires_days)

        api_key = cls(
            company_id=company_id,
            user_id=user_id,
            name=name,
            key_prefix='aev_live_',
            key_hash=key_hash,
            role=role,
            is_active=True,
            expires_at=expires_at,
            created_at=datetime.utcnow()
        )
        db.session.add(api_key)
        db.session.commit()
        return api_key, raw_secret

    @classmethod
    def verify(cls, raw_key: str):
        """
        Verify a candidate raw key against active, unexpired keys.
        Returns the matching ApiKey record or None.
        """
        if not raw_key or not isinstance(raw_key, str):
            return None
        
        key_hash = cls.hash_key(raw_key)
        record = cls.query.filter_by(key_hash=key_hash, is_active=True).first()
        
        if not record:
            return None
        
        if record.expires_at and record.expires_at < datetime.utcnow():
            return None
            
        return record

    def touch(self):
        """Update last_used_at timestamp without altering other attributes."""
        self.last_used_at = datetime.utcnow()
        try:
            db.session.commit()
        except Exception:
            db.session.rollback()

    def revoke(self):
        """Permanently revoke this API key."""
        self.is_active = False
        self.revoked_at = datetime.utcnow()
        db.session.commit()

    def to_dict(self):
        """Return safe, non-sensitive dictionary representation."""
        return {
            'id': self.id,
            'company_id': self.company_id,
            'user_id': self.user_id,
            'name': self.name,
            'key_prefix': self.key_prefix,
            'role': self.role,
            'is_active': self.is_active,
            'last_used_at': self.last_used_at.isoformat() if self.last_used_at else None,
            'expires_at': self.expires_at.isoformat() if self.expires_at else None,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'revoked_at': self.revoked_at.isoformat() if self.revoked_at else None
        }
