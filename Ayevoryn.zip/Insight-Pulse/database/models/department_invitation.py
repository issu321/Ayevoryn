from database.db import db
from datetime import datetime
import uuid


class DepartmentInvitation(db.Model):
    """
    Represents an invitation for a department leader who has not registered yet.
    Allows company admins to configure organizational topology during onboarding
    without fabricating active authenticated user accounts prematurely.
    """
    __tablename__ = 'department_invitations'

    id = db.Column(db.Integer, primary_key=True)
    company_id = db.Column(db.Integer, db.ForeignKey('companies.id'), nullable=False, index=True)
    department_id = db.Column(db.Integer, db.ForeignKey('departments.id'), nullable=True, index=True)
    department_name = db.Column(db.String(200), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    work_email = db.Column(db.String(120), nullable=False, index=True)
    designation = db.Column(db.String(100), default='Department Head')
    status = db.Column(db.String(30), default='pending')  # pending, accepted, expired, revoked
    invitation_token = db.Column(db.String(64), unique=True, default=lambda: uuid.uuid4().hex)
    invited_by = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    __table_args__ = (
        db.Index('idx_dept_inv_company_email', 'company_id', 'work_email'),
    )

    def to_dict(self):
        return {
            'id': self.id,
            'company_id': self.company_id,
            'department_id': self.department_id,
            'department_name': self.department_name,
            'name': self.name,
            'work_email': self.work_email,
            'designation': self.designation,
            'status': self.status,
            'invitation_token': self.invitation_token,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }

