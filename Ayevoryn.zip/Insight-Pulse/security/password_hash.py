import hashlib
import hmac
import secrets

try:
    import bcrypt
    HAS_BCRYPT = True
except ImportError:
    HAS_BCRYPT = False

try:
    from werkzeug.security import check_password_hash as werkzeug_check_hash, generate_password_hash as werkzeug_gen_hash
    HAS_WERKZEUG = True
except ImportError:
    HAS_WERKZEUG = False


def _pbkdf2_hash(password: str, iterations: int = 600000) -> str:
    """Generate a Werkzeug-compatible pbkdf2:sha256 hash using Python's cryptographic standard library."""
    salt = secrets.token_hex(16)
    dk = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), iterations)
    return f"pbkdf2:sha256:{iterations}${salt}${dk.hex()}"


def _pbkdf2_verify(password: str, hashed: str) -> bool:
    """Verify a Werkzeug-compatible pbkdf2:sha256$<salt>$<hash> string in constant time."""
    try:
        header, salt, stored_hex = hashed.split('$', 2)
        parts = header.split(':')
        algo = parts[1] if len(parts) > 1 else 'sha256'
        iterations = int(parts[2]) if len(parts) > 2 else 260000
        dk = hashlib.pbkdf2_hmac(algo, password.encode('utf-8'), salt.encode('utf-8'), iterations)
        return hmac.compare_digest(dk.hex(), stored_hex)
    except Exception:
        return False


def hash_password(password: str) -> str:
    """Hash a password using strong enterprise bcrypt (12 rounds) or PBKDF2-HMAC-SHA256 (600,000 iterations)."""
    if isinstance(password, bytes):
        password_str = password.decode('utf-8', errors='replace')
    else:
        password_str = str(password or '')

    if HAS_BCRYPT:
        pw_bytes = password_str.encode('utf-8')
        return bcrypt.hashpw(pw_bytes, bcrypt.gensalt(rounds=12)).decode('utf-8')

    if HAS_WERKZEUG:
        return werkzeug_gen_hash(password_str)

    return _pbkdf2_hash(password_str)


def verify_password(password: str, hashed: str) -> bool:
    """Verify password against bcrypt, scrypt, argon2, or pbkdf2 hashes with constant-time comparison."""
    if not password or not hashed:
        return False

    pw_str = password.decode('utf-8', errors='replace') if isinstance(password, bytes) else str(password)
    hash_str = hashed.decode('utf-8', errors='replace') if isinstance(hashed, bytes) else str(hashed)

    # 1. Werkzeug / PBKDF2 / Scrypt / Argon2 format
    if hash_str.startswith('pbkdf2:'):
        if HAS_WERKZEUG:
            try:
                return werkzeug_check_hash(hash_str, pw_str)
            except Exception:
                pass
        return _pbkdf2_verify(pw_str, hash_str)

    if hash_str.startswith(('scrypt:', 'argon2:')):
        if HAS_WERKZEUG:
            try:
                return werkzeug_check_hash(hash_str, pw_str)
            except Exception:
                return False

    # 2. Bcrypt format ($2b$, $2a$, $2y$)
    if HAS_BCRYPT and hash_str.startswith('$2'):
        try:
            return bcrypt.checkpw(pw_str.encode('utf-8'), hash_str.encode('utf-8'))
        except Exception:
            pass

    if HAS_WERKZEUG:
        try:
            return werkzeug_check_hash(hash_str, pw_str)
        except Exception:
            pass

    return False