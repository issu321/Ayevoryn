import secrets
import json
import hmac
import hashlib
import base64
from datetime import datetime, timedelta
from flask import current_app

try:
    import jwt
    HAS_PYJWT = True
except ImportError:
    HAS_PYJWT = False


def _b64url_encode(raw: bytes) -> str:
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _b64url_decode(s: str) -> bytes:
    pad = '=' * (-len(s) % 4)
    return base64.urlsafe_b64decode((s + pad).encode('ascii'))


def generate_token(data, expires_in=3600):
    secret = current_app.config['SECRET_KEY']
    if HAS_PYJWT:
        payload = {
            'data': data,
            'exp': datetime.utcnow() + timedelta(seconds=expires_in),
            'iat': datetime.utcnow(),
            'jti': secrets.token_hex(16)
        }
        return jwt.encode(payload, secret, algorithm='HS256')

    now_ts = int(datetime.utcnow().timestamp())
    header = _b64url_encode(json.dumps({'alg': 'HS256', 'typ': 'JWT'}).encode('utf-8'))
    body = _b64url_encode(json.dumps({
        'data': data,
        'exp': now_ts + int(expires_in),
        'iat': now_ts,
        'jti': secrets.token_hex(16)
    }).encode('utf-8'))
    sig = hmac.new(secret.encode('utf-8'), f"{header}.{body}".encode('ascii'), hashlib.sha256).digest()
    return f"{header}.{body}.{_b64url_encode(sig)}"


def verify_token(token):
    secret = current_app.config['SECRET_KEY']
    if HAS_PYJWT:
        try:
            payload = jwt.decode(token, secret, algorithms=['HS256'])
            return payload.get('data')
        except Exception:
            return None

    try:
        header_b64, body_b64, sig_b64 = str(token).split('.', 2)
        expected_sig = _b64url_encode(
            hmac.new(secret.encode('utf-8'), f"{header_b64}.{body_b64}".encode('ascii'), hashlib.sha256).digest()
        )
        if not hmac.compare_digest(expected_sig, sig_b64):
            return None
        payload = json.loads(_b64url_decode(body_b64).decode('utf-8'))
        if payload.get('exp', 0) < int(datetime.utcnow().timestamp()):
            return None
        return payload.get('data')
    except Exception:
        return None


def generate_csrf_token():
    return secrets.token_urlsafe(32)