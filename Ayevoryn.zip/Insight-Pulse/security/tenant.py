"""
AEVORYN / INSIGHT-PULSE
ENTERPRISE TENANT CONTEXT AND ISOLATION SERVICE
Provides centralized tenant resolution, scoping, access verification, and IDOR prevention.
"""

from functools import wraps
from flask import session, request, abort, redirect, url_for, jsonify
from flask_login import current_user
from database.models.company import Company
from config.constants import CURRENCY_SYMBOLS


class TenantContext:
    """Manages active tenant context for the current request."""

    @staticmethod
    def get_current_company_id():
        """
        Resolve the active tenant company_id for the current request context.
        
        Security Invariants:
        1. If user is authenticated and has an assigned company_id:
           - Non-admin users are strictly locked to their assigned company_id.
           - If session['company_id'] differs, it is forced back to user.company_id to prevent session tampering.
        2. If user is admin or unauthenticated, session['company_id'] is respected if valid.
        3. Returns None if no valid company context can be resolved.
        """
        active_id = session.get('company_id')
        
        if current_user and current_user.is_authenticated:
            user_company_id = getattr(current_user, 'company_id', None)
            is_admin = getattr(current_user, 'is_admin', False) or getattr(current_user, 'role', '').lower() == 'admin'
            
            if user_company_id is not None:
                if not is_admin:
                    # Strict isolation: lock non-admin user to their assigned tenant
                    if active_id != user_company_id:
                        active_id = user_company_id
                        session['company_id'] = user_company_id
                else:
                    # Admin can switch, but if no active_id in session, fallback to user's company
                    if active_id is None:
                        active_id = user_company_id
                        session['company_id'] = user_company_id

        if active_id is not None:
            try:
                active_id = int(active_id)
            except (ValueError, TypeError):
                active_id = None
                session.pop('company_id', None)

        return active_id

    @staticmethod
    def get_current_company():
        """Return the active Company model instance for the resolved company_id."""
        cid = TenantContext.get_current_company_id()
        if not cid:
            return None
        return Company.query.get(cid)

    @staticmethod
    def set_current_company(company_id):
        """
        Explicitly set active company context in session if user is authorized.
        Returns (success: bool, error: str | None).
        """
        if not company_id:
            return False, 'Invalid company ID'

        try:
            cid = int(company_id)
        except (ValueError, TypeError):
            return False, 'Invalid company ID format'

        company = Company.query.get(cid)
        if not company or not company.is_active:
            return False, 'Company not found or inactive'

        if current_user and current_user.is_authenticated:
            is_admin = getattr(current_user, 'is_admin', False) or getattr(current_user, 'role', '').lower() == 'admin'
            user_company_id = getattr(current_user, 'company_id', None)
            
            if not is_admin and user_company_id is not None and user_company_id != cid:
                return False, 'Unauthorized: You do not have permission to access this company'

        session['company_id'] = company.id
        session['company_name'] = company.company_name
        session['company_currency'] = company.currency
        session['currency_symbol'] = CURRENCY_SYMBOLS.get(company.currency, '$')
        session['company_timezone'] = getattr(company, 'timezone', 'UTC')
        return True, None

    @staticmethod
    def verify_tenant_access(resource, company_id_attr='company_id'):
        """
        Verify that a model instance belongs to the current active tenant.
        Aborts with HTTP 403 Forbidden if there is a tenant boundary violation.
        """
        if resource is None:
            abort(404)
            
        current_cid = TenantContext.get_current_company_id()
        res_cid = getattr(resource, company_id_attr, None)
        
        if current_cid is None or res_cid is None or current_cid != res_cid:
            abort(403, description='Access denied: Resource belongs to another tenant.')

    @staticmethod
    def get_tenant_or_404(model, ident):
        """
        Look up a model instance by primary key and verify tenant ownership.
        Returns the instance if found and authorized, else raises 404/403.
        """
        current_cid = TenantContext.get_current_company_id()
        if not current_cid:
            abort(403, description='No active tenant context.')
            
        record = model.query.get(ident)
        if not record:
            abort(404)
            
        if getattr(record, 'company_id', None) != current_cid:
            abort(403, description='Access denied: Resource belongs to another tenant.')
            
        return record


# Global helper aliases
get_current_company_id = TenantContext.get_current_company_id
get_current_company = TenantContext.get_current_company
set_current_company = TenantContext.set_current_company
verify_tenant_access = TenantContext.verify_tenant_access
get_tenant_or_404 = TenantContext.get_tenant_or_404


def tenant_required(f):
    """Decorator ensuring a route is accessed within a valid tenant context."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        cid = TenantContext.get_current_company_id()
        if not cid:
            if request.is_json or request.path.startswith('/api/'):
                return jsonify({'error': 'Active company tenant context required'}), 403
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    return decorated_function
