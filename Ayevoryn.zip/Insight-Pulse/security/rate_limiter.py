from datetime import datetime, timezone, timedelta
from collections import defaultdict
import threading
from functools import wraps
from flask import request, jsonify, flash, redirect, url_for, current_app, Response

class RateLimiter:
    def __init__(self):
        self.attempts = defaultdict(list)
        self._lock = threading.Lock()
    
    def _now(self):
        return datetime.now(timezone.utc)
    
    def is_allowed(self, key, max_attempts=5, window_seconds=300):
        with self._lock:
            now = self._now()
            window_start = now - timedelta(seconds=window_seconds)
            
            # Filter attempts within current window
            self.attempts[key] = [t for t in self.attempts[key] if t > window_start]
            
            if len(self.attempts[key]) >= max_attempts:
                return False
            
            self.attempts[key].append(now)
            return True
    
    def reset(self, key=None):
        with self._lock:
            if key is None:
                self.attempts.clear()
            elif key in self.attempts:
                del self.attempts[key]
    
    def get_remaining(self, key, max_attempts=5, window_seconds=300):
        with self._lock:
            now = self._now()
            window_start = now - timedelta(seconds=window_seconds)
            self.attempts[key] = [t for t in self.attempts[key] if t > window_start]
            return max(0, max_attempts - len(self.attempts[key]))

limiter = RateLimiter()

def get_client_ip():
    """Extract real client IP considering forward headers."""
    if request.headers.get('X-Forwarded-For'):
        return request.headers.get('X-Forwarded-For').split(',')[0].strip()
    return request.remote_addr or '127.0.0.1'

def rate_limit(max_attempts=5, window_seconds=60, key_prefix=''):
    """
    Production-grade rate limiting decorator for Flask endpoints.
    Protects against credential stuffing, brute force, and DoS.
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            # Allow tests to disable rate limiting unless specifically testing rate limiting
            if current_app.config.get('TESTING') and not current_app.config.get('ENFORCE_RATE_LIMIT_IN_TESTS'):
                return f(*args, **kwargs)
                
            ip = get_client_ip()
            endpoint = key_prefix or request.endpoint or 'endpoint'
            key = f"{endpoint}:{ip}"
            
            if not limiter.is_allowed(key, max_attempts=max_attempts, window_seconds=window_seconds):
                remaining = 0
                if request.is_json or request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                    resp = jsonify({
                        'success': False,
                        'error': 'Too Many Requests',
                        'message': f'Rate limit exceeded ({max_attempts} requests per {window_seconds}s). Please wait before retrying.'
                    })
                    resp.status_code = 429
                    resp.headers['Retry-After'] = str(window_seconds)
                    resp.headers['X-RateLimit-Limit'] = str(max_attempts)
                    resp.headers['X-RateLimit-Remaining'] = '0'
                    return resp
                else:
                    flash(f'Too many requests. Please wait {window_seconds} seconds before trying again.', 'danger')
                    resp = Response("Too Many Requests", status=429)
                    resp.headers['Retry-After'] = str(window_seconds)
                    return resp
                    
            return f(*args, **kwargs)
        return decorated_function
    return decorator