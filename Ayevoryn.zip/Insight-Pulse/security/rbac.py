"""
AEVORYN / INSIGHT-PULSE
ROLE-BASED ACCESS CONTROL (RBAC) SERVICE
Provides centralized enterprise roles, hierarchy, permission mapping, and authorization decorators.
Strictly separates Global Superadmin (platform-wide control plane) from Company Administrators and Users.
"""

from functools import wraps
from flask import abort, jsonify, request, redirect, url_for, flash
from flask_login import current_user


class Role:
    GLOBAL_SUPERADMIN = 'GLOBAL_SUPERADMIN'
    OWNER = 'Owner'
    ADMIN = 'Admin'
    MANAGER = 'Manager'
    ANALYST = 'Analyst'
    AUDITOR = 'Auditor'
    VIEWER = 'Viewer'


# Role constants for backwards-compatibility
ROLE_GLOBAL_SUPERADMIN = Role.GLOBAL_SUPERADMIN
ROLE_OWNER = Role.OWNER
ROLE_ADMIN = Role.ADMIN
ROLE_MANAGER = Role.MANAGER
ROLE_ANALYST = Role.ANALYST
ROLE_AUDITOR = Role.AUDITOR
ROLE_VIEWER = Role.VIEWER

COMPANY_ROLES = [Role.OWNER, Role.ADMIN, Role.MANAGER, Role.ANALYST, Role.AUDITOR, Role.VIEWER]
ALL_ROLES = [Role.GLOBAL_SUPERADMIN] + COMPANY_ROLES

# Role Hierarchical Weight (higher number = greater privilege)
ROLE_HIERARCHY = {
    Role.GLOBAL_SUPERADMIN: 1000,
    Role.OWNER: 100,
    Role.ADMIN: 80,
    Role.MANAGER: 60,
    Role.ANALYST: 40,
    Role.AUDITOR: 20,
    Role.VIEWER: 10,
}


class Permission:
    PLATFORM_SUPERADMIN = 'platform:superadmin'
    COMPANY_MANAGE = 'company:manage'
    USER_MANAGE = 'user:manage'
    MANAGE_USERS = 'user:manage'
    DATA_WRITE = 'data:write'
    DATA_DELETE = 'data:delete'
    SIMULATION_RUN = 'simulation:run'
    RUN_SIMULATION = 'simulation:run'
    REPORT_EXPORT = 'report:export'
    AUDIT_VIEW = 'audit:view'
    VIEW_DASHBOARD = 'dashboard:view'


PERMISSION_PLATFORM_SUPERADMIN = Permission.PLATFORM_SUPERADMIN
PERMISSION_COMPANY_MANAGE = Permission.COMPANY_MANAGE
PERMISSION_USER_MANAGE = Permission.USER_MANAGE
PERMISSION_DATA_WRITE = Permission.DATA_WRITE
PERMISSION_DATA_DELETE = Permission.DATA_DELETE
PERMISSION_SIMULATION_RUN = Permission.SIMULATION_RUN
PERMISSION_REPORT_EXPORT = Permission.REPORT_EXPORT
PERMISSION_AUDIT_VIEW = Permission.AUDIT_VIEW

# Role to Permissions Mapping
ROLE_PERMISSIONS = {
    Role.GLOBAL_SUPERADMIN: {
        Permission.PLATFORM_SUPERADMIN,
        Permission.COMPANY_MANAGE,
        Permission.USER_MANAGE,
        Permission.DATA_WRITE,
        Permission.DATA_DELETE,
        Permission.SIMULATION_RUN,
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.VIEW_DASHBOARD,
    },
    Role.OWNER: {
        Permission.COMPANY_MANAGE,
        Permission.USER_MANAGE,
        Permission.DATA_WRITE,
        Permission.DATA_DELETE,
        Permission.SIMULATION_RUN,
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.VIEW_DASHBOARD,
    },
    Role.ADMIN: {
        Permission.COMPANY_MANAGE,
        Permission.USER_MANAGE,
        Permission.DATA_WRITE,
        Permission.DATA_DELETE,
        Permission.SIMULATION_RUN,
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.VIEW_DASHBOARD,
    },
    Role.MANAGER: {
        Permission.DATA_WRITE,
        Permission.DATA_DELETE,
        Permission.SIMULATION_RUN,
        Permission.REPORT_EXPORT,
        Permission.VIEW_DASHBOARD,
    },
    Role.ANALYST: {
        Permission.DATA_WRITE,
        Permission.SIMULATION_RUN,
        Permission.REPORT_EXPORT,
        Permission.VIEW_DASHBOARD,
    },
    Role.AUDITOR: {
        Permission.REPORT_EXPORT,
        Permission.AUDIT_VIEW,
        Permission.VIEW_DASHBOARD,
    },
    Role.VIEWER: {
        Permission.REPORT_EXPORT,
        Permission.VIEW_DASHBOARD,
    },
}


class RBACService:
    """Service for checking roles, hierarchy, and permissions on authenticated users."""

    @staticmethod
    def is_superadmin(user=None) -> bool:
        """Strictly verify whether the user holds the GLOBAL_SUPERADMIN role."""
        u = user if user is not None else current_user
        if not u or not getattr(u, 'is_authenticated', False):
            return False
        if not getattr(u, 'is_active', True):
            return False
        if getattr(u, 'account_status', 'active') in ('suspended', 'deactivated'):
            return False
        raw_role = (getattr(u, 'role', '') or '').strip().upper()
        return raw_role == Role.GLOBAL_SUPERADMIN

    @staticmethod
    def get_user_role(user=None):
        """Get canonical role for a user instance, defaulting to current_user."""
        u = user if user is not None else current_user
        if not u or not getattr(u, 'is_authenticated', False):
            return None
        raw_role = (getattr(u, 'role', 'Analyst') or 'Analyst').strip()
        if raw_role.upper() == Role.GLOBAL_SUPERADMIN:
            return Role.GLOBAL_SUPERADMIN
        normalized = raw_role.capitalize()
        if getattr(u, 'is_admin', False) and normalized not in (Role.OWNER, Role.ADMIN):
            return Role.ADMIN
        return normalized if normalized in ROLE_HIERARCHY else Role.ANALYST

    @staticmethod
    def has_role(required_role, user=None):
        """Check if user possesses at least the hierarchical level of required_role."""
        user_role = RBACService.get_user_role(user)
        if not user_role:
            return False
        raw_target = getattr(required_role, 'value', required_role)
        target_str = str(raw_target).strip()
        if target_str.upper() == Role.GLOBAL_SUPERADMIN:
            return user_role == Role.GLOBAL_SUPERADMIN
        target_role = target_str.capitalize()
        user_weight = ROLE_HIERARCHY.get(user_role, 0)
        req_weight = ROLE_HIERARCHY.get(target_role, 0)
        return user_weight >= req_weight

    @staticmethod
    def has_permission(permission, user=None):
        """Check if user possesses a specific named permission."""
        user_role = RBACService.get_user_role(user)
        if not user_role:
            return False
        perms = ROLE_PERMISSIONS.get(user_role, set())
        return permission in perms


def has_role(user, *roles):
    """Check if user has any of the specified roles or meets hierarchical requirement."""
    for r in roles:
        r_str = getattr(r, 'value', r)
        if RBACService.has_role(r_str, user):
            return True
    return False


def has_permission(user, permission):
    """Check if user has the specified permission."""
    p_str = getattr(permission, 'value', permission)
    return RBACService.has_permission(p_str, user)


def superadmin_required(f):
    """
    Strict server-side decorator for the Global Superadmin Control Plane.
    Denies all regular users and Company Administrators with 403 Forbidden and logs the attempt.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not current_user or not current_user.is_authenticated:
            if request.is_json or request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'error': 'Authentication required'}), 401
            return redirect(url_for('auth.login', next=request.path))

        if not RBACService.is_superadmin(current_user):
            try:
                from services.superadmin_service import SuperadminService
                SuperadminService.record_audit(
                    action='UNAUTHORIZED_SUPERADMIN_ACCESS_ATTEMPT',
                    category='SECURITY',
                    result_status='DENIED',
                    details=f"Non-superadmin user '{current_user.username}' (role={current_user.role}) attempted to access {request.path}"
                )
            except Exception:
                pass
            if request.is_json or request.path.startswith('/api/') or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({'success': False, 'error': 'Forbidden: Global Superadmin authority required'}), 403
            abort(403)

        # Enforce first-login password change on all Superadmin routes except the password-change and logout endpoints
        allowed_endpoints = {'superadmin.force_password_change', 'superadmin.mfa_verify', 'auth.logout'}
        if getattr(current_user, 'must_change_password', False) and request.endpoint not in allowed_endpoints:
            if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
                return jsonify({
                    'success': False,
                    'error': 'Mandatory initial password change required before executing administrative operations.',
                    'redirect': url_for('superadmin.force_password_change')
                }), 403
            flash('For platform security, you must change your initial bootstrap password before accessing the Global Superadmin Control Center.', 'warning')
            return redirect(url_for('superadmin.force_password_change'))

        return f(*args, **kwargs)
    return decorated_function


def roles_required(*allowed_roles):
    """Decorator restricting route access to users with one of the allowed roles (or higher)."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user or not current_user.is_authenticated:
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({'error': 'Authentication required'}), 401
                return redirect(url_for('auth.login'))

            user_role = RBACService.get_user_role()
            user_weight = ROLE_HIERARCHY.get(user_role, 0)

            allowed_weights = []
            for r in allowed_roles:
                r_str = str(getattr(r, 'value', r)).strip()
                if r_str.upper() == Role.GLOBAL_SUPERADMIN:
                    allowed_weights.append(ROLE_HIERARCHY[Role.GLOBAL_SUPERADMIN])
                else:
                    allowed_weights.append(ROLE_HIERARCHY.get(r_str.capitalize(), 0))
            min_allowed_weight = min(allowed_weights) if allowed_weights else 0

            if user_weight < min_allowed_weight:
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({'error': 'Forbidden: Insufficient role permissions'}), 403
                abort(403)

            return f(*args, **kwargs)
        return decorated_function
    return decorator


def permission_required(permission):
    """Decorator restricting route access to users with a specific permission."""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if not current_user or not current_user.is_authenticated:
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({'error': 'Authentication required'}), 401
                return redirect(url_for('auth.login'))

            perm_str = getattr(permission, 'value', permission)
            if not RBACService.has_permission(perm_str):
                if request.is_json or request.path.startswith('/api/'):
                    return jsonify({'error': f'Forbidden: Missing required permission {perm_str}'}), 403
                abort(403)

            return f(*args, **kwargs)
        return decorated_function
    return decorator


def admin_required(f):
    """Convenience decorator requiring Admin or Owner role."""
    return roles_required(Role.ADMIN)(f)
