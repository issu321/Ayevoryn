from flask import Blueprint, send_from_directory, abort, current_app, session, Response, request
from flask_login import login_required, current_user
import os
import uuid
import base64
from datetime import datetime
from werkzeug.utils import safe_join, secure_filename
from database.db import db
from database.models.company import Company
from database.models.user import User
from security.tenant import TenantContext

uploads_bp = Blueprint('uploads', __name__)

BLOCKED_EXTENSIONS = {
    'py', 'pyc', 'pyo', 'pyd', 'db', 'sqlite', 'sqlite3', 'env',
    'bak', 'log', 'sh', 'bat', 'cmd', 'ps1', 'exe', 'dll', 'so',
    'ini', 'cfg', 'conf', 'key', 'pem', 'cert', 'crt'
}

ALLOWED_IMAGE_MIMES = {
    'png': 'image/png',
    'jpg': 'image/jpeg',
    'jpeg': 'image/jpeg',
    'webp': 'image/webp',
    'gif': 'image/gif',
    'svg': 'image/svg+xml'
}

MAX_IMAGE_BYTES = 5 * 1024 * 1024  # 5 MB


def validate_and_extract_image(file_storage):
    if not file_storage or not getattr(file_storage, 'filename', None):
        return None, None, None, 'No image file selected'

    filename = secure_filename(file_storage.filename)
    if '.' not in filename:
        return None, None, None, 'File must have a valid image extension (PNG, JPG, WEBP, SVG, GIF)'

    ext = filename.rsplit('.', 1)[1].lower()
    if ext not in ALLOWED_IMAGE_MIMES:
        return None, None, None, f'Unsupported file extension .{ext}. Allowed: PNG, JPG, JPEG, WEBP, SVG, GIF'

    raw_bytes = file_storage.read()
    file_storage.seek(0)

    if not raw_bytes or len(raw_bytes) == 0:
        return None, None, None, 'Uploaded image file is empty'

    if len(raw_bytes) > MAX_IMAGE_BYTES:
        return None, None, None, 'Image exceeds maximum allowed size of 5 MB'

    header = raw_bytes[:512]
    is_valid_sig = False
    detected_mime = ALLOWED_IMAGE_MIMES[ext]

    if header.startswith(b'\x89PNG\r\n\x1a\n'):
        is_valid_sig = True
        detected_mime = 'image/png'
        ext = 'png'
    elif header.startswith(b'\xff\xd8\xff'):
        is_valid_sig = True
        detected_mime = 'image/jpeg'
        if ext not in ('jpg', 'jpeg'):
            ext = 'jpg'
    elif header.startswith((b'GIF87a', b'GIF89a')):
        is_valid_sig = True
        detected_mime = 'image/gif'
        ext = 'gif'
    elif header[:4] == b'RIFF' and header[8:12] == b'WEBP':
        is_valid_sig = True
        detected_mime = 'image/webp'
        ext = 'webp'
    elif ext == 'svg' and (b'<svg' in header.lower() or b'<?xml' in header.lower()):
        if b'<script' in raw_bytes.lower() or b'javascript:' in raw_bytes.lower():
            return None, None, None, 'SVG contains disallowed script content'
        is_valid_sig = True
        detected_mime = 'image/svg+xml'

    if not is_valid_sig:
        return None, None, None, 'Invalid or corrupted image file signature'

    return raw_bytes, ext, detected_mime, None


def persist_image_asset(raw_bytes: bytes, ext: str, category: str, prefix: str):
    fname = f"{prefix}_{uuid.uuid4().hex[:10]}.{ext}"
    relative_path = f"uploads/{category}/{fname}"

    root_dir = current_app.root_path if current_app else os.getcwd()
    static_target_dir = os.path.join(root_dir, 'static', 'uploads', category)
    os.makedirs(static_target_dir, exist_ok=True)
    static_file_path = os.path.join(static_target_dir, fname)
    with open(static_file_path, 'wb') as f:
        f.write(raw_bytes)

    upload_root = os.path.abspath(
        (current_app.config.get('UPLOAD_FOLDER') if current_app else None) or
        os.path.join(root_dir, 'uploads')
    )
    upload_target_dir = os.path.join(upload_root, category)
    os.makedirs(upload_target_dir, exist_ok=True)
    with open(os.path.join(upload_target_dir, fname), 'wb') as f:
        f.write(raw_bytes)

    b64_data = base64.b64encode(raw_bytes).decode('ascii')
    return relative_path, b64_data


def remove_persisted_files(relative_path: str):
    if not relative_path:
        return
    root_dir = current_app.root_path if current_app else os.getcwd()
    candidates = [
        os.path.join(root_dir, 'static', relative_path),
        os.path.join(
            os.path.abspath((current_app.config.get('UPLOAD_FOLDER') if current_app else None) or os.path.join(root_dir, 'uploads')),
            relative_path.replace('uploads/', '', 1)
        )
    ]
    for path in candidates:
        try:
            if os.path.exists(path) and os.path.isfile(path):
                os.remove(path)
        except Exception:
            pass


@uploads_bp.route('/media/company/<int:company_id>/logo')
@login_required
def serve_company_logo(company_id):
    active_cid = TenantContext.get_current_company_id()
    user_cid = getattr(current_user, 'company_id', None)
    is_superadmin = getattr(current_user, 'is_global_superadmin', False)

    if not is_superadmin and company_id != active_cid and company_id != user_cid:
        abort(403, description="Access denied: You do not have permission to view another organization's assets.")

    company = db.session.get(Company, company_id)
    if not company:
        abort(404)

    raw_bytes = None
    mime_type = company.logo_mime or 'image/png'

    if company.logo_data:
        try:
            raw_bytes = base64.b64decode(company.logo_data)
        except Exception:
            raw_bytes = None

    if company.logo_path:
        root_dir = current_app.root_path
        disk_path = os.path.join(root_dir, 'static', company.logo_path)
        if raw_bytes and not os.path.exists(disk_path):
            try:
                os.makedirs(os.path.dirname(disk_path), exist_ok=True)
                with open(disk_path, 'wb') as f:
                    f.write(raw_bytes)
            except Exception:
                pass
        elif not raw_bytes and os.path.exists(disk_path):
            try:
                with open(disk_path, 'rb') as f:
                    raw_bytes = f.read()
                ext = company.logo_path.rsplit('.', 1)[-1].lower() if '.' in company.logo_path else 'png'
                mime_type = ALLOWED_IMAGE_MIMES.get(ext, 'image/png')
                company.logo_data = base64.b64encode(raw_bytes).decode('ascii')
                company.logo_mime = mime_type
                company.logo_updated_at = company.logo_updated_at or datetime.utcnow()
                db.session.commit()
            except Exception:
                db.session.rollback()

    if not raw_bytes:
        abort(404)

    resp = Response(raw_bytes, mimetype=mime_type)
    resp.headers['Cache-Control'] = 'private, max-age=86400'
    return resp


@uploads_bp.route('/media/user/<int:user_id>/avatar')
@login_required
def serve_user_avatar(user_id):
    target_user = db.session.get(User, user_id)
    if not target_user:
        abort(404)

    active_cid = TenantContext.get_current_company_id()
    user_cid = getattr(current_user, 'company_id', None)
    is_superadmin = getattr(current_user, 'is_global_superadmin', False)

    if not is_superadmin and target_user.id != current_user.id:
        if target_user.company_id not in (active_cid, user_cid) or target_user.company_id is None:
            abort(403, description="Access denied: User belongs to another organization.")

    raw_bytes = None
    mime_type = target_user.avatar_mime or 'image/png'

    if target_user.avatar_data:
        try:
            raw_bytes = base64.b64decode(target_user.avatar_data)
        except Exception:
            raw_bytes = None

    if target_user.avatar_path:
        root_dir = current_app.root_path
        disk_path = os.path.join(root_dir, 'static', target_user.avatar_path)
        if raw_bytes and not os.path.exists(disk_path):
            try:
                os.makedirs(os.path.dirname(disk_path), exist_ok=True)
                with open(disk_path, 'wb') as f:
                    f.write(raw_bytes)
            except Exception:
                pass
        elif not raw_bytes and os.path.exists(disk_path):
            try:
                with open(disk_path, 'rb') as f:
                    raw_bytes = f.read()
                ext = target_user.avatar_path.rsplit('.', 1)[-1].lower() if '.' in target_user.avatar_path else 'png'
                mime_type = ALLOWED_IMAGE_MIMES.get(ext, 'image/png')
                target_user.avatar_data = base64.b64encode(raw_bytes).decode('ascii')
                target_user.avatar_mime = mime_type
                target_user.avatar_updated_at = target_user.avatar_updated_at or datetime.utcnow()
                db.session.commit()
            except Exception:
                db.session.rollback()

    if not raw_bytes:
        abort(404)

    resp = Response(raw_bytes, mimetype=mime_type)
    resp.headers['Cache-Control'] = 'private, max-age=86400'
    return resp


@uploads_bp.route('/<path:filename>')
@login_required
def uploaded_file(filename):
    if not filename:
        abort(404)

    basename = os.path.basename(filename)
    if basename.startswith('.') or '..' in filename:
        abort(404)

    ext = filename.rsplit('.', 1)[-1].lower() if '.' in filename else ''
    if ext in BLOCKED_EXTENSIONS:
        abort(404)

    upload_folder = os.path.abspath(
        current_app.config.get('UPLOAD_FOLDER') or
        os.path.join(current_app.root_path, 'uploads')
    )
    os.makedirs(upload_folder, exist_ok=True)

    safe_path = safe_join(upload_folder, filename)
    if not safe_path or not os.path.exists(safe_path) or os.path.isdir(safe_path):
        abort(404)

    resolved_path = os.path.abspath(safe_path)
    if not resolved_path.startswith(upload_folder + os.sep):
        abort(404)

    rel_dir = os.path.dirname(os.path.relpath(resolved_path, upload_folder))
    serve_dir = os.path.join(upload_folder, rel_dir) if rel_dir else upload_folder
    file_to_serve = os.path.basename(resolved_path)

    return send_from_directory(serve_dir, file_to_serve, as_attachment=False)