"""
AEVORYN / INSIGHT-PULSE
TWIN DEPENDENCY GRAPH ROUTES
Visual interactive graph explorer, blast-radius simulation, and dependency topology APIs.
"""

from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user
from security.tenant import get_current_company_id
from security.rbac import permission_required, Permission
from services.twin_dependency_service import TwinDependencyService
from services.impact_engine import ImpactEngine
from database.models.twin_dependency import DependencyType, TwinDependency
from database.models.impact_trace import ImpactSeverity
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.custom_twin import CustomTwin

twin_graph_bp = Blueprint('twin_graph', __name__)


@twin_graph_bp.route('/')
@login_required
def index():
    """Render the Interactive Digital Twin Dependency Graph interface."""
    company_id = get_current_company_id()
    graph_data = TwinDependencyService.build_graph(company_id)
    centrality = TwinDependencyService.get_centrality_metrics(company_id)
    
    # Preload entities for the Add Link modal
    departments = Department.query.filter_by(company_id=company_id).all()
    employees = Employee.query.filter_by(company_id=company_id).all()
    suppliers = Supplier.query.filter_by(company_id=company_id).all()
    customers = Customer.query.filter_by(company_id=company_id).all()
    custom_twins = CustomTwin.query.filter_by(company_id=company_id, is_active=True).all()
    
    entity_data = {
        'departments': [d.id for d in departments],
        'department_names': [d.name for d in departments],
        'employees': [e.id for e in employees],
        'employee_names': [e.name or f"Employee {e.id}" for e in employees],
        'suppliers': [s.id for s in suppliers],
        'supplier_names': [s.name for s in suppliers],
        'customers': [c.id for c in customers],
        'customer_names': [c.name or f"Customer {c.id}" for c in customers],
        'custom_twins': [t.id for t in custom_twins],
        'custom_twin_names': [t.name for t in custom_twins]
    }
    
    dept_map = TwinDependencyService.build_department_relationship_map(company_id)

    return render_template(
        'twin/dependency_graph.html',
        graph=graph_data,
        dept_map=dept_map,
        centrality=centrality,
        departments=departments,
        employees=employees,
        suppliers=suppliers,
        customers=customers,
        custom_twins=custom_twins,
        dependency_types=DependencyType.ALL,
        entity_data=entity_data
    )


@twin_graph_bp.route('/api/data')
@login_required
def api_graph_data():
    """JSON API returning graph nodes, edges, and structural summary."""
    company_id = get_current_company_id()
    types_arg = request.args.get('types')
    include_types = types_arg.split(',') if types_arg else None
    
    graph_data = TwinDependencyService.build_graph(company_id, include_types=include_types)
    return jsonify({
        'success': True,
        'data': graph_data
    })


@twin_graph_bp.route('/api/blast-radius/<path:node_id>')
@login_required
def api_blast_radius(node_id):
    """JSON API returning forward downstream impact blast radius for a node."""
    company_id = get_current_company_id()
    max_depth = request.args.get('depth', 5, type=int)
    types_arg = request.args.get('types')
    include_types = types_arg.split(',') if types_arg else None
    
    result = TwinDependencyService.get_blast_radius(
        company_id=company_id,
        node_id=node_id,
        max_depth=max_depth,
        dependency_types=include_types
    )
    return jsonify({
        'success': True,
        'data': result
    })


@twin_graph_bp.route('/api/lineage/<path:node_id>')
@login_required
def api_upstream_lineage(node_id):
    """JSON API returning upstream causal root causes for a node or metric."""
    company_id = get_current_company_id()
    max_depth = request.args.get('depth', 5, type=int)
    types_arg = request.args.get('types')
    include_types = types_arg.split(',') if types_arg else None
    
    result = TwinDependencyService.get_upstream_lineage(
        company_id=company_id,
        node_id=node_id,
        max_depth=max_depth,
        dependency_types=include_types
    )
    return jsonify({
        'success': True,
        'data': result
    })


@twin_graph_bp.route('/api/centrality')
@login_required
def api_centrality():
    """JSON API returning centrality analysis, single points of failure, and orphans."""
    company_id = get_current_company_id()
    metrics = TwinDependencyService.get_centrality_metrics(company_id)
    return jsonify({
        'success': True,
        'data': metrics
    })


@twin_graph_bp.route('/api/dependencies', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def api_add_dependency():
    """Create or update a user-configured or estimated twin dependency edge."""
    company_id = get_current_company_id()
    data = request.get_json() or {}
    
    source_type = data.get('source_type')
    source_id = data.get('source_id')
    target_type = data.get('target_type')
    target_id = data.get('target_id')
    dep_type = data.get('dependency_type', DependencyType.CONFIGURED)
    strength = data.get('strength', 1.0)
    description = data.get('description', '')
    metadata = data.get('metadata', {})
    
    if not (source_type and source_id and target_type and target_id):
        return jsonify({'success': False, 'error': 'Missing required source or target entity identifiers'}), 400
        
    try:
        actor_id = current_user.id if current_user and current_user.is_authenticated else None
        actor_name = current_user.username if current_user and current_user.is_authenticated else 'System'
        
        dep = TwinDependencyService.add_configured_dependency(
            company_id=company_id,
            source_type=str(source_type).strip(),
            source_id=str(source_id).strip(),
            target_type=str(target_type).strip(),
            target_id=str(target_id).strip(),
            dependency_type=dep_type,
            strength=strength,
            description=description,
            metadata=metadata,
            actor_id=actor_id,
            actor_name=actor_name
        )
        return jsonify({
            'success': True,
            'message': 'Dependency link established successfully',
            'dependency': dep.to_dict()
        }), 201
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': f'Failed to create dependency: {str(e)}'}), 500


@twin_graph_bp.route('/api/dependencies/<int:dep_id>', methods=['DELETE'])
@login_required
@permission_required(Permission.DATA_DELETE)
def api_delete_dependency(dep_id):
    """Delete a user-configured twin dependency edge."""
    company_id = get_current_company_id()
    actor_id = current_user.id if current_user and current_user.is_authenticated else None
    actor_name = current_user.username if current_user and current_user.is_authenticated else 'System'
    
    success = TwinDependencyService.delete_configured_dependency(
        company_id=company_id,
        dependency_id=dep_id,
        actor_id=actor_id,
        actor_name=actor_name
    )
    
    if not success:
        return jsonify({'success': False, 'error': 'Dependency not found or access denied'}), 404
        
    return jsonify({
        'success': True,
        'message': 'Dependency link removed successfully'
    })


# =========================================================================
# STAGE 12: IMPACT PROPAGATION & WHAT-IF SIMULATION APIS
# =========================================================================

@twin_graph_bp.route('/api/impact/simulate', methods=['POST'])
@login_required
def api_simulate_impact():
    """Execute an uncommitted what-if impact simulation on a digital twin node."""
    company_id = get_current_company_id()
    data = request.get_json() or {}
    
    root_type = data.get('root_type')
    root_id = data.get('root_id', '')
    delta_payload = data.get('delta_payload', {})
    
    if not root_type:
        return jsonify({'success': False, 'error': 'root_type is required for impact simulation'}), 400
        
    result = ImpactEngine.simulate_impact(
        company_id=company_id,
        root_type=str(root_type).strip(),
        root_id=str(root_id).strip(),
        delta_payload=delta_payload
    )
    
    return jsonify({
        'success': True,
        'data': result
    })


@twin_graph_bp.route('/api/impact/traces')
@login_required
def api_get_impact_traces():
    """List recent explainable impact propagation traces for the tenant."""
    company_id = get_current_company_id()
    limit = request.args.get('limit', 25, type=int)
    severity = request.args.get('severity')
    
    traces = ImpactEngine.get_recent_traces(
        company_id=company_id,
        limit=limit,
        severity=severity
    )
    
    return jsonify({
        'success': True,
        'count': len(traces),
        'data': traces
    })


@twin_graph_bp.route('/api/impact/traces/<string:trace_id>')
@login_required
def api_get_impact_trace_by_id(trace_id):
    """Retrieve an explainable causal trace with complete hop breakdown."""
    company_id = get_current_company_id()
    trace = ImpactEngine.get_trace_by_id(company_id, trace_id)
    
    if not trace:
        return jsonify({'success': False, 'error': 'Impact trace not found or access denied'}), 404
        
    return jsonify({
        'success': True,
        'data': trace
    })




# =========================================================================
# ENTERPRISE DEPARTMENT RELATIONSHIP MAP & DEPARTMENT CONFIGURATION APIS
# =========================================================================

@twin_graph_bp.route('/api/department-map')
@login_required
def api_department_map():
    """Return structured Enterprise Department Relationship Map data from database."""
    company_id = get_current_company_id()
    dept_map = TwinDependencyService.build_department_relationship_map(company_id)
    return jsonify({
        'success': True,
        'data': dept_map
    })


@twin_graph_bp.route('/api/departments', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def api_save_department():
    """Create or update an organizational department and synchronize across the platform."""
    from database.db import db
    from services.events import EventBus, DomainEvent, EventTypes

    company_id = get_current_company_id()
    data = request.get_json(silent=True) or request.form.to_dict() or {}

    dept_id = data.get('id') or data.get('department_id')
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({'success': False, 'error': 'Department name is required'}), 400

    code_val = (data.get('code') or name[:3].upper()).strip().upper()
    head_name = (data.get('head_name') or 'Department Head').strip()
    description = (data.get('description') or '').strip()
    responsibilities = (data.get('responsibilities') or '').strip()
    kpi_summary = (data.get('kpi_summary') or '').strip()
    color = (data.get('color') or '#2563EB').strip()

    try:
        budget = float(data.get('budget') or 0.0)
    except (ValueError, TypeError):
        budget = 0.0

    try:
        employee_count = int(data.get('employee_count') or 0)
    except (ValueError, TypeError):
        employee_count = 0

    try:
        hierarchy_level = int(data.get('hierarchy_level') or 2)
    except (ValueError, TypeError):
        hierarchy_level = 2

    parent_id_raw = data.get('parent_department_id')
    try:
        parent_department_id = int(parent_id_raw) if parent_id_raw else None
    except (ValueError, TypeError):
        parent_department_id = None

    if dept_id:
        dept = Department.query.filter_by(id=int(dept_id), company_id=company_id).first()
        if not dept:
            return jsonify({'success': False, 'error': 'Department not found or access denied'}), 404
        dept.name = name
        dept.code = code_val
        dept.head_name = head_name
        dept.budget = budget
        dept.employee_count = employee_count
        dept.description = description
        dept.responsibilities = responsibilities
        dept.kpi_summary = kpi_summary
        dept.color = color
        dept.hierarchy_level = hierarchy_level
        if parent_department_id != dept.id:
            dept.parent_department_id = parent_department_id
        action_msg = f"Department '{dept.name}' updated successfully."
    else:
        dept = Department(
            company_id=company_id,
            name=name,
            code=code_val,
            head_name=head_name,
            budget=budget,
            employee_count=employee_count,
            description=description,
            responsibilities=responsibilities,
            kpi_summary=kpi_summary,
            color=color,
            hierarchy_level=hierarchy_level,
            parent_department_id=parent_department_id,
            is_active=True
        )
        db.session.add(dept)
        action_msg = f"Department '{name}' created successfully."

    db.session.commit()

    # If parent_department_id was set, ensure a 'Reports To' relationship exists
    if dept.parent_department_id and dept.parent_department_id != dept.id:
        existing_rel = TwinDependency.query.filter_by(
            company_id=company_id,
            source_type='department',
            source_id=str(dept.id),
            target_type='department',
            target_id=str(dept.parent_department_id),
            is_active=True
        ).first()
        if not existing_rel:
            parent_dept = db.session.get(Department, dept.parent_department_id)
            p_name = parent_dept.name if parent_dept else f"Department #{dept.parent_department_id}"
            rel = TwinDependency(
                company_id=company_id,
                source_type='department',
                source_id=str(dept.id),
                target_type='department',
                target_id=str(dept.parent_department_id),
                dependency_type=DependencyType.CONFIGURED,
                strength=1.0,
                description=f"{dept.name} reports organizationally to {p_name}",
                created_by=current_user.id if current_user.is_authenticated else None
            )
            rel.set_metadata({'relationship_category': 'Reports To', 'mode': 'HIERARCHY'})
            db.session.add(rel)
            db.session.commit()

    try:
        EventBus.publish(DomainEvent(
            event_type=EventTypes.DEPARTMENT_UPDATED if hasattr(EventTypes, 'DEPARTMENT_UPDATED') else 'DEPARTMENT_UPDATED',
            company_id=company_id,
            actor_id=current_user.id if current_user.is_authenticated else None,
            actor_name=current_user.username if current_user.is_authenticated else 'System',
            entity_type='department',
            entity_id=str(dept.id),
            payload=dept.to_dict()
        ))
    except Exception:
        pass

    dept_map = TwinDependencyService.build_department_relationship_map(company_id)
    return jsonify({
        'success': True,
        'message': action_msg,
        'department': dept.to_dict(),
        'dept_map': dept_map
    })


@twin_graph_bp.route('/api/departments/<int:dept_id>', methods=['DELETE'])
@login_required
@permission_required(Permission.DATA_DELETE)
def api_delete_department(dept_id):
    """Deactivate/remove a department and its dependency links within the organization."""
    from database.db import db

    company_id = get_current_company_id()
    dept = Department.query.filter_by(id=dept_id, company_id=company_id).first()
    if not dept:
        return jsonify({'success': False, 'error': 'Department not found or access denied'}), 404

    dept.is_active = False
    # Deactivate associated department dependency links
    TwinDependency.query.filter(
        TwinDependency.company_id == company_id,
        db.or_(
            db.and_(TwinDependency.source_type == 'department', TwinDependency.source_id == str(dept_id)),
            db.and_(TwinDependency.target_type == 'department', TwinDependency.target_id == str(dept_id))
        )
    ).update({'is_active': False}, synchronize_session=False)

    db.session.commit()
    dept_map = TwinDependencyService.build_department_relationship_map(company_id)
    return jsonify({
        'success': True,
        'message': f"Department '{dept.name}' removed.",
        'dept_map': dept_map
    })


@twin_graph_bp.route('/api/department-relationships', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def api_add_department_relationship():
    """Create or update a structured inter-departmental relationship."""
    company_id = get_current_company_id()
    data = request.get_json(silent=True) or {}

    source_dept_id = str(data.get('source_dept_id') or data.get('source_id') or '').strip()
    target_dept_id = str(data.get('target_dept_id') or data.get('target_id') or '').strip()
    rel_cat = (data.get('relationship_category') or 'Collaborates With').strip()
    description = (data.get('description') or '').strip()

    if not source_dept_id or not target_dept_id:
        return jsonify({'success': False, 'error': 'Both source and target departments are required'}), 400
    if source_dept_id == target_dept_id:
        return jsonify({'success': False, 'error': 'A department cannot establish a relationship with itself'}), 400

    if rel_cat not in TwinDependencyService.RELATIONSHIP_CATEGORIES:
        rel_cat = 'Collaborates With'

    try:
        strength = float(data.get('strength') or 0.9)
    except (ValueError, TypeError):
        strength = 0.9

    src_dept = Department.query.filter_by(id=int(source_dept_id), company_id=company_id).first()
    tgt_dept = Department.query.filter_by(id=int(target_dept_id), company_id=company_id).first()
    if not src_dept or not tgt_dept:
        return jsonify({'success': False, 'error': 'Selected departments do not belong to your organization'}), 404

    if not description:
        description = f"{src_dept.name} {rel_cat.lower()} {tgt_dept.name}"

    mode = TwinDependencyService.RELATIONSHIP_MODE_MAP.get(rel_cat, 'OPERATIONAL')

    dep = TwinDependencyService.add_configured_dependency(
        company_id=company_id,
        source_type='department',
        source_id=source_dept_id,
        target_type='department',
        target_id=target_dept_id,
        dependency_type=DependencyType.CONFIGURED,
        strength=strength,
        description=description,
        metadata={'relationship_category': rel_cat, 'mode': mode},
        actor_id=current_user.id if current_user.is_authenticated else None,
        actor_name=current_user.username if current_user.is_authenticated else 'System'
    )

    if rel_cat == 'Reports To':
        src_dept.parent_department_id = tgt_dept.id
        from database.db import db
        db.session.commit()

    dept_map = TwinDependencyService.build_department_relationship_map(company_id)
    return jsonify({
        'success': True,
        'message': f"Relationship '{src_dept.name} → {rel_cat} → {tgt_dept.name}' created.",
        'dependency': dep.to_dict(),
        'dept_map': dept_map
    }), 201
