from flask import Blueprint, render_template, request, jsonify, session
from flask_login import login_required, current_user
from database.models.employee import Employee
from database.models.department import Department
from database.models.company import Company
from services.simulation_service import SimulationService
from security.rbac import permission_required, Permission
from config.constants import CURRENCY_SYMBOLS
from datetime import datetime

employee_bp = Blueprint('employee_simulator', __name__)


def _get_currency_symbol(company_id=None):
    """Get currency symbol from session or database."""
    currency_code = session.get('company_currency')
    if not currency_code and company_id:
        company = Company.query.get(company_id)
        currency_code = getattr(company, 'currency', None) if company else None
    if not currency_code:
        currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@employee_bp.route('/')
@employee_bp.route('/simulator')
@login_required
def index():
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol(company_id)
    employees = Employee.query.filter_by(company_id=company_id).order_by(Employee.created_at.desc()).all()
    departments = Department.query.filter_by(company_id=company_id).all()
    company = Company.query.get(company_id)
    total_employee_count = company.employee_count if company and company.employee_count else len(employees)

    return render_template(
        'employee/employee_simulator.html',
        employees=employees,
        departments=departments,
        total_employee_count=total_employee_count,
        company=company,
        currency_symbol=currency_symbol
    )


@employee_bp.route('/run', methods=['POST'])
@employee_bp.route('/simulator/run', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def run_employee_simulation():
    """
    Execute real workforce / hiring simulation backed by SimulationService and Monte Carlo distributions.
    """
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol(company_id)

    data = request.get_json(silent=True) or request.form or {}

    dept_id = data.get('department_id') or data.get('department')
    dept_name = 'General'
    if dept_id:
        try:
            dept_id = int(dept_id)
            dept = Department.query.filter_by(id=dept_id, company_id=company_id).first()
            if not dept:
                return jsonify({'error': 'Department not found'}), 404
            dept_name = dept.name
        except (ValueError, TypeError):
            pass

    role = str(data.get('role', 'Employee')).strip() or 'Employee'

    try:
        salary = float(data.get('salary', 75000.0))
    except (ValueError, TypeError):
        salary = 75000.0

    try:
        benefits = float(data.get('benefits', salary * 0.2))
    except (ValueError, TypeError):
        benefits = salary * 0.2

    try:
        headcount = int(data.get('headcount', 1))
        if headcount < 1:
            headcount = 1
    except (ValueError, TypeError):
        headcount = 1

    try:
        iterations = int(data.get('iterations', 1000))
    except (ValueError, TypeError):
        iterations = 1000

    try:
        volatility = float(data.get('volatility', 0.15))
    except (ValueError, TypeError):
        volatility = 0.15

    seed = data.get('seed')
    if seed is not None:
        try:
            seed = int(seed)
        except (ValueError, TypeError):
            seed = None

    params = {
        'role': role,
        'salary': salary,
        'benefits': benefits,
        'headcount': headcount,
        'department': dept_name,
        'department_id': dept_id,
        'iterations': iterations,
        'volatility': volatility,
        'seed': seed
    }

    sim_name = f"Hiring Simulation - {headcount}x {role} ({datetime.now().strftime('%Y-%m-%d %H:%M')})"
    sim = SimulationService.run_simulation(
        company_id=company_id,
        user_id=current_user.id,
        sim_type='employee_hiring',
        name=sim_name,
        parameters=params,
        currency_symbol=currency_symbol
    )

    sim_dict = sim.to_dict()
    res = sim.get_results()

    total_cost = (salary + benefits) * headcount
    productivity_gain = res.get('productivity_gain', total_cost * 2.5)
    roi_pct = res.get('roi_pct', ((productivity_gain - total_cost) / total_cost * 100) if total_cost > 0 else 0)

    return jsonify({
        'success': True,
        'simulation': sim_dict,
        'sim_id': sim.id,
        'role': role,
        'headcount': headcount,
        'department': dept_name,
        'salary': salary,
        'benefits': benefits,
        'total_cost': total_cost,
        'annual_cost': total_cost,
        'productivity_gain': productivity_gain,
        'roi_pct': roi_pct,
        'revenue_before': sim.revenue_before,
        'revenue_after': sim.revenue_after,
        'cost_before': sim.cost_before,
        'cost_after': sim.cost_after,
        'profit_before': sim.profit_before,
        'profit_after': sim.profit_after,
        'p10_profit': res.get('p10_profit'),
        'p50_profit': res.get('p50_profit'),
        'p90_profit': res.get('p90_profit'),
        'confidence_low': sim.confidence_low,
        'confidence_high': sim.confidence_high,
        'monte_carlo': res.get('monte_carlo', {}),
        'recommendations': sim.recommendations
    })
