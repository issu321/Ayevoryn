"""
AEVORYN / INSIGHT-PULSE
TEMPORAL DIGITAL TWIN ROUTES (STAGE 13)
Interactive time travel, historical state reconstruction, milestone snapshotting, and variance diff APIs.
"""

from datetime import datetime
from flask import Blueprint, render_template, request, jsonify
from flask_login import login_required, current_user

from security.tenant import get_current_company_id
from security.rbac import permission_required, Permission
from services.temporal_service import TemporalService
from database.models.twin_snapshot import SnapshotType

temporal_bp = Blueprint('temporal', __name__)


@temporal_bp.route('/')
@login_required
def index():
    """Render the Temporal Digital Twin interface."""
    company_id = get_current_company_id()
    now = datetime.utcnow()
    current_state = TemporalService.reconstruct_state_as_of(company_id, now)
    snapshots = TemporalService.get_snapshots(company_id, limit=20)

    return render_template(
        'twin/temporal_twin.html',
        current_state=current_state,
        snapshots=snapshots,
        snapshot_types=SnapshotType.ALL,
        today_date=now.strftime('%Y-%m-%d')
    )


@temporal_bp.route('/api/state-as-of')
@login_required
def api_state_as_of():
    """JSON API returning reconstructed digital twin state as of a historical date."""
    company_id = get_current_company_id()
    date_str = request.args.get('date')

    if date_str:
        try:
            # Support both date (YYYY-MM-DD) and datetime formats
            if len(date_str) == 10:
                as_of = datetime.strptime(date_str, '%Y-%m-%d')
            else:
                as_of = datetime.fromisoformat(date_str)
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid date format. Use YYYY-MM-DD or ISO 8601.'}), 400
    else:
        as_of = datetime.utcnow()

    try:
        state = TemporalService.reconstruct_state_as_of(company_id, as_of)
        return jsonify({
            'success': True,
            'data': state
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@temporal_bp.route('/api/snapshots', methods=['GET'])
@login_required
def api_list_snapshots():
    """List frozen digital twin snapshots for the current tenant."""
    company_id = get_current_company_id()
    limit = request.args.get('limit', 50, type=int)
    snap_type = request.args.get('type')

    snapshots = TemporalService.get_snapshots(company_id, limit=limit, snapshot_type=snap_type)
    return jsonify({
        'success': True,
        'count': len(snapshots),
        'data': snapshots
    })


@temporal_bp.route('/api/snapshots', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def api_create_snapshot():
    """Capture and freeze the digital twin's state as a permanent historical snapshot."""
    company_id = get_current_company_id()
    data = request.get_json() or {}

    name = data.get('name')
    if not name or not str(name).strip():
        return jsonify({'success': False, 'error': 'Snapshot name is required'}), 400

    snap_type = data.get('snapshot_type', SnapshotType.MANUAL)
    description = data.get('description', '')
    as_of_str = data.get('as_of')

    as_of = None
    if as_of_str:
        try:
            if len(as_of_str) == 10:
                as_of = datetime.strptime(as_of_str, '%Y-%m-%d')
            else:
                as_of = datetime.fromisoformat(as_of_str)
        except ValueError:
            return jsonify({'success': False, 'error': 'Invalid as_of timestamp format'}), 400

    try:
        user_id = current_user.id if current_user and current_user.is_authenticated else None
        user_name = current_user.username if current_user and current_user.is_authenticated else 'System'

        snapshot = TemporalService.create_snapshot(
            company_id=company_id,
            name=name,
            snapshot_type=snap_type,
            as_of=as_of,
            description=description,
            user_id=user_id,
            actor_name=user_name
        )

        return jsonify({
            'success': True,
            'message': f"Snapshot '{snapshot.name}' frozen successfully",
            'snapshot': snapshot.to_dict()
        }), 201
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': f"Failed to capture snapshot: {str(e)}"}), 500


@temporal_bp.route('/api/snapshots/<string:snapshot_id>', methods=['GET'])
@login_required
def api_get_snapshot(snapshot_id):
    """Retrieve a single snapshot with full payload."""
    company_id = get_current_company_id()
    snapshot = TemporalService.get_snapshot_by_id(company_id, snapshot_id)

    if not snapshot:
        return jsonify({'success': False, 'error': 'Snapshot not found or access denied'}), 404

    return jsonify({
        'success': True,
        'data': snapshot
    })


@temporal_bp.route('/api/snapshots/<string:snapshot_id>', methods=['DELETE'])
@login_required
@permission_required(Permission.DATA_DELETE)
def api_delete_snapshot(snapshot_id):
    """Delete a historical snapshot."""
    company_id = get_current_company_id()
    user_id = current_user.id if current_user and current_user.is_authenticated else None
    user_name = current_user.username if current_user and current_user.is_authenticated else 'System'

    success = TemporalService.delete_snapshot(
        company_id=company_id,
        snapshot_id=snapshot_id,
        actor_id=user_id,
        actor_name=user_name
    )

    if not success:
        return jsonify({'success': False, 'error': 'Snapshot not found or access denied'}), 404

    return jsonify({
        'success': True,
        'message': 'Snapshot deleted successfully'
    })


@temporal_bp.route('/api/diff')
@login_required
def api_compare_diff():
    """Compare two snapshots or two historical dates to calculate multi-dimensional variance."""
    company_id = get_current_company_id()

    base_id = request.args.get('base_snapshot')
    target_id = request.args.get('target_snapshot')

    if base_id and target_id:
        diff = TemporalService.compare_snapshots(company_id, base_id, target_id)
        if not diff:
            return jsonify({'success': False, 'error': 'One or both snapshots not found or access denied'}), 404
        return jsonify({'success': True, 'data': diff})

    date_a_str = request.args.get('date_a')
    date_b_str = request.args.get('date_b')

    if date_a_str and date_b_str:
        try:
            date_a = datetime.strptime(date_a_str[:10], '%Y-%m-%d')
            date_b = datetime.strptime(date_b_str[:10], '%Y-%m-%d')
            diff = TemporalService.compare_historical_dates(company_id, date_a, date_b)
            return jsonify({'success': True, 'data': diff})
        except Exception as e:
            return jsonify({'success': False, 'error': f"Failed to calculate date diff: {str(e)}"}), 400

    return jsonify({'success': False, 'error': 'Must provide either (base_snapshot, target_snapshot) or (date_a, date_b)'}), 400
