from flask import Blueprint, render_template, redirect, url_for
from flask_login import current_user

public_bp = Blueprint('public', __name__)

@public_bp.route('/')
def home():
    """AEVORYN Enterprise Digital Twin & Decision Intelligence Public Landing Page."""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard.index'))
    return render_template('landing/index.html', active_page='home')

@public_bp.route('/architecture')
def architecture():
    """AEVORYN Enterprise Digital Twin Architecture Deep-Dive."""
    return render_template('landing/architecture.html', active_page='architecture')

@public_bp.route('/features')
def features():
    """AEVORYN Comprehensive Simulator Features & Capabilities Tour."""
    return render_template('landing/features.html', active_page='features')

@public_bp.route('/decision-models')
def decision_models():
    """AEVORYN Causal Decision Models & Stochastic Simulation Showcase."""
    return render_template('landing/decision_models.html', active_page='decision_models')

@public_bp.route('/dependency-intelligence')
def dependency_intelligence():
    """AEVORYN Enterprise Department Relationship & Dependency Graph Overview."""
    return render_template('landing/dependency_intelligence.html', active_page='dependency_intelligence')
