"""
FORECASTING ROUTES - Enterprise Predictive Intelligence Blueprint.
Stage 16: Rigorous RBAC, strict tenant IDOR protection (abort 404),
model registry transparency, holdout backtest evaluation, and data readiness gating.
"""

from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from database.db import db
from database.models.forecast import (
    Forecast, ForecastResult, ForecastModelFamily, DataReadinessLevel, ForecastStatus
)
from services.forecast_service import ForecastService
from services.forecasting import ForecastModelRegistry, DataReadinessService
from security.rbac import permission_required, Permission, Role, roles_required
from config.constants import CURRENCY_SYMBOLS
from datetime import datetime
import logging

logger = logging.getLogger(__name__)

forecasting_bp = Blueprint('forecasting', __name__)

DEFAULT_FORECAST_TYPES = [
    'revenue', 'profit', 'demand', 'customer', 'market',
    'cashflow', 'expense', 'expansion', 'risk', 'opportunity'
]
DEFAULT_FORECAST_LABELS = {
    'revenue': 'Revenue Forecast',
    'profit': 'Profit Forecast',
    'demand': 'Demand Forecast',
    'customer': 'Customer Growth Forecast',
    'market': 'Market Growth Forecast',
    'cashflow': 'Cash Flow Forecast',
    'expense': 'Expense Forecast',
    'expansion': 'Expansion Forecast',
    'risk': 'Risk Forecast',
    'opportunity': 'Opportunity Forecast'
}
DEFAULT_METHODS = ['linear_regression', 'moving_average', 'exponential_smoothing', 'arima', 'prophet', 'weighted_ensemble', 'auto']
DEFAULT_HORIZONS = [30, 90, 180, 365, 1095, 1825]


def _get_forecast_config():
    return DEFAULT_FORECAST_TYPES, DEFAULT_FORECAST_LABELS, DEFAULT_METHODS, DEFAULT_HORIZONS


def _get_currency_symbol():
    if 'currency_symbol' in session:
        return session['currency_symbol']
    currency = session.get('company_currency', 'USD')
    return CURRENCY_SYMBOLS.get(currency, '$')


def _get_metric_format(forecast_type):
    if forecast_type in {'customer'}:
        return {'is_currency': False, 'suffix': ' users', 'prefix': '', 'title': 'Customer Base (Users)'}
    elif forecast_type in {'demand'}:
        return {'is_currency': False, 'suffix': ' units', 'prefix': '', 'title': 'Product Demand (Units)'}
    elif forecast_type in {'risk'}:
        return {'is_currency': False, 'suffix': ' / 100', 'prefix': '', 'title': 'Risk Score (0–100)'}
    elif forecast_type in {'expansion'}:
        return {'is_currency': False, 'suffix': ' idx', 'prefix': '', 'title': 'Expansion Index (0–100)'}
    elif forecast_type in {'headcount'}:
        return {'is_currency': False, 'suffix': ' staff', 'prefix': '', 'title': 'Headcount (Employees)'}
    elif forecast_type in {'churn', 'lead_conversion'}:
        return {'is_currency': False, 'suffix': '%', 'prefix': '', 'title': 'Conversion Rate (%)'}
    else:
        return {'is_currency': True, 'suffix': '', 'prefix': True, 'title': f'{forecast_type.replace("_", " ").title()}'}


def _get_historical_baseline(company_id, forecast_type, days=60):
    try:
        readiness = DataReadinessService.assess_readiness(company_id, forecast_type, allow_synthetic_fallback=True)
        baseline_df = readiness.baseline_df
        if baseline_df is not None and not baseline_df.empty:
            tail_df = baseline_df.tail(days)
            historical_records = []
            for _, row in tail_df.iterrows():
                d_val = row['ds']
                d_str = d_val.strftime('%Y-%m-%d') if hasattr(d_val, 'strftime') else str(d_val)[:10]
                historical_records.append({'date': d_str, 'value': round(float(row['y']), 2)})
            return historical_records
    except Exception as e:
        logger.warning(f"Error fetching historical baseline for {forecast_type}: {e}")
    return []


@forecasting_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    forecasts = Forecast.query.filter_by(company_id=company_id).order_by(Forecast.created_at.desc()).limit(50).all()

    ft, fl, m, h = _get_forecast_config()
    currency_symbol = _get_currency_symbol()

    view_forecast = None
    results = None
    historical_records = []
    summary = None
    metric_format = _get_metric_format('revenue')
    readiness_report = None

    if forecasts:
        view_forecast = next((f for f in forecasts if f.status == ForecastStatus.COMPLETED), forecasts[0])
        results = ForecastResult.query.filter_by(forecast_id=view_forecast.id).order_by(ForecastResult.date).all()
        historical_records = _get_historical_baseline(view_forecast.company_id, view_forecast.forecast_type)
        metric_format = _get_metric_format(view_forecast.forecast_type)
        summary = _calculate_summary(results, view_forecast)
        readiness_report = DataReadinessService.assess_readiness(company_id, view_forecast.forecast_type).to_dict()
    else:
        readiness_report = DataReadinessService.assess_readiness(company_id, 'revenue').to_dict()

    registered_models = ForecastModelRegistry.list_models()

    return render_template('forecasting/forecast_lab.html',
                         forecasts=forecasts,
                         forecast_types=ft,
                         forecast_labels=fl,
                         methods=m,
                         horizons=h,
                         view_forecast=view_forecast,
                         results=results,
                         historical=historical_records,
                         summary=summary,
                         metric_format=metric_format,
                         currency_symbol=currency_symbol,
                         registered_models=registered_models,
                         readiness=readiness_report)


@forecasting_bp.route('/run', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def run_forecast():
    company_id = session.get('company_id')
    forecast_type = request.form.get('forecast_type', 'revenue')
    method = request.form.get('method', 'linear_regression')
    horizon = int(request.form.get('horizon_days', 90))
    name = request.form.get('name', '').strip()
    allow_heuristic = request.form.get('allow_heuristic') in ('1', 'true', 'True', 'on')
    currency_symbol = _get_currency_symbol()

    if not name:
        _, fl, _, _ = _get_forecast_config()
        name = f"{fl.get(forecast_type, 'Forecast').title()} - {datetime.now().strftime('%Y-%m-%d')}"

    forecast = ForecastService.generate_forecast(
        company_id, current_user.id, forecast_type, method, horizon, name,
        currency_symbol=currency_symbol, allow_heuristic=allow_heuristic
    )

    if forecast.status == ForecastStatus.COMPLETED:
        if forecast.is_synthetic_heuristic:
            flash(f'Heuristic scenario projection "{name}" generated successfully.', 'warning')
        else:
            flash(f'Empirical forecast "{name}" generated successfully and validated via out-of-sample backtesting.', 'success')
        return redirect(url_for('forecasting.view', forecast_id=forecast.id))
    elif forecast.status == ForecastStatus.INSUFFICIENT_DATA:
        flash(f'Insufficient data: {forecast.summary}', 'danger')
        return redirect(url_for('forecasting.index'))
    else:
        flash(f'Forecast generated with notes: {forecast.summary}', 'warning')
        return redirect(url_for('forecasting.view', forecast_id=forecast.id))


@forecasting_bp.route('/rerun/<int:forecast_id>', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def rerun_forecast(forecast_id):
    """Re-execute a forecast with tenant IDOR check."""
    company_id = session.get('company_id')
    forecast = Forecast.query.get_or_404(forecast_id)
    if forecast.company_id != company_id:
        abort(404)

    currency_symbol = _get_currency_symbol()
    allow_heuristic = request.form.get('allow_heuristic') in ('1', 'true', 'on')
    ForecastService.rerun_forecast(forecast.id, currency_symbol=currency_symbol, allow_heuristic=allow_heuristic)
    flash(f'Forecast "{forecast.name}" re-calculated and healed successfully with out-of-sample validation.', 'success')
    return redirect(url_for('forecasting.view', forecast_id=forecast.id))


@forecasting_bp.route('/delete/<int:forecast_id>', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def delete_forecast(forecast_id):
    """Delete a forecast record and its cascaded results with tenant IDOR check."""
    company_id = session.get('company_id')
    forecast = Forecast.query.get_or_404(forecast_id)
    if forecast.company_id != company_id:
        abort(404)

    name = forecast.name
    ForecastService.delete_forecast(forecast.id, company_id=company_id)
    flash(f'Forecast "{name}" deleted successfully.', 'info')
    return redirect(url_for('forecasting.index'))


@forecasting_bp.route('/view/<int:forecast_id>')
@login_required
def view(forecast_id):
    company_id = session.get('company_id')
    forecast = Forecast.query.get_or_404(forecast_id)
    if forecast.company_id != company_id:
        abort(404)

    results = ForecastResult.query.filter_by(forecast_id=forecast_id).order_by(ForecastResult.date).all()
    historical_records = _get_historical_baseline(forecast.company_id, forecast.forecast_type)

    ft, fl, m, h = _get_forecast_config()
    currency_symbol = _get_currency_symbol()
    metric_format = _get_metric_format(forecast.forecast_type)
    summary = _calculate_summary(results, forecast)
    readiness_report = DataReadinessService.assess_readiness(company_id, forecast.forecast_type).to_dict()
    registered_models = ForecastModelRegistry.list_models()

    return render_template('forecasting/forecast_lab.html',
                         view_forecast=forecast,
                         results=results,
                         historical=historical_records,
                         forecasts=Forecast.query.filter_by(company_id=company_id).order_by(Forecast.created_at.desc()).limit(50).all(),
                         forecast_types=ft,
                         forecast_labels=fl,
                         methods=m,
                         horizons=h,
                         summary=summary,
                         metric_format=metric_format,
                         currency_symbol=currency_symbol,
                         registered_models=registered_models,
                         readiness=readiness_report)


@forecasting_bp.route('/api/data/<int:forecast_id>')
@login_required
def api_data(forecast_id):
    forecast = Forecast.query.get_or_404(forecast_id)
    if forecast.company_id != session.get('company_id'):
        return jsonify({'error': 'Access denied'}), 404

    results = ForecastResult.query.filter_by(forecast_id=forecast_id).order_by(ForecastResult.date).all()
    historical_records = _get_historical_baseline(forecast.company_id, forecast.forecast_type)
    return jsonify({
        'forecast': forecast.to_dict(include_backtest=True),
        'historical': historical_records,
        'data': [{
            'date': r.date.isoformat(),
            'value': r.value,
            'lower': r.lower_bound,
            'upper': r.upper_bound
        } for r in results]
    })


@forecasting_bp.route('/api/readiness/<forecast_type>')
@login_required
def api_readiness(forecast_type):
    company_id = session.get('company_id')
    report = DataReadinessService.assess_readiness(company_id, forecast_type)
    return jsonify(report.to_dict())


@forecasting_bp.route('/api/compare-models')
@login_required
def api_compare_models():
    company_id = session.get('company_id')
    forecast_type = request.args.get('forecast_type', 'revenue')
    horizon_days = int(request.args.get('horizon_days', 90))
    allow_heuristic = request.args.get('allow_heuristic') in ('1', 'true')
    comp = ForecastService.compare_models(company_id, forecast_type, horizon_days, allow_heuristic=allow_heuristic)
    return jsonify(comp)


@forecasting_bp.route('/api/models')
@login_required
def api_models():
    company_id = session.get('company_id')
    forecast_type = request.args.get('forecast_type', 'revenue')
    report = DataReadinessService.assess_readiness(company_id, forecast_type)
    return jsonify({
        'models': ForecastModelRegistry.to_dict(observation_count=report.distinct_dates_count),
        'readiness': report.to_dict()
    })


def _calculate_summary(results, forecast):
    if not results or len(results) < 2:
        return None

    values = [r.value for r in results]
    lowers = [r.lower_bound for r in results if r.lower_bound is not None]
    uppers = [r.upper_bound for r in results if r.upper_bound is not None]

    first_val = values[0]
    last_val = values[-1]
    change = last_val - first_val
    change_pct = (change / first_val * 100) if first_val != 0 else 0

    avg_val = sum(values) / len(values)
    max_val = max(values)
    min_val = min(values)

    trend = "upward" if last_val > first_val else "downward" if last_val < first_val else "stable"
    volatility = ((max_val - min_val) / avg_val * 100) if avg_val != 0 else 0

    confidence_width = 0
    if lowers and uppers:
        avg_width = sum(u - l for u, l in zip(uppers, lowers)) / len(lowers)
        confidence_width = (avg_width / avg_val * 100) if avg_val != 0 else 0

    ftype = forecast.forecast_type if forecast else 'revenue'
    if ftype in {'risk'}:
        if trend == 'downward':
            recommendation = "Enterprise risk trajectory is declining favorably due to active mitigation controls."
        elif trend == 'upward':
            recommendation = "Projected increase in risk exposure. Prioritize operational safety and compliance contingencies."
        else:
            recommendation = "Enterprise risk profile is stable within acceptable tolerance limits."
    elif ftype in {'customer', 'demand', 'opportunity', 'market', 'expansion'}:
        if trend == "upward" and change_pct > 10:
            recommendation = f"Strong expansion in {ftype} projected (+{change_pct:.1f}%). Scale operational and fulfillment capacity."
        elif trend == "upward":
            recommendation = f"Steady positive growth in {ftype}. Maintain pipeline momentum."
        elif trend == "downward":
            recommendation = f"Potential contraction detected in {ftype}. Review acquisition and engagement initiatives."
        else:
            recommendation = f"{ftype.title()} metrics are projected to remain stable across the planning horizon."
    else:
        if trend == "upward" and change_pct > 10:
            recommendation = "Strong positive financial trend detected. Increase capital allocation to capture high-margin growth."
        elif trend == "upward":
            recommendation = "Moderate upward trajectory expected. Maintain current operating expenditure discipline."
        elif trend == "downward" and change_pct < -10:
            recommendation = "Significant contraction projected. Review variable cost structure and adjust cash buffers immediately."
        elif trend == "downward":
            recommendation = "Slight contraction ahead. Focus on margin preservation and customer retention."
        else:
            recommendation = "Stable performance expected across the forecast period. Optimal environment for strategic investments."

    return {
        'first_value': first_val,
        'last_value': last_val,
        'change': change,
        'change_pct': change_pct,
        'trend': trend,
        'volatility': volatility,
        'confidence_width': confidence_width,
        'average': avg_val,
        'max': max_val,
        'min': min_val,
        'recommendation': recommendation,
        'direction_icon': '↑' if trend == 'upward' else '↓' if trend == 'downward' else '→',
        'direction_color': 'success' if (trend == 'upward' and ftype != 'risk') or (trend == 'downward' and ftype == 'risk') else 'danger' if (trend == 'downward' and ftype != 'risk') or (trend == 'upward' and ftype == 'risk') else 'warning'
    }