import json
import csv
import io
from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from database.models.competitor import Competitor
from database.models.company import Company
from services.competition_service import CompetitionService
from security.rbac import permission_required, Permission
from config.constants import CURRENCY_SYMBOLS

competition_bp = Blueprint('competition', __name__)


def _get_currency_symbol():
    currency_code = session.get('company_currency')
    if not currency_code:
        company = Company.query.get(session.get('company_id'))
        currency_code = getattr(company, 'currency', None) if company else None
        if not currency_code:
            currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@competition_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    summary = CompetitionService.get_competition_summary(company_id)
    competitors = summary['competitors'] if summary else []
    currency_symbol = _get_currency_symbol()
    
    return render_template(
        'market/competition_analysis.html', 
        competitors=competitors,
        summary=summary,
        currency_symbol=currency_symbol
    )


@competition_bp.route('/create', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def create():
    company_id = session.get('company_id')
    name = request.form.get('name', '').strip()
    if not name:
        flash('Competitor name is required.', 'danger')
        return redirect(url_for('competition.index'))

    data = {
        'name': name,
        'website': request.form.get('website'),
        'industry': request.form.get('industry'),
        'market_share': request.form.get('market_share'),
        'revenue_estimate': request.form.get('revenue_estimate'),
        'employee_count': request.form.get('employee_count'),
        'market_position': request.form.get('market_position') or 'Challenger',
        'threat_level': request.form.get('threat_level') or 'medium',
        'strengths': request.form.get('strengths'),
        'weaknesses': request.form.get('weaknesses'),
        'pricing_strategy': request.form.get('pricing_strategy'),
        'notes': request.form.get('notes'),
        'source': 'MANUAL',
        'is_benchmark': False
    }

    try:
        CompetitionService.create_competitor(company_id, data, actor_user_id=current_user.id)
        flash(f"Competitor '{name}' successfully added.", 'success')
    except Exception as e:
        flash(f"Failed to create competitor: {str(e)}", 'danger')

    return redirect(url_for('competition.index'))


@competition_bp.route('/update/<int:competitor_id>', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def update(competitor_id):
    company_id = session.get('company_id')
    data = {
        'name': request.form.get('name'),
        'website': request.form.get('website'),
        'industry': request.form.get('industry'),
        'market_share': request.form.get('market_share'),
        'revenue_estimate': request.form.get('revenue_estimate'),
        'employee_count': request.form.get('employee_count'),
        'market_position': request.form.get('market_position'),
        'threat_level': request.form.get('threat_level'),
        'strengths': request.form.get('strengths'),
        'weaknesses': request.form.get('weaknesses'),
        'pricing_strategy': request.form.get('pricing_strategy'),
        'notes': request.form.get('notes')
    }

    comp = CompetitionService.update_competitor(
        company_id, competitor_id, data, actor_user_id=current_user.id
    )
    if not comp:
        abort(404)

    flash(f"Competitor '{comp.name}' updated successfully.", 'success')
    return redirect(url_for('competition.index'))


@competition_bp.route('/delete/<int:competitor_id>', methods=['POST'])
@login_required
@permission_required(Permission.DATA_DELETE)
def delete(competitor_id):
    company_id = session.get('company_id')
    deleted = CompetitionService.delete_competitor(
        company_id, competitor_id, actor_user_id=current_user.id
    )
    if not deleted:
        abort(404)

    flash('Competitor successfully deleted.', 'success')
    return redirect(url_for('competition.index'))


@competition_bp.route('/import', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def import_competitors():
    company_id = session.get('company_id')
    raw_json = request.form.get('import_data', '').strip()
    file = request.files.get('file')

    records = []
    if file and file.filename:
        filename = file.filename.lower()
        if filename.endswith('.json'):
            try:
                records = json.load(file)
            except Exception as e:
                flash(f"Invalid JSON file: {str(e)}", 'danger')
                return redirect(url_for('competition.index'))
        elif filename.endswith('.csv'):
            try:
                stream = io.StringIO(file.stream.read().decode('utf-8', errors='replace'), newline=None)
                reader = csv.DictReader(stream)
                records = list(reader)
            except Exception as e:
                flash(f"Invalid CSV file: {str(e)}", 'danger')
                return redirect(url_for('competition.index'))
    elif raw_json:
        try:
            parsed = json.loads(raw_json)
            records = parsed if isinstance(parsed, list) else [parsed]
        except Exception as e:
            flash(f"Invalid JSON text: {str(e)}", 'danger')
            return redirect(url_for('competition.index'))

    if not records:
        flash('No valid records found to import.', 'warning')
        return redirect(url_for('competition.index'))

    created = CompetitionService.import_competitors(company_id, records, actor_user_id=current_user.id)
    flash(f"Successfully imported {len(created)} competitors.", 'success')
    return redirect(url_for('competition.index'))


@competition_bp.route('/load-templates', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def load_templates():
    company_id = session.get('company_id')
    created = CompetitionService.load_industry_benchmark_templates(
        company_id, actor_user_id=current_user.id
    )
    flash(f"Loaded {len(created)} reference benchmark competitors for your industry.", 'success')
    return redirect(url_for('competition.index'))


@competition_bp.route('/refresh', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def refresh():
    company_id = session.get('company_id')
    CompetitionService.refresh_competitors(company_id)
    flash('Competitor benchmark landscape recalibrated.', 'success')
    return redirect(url_for('competition.index'))


@competition_bp.route('/api/summary')
@login_required
def api_summary():
    company_id = session.get('company_id')
    summary = CompetitionService.get_competition_summary(company_id)
    if not summary:
        return jsonify({'error': 'No data available'}), 404

    data = {k: v for k, v in summary.items() if k not in ('competitors', 'market_leader')}
    data['competitors'] = [c.to_dict() for c in summary['competitors']]
    data['market_leader'] = summary['market_leader'].to_dict() if summary.get('market_leader') else None
    return jsonify(data)


@competition_bp.route('/api/competitors')
@login_required
def api_competitors():
    company_id = session.get('company_id')
    competitors = CompetitionService.get_competitors(company_id)
    return jsonify([c.to_dict() for c in competitors])
