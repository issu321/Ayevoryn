"""
AEVORYN PULSE AI — ENTERPRISE INTELLIGENCE WORKSPACE ROUTES
Strictly enforces server-side multi-tenant company_id derivation (never trusts client-supplied company_id).
Supports persistent conversations, controlled tool confirmation, and real SSE progressive streaming.
"""

import json
import time
import re
from flask import Blueprint, render_template, request, jsonify, session, Response, stream_with_context, redirect, url_for
from flask_login import login_required, current_user

from database.db import db
from database.models.company import Company
from database.models.pulse_ai import AIConversation, AIMessage, AIToolExecution
from security.tenant import get_current_company_id
from services.pulse_ai_engine import PulseAIEngine, PulseAIProviderManager, PulseAIContextRetriever

pulse_ai_bp = Blueprint('pulse_ai', __name__, url_prefix='/pulse-ai')


def _get_verified_tenant_company_id() -> int:
    """
    Strictly derive the organization scope from the authenticated server-side session and user record.
    Never trusts any organization ID sent in request body or query parameters.
    """
    cid = getattr(current_user, 'company_id', None) or get_current_company_id() or session.get('company_id')
    if cid:
        return int(cid)
    first_c = Company.query.first()
    return first_c.id if first_c else None


@pulse_ai_bp.route('/')
@login_required
def workspace():
    """Render the dedicated Pulse AI Enterprise Intelligence Workspace."""
    cid = _get_verified_tenant_company_id()
    if not cid:
        return redirect(url_for('auth.login'))

    company = db.session.get(Company, cid)
    conversations = PulseAIEngine.list_conversations(cid, current_user.id, limit=30)
    provider_status = PulseAIProviderManager.get_provider_status()

    return render_template(
        'ai/pulse_ai_workspace.html',
        company=company,
        conversations=conversations,
        provider_status=provider_status
    )


@pulse_ai_bp.route('/api/status')
@login_required
def api_status():
    cid = _get_verified_tenant_company_id()
    comp = db.session.get(Company, cid) if cid else None
    status = PulseAIProviderManager.get_provider_status()
    return jsonify({
        'success': True,
        'provider': status,
        'tenant': {
            'company_id': comp.id if comp else None,
            'company_name': comp.company_name if comp else None,
            'org_uid': comp.organization_code if comp else None
        }
    })


@pulse_ai_bp.route('/api/conversations', methods=['GET', 'POST'])
@login_required
def api_conversations():
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'Organization context unavailable'}), 400

    if request.method == 'POST':
        data = request.get_json(force=True, silent=True) or {}
        title = (data.get('title') or 'New Executive Briefing').strip()
        conv = PulseAIEngine.get_or_create_conversation(cid, current_user.id, title_hint=title)
        return jsonify({'success': True, 'conversation': conv.to_dict()})

    items = PulseAIEngine.list_conversations(cid, current_user.id, limit=40)
    return jsonify({'success': True, 'conversations': items})


@pulse_ai_bp.route('/api/conversations/<int:conversation_id>', methods=['GET'])
@login_required
def api_get_conversation(conversation_id):
    cid = _get_verified_tenant_company_id()
    data = PulseAIEngine.get_conversation_messages(cid, current_user.id, conversation_id)
    if not data:
        return jsonify({'success': False, 'error': 'Conversation not found or access denied'}), 404
    return jsonify({'success': True, **data})


@pulse_ai_bp.route('/api/conversations/<int:conversation_id>/rename', methods=['POST', 'PATCH'])
@login_required
def api_rename_conversation(conversation_id):
    cid = _get_verified_tenant_company_id()
    data = request.get_json(force=True, silent=True) or {}
    new_title = (data.get('title') or request.form.get('title') or '').strip()
    if not new_title:
        return jsonify({'success': False, 'error': 'Title is required'}), 400
    ok = PulseAIEngine.rename_conversation(cid, current_user.id, conversation_id, new_title)
    if not ok:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    return jsonify({'success': True, 'title': new_title})


@pulse_ai_bp.route('/api/conversations/<int:conversation_id>/delete', methods=['POST', 'DELETE'])
@login_required
def api_delete_conversation(conversation_id):
    cid = _get_verified_tenant_company_id()
    ok = PulseAIEngine.delete_conversation(cid, current_user.id, conversation_id)
    if not ok:
        return jsonify({'success': False, 'error': 'Conversation not found'}), 404
    return jsonify({'success': True})


@pulse_ai_bp.route('/api/chat', methods=['POST'])
@login_required
def api_chat():
    """
    Execute a conversational turn scoped strictly to the authenticated session's company_id.
    Note: Any `company_id` passed in the request JSON is ignored to guarantee multi-tenant security.
    """
    cid = _get_verified_tenant_company_id()
    if not cid:
        return jsonify({'success': False, 'error': 'No active organization context'}), 400

    data = request.get_json(force=True, silent=True) or {}
    prompt = (data.get('prompt') or data.get('message') or '').strip()
    conversation_id = data.get('conversation_id')

    res = PulseAIEngine.process_conversation_turn(
        company_id=cid,
        user_id=current_user.id,
        prompt=prompt,
        conversation_id=conversation_id,
        require_confirmation_for_mutations=True
    )
    status_code = 200 if res.get('success') else 400
    return jsonify(res), status_code


@pulse_ai_bp.route('/api/stream', methods=['POST', 'GET'])
@login_required
def api_stream():
    """
    Real Server-Sent Events (SSE) progressive streaming endpoint for Pulse AI.
    Synchronizes with genuine backend operations:
      1. state: preparing_context
      2. state: analyzing_company_information
      3. state: executing_tool (only if an analytical/mutation tool is invoked)
      4. state: generating_response + progressive text chunks
      5. state: completed (with full structured tables, metrics, and provenance)
    """
    cid = _get_verified_tenant_company_id()
    uid = current_user.id

    if request.method == 'POST':
        data = request.get_json(force=True, silent=True) or {}
        prompt = (data.get('prompt') or data.get('message') or '').strip()
        conversation_id = data.get('conversation_id')
    else:
        prompt = (request.args.get('prompt') or '').strip()
        conversation_id = request.args.get('conversation_id', type=int)

    if not prompt:
        return jsonify({'success': False, 'error': 'Prompt is required'}), 400

    def _sse_event(event_type: str, payload: dict) -> str:
        return f"event: {event_type}\ndata: {json.dumps(payload, default=str)}\n\n"

    @stream_with_context
    def generate():
        try:
            # Stage 1: Preparing context
            yield _sse_event('stage', {'state': 'preparing_context', 'label': 'Preparing organization context...'})

            domains = PulseAIContextRetriever.detect_domains(prompt)
            # Stage 2: Analyzing company information
            yield _sse_event('stage', {
                'state': 'analyzing_company_information',
                'label': f"Analyzing {', '.join(sorted(domains))} records..."
            })

            # Execute full turn on server
            result = PulseAIEngine.process_conversation_turn(
                company_id=cid,
                user_id=uid,
                prompt=prompt,
                conversation_id=conversation_id,
                require_confirmation_for_mutations=True
            )

            if not result.get('success'):
                yield _sse_event('error', {'state': 'error', 'error': result.get('error', 'Failed to generate response')})
                return

            # Stage 3: If tools were invoked, emit genuine tool stage
            asst_msg = result.get('assistant_message') or {}
            tools = asst_msg.get('tool_calls') or []
            if tools:
                tool_names = ', '.join(t.get('name', 'tool') for t in tools)
                yield _sse_event('stage', {
                    'state': 'executing_tool',
                    'label': f"Executing authorized tool: {tool_names}"
                })

            # Stage 4: Generating response — stream markdown tokens progressively with animated typing cadence
            yield _sse_event('stage', {'state': 'generating_response', 'label': 'Synthesizing executive response...'})
            full_md = result.get('markdown') or ''
            
            # Tokenize into word units with trailing spaces/newlines preserved
            tokens = re.findall(r'\S+\s*', full_md)
            if not tokens:
                tokens = [full_md]

            # Progressive streaming with ~15ms cadence for smooth, realistic animated typing
            batch_size = 2
            for i in range(0, len(tokens), batch_size):
                piece = ''.join(tokens[i:i + batch_size])
                yield _sse_event('chunk', {'delta': piece})
                time.sleep(0.015)

            # Stage 5: Completed
            yield _sse_event('completed', {
                'state': 'completed',
                'label': 'Completed',
                'result': result
            })
        except Exception as e:
            yield _sse_event('error', {'state': 'error', 'error': str(e)})

    headers = {
        'Content-Type': 'text/event-stream; charset=utf-8',
        'Cache-Control': 'no-cache, no-transform',
        'X-Accel-Buffering': 'no'
    }
    return Response(generate(), headers=headers)


@pulse_ai_bp.route('/api/actions/<execution_uid>/confirm', methods=['POST'])
@login_required
def api_confirm_action(execution_uid):
    cid = _get_verified_tenant_company_id()
    res = PulseAIEngine.confirm_and_execute_action(
        execution_uid=execution_uid,
        company_id=cid,
        user_id=current_user.id,
        username=current_user.username
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/actions/<execution_uid>/cancel', methods=['POST'])
@login_required
def api_cancel_action(execution_uid):
    cid = _get_verified_tenant_company_id()
    res = PulseAIEngine.cancel_action(
        execution_uid=execution_uid,
        company_id=cid,
        user_id=current_user.id
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/messages/<int:message_id>/feedback', methods=['POST'])
@login_required
def api_message_feedback(message_id):
    cid = _get_verified_tenant_company_id()
    msg = AIMessage.query.filter_by(id=message_id, company_id=cid).first()
    if not msg:
        return jsonify({'success': False, 'error': 'Message not found'}), 404

    data = request.get_json(force=True, silent=True) or {}
    rating = (data.get('rating') or '').strip().lower()
    if rating not in ('up', 'down'):
        return jsonify({'success': False, 'error': 'Invalid rating'}), 400

    msg.feedback_rating = rating
    db.session.commit()
    return jsonify({'success': True, 'message_id': msg.id, 'rating': rating})


@pulse_ai_bp.route('/api/messages/<int:message_id>/regenerate', methods=['POST'])
@login_required
def api_regenerate_message(message_id):
    cid = _get_verified_tenant_company_id()
    msg = AIMessage.query.filter_by(id=message_id, company_id=cid).first()
    if not msg:
        return jsonify({'success': False, 'error': 'Message not found'}), 404

    # Find the preceding user message in the same conversation
    user_msg = AIMessage.query.filter(
        AIMessage.conversation_id == msg.conversation_id,
        AIMessage.company_id == cid,
        AIMessage.role == 'user',
        AIMessage.id <= msg.id
    ).order_by(AIMessage.id.desc()).first()

    if not user_msg:
        return jsonify({'success': False, 'error': 'Original user prompt not found'}), 404

    res = PulseAIEngine.process_conversation_turn(
        company_id=cid,
        user_id=current_user.id,
        prompt=user_msg.content,
        conversation_id=msg.conversation_id,
        require_confirmation_for_mutations=True
    )
    return jsonify(res), (200 if res.get('success') else 400)


@pulse_ai_bp.route('/api/configure-provider', methods=['POST'])
@login_required
def api_configure_provider():
    """Allow authenticated users to configure optional Cloud LLM API keys or select the Neural Twin Engine."""
    from services.superadmin_service import SuperadminService
    data = request.get_json(force=True, silent=True) or {}
    provider = (data.get('provider') or 'auto').strip().lower()
    model_name = (data.get('model_name') or 'gemini-2.5-flash').strip()
    api_key = (data.get('api_key') or '').strip()

    SuperadminService.set_setting('ai_provider', provider, value_type='string', category='ai_config', user_id=current_user.id)
    if model_name:
        SuperadminService.set_setting('ai_model_name', model_name, value_type='string', category='ai_config', user_id=current_user.id)

    if api_key:
        if provider in ('gemini', 'auto') or api_key.startswith('AIza'):
            SuperadminService.set_setting('ai_gemini_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'openai' or api_key.startswith('sk-'):
            SuperadminService.set_setting('ai_openai_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'anthropic' or api_key.startswith('sk-ant'):
            SuperadminService.set_setting('ai_anthropic_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)
        elif provider == 'groq' or api_key.startswith('gsk_'):
            SuperadminService.set_setting('ai_groq_api_key', api_key, value_type='string', category='ai_config', user_id=current_user.id)

    status = PulseAIProviderManager.get_provider_status()
    return jsonify({'success': True, 'provider_status': status})
