"""
Unified Digital Twin Data Exchange Route Blueprint
Provides enterprise endpoints for:
1. Multi-sheet Excel and JSON template downloads
2. Schema introspection
3. Preview-first non-destructive validation
4. Safe transactional data imports (insert, update, upsert)
5. Authoritative dataset exports (Excel and JSON)
6. Instant recalculation of business intelligence metrics
"""
import io
import json
from flask import Blueprint, request, jsonify, send_file, current_app, session
from flask_login import login_required, current_user
from security.tenant import get_current_company_id
from services.digital_twin_template_service import DigitalTwinTemplateService
from services.twin_service import TwinService
from database.db import db
from database.models.company import Company

twin_data_exchange_bp = Blueprint('twin_data_exchange', __name__, url_prefix='/twin-data')


def _get_active_company_id():
    """Retrieve verified active company id for current user session."""
    cid = get_current_company_id()
    if not cid and current_user and current_user.is_authenticated:
        cid = getattr(current_user, 'company_id', None)
    if not cid:
        cid = session.get('company_id')
    return cid


@twin_data_exchange_bp.route('/template/<twin_type>/excel', methods=['GET'])
@login_required
def download_excel_template(twin_type):
    """Download multi-sheet schema-compliant Excel template."""
    company_id = _get_active_company_id()
    custom_twin_id = request.args.get('custom_twin_id', type=int)

    try:
        buf, filename = DigitalTwinTemplateService.generate_excel_template(
            twin_type=twin_type,
            company_id=company_id,
            custom_twin_id=custom_twin_id
        )
        return send_file(
            buf,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@twin_data_exchange_bp.route('/template/<twin_type>/json', methods=['GET'])
@login_required
def download_json_template(twin_type):
    """Download schema-compliant JSON template."""
    company_id = _get_active_company_id()
    custom_twin_id = request.args.get('custom_twin_id', type=int)

    try:
        data = DigitalTwinTemplateService.generate_json_template(
            twin_type=twin_type,
            company_id=company_id,
            custom_twin_id=custom_twin_id
        )
        buf = io.BytesIO(json.dumps(data, indent=2).encode('utf-8'))
        filename = f"{twin_type}_digital_twin_template.json"
        return send_file(
            buf,
            as_attachment=True,
            download_name=filename,
            mimetype='application/json'
        )
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@twin_data_exchange_bp.route('/schema/<twin_type>', methods=['GET'])
@login_required
def get_twin_schema(twin_type):
    """Introspect twin data schema and required attributes."""
    company_id = _get_active_company_id()
    custom_twin_id = request.args.get('custom_twin_id', type=int)
    schema = DigitalTwinTemplateService.get_schema(twin_type, custom_twin_id=custom_twin_id, company_id=company_id)
    if not schema:
        return jsonify({'success': False, 'error': f'Unsupported twin type: {twin_type}'}), 400

    return jsonify({
        'success': True,
        'twin_type': twin_type,
        'display_name': schema.get('display_name'),
        'model_name': schema.get('model_name'),
        'description': schema.get('description'),
        'fields': schema.get('fields', [])
    })


@twin_data_exchange_bp.route('/validate/<twin_type>', methods=['POST'])
@login_required
def validate_twin_data(twin_type):
    """
    Non-destructive preview-first data validation.
    Accepts .xlsx or .json file and returns validation report without modifying the database.
    """
    company_id = _get_active_company_id()
    if not company_id:
        return jsonify({'success': False, 'error': 'No active company tenant detected.'}), 400

    if 'file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded. Please attach an Excel or JSON file.'}), 400

    uploaded_file = request.files['file']
    filename = uploaded_file.filename or ''
    if not (filename.endswith('.xlsx') or filename.endswith('.json') or filename.endswith('.xls') or filename.endswith('.xlsm')):
        return jsonify({'success': False, 'error': 'Invalid file format. Please upload an Excel (.xlsx) or JSON (.json) file.'}), 400

    custom_twin_id = request.form.get('custom_twin_id', type=int)

    try:
        file_bytes = uploaded_file.read()
        report = DigitalTwinTemplateService.validate_uploaded_data(
            twin_type=twin_type,
            file_bytes=file_bytes,
            filename=filename,
            company_id=company_id,
            custom_twin_id=custom_twin_id
        )
        return jsonify(report)
    except Exception as e:
        current_app.logger.exception(f"Error validating {twin_type} data")
        return jsonify({'success': False, 'error': f'Validation failed: {str(e)}'}), 500


@twin_data_exchange_bp.route('/import/<twin_type>', methods=['POST'])
@login_required
def import_twin_data(twin_type):
    """
    Safe transactional data import supporting 'insert', 'update', or 'upsert'.
    Accepts either verified records in JSON body or direct file upload with specified import mode.
    Rolls back automatically on failure.
    Recalculates digital twin metrics upon successful commit.
    """
    company_id = _get_active_company_id()
    if not company_id:
        return jsonify({'success': False, 'error': 'No active company tenant detected.'}), 400

    custom_twin_id = request.form.get('custom_twin_id', type=int) or (request.json.get('custom_twin_id') if request.is_json else None)
    mode = request.form.get('mode') or (request.json.get('mode') if request.is_json else 'insert')
    mode = (mode or 'insert').lower()
    if mode not in ('insert', 'update', 'upsert'):
        mode = 'insert'

    records = []
    # Option A: Records provided directly in JSON body (e.g. following preview validation)
    if request.is_json and 'records' in request.json:
        records = request.json.get('records', [])
    # Option B: File uploaded directly with mode
    elif 'file' in request.files:
        uploaded_file = request.files['file']
        val_report = DigitalTwinTemplateService.validate_uploaded_data(
            twin_type=twin_type,
            file_bytes=uploaded_file.read(),
            filename=uploaded_file.filename,
            company_id=company_id,
            custom_twin_id=custom_twin_id
        )
        if not val_report.get('success'):
            return jsonify({
                'success': False,
                'error': val_report.get('error', 'Uploaded data failed validation.'),
                'validation': val_report
            }), 400
        records = val_report.get('valid_records', [])

    if not records:
        return jsonify({'success': False, 'error': 'No valid records found to import.'}), 400

    try:
        result = DigitalTwinTemplateService.execute_import(
            twin_type=twin_type,
            valid_records=records,
            import_mode=mode,
            company_id=company_id,
            user_id=current_user.id if current_user and current_user.is_authenticated else None,
            custom_twin_id=custom_twin_id
        )
        return jsonify(result)
    except Exception as e:
        db.session.rollback()
        current_app.logger.exception(f"Error executing {twin_type} import")
        return jsonify({'success': False, 'error': f'Import transaction aborted: {str(e)}'}), 500


@twin_data_exchange_bp.route('/export/<twin_type>/<export_format>', methods=['GET'])
@login_required
def export_twin_data(twin_type, export_format):
    """Authoritative dataset export to Excel (.xlsx) or JSON (.json)."""
    company_id = _get_active_company_id()
    if not company_id:
        return jsonify({'success': False, 'error': 'No active company tenant detected.'}), 400

    custom_twin_id = request.args.get('custom_twin_id', type=int)
    export_format = export_format.lower()

    if export_format in ('excel', 'xlsx'):
        try:
            buf, filename = DigitalTwinTemplateService.export_dataset_excel(
                twin_type=twin_type,
                company_id=company_id,
                custom_twin_id=custom_twin_id
            )
            return send_file(
                buf,
                as_attachment=True,
                download_name=filename,
                mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            )
        except Exception as e:
            return jsonify({'success': False, 'error': f'Failed to generate Excel export: {str(e)}'}), 500

    elif export_format == 'json':
        try:
            data = DigitalTwinTemplateService.export_dataset_json(
                twin_type=twin_type,
                company_id=company_id,
                custom_twin_id=custom_twin_id
            )
            buf = io.BytesIO(json.dumps(data, indent=2).encode('utf-8'))
            return send_file(
                buf,
                as_attachment=True,
                download_name=f"{twin_type}_export.json",
                mimetype='application/json'
            )
        except Exception as e:
            return jsonify({'success': False, 'error': f'Failed to generate JSON export: {str(e)}'}), 500
    else:
        return jsonify({'success': False, 'error': f'Unsupported export format: {export_format}'}), 400
