"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 DATA QUALITY & LINEAGE ENGINE
Endpoints for deterministic quality scoring, anomaly feeds, and provenance DAGs.
"""

from flask import request
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_auth_required, get_api_company_id
from security.rbac import Permission
from services.data_quality_service import DataQualityService


@api_v1_bp.route('/quality/summary', methods=['GET'])
@api_auth_required()
def get_quality_summary():
    """Retrieve multi-dimensional quality scorecard and dimension breakdown."""
    cid = get_api_company_id()
    summary = DataQualityService.evaluate_quality(cid)
    if isinstance(summary, dict) and 'score' not in summary:
        summary['score'] = summary.get('composite_score')
    return api_response(data=summary)


@api_v1_bp.route('/quality/anomalies', methods=['GET'])
@api_auth_required()
def get_quality_anomalies():
    """Retrieve statistical anomalies across financial, compensation, and inventory domains."""
    cid = get_api_company_id()
    anomalies = DataQualityService.detect_anomalies(cid)
    return api_response(data=anomalies)


@api_v1_bp.route('/quality/lineage/metric/<metric_name>', methods=['GET'])
@api_auth_required()
def get_metric_lineage(metric_name):
    """Retrieve directed acyclic graph (DAG) nodes and edges tracing metric provenance."""
    cid = get_api_company_id()
    dag = DataQualityService.get_metric_lineage(cid, metric_name)
    return api_response(data=dag)


@api_v1_bp.route('/quality/lineage/entity/<entity_type>/<int:entity_id>', methods=['GET'])
@api_auth_required()
def get_entity_lineage(entity_type, entity_id):
    """Retrieve entity-level provenance trace with tenant isolation."""
    cid = get_api_company_id()
    trace = DataQualityService.get_entity_lineage(cid, entity_type, entity_id)
    if 'error' in trace:
        return api_error("NOT_FOUND", trace['error'], status_code=404)
    return api_response(data=trace)


@api_v1_bp.route('/quality/scan', methods=['POST'])
@api_auth_required(required_permission=Permission.DATA_WRITE)
def run_quality_scan():
    """Trigger on-demand data quality scan and anomaly detection."""
    cid = get_api_company_id()
    summary = DataQualityService.evaluate_quality(cid)
    anomalies = DataQualityService.detect_anomalies(cid)
    return api_response(data={
        "scanned": True,
        "composite_score": summary.get('composite_score', summary.get('score')),
        "score": summary.get('composite_score', summary.get('score')),
        "rating": summary.get('rating'),
        "anomalies_detected": len(anomalies)
    })
