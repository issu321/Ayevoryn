"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 WEBHOOK SUBSCRIPTION & DELIVERY MANAGEMENT
Full CRUD for outbound webhook subscriptions, test ping triggers, and delivery audit logs.
"""

from flask import request
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_auth_required, get_api_company_id
from security.rbac import Permission
from services.webhook_service import WebhookService


@api_v1_bp.route('/webhooks', methods=['GET'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def list_webhooks():
    """List all webhook subscriptions for the active tenant."""
    cid = get_api_company_id()
    subs = WebhookService.list_subscriptions(cid)
    return api_response(data=[s.to_dict() for s in subs])


@api_v1_bp.route('/webhooks', methods=['POST'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def create_webhook():
    """
    Register a new webhook subscription.
    Payload: {"url": "https://...", "event_types": ["*"], "description": "..."}
    """
    cid = get_api_company_id()
    data = request.get_json(silent=True) or {}
    url = data.get('url', '').strip()
    event_types = data.get('event_types', '*')
    description = data.get('description')
    secret = data.get('secret')

    try:
        sub = WebhookService.create_subscription(
            company_id=cid,
            url=url,
            event_types=event_types,
            description=description,
            secret=secret
        )
        return api_response(data=sub.to_dict(include_secret=True), status_code=201)
    except ValueError as e:
        return api_error("VALIDATION_ERROR", str(e), status_code=400)


@api_v1_bp.route('/webhooks/<int:sub_id>', methods=['GET'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def get_webhook(sub_id):
    """Retrieve single webhook subscription details."""
    cid = get_api_company_id()
    sub = WebhookService.get_subscription(sub_id, cid)
    if not sub:
        return api_error("NOT_FOUND", f"Webhook subscription {sub_id} not found in this organization.", status_code=404)
    return api_response(data=sub.to_dict(include_secret=True))


@api_v1_bp.route('/webhooks/<int:sub_id>', methods=['PUT'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def update_webhook(sub_id):
    """Update webhook subscription configuration."""
    cid = get_api_company_id()
    data = request.get_json(silent=True) or {}
    url = data.get('url')
    event_types = data.get('event_types')
    is_active = data.get('is_active')
    description = data.get('description')

    try:
        updated = WebhookService.update_subscription(
            sub_id=sub_id,
            company_id=cid,
            url=url,
            event_types=event_types,
            is_active=is_active,
            description=description
        )
        if not updated:
            return api_error("NOT_FOUND", f"Webhook subscription {sub_id} not found in this organization.", status_code=404)
        return api_response(data=updated.to_dict())
    except ValueError as e:
        return api_error("VALIDATION_ERROR", str(e), status_code=400)


@api_v1_bp.route('/webhooks/<int:sub_id>', methods=['DELETE'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def delete_webhook(sub_id):
    """Delete a webhook subscription strictly owned by the tenant."""
    cid = get_api_company_id()
    success = WebhookService.delete_subscription(sub_id, cid)
    if not success:
        return api_error("NOT_FOUND", f"Webhook subscription {sub_id} not found in this organization.", status_code=404)
    return api_response(data={"deleted": True, "subscription_id": sub_id})


@api_v1_bp.route('/webhooks/<int:sub_id>/test', methods=['POST'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def test_webhook_ping(sub_id):
    """Trigger an immediate connectivity test ping to the webhook endpoint."""
    cid = get_api_company_id()
    delivery = WebhookService.dispatch_test_ping(sub_id, cid)
    if not delivery:
        return api_error("NOT_FOUND", f"Webhook subscription {sub_id} not found in this organization.", status_code=404)
    return api_response(data=delivery.to_dict())


@api_v1_bp.route('/webhooks/<int:sub_id>/deliveries', methods=['GET'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def list_webhook_deliveries(sub_id):
    """List recent delivery logs for a webhook subscription."""
    cid = get_api_company_id()
    deliveries = WebhookService.get_deliveries(sub_id, cid)
    return api_response(data=[d.to_dict() for d in deliveries])
