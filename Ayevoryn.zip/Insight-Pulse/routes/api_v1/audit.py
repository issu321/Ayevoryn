"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 AUDIT & BUSINESS EVENT STREAM
Paginated immutable business event ledger with tenant scoping.
"""

from flask import request
from database.models.business_event import BusinessEvent
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_paginate, api_auth_required, get_api_company_id
from security.rbac import Permission


@api_v1_bp.route('/audit/events', methods=['GET'])
@api_auth_required(required_permission=Permission.AUDIT_VIEW)
def list_business_events():
    """
    Paginated stream of immutable business events for the active tenant.
    Query parameters: page, per_page, event_type.
    """
    cid = get_api_company_id()
    page = request.args.get('page', 1)
    per_page = request.args.get('per_page', 20)
    event_type = request.args.get('event_type', '').strip()

    query = BusinessEvent.query.filter_by(company_id=cid)
    if event_type:
        query = query.filter_by(event_type=event_type)

    query = query.order_by(BusinessEvent.occurred_at.desc())
    items, meta = api_paginate(query, page=page, per_page=per_page)
    return api_response(data=items, meta=meta)
