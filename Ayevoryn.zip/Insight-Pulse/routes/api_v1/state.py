"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 CANONICAL STATE ENDPOINT
Authoritative digital twin business state from BusinessStateService.
"""

from flask import request
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_auth_required, get_api_company_id
from services.business_state_service import BusinessStateService


@api_v1_bp.route('/state/canonical', methods=['GET'])
@api_auth_required()
def get_canonical_state():
    """
    Retrieve authoritative canonical business state with explicit metric provenance tags
    (OBSERVED, DECLARED, SYNTHESIZED, SIMULATED).
    """
    cid = get_api_company_id()
    state = BusinessStateService.get_canonical_state(cid)
    data = state if isinstance(state, dict) else (state.to_dict() if hasattr(state, 'to_dict') else state)
    return api_response(data=data)
