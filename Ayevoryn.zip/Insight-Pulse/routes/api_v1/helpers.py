"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 STANDARDIZED HELPERS & AUTHENTICATION GUARDS
Provides standardized JSON envelopes, pagination, and multi-modal authentication guards.
"""

from functools import wraps
from datetime import datetime, timedelta
import jwt
from typing import Optional, Dict, Any, List, Tuple
from flask import request, jsonify, current_app, session, g
from flask_login import current_user

from database.db import db
from database.models.api_key import ApiKey
from database.models.user import User
from security.rbac import RBACService, ROLE_HIERARCHY, ROLE_PERMISSIONS, Role, Permission
from security.tenant import TenantContext


def get_api_company_id() -> Optional[int]:
    """Resolve the authoritative tenant company_id for the current API request."""
    if hasattr(g, 'current_company_id') and g.current_company_id:
        return g.current_company_id
    cid = TenantContext.get_current_company_id()
    if cid:
        return cid
    return session.get('company_id')


def api_response(data: Any = None, meta: Optional[Dict[str, Any]] = None, status_code: int = 200) -> Tuple[Any, int]:
    """Return standardized API success envelope."""
    cid = get_api_company_id()
    response_meta = {
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "version": "1.0",
        "tenant_id": cid
    }
    if meta and isinstance(meta, dict):
        response_meta.update(meta)

    body = {
        "success": True,
        "data": data,
        "meta": response_meta,
        "error": None
    }
    return jsonify(body), status_code


def api_error(code: str, message: str, details: Optional[Dict[str, Any]] = None, status_code: int = 400) -> Tuple[Any, int]:
    """Return standardized API error envelope."""
    cid = None
    try:
        cid = get_api_company_id()
    except Exception:
        pass

    body = {
        "success": False,
        "data": None,
        "meta": {
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "version": "1.0",
            "tenant_id": cid
        },
        "error": {
            "code": code,
            "message": message,
            "details": details if details is not None else {}
        }
    }
    return jsonify(body), status_code


def api_paginate(query, page: int = 1, per_page: int = 20, serializer=None) -> Tuple[List[Any], Dict[str, Any]]:
    """Paginate a SQLAlchemy query and return (serialized_items, pagination_meta)."""
    try:
        page = max(1, int(page))
    except (ValueError, TypeError):
        page = 1

    try:
        per_page = max(1, min(100, int(per_page)))
    except (ValueError, TypeError):
        per_page = 20

    pagination = query.paginate(page=page, per_page=per_page, error_out=False)
    
    if serializer:
        items = [serializer(item) for item in pagination.items]
    else:
        items = [item.to_dict() if hasattr(item, 'to_dict') else item for item in pagination.items]

    meta = {
        "pagination": {
            "page": pagination.page,
            "per_page": pagination.per_page,
            "total": pagination.total,
            "pages": pagination.pages,
            "has_next": pagination.has_next,
            "has_prev": pagination.has_prev
        }
    }
    return items, meta


def api_auth_required(required_role=None, required_permission=None):
    """
    Multi-modal authentication decorator for API v1.
    Supports:
      1. X-API-Key: aev_live_...
      2. Authorization: Bearer <jwt_or_api_key> / Authorization: ApiKey <api_key>
      3. Active session cookie (current_user.is_authenticated)
    """
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            caller_company_id = None
            caller_role = None
            auth_success = False

            # 1. Inspect X-API-Key header
            x_api_key = request.headers.get('X-API-Key')
            if x_api_key:
                api_key_rec = ApiKey.verify(x_api_key)
                if not api_key_rec:
                    return api_error("UNAUTHORIZED", "Invalid or expired API key provided in X-API-Key header.", status_code=401)
                
                caller_company_id = api_key_rec.company_id
                caller_role = api_key_rec.role
                g.api_key = api_key_rec
                api_key_rec.touch()
                auth_success = True

            # 2. Inspect Authorization header if not authenticated yet
            if not auth_success:
                auth_header = request.headers.get('Authorization', '')
                if auth_header.startswith('Bearer '):
                    token = auth_header[7:].strip()
                    if token.startswith('aev_live_'):
                        # API key sent in Bearer header
                        api_key_rec = ApiKey.verify(token)
                        if not api_key_rec:
                            return api_error("UNAUTHORIZED", "Invalid or expired API key provided in Authorization header.", status_code=401)
                        caller_company_id = api_key_rec.company_id
                        caller_role = api_key_rec.role
                        g.api_key = api_key_rec
                        api_key_rec.touch()
                        auth_success = True
                    else:
                        # JWT bearer token
                        try:
                            payload = jwt.decode(token, current_app.config['SECRET_KEY'], algorithms=['HS256'], leeway=10, options={"verify_iat": False})
                            user_id = payload.get('user_id')
                            token_cid = payload.get('company_id')
                            user = db.session.get(User, user_id) if user_id else None
                            if not user or not user.is_active:
                                return api_error("UNAUTHORIZED", "Invalid token subject or deactivated user.", status_code=401)
                            
                            caller_company_id = token_cid or user.company_id
                            caller_role = RBACService.get_user_role(user)
                            g.api_user = user
                            auth_success = True
                        except jwt.ExpiredSignatureError:
                            return api_error("UNAUTHORIZED", "Bearer token has expired.", status_code=401)
                        except (jwt.InvalidTokenError, Exception) as e:
                            return api_error("UNAUTHORIZED", f"Invalid bearer token: {str(e)}", status_code=401)

                elif auth_header.startswith('ApiKey '):
                    token = auth_header[7:].strip()
                    api_key_rec = ApiKey.verify(token)
                    if not api_key_rec:
                        return api_error("UNAUTHORIZED", "Invalid or expired API key provided in Authorization header.", status_code=401)
                    caller_company_id = api_key_rec.company_id
                    caller_role = api_key_rec.role
                    g.api_key = api_key_rec
                    api_key_rec.touch()
                    auth_success = True

            # 3. Session fallback
            if not auth_success and current_user and getattr(current_user, 'is_authenticated', False):
                caller_company_id = TenantContext.get_current_company_id()
                caller_role = RBACService.get_user_role(current_user)
                g.api_user = current_user
                auth_success = True

            if not auth_success:
                return api_error("UNAUTHORIZED", "Authentication required. Provide an API key via 'X-API-Key' or Bearer token via 'Authorization' header.", status_code=401)

            if not caller_company_id:
                return api_error("FORBIDDEN", "No active organization/tenant context bound to credentials.", status_code=403)

            # Set tenant context
            g.current_company_id = caller_company_id
            session['company_id'] = caller_company_id

            # Role check
            if required_role:
                req_role_str = getattr(required_role, 'value', required_role).strip().capitalize()
                user_weight = ROLE_HIERARCHY.get(caller_role, 0)
                req_weight = ROLE_HIERARCHY.get(req_role_str, 0)
                if user_weight < req_weight:
                    return api_error("FORBIDDEN", f"Insufficient role permissions. Required: {req_role_str}, current: {caller_role}.", status_code=403)

            # Permission check
            if required_permission:
                perm_str = getattr(required_permission, 'value', required_permission)
                allowed_perms = ROLE_PERMISSIONS.get(caller_role, set())
                if perm_str not in allowed_perms:
                    return api_error("FORBIDDEN", f"Missing required permission: {perm_str}.", status_code=403)

            return f(*args, **kwargs)
        return decorated_function
    return decorator
