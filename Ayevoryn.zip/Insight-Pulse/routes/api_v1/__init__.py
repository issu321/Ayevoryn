"""
AEVORYN / INSIGHT-PULSE
STAGE 22: VERSIONED REST API FOUNDATION (v1)
Centralized Blueprint and standardized error handlers.
"""

from flask import Blueprint, jsonify
from routes.api_v1.helpers import api_error

api_v1_bp = Blueprint('api_v1', __name__)

# Register standardized error handlers for the blueprint
@api_v1_bp.errorhandler(400)
def handle_bad_request(e):
    return api_error("BAD_REQUEST", str(e.description if hasattr(e, 'description') else e), status_code=400)

@api_v1_bp.errorhandler(401)
def handle_unauthorized(e):
    return api_error("UNAUTHORIZED", str(e.description if hasattr(e, 'description') else "Authentication required."), status_code=401)

@api_v1_bp.errorhandler(403)
def handle_forbidden(e):
    return api_error("FORBIDDEN", str(e.description if hasattr(e, 'description') else "Access denied."), status_code=403)

@api_v1_bp.errorhandler(404)
def handle_not_found(e):
    return api_error("NOT_FOUND", str(e.description if hasattr(e, 'description') else "Resource not found."), status_code=404)

@api_v1_bp.errorhandler(405)
def handle_method_not_allowed(e):
    return api_error("METHOD_NOT_ALLOWED", "HTTP method is not allowed for this endpoint.", status_code=405)

@api_v1_bp.errorhandler(429)
def handle_rate_limit(e):
    return api_error("RATE_LIMIT_EXCEEDED", "API rate limit exceeded. Please back off.", status_code=429)

@api_v1_bp.errorhandler(500)
def handle_server_error(e):
    return api_error("INTERNAL_SERVER_ERROR", "An unexpected error occurred while processing the API request.", status_code=500)

# Import sub-modules to register endpoints onto api_v1_bp
from routes.api_v1 import auth, state, twins, simulations, quality, audit, webhooks, jobs
