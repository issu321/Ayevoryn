"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 DIGITAL TWIN ENTITIES CRUD & PAGINATION
Uniform REST access across the 7 digital twin pillars under strict multi-tenant isolation.
"""

from flask import request
from database.db import db
from database.models.financial import FinancialRecord
from database.models.customer import Customer
from database.models.employee import Employee
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.department import Department
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_paginate, api_auth_required, get_api_company_id
from security.rbac import Permission
from services.events import EventBus, DomainEvent
from services.events.types import EventTypes

DOMAIN_MAP = {
    'financials': FinancialRecord,
    'customers': Customer,
    'employees': Employee,
    'suppliers': Supplier,
    'inventory': Inventory,
    'departments': Department,
    'custom_twins': CustomTwin
}


@api_v1_bp.route('/twins/<domain>', methods=['GET'])
@api_auth_required()
def list_twin_entities(domain):
    """
    Paginated query across any of the 7 digital twin pillars.
    Supports query parameters: page, per_page, q (search).
    """
    model = DOMAIN_MAP.get(domain.lower())
    if not model:
        return api_error("INVALID_DOMAIN", f"Twin domain '{domain}' is not recognized. Valid: {list(DOMAIN_MAP.keys())}", status_code=404)

    cid = get_api_company_id()
    page = request.args.get('page', 1)
    per_page = request.args.get('per_page', 20)
    q = request.args.get('q', '').strip()

    query = model.query.filter_by(company_id=cid)

    # Simple name filtering if q is provided and model has name/company_name
    if q:
        if hasattr(model, 'name'):
            query = query.filter(model.name.ilike(f'%{q}%'))
        elif hasattr(model, 'company_name'):
            query = query.filter(model.company_name.ilike(f'%{q}%'))
        elif hasattr(model, 'description'):
            query = query.filter(model.description.ilike(f'%{q}%'))

    if hasattr(model, 'id'):
        query = query.order_by(model.id.desc())

    items, meta = api_paginate(query, page=page, per_page=per_page)
    return api_response(data=items, meta=meta)


@api_v1_bp.route('/twins/<domain>/<int:entity_id>', methods=['GET'])
@api_auth_required()
def get_twin_entity(domain, entity_id):
    """Retrieve single twin entity verifying tenant ownership."""
    model = DOMAIN_MAP.get(domain.lower())
    if not model:
        return api_error("INVALID_DOMAIN", f"Twin domain '{domain}' is not recognized.", status_code=404)

    cid = get_api_company_id()
    entity = model.query.filter_by(id=entity_id, company_id=cid).first()
    if not entity:
        return api_error("NOT_FOUND", f"{domain.capitalize()} with ID {entity_id} was not found in this organization.", status_code=404)

    return api_response(data=entity.to_dict() if hasattr(entity, 'to_dict') else {'id': entity.id})


@api_v1_bp.route('/twins/<domain>', methods=['POST'])
@api_auth_required(required_permission=Permission.DATA_WRITE)
def create_twin_entity(domain):
    """Create a new twin entity under strict tenant isolation."""
    model = DOMAIN_MAP.get(domain.lower())
    if not model:
        return api_error("INVALID_DOMAIN", f"Twin domain '{domain}' is not recognized.", status_code=404)

    cid = get_api_company_id()
    data = request.get_json(silent=True) or {}
    if not data:
        return api_error("VALIDATION_ERROR", "JSON body is required to create an entity.", status_code=400)

    # Force tenant company_id
    data['company_id'] = cid

    try:
        from datetime import date
        if domain == 'financials':
            rec = FinancialRecord(
                company_id=cid,
                transaction_date=data.get('transaction_date') or date.today(),
                transaction_type=data.get('transaction_type', data.get('record_type', 'revenue')),
                category=data.get('category', 'General'),
                amount=float(data.get('amount', 0)),
                description=data.get('description', '')
            )
            event_type = EventTypes.FINANCIAL_TRANSACTION_CREATED
        elif domain == 'customers':
            rec = Customer(
                company_id=cid,
                company_name=data.get('company_name', data.get('name', 'New Customer')),
                email=data.get('email', ''),
                phone=data.get('phone', ''),
                status=data.get('status', 'Active')
            )
            event_type = EventTypes.CUSTOMER_CREATED
        elif domain == 'employees':
            rec = Employee(
                company_id=cid,
                name=data.get('name', 'New Employee'),
                email=data.get('email', ''),
                role=data.get('role', 'Staff'),
                department=data.get('department', 'Operations'),
                salary=float(data.get('salary', 0)),
                status=data.get('status', 'Active')
            )
            event_type = EventTypes.EMPLOYEE_CREATED
        elif domain == 'suppliers':
            rec = Supplier(
                company_id=cid,
                name=data.get('name', 'New Supplier'),
                contact_person=data.get('contact_person', ''),
                email=data.get('email', ''),
                phone=data.get('phone', ''),
                status=data.get('status', 'Active')
            )
            event_type = EventTypes.SUPPLIER_CREATED
        elif domain == 'inventory':
            rec = Inventory(
                company_id=cid,
                name=data.get('name', 'New Item'),
                sku=data.get('sku', 'SKU-001'),
                category=data.get('category', 'General'),
                quantity=int(data.get('quantity', 0)),
                unit_price=float(data.get('unit_price', 0))
            )
            event_type = EventTypes.INVENTORY_ITEM_CREATED
        elif domain == 'departments':
            rec = Department(
                company_id=cid,
                name=data.get('name', 'New Department'),
                code=data.get('code', 'DEPT'),
                budget=float(data.get('budget', 0))
            )
            event_type = EventTypes.DEPARTMENT_CREATED
        else:
            return api_error("UNSUPPORTED_CREATION", f"Dynamic entity creation via API is not enabled for '{domain}'.", status_code=400)

        db.session.add(rec)
        db.session.commit()

        EventBus.publish(DomainEvent.create(
            event_type=event_type,
            company_id=cid,
            aggregate_type=model.__name__,
            aggregate_id=str(rec.id),
            payload={"id": rec.id, "domain": domain}
        ))

        return api_response(data=rec.to_dict() if hasattr(rec, 'to_dict') else {'id': rec.id}, status_code=201)

    except Exception as e:
        db.session.rollback()
        return api_error("CREATION_FAILED", f"Failed to create {domain} record: {str(e)}", status_code=400)
