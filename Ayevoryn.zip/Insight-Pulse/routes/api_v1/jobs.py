"""
AEVORYN / INSIGHT-PULSE
STAGE 23: API v1 BACKGROUND JOBS MANAGEMENT
RESTful endpoints for enqueuing, polling, inspecting, and cancelling asynchronous background tasks.
"""

from flask import request
from database.models.job import BackgroundJob
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_paginate, api_auth_required, get_api_company_id
from security.rbac import Permission
from services.job_service import JobService


@api_v1_bp.route('/jobs', methods=['GET'])
@api_auth_required()
def list_jobs():
    """
    List background jobs for the active tenant.
    Query params:
      - status: filter by job status (e.g. pending, running, completed, failed, cancelled)
      - job_type: filter by job handler type
      - page: page number (default 1)
      - per_page: page size (default 20)
    """
    cid = get_api_company_id()
    status = request.args.get('status')
    job_type = request.args.get('job_type')
    page = request.args.get('page', 1)
    per_page = request.args.get('per_page', 20)

    query = BackgroundJob.query.filter_by(company_id=cid)
    if status:
        query = query.filter_by(status=status)
    if job_type:
        query = query.filter_by(job_type=job_type)

    query = query.order_by(BackgroundJob.created_at.desc())
    items, meta = api_paginate(query, page=page, per_page=per_page)
    return api_response(data=items, meta=meta)


@api_v1_bp.route('/jobs', methods=['POST'])
@api_auth_required()
def enqueue_job():
    """
    Enqueue a new asynchronous background job.
    Payload:
    {
      "job_type": "simulation.monte_carlo",
      "payload": { ... },
      "priority": 5,
      "max_retries": 3
    }
    """
    cid = get_api_company_id()
    data = request.get_json(silent=True) or {}
    job_type = data.get('job_type')
    payload = data.get('payload', {})
    priority = data.get('priority', 5)
    max_retries = data.get('max_retries', 3)

    if not job_type:
        return api_error("VALIDATION_ERROR", "Field 'job_type' is required.", status_code=400)

    user = getattr(request, 'api_user', None)
    user_id = user.id if user else None

    try:
        job = JobService.enqueue_job(
            job_type=job_type,
            company_id=cid,
            payload=payload,
            user_id=user_id,
            priority=priority,
            max_retries=max_retries
        )
        return api_response(
            data=job.to_dict(),
            status_code=202,
            meta={"message": f"Job {job.id} of type '{job_type}' queued successfully."}
        )
    except ValueError as e:
        return api_error("VALIDATION_ERROR", str(e), status_code=400)
    except Exception as e:
        return api_error("INTERNAL_ERROR", f"Failed to enqueue job: {str(e)}", status_code=500)


@api_v1_bp.route('/jobs/<job_id>', methods=['GET'])
@api_auth_required()
def get_job(job_id):
    """
    Retrieve real-time execution status and result of a specific background job.
    """
    cid = get_api_company_id()
    job = JobService.get_job(job_id, company_id=cid)
    if not job:
        return api_error("NOT_FOUND", f"Job '{job_id}' not found in this organization.", status_code=404)
    return api_response(data=job.to_dict())


@api_v1_bp.route('/jobs/<job_id>/cancel', methods=['POST'])
@api_auth_required()
def cancel_job(job_id):
    """
    Request cancellation of a pending or running job.
    """
    cid = get_api_company_id()
    user = getattr(request, 'api_user', None)
    user_id = user.id if user else None

    job = JobService.cancel_job(job_id, company_id=cid, user_id=user_id)
    if not job:
        return api_error("NOT_FOUND", f"Job '{job_id}' not found or cannot be cancelled.", status_code=404)

    return api_response(
        data=job.to_dict(),
        meta={"message": f"Job {job_id} cancellation requested."}
    )


@api_v1_bp.route('/jobs/types', methods=['GET'])
@api_auth_required()
def list_job_types():
    """
    List all registered job handler types and descriptions.
    """
    types = JobService.get_registered_job_types()
    return api_response(data=types)
