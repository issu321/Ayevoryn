"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 AUTHENTICATION & KEY MANAGEMENT
Token issuance, profile inspection, and programmatic API key CRUD.
"""

from datetime import datetime, timedelta
import jwt
from flask import request, current_app, g
from werkzeug.security import check_password_hash

from database.db import db
from database.models.user import User
from database.models.company import Company
from database.models.api_key import ApiKey
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_auth_required, get_api_company_id
from security.rbac import Permission, Role
from services.events import EventBus, DomainEvent
from services.events.types import EventTypes


@api_v1_bp.route('/auth/token', methods=['POST'])
def generate_token():
    """
    Authenticate user credentials and issue a signed JWT access token.
    Payload: {"username": "...", "password": "..."}
    """
    data = request.get_json(silent=True) or {}
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not username or not password:
        return api_error("VALIDATION_ERROR", "Both 'username' and 'password' are required.", status_code=400)

    user = User.query.filter((User.username == username) | (User.email == username)).first()
    if not user or not user.check_password(password):
        return api_error("INVALID_CREDENTIALS", "Invalid username or password.", status_code=401)

    if not user.is_active:
        return api_error("ACCOUNT_DEACTIVATED", "User account is inactive.", status_code=403)

    if user.is_locked():
        return api_error("ACCOUNT_LOCKED", "Account is temporarily locked due to failed login attempts.", status_code=403)

    expires_in_seconds = 86400  # 24 hours
    exp_dt = datetime.utcnow() + timedelta(seconds=expires_in_seconds)
    token_payload = {
        'user_id': user.id,
        'username': user.username,
        'company_id': user.company_id,
        'role': user.role,
        'is_admin': user.is_admin,
        'exp': int(exp_dt.timestamp())
    }
    token = jwt.encode(token_payload, current_app.config['SECRET_KEY'], algorithm='HS256')

    return api_response(
        data={
            'access_token': token,
            'token_type': 'Bearer',
            'expires_in': expires_in_seconds,
            'expires_at': exp_dt.isoformat() + 'Z',
            'user': user.to_dict()
        }
    )


@api_v1_bp.route('/auth/me', methods=['GET'])
@api_auth_required()
def get_current_caller():
    """Inspect identity, permissions, and tenant metadata for the authenticated caller."""
    cid = get_api_company_id()
    company = Company.query.get(cid)
    caller_info = {
        'tenant': company.to_dict() if company else None,
        'authenticated_via': 'api_key' if hasattr(g, 'api_key') else 'user_session_or_jwt'
    }
    if hasattr(g, 'api_key'):
        caller_info['api_key'] = g.api_key.to_dict()
    if hasattr(g, 'api_user'):
        caller_info['user'] = g.api_user.to_dict()

    return api_response(data=caller_info)


@api_v1_bp.route('/auth/keys', methods=['GET'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def list_api_keys():
    """List all API keys registered for the active tenant."""
    cid = get_api_company_id()
    keys = ApiKey.query.filter_by(company_id=cid).order_by(ApiKey.created_at.desc()).all()
    return api_response(data=[k.to_dict() for k in keys])


@api_v1_bp.route('/auth/keys', methods=['POST'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def create_api_key():
    """
    Generate a new API key for the active tenant.
    Payload: {"name": "...", "role": "Analyst", "expires_days": 90}
    """
    cid = get_api_company_id()
    data = request.get_json(silent=True) or {}
    name = data.get('name', 'API Key').strip()
    role = data.get('role', Role.ANALYST).strip().capitalize()
    expires_days = data.get('expires_days')
    if expires_days is not None:
        try:
            expires_days = int(expires_days)
        except (ValueError, TypeError):
            expires_days = None

    user_id = getattr(getattr(g, 'api_user', None), 'id', None)
    api_key_rec, raw_secret = ApiKey.generate(
        company_id=cid,
        user_id=user_id,
        name=name,
        role=role,
        expires_days=expires_days
    )

    EventBus.publish(DomainEvent.create(
        event_type=EventTypes.API_KEY_CREATED,
        company_id=cid,
        aggregate_type="ApiKey",
        aggregate_id=str(api_key_rec.id),
        actor_id=user_id,
        payload={"key_id": api_key_rec.id, "name": api_key_rec.name, "role": api_key_rec.role}
    ))

    res_data = api_key_rec.to_dict()
    res_data['secret_key'] = raw_secret  # Only exposed on creation!
    return api_response(data=res_data, status_code=201)


@api_v1_bp.route('/auth/keys/<int:key_id>', methods=['DELETE'])
@api_auth_required(required_permission=Permission.COMPANY_MANAGE)
def revoke_api_key(key_id):
    """Revoke an API key belonging to the tenant."""
    cid = get_api_company_id()
    key_rec = ApiKey.query.filter_by(id=key_id, company_id=cid).first()
    if not key_rec:
        return api_error("NOT_FOUND", f"API Key {key_id} not found in this organization.", status_code=404)

    key_rec.revoke()
    EventBus.publish(DomainEvent.create(
        event_type=EventTypes.API_KEY_REVOKED,
        company_id=cid,
        aggregate_type="ApiKey",
        aggregate_id=str(key_rec.id),
        payload={"key_id": key_rec.id, "name": key_rec.name}
    ))
    return api_response(data={"revoked": True, "key_id": key_id})
