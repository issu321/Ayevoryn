"""
AEVORYN / INSIGHT-PULSE
STAGE 22: API v1 SIMULATION ENGINE
Execute empirical Monte Carlo and scenario simulations with parameter validation.
"""

from flask import request
from database.db import db
from database.models.simulation import Simulation
from routes.api_v1 import api_v1_bp
from routes.api_v1.helpers import api_response, api_error, api_paginate, api_auth_required, get_api_company_id
from security.rbac import Permission
from services.simulation_service import SimulationService
from services.events import EventBus, DomainEvent
from services.events.types import EventTypes


@api_v1_bp.route('/simulations', methods=['GET'])
@api_auth_required()
def list_simulations():
    """List historical simulation runs for the active tenant."""
    cid = get_api_company_id()
    page = request.args.get('page', 1)
    per_page = request.args.get('per_page', 20)
    query = Simulation.query.filter_by(company_id=cid).order_by(Simulation.created_at.desc())
    items, meta = api_paginate(query, page=page, per_page=per_page)
    return api_response(data=items, meta=meta)


@api_v1_bp.route('/simulations/<int:sim_id>', methods=['GET'])
@api_auth_required()
def get_simulation(sim_id):
    """Get single simulation detail and parsed results."""
    cid = get_api_company_id()
    sim = Simulation.query.filter_by(id=sim_id, company_id=cid).first()
    if not sim:
        return api_error("NOT_FOUND", f"Simulation {sim_id} not found in this organization.", status_code=404)
    return api_response(data=sim.to_dict())


@api_v1_bp.route('/simulations/run', methods=['POST'])
@api_auth_required(required_permission=Permission.SIMULATION_RUN)
def run_simulation_api():
    """
    Execute empirical Monte Carlo simulation over revenue and cost distributions.
    Payload:
    {
      "revenue_before": 100000,
      "cost_before": 70000,
      "revenue_after": 120000,
      "cost_after": 80000,
      "iterations": 1000,
      "volatility": 0.15,
      "seed": 42
    }
    """
    cid = get_api_company_id()
    data = request.get_json(silent=True) or {}

    try:
        rev_before = float(data.get('revenue_before', 100000))
        cost_before = float(data.get('cost_before', 70000))
        rev_after = float(data.get('revenue_after', 120000))
        cost_after = float(data.get('cost_after', 80000))
        iterations = int(data.get('iterations', 1000))
        volatility = float(data.get('volatility', 0.15))
        seed = int(data.get('seed')) if data.get('seed') is not None else None
    except (ValueError, TypeError) as e:
        return api_error("VALIDATION_ERROR", f"Invalid simulation parameters: {str(e)}", status_code=400)

    results = SimulationService.run_monte_carlo(
        revenue_before=rev_before,
        cost_before=cost_before,
        revenue_after=rev_after,
        cost_after=cost_after,
        iterations=iterations,
        volatility=volatility,
        seed=seed
    )

    EventBus.publish(DomainEvent.create(
        event_type=EventTypes.SIMULATION_EXECUTED,
        company_id=cid,
        aggregate_type="Simulation",
        aggregate_id=None,
        payload={"iterations": iterations, "volatility": volatility, "prob_profitable": results.get('prob_profitable')}
    ))

    return api_response(data=results)
