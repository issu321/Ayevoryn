import json
import csv
import io
from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from database.models.market_data import MarketData
from database.models.company import Company
from services.market_intelligence_service import MarketIntelligenceService
from security.rbac import permission_required, Permission
from config.constants import CURRENCY_SYMBOLS

market_bp = Blueprint('market_intelligence', __name__)


def _get_currency_symbol():
    """Get currency symbol from session or database."""
    currency_code = session.get('company_currency')
    if not currency_code:
        company = Company.query.get(session.get('company_id'))
        currency_code = getattr(company, 'currency', None) if company else None
        if not currency_code:
            currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@market_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol()
    currency_code = session.get('company_currency', 'USD')
    
    summary = MarketIntelligenceService.get_market_summary(company_id, currency_code=currency_code)
    market_data = summary['data'] if summary else []
    
    return render_template(
        'market/market_intelligence.html', 
        market_data=market_data,
        summary=summary,
        currency_symbol=currency_symbol
    )


@market_bp.route('/create', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def create():
    company_id = session.get('company_id')
    metric_name = request.form.get('metric_name', '').strip()
    if not metric_name:
        flash('Metric name is required.', 'danger')
        return redirect(url_for('market_intelligence.index'))

    data = {
        'metric_name': metric_name,
        'metric_value': request.form.get('metric_value', 0.0),
        'market_name': request.form.get('market_name'),
        'industry': request.form.get('industry'),
        'region': request.form.get('region'),
        'currency': request.form.get('currency', 'USD'),
        'period': request.form.get('period'),
        'year': request.form.get('year'),
        'quarter': request.form.get('quarter'),
        'source': request.form.get('source') or 'User Entry',
        'notes': request.form.get('notes')
    }

    try:
        MarketIntelligenceService.create_market_datum(company_id, data, actor_user_id=current_user.id)
        flash(f"Market metric '{metric_name}' added successfully.", 'success')
    except Exception as e:
        flash(f"Failed to add market metric: {str(e)}", 'danger')

    return redirect(url_for('market_intelligence.index'))


@market_bp.route('/delete/<int:datum_id>', methods=['POST'])
@login_required
@permission_required(Permission.DATA_DELETE)
def delete(datum_id):
    company_id = session.get('company_id')
    deleted = MarketIntelligenceService.delete_market_datum(
        company_id, datum_id, actor_user_id=current_user.id
    )
    if not deleted:
        abort(404)

    flash('Market metric deleted successfully.', 'success')
    return redirect(url_for('market_intelligence.index'))


@market_bp.route('/load-benchmarks', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def load_benchmarks():
    company_id = session.get('company_id')
    currency_code = session.get('company_currency', 'USD')
    created = MarketIntelligenceService.load_industry_benchmarks(
        company_id, currency_code=currency_code, actor_user_id=current_user.id
    )
    flash(f"Loaded {len(created)} reference benchmarks for your industry.", 'success')
    return redirect(url_for('market_intelligence.index'))


@market_bp.route('/refresh', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def refresh():
    company_id = session.get('company_id')
    currency_code = session.get('company_currency', 'USD')
    MarketIntelligenceService.refresh_market_data(company_id, currency_code=currency_code)
    flash('Market intelligence benchmarks recalibrated.', 'success')
    return redirect(url_for('market_intelligence.index'))


@market_bp.route('/import', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def import_data():
    company_id = session.get('company_id')
    raw = request.form.get('import_data', '').strip()
    file = request.files.get('file')

    records = []
    if file and file.filename:
        filename = file.filename.lower()
        if filename.endswith('.json'):
            try:
                records = json.load(file)
            except Exception as e:
                flash(f"Invalid JSON file: {str(e)}", 'danger')
                return redirect(url_for('market_intelligence.index'))
        elif filename.endswith('.csv'):
            try:
                stream = io.StringIO(file.stream.read().decode('utf-8', errors='replace'), newline=None)
                reader = csv.DictReader(stream)
                records = list(reader)
            except Exception as e:
                flash(f"Invalid CSV file: {str(e)}", 'danger')
                return redirect(url_for('market_intelligence.index'))
    elif raw:
        try:
            parsed = json.loads(raw)
            records = parsed if isinstance(parsed, list) else [parsed]
        except Exception as e:
            flash(f"Invalid JSON text: {str(e)}", 'danger')
            return redirect(url_for('market_intelligence.index'))

    if not records:
        flash('No valid market records found to import.', 'warning')
        return redirect(url_for('market_intelligence.index'))

    try:
        created = MarketIntelligenceService.import_market_data(
            company_id, records, actor_user_id=current_user.id
        )
        flash(f"Successfully imported {len(created)} market data records.", 'success')
    except Exception as e:
        flash(f"Import failed: {str(e)}", 'danger')

    return redirect(url_for('market_intelligence.index'))


@market_bp.route('/api/data')
@login_required
def api_data():
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol()
    currency_code = session.get('company_currency', 'USD')
    summary = MarketIntelligenceService.get_market_summary(company_id, currency_code=currency_code)
    return jsonify({
        'summary': {k: v for k, v in summary.items() if k != 'data'} if summary else None,
        'records': [d.to_dict() for d in (summary['data'] if summary else [])],
        'currency_symbol': currency_symbol
    })
