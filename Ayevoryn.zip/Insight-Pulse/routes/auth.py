from flask import Blueprint, render_template, request, redirect, url_for, flash, session, jsonify, send_from_directory, current_app
from flask_login import login_user, logout_user, login_required, current_user
from sqlalchemy import func
from database.db import db
from database.models.user import User
from database.models.company import Company
from database.models.company_payments import CompanyPayments
from database.models.theme_preference import ThemePreference
from services.auth_service import AuthService
from services.company_service import CompanyService
from security.password_hash import hash_password, verify_password
from config.constants import SECURITY_QUESTIONS, CURRENCY_SYMBOLS, COUNTRY_DATA, COUNTRY_CALLING_CODES, UPI_COUNTRIES
from datetime import datetime
import uuid
import io
import os
import re
import base64
import json

try:
    import qrcode
    from qrcode.image.styledpil import StyledPilImage
    from qrcode.image.styles.moduledrawers import RoundedModuleDrawer
    HAS_QR = True
except ImportError:
    HAS_QR = False


def _clean_mobile(raw):
    if not raw:
        return ''
    digits = re.sub(r'\D', '', str(raw))
    return digits


def _generate_whatsapp_link(mobile, country_code=''):
    digits = _clean_mobile(mobile)
    if not digits:
        return ''
    cc = _clean_mobile(country_code)
    if cc and not digits.startswith(cc):
        digits = cc + digits
    return f'https://wa.me/{digits}'


def _generate_upi_link(upi_id, name='', amount='', currency='INR', note=''):
    if not upi_id:
        return ''
    parts = [f'pa={_upi_encode(upi_id)}']
    if name:
        parts.append(f'pn={_upi_encode(name)}')
    if amount:
        parts.append(f'am={_upi_encode(amount)}')
    parts.append(f'cu={_upi_encode(currency)}')
    if note:
        parts.append(f'tn={_upi_encode(note)}')
    return 'upi://pay?' + '&'.join(parts)


def _upi_encode(val):
    if val is None:
        return ''
    s = str(val)
    safe = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~@'
    out = []
    for ch in s:
        if ch in safe:
            out.append(ch)
        else:
            for b in ch.encode('utf-8'):
                out.append(f'%{b:02X}')
    return ''.join(out)


def _generate_qr_png(data):
    if not HAS_QR or not data:
        return ''
    qr = qrcode.QRCode(version=1, box_size=10, border=2)
    qr.add_data(data)
    qr.make(fit=True)
    img = qr.make_image(fill_color='#0B1120', back_color='#FFFFFF')
    buf = io.BytesIO()
    img.save(buf, format='PNG')
    return base64.b64encode(buf.getvalue()).decode('ascii')


auth_bp = Blueprint('auth', __name__)


@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    # Ensure initial superadmin bootstrap has run
    try:
        from services.superadmin_service import SuperadminService
        SuperadminService.bootstrap_superadmin()
    except Exception:
        pass

    if current_user.is_authenticated:
        if getattr(current_user, 'is_global_superadmin', False):
            if getattr(current_user, 'must_change_password', False):
                return redirect(url_for('superadmin.force_password_change'))
            return redirect(url_for('superadmin.dashboard'))
        return redirect(url_for('dashboard.index'))

    # Check if first launch
    if not CompanyService.company_exists():
        return redirect(url_for('auth.setup'))

    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = bool(request.form.get('remember'))

        user, error = AuthService.authenticate(username, password, request.remote_addr)

        if user:
            csrf_token = session.get('csrf_token')
            session.clear()
            if csrf_token:
                session['csrf_token'] = csrf_token
            login_user(user, remember=remember)
            session.permanent = True

            # Record active session token & version
            try:
                from services.superadmin_service import SuperadminService
                SuperadminService.record_login_session(
                    user,
                    ip_address=request.remote_addr,
                    user_agent=request.headers.get('User-Agent')
                )
            except Exception:
                session['session_version'] = getattr(user, 'session_version', 1) or 1

            # 1. Global Superadmin Authentication Routing
            if getattr(user, 'is_global_superadmin', False):
                try:
                    from services.superadmin_service import SuperadminService
                    SuperadminService.record_audit(
                        action='SUPERADMIN_LOGIN_SUCCESS',
                        category='AUTH',
                        target_user_id=user.id,
                        target_username=user.username,
                        details=f"Global Superadmin '{user.display_name}' ({user.username}) signed in.",
                        actor_user=user
                    )
                except Exception:
                    pass

                # Check if MFA is required & enabled for Superadmin
                if getattr(user, 'mfa_enabled', False) and getattr(user, 'mfa_secret', None):
                    session['mfa_verified'] = False
                    return redirect(url_for('superadmin.mfa_verify'))

                session['mfa_verified'] = True
                if getattr(user, 'must_change_password', False):
                    flash('Welcome, Mohammed Usman. Please update your initial bootstrap password to activate full platform controls.', 'warning')
                    return redirect(url_for('superadmin.force_password_change'))

                flash(f'Welcome to the Global Superadmin Control Center, {user.display_name}.', 'success')
                next_page = request.args.get('next')
                if next_page and next_page.startswith('/superadmin'):
                    return redirect(next_page)
                return redirect(url_for('superadmin.dashboard'))

            # 2. Tenant Organization User Routing
            target_company_id = getattr(user, 'company_id', None)
            company = None
            if target_company_id:
                company = db.session.get(Company, target_company_id)
            if not company:
                theme_pref = ThemePreference.query.filter_by(user_id=user.id).first()
                if theme_pref and theme_pref.company_id:
                    company = db.session.get(Company, theme_pref.company_id)
                    if company:
                        user.company_id = company.id
                        db.session.commit()
            if not company:
                company = Company.query.first()
                if company:
                    user.company_id = company.id
                    db.session.commit()

            if company:
                company.last_activity_at = datetime.utcnow()
                db.session.commit()
                session['company_id'] = company.id
                session['company_name'] = company.company_name
                session['company_currency'] = company.currency
                session['currency_symbol'] = CURRENCY_SYMBOLS.get(company.currency, '$')
                session['company_timezone'] = getattr(company, 'timezone', 'UTC')
                if getattr(company, 'logo_path', None):
                    session['company_logo'] = company.logo_path
            session['theme'] = 'white_clay_glass'

            if getattr(user, 'avatar_path', None):
                session['user_avatar'] = user.avatar_path
            theme_pref = ThemePreference.query.filter_by(user_id=user.id).first()
            if theme_pref:
                session['theme'] = theme_pref.theme_id

            if getattr(user, 'must_change_password', False):
                flash('Your administrator requires you to set a new password before continuing.', 'warning')
                return redirect(url_for('auth.force_user_password_change'))

            flash(f'Welcome back, {user.username}!', 'success')
            next_page = request.args.get('next')
            if next_page and not next_page.startswith('/superadmin'):
                return redirect(next_page)
            return redirect(url_for('dashboard.index'))
        else:
            flash(error or 'Invalid credentials', 'danger')

    return render_template('auth/login.html')


@auth_bp.route('/force-password-change', methods=['GET', 'POST'])
@login_required
def force_user_password_change():
    if getattr(current_user, 'is_global_superadmin', False):
        return redirect(url_for('superadmin.force_password_change'))

    if request.method == 'POST':
        current_pw = (request.form.get('current_password') or '').strip()
        new_pw = (request.form.get('new_password') or '').strip()
        confirm_pw = (request.form.get('confirm_password') or '').strip()

        if not verify_password(current_pw, current_user.password_hash):
            flash('Current password is incorrect.', 'danger')
        elif len(new_pw) < 8:
            flash('New password must be at least 8 characters long.', 'danger')
        elif new_pw != confirm_pw:
            flash('New passwords do not match.', 'danger')
        elif verify_password(new_pw, current_user.password_hash):
            flash('New password must be different from your temporary password.', 'danger')
        else:
            current_user.set_password(new_pw)
            current_user.must_change_password = False
            db.session.commit()
            flash('Your password has been updated. Welcome to your workspace!', 'success')
            return redirect(url_for('dashboard.index'))

    return render_template('superadmin/force_password_change.html', is_tenant_user=True)


@auth_bp.route('/get-challenges', methods=['GET'])
def get_challenges():
    identifier = request.args.get('identifier', '').strip()
    data, err = AuthService.get_security_questions(identifier)
    if err:
        return jsonify({'success': False, 'error': err}), 404
    return jsonify({'success': True, 'data': data})


@auth_bp.route('/recover-account', methods=['POST'])
def recover_account():
    identifier = request.form.get('identifier', '').strip()
    answer1 = request.form.get('answer1', '').strip()
    answer2 = request.form.get('answer2', '').strip()
    new_password = request.form.get('new_password', '').strip()

    ok, msg = AuthService.reset_password_with_security_answers(
        identifier, answer1, answer2, new_password, ip_address=request.remote_addr
    )
    if not ok:
        return jsonify({'success': False, 'error': msg}), 400
    return jsonify({'success': True, 'message': msg})


@auth_bp.route('/setup', methods=['GET', 'POST'])
def setup():
    # Respect Global Platform Control registration settings
    try:
        from services.superadmin_service import SuperadminService
        if not SuperadminService.get_setting('allow_public_registration', True) or not SuperadminService.get_setting('allow_company_provisioning', True):
            if CompanyService.company_exists():
                if request.method == 'POST':
                    return jsonify({'success': False, 'error': 'Public organization provisioning is currently disabled by the Global Superadmin.'}), 403
                flash('Public organization provisioning is currently disabled by platform administration.', 'warning')
                return redirect(url_for('auth.login'))
    except Exception:
        pass

    if request.method == 'POST':
        # Accept payload from either JSON body or form parameters
        payload = request.get_json(silent=True) if request.is_json else {}
        step = int(payload.get('step') or request.form.get('step', 1))

        if step == 1:
            session['setup_step'] = 2
            return jsonify({'success': True, 'next_step': 2})

        elif step == 2:
            # Stage 2: Enterprise Identity & Business Profile
            src = payload if request.is_json else request.form
            country = (src.get('country') or '').strip()
            derived = COUNTRY_DATA.get(country, {})
            currency = (src.get('currency') or '').strip() or derived.get('currency', 'USD')
            tax_type = (src.get('tax_type') or '').strip() or derived.get('tax_type', '')
            try:
                tax_rate = float(src.get('tax_rate', 0) or 0)
            except (TypeError, ValueError):
                tax_rate = derived.get('tax_rate', 0.0)

            mobile = _clean_mobile(src.get('mobile', ''))
            mobile_cc = _clean_mobile(src.get('mobile_country_code', ''))
            whatsapp = _clean_mobile(src.get('whatsapp_number', '')) or mobile

            try:
                emp_count = int(src.get('employee_count', 0) or 0)
            except (TypeError, ValueError):
                emp_count = 0

            try:
                ann_rev = float(src.get('annual_revenue', 0) or 0)
            except (TypeError, ValueError):
                ann_rev = 0.0

            try:
                loc_count = int(src.get('locations_count', 1) or 1)
            except (TypeError, ValueError):
                loc_count = 1

            comp_name = (src.get('company_name') or '').strip()
            if not comp_name:
                return jsonify({'success': False, 'error': 'Legal Company Name is required.'}), 400

            company_data = {
                'company_name': comp_name,
                'business_name': (src.get('business_name') or comp_name).strip(),
                'owner_name': (src.get('owner_name') or comp_name or 'Corporate Owner').strip(),
                'ceo_name': (src.get('ceo_name') or src.get('owner_name') or comp_name or 'Corporate Executive').strip(),
                'industry': (src.get('industry') or 'Technology').strip(),
                'business_type': (src.get('business_type') or 'Private Limited').strip(),
                'description': (src.get('description') or '').strip(),
                'company_size': src.get('company_size') or 'Medium (51-250)',
                'employee_count': emp_count,
                'annual_revenue': ann_rev,
                'revenue_range': src.get('revenue_range') or '$1M - $10M',
                'currency': currency,
                'country': country,
                'state': (src.get('state') or '').strip(),
                'city': (src.get('city') or '').strip(),
                'timezone': src.get('timezone', 'UTC') or 'UTC',
                'tax_type': tax_type,
                'tax_rate': tax_rate,
                'tax_id': (src.get('tax_id') or '').strip(),
                'cin_number': (src.get('cin_number') or '').strip(),
                'registered_address': (src.get('registered_address') or '').strip(),
                'fiscal_year_start': (src.get('fiscal_year_start') or 'April').strip(),
                'operating_model': (src.get('operating_model') or 'B2B').strip(),
                'primary_activities': (src.get('primary_activities') or '').strip(),
                'growth_stage': (src.get('growth_stage') or 'Scale-Up').strip(),
                'locations_count': loc_count,
                'operational_objectives': (src.get('operational_objectives') or '').strip(),
                'email': (src.get('email') or '').strip(),
                'mobile': mobile,
                'mobile_country_code': mobile_cc,
                'whatsapp_number': whatsapp,
                'website': (src.get('website') or '').strip()
            }
            session['whatsapp_link'] = _generate_whatsapp_link(whatsapp or mobile, mobile_cc)
            session['company_data'] = company_data
            return jsonify({'success': True, 'next_step': 3})

        elif step == 3:
            # Stage 3: Financial Infrastructure & Payment Rails
            src = payload if request.is_json else request.form
            company_data = session.get('company_data', {})
            company_name = company_data.get('company_name', '')
            whatsapp_link = (src.get('whatsapp_business_link') or '').strip()
            if not whatsapp_link:
                mobile = company_data.get('whatsapp_number') or company_data.get('mobile', '')
                mobile_cc = company_data.get('mobile_country_code', '')
                whatsapp_link = _generate_whatsapp_link(mobile, mobile_cc)

            upi_id = (src.get('upi_id') or '').strip()
            upi_link = (src.get('upi_link') or '').strip()
            if upi_id and not upi_link:
                cur = company_data.get('currency', 'INR') or 'INR'
                upi_link = _generate_upi_link(upi_id, name=company_name, currency=cur)

            qr_b64 = ''
            if upi_link:
                qr_b64 = _generate_qr_png(upi_link)

            raw_acc = (src.get('bank_account_number') or '').strip()
            masked_acc = f"{'•' * (len(raw_acc) - 4)}{raw_acc[-4:]}" if len(raw_acc) >= 4 else raw_acc

            payment_data = {
                'upi_link': upi_link,
                'upi_id': upi_id,
                'upi_display_name': (src.get('upi_display_name') or company_name).strip(),
                'bank_name': (src.get('bank_name') or '').strip(),
                'account_holder_name': (src.get('account_holder_name') or company_name).strip(),
                'bank_account_number': raw_acc,
                'bank_ifsc': (src.get('bank_ifsc') or '').strip(),
                'bank_branch': (src.get('bank_branch') or '').strip(),
                'account_type': (src.get('account_type') or 'Current').strip(),
                'masked_account_number': masked_acc,
                'default_payment_method': (src.get('default_payment_method') or 'Bank Transfer').strip(),
                'payment_terms': (src.get('payment_terms') or 'Net 30').strip(),
                'invoice_payment_instructions': (src.get('invoice_payment_instructions') or '').strip(),
                'payment_gateway_link': (src.get('payment_gateway_link') or '').strip(),
                'payment_link': (src.get('payment_link') or '').strip(),
                'whatsapp_business_link': whatsapp_link,
                'telegram_business_link': (src.get('telegram_business_link') or '').strip(),
            }
            session['payment_data'] = payment_data
            return jsonify({
                'success': True,
                'next_step': 4,
                'whatsapp_link': whatsapp_link,
                'upi_link': upi_link,
                'qr_code_b64': qr_b64,
                'has_qr': bool(qr_b64),
                'masked_account': masked_acc
            })

        elif step == 4:
            # Stage 4: Dynamic Department Builder & Relationships
            src = payload if request.is_json else request.form
            depts_raw = src.get('departments')
            if isinstance(depts_raw, str):
                try:
                    departments = json.loads(depts_raw)
                except Exception:
                    departments = []
            elif isinstance(depts_raw, list):
                departments = depts_raw
            else:
                departments = []

            rels_raw = src.get('relationships')
            if isinstance(rels_raw, str):
                try:
                    relationships = json.loads(rels_raw)
                except Exception:
                    relationships = []
            elif isinstance(rels_raw, list):
                relationships = rels_raw
            else:
                relationships = []

            # If user did not specify any departments, provide a default clean set so workspace isn't empty
            if not departments:
                # Only if explicitly left empty, suggest default core operational units
                departments = [
                    {
                        'name': 'Operations',
                        'code': 'OPS',
                        'description': 'Core business fulfillment and workflow orchestration.',
                        'head_name': 'Operations Lead',
                        'head_designation': 'VP of Operations',
                        'budget': 50000.0,
                        'budget_period': 'Annual',
                        'responsibilities': 'Daily fulfillment, quality assurance, logistics'
                    }
                ]

            session['departments_data'] = departments
            session['relationships_data'] = relationships
            return jsonify({
                'success': True,
                'next_step': 5,
                'department_count': len(departments),
                'relationship_count': len(relationships)
            })

        elif step == 5:
            # Stage 5: Master Administrator & Security Governance
            src = payload if request.is_json else request.form
            req_username = (src.get('username') or '').strip()
            req_email = (src.get('email') or '').strip()
            req_password = src.get('password') or ''
            first_name = (src.get('first_name') or 'Admin').strip()

            if not req_username:
                return jsonify({'success': False, 'error': 'Administrator username is required.'}), 400
            if not req_email:
                return jsonify({'success': False, 'error': 'Administrator corporate email is required.'}), 400
            if not req_password or len(req_password) < 6:
                return jsonify({'success': False, 'error': 'Master password must be at least 6 characters.'}), 400

            # Block reserved superadmin identifiers
            if req_username.lower() == 'usman' or req_email.lower() == 'jaafreeusman@gmail.com':
                return jsonify({'success': False, 'error': 'This username or email is reserved by platform governance.'}), 400

            # Check if username or email is already registered in User table
            existing_user = User.query.filter(
                (func.lower(User.username) == req_username.lower()) |
                (func.lower(User.email) == req_email.lower())
            ).first()
            if existing_user:
                if existing_user.username.lower() == req_username.lower():
                    return jsonify({'success': False, 'error': f"The username '{req_username}' is already taken. Please choose another username."}), 400
                else:
                    return jsonify({'success': False, 'error': f"The email '{req_email}' is already registered. Please use another email."}), 400

            admin_data = {
                'username': req_username,
                'email': req_email,
                'password': req_password,
                'first_name': first_name or 'Admin',
                'phone': (src.get('phone') or '').strip(),
                'designation': (src.get('designation') or 'Master Administrator').strip(),
                'security_question_1': src.get('security_question_1'),
                'security_answer_1': src.get('security_answer_1'),
                'security_question_2': src.get('security_question_2'),
                'security_answer_2': src.get('security_answer_2'),
                'security_question_3': src.get('security_question_3'),
                'security_answer_3': src.get('security_answer_3')
            }
            if 'avatar_file' in request.files and request.files['avatar_file'].filename:
                from routes.uploads import validate_and_extract_image, persist_image_asset
                raw_bytes, ext, mime_type, err = validate_and_extract_image(request.files['avatar_file'])
                if not err and raw_bytes:
                    rel_path, _ = persist_image_asset(raw_bytes, ext, 'avatars', 'admin_setup')
                    admin_data['avatar_path'] = rel_path
                    admin_data['avatar_mime'] = mime_type
                    # Intentionally omit raw base64 data from session to prevent cookie overflow (>4KB)

            session['admin_data'] = admin_data
            return jsonify({'success': True, 'next_step': 6})

        elif step == 6:
            # Stage 6: Emergency Recovery & Review
            src = payload if request.is_json else request.form
            recovery_email = (src.get('recovery_email') or '').strip()
            session['recovery_email'] = recovery_email
            if 'recovery_code' not in session:
                session['recovery_code'] = str(uuid.uuid4())[:8].upper()

            # Compile full preview summary for client inspection
            company_data = session.get('company_data') or {}
            payment_data = session.get('payment_data') or {}
            departments_data = session.get('departments_data') or []
            admin_data = session.get('admin_data') or {}

            summary = {
                'company_name': company_data.get('company_name'),
                'business_name': company_data.get('business_name'),
                'industry': company_data.get('industry'),
                'country': company_data.get('country'),
                'currency': company_data.get('currency'),
                'operating_model': company_data.get('operating_model'),
                'growth_stage': company_data.get('growth_stage'),
                'bank_name': payment_data.get('bank_name'),
                'account_number_masked': payment_data.get('masked_account_number'),
                'upi_id': payment_data.get('upi_id'),
                'departments_count': len(departments_data),
                'departments': [d.get('name') for d in departments_data],
                'admin_username': admin_data.get('username'),
                'admin_email': admin_data.get('email'),
                'recovery_code': session['recovery_code']
            }

            return jsonify({
                'success': True,
                'next_step': 7,
                'recovery_code': session['recovery_code'],
                'summary': summary
            })

        elif step == 7 or request.form.get('action') == 'launch' or payload.get('action') == 'launch':
            # Final Launch Execution: Atomic transaction committing all entities
            created_company = None
            try:
                src = payload if request.is_json else request.form
                company_data = session.get('company_data') or {}
                # Fallback to form/json parameters if session was lost
                if not company_data or not company_data.get('company_name'):
                    comp_name = (src.get('company_name') or '').strip()
                    if comp_name:
                        company_data = {
                            'company_name': comp_name,
                            'business_name': src.get('business_name') or comp_name,
                            'industry': src.get('industry') or 'Technology',
                            'business_type': src.get('business_type') or 'Private Limited',
                            'currency': src.get('currency', 'USD'),
                            'country': src.get('country') or 'United States',
                            'state': (src.get('state') or '').strip(),
                            'city': src.get('city') or '',
                            'timezone': src.get('timezone', 'UTC'),
                            'tax_type': src.get('tax_type', ''),
                            'tax_rate': float(src.get('tax_rate', 0) or 0),
                            'tax_id': (src.get('tax_id') or '').strip(),
                            'cin_number': (src.get('cin_number') or '').strip(),
                            'registered_address': (src.get('registered_address') or '').strip(),
                            'fiscal_year_start': (src.get('fiscal_year_start') or 'April').strip(),
                            'operating_model': (src.get('operating_model') or 'B2B').strip(),
                            'primary_activities': (src.get('primary_activities') or '').strip(),
                            'growth_stage': (src.get('growth_stage') or 'Scale-Up').strip(),
                            'locations_count': int(src.get('locations_count', 1) or 1),
                            'operational_objectives': (src.get('operational_objectives') or '').strip(),
                            'revenue_range': src.get('revenue_range') or '$1M - $10M',
                            'employee_count': int(src.get('employee_count', 0) or 0),
                            'email': src.get('email') or '',
                            'mobile': src.get('mobile') or '',
                            'owner_name': src.get('owner_name') or comp_name or 'Corporate Owner',
                            'ceo_name': src.get('ceo_name') or src.get('owner_name') or comp_name or 'Corporate Owner',
                        }

                admin_data = session.get('admin_data') or {}
                # Ensure all administrative credentials are fully resolved
                admin_username = (admin_data.get('username') or src.get('username') or '').strip()
                admin_email = (admin_data.get('email') or src.get('email') or '').strip()
                admin_password = admin_data.get('password') or src.get('password') or ''
                admin_first_name = (admin_data.get('first_name') or src.get('first_name') or 'Admin').strip()
                admin_designation = (admin_data.get('designation') or src.get('designation') or 'Master Administrator').strip()
                admin_phone = (admin_data.get('phone') or src.get('phone') or '').strip()

                if not admin_username:
                    return jsonify({'success': False, 'error': 'Master Administrator username is required. Please complete Step 5.'}), 400
                if not admin_email:
                    return jsonify({'success': False, 'error': 'Corporate work email is required. Please complete Step 5.'}), 400
                if not admin_password or len(admin_password) < 6:
                    return jsonify({'success': False, 'error': 'Master administrator password must be at least 6 characters. Please complete Step 5.'}), 400

                # Validate username and email uniqueness
                existing = User.query.filter(
                    (func.lower(User.username) == admin_username.lower()) |
                    (func.lower(User.email) == admin_email.lower())
                ).first()
                if existing:
                    if existing.username.lower() == admin_username.lower():
                        return jsonify({'success': False, 'error': f"The username '{admin_username}' is already in use. Please choose another username."}), 400
                    else:
                        return jsonify({'success': False, 'error': f"The email '{admin_email}' is already registered. Please choose another email."}), 400

                admin_data['username'] = admin_username
                admin_data['email'] = admin_email
                admin_data['password'] = admin_password
                admin_data['first_name'] = admin_first_name
                admin_data['designation'] = admin_designation
                admin_data['phone'] = admin_phone

                # Merge departments and relationships into company_data
                departments_data = session.get('departments_data') or []
                if not departments_data and 'departments' in src:
                    d_raw = src.get('departments')
                    departments_data = json.loads(d_raw) if isinstance(d_raw, str) else d_raw
                company_data['departments'] = departments_data

                relationships_data = session.get('relationships_data') or []
                if not relationships_data and 'relationships' in src:
                    r_raw = src.get('relationships')
                    relationships_data = json.loads(r_raw) if isinstance(r_raw, str) else r_raw
                company_data['relationships'] = relationships_data

                # Create company and all dynamic departments & dependencies
                company = CompanyService.create_company(company_data)
                created_company = company
                if not company.org_uid:
                    company.org_uid = f"ORG-AEV-{int(company.id):04d}"
                company.status = 'active'
                db.session.commit()

                # Save payments if provided
                payment_data = session.get('payment_data') or {}
                if not payment_data and src.get('bank_name'):
                    payment_data = {
                        'bank_name': src.get('bank_name'),
                        'bank_account_number': src.get('bank_account_number'),
                        'bank_ifsc': src.get('bank_ifsc'),
                        'bank_branch': src.get('bank_branch'),
                        'account_holder_name': src.get('account_holder_name'),
                        'account_type': src.get('account_type') or 'Current',
                        'upi_id': src.get('upi_id'),
                        'upi_display_name': src.get('upi_display_name'),
                        'payment_terms': src.get('payment_terms') or 'Net 30',
                        'invoice_payment_instructions': src.get('invoice_payment_instructions'),
                        'payment_gateway_link': src.get('payment_gateway_link')
                    }
                if payment_data:
                    CompanyService.save_payments(company.id, payment_data)

                # Read avatar_data from disk if avatar was uploaded
                avatar_path = admin_data.get('avatar_path')
                avatar_mime = admin_data.get('avatar_mime')
                avatar_data = None
                if avatar_path:
                    try:
                        root_dir = current_app.root_path
                        disk_path = os.path.join(root_dir, 'static', avatar_path)
                        if not os.path.exists(disk_path):
                            disk_path = os.path.join(root_dir, avatar_path)
                        if os.path.exists(disk_path):
                            with open(disk_path, 'rb') as f:
                                avatar_data = base64.b64encode(f.read()).decode('ascii')
                    except Exception:
                        avatar_data = None

                # Create master tenant admin
                admin = User(
                    username=admin_data['username'],
                    email=admin_data['email'],
                    first_name=admin_data.get('first_name', 'Admin'),
                    role='Admin',
                    is_admin=True,
                    account_status='active',
                    company_id=company.id,
                    avatar_path=avatar_path,
                    avatar_data=avatar_data,
                    avatar_mime=avatar_mime,
                    security_question_1=admin_data.get('security_question_1'),
                    security_answer_1=admin_data.get('security_answer_1'),
                    security_question_2=admin_data.get('security_question_2'),
                    security_answer_2=admin_data.get('security_answer_2'),
                    security_question_3=admin_data.get('security_question_3'),
                    security_answer_3=admin_data.get('security_answer_3')
                )
                admin.set_password(admin_data['password'])
                db.session.add(admin)
                db.session.commit()

                # Audit logging
                try:
                    from services.superadmin_service import SuperadminService
                    SuperadminService.record_audit(
                        action='COMPANY_REGISTERED',
                        category='COMPANY',
                        target_company_id=company.id,
                        target_company_name=company.company_name,
                        target_user_id=admin.id,
                        target_username=admin.username,
                        updated_values={'org_uid': company.org_uid or company.organization_code, 'company_name': company.company_name},
                        details=f"New organization '{company.company_name}' ({company.org_uid or company.organization_code}) provisioned with {len(departments_data)} departments by '{admin.username}'.",
                        actor_user=admin
                    )
                except Exception:
                    pass

                theme = ThemePreference(user_id=admin.id, company_id=company.id, theme_id='white_clay_glass')
                db.session.add(theme)
                db.session.commit()

                login_user(admin)
                session['company_id'] = company.id
                session['company_name'] = company.company_name
                session['company_currency'] = company.currency
                session['currency_symbol'] = CURRENCY_SYMBOLS.get(company.currency, '$')
                session['theme'] = 'white_clay_glass'
                if admin.avatar_path:
                    session['user_avatar'] = admin.avatar_path

                # Clean up onboarding session cache
                session.pop('company_data', None)
                session.pop('payment_data', None)
                session.pop('departments_data', None)
                session.pop('relationships_data', None)
                session.pop('admin_data', None)
                session.pop('recovery_email', None)
                session.pop('recovery_code', None)

                return jsonify({'success': True, 'redirect': url_for('dashboard.index')})
            except Exception as e:
                db.session.rollback()
                if created_company and created_company.id:
                    try:
                        from database.models.branch import Branch
                        from database.models.department import Department
                        from database.models.department_budget import DepartmentBudget
                        from database.models.department_invitation import DepartmentInvitation
                        from database.models.twin_dependency import TwinDependency
                        TwinDependency.query.filter_by(company_id=created_company.id).delete()
                        DepartmentBudget.query.filter_by(company_id=created_company.id).delete()
                        DepartmentInvitation.query.filter_by(company_id=created_company.id).delete()
                        Branch.query.filter_by(company_id=created_company.id).delete()
                        Department.query.filter_by(company_id=created_company.id).delete()
                        CompanyPayments.query.filter_by(company_id=created_company.id).delete()
                        db.session.delete(created_company)
                        db.session.commit()
                    except Exception:
                        db.session.rollback()
                import logging
                logging.getLogger(__name__).error(f"Setup Finalize error: {e}", exc_info=True)
                return jsonify({'success': False, 'error': f"Setup failed: {str(e)}"}), 500

    return render_template('auth/register.html',
                           security_questions=SECURITY_QUESTIONS,
                           country_data=COUNTRY_DATA,
                           calling_codes=COUNTRY_CALLING_CODES,
                           upi_countries=list(UPI_COUNTRIES))


@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    """Standalone user registration for existing companies."""
    try:
        from services.superadmin_service import SuperadminService
        if not SuperadminService.get_setting('allow_public_registration', True):
            flash('Public user registration is currently disabled by platform administration.', 'warning')
            return redirect(url_for('auth.login'))
    except Exception:
        pass

    if not CompanyService.company_exists():
        flash('Please complete company setup first.', 'warning')
        return redirect(url_for('auth.setup'))

    if request.method == 'POST':
        username = (request.form.get('username') or '').strip()
        email = (request.form.get('email') or '').strip()
        password = request.form.get('password')
        first_name = request.form.get('first_name', '')

        security_question_1 = request.form.get('security_question_1')
        security_answer_1 = request.form.get('security_answer_1')
        security_question_2 = request.form.get('security_question_2')
        security_answer_2 = request.form.get('security_answer_2')
        security_question_3 = request.form.get('security_question_3')
        security_answer_3 = request.form.get('security_answer_3')

        if not username or not email or not password:
            flash('Username, email and password are required.', 'danger')
            return redirect(url_for('auth.register'))

        if username.lower() == 'usman' or email.lower() == 'jaafreeusman@gmail.com':
            flash('Username or email is reserved.', 'danger')
            return redirect(url_for('auth.register'))

        existing = User.query.filter((User.username == username) | (User.email == email)).first()
        if existing:
            flash('Username or email already exists.', 'danger')
            return redirect(url_for('auth.register'))

        target_company_id = request.form.get('company_id', type=int)
        company = None
        if target_company_id:
            company = db.session.get(Company, target_company_id)
        if not company:
            company = Company.query.first()

        avatar_path = None
        avatar_data = None
        avatar_mime = None
        if 'avatar_file' in request.files and request.files['avatar_file'].filename:
            from routes.uploads import validate_and_extract_image, persist_image_asset
            raw_bytes, ext, mime_type, err = validate_and_extract_image(request.files['avatar_file'])
            if not err and raw_bytes:
                avatar_path, avatar_data = persist_image_asset(raw_bytes, ext, 'avatars', 'user_reg')
                avatar_mime = mime_type

        # Public registration can NEVER create a GLOBAL_SUPERADMIN
        user = User(
            username=username,
            email=email,
            first_name=first_name,
            role='Analyst',
            is_admin=False,
            account_status='active',
            company_id=company.id if company else None,
            avatar_path=avatar_path,
            avatar_data=avatar_data,
            avatar_mime=avatar_mime,
            security_question_1=security_question_1,
            security_answer_1=security_answer_1,
            security_question_2=security_question_2,
            security_answer_2=security_answer_2,
            security_question_3=security_question_3,
            security_answer_3=security_answer_3
        )
        user.set_password(password)
        db.session.add(user)
        db.session.commit()

        if company:
            theme = ThemePreference(user_id=user.id, company_id=company.id, theme_id='white_clay_glass')
            db.session.add(theme)
            db.session.commit()

        flash('Account created successfully! Please log in.', 'success')
        return redirect(url_for('auth.login'))

    return render_template('auth/register.html',
                           security_questions=SECURITY_QUESTIONS,
                           country_data=COUNTRY_DATA,
                           calling_codes=COUNTRY_CALLING_CODES,
                           upi_countries=list(UPI_COUNTRIES))


@auth_bp.route('/logout', methods=['GET', 'POST'])
def logout():
    from flask import current_app, make_response
    from database.models.audit_log import AuditLog
    from database.models.superadmin import UserSessionRecord

    if current_user and current_user.is_authenticated:
        try:
            tok = session.get('session_record_token')
            if tok:
                rec = UserSessionRecord.query.filter_by(session_token=tok).first()
                if rec:
                    rec.is_active = False
                    rec.revoked_at = datetime.utcnow()
                    rec.revoked_reason = 'User logged out'
                    db.session.commit()
        except Exception:
            db.session.rollback()

        if getattr(current_user, 'is_global_superadmin', False):
            try:
                from services.superadmin_service import SuperadminService
                SuperadminService.record_audit(
                    action='SUPERADMIN_LOGOUT',
                    category='AUTH',
                    target_user_id=current_user.id,
                    target_username=current_user.username,
                    details=f"Global Superadmin '{current_user.username}' logged out."
                )
            except Exception:
                pass

        try:
            audit = AuditLog(
                company_id=getattr(current_user, 'company_id', None) or session.get('company_id'),
                user_id=current_user.id,
                action='USER_LOGOUT',
                entity_type='user',
                entity_id=current_user.id,
                details=f"User '{current_user.username}' logged out cleanly.",
                ip_address=request.remote_addr
            )
            db.session.add(audit)
            db.session.commit()
        except Exception:
            db.session.rollback()

    session.clear()
    logout_user()
    session['_remember'] = 'clear'
    session.modified = True

    flash('You have been securely logged out of your session.', 'info')

    target_url = url_for('auth.login', logged_out='1')
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        resp = make_response(jsonify({'success': True, 'redirect': target_url, 'message': 'Logged out successfully'}))
    else:
        resp = make_response(redirect(target_url))

    remember_cookie_name = current_app.config.get('REMEMBER_COOKIE_NAME', 'remember_token')
    session_cookie_name = current_app.config.get('SESSION_COOKIE_NAME', 'session')
    resp.delete_cookie(remember_cookie_name, path='/')
    resp.delete_cookie(session_cookie_name, path='/')

    resp.headers['Cache-Control'] = 'no-store, no-cache, must-revalidate, private, max-age=0'
    resp.headers['Pragma'] = 'no-cache'
    resp.headers['Expires'] = '0'
    return resp
