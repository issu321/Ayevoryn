from flask import Blueprint, render_template, request, jsonify, session, send_file
from flask_login import login_required, current_user
from database.models.custom_twin import CustomTwin, CustomTwinRecord, TwinLink, TwinAuditLog
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.branch import Branch
from database.models.project import Project
from database.db import db
from services.twin_service import TwinService
from services.custom_twin_service import (
    CustomTwinSchemaService, TwinFormulaEngine,
    SchemaValidationError, CycleDependencyError
)
from services.events import DomainEvent, EventTypes, publish_event
from sqlalchemy import func
import csv
import io
import json
from datetime import datetime, date
import re
import logging

logger = logging.getLogger(__name__)

custom_twin_bp = Blueprint('custom_twin', __name__)


# =============================================================================
# CUSTOM TWIN MANAGEMENT
# =============================================================================

@custom_twin_bp.route('/custom-twins')
@login_required
def list_custom_twins():
    """List all custom twins for the company."""
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    
    twins = CustomTwin.query.filter_by(company_id=company_id, is_active=True).order_by(CustomTwin.name).all()
    
    # Get twin network health for each twin
    twin_health = {}
    for twin in twins:
        twin_health[twin.id] = TwinService.get_twin_health(twin)
    
    return render_template('business_twin/custom_twins.html',
                         company=company,
                         twins=twins,
                         twin_health=twin_health)


@custom_twin_bp.route('/custom-twins/<int:twin_id>/json')
@login_required
def get_custom_twin_json(twin_id):
    """Fresh twin data as JSON for edit-modal prefill (fetched by ID so the
    template never has to embed JSON payloads inside HTML attributes)."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    return jsonify({'success': True, 'twin': twin.to_dict()})


@custom_twin_bp.route('/custom-twins/network')
@login_required
def twin_network():
    """View the full twin interconnection network."""
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    
    network = TwinService.get_company_twin_network(company_id)
    
    return render_template('business_twin/twin_network.html',
                         company=company,
                         network=network)


def _parse_interconnection_config(payload=None):
    """Parse enterprise-interconnection fields (impact config, automation
    rules, entity linkage) from request form or JSON dict."""
    if payload is None:
        payload = request.get_json(silent=True) if request.is_json else request.form

    impact_level = (payload.get('impact_level') or 'none').strip() or 'none'
    if impact_level not in ('none', 'low', 'medium', 'high', 'critical'):
        impact_level = 'none'

    if hasattr(payload, 'getlist'):
        propagate_to = [p for p in payload.getlist('impact_propagate_to')
                        if p in ('revenue', 'expenses', 'employees', 'customers')]
    else:
        raw_prop = payload.get('impact_propagate_to') or []
        if isinstance(raw_prop, str):
            raw_prop = [raw_prop]
        propagate_to = [p for p in raw_prop if p in ('revenue', 'expenses', 'employees', 'customers')]

    try:
        impact_weight = float(payload.get('impact_weight') or 0.5)
    except (TypeError, ValueError):
        impact_weight = 0.5
    impact_weight = min(1.0, max(0.0, impact_weight))

    impact_field = (payload.get('impact_field') or '').strip()
    impact_config = {
        'level': impact_level,
        'weight': impact_weight,
        'propagate_to': propagate_to,
    }
    if impact_field:
        impact_config['field'] = impact_field

    linked_entity_type = (payload.get('linked_entity_type') or 'custom').strip() or 'custom'
    raw_entity_id = payload.get('linked_entity_id')
    try:
        linked_entity_id = int(raw_entity_id) if raw_entity_id not in (None, '') else None
    except (ValueError, TypeError):
        linked_entity_id = None

    raw_parent_id = payload.get('parent_twin_id')
    try:
        parent_twin_id = int(raw_parent_id) if raw_parent_id not in (None, '') else None
    except (ValueError, TypeError):
        parent_twin_id = None

    automation_rules = []
    rules_raw = payload.get('automation_rules')
    if isinstance(rules_raw, list):
        automation_rules = rules_raw
    elif isinstance(rules_raw, dict):
        automation_rules = [rules_raw]
    elif isinstance(rules_raw, str) and rules_raw.strip():
        try:
            parsed = json.loads(rules_raw.strip())
            if isinstance(parsed, dict):
                parsed = [parsed]
            if isinstance(parsed, list):
                for rule in parsed:
                    if isinstance(rule, dict) and rule.get('action'):
                        automation_rules.append(rule)
        except (ValueError, TypeError):
            pass

    return {
        'impact_config': impact_config,
        'linked_entity_type': linked_entity_type,
        'linked_entity_id': linked_entity_id,
        'parent_twin_id': parent_twin_id,
        'automation_rules': automation_rules,
    }


@custom_twin_bp.route('/custom-twins/create', methods=['POST'])
@login_required
def create_custom_twin():
    """Create a new custom twin with schema validation and hierarchy checking."""
    company_id = session.get('company_id')
    payload = request.get_json(silent=True) if request.is_json else request.form
    
    try:
        name = (payload.get('name') or '').strip()
        if not name:
            return jsonify({'success': False, 'error': 'Twin name is required'}), 400
        
        # Generate slug from name
        slug = re.sub(r'[^\w\s-]', '', name.lower())
        slug = re.sub(r'[-\s]+', '-', slug)
        
        # Check if slug already exists for this company
        existing = CustomTwin.query.filter_by(company_id=company_id, slug=slug).first()
        if existing:
            return jsonify({'success': False, 'error': 'A twin with this name already exists'}), 400
        
        # Parse field definitions
        fields = []
        if 'field_definitions' in payload and isinstance(payload['field_definitions'], list):
            fields = payload['field_definitions']
        else:
            field_count = int(payload.get('field_count') or 0)
            for i in range(field_count):
                field_name = (payload.get(f'field_name_{i}') or '').strip()
                field_label = (payload.get(f'field_label_{i}') or '').strip()
                field_type = (payload.get(f'field_type_{i}') or 'text').strip()
                field_required = payload.get(f'field_required_{i}') in ('on', 'true', True)
                field_default = (payload.get(f'field_default_{i}') or '').strip()
                formula = (payload.get(f'field_formula_{i}') or '').strip()
                
                if field_name:
                    f_def = {
                        'name': field_name,
                        'label': field_label or field_name.replace('_', ' ').title(),
                        'type': field_type,
                        'required': field_required,
                        'default': field_default
                    }
                    if formula:
                        f_def['formula'] = formula
                    fields.append(f_def)
        
        if fields:
            cleaned_fields, field_errors = CustomTwinSchemaService.validate_field_definitions(fields)
            if field_errors:
                err_msg = field_errors.get('formula_cycle') or 'Invalid field definitions'
                return jsonify({'success': False, 'error': err_msg, 'errors': field_errors}), 400
            fields = cleaned_fields
        
        interconnection = _parse_interconnection_config(payload)
        parent_twin_id = interconnection['parent_twin_id']
        if parent_twin_id:
            try:
                CustomTwinSchemaService.validate_parent_hierarchy(company_id, None, parent_twin_id)
            except CycleDependencyError as cde:
                return jsonify({'success': False, 'error': str(cde), 'errors': {'parent_twin_id': str(cde)}}), 400

        # Parse stats configuration
        stats = []
        if 'stats_config' in payload and isinstance(payload['stats_config'], list):
            stats = payload['stats_config']
        else:
            stat_count = int(payload.get('stat_count') or 0)
            for i in range(stat_count):
                stat_name = (payload.get(f'stat_name_{i}') or '').strip()
                stat_label = (payload.get(f'stat_label_{i}') or '').strip()
                stat_type = (payload.get(f'stat_type_{i}') or 'count').strip()
                stat_field = (payload.get(f'stat_field_{i}') or '').strip()
                stat_color = (payload.get(f'stat_color_{i}') or '#00D4FF').strip()
                
                if stat_name:
                    stats.append({
                        'name': stat_name,
                        'label': stat_label or stat_name.replace('_', ' ').title(),
                        'type': stat_type,
                        'field': stat_field,
                        'color': stat_color
                    })
        
        twin = CustomTwin(
            company_id=company_id,
            name=name,
            slug=slug,
            description=(payload.get('description') or '').strip(),
            icon=payload.get('icon') or 'fa-cube',
            color=payload.get('color') or '#00D4FF',
            created_by=current_user.id if hasattr(current_user, 'id') else None
        )
        twin.set_field_definitions(fields)
        twin.set_stats_config(stats)
        table_cols = payload.get('table_columns')
        if table_cols and isinstance(table_cols, list):
            twin.set_table_columns(table_cols)
        else:
            twin.set_table_columns([f['name'] for f in fields[:5]])

        twin.set_impact_config(interconnection['impact_config'])
        twin.set_automation_rules(interconnection['automation_rules'])
        twin.linked_entity_type = interconnection['linked_entity_type']
        if interconnection['linked_entity_id']:
            twin.linked_entity_id = interconnection['linked_entity_id']
        if parent_twin_id:
            twin.parent_twin_id = parent_twin_id
        
        db.session.add(twin)
        db.session.commit()
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_TWIN_CREATED,
                company_id=company_id,
                aggregate_type='custom_twin',
                aggregate_id=str(twin.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': twin.name, 'slug': twin.slug}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': f'Custom twin "{name}" created successfully',
            'twin': twin.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/edit', methods=['POST'])
@login_required
def edit_custom_twin(twin_id):
    """Edit a custom twin configuration with schema validation and hierarchy checking."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    payload = request.get_json(silent=True) if request.is_json else request.form
    try:
        name = (payload.get('name') or '').strip()
        if name:
            twin.name = name
            slug = re.sub(r'[^\w\s-]', '', name.lower())
            slug = re.sub(r'[-\s]+', '-', slug)
            existing = CustomTwin.query.filter_by(company_id=company_id, slug=slug).first()
            if not existing or existing.id == twin.id:
                twin.slug = slug
        
        if payload.get('description') is not None:
            twin.description = (payload.get('description') or '').strip()
        if payload.get('icon'):
            twin.icon = payload.get('icon')
        if payload.get('color'):
            twin.color = payload.get('color')
        
        # Update field definitions if provided
        fields = None
        if 'field_definitions' in payload and isinstance(payload['field_definitions'], list):
            fields = payload['field_definitions']
        elif payload.get('field_count') is not None:
            field_count = int(payload.get('field_count') or 0)
            fields = []
            for i in range(field_count):
                field_name = (payload.get(f'field_name_{i}') or '').strip()
                field_label = (payload.get(f'field_label_{i}') or '').strip()
                field_type = (payload.get(f'field_type_{i}') or 'text').strip()
                field_required = payload.get(f'field_required_{i}') in ('on', 'true', True)
                field_default = (payload.get(f'field_default_{i}') or '').strip()
                formula = (payload.get(f'field_formula_{i}') or '').strip()
                
                if field_name:
                    f_def = {
                        'name': field_name,
                        'label': field_label or field_name.replace('_', ' ').title(),
                        'type': field_type,
                        'required': field_required,
                        'default': field_default
                    }
                    if formula:
                        f_def['formula'] = formula
                    fields.append(f_def)

        if fields is not None:
            cleaned_fields, field_errors = CustomTwinSchemaService.validate_field_definitions(fields)
            if field_errors:
                err_msg = field_errors.get('formula_cycle') or 'Invalid field definitions'
                return jsonify({'success': False, 'error': err_msg, 'errors': field_errors}), 400
            twin.set_field_definitions(cleaned_fields)
            twin.set_table_columns([f['name'] for f in cleaned_fields[:5]])
        
        # Update stats configuration if provided
        stats = None
        if 'stats_config' in payload and isinstance(payload['stats_config'], list):
            stats = payload['stats_config']
        elif payload.get('stat_count') is not None:
            stat_count = int(payload.get('stat_count') or 0)
            stats = []
            for i in range(stat_count):
                stat_name = (payload.get(f'stat_name_{i}') or '').strip()
                stat_label = (payload.get(f'stat_label_{i}') or '').strip()
                stat_type = (payload.get(f'stat_type_{i}') or 'count').strip()
                stat_field = (payload.get(f'stat_field_{i}') or '').strip()
                stat_color = (payload.get(f'stat_color_{i}') or '#00D4FF').strip()
                
                if stat_name:
                    stats.append({
                        'name': stat_name,
                        'label': stat_label or stat_name.replace('_', ' ').title(),
                        'type': stat_type,
                        'field': stat_field,
                        'color': stat_color
                    })
        if stats is not None:
            twin.set_stats_config(stats)

        # Update enterprise interconnection config (impact, automation, linkage)
        if payload.get('impact_level') is not None or 'parent_twin_id' in payload or 'interconnection' in payload or request.is_json:
            interconnection = _parse_interconnection_config(payload)
            parent_twin_id = interconnection['parent_twin_id']
            if parent_twin_id is not None and parent_twin_id != twin.parent_twin_id:
                try:
                    CustomTwinSchemaService.validate_parent_hierarchy(company_id, twin.id, parent_twin_id)
                except CycleDependencyError as cde:
                    return jsonify({'success': False, 'error': str(cde), 'errors': {'parent_twin_id': str(cde)}}), 400
                twin.parent_twin_id = parent_twin_id
            elif 'parent_twin_id' in payload and (payload.get('parent_twin_id') in (None, '', 0, '0')):
                twin.parent_twin_id = None

            twin.set_impact_config(interconnection['impact_config'])
            twin.set_automation_rules(interconnection['automation_rules'])
            twin.linked_entity_type = interconnection['linked_entity_type']
            twin.linked_entity_id = interconnection['linked_entity_id']
        
        db.session.commit()
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_TWIN_UPDATED,
                company_id=company_id,
                aggregate_type='custom_twin',
                aggregate_id=str(twin.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': twin.name, 'slug': twin.slug}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': f'Custom twin "{twin.name}" updated successfully',
            'twin': twin.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/delete', methods=['DELETE'])
@login_required
def delete_custom_twin(twin_id):
    """Delete a custom twin and all its records."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    try:
        name = twin.name
        # Clean up every row that references this twin so no orphans remain:
        # cross-twin links, audit logs, and child twin parent references.
        # Records are removed automatically via the cascade relationship.
        TwinLink.query.filter(
            (TwinLink.source_twin_id == twin.id) | (TwinLink.target_twin_id == twin.id)
        ).delete(synchronize_session=False)
        TwinAuditLog.query.filter_by(twin_id=twin.id).delete(synchronize_session=False)
        CustomTwin.query.filter_by(parent_twin_id=twin.id).update(
            {'parent_twin_id': None}, synchronize_session=False)
        
        db.session.delete(twin)
        db.session.commit()
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_TWIN_DELETED,
                company_id=company_id,
                aggregate_type='custom_twin',
                aggregate_id=str(twin_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': name}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': f'Custom twin "{name}" deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# CUSTOM TWIN RECORDS
# =============================================================================

@custom_twin_bp.route('/custom-twins/<slug>')
@login_required
def view_custom_twin(slug):
    """View a custom twin and its records."""
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    
    twin = CustomTwin.query.filter_by(company_id=company_id, slug=slug, is_active=True).first()
    if not twin:
        return render_template('base.html', error='Twin not found'), 404
    
    records = CustomTwinRecord.query.filter_by(twin_id=twin.id, company_id=company_id, is_active=True).order_by(CustomTwinRecord.created_at.desc()).all()
    
    # Calculate stats
    stats = _calculate_stats(twin, records)
    
    # Calculate dynamic charts based on real records
    field_defs = twin.get_field_definitions() or []
    chart_data = {'has_data': False}
    if records:
        chart_data['has_data'] = True
        # 1. Look for a categorical / select field
        cat_field = next((f for f in field_defs if f.get('type') in ('select', 'status', 'category')), None)
        if not cat_field:
            cat_field = next((f for f in field_defs if f.get('type') == 'text' and 'name' not in f.get('name', '').lower()), None)
        
        if cat_field:
            cf_name = cat_field.get('name')
            cf_label = cat_field.get('label') or cf_name.replace('_', ' ').title()
            dist = {}
            for r in records:
                val = str(r.get_data().get(cf_name, '')).strip() or 'Unspecified'
                dist[val] = dist.get(val, 0) + 1
            chart_data['category_title'] = f'{cf_label} Distribution'
            chart_data['categories'] = list(dist.keys())
            chart_data['category_counts'] = list(dist.values())
        else:
            chart_data['category_title'] = 'Record Volume'
            chart_data['categories'] = ['Active Records']
            chart_data['category_counts'] = [len(records)]
        
        # 2. Look for numeric field for metrics bar/scatter
        num_field = next((f for f in field_defs if f.get('type') in ('number', 'integer', 'float', 'currency')), None)
        if num_field:
            nf_name = num_field.get('name')
            nf_label = num_field.get('label') or nf_name.replace('_', ' ').title()
            name_field = next((f for f in field_defs if 'name' in f.get('name', '').lower() or 'code' in f.get('name', '').lower() or 'title' in f.get('name', '').lower()), None)
            nf_title = f'{nf_label} by Item'
            
            top_recs = records[:12]
            labels = []
            vals = []
            for r in top_recs:
                lbl = str(r.get_data().get(name_field.get('name') if name_field else 'id', f"Item #{r.id}"))
                v = 0
                try:
                    v = float(r.get_data().get(nf_name, 0) or 0)
                except (ValueError, TypeError):
                    v = 0
                labels.append(lbl)
                vals.append(v)
            chart_data['metric_title'] = nf_title
            chart_data['metric_labels'] = labels
            chart_data['metric_values'] = vals

    return render_template('business_twin/custom_twin_detail.html',
                         company=company,
                         twin=twin,
                         records=records,
                         stats=stats,
                         chart_data=chart_data,
                         field_definitions=twin.get_field_definitions(),
                         table_columns=twin.get_table_columns())


def _calculate_stats(twin, records):
    """Calculate statistics for a custom twin with automatic fallback to live record fields."""
    stats_config = twin.get_stats_config()
    results = []
    
    for stat in stats_config:
        value = 0
        stat_type = stat.get('type', 'count')
        field = stat.get('field', '')
        
        if stat_type == 'count':
            value = len(records)
        elif stat_type == 'sum' and field:
            value = sum(float(r.get_data().get(field, 0) or 0) for r in records)
        elif stat_type == 'avg' and field:
            values = [float(r.get_data().get(field, 0) or 0) for r in records if r.get_data().get(field)]
            value = sum(values) / len(values) if values else 0
        elif stat_type == 'min' and field:
            values = [float(r.get_data().get(field, 0) or 0) for r in records if r.get_data().get(field)]
            value = min(values) if values else 0
        elif stat_type == 'max' and field:
            values = [float(r.get_data().get(field, 0) or 0) for r in records if r.get_data().get(field)]
            value = max(values) if values else 0
        
        results.append({
            'name': stat.get('name', ''),
            'label': stat.get('label', ''),
            'value': value,
            'color': stat.get('color', '#00D4FF')
        })
    
    # If stats_config was not explicitly configured or yielded fewer than 2 cards,
    # auto-derive authoritative stats from the twin's actual fields & records!
    if len(results) < 2:
        field_defs = twin.get_field_definitions() or []
        auto_stats = []
        
        # Always Card 1: Total Records
        auto_stats.append({
            'name': 'total_records',
            'label': 'Total Records',
            'value': len(records),
            'color': '#3B82F6'
        })
        
        # Find numeric fields
        num_fields = [f for f in field_defs if f.get('type') in ('number', 'integer', 'float', 'currency')]
        colors = ['#10B981', '#F59E0B', '#8B5CF6', '#EC4899']
        c_idx = 0
        for f in num_fields[:3]:
            fname = f.get('name')
            flabel = f.get('label') or fname.replace('_', ' ').title()
            vals = []
            for r in records:
                d = r.get_data()
                v = d.get(fname)
                if v is not None and v != '':
                    try:
                        vals.append(float(v))
                    except (ValueError, TypeError):
                        pass
            total_val = sum(vals) if vals else 0
            avg_val = (total_val / len(vals)) if vals else 0
            
            auto_stats.append({
                'name': f'total_{fname}',
                'label': f'Total {flabel}',
                'value': round(total_val, 2),
                'color': colors[c_idx % len(colors)]
            })
            c_idx += 1
            if len(auto_stats) < 4:
                auto_stats.append({
                    'name': f'avg_{fname}',
                    'label': f'Avg {flabel}',
                    'value': round(avg_val, 2),
                    'color': colors[c_idx % len(colors)]
                })
                c_idx += 1
        
        # If still need cards, check categorical/select fields
        if len(auto_stats) < 4:
            cat_fields = [f for f in field_defs if f.get('type') in ('select', 'status', 'category')]
            for f in cat_fields[:2]:
                fname = f.get('name')
                flabel = f.get('label') or fname.replace('_', ' ').title()
                val_counts = {}
                for r in records:
                    v = str(r.get_data().get(fname, '')).strip()
                    if v:
                        val_counts[v] = val_counts.get(v, 0) + 1
                top_val = max(val_counts.items(), key=lambda x: x[1])[0] if val_counts else 'None'
                auto_stats.append({
                    'name': f'top_{fname}',
                    'label': f'Top {flabel}',
                    'value': top_val,
                    'color': colors[c_idx % len(colors)]
                })
                c_idx += 1
                if len(auto_stats) >= 4:
                    break
                    
        return auto_stats
    
    return results


@custom_twin_bp.route('/custom-twins/records/<int:record_id>/json')
@login_required
def get_custom_record_json(record_id):
    """Fresh record data as JSON for edit-modal prefill (fetched by ID so the
    template never has to embed JSON payloads inside HTML attributes)."""
    company_id = session.get('company_id')
    record = CustomTwinRecord.query.filter_by(id=record_id, company_id=company_id).first()
    if not record:
        return jsonify({'success': False, 'error': 'Record not found'}), 404
    return jsonify({'success': True, 'record': record.to_dict(include_twin=False), 'twin_id': record.twin_id})


@custom_twin_bp.route('/custom-twins/<int:twin_id>/records', methods=['POST'])
@login_required
def add_custom_record(twin_id):
    """Add a new record to a custom twin with schema validation and formula computation."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    try:
        fields = twin.get_field_definitions()
        payload = request.get_json(silent=True)
        if payload is None:
            payload = {}
            for k in request.form.keys():
                payload[k] = request.form.get(k)
        
        cleaned_data, errors = CustomTwinSchemaService.validate_and_clean_record_data(fields, payload)
        if errors:
            return jsonify({'success': False, 'error': 'Record validation failed', 'errors': errors}), 400
        
        record = CustomTwinRecord(
            twin_id=twin_id,
            company_id=company_id,
            created_by=current_user.id if hasattr(current_user, 'id') else None
        )
        record.set_data(cleaned_data)
        
        db.session.add(record)
        db.session.commit()
        
        # ============================================================
        # ENTERPRISE INTERCONNECTION: Propagate to linked twins,
        # execute automation rules, apply company impact, sync entities
        # ============================================================
        try:
            TwinService.propagate_record(
                twin, record, 'on_create',
                user_id=current_user.id if hasattr(current_user, 'id') else None
            )
            db.session.commit()
        except Exception as prop_error:
            db.session.rollback()
            logger.error(f"Twin propagation error: {prop_error}")
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_RECORD_CREATED,
                company_id=company_id,
                aggregate_type='custom_record',
                aggregate_id=str(record.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'twin_id': twin_id, 'twin_name': twin.name, 'data': cleaned_data}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': 'Record added successfully',
            'record': record.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/records/<int:record_id>', methods=['POST'])
@login_required
def edit_custom_record(record_id):
    """Edit a custom twin record with schema validation and formula computation."""
    company_id = session.get('company_id')
    record = CustomTwinRecord.query.filter_by(id=record_id, company_id=company_id).first()
    
    if not record:
        return jsonify({'success': False, 'error': 'Record not found'}), 404
    
    try:
        twin = record.twin
        fields = twin.get_field_definitions()
        payload = request.get_json(silent=True)
        if payload is None:
            payload = {}
            for k in request.form.keys():
                payload[k] = request.form.get(k)
        
        # Merge existing record data for unsupplied fields
        existing_data = record.get_data() or {}
        merged_payload = dict(existing_data)
        merged_payload.update(payload)
        
        cleaned_data, errors = CustomTwinSchemaService.validate_and_clean_record_data(fields, merged_payload)
        if errors:
            return jsonify({'success': False, 'error': 'Record validation failed', 'errors': errors}), 400
        
        record.set_data(cleaned_data)
        db.session.commit()
        
        # ============================================================
        # ENTERPRISE INTERCONNECTION: Propagate update to linked twins
        # ============================================================
        try:
            TwinService.propagate_record(
                twin, record, 'on_update',
                user_id=current_user.id if hasattr(current_user, 'id') else None
            )
            db.session.commit()
        except Exception as prop_error:
            db.session.rollback()
            logger.error(f"Twin propagation error: {prop_error}")
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_RECORD_UPDATED,
                company_id=company_id,
                aggregate_type='custom_record',
                aggregate_id=str(record.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'twin_id': twin.id, 'twin_name': twin.name, 'data': cleaned_data}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': 'Record updated successfully',
            'record': record.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/records/<int:record_id>', methods=['DELETE'])
@login_required
def delete_custom_record(record_id):
    """Delete a custom twin record."""
    company_id = session.get('company_id')
    record = CustomTwinRecord.query.filter_by(id=record_id, company_id=company_id).first()
    
    if not record:
        return jsonify({'success': False, 'error': 'Record not found'}), 404
    
    try:
        twin = record.twin
        
        # ============================================================
        # ENTERPRISE INTERCONNECTION: Propagate delete to linked twins
        # MUST run BEFORE the record is deleted, otherwise the
        # automation rules operate on a removed row.
        # ============================================================
        try:
            TwinService.propagate_record(
                twin, record, 'on_delete',
                user_id=current_user.id if hasattr(current_user, 'id') else None
            )
        except Exception as prop_error:
            logger.error(f"Twin propagation error: {prop_error}")
        
        db.session.delete(record)
        db.session.commit()
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_RECORD_DELETED,
                company_id=company_id,
                aggregate_type='custom_record',
                aggregate_id=str(record_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'twin_id': twin.id if twin else None}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': 'Record deleted successfully'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/records/delete-all', methods=['DELETE', 'POST'])
@login_required
def delete_all_custom_records(twin_id):
    """Delete all records from a custom twin."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    try:
        # Propagate on_delete for every record BEFORE bulk removal so
        # automation rules (impact reversal) fire correctly
        records = CustomTwinRecord.query.filter_by(
            twin_id=twin_id, company_id=company_id).all()
        for record in records:
            try:
                TwinService.propagate_record(
                    twin, record, 'on_delete',
                    user_id=current_user.id if hasattr(current_user, 'id') else None
                )
            except Exception as prop_error:
                logger.error(f"Twin propagation error: {prop_error}")
        
        count = len(records)
        CustomTwinRecord.query.filter_by(twin_id=twin_id, company_id=company_id).delete()
        db.session.commit()
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOM_RECORD_ALL_DELETED,
                company_id=company_id,
                aggregate_type='custom_record',
                aggregate_id=str(twin_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'twin_id': twin_id, 'deleted_count': count}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({
            'success': True,
            'message': f'All {count} records deleted successfully',
            'deleted': count
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# IMPORT/EXPORT
# =============================================================================

@custom_twin_bp.route('/custom-twins/<int:twin_id>/import-csv', methods=['POST'])
@login_required
def import_custom_csv(twin_id):
    """Import records from CSV to a custom twin."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not file.filename.endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV'}), 400
    
    try:
        fields = twin.get_field_definitions()
        field_names = [f['name'] for f in fields]
        
        stream = io.StringIO(file.stream.read().decode('UTF-8'), newline=None)
        csv_reader = csv.DictReader(stream)
        
        added_count = 0
        updated_count = 0
        errors = []
        
        for row_num, row in enumerate(csv_reader, start=2):
            try:
                data = {}
                for field in fields:
                    field_name = field['name']
                    field_type = field.get('type', 'text')
                    value = row.get(field_name, '').strip()
                    
                    # Convert value based on field type
                    if field_type == 'number':
                        value = float(value) if value else 0
                    elif field_type == 'integer':
                        value = int(float(value)) if value else 0
                    elif field_type == 'boolean':
                        value = value.lower() in ['true', 'yes', '1', 'on']
                    
                    data[field_name] = value
                
                # Check for existing record by first field (usually an ID or name)
                existing = None
                if field_names and data.get(field_names[0]):
                    existing = CustomTwinRecord.query.filter_by(
                        twin_id=twin_id,
                        company_id=company_id
                    ).filter(
                        CustomTwinRecord.data.contains(json.dumps({field_names[0]: data[field_names[0]]}))
                    ).first()
                
                if existing:
                    existing.set_data(data)
                    updated_count += 1
                else:
                    record = CustomTwinRecord(
                        twin_id=twin_id,
                        company_id=company_id,
                        created_by=current_user.id if hasattr(current_user, 'id') else None
                    )
                    record.set_data(data)
                    db.session.add(record)
                    added_count += 1
                    
            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/import-excel', methods=['POST'])
@login_required
def import_custom_excel(twin_id):
    """Import records from Excel to a custom twin."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['excel_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if not (file.filename.endswith('.xlsx') or file.filename.endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400
    
    try:
        from openpyxl import load_workbook
        
        fields = twin.get_field_definitions()
        field_names = [f['name'] for f in fields]
        
        wb = load_workbook(filename=io.BytesIO(file.read()))
        ws = wb.active
        
        # Read headers
        headers = []
        for cell in ws[1]:
            val = cell.value
            if val:
                h = str(val).strip().lower().replace(' ', '_')
                headers.append(h)
            else:
                headers.append('')
        
        # Create header map
        header_map = {}
        for idx, h in enumerate(headers):
            for field in fields:
                if h == field['name'].lower():
                    header_map[field['name']] = idx
                    break
        
        added_count = 0
        updated_count = 0
        errors = []
        
        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            try:
                data = {}
                for field in fields:
                    field_name = field['name']
                    field_type = field.get('type', 'text')
                    idx = header_map.get(field_name)
                    
                    if idx is not None and idx < len(row):
                        value = row[idx]
                        if value is not None:
                            value = str(value).strip()
                    else:
                        value = ''
                    
                    # Convert value based on field type
                    if field_type == 'number':
                        if isinstance(value, (int, float)):
                            value = float(value)
                        else:
                            value = float(value) if value else 0
                    elif field_type == 'integer':
                        if isinstance(value, (int, float)):
                            value = int(value)
                        else:
                            value = int(float(value)) if value else 0
                    elif field_type == 'boolean':
                        if isinstance(value, str):
                            value = value.lower() in ['true', 'yes', '1', 'on']
                        else:
                            value = bool(value)
                    
                    data[field_name] = value
                
                # Check for existing
                existing = None
                if field_names and data.get(field_names[0]):
                    existing = CustomTwinRecord.query.filter_by(
                        twin_id=twin_id,
                        company_id=company_id
                    ).filter(
                        CustomTwinRecord.data.contains(json.dumps({field_names[0]: data[field_names[0]]}))
                    ).first()
                
                if existing:
                    existing.set_data(data)
                    updated_count += 1
                else:
                    record = CustomTwinRecord(
                        twin_id=twin_id,
                        company_id=company_id,
                        created_by=current_user.id if hasattr(current_user, 'id') else None
                    )
                    record.set_data(data)
                    db.session.add(record)
                    added_count += 1
                    
            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")
        
        db.session.commit()
        
        return jsonify({
            'success': True,
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/export-excel')
@login_required
def export_custom_excel(twin_id):
    """Export records to Excel from a custom twin."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        
        fields = twin.get_field_definitions()
        records = CustomTwinRecord.query.filter_by(twin_id=twin_id, company_id=company_id, is_active=True).all()
        
        wb = Workbook()
        ws = wb.active
        ws.title = twin.name[:31]  # Excel sheet name limit
        
        # Headers
        headers = [f['label'] for f in fields]
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
        header_align = Alignment(horizontal="center", vertical="center")
        
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_align
        
        # Data
        for row_num, record in enumerate(records, 2):
            data = record.get_data()
            for col_num, field in enumerate(fields, 1):
                value = data.get(field['name'], '')
                ws.cell(row=row_num, column=col_num, value=value)
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"{twin.slug}_export.xlsx"
        return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        as_attachment=True, download_name=filename)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/export-csv')
@custom_twin_bp.route('/custom-twins/<slug>/export-csv')
@login_required
def export_custom_csv(twin_id=None, slug=None):
    """Export records to CSV from a custom twin."""
    company_id = session.get('company_id')
    if twin_id is not None:
        twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    else:
        twin = CustomTwin.query.filter_by(slug=slug, company_id=company_id, is_active=True).first()

    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404

    try:
        fields = twin.get_field_definitions()
        records = CustomTwinRecord.query.filter_by(twin_id=twin.id, company_id=company_id, is_active=True).all()

        output = io.StringIO()
        writer = csv.writer(output)

        headers = [f['label'] for f in fields]
        writer.writerow(headers)

        for record in records:
            data = record.get_data()
            row = [data.get(f['name'], '') for f in fields]
            writer.writerow(row)

        output.seek(0)
        filename = f"{twin.slug}_export.csv"
        return send_file(
            io.BytesIO(output.getvalue().encode('utf-8-sig')),
            mimetype='text/csv',
            as_attachment=True,
            download_name=filename
        )
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/download-template')
@login_required
def download_custom_template(twin_id):
    """Download CSV template for a custom twin."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    try:
        fields = twin.get_field_definitions()
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Header row with field names
        headers = [f['name'] for f in fields]
        writer.writerow(headers)
        
        # Sample data row
        sample = []
        for field in fields:
            field_type = field.get('type', 'text')
            if field_type == 'number':
                sample.append('100.00')
            elif field_type == 'integer':
                sample.append('10')
            elif field_type == 'boolean':
                sample.append('true')
            elif field_type == 'date':
                sample.append('2026-01-15')
            else:
                sample.append(f'Sample {field["label"]}')
        writer.writerow(sample)
        
        output.seek(0)
        filename = f"{twin.slug}_template.csv"
        return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv',
                        as_attachment=True, download_name=filename)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/<int:twin_id>/download-excel-template')
@login_required
def download_custom_excel_template(twin_id):
    """Download Excel template for a custom twin."""
    company_id = session.get('company_id')
    twin = CustomTwin.query.filter_by(id=twin_id, company_id=company_id).first()
    
    if not twin:
        return jsonify({'success': False, 'error': 'Twin not found'}), 404
    
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
        
        fields = twin.get_field_definitions()
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Template"
        
        # Headers
        headers = [f['name'] for f in fields]
        header_font = Font(bold=True, color="FFFFFF", size=11)
        header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
        header_align = Alignment(horizontal="center", vertical="center")
        
        for col, header in enumerate(headers, 1):
            cell = ws.cell(row=1, column=col, value=header)
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_align
        
        # Sample data row
        for col_num, field in enumerate(fields, 1):
            field_type = field.get('type', 'text')
            if field_type == 'number':
                value = 100.00
            elif field_type == 'integer':
                value = 10
            elif field_type == 'boolean':
                value = 'true'
            elif field_type == 'date':
                value = '2026-01-15'
            else:
                value = f'Sample {field["label"]}'
            ws.cell(row=2, column=col_num, value=value)
        
        # Auto-adjust column widths
        for column in ws.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if cell.value:
                        max_length = max(max_length, len(str(cell.value)))
                except:
                    pass
            adjusted_width = min(max_length + 2, 50)
            ws.column_dimensions[column_letter].width = adjusted_width
        
        output = io.BytesIO()
        wb.save(output)
        output.seek(0)
        
        filename = f"{twin.slug}_template.xlsx"
        return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                        as_attachment=True, download_name=filename)
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@custom_twin_bp.route('/custom-twins/records/bulk-delete', methods=['POST'])
@login_required
def bulk_delete_custom_records():
    """Bulk delete selected custom-twin records.

    Reuses the single-record handler so twin-interconnection hooks
    (on_delete propagation to linked twins) run exactly as for
    individual deletes. Body: {"ids": [1, 2, ...]}
    """
    data = request.get_json(silent=True) or {}
    raw_ids = data.get('ids') or []
    try:
        ids = sorted({int(i) for i in raw_ids})
    except (TypeError, ValueError):
        return jsonify({'success': False, 'error': 'Invalid record ids'}), 400
    if not ids:
        return jsonify({'success': False, 'error': 'No records selected'}), 400

    handler = globals().get('delete_custom_record')
    if not handler:
        return jsonify({'success': False, 'error': 'Handler unavailable'}), 500

    deleted, failed = [], []
    for rid in ids:
        try:
            result = handler(rid)
            status = result[1] if isinstance(result, tuple) else 200
            (deleted if status == 200 else failed).append(rid)
        except Exception:
            db.session.rollback()
            failed.append(rid)
    try:
        db.session.commit()
    except Exception:
        db.session.rollback()
    return jsonify({
        'success': len(deleted) > 0,
        'deleted': len(deleted),
        'failed': failed,
        'message': f'{len(deleted)} record(s) deleted' + (f', {len(failed)} failed' if failed else ''),
    })

