"""
AEVORYN / INSIGHT-PULSE
DECISION INTELLIGENCE & HONEST INSIGHTS ROUTES (STAGE 18)

Provides honest, transparent, and explainable decision intelligence controllers.
Completely replaces fabricated AI confidence integers with verified statistical bounds,
deterministic rule metadata, and multi-domain causal synthesis.
"""

from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from services.analytics_service import AnalyticsService
from services.risk_service import RiskService
from services.decision_intelligence_service import DecisionIntelligenceService
from services.decision_intelligence.types import InsightSource, InsightCategory
from database.models.company import Company
from security.rbac import Permission, permission_required
from config.constants import CURRENCY_SYMBOLS

ai_insights_bp = Blueprint('ai_insights', __name__)


def _get_currency_symbol():
    """Get currency symbol from session or database."""
    currency_code = session.get('company_currency')
    if not currency_code:
        company = Company.query.get(session.get('company_id'))
        currency_code = getattr(company, 'currency', None) if company else None
        if not currency_code:
            currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@ai_insights_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol()
    summary = AnalyticsService.get_executive_summary(company_id)
    risk_summary = RiskService.get_risk_summary(company_id)
    
    # Filter support
    source_filter = request.args.get('source')
    category_filter = request.args.get('category')
    
    insights = DecisionIntelligenceService.get_insights(
        company_id=company_id,
        category=category_filter,
        source=source_filter
    )
    
    insights_dicts = [i.to_dict() for i in insights]
    
    return render_template(
        'ai/ai_insights.html',
        insights=insights_dicts,
        raw_insights=insights,
        summary=summary,
        risk_summary=risk_summary,
        currency_symbol=currency_symbol,
        sources=InsightSource.ALL,
        categories=InsightCategory.ALL,
        current_source=source_filter,
        current_category=category_filter
    )


@ai_insights_bp.route('/scan', methods=['POST'])
@ai_insights_bp.route('/api/scan', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def run_scan():
    """Triggers an immediate multi-domain decision intelligence scan for the active tenant."""
    company_id = session.get('company_id')
    result = DecisionIntelligenceService.run_decision_scan(
        company_id=company_id,
        actor_user_id=current_user.id,
        publish_events=True
    )
    
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(result)
        
    flash(f"Decision scan complete: {result.get('total_insights', 0)} verified insight(s) evaluated across operational, financial, and causal layers.", "info")
    return redirect(url_for('ai_insights.index'))


@ai_insights_bp.route('/api/insights', methods=['GET'])
@login_required
def api_insights():
    """Returns active decision insights with honest evidence dictionaries and confidence bounds."""
    company_id = session.get('company_id')
    category = request.args.get('category')
    source = request.args.get('source')
    
    insights = DecisionIntelligenceService.get_insights(
        company_id=company_id,
        category=category,
        source=source
    )
    return jsonify([i.to_dict() for i in insights])


@ai_insights_bp.route('/api/explain/<insight_id>', methods=['GET'])
@login_required
def api_explain(insight_id):
    """Provides deep explainability and empirical data provenance for a specific insight."""
    company_id = session.get('company_id')
    explanation = DecisionIntelligenceService.explain_insight(company_id, insight_id)
    if not explanation:
        abort(404)
    return jsonify(explanation)