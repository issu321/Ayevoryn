"""
AEVORYN / INSIGHT-PULSE
STAGE 21: DATA LAKE & DATA QUALITY ROUTE CONTROLLER
Observability portal for deterministic data quality scores, statistical anomalies, and end-to-end lineage DAGs.
"""

from flask import Blueprint, render_template, request, jsonify, abort
from flask_login import login_required, current_user
from database.models.document import Document
from database.models.import_history import ImportHistory
from database.models.financial import FinancialRecord
from database.models.customer import Customer
from database.models.employee import Employee
from database.models.inventory import Inventory
from database.models.supplier import Supplier
from database.models.department import Department
from security.tenant import get_current_company_id
from security.rbac import permission_required, Permission
from services.data_quality_service import DataQualityService

data_lake_bp = Blueprint('data_lake', __name__)


@data_lake_bp.route('/')
@login_required
def index():
    """Render Data Lake, Data Quality, and Lineage Observability command portal."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    quality_data = DataQualityService.evaluate_quality(company_id)
    anomalies = DataQualityService.detect_anomalies(company_id)
    documents = Document.query.filter_by(company_id=company_id, is_deleted=False).count()
    imports = ImportHistory.query.filter_by(company_id=company_id).order_by(
        ImportHistory.created_at.desc()
    ).limit(20).all()

    return render_template(
        'data_lake/data_lake.html',
        quality=quality_data,
        anomalies=anomalies,
        document_count=documents,
        imports=imports
    )


@data_lake_bp.route('/api/quality-summary')
@login_required
def api_quality_summary():
    """Get multi-dimensional data quality summary."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    quality_data = DataQualityService.evaluate_quality(company_id)
    return jsonify(quality_data)


@data_lake_bp.route('/api/rules')
@login_required
def api_rules():
    """Get auditable data quality rule evaluations."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    quality_data = DataQualityService.evaluate_quality(company_id)
    return jsonify({
        'rules': quality_data['rules'],
        'rules_passed': quality_data['rules_passed'],
        'rules_failed': quality_data['rules_failed'],
        'evaluated_at': quality_data['evaluated_at']
    })


@data_lake_bp.route('/api/anomalies')
@login_required
def api_anomalies():
    """Get detected statistical data anomalies."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    anomalies = DataQualityService.detect_anomalies(company_id)
    return jsonify({
        'anomalies': anomalies,
        'count': len(anomalies)
    })


@data_lake_bp.route('/api/lineage/metric/<metric_name>')
@login_required
def api_metric_lineage(metric_name):
    """Get directed acyclic graph (DAG) for a canonical metric."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    lineage = DataQualityService.get_metric_lineage(company_id, metric_name)
    return jsonify(lineage)


@data_lake_bp.route('/api/lineage/entity/<entity_type>/<int:entity_id>')
@login_required
def api_entity_lineage(entity_type, entity_id):
    """Get directed acyclic graph (DAG) for an entity instance with tenant IDOR protection."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    # Verify tenant ownership of the entity
    e_type = entity_type.lower().strip()
    entity = None
    if e_type in ('financial', 'financial_record', 'revenue', 'expense'):
        entity = FinancialRecord.query.filter_by(id=entity_id, company_id=company_id).first()
    elif e_type in ('customer', 'customers'):
        entity = Customer.query.filter_by(id=entity_id, company_id=company_id).first()
    elif e_type in ('employee', 'employees'):
        entity = Employee.query.filter_by(id=entity_id, company_id=company_id).first()
    elif e_type in ('inventory', 'inventory_item'):
        entity = Inventory.query.filter_by(id=entity_id, company_id=company_id).first()
    elif e_type in ('supplier', 'suppliers'):
        entity = Supplier.query.filter_by(id=entity_id, company_id=company_id).first()
    elif e_type in ('department', 'departments'):
        entity = Department.query.filter_by(id=entity_id, company_id=company_id).first()

    if not entity:
        return jsonify({'error': f'{entity_type.title()} #{entity_id} not found for this tenant.'}), 404

    lineage = DataQualityService.get_entity_lineage(company_id, entity_type, entity_id)
    return jsonify(lineage)


@data_lake_bp.route('/api/scan', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def api_scan():
    """Trigger a full data quality re-evaluation and anomaly scan."""
    company_id = get_current_company_id()
    if not company_id:
        return jsonify({'error': 'Not authenticated'}), 401

    user_id = current_user.id if current_user and current_user.is_authenticated else None
    quality_data = DataQualityService.evaluate_quality(company_id, user_id=user_id)

    return jsonify({
        'success': True,
        'message': 'Data quality and anomaly scan completed successfully.',
        'quality': quality_data
    })
