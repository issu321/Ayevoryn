"""
AEVORYN / INSIGHT-PULSE
STAGE 25: HEALTH PROBES & RUNTIME METRICS
Standard Kubernetes / Cloud Liveness (/healthz), Readiness (/readiness), and Telemetry endpoints.
"""

import os
from datetime import datetime
from flask import Blueprint, jsonify, current_app
from sqlalchemy import text
from database.db import db
from services.job_service import JobService

health_bp = Blueprint('health', __name__)


@health_bp.route('/healthz', methods=['GET'])
def liveness():
    """
    Kubernetes Liveness Probe.
    Fast check verifying the web server is responsive and accepting connections.
    """
    return jsonify({
        "status": "healthy",
        "service": "aevoryn-insight-pulse",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }), 200


@health_bp.route('/readiness', methods=['GET'])
def readiness():
    """
    Kubernetes Readiness Probe.
    Deep dependency check: validates database connectivity, storage accessibility,
    and background worker pool health before routing traffic.
    """
    checks = {}
    is_ready = True

    # 1. Database connectivity check
    try:
        db.session.execute(text("SELECT 1"))
        checks["database"] = {"status": "ok", "message": "Database query responsive"}
    except Exception as ex:
        checks["database"] = {"status": "error", "message": str(ex)}
        is_ready = False

    # 2. Storage write permission check
    upload_folder = current_app.config.get('UPLOAD_FOLDER', 'uploads')
    try:
        os.makedirs(upload_folder, exist_ok=True)
        test_file = os.path.join(upload_folder, '.health_check_tmp')
        with open(test_file, 'w') as f:
            f.write('ok')
        os.remove(test_file)
        checks["storage"] = {"status": "ok", "message": "Upload storage writable"}
    except Exception as ex:
        checks["storage"] = {"status": "error", "message": str(ex)}
        is_ready = False

    # 3. Background worker pool check
    try:
        executor = JobService.get_executor()
        checks["workers"] = {
            "status": "ok",
            "workers_available": getattr(executor, '_max_workers', 4)
        }
    except Exception as ex:
        checks["workers"] = {"status": "error", "message": str(ex)}
        is_ready = False

    response_payload = {
        "status": "ready" if is_ready else "not_ready",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "checks": checks
    }
    status_code = 200 if is_ready else 503
    return jsonify(response_payload), status_code


@health_bp.route('/health/metrics', methods=['GET'])
def metrics():
    """
    Runtime Telemetry Endpoint.
    Reports system uptime, worker thread metrics, and database engine info.
    """
    start_time = getattr(current_app, 'start_time', datetime.utcnow())
    uptime_seconds = round((datetime.utcnow() - start_time).total_seconds(), 2)

    registered_handlers = JobService.get_registered_job_types()
    backend_name = db.engine.url.get_backend_name()

    return jsonify({
        "status": "operational",
        "timestamp": datetime.utcnow().isoformat() + "Z",
        "uptime_seconds": uptime_seconds,
        "database": {
            "dialect": backend_name,
            "pooling": getattr(db.engine.pool, 'size', lambda: 'N/A')() if hasattr(db.engine.pool, 'size') else 'default'
        },
        "background_jobs": {
            "registered_handlers": [h['type'] for h in registered_handlers],
            "max_workers": getattr(JobService.get_executor(), '_max_workers', 4)
        }
    }), 200
