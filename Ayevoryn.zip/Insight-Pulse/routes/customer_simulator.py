from flask import Blueprint, render_template, request, jsonify, session
from flask_login import login_required, current_user
from database.models.customer import Customer
from database.models.company import Company
from services.simulation_service import SimulationService
from services.analytics_service import AnalyticsService
from security.rbac import permission_required, Permission
from config.constants import CURRENCY_SYMBOLS
from datetime import datetime

customer_bp = Blueprint('customer_simulator', __name__)


def _get_currency_symbol(company_id=None):
    currency_code = session.get('company_currency')
    if not currency_code and company_id:
        company = Company.query.get(company_id)
        if company and getattr(company, 'currency', None):
            currency_code = company.currency
    if not currency_code:
        currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@customer_bp.route('/')
@customer_bp.route('/simulator')
@login_required
def index():
    company_id = session.get('company_id')
    customers = Customer.query.filter_by(company_id=company_id).order_by(Customer.created_at.desc()).all()
    company = Company.query.get(company_id)
    currency_symbol = _get_currency_symbol(company_id)

    total_customers = len(customers)
    active_customers = len([c for c in customers if c.status == 'active'])
    churned_customers = len([c for c in customers if getattr(c, 'is_churned', False)])

    if total_customers == 0 and company:
        estimated_customers = AnalyticsService._estimate_customers(company)
        total_customers = estimated_customers
        active_customers = int(estimated_customers * 0.85)
        churned_customers = int(estimated_customers * 0.05)

    return render_template(
        'customer/customer_simulator.html',
        customers=customers,
        company=company,
        total_customers=total_customers,
        active_customers=active_customers,
        churned_customers=churned_customers,
        currency_symbol=currency_symbol
    )


@customer_bp.route('/run', methods=['POST'])
@customer_bp.route('/simulator/run', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def run_customer_simulation():
    """
    Execute real customer growth simulation backed by SimulationService and Monte Carlo distributions.
    """
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol(company_id)

    data = request.get_json(silent=True) or request.form or {}

    try:
        growth_rate = float(data.get('growth_rate', 10.0))
    except (ValueError, TypeError):
        growth_rate = 10.0

    try:
        retention = float(data.get('retention_improvement', 5.0))
    except (ValueError, TypeError):
        retention = 5.0

    channels = str(data.get('acquisition_channels', 'organic')).strip() or 'organic'

    try:
        iterations = int(data.get('iterations', 1000))
    except (ValueError, TypeError):
        iterations = 1000

    try:
        volatility = float(data.get('volatility', 0.15))
    except (ValueError, TypeError):
        volatility = 0.15

    seed = data.get('seed')
    if seed is not None:
        try:
            seed = int(seed)
        except (ValueError, TypeError):
            seed = None

    params = {
        'growth_rate': growth_rate,
        'acquisition_channels': channels,
        'retention_improvement': retention,
        'iterations': iterations,
        'volatility': volatility,
        'seed': seed
    }

    sim_name = f"Customer Growth ({growth_rate}%) - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    sim = SimulationService.run_simulation(
        company_id=company_id,
        user_id=current_user.id,
        sim_type='customer_growth',
        name=sim_name,
        parameters=params,
        currency_symbol=currency_symbol
    )

    sim_dict = sim.to_dict()
    res = sim.get_results()

    baseline = SimulationService._get_company_baseline(company_id)
    base_customers = baseline.get('customers', 100)
    actual_growth_rate = growth_rate / 100.0 if growth_rate > 1.0 else growth_rate
    actual_retention = retention / 100.0 if retention > 1.0 else retention

    growth_count = max(int(round(base_customers * actual_growth_rate)), 1) if actual_growth_rate > 0 else 0
    projected_customers = base_customers + growth_count
    retained_customers = int(round(projected_customers * actual_retention))
    net_customer_growth = projected_customers - base_customers

    return jsonify({
        'success': True,
        'simulation': sim_dict,
        'sim_id': sim.id,
        'current_customers': base_customers,
        'projected_customers': projected_customers,
        'retained_customers': retained_customers,
        'net_customer_growth': net_customer_growth,
        'revenue_before': sim.revenue_before,
        'revenue_after': sim.revenue_after,
        'profit_before': sim.profit_before,
        'profit_after': sim.profit_after,
        'p10_profit': res.get('p10_profit'),
        'p50_profit': res.get('p50_profit'),
        'p90_profit': res.get('p90_profit'),
        'confidence_low': sim.confidence_low,
        'confidence_high': sim.confidence_high,
        'monte_carlo': res.get('monte_carlo', {}),
        'recommendations': sim.recommendations
    })
