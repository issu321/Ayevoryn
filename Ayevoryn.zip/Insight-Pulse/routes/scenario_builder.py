import json
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for
from flask_login import login_required, current_user
from database.models.scenario import Scenario, ScenarioStep, ScenarioStatus, BranchType
from database.models.company import Company
from database.models.employee import Employee
from database.models.twin_snapshot import TwinSnapshot
from database.db import db
from services.analytics_service import AnalyticsService
from services.scenario_branching_service import ScenarioBranchingService
from security.rbac import roles_required, permission_required, Permission, Role
from config.constants import CURRENCY_SYMBOLS

scenario_bp = Blueprint('scenario_builder', __name__)


def _get_currency_symbol(company_id=None):
    currency = session.get('company_currency')
    if not currency and company_id:
        company = Company.query.get(company_id)
        if company:
            currency = company.currency
    return CURRENCY_SYMBOLS.get(currency or 'USD', '$')


@scenario_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    scenarios = Scenario.query.filter_by(company_id=company_id).order_by(Scenario.created_at.desc()).all()
    snapshots = TwinSnapshot.query.filter_by(company_id=company_id).order_by(TwinSnapshot.created_at.desc()).all()
    
    # Financial baseline context from company ledger
    summary = AnalyticsService.get_executive_summary(company_id)
    currency_symbol = _get_currency_symbol(company_id)

    # Calculate run-rate baselines
    rev_30d = float(summary.get('revenue_30d', 0.0) or 0.0)
    exp_30d = float(summary.get('expense_30d', 0.0) or 0.0)
    annual_rev_baseline = (rev_30d * 12.0) if rev_30d > 0 else float(getattr(company, 'annual_revenue', 0.0) or 100000.0)
    annual_exp_baseline = (exp_30d * 12.0) if exp_30d > 0 else (annual_rev_baseline * 0.75)
    baseline_profit = annual_rev_baseline - annual_exp_baseline
    baseline_margin = (baseline_profit / annual_rev_baseline * 100.0) if annual_rev_baseline else 0.0
    active_headcount = Employee.query.filter_by(company_id=company_id, status='active').count()

    baseline = {
        'annual_revenue': annual_rev_baseline,
        'annual_revenue_formatted': f"{currency_symbol}{annual_rev_baseline:,.2f}",
        'annual_expense': annual_exp_baseline,
        'annual_expense_formatted': f"{currency_symbol}{annual_exp_baseline:,.2f}",
        'annual_profit': baseline_profit,
        'annual_profit_formatted': f"{currency_symbol}{baseline_profit:,.2f}",
        'profit_margin': round(baseline_margin, 1),
        'headcount': active_headcount or getattr(company, 'employee_count', 1),
        'cash_reserves': float(summary.get('cash_balance', 0.0) or 0.0),
        'runway_months': float(summary.get('runway_months', 0.0) or 999.0)
    }

    # Lineage Tree
    tree = ScenarioBranchingService.get_branch_lineage_tree(company_id)

    # Enhance scenarios with parsed parameters for template
    scenarios_data = []
    for s in scenarios:
        s_dict = s.to_dict(include_details=True)
        scenarios_data.append(s_dict)

    return render_template('scenario/scenario_builder.html', 
                           scenarios=scenarios,
                           scenarios_data=scenarios_data,
                           snapshots=snapshots,
                           lineage_tree=tree,
                           baseline=baseline,
                           currency_symbol=currency_symbol,
                           branch_types=BranchType.ALL,
                           scenario_statuses=ScenarioStatus.ALL)


@scenario_bp.route('/create', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def create():
    company_id = session.get('company_id')
    is_json = request.is_json or request.headers.get('Content-Type') == 'application/json'
    data = request.get_json(silent=True) if is_json else request.form

    name = data.get('name', '').strip() if data else ''
    if not name:
        if is_json:
            return jsonify({'success': False, 'error': 'Scenario name is required'}), 400
        flash('Scenario name is required', 'error')
        return redirect(url_for('scenario_builder.index'))

    description = (data.get('description') or '').strip()
    scenario_type = data.get('scenario_type', 'Strategic')
    branch_type = data.get('branch_type', BranchType.SANDBOX)
    parent_scenario_id = data.get('parent_scenario_id')
    if parent_scenario_id in ('', 'none', 'None', None):
        parent_scenario_id = None
    else:
        try:
            parent_scenario_id = int(parent_scenario_id)
        except (ValueError, TypeError):
            parent_scenario_id = None

    baseline_snapshot_id = data.get('baseline_snapshot_id')
    if baseline_snapshot_id in ('', 'none', 'None', 'live', None):
        baseline_snapshot_id = None

    # Simulation delta parameters
    rev_delta = float(data.get('revenue_delta_pct', 0.0) or 0.0)
    exp_delta = float(data.get('expense_delta_pct', 0.0) or 0.0)
    headcount_delta = int(data.get('headcount_delta', 0) or 0)
    capex = float(data.get('capex_investment', 0.0) or 0.0)
    duration_months = int(data.get('duration_months', 12) or 12)

    params = {
        'revenue_delta_pct': rev_delta,
        'expense_delta_pct': exp_delta,
        'headcount_delta': headcount_delta,
        'capex_investment': capex,
        'duration_months': duration_months
    }

    try:
        scenario = ScenarioBranchingService.branch_scenario(
            company_id=company_id,
            user_id=current_user.id,
            name=name,
            parent_scenario_id=parent_scenario_id,
            baseline_snapshot_id=baseline_snapshot_id,
            scenario_type=scenario_type,
            branch_type=branch_type,
            description=description,
            parameters=params,
            deltas=params
        )
    except ValueError as e:
        if is_json:
            return jsonify({'success': False, 'error': str(e)}), 400
        flash(str(e), 'error')
        return redirect(url_for('scenario_builder.index'))

    if is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': True,
            'message': f'Scenario "{name}" branched successfully.',
            'scenario': scenario.to_dict(include_details=True)
        })

    flash(f'Scenario "{name}" created successfully!', 'success')
    return redirect(url_for('scenario_builder.index'))


@scenario_bp.route('/run/<int:scenario_id>', methods=['GET', 'POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def run_scenario(scenario_id):
    company_id = session.get('company_id')
    scenario = Scenario.query.filter_by(id=scenario_id, company_id=company_id).first()
    if not scenario:
        return jsonify({'success': False, 'error': 'Scenario not found'}), 404

    currency_symbol = _get_currency_symbol(company_id)
    evaluation = ScenarioBranchingService.evaluate_branch(company_id, scenario_id)

    b = evaluation['baseline']
    p = evaluation['projected']
    v = evaluation['variance']
    r = evaluation['risk']

    steps = [st.to_dict() for st in scenario.steps.order_by(ScenarioStep.step_number.asc()).all()]

    return jsonify({
        'success': True,
        'scenario_id': scenario.id,
        'scenario_name': scenario.name,
        'scenario_type': scenario.scenario_type,
        'branch_type': scenario.branch_type,
        'status': scenario.status,
        'currency_symbol': currency_symbol,
        'baseline': {
            'revenue': b['revenue'],
            'revenue_formatted': f"{currency_symbol}{b['revenue']:,.2f}",
            'expense': b['expense'],
            'expense_formatted': f"{currency_symbol}{b['expense']:,.2f}",
            'profit': b['profit'],
            'profit_formatted': f"{currency_symbol}{b['profit']:,.2f}",
            'margin': b['margin'],
            'headcount': b['headcount'],
            'cash': b.get('cash', 0.0),
            'runway_months': b.get('runway_months', 999.0)
        },
        'projected': {
            'revenue': p['revenue'],
            'revenue_formatted': f"{currency_symbol}{p['revenue']:,.2f}",
            'expense': p['expense'],
            'expense_formatted': f"{currency_symbol}{p['expense']:,.2f}",
            'profit': p['profit'],
            'profit_formatted': f"{currency_symbol}{p['profit']:,.2f}",
            'margin': p['margin'],
            'headcount': p['headcount'],
            'cash': p.get('cash', 0.0),
            'runway_months': p.get('runway_months', 999.0)
        },
        'variance': {
            'revenue_delta_formatted': f"{currency_symbol}{v['revenue_delta']:+,.2f} ({v['revenue_delta_pct']:+0.1f}%)",
            'expense_delta_formatted': f"{currency_symbol}{v['expense_delta']:+,.2f} ({v['expense_delta_pct']:+0.1f}%)",
            'profit_delta_formatted': f"{currency_symbol}{v['profit_delta']:+,.2f}",
            'margin_delta_formatted': f"{v['margin_delta']:+0.1f}%",
            'net_benefit': v['net_benefit'],
            'roi_pct': v['roi_pct'],
            'payback_months': v['payback_months'],
            'risk_level': r['level'],
            'risk_color': r['color'],
            'risk_reasons': r.get('reasons', [])
        },
        'steps': steps
    })


@scenario_bp.route('/api/branch', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def api_branch():
    """Explicit JSON endpoint to spin up an isolated scenario branch."""
    company_id = session.get('company_id')
    data = request.get_json(silent=True) or {}
    
    name = (data.get('name') or '').strip()
    if not name:
        return jsonify({'success': False, 'error': 'Scenario name is required'}), 400

    try:
        scenario = ScenarioBranchingService.branch_scenario(
            company_id=company_id,
            user_id=current_user.id,
            name=name,
            parent_scenario_id=data.get('parent_scenario_id'),
            baseline_snapshot_id=data.get('baseline_snapshot_id'),
            scenario_type=data.get('scenario_type', 'Strategic'),
            branch_type=data.get('branch_type', BranchType.SANDBOX),
            description=data.get('description', ''),
            parameters=data.get('parameters'),
            deltas=data.get('deltas')
        )
        return jsonify({
            'success': True,
            'scenario': scenario.to_dict(include_details=True)
        }), 201
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 400
    except Exception as e:
        return jsonify({'success': False, 'error': f"Failed to branch scenario: {str(e)}"}), 500


@scenario_bp.route('/api/evaluate/<int:scenario_id>', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def api_evaluate(scenario_id):
    """Evaluates the forward projection of a scenario branch with zero live mutation."""
    company_id = session.get('company_id')
    try:
        evaluation = ScenarioBranchingService.evaluate_branch(company_id, scenario_id)
        return jsonify({
            'success': True,
            'scenario_id': scenario_id,
            'evaluation': evaluation
        })
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': f"Evaluation failed: {str(e)}"}), 500


@scenario_bp.route('/api/compare/<int:scenario_id>', methods=['GET'])
@login_required
def api_compare(scenario_id):
    """Compares scenario A to baseline or scenario A to scenario B."""
    company_id = session.get('company_id')
    compare_to = request.args.get('compare_to', type=int)
    try:
        result = ScenarioBranchingService.compare_branches(company_id, scenario_id, compare_to)
        return jsonify({
            'success': True,
            'comparison': result
        })
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': f"Comparison failed: {str(e)}"}), 500


@scenario_bp.route('/api/merge/<int:scenario_id>', methods=['POST'])
@login_required
@roles_required(Role.OWNER, Role.ADMIN, Role.MANAGER)
def api_merge(scenario_id):
    """
    Merges an evaluated scenario branch into the company's formal target plan.
    Zero mutation of historical ledger records is guaranteed.
    """
    company_id = session.get('company_id')
    try:
        result = ScenarioBranchingService.merge_to_plan(company_id, scenario_id, current_user.id)
        return jsonify(result)
    except ValueError as e:
        return jsonify({'success': False, 'error': str(e)}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': f"Merge failed: {str(e)}"}), 500


@scenario_bp.route('/api/tree', methods=['GET'])
@login_required
def api_tree():
    """Returns the hierarchical branch lineage tree."""
    company_id = session.get('company_id')
    tree = ScenarioBranchingService.get_branch_lineage_tree(company_id)
    return jsonify({
        'success': True,
        'tree': tree
    })


@scenario_bp.route('/delete/<int:scenario_id>', methods=['POST', 'DELETE'])
@login_required
@permission_required(Permission.DATA_DELETE)
def delete_scenario(scenario_id):
    company_id = session.get('company_id')
    scenario = Scenario.query.filter_by(id=scenario_id, company_id=company_id).first()
    if not scenario:
        return jsonify({'success': False, 'error': 'Scenario not found'}), 404

    name = scenario.name
    ScenarioBranchingService.delete_scenario(company_id, scenario_id)

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'message': f'Scenario "{name}" deleted successfully.'})

    flash(f'Scenario "{name}" deleted successfully.', 'success')
    return redirect(url_for('scenario_builder.index'))
