from flask import Blueprint, render_template, request, jsonify, session
from flask_login import login_required, current_user
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.company import Company
from services.simulation_service import SimulationService
from security.rbac import permission_required, Permission
from config.constants import CURRENCY_SYMBOLS
from datetime import datetime

supply_chain_bp = Blueprint('supply_chain_simulator', __name__)


def _get_currency_symbol(company_id=None):
    """Get currency symbol from session or database."""
    currency_code = session.get('company_currency')
    if not currency_code and company_id:
        company = Company.query.get(company_id)
        currency_code = getattr(company, 'currency', None) if company else None
    if not currency_code:
        currency_code = 'USD'
    return CURRENCY_SYMBOLS.get(currency_code, '$')


@supply_chain_bp.route('/')
@supply_chain_bp.route('/simulator')
@login_required
def index():
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol(company_id)
    suppliers = Supplier.query.filter_by(company_id=company_id).all()
    items = Inventory.query.filter_by(company_id=company_id, is_active=True).all()
    return render_template(
        'supply_chain/supply_chain_simulator.html',
        suppliers=suppliers,
        items=items,
        currency_symbol=currency_symbol
    )


@supply_chain_bp.route('/run', methods=['POST'])
@supply_chain_bp.route('/simulator/run', methods=['POST'])
@login_required
@permission_required(Permission.SIMULATION_RUN)
def run_supply_chain_simulation():
    """
    Execute real supply chain / supplier change simulation backed by SimulationService and Monte Carlo distributions.
    """
    company_id = session.get('company_id')
    currency_symbol = _get_currency_symbol(company_id)

    data = request.get_json(silent=True) or request.form or {}

    supplier_id = data.get('supplier_id')
    supplier_name = 'Supplier'
    if supplier_id:
        try:
            supplier_id = int(supplier_id)
            supp = Supplier.query.filter_by(id=supplier_id, company_id=company_id).first()
            if not supp:
                return jsonify({'error': 'Supplier not found'}), 404
            supplier_name = supp.name
        except (ValueError, TypeError):
            pass

    try:
        current_cost = float(data.get('current_cost', 100.0))
    except (ValueError, TypeError):
        current_cost = 100.0

    try:
        new_cost = float(data.get('new_cost', 85.0))
    except (ValueError, TypeError):
        new_cost = 85.0

    try:
        volume = float(data.get('volume', 1000.0))
    except (ValueError, TypeError):
        volume = 1000.0

    quality_rating = data.get('quality_rating', '4')

    try:
        lead_time = int(data.get('lead_time', data.get('lead_time_days', 14)))
    except (ValueError, TypeError):
        lead_time = 14

    try:
        transition_cost = float(data.get('transition_cost', 5000.0))
    except (ValueError, TypeError):
        transition_cost = 5000.0

    try:
        iterations = int(data.get('iterations', 1000))
    except (ValueError, TypeError):
        iterations = 1000

    try:
        volatility = float(data.get('volatility', 0.15))
    except (ValueError, TypeError):
        volatility = 0.15

    seed = data.get('seed')
    if seed is not None:
        try:
            seed = int(seed)
        except (ValueError, TypeError):
            seed = None

    params = {
        'current_cost': current_cost,
        'new_cost': new_cost,
        'volume': volume,
        'quality_rating': quality_rating,
        'lead_time': lead_time,
        'transition_cost': transition_cost,
        'supplier_id': supplier_id,
        'supplier_name': supplier_name,
        'iterations': iterations,
        'volatility': volatility,
        'seed': seed
    }

    sim_name = f"Supplier Change ({supplier_name}) - {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    sim = SimulationService.run_simulation(
        company_id=company_id,
        user_id=current_user.id,
        sim_type='supplier_change',
        name=sim_name,
        parameters=params,
        currency_symbol=currency_symbol
    )

    sim_dict = sim.to_dict()
    res = sim.get_results()

    monthly_savings = res.get('monthly_savings', round((current_cost - new_cost) * volume, 2))
    annual_savings = res.get('annual_savings', round(monthly_savings * 12, 2))
    net_savings = res.get('net_savings', round(annual_savings - transition_cost, 2))

    return jsonify({
        'success': True,
        'simulation': sim_dict,
        'sim_id': sim.id,
        'supplier_id': supplier_id,
        'supplier_name': supplier_name,
        'current_cost': current_cost,
        'new_cost': new_cost,
        'volume': volume,
        'monthly_savings': monthly_savings,
        'annual_savings': annual_savings,
        'net_savings': net_savings,
        'payback_months': res.get('payback_months'),
        'risk_score': sim.risk_score,
        'revenue_before': sim.revenue_before,
        'revenue_after': sim.revenue_after,
        'cost_before': sim.cost_before,
        'cost_after': sim.cost_after,
        'profit_before': sim.profit_before,
        'profit_after': sim.profit_after,
        'p10_profit': res.get('p10_profit'),
        'p50_profit': res.get('p50_profit'),
        'p90_profit': res.get('p90_profit'),
        'confidence_low': sim.confidence_low,
        'confidence_high': sim.confidence_high,
        'monte_carlo': res.get('monte_carlo', {}),
        'recommendations': sim.recommendations
    })
