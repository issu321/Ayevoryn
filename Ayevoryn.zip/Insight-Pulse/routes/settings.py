from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for
from flask_login import login_required, current_user
from database.models.company import Company
from database.models.company_payments import CompanyPayments
from database.models.theme_preference import ThemePreference
from database.models.user import User
from services.company_service import CompanyService
from security.password_hash import hash_password
from security.rbac import Role, roles_required
from database.db import db
from config.themes import THEMES, get_theme_css, resolve_theme_id
from config.constants import CURRENCIES, CURRENCY_SYMBOLS, TIMEZONES, INDUSTRIES, BUSINESS_TYPES, TAX_TYPES

settings_bp = Blueprint('settings', __name__)

@settings_bp.route('/')
@login_required
def index():
    from security.tenant import get_current_company_id
    company_id = get_current_company_id() or getattr(current_user, 'company_id', None)
    company = db.session.get(Company, company_id) if company_id else Company.query.first()
    payments = CompanyPayments.query.filter_by(company_id=company_id).first()
    theme_pref = ThemePreference.query.filter_by(user_id=current_user.id).first()
    current_theme = theme_pref.theme_id if theme_pref else session.get('theme', 'white_clay_glass')
    
    return render_template('settings/settings.html',
                         company=company,
                         payments=payments,
                         themes=THEMES,
                         current_theme=current_theme,
                         theme_id=current_theme,
                         currencies=CURRENCIES,
                         currency_symbols=CURRENCY_SYMBOLS,
                         timezones=TIMEZONES,
                         industries=INDUSTRIES,
                         business_types=BUSINESS_TYPES,
                         tax_types=TAX_TYPES)

@settings_bp.route('/company', methods=['POST'])
@login_required
@roles_required('Owner', 'Admin')
def update_company():
    from security.tenant import get_current_company_id
    company_id = get_current_company_id() or getattr(current_user, 'company_id', None)
    
    # Safe numerical parsing
    tax_rate_raw = request.form.get('tax_rate', '0').strip()
    try:
        tax_rate = float(tax_rate_raw) if tax_rate_raw else 0.0
    except (ValueError, TypeError):
        tax_rate = 0.0

    rev_raw = request.form.get('annual_revenue', '0').strip()
    try:
        annual_revenue = float(rev_raw) if rev_raw else 0.0
    except (ValueError, TypeError):
        annual_revenue = 0.0

    emp_raw = request.form.get('employee_count', '0').strip()
    try:
        employee_count = int(emp_raw) if emp_raw else 0
    except (ValueError, TypeError):
        employee_count = 0

    comp_name = request.form.get('company_name', '').strip() or request.form.get('name', '').strip()
    currency = request.form.get('currency', 'USD').strip() or 'USD'
    timezone = request.form.get('timezone', 'UTC').strip() or 'UTC'

    data = {
        'company_name': comp_name,
        'business_name': request.form.get('business_name', '').strip() or comp_name,
        'industry': request.form.get('industry', 'Technology'),
        'business_type': request.form.get('business_type', 'Startup'),
        'currency': currency,
        'timezone': timezone,
        'tax_type': request.form.get('tax_type', 'GST'),
        'tax_rate': tax_rate,
        'annual_revenue': annual_revenue,
        'employee_count': employee_count,
        'country': request.form.get('country', '').strip(),
        'city': request.form.get('city', '').strip(),
        'email': request.form.get('email', '').strip(),
        'mobile': request.form.get('mobile', '').strip(),
        'whatsapp_number': request.form.get('whatsapp_number', '').strip(),
        'website': request.form.get('website', '').strip(),
        'description': request.form.get('description', '').strip(),
    }
    
    company = CompanyService.update_company(company_id, data)
    
    # ── Immediate Live Session Synchronization ──
    if company:
        session['company_name'] = company.company_name
        session['company_currency'] = company.currency
        session['currency_symbol'] = CURRENCY_SYMBOLS.get(company.currency, '$')
        session['company_timezone'] = company.timezone

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': True,
            'message': 'Company settings updated and live session synchronized!',
            'company_name': company.company_name if company else comp_name,
            'currency': company.currency if company else currency,
            'currency_symbol': CURRENCY_SYMBOLS.get(company.currency if company else currency, '$'),
            'timezone': company.timezone if company else timezone
        })

    flash('Enterprise settings saved and live session updated!', 'success')
    return redirect(url_for('settings.index'))

@settings_bp.route('/theme', methods=['GET', 'POST'])
def update_theme():
    raw_theme_id = None
    if request.is_json:
        data = request.get_json(silent=True) or {}
        raw_theme_id = data.get('theme_id') or data.get('theme')
    if not raw_theme_id:
        raw_theme_id = request.form.get('theme_id') or request.form.get('theme') or request.args.get('theme_id') or request.args.get('theme', 'white_clay_glass')
    theme_id = resolve_theme_id(raw_theme_id)
    session['theme'] = theme_id
    session.modified = True
    
    if hasattr(current_user, 'is_authenticated') and current_user.is_authenticated:
        try:
            theme_pref = ThemePreference.query.filter_by(user_id=current_user.id).first()
            if theme_pref:
                theme_pref.theme_id = theme_id
            else:
                theme_pref = ThemePreference(user_id=current_user.id, theme_id=theme_id)
                db.session.add(theme_pref)
            db.session.commit()
        except Exception:
            db.session.rollback()
    
    theme_info = dict(THEMES.get(theme_id, THEMES['white_clay_glass']))
    css = get_theme_css(theme_id)
    
    resp = jsonify({
        'success': True,
        'theme_id': theme_id,
        'theme': theme_info,
        'css': css
    })
    resp.set_cookie('aevoryn_theme', theme_id, max_age=31536000, path='/', samesite='Lax')
    return resp

@settings_bp.route('/profile', methods=['POST'])
@login_required
def update_profile():
    first_name = request.form.get('first_name', '').strip()
    last_name = request.form.get('last_name', '').strip()
    email = request.form.get('email', '').strip()
    
    if first_name: current_user.first_name = first_name
    if last_name: current_user.last_name = last_name
    if email: current_user.email = email
    
    current_pw = request.form.get('current_password', '').strip()
    new_pw = request.form.get('new_password', '').strip()
    confirm_pw = request.form.get('confirm_password', '').strip()
    
    if new_pw or confirm_pw:
        if not current_pw:
            flash('Current password is required to change your credentials.', 'danger')
            return redirect(url_for('settings.index'))
        if not current_user.check_password(current_pw):
            flash('Current password verification failed. Password was not updated.', 'danger')
            return redirect(url_for('settings.index'))
        if len(new_pw) < 6:
            flash('New password must be at least 6 characters long.', 'danger')
            return redirect(url_for('settings.index'))
        if new_pw != confirm_pw:
            flash('New passwords do not match.', 'danger')
            return redirect(url_for('settings.index'))
        current_user.set_password(new_pw)
        flash('Password updated successfully!', 'success')
    
    db.session.commit()
    flash('Profile updated successfully!', 'success')
    return redirect(url_for('settings.index'))

import os
import uuid
from werkzeug.utils import secure_filename

ALLOWED_LOGO_EXTENSIONS = {'png', 'jpg', 'jpeg', 'svg', 'webp', 'gif'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_LOGO_EXTENSIONS

@settings_bp.route('/upload-logo', methods=['POST'])
@login_required
@roles_required('Owner', 'Admin')
def upload_logo():
    from datetime import datetime
    from security.tenant import get_current_company_id
    from routes.uploads import validate_and_extract_image, persist_image_asset, remove_persisted_files
    from services.events import EventBus, DomainEvent, EventTypes

    company_id = get_current_company_id() or getattr(current_user, 'company_id', None)
    company = db.session.get(Company, company_id) if company_id else None
    if not company:
        return jsonify({'success': False, 'error': 'Organization not found or unauthorized'}), 404

    action = request.form.get('action', 'upload')
    if action == 'remove':
        old_path = company.logo_path
        company.logo_path = None
        company.logo_data = None
        company.logo_mime = None
        company.logo_updated_at = datetime.utcnow()
        session.pop('company_logo', None)
        db.session.commit()
        if old_path:
            remove_persisted_files(old_path)
        return jsonify({
            'success': True,
            'message': 'Company logo removed. Initial monogram restored.',
            'logo_url': None
        })

    if 'logo_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file part in request'}), 400

    file = request.files['logo_file']
    raw_bytes, ext, mime_type, err = validate_and_extract_image(file)
    if err:
        return jsonify({'success': False, 'error': err}), 400

    old_path = company.logo_path
    relative_path, b64_data = persist_image_asset(raw_bytes, ext, 'logos', f"company_{company.id}")

    company.logo_path = relative_path
    company.logo_data = b64_data
    company.logo_mime = mime_type
    company.logo_updated_at = datetime.utcnow()
    session['company_logo'] = relative_path
    session.modified = True
    db.session.commit()

    if old_path and old_path != relative_path:
        remove_persisted_files(old_path)

    try:
        EventBus.publish(DomainEvent(
            event_type='COMPANY_BRANDING_UPDATED',
            company_id=company.id,
            actor_id=current_user.id,
            actor_name=current_user.username,
            entity_type='company',
            entity_id=str(company.id),
            payload={'logo_url': company.logo_url, 'company_name': company.company_name}
        ))
    except Exception:
        pass

    return jsonify({
        'success': True,
        'message': 'Company logo permanently saved to database and storage!',
        'logo_url': company.logo_url,
        'static_url': url_for('static', filename=relative_path)
    })


@settings_bp.route('/upload-avatar', methods=['POST'])
@login_required
def upload_avatar():
    from datetime import datetime
    from routes.uploads import validate_and_extract_image, persist_image_asset, remove_persisted_files
    from services.events import EventBus, DomainEvent

    user = db.session.get(User, current_user.id)
    if not user:
        return jsonify({'success': False, 'error': 'Authenticated user not found'}), 404

    action = request.form.get('action', 'upload')
    if action == 'remove':
        old_path = user.avatar_path
        user.avatar_path = None
        user.avatar_data = None
        user.avatar_mime = None
        user.avatar_updated_at = datetime.utcnow()
        session.pop('user_avatar', None)
        db.session.commit()
        if old_path:
            remove_persisted_files(old_path)
        return jsonify({
            'success': True,
            'message': 'Profile photo removed. Initial monogram restored.',
            'avatar_url': None
        })

    if 'avatar_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file part in request'}), 400

    file = request.files['avatar_file']
    raw_bytes, ext, mime_type, err = validate_and_extract_image(file)
    if err:
        return jsonify({'success': False, 'error': err}), 400

    old_path = user.avatar_path
    relative_path, b64_data = persist_image_asset(raw_bytes, ext, 'avatars', f"user_{user.id}")

    user.avatar_path = relative_path
    user.avatar_data = b64_data
    user.avatar_mime = mime_type
    user.avatar_updated_at = datetime.utcnow()
    session['user_avatar'] = relative_path
    session.modified = True
    db.session.commit()

    if old_path and old_path != relative_path:
        remove_persisted_files(old_path)

    try:
        EventBus.publish(DomainEvent(
            event_type='USER_PROFILE_UPDATED',
            company_id=user.company_id or session.get('company_id') or 1,
            actor_id=user.id,
            actor_name=user.username,
            entity_type='user',
            entity_id=str(user.id),
            payload={'avatar_url': user.avatar_url, 'username': user.username}
        ))
    except Exception:
        pass

    return jsonify({
        'success': True,
        'message': 'Profile photo permanently saved to database and storage!',
        'avatar_url': user.avatar_url,
        'static_url': url_for('static', filename=relative_path)
    })
