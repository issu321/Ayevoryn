"""
AEVORYN / INSIGHT-PULSE
STAGE 23: BACKGROUND JOBS MANAGEMENT & MONITORING DASHBOARD
Enterprise UI & Web Controller for Asynchronous Task Worker.
"""

from flask import Blueprint, render_template, jsonify, request, redirect, flash, url_for
from flask_login import login_required, current_user
from database.models.job import BackgroundJob
from services.job_service import JobService
from security.tenant import get_current_company_id
from security.rbac import permission_required, Permission

jobs_bp = Blueprint('jobs', __name__, url_prefix='/jobs')


@jobs_bp.route('/')
@login_required
def index():
    """Jobs dashboard showing recent runs, active workers, and job queues."""
    cid = get_current_company_id()
    if not cid:
        return redirect('/logout')

    status_filter = request.args.get('status')
    type_filter = request.args.get('type')

    jobs = JobService.list_jobs(
        company_id=cid,
        status=status_filter if status_filter else None,
        job_type=type_filter if type_filter else None,
        limit=50
    )

    stats = JobService.get_job_stats(cid)
    registered_types = JobService.get_registered_job_types()

    return render_template(
        'jobs/jobs.html',
        jobs=jobs,
        stats=stats,
        job_types=registered_types,
        status_filter=status_filter,
        type_filter=type_filter
    )


@jobs_bp.route('/<job_id>')
@login_required
def detail(job_id):
    """View details, execution trace, and results of a specific background job."""
    cid = get_current_company_id()
    if not cid:
        return redirect('/logout')

    job = JobService.get_job(job_id, company_id=cid)
    if not job:
        flash('Background job not found or does not belong to your company.', 'warning')
        return redirect(url_for('jobs.index'))

    return render_template('jobs/detail.html', job=job)


@jobs_bp.route('/api/status/<job_id>', methods=['GET'])
@login_required
def job_status_api(job_id):
    """Real-time JSON endpoint for live status polling."""
    cid = get_current_company_id()
    job = JobService.get_job(job_id, company_id=cid)
    if not job:
        return jsonify({"success": False, "error": "Job not found"}), 404

    return jsonify({
        "success": True,
        "job": job.to_dict()
    })


@jobs_bp.route('/api/cancel/<job_id>', methods=['POST'])
@login_required
def cancel_job_action(job_id):
    """Cancel a pending or running background job."""
    cid = get_current_company_id()
    job = JobService.cancel_job(job_id, company_id=cid, user_id=getattr(current_user, 'id', None))
    if not job:
        return jsonify({"success": False, "error": "Job not found or cannot be cancelled"}), 400

    return jsonify({
        "success": True,
        "message": f"Job {job_id} cancelled.",
        "job": job.to_dict()
    })


@jobs_bp.route('/api/enqueue', methods=['POST'])
@login_required
def enqueue_action():
    """Trigger a new job from web UI."""
    cid = get_current_company_id()
    data = request.get_json(silent=True) or request.form or {}
    job_type = data.get('job_type')
    payload = data.get('payload', {})
    if isinstance(payload, str):
        import json
        try:
            payload = json.loads(payload)
        except Exception:
            payload = {}

    if not job_type:
        return jsonify({"success": False, "error": "Job type required"}), 400

    try:
        job = JobService.enqueue_job(
            job_type=job_type,
            company_id=cid,
            payload=payload,
            user_id=getattr(current_user, 'id', None)
        )
        return jsonify({
            "success": True,
            "job": job.to_dict()
        }), 202
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 400
