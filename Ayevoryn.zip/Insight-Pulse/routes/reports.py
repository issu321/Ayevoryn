from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, send_file, current_app
from flask_login import login_required, current_user
from database.models.report import Report
from database.models.company import Company
from services.report_service import ReportService
from config.constants import REPORT_TYPES, REPORT_LABELS, CURRENCY_SYMBOLS
from database.db import db
from datetime import datetime
import os

reports_bp = Blueprint('reports', __name__)

def _get_currency_symbol():
    """Get currency symbol from session or fallback to CURRENCY_SYMBOLS."""
    if 'currency_symbol' in session:
        return session['currency_symbol']
    currency = session.get('company_currency', 'USD')
    return CURRENCY_SYMBOLS.get(currency, '$')

@reports_bp.route('/')
@login_required
def center():
    company_id = session.get('company_id')
    reports = Report.query.filter_by(company_id=company_id).order_by(Report.created_at.desc()).all()
    company = Company.query.get(company_id)
    currency_symbol = _get_currency_symbol()
    return render_template('reports/report_center.html', 
                         reports=reports,
                         report_types=REPORT_TYPES,
                         report_labels=REPORT_LABELS,
                         report_configs=ReportService.REPORT_TYPE_CONFIG,
                         company=company,
                         currency_symbol=currency_symbol)

@reports_bp.route('/api/deliverable-preview/<report_type>/<format_type>')
@login_required
def api_deliverable_preview(report_type, format_type):
    manifest = ReportService.get_deliverable_manifest(report_type, format_type)
    return jsonify(manifest)

@reports_bp.route('/generate', methods=['POST'])
@login_required
def generate():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    report_type = (request.form.get('report_type', 'executive') or 'executive').strip().lower()
    name = request.form.get('name', '').strip()
    format_type = (request.form.get('format', 'pdf') or 'pdf').strip().lower()
    currency_symbol = _get_currency_symbol()

    if report_type not in REPORT_TYPES:
        flash('Please select a valid report type.', 'danger')
        return redirect(url_for('reports.center'))
    if format_type == 'xlsx':
        format_type = 'excel'
    if format_type not in {'pdf', 'csv', 'excel'}:
        flash('Please select a valid export format.', 'danger')
        return redirect(url_for('reports.center'))
    
    if not name:
        comp_name = company.company_name if company and company.company_name else 'Enterprise'
        name = f"{comp_name} - {REPORT_LABELS.get(report_type, 'Report')} - {datetime.now().strftime('%Y-%m-%d')}"
    
    report = ReportService.generate_report(
        company_id, current_user.id, report_type, name, format_type, currency_symbol=currency_symbol
    )
    
    if report.file_path and os.path.exists(report.file_path):
        flash(f'Report "{name}" generated successfully as {format_type.upper()} ({os.path.basename(report.file_path)})!', 'success')
    else:
        flash(f'Report generation failed: {report.summary}', 'danger')
    return redirect(url_for('reports.center'))

@reports_bp.route('/re-export/<int:report_id>/<format_type>', methods=['POST'])
@login_required
def re_export(report_id, format_type):
    report = Report.query.get_or_404(report_id)
    if report.company_id != session.get('company_id'):
        flash('Access denied', 'danger')
        return redirect(url_for('reports.center'))
    
    fmt = (format_type or 'pdf').strip().lower()
    if fmt == 'xlsx':
        fmt = 'excel'
    if fmt not in {'pdf', 'excel', 'csv'}:
        flash('Invalid format requested for re-export.', 'danger')
        return redirect(url_for('reports.center'))
    
    currency_symbol = _get_currency_symbol()
    clean_base_name = report.name
    # Strip existing format parenthetical if any
    for existing_fmt in ['(PDF)', '(EXCEL)', '(CSV)', '(XLSX)']:
        if clean_base_name.upper().endswith(existing_fmt):
            clean_base_name = clean_base_name[:-len(existing_fmt)].strip()
            
    name = f"{clean_base_name} ({fmt.upper()})"
    new_report = ReportService.generate_report(
        report.company_id, current_user.id, report.report_type, name, fmt, currency_symbol=currency_symbol
    )
    
    if new_report.file_path and os.path.exists(new_report.file_path):
        flash(f'Companion report "{name}" successfully generated in {fmt.upper()} format!', 'success')
    else:
        flash(f'Companion generation failed: {new_report.summary}', 'danger')
    return redirect(url_for('reports.center'))

@reports_bp.route('/delete/<int:report_id>', methods=['POST'])
@login_required
def delete(report_id):
    report = Report.query.get_or_404(report_id)
    if report.company_id != session.get('company_id'):
        flash('Access denied', 'danger')
        return redirect(url_for('reports.center'))
    
    # Unlink file from filesystem if present
    if report.file_path and os.path.exists(report.file_path):
        try:
            os.remove(report.file_path)
        except Exception:
            pass
            
    name = report.name
    db.session.delete(report)
    db.session.commit()
    flash(f'Report "{name}" has been deleted.', 'success')
    return redirect(url_for('reports.center'))

@reports_bp.route('/download/<int:report_id>')
@login_required
def download(report_id):
    report = Report.query.get_or_404(report_id)
    if report.company_id != session.get('company_id'):
        flash('Access denied', 'danger')
        return redirect(url_for('reports.center'))
    
    if not report.file_path:
        flash('Report file not available', 'danger')
        return redirect(url_for('reports.center'))
    
    # Resolve file path - handle both relative and absolute paths
    file_path = report.file_path
    if not os.path.isabs(file_path):
        file_path = os.path.join(current_app.root_path, file_path)
    
    # If file doesn't exist, regenerate on-the-fly
    if not os.path.exists(file_path):
        try:
            new_path = ReportService.generate_file_for_report(
                report,
                report.company_id,
                report.report_type,
                report.format,
                currency_symbol=_get_currency_symbol()
            )
            report.file_path = new_path
            report.last_generated = datetime.utcnow()
            if os.path.exists(new_path):
                report.file_size = os.path.getsize(new_path)
            db.session.commit()
            file_path = new_path
            if not os.path.isabs(file_path):
                file_path = os.path.join(current_app.root_path, file_path)
        except Exception as e:
            flash(f'File not found and regeneration failed: {str(e)}', 'danger')
            return redirect(url_for('reports.center'))
    
    if os.path.exists(file_path):
        filename = os.path.basename(file_path)
        return send_file(
            file_path,
            as_attachment=True,
            download_name=filename
        )
    
    flash('File not found', 'danger')
    return redirect(url_for('reports.center'))

@reports_bp.route('/view/<report_type>')
@login_required
def view(report_type):
    report_type = (report_type or 'executive').strip().lower()
    if report_type not in REPORT_TYPES:
        flash('Please select a valid report type to view.', 'warning')
        return redirect(url_for('reports.center'))
        
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    currency_symbol = _get_currency_symbol()
    data = ReportService._get_report_data(company_id, report_type, currency_symbol)
    config = ReportService.REPORT_TYPE_CONFIG.get(report_type, ReportService.REPORT_TYPE_CONFIG['executive'])
    
    return render_template('reports/report_view.html',
                           report_type=report_type,
                           config=config,
                           data=data,
                           company=company,
                           currency_symbol=currency_symbol,
                           report_labels=REPORT_LABELS)