from flask import Blueprint, render_template, request, jsonify, session, send_file, flash
from flask_login import login_required, current_user
from database.models.company import Company
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.branch import Branch
from database.models.department import Department
from database.models.department_budget import DepartmentBudget
from database.models.department_invitation import DepartmentInvitation
from database.models.company_payments import CompanyPayments
from database.models.project import Project
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.app_config import AppConfig
from database.models.core_twin_extra import CoreTwinExtraRecord

from services.analytics_service import AnalyticsService
from database.db import db
from sqlalchemy import func
from sqlalchemy.orm import joinedload
from collections import Counter
import csv
import io
import os
import json
import logging
from datetime import datetime, date, timedelta
from services.events import DomainEvent, EventTypes, publish_event
from services.company_service import CompanyService
from services.twin_record_service import TwinRecordService
from services.universal_filter_service import UniversalFilterService

logger = logging.getLogger(__name__)

business_twin_bp = Blueprint('business_twin', __name__)


def _get_active_company_id():
    """
    Robust tenant isolation helper: resolves active company id across direct session,
    superadmin impersonation, and authenticated user identity.
    """
    cid = session.get('impersonating_company_id') or session.get('company_id')
    if not cid and current_user.is_authenticated:
        cid = getattr(current_user, 'company_id', None)
    if not cid:
        comp = Company.query.first()
        if comp:
            cid = comp.id
    if cid:
        session['company_id'] = cid
    return cid


# =============================================================================
# CORE (BUILT-IN) BUSINESS TWINS — per-company customizable, not hard-coded
# =============================================================================
# These are the real, data-backed twins (Revenue, Expenses, Customers, ...).
# Each company can rename, re-colour, re-describe or hide/restore any of them;
# the customisation is stored per-company in AppConfig so no code change or
# global edit is ever needed. Del "/hide" only un-lists the card — the real
# data and its page are never deleted.
# =============================================================================

DEFAULT_TWIN_SPECS = [
    {'key': 'revenue', 'name': 'Revenue', 'icon': 'fa-coins', 'color': '#00D4FF',
     'endpoint': 'business_twin.revenue', 'unit': 'entries',
     'description': 'Every income line and revenue stream in one place.'},
    {'key': 'expenses', 'name': 'Expenses', 'icon': 'fa-receipt', 'color': '#F472B6',
     'endpoint': 'business_twin.expenses', 'unit': 'entries',
     'description': 'Track every outgoing payment and cost centre.'},
    {'key': 'customers', 'name': 'Customers', 'icon': 'fa-users', 'color': '#8B5CF6',
     'endpoint': 'business_twin.customers', 'unit': 'customers',
     'description': 'Your active customer base, value and segments.'},
    {'key': 'employees', 'name': 'Employees', 'icon': 'fa-user-tie', 'color': '#10B981',
     'endpoint': 'business_twin.employees', 'unit': 'people',
     'description': 'Your people — roles, salaries and headcount.'},
    {'key': 'suppliers', 'name': 'Suppliers', 'icon': 'fa-truck', 'color': '#F59E0B',
     'endpoint': 'business_twin.suppliers', 'unit': 'suppliers',
     'description': 'Vendors and supply relationships.'},
    {'key': 'inventory', 'name': 'Inventory', 'icon': 'fa-boxes', 'color': '#3B82F6',
     'endpoint': 'business_twin.inventory', 'unit': 'items',
     'description': 'Stock levels, quantities and reorder alerts.'},
    {'key': 'departments', 'name': 'Departments', 'icon': 'fa-building', 'color': '#EC4899',
     'endpoint': 'business_twin.departments', 'unit': 'departments',
     'description': 'Structure, budgets and heads by department.'},
    {'key': 'payments', 'name': 'Payments & Treasury', 'icon': 'fa-building-columns', 'color': '#0EA5E9',
     'endpoint': 'business_twin.payments', 'unit': 'rails',
     'description': 'Corporate bank accounts, UPI IDs, dynamic QR codes, and financial rails.'},
]

_TWINS_CONFIG_KEY = 'default_twins_config'


def _get_twins_config(company_id):
    """Read per-company core-twin customisation (JSON) from AppConfig."""
    raw = AppConfig.get(company_id, _TWINS_CONFIG_KEY, '{}') or '{}'
    try:
        return json.loads(raw) if raw else {}
    except Exception:
        return {}


def _save_twins_config(company_id, data):
    AppConfig.set(company_id, _TWINS_CONFIG_KEY, json.dumps(data), config_type='json')


def _core_twin_count(key, company_id):
    """Return the live record count that a core twin really holds today."""
    try:
        if key == 'revenue':
            return FinancialRecord.query.filter_by(company_id=company_id, transaction_type='revenue').count()
        if key == 'expenses':
            return FinancialRecord.query.filter_by(company_id=company_id, transaction_type='expense').count()
        if key == 'customers':
            return Customer.query.filter_by(company_id=company_id).count()
        if key == 'employees':
            return Employee.query.filter_by(company_id=company_id).count()
        if key == 'suppliers':
            return Supplier.query.filter_by(company_id=company_id).count()
        if key == 'inventory':
            return Inventory.query.filter_by(company_id=company_id, is_active=True).count()
        if key == 'departments':
            return Department.query.filter_by(company_id=company_id, is_active=True).count()
        if key == 'payments':
            return CompanyPayments.query.filter_by(company_id=company_id).count()
    except Exception:
        pass
    return 0


def _resolve_core_twins(company_id):
    """Build the displayed (visible) + hidden core twins for a company."""
    cfg = _get_twins_config(company_id)
    visible, hidden = [], []
    for spec in DEFAULT_TWIN_SPECS:
        ov = cfg.get(spec['key']) or {}
        merged = {
            'key': spec['key'],
            'name': (ov.get('name') or spec['name']).strip() or spec['name'],
            'icon': (ov.get('icon') or spec['icon']).strip() or spec['icon'],
            'color': (ov.get('color') or spec['color']).strip() or spec['color'],
            'description': (ov.get('description') or spec['description']).strip() or spec['description'],
            'endpoint': spec['endpoint'],
            'unit': spec.get('unit', 'records'),
            'count': _core_twin_count(spec['key'], company_id),
        }
        (hidden if ov.get('hidden') else visible).append(merged)
    return visible, hidden


def _get_core_twin(key):
    for spec in DEFAULT_TWIN_SPECS:
        if spec['key'] == key:
            return spec
    return None


# =============================================================================
# Per-record custom field storage for core twins (shadow table)
# =============================================================================
_FIELD_TYPES = ('text', 'number', 'integer', 'boolean', 'date', 'email', 'url', 'select')


def _coerce_extra_value(raw, ftype, default=None):
    """Coerce a submitted custom-field value into the field's declared type."""
    if ftype == 'number':
        try:
            return float(raw) if raw is not None and str(raw).strip() != '' else None
        except (TypeError, ValueError):
            return None
    if ftype == 'integer':
        try:
            return int(raw) if raw is not None and str(raw).strip() != '' else None
        except (TypeError, ValueError):
            return None
    if ftype == 'boolean':
        if raw is None:
            return bool(default)
        if isinstance(raw, bool):
            return raw
        return str(raw).lower() in ('1', 'true', 'yes', 'on')
    if ftype == 'date':
        if not raw:
            return None
        return str(raw)
    return (str(raw) if raw is not None else None)


def _get_core_extra(company_id, key, record_id):
    """Return the stored extra-field data dict for a core record (or {})."""
    row = CoreTwinExtraRecord.query.filter_by(
        company_id=company_id, twin_key=key, record_id=record_id).first()
    return row.get_data() if row else {}


def _get_core_extra_batch(company_id, key, record_ids):
    """Batch-fetch stored extra-field data dicts for multiple core records in a single query."""
    if not record_ids:
        return {}
    rows = CoreTwinExtraRecord.query.filter(
        CoreTwinExtraRecord.company_id == company_id,
        CoreTwinExtraRecord.twin_key == key,
        CoreTwinExtraRecord.record_id.in_(record_ids)
    ).all()
    return {row.record_id: row.get_data() for row in rows}


def _save_core_extra(company_id, key, record_id, data):
    """Upsert the extra-field data dict for a core record."""
    row = CoreTwinExtraRecord.query.filter_by(
        company_id=company_id, twin_key=key, record_id=record_id).first()
    if row is None:
        row = CoreTwinExtraRecord(
            company_id=company_id, twin_key=key, record_id=record_id)
        db.session.add(row)
    row.set_data(data or {})
    return row


def _delete_core_extra(company_id, key, record_id):
    CoreTwinExtraRecord.query.filter_by(
        company_id=company_id, twin_key=key, record_id=record_id).delete(
            synchronize_session=False)


def _collect_extra_fields(company_id, key):
    """Collect & type-coerce submitted extra_* custom field values for a twin."""
    cfg = _get_twins_config(company_id)
    entry = cfg.get(key) or {}
    fields = entry.get('fields') or []
    data = {}
    for f in fields:
        name = (f.get('name') or '').strip()
        if not name:
            continue
        raw = request.form.get(f'extra_{name}')
        data[name] = _coerce_extra_value(raw, f.get('type', 'text'), f.get('default'))
    return data


def _parse_core_fields_from_form(count_key='field_count'):
    """Parse custom-field definitions from the core-twin edit form."""
    try:
        count = int(request.form.get(count_key, 0))
    except (TypeError, ValueError):
        count = 0
    count = min(max(count, 0), 200)
    fields = []
    for i in range(count):
        name = (request.form.get(f'field_name_{i}') or '').strip()
        label = (request.form.get(f'field_label_{i}') or '').strip()
        if not name:
            continue
        ftype = (request.form.get(f'field_type_{i}') or 'text').strip()
        if ftype not in _FIELD_TYPES:
            ftype = 'text'
        default = request.form.get(f'field_default_{i}', '') or ''
        options = [o.strip() for o in
                   (request.form.get(f'field_options_{i}') or '').split(',') if o.strip()]
        field = {
            'name': name,
            'label': label or name,
            'type': ftype,
            'default': default,
        }
        if options and ftype == 'select':
            field['options'] = options
        if request.form.get(f'field_required_{i}') in ('on', 'true', '1'):
            field['required'] = True
        fields.append(field)
    return fields


def _parse_core_interconnection():
    """Parse enterprise-interconnection settings for a core twin from the form."""
    impact_level = (request.form.get('impact_level') or 'none').strip() or 'none'
    if impact_level not in ('none', 'low', 'medium', 'high', 'critical'):
        impact_level = 'none'
    propagate_to = [p for p in request.form.getlist('impact_propagate_to')
                    if p in ('revenue', 'expenses', 'employees', 'customers')]
    try:
        impact_weight = float(request.form.get('impact_weight') or 0.5)
    except (TypeError, ValueError):
        impact_weight = 0.5
    impact_weight = min(1.0, max(0.0, impact_weight))
    return {
        'impact': {
            'level': impact_level,
            'weight': impact_weight,
            'propagate_to': propagate_to,
            'field': (request.form.get('impact_field') or '').strip(),
        },
        'linked_entity_type': (request.form.get('linked_entity_type') or 'custom').strip() or 'custom',
        'linked_entity_id': request.form.get('linked_entity_id', type=int),
        'tags': [t.strip() for t in
                 (request.form.get('tags') or '').split(',') if t.strip()],
    }


def _get_currency_symbol(company_id):
    """Get the currency symbol for a company."""
    from config.constants import CURRENCY_SYMBOLS
    company = Company.query.get(company_id)
    currency = company.currency if company and company.currency else 'USD'
    return CURRENCY_SYMBOLS.get(currency, '$')


def _sync_dept_headcount(company_id, dept_id):
    """Sync Department.employee_count to actual active employees."""
    if not dept_id:
        return
    count = Employee.query.filter_by(
        company_id=company_id,
        department_id=dept_id,
        status='active'
    ).count()
    dept = Department.query.filter_by(id=dept_id, company_id=company_id).first()
    if dept:
        dept.employee_count = count
        db.session.commit()


def _mirror_employee_to_twin(company_id, employee, event, user_id=None):
    """ENTERPRISE INTERCONNECTION: mirror an employee change into the
    department's linked custom twin so the twin network stays real.

    Every employee create/update/delete is mirrored as a CustomTwinRecord
    in the department twin, then TwinService.propagate_record() fires the
    twin's automation rules (payroll expense record, company employee
    count) and recomputes authoritative company metrics + health score.
    """
    if not employee or not employee.department_id:
        return None
    try:
        from database.models.custom_twin import CustomTwin, CustomTwinRecord
        from services.twin_service import TwinService

        twin = CustomTwin.query.filter_by(
            company_id=company_id,
            linked_entity_type='department',
            linked_entity_id=employee.department_id
        ).first()
        if not twin:
            return None

        emp_key = employee.employee_id or f'EMP-{employee.id}'
        record = None
        for r in CustomTwinRecord.query.filter_by(
                twin_id=twin.id, company_id=company_id, is_active=True).all():
            d = r.get_data()
            if d.get('_employee_pk') == employee.id or d.get('employee_id') == emp_key:
                record = r
                break

        data = {
            '_employee_pk': employee.id,
            'employee_id': emp_key,
            'employee_name': f'{employee.first_name or ""} {employee.last_name or ""}'.strip(),
            'role': employee.job_title or '',
            'salary': float(employee.salary or 0),
            'status': employee.status or 'active',
            'start_date': employee.hire_date.isoformat() if employee.hire_date else ''
        }

        if event == 'on_delete':
            if record:
                # Reverse impacts BEFORE removing the mirrored record
                TwinService.propagate_record(twin, record, 'on_delete', user_id=user_id)
                # Explicitly reverse the payroll expense created by the
                # on_create automation rule (salary is not in the generic
                # amount-field list used by _apply_company_impact)
                try:
                    TwinService._remove_impact_financial_record(
                        company_id, twin.name, float(employee.salary or 0),
                        'expense', record.id)
                except (ValueError, TypeError):
                    pass
                db.session.delete(record)
            return None

        if event == 'on_create' and record:
            return record  # already mirrored

        if not record:
            record = CustomTwinRecord(
                twin_id=twin.id, company_id=company_id, created_by=user_id)
            record.set_data(data)
            db.session.add(record)
            db.session.flush()  # assign record.id before propagation
        else:
            record.set_data(data)

        TwinService.propagate_record(twin, record, event, user_id=user_id)
        # Keep the department's own headcount in sync with reality
        _sync_dept_headcount(company_id, employee.department_id)
        return record
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Employee twin mirror failed: {e}")
        return None


def _mirror_customer_to_twin(company_id, customer, event, user_id=None):
    """ENTERPRISE INTERCONNECTION: mirror a customer change into any
    customer-linked custom twin, so twin dashboards reflect real CRM data
    and company metrics stay authoritative."""
    if not customer:
        return None
    try:
        from database.models.custom_twin import CustomTwin, CustomTwinRecord
        from services.twin_service import TwinService

        twins = CustomTwin.query.filter_by(
            company_id=company_id,
            linked_entity_type='customer',
            linked_entity_id=customer.id
        ).all()
        if not twins:
            return None

        results = []
        for twin in twins:
            record = CustomTwinRecord.query.filter_by(
                twin_id=twin.id, company_id=company_id, is_active=True
            ).filter(
                CustomTwinRecord.data.like(f'%"_customer_pk": {customer.id}%')
            ).first()

            data = {
                '_customer_pk': customer.id,
                'customer_code': customer.customer_code or '',
                'customer_name': f'{customer.first_name or ""} {customer.last_name or ""}'.strip()
                                 or (customer.company_name or ''),
                'segment': customer.segment or 'General',
                'lifetime_value': float(customer.lifetime_value or 0),
                'total_spent': float(customer.total_spent or 0),
                'total_orders': int(customer.total_orders or 0),
                'status': customer.status or 'active'
            }

            if event == 'on_delete':
                if record:
                    TwinService.propagate_record(twin, record, 'on_delete', user_id=user_id)
                    db.session.delete(record)
                continue

            if not record:
                record = CustomTwinRecord(
                    twin_id=twin.id, company_id=company_id, created_by=user_id)
                record.set_data(data)
                db.session.add(record)
                db.session.flush()
            else:
                record.set_data(data)

            TwinService.propagate_record(twin, record, event, user_id=user_id)
            results.append(record)
        return results[0] if results else None
    except Exception as e:
        import logging
        logging.getLogger(__name__).error(f"Customer twin mirror failed: {e}")
        return None


@business_twin_bp.route('/')
@login_required
def overview():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    summary = AnalyticsService.get_executive_summary(company_id)

    employees = Employee.query.filter_by(company_id=company_id, status='active').count()
    customers = Customer.query.filter_by(company_id=company_id, status='active').count()
    suppliers = Supplier.query.filter_by(company_id=company_id, status='active').count()
    inventory_items = Inventory.query.filter_by(company_id=company_id, is_active=True).count()
    branches = Branch.query.filter_by(company_id=company_id, status='active').count()
    departments = Department.query.filter_by(company_id=company_id, is_active=True).all()
    # Honest observed database counts (no synthetic override of raw counts)
    # Get custom twins for the company
    custom_twins = CustomTwin.query.filter_by(company_id=company_id, is_active=True).order_by(CustomTwin.name).all()

    # Core (built-in) twins resolved with per-company customisation + live counts
    default_twins, hidden_twins = _resolve_core_twins(company_id)

    return render_template('business_twin/twin_overview.html',
                         company=company, summary=summary,
                         employees=employees, customers=customers,
                         suppliers=suppliers, inventory_items=inventory_items,
                         branches=branches, departments=departments,
                         custom_twins=custom_twins,
                         default_twins=default_twins, hidden_twins=hidden_twins)


@business_twin_bp.route('/core-twins/<key>/json')
@login_required
def core_twin_json(key):
    """Fresh core-twin data for the edit modal (fetched by key, no inline JSON)."""
    company_id = session.get('company_id')
    spec = _get_core_twin(key)
    if not spec:
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 404
    cfg = _get_twins_config(company_id)
    ov = cfg.get(key) or {}
    interconnection = ov.get('interconnection') or {}
    return jsonify({'success': True, 'twin': {
        'key': key,
        'name': ov.get('name') or spec['name'],
        'icon': ov.get('icon') or spec['icon'],
        'color': ov.get('color') or spec['color'],
        'description': ov.get('description') or spec['description'],
        'hidden': bool(ov.get('hidden')),
        'count': _core_twin_count(key, company_id),
        'unit': spec.get('unit', 'records'),
        'is_core': True,
        'fields': ov.get('fields') or [],
        'interconnection': interconnection,
        'tags': (interconnection.get('tags') or []) if isinstance(interconnection, dict) else [],
    }})


@business_twin_bp.route('/core-twins/edit', methods=['POST'])
@login_required
def core_twin_edit():
    """Customise a core twin for this company — rename / recolor / describe plus
    production-grade options: custom field definitions, tags and enterprise
    interconnection settings."""
    company_id = session.get('company_id')
    key = (request.form.get('key') or '').strip()
    if not _get_core_twin(key):
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 400
    cfg = _get_twins_config(company_id)
    entry = cfg.get(key) or {}
    entry['name'] = (request.form.get('name') or '').strip()
    entry['icon'] = (request.form.get('icon') or '').strip()
    entry['color'] = (request.form.get('color') or '').strip()
    entry['description'] = (request.form.get('description') or '').strip()

    # Custom field definitions + interconnection (only when submitted)
    if request.form.get('field_count') is not None:
        entry['fields'] = _parse_core_fields_from_form()
    if request.form.get('impact_level') is not None:
        inter = _parse_core_interconnection()
        entry['interconnection'] = inter

    entry.pop('hidden', None)  # editing re-shows it if it was hidden
    cfg[key] = entry
    _save_twins_config(company_id, cfg)
    return jsonify({'success': True, 'message': f'"{entry["name"] or key}" twin updated',
                    'twin': {'key': key, **entry}})


# --- Generic per-record custom-field value endpoints (used by all core twins) ---
@business_twin_bp.route('/core-twins/<key>/record/<int:record_id>/extra')
@login_required
def core_twin_record_extra_get(key, record_id):
    """Fresh custom-field values for one core record."""
    company_id = session.get('company_id')
    if not _get_core_twin(key):
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 404
    return jsonify({'success': True, 'key': key, 'record_id': record_id,
                    'data': _get_core_extra(company_id, key, record_id)})


@business_twin_bp.route('/core-twins/<key>/record/<int:record_id>/extra', methods=['POST'])
@login_required
def core_twin_record_extra_set(key, record_id):
    """Persist custom-field values for one core record (JSON body or form)."""
    company_id = session.get('company_id')
    if not _get_core_twin(key):
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 404
    try:
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict):
            payload = {}
        _save_core_extra(company_id, key, record_id,
                         {k: v for k, v in payload.items()
                          if k not in ('csrf_token', 'key', 'record_id')})
        db.session.commit()
        return jsonify({'success': True, 'data': _get_core_extra(company_id, key, record_id)})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/core-twins/<key>/record/<int:record_id>/extra', methods=['DELETE'])
@login_required
def core_twin_record_extra_clear(key, record_id):
    """Clear custom-field values for one core record."""
    company_id = session.get('company_id')
    if not _get_core_twin(key):
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 404
    _delete_core_extra(company_id, key, record_id)
    db.session.commit()
    return jsonify({'success': True, 'message': 'Custom fields cleared'})


@business_twin_bp.route('/core-twins/<key>/delete', methods=['POST'])
@login_required
def core_twin_delete(key):
    """Hide a core twin card for this company (its real data is never deleted)."""
    if not _get_core_twin(key):
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 400
    cfg = _get_twins_config(session.get('company_id'))
    entry = cfg.get(key) or {}
    entry['hidden'] = True
    cfg[key] = entry
    _save_twins_config(session.get('company_id'), cfg)
    return jsonify({'success': True, 'message': 'Twin hidden'})


@business_twin_bp.route('/core-twins/<key>/restore', methods=['POST'])
@login_required
def core_twin_restore(key):
    """Bring a hidden core twin card back."""
    if not _get_core_twin(key):
        return jsonify({'success': False, 'error': 'Unknown core twin'}), 400
    cfg = _get_twins_config(session.get('company_id'))
    entry = cfg.get(key) or {}
    entry['hidden'] = False
    cfg[key] = entry
    _save_twins_config(session.get('company_id'), cfg)
    return jsonify({'success': True, 'message': 'Twin restored'})


@business_twin_bp.route('/departments')
@login_required
def departments():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    
    depts = Department.query.filter_by(company_id=company_id, is_active=True).all()
    
    # LIVE budget/spend aggregates (projects + expense records) — computed
    # fresh on every request, never read from the stored snapshot columns.
    live_totals = AnalyticsService._department_live_totals(company_id)
    
    dept_data = []
    total_headcount = 0
    total_payroll = 0
    total_budget = 0
    total_spent = 0
    
    for dept in depts:
        # Real-time employee aggregation
        emp_stats = db.session.query(
            func.count(Employee.id).label('headcount'),
            func.sum(Employee.salary).label('total_salary'),
            func.sum(Employee.benefits_cost).label('total_benefits'),
            func.avg(Employee.salary).label('avg_salary')
        ).filter(
            Employee.company_id == company_id,
            Employee.department_id == dept.id,
            Employee.status == 'active'
        ).first()
        
        headcount = emp_stats.headcount or 0
        dept_salary = float(emp_stats.total_salary or 0)
        dept_benefits = float(emp_stats.total_benefits or 0)
        dept_payroll = dept_salary + dept_benefits
        avg_salary = float(emp_stats.avg_salary or 0)
        
        # Keep stored count in sync
        if dept.employee_count != headcount:
            dept.employee_count = headcount
            db.session.commit()
        
        live = live_totals.get(dept.id, {'budget': float(dept.budget or 0), 'spent': 0.0})
        live_budget = live['budget']
        live_spent = live['spent']
        
        utilization = round((live_spent / live_budget * 100), 1) if live_budget > 0 else 0
        
        # Employment type breakdown
        type_rows = db.session.query(
            Employee.employment_type,
            func.count(Employee.id).label('count')
        ).filter(
            Employee.company_id == company_id,
            Employee.department_id == dept.id,
            Employee.status == 'active'
        ).group_by(Employee.employment_type).all()
        type_breakdown = {t: c for t, c in type_rows}
        
        # Top skills
        skills_list = []
        for emp in Employee.query.filter_by(company_id=company_id, department_id=dept.id, status='active').all():
            if emp.skills:
                skills_list.extend([s.strip() for s in emp.skills.split(',') if s.strip()])
        top_skills = [s[0] for s in Counter(skills_list).most_common(3)]
        
        dept_data.append({
            'id': dept.id,
            'name': dept.name,
            'code': dept.code,
            'color': dept.color or '#00D4FF',
            'head_name': dept.head_name,
            'headcount': headcount,
            'total_salary': dept_salary,
            'total_benefits': dept_benefits,
            'total_payroll': dept_payroll,
            'avg_salary': avg_salary,
            'budget': live_budget,
            'spent': live_spent,
            'remaining': max(0, live_budget - live_spent),
            'utilization': utilization,
            'type_breakdown': type_breakdown,
            'top_skills': top_skills,
            'is_active': dept.is_active
        })
        
        total_headcount += headcount
        total_payroll += dept_payroll
        total_budget += live_budget
        total_spent += live_spent
    
    company_avg_salary = db.session.query(func.avg(Employee.salary)).filter(
        Employee.company_id == company_id,
        Employee.status == 'active'
    ).scalar() or 0
    
    dept_data.sort(key=lambda x: x['headcount'], reverse=True)
    
    return render_template('business_twin/twin_departments.html',
                         company=company,
                         currency_symbol=_get_currency_symbol(company_id),
                         departments=dept_data,
                         total_headcount=total_headcount,
                         total_payroll=total_payroll,
                         total_budget=total_budget,
                         total_spent=total_spent,
                         avg_salary=float(company_avg_salary),
                         dept_count=len(depts))


@business_twin_bp.route('/departments/add', methods=['POST'])
@login_required
def add_department():
    company_id = session.get('company_id')
    try:
        name = request.form.get('name', '').strip()
        if not name:
            return jsonify({'success': False, 'error': 'Department name is required'}), 400
        
        code = request.form.get('code', name[:3].upper()).strip()
        dept = Department(
            company_id=company_id,
            name=name,
            code=code,
            description=request.form.get('description', '').strip(),
            head_name=request.form.get('head_name', '').strip(),
            budget=float(request.form.get('budget', 0) or 0),
            color=request.form.get('color', '#2563EB') or '#2563EB',
            is_active=True
        )
        db.session.add(dept)
        db.session.commit()
        
        # ============================================================
        # ENTERPRISE INTERCONNECTION: Auto-create a linked custom twin
        # for the new department so it's fully integrated into the
        # business twin network
        # ============================================================
        try:
            from database.models.custom_twin import CustomTwin
            import re as _re
            
            # Check if a twin already exists for this department
            existing_twin = CustomTwin.query.filter_by(
                company_id=company_id,
                linked_entity_type='department',
                linked_entity_id=dept.id
            ).first()
            
            if not existing_twin:
                slug = _re.sub(r'[^\w\s-]', '', name.lower())
                slug = _re.sub(r'[-\s]+', '-', slug)
                
                # Ensure unique slug
                base_slug = slug
                counter = 1
                while CustomTwin.query.filter_by(company_id=company_id, slug=slug).first():
                    slug = f"{base_slug}-{counter}"
                    counter += 1
                
                twin = CustomTwin(
                    company_id=company_id,
                    name=f"{name} Department",
                    slug=slug,
                    description=f"Automatically created twin for the {name} department. Tracks department operations, budget, and performance.",
                    icon='fa-building',
                    color=dept.color or '#00D4FF',
                    linked_entity_type='department',
                    linked_entity_id=dept.id,
                    auto_sync=True,
                    created_by=current_user.id if hasattr(current_user, 'id') else None
                )
                
                # Default field definitions for department twin
                twin.set_field_definitions([
                    {'name': 'employee_id', 'label': 'Employee ID', 'type': 'text', 'required': True, 'default': ''},
                    {'name': 'employee_name', 'label': 'Employee Name', 'type': 'text', 'required': True, 'default': ''},
                    {'name': 'role', 'label': 'Role', 'type': 'text', 'required': False, 'default': ''},
                    {'name': 'salary', 'label': 'Salary', 'type': 'number', 'required': False, 'default': 0},
                    {'name': 'status', 'label': 'Status', 'type': 'text', 'required': False, 'default': 'active'},
                    {'name': 'start_date', 'label': 'Start Date', 'type': 'date', 'required': False, 'default': ''}
                ])
                
                # Default stats
                twin.set_stats_config([
                    {'name': 'total_employees', 'label': 'Total Employees', 'type': 'count', 'field': '', 'color': dept.color or '#00D4FF'},
                    {'name': 'total_payroll', 'label': 'Total Payroll', 'type': 'sum', 'field': 'salary', 'color': '#10B981'},
                    {'name': 'avg_salary', 'label': 'Avg Salary', 'type': 'avg', 'field': 'salary', 'color': '#8B5CF6'}
                ])
                
                twin.set_table_columns(['employee_id', 'employee_name', 'role', 'salary', 'status'])
                
                # Default automation rules - department twin affects company
                twin.set_automation_rules([
                    {
                        'name': 'Update Employee Count',
                        'event': 'on_create',
                        'action': 'update_employee_count',
                        'target': 'employee_count',
                        'value': '1'
                    },
                    {
                        'name': 'Update Payroll Expense',
                        'event': 'on_create',
                        'action': 'update_expense',
                        'target': 'Payroll',
                        'value': 'salary'
                    }
                ])
                
                # Impact config - department twin has medium impact on company
                twin.set_impact_config({
                    'level': 'medium',
                    'weight': 0.5,
                    'propagate_to': ['employees', 'expenses']
                })
                
                db.session.add(twin)
                db.session.commit()
        except Exception as twin_error:
            db.session.rollback()
            # Don't fail the department creation if twin creation fails
            pass
        
        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.DEPARTMENT_CREATED,
                company_id=company_id,
                aggregate_type='department',
                aggregate_id=str(dept.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': dept.name, 'code': dept.code, 'budget': dept.budget}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({'success': True, 'department': dept.to_dict()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/departments/edit/<int:dept_id>', methods=['POST'])
@login_required
def edit_department(dept_id):
    company_id = session.get('company_id')
    dept = Department.query.filter_by(id=dept_id, company_id=company_id).first()
    if not dept:
        return jsonify({'success': False, 'error': 'Department not found'}), 404

    try:
        data = request.get_json(silent=True) if request.is_json else request.form
        if not data:
            data = request.form

        name = data.get('name')
        if name is not None and str(name).strip():
            dept.name = str(name).strip()

        code = data.get('code')
        if code is not None:
            dept.code = str(code).strip()

        description = data.get('description')
        if description is not None:
            dept.description = str(description).strip()

        head_name = data.get('head_name')
        if head_name is not None:
            dept.head_name = str(head_name).strip()

        budget = data.get('budget')
        if budget is not None and str(budget).strip() != '':
            dept.budget = float(budget)

        color = data.get('color')
        if color is not None and str(color).strip():
            dept.color = str(color).strip()

        is_active = data.get('is_active')
        if is_active is not None:
            if isinstance(is_active, bool):
                dept.is_active = is_active
            else:
                dept.is_active = str(is_active).lower() in ('true', '1', 'yes')

        db.session.commit()

        try:
            from services.enterprise_service import EnterpriseService
            from database.models.notification import Notification
            EnterpriseService.calculate_all_metrics(company_id)
            notif = Notification(
                company_id=company_id,
                user_id=current_user.id if hasattr(current_user, 'id') else None,
                title=f"Department Updated: {dept.name}",
                message=f"Allocated budget for {dept.name} ({dept.code}) synchronized at {dept.budget:,.2f}.",
                notification_type='info',
                is_read=False
            )
            db.session.add(notif)
            db.session.commit()
        except Exception:
            db.session.rollback()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.DEPARTMENT_UPDATED,
                company_id=company_id,
                aggregate_type='department',
                aggregate_id=str(dept.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': dept.name, 'code': dept.code, 'budget': dept.budget}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({'success': True, 'department': dept.to_dict()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/departments/delete-all', methods=['DELETE'])
@login_required
def delete_all_departments():
    company_id = session.get('company_id')
    try:
        depts = Department.query.filter_by(company_id=company_id).all()
        count = len(depts)
        if count == 0:
            return jsonify({'success': True, 'message': 'No departments to delete'})

        # Detach referencing tables safely before deleting departments
        Employee.query.filter_by(company_id=company_id).filter(
            Employee.department_id.isnot(None)
        ).update({'department_id': None}, synchronize_session=False)

        FinancialRecord.query.filter_by(company_id=company_id).filter(
            FinancialRecord.department_id.isnot(None)
        ).update({'department_id': None}, synchronize_session=False)

        Project.query.filter_by(company_id=company_id).filter(
            Project.department_id.isnot(None)
        ).update({'department_id': None}, synchronize_session=False)

        # Delete custom twins linked to these departments
        dept_ids = [d.id for d in depts]
        CustomTwin.query.filter_by(company_id=company_id, linked_entity_type='department').filter(
            CustomTwin.linked_entity_id.in_(dept_ids)
        ).delete(synchronize_session=False)

        CoreTwinExtraRecord.query.filter_by(company_id=company_id, twin_key='departments').delete(synchronize_session=False)

        Department.query.filter_by(company_id=company_id).delete(synchronize_session=False)
        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.DEPARTMENT_ALL_DELETED,
                company_id=company_id,
                aggregate_type='department',
                aggregate_id=None,
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'deleted_count': count}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({'success': True, 'message': f'All {count} departments deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/departments/export-excel')
@login_required
def export_departments_excel():
    company_id = session.get('company_id')
    depts = Department.query.filter_by(company_id=company_id).order_by(Department.name).all()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Departments"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'Name', 'Code', 'Head of Department', 'Budget', 'Spent', 'Employee Count', 'Status']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    for row_num, dept in enumerate(depts, 2):
        ws.cell(row=row_num, column=1, value=dept.id)
        ws.cell(row=row_num, column=2, value=dept.name)
        ws.cell(row=row_num, column=3, value=dept.code or '')
        ws.cell(row=row_num, column=4, value=dept.head_name or '')
        ws.cell(row=row_num, column=5, value=dept.budget or 0.0)
        ws.cell(row=row_num, column=6, value=dept.spent or 0.0)
        ws.cell(row=row_num, column=7, value=dept.employee_count or 0)
        ws.cell(row=row_num, column=8, value='Active' if dept.is_active else 'Inactive')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='departments_export.xlsx')


@business_twin_bp.route('/departments/export-csv')
@login_required
def export_departments_csv():
    company_id = session.get('company_id')
    depts = Department.query.filter_by(company_id=company_id).order_by(Department.name).all()

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Name', 'Code', 'Head of Department', 'Budget', 'Spent', 'Employee Count', 'Status'])

    for dept in depts:
        writer.writerow([
            dept.id,
            dept.name,
            dept.code or '',
            dept.head_name or '',
            dept.budget or 0.0,
            dept.spent or 0.0,
            dept.employee_count or 0,
            'Active' if dept.is_active else 'Inactive'
        ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode('utf-8')), mimetype='text/csv',
                     as_attachment=True, download_name='departments_export.csv')


@business_twin_bp.route('/departments/download-template')
@login_required
def download_department_csv_template():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['name', 'code', 'description', 'head_name', 'budget', 'color'])
    writer.writerow(['Engineering', 'ENG', 'Product software engineering', 'Alice Smith', '250000', '#2563EB'])
    writer.writerow(['Sales', 'SLS', 'Commercial sales and accounts', 'Bob Jones', '180000', '#10B981'])
    writer.writerow(['Marketing', 'MKT', 'Brand awareness and growth', 'Charlie Brown', '90000', '#F59E0B'])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode('utf-8')), mimetype='text/csv',
                     as_attachment=True, download_name='department_import_template.csv')


@business_twin_bp.route('/departments/download-excel-template')
@login_required
def download_department_excel_template():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Departments"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['name', 'code', 'description', 'head_name', 'budget', 'color']
    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    sample_data = [
        ['Engineering', 'ENG', 'Product software engineering', 'Alice Smith', 250000, '#2563EB'],
        ['Sales', 'SLS', 'Commercial sales and accounts', 'Bob Jones', 180000, '#10B981'],
        ['Marketing', 'MKT', 'Brand awareness and growth', 'Charlie Brown', 90000, '#F59E0B']
    ]
    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, val in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=val)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='department_import_template.xlsx')


@business_twin_bp.route('/departments/import-csv', methods=['POST'])
@login_required
def import_departments_csv():
    company_id = session.get('company_id')
    file = request.files.get('csv_file') or request.files.get('file')
    if not file or file.filename == '':
        return jsonify({'success': False, 'error': 'No file uploaded or selected'}), 400

    if not file.filename.lower().endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV'}), 400

    try:
        stream = io.StringIO(file.stream.read().decode('utf-8', errors='replace'), newline=None)
        csv_reader = csv.DictReader(stream)
        added_count = 0
        updated_count = 0
        errors = []

        for row_num, row in enumerate(csv_reader, start=2):
            try:
                name = (row.get('name') or '').strip()
                if not name:
                    errors.append(f"Row {row_num}: Department name is required")
                    continue

                code = (row.get('code') or name[:3].upper()).strip()
                budget_val = 0.0
                try:
                    raw_b = (row.get('budget') or '').replace('$', '').replace(',', '').strip()
                    if raw_b:
                        budget_val = float(raw_b)
                except ValueError:
                    budget_val = 0.0

                dept = Department.query.filter_by(company_id=company_id, name=name).first()
                if dept:
                    dept.code = code or dept.code
                    dept.description = (row.get('description') or dept.description or '').strip()
                    dept.head_name = (row.get('head_name') or dept.head_name or '').strip()
                    dept.budget = budget_val
                    dept.color = (row.get('color') or dept.color or '#2563EB').strip()
                    updated_count += 1
                else:
                    dept = Department(
                        company_id=company_id,
                        name=name,
                        code=code,
                        description=(row.get('description') or '').strip(),
                        head_name=(row.get('head_name') or '').strip(),
                        budget=budget_val,
                        color=(row.get('color') or '#2563EB').strip(),
                        is_active=True
                    )
                    db.session.add(dept)
                    added_count += 1
            except Exception as row_err:
                errors.append(f"Row {row_num}: {str(row_err)}")

        db.session.commit()
        return jsonify({
            'success': True,
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f"Imported {added_count} departments, updated {updated_count}"
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# CORPORATE TREASURY & PAYMENTS TWIN
# =============================================================================

@business_twin_bp.route('/payments')
@login_required
def payments():
    company_id = session.get('company_id')
    if not company_id:
        return redirect('/login')

    company = Company.query.get(company_id)
    if not company:
        flash('Company record not found.', 'danger')
        return redirect(url_for('dashboard.index'))

    from config.constants import CURRENCY_SYMBOLS
    currency_symbol = CURRENCY_SYMBOLS.get(company.currency, '$')

    payments = CompanyPayments.query.filter_by(company_id=company_id).first()
    if not payments:
        payments = CompanyPayments(
            company_id=company_id,
            account_holder_name=company.company_name,
            upi_display_name=company.company_name,
            upi_verification_status='Not Configured',
            data_confidence='User-provided'
        )
        db.session.add(payments)
        db.session.commit()

    # If UPI ID exists but QR has not been generated, generate it now
    if payments.upi_id and not payments.qr_code_path:
        try:
            from flask import current_app
            payments.generate_and_save_qr(root_dir=current_app.root_path)
            db.session.commit()
        except Exception as e:
            logger.warning(f"Auto QR generation on view: {e}")

    # Gather Department Budget authority data
    depts = Department.query.filter_by(company_id=company_id, is_active=True).all()
    budgets = DepartmentBudget.query.filter_by(company_id=company_id, status='active').all()
    budget_map = {b.department_id: b for b in budgets}

    departments_budget_data = []
    for d in depts:
        b = budget_map.get(d.id)
        alloc = float(b.allocated_amount or d.budget or 0.0)
        spent = float(b.actual_spent or d.spent or 0.0)
        rem = max(0.0, alloc - spent)
        util = round((spent / alloc * 100), 1) if alloc > 0 else 0.0
        departments_budget_data.append({
            'id': d.id,
            'name': d.name,
            'code': d.code or d.name[:3].upper(),
            'head_name': d.head_name or 'Unassigned',
            'head_email': d.head_email or '',
            'allocated_amount': alloc,
            'actual_spent': spent,
            'remaining_budget': rem,
            'utilization': util
        })

    # High precision financial profile
    summary = AnalyticsService.get_executive_summary(company_id)
    ann_rev = float(company.annual_revenue or 0.0)
    rev_30d = float(summary.get('revenue_30d', 0.0) or 0.0)
    exp_30d = float(summary.get('expense_30d', 0.0) or 0.0)
    cash_bal = float(summary.get('cash_balance', 0.0) or 0.0)
    gross_profit = float(summary.get('gross_profit', ann_rev * 0.4) or 0.0)
    net_margin = float(summary.get('margin', 0.0) or 0.0)

    # Calculate actual receivables and payables if records exist
    receivables = db.session.query(
        func.coalesce(func.sum(FinancialRecord.amount), 0.0)
    ).filter(
        FinancialRecord.company_id == company_id,
        FinancialRecord.transaction_type == 'revenue',
        FinancialRecord.category.ilike('%receivable%')
    ).scalar() or (ann_rev * 0.08)

    financial_profile = {
        'annual_revenue': ann_rev,
        'monthly_revenue': rev_30d,
        'operating_expenses': exp_30d,
        'gross_profit': gross_profit,
        'net_margin': net_margin,
        'cash_balance': cash_bal,
        'receivables': float(receivables),
        'runway_months': summary.get('runway_months'),
        'data_confidence': payments.data_confidence or 'User-provided'
    }

    return render_template(
        'business_twin/twin_payments.html',
        company=company,
        payments=payments,
        currency_symbol=currency_symbol,
        departments_budget_data=departments_budget_data,
        financial_profile=financial_profile
    )


@business_twin_bp.route('/payments/update', methods=['POST'])
@login_required
def update_payment_rail():
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'success': False, 'error': 'Session expired'}), 401

    try:
        from services.company_service import CompanyService
        src = request.get_json(silent=True) or request.form.to_dict()
        payments = CompanyService.save_payments(company_id, src)
        return jsonify({
            'success': True,
            'message': 'Payment rail and treasury settings updated successfully.',
            'payments': payments.to_dict()
        })
    except Exception as e:
        logger.error(f"Error updating payment rail: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/payments/regenerate-qr', methods=['POST'])
@login_required
def regenerate_payment_qr():
    company_id = session.get('company_id')
    if not company_id:
        return jsonify({'success': False, 'error': 'Session expired'}), 401

    payments = CompanyPayments.query.filter_by(company_id=company_id).first()
    if not payments or not payments.upi_id:
        return jsonify({'success': False, 'error': 'No UPI ID configured to generate QR.'}), 400

    try:
        from flask import current_app
        rel_path = payments.generate_and_save_qr(root_dir=current_app.root_path)
        db.session.commit()
        return jsonify({
            'success': True,
            'qr_code_path': rel_path,
            'message': 'QR Code regenerated successfully.'
        })
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# =============================================================================
# REVENUE TWIN — ENHANCED ROUTES
# =============================================================================

@business_twin_bp.route('/revenue')
@login_required
def revenue():
    company_id = _get_active_company_id()
    if not company_id:
        return redirect('/login')

    # Guarantee real enterprise accounts are provisioned and synchronized
    CompanyService.ensure_company_financial_accounts(company_id)

    # Filtering & period criteria
    period = request.args.get('period', '30d')
    date_from = request.args.get('date_from') or request.args.get('start_date')
    date_to = request.args.get('date_to') or request.args.get('end_date')

    filter_dict = {
        'period': period,
        'date_from': date_from,
        'date_to': date_to,
        'category': request.args.get('category'),
        'subcategory': request.args.get('subcategory'),
        'department_id': request.args.get('department_id'),
        'account_id': request.args.get('account_id'),
        'min_amount': request.args.get('min_amount'),
        'max_amount': request.args.get('max_amount'),
        'is_recurring': request.args.get('is_recurring'),
        'q': request.args.get('q') or request.args.get('search'),
        'order_by': request.args.get('order_by', 'transaction_date'),
        'order_dir': request.args.get('order_dir', 'desc'),
    }

    # Fetch records matching criteria (or all if unbounded)
    records = UniversalFilterService.filter_financial_records(
        company_id=company_id,
        transaction_type='revenue',
        filters=filter_dict
    )

    metrics = UniversalFilterService.get_financial_summary_metrics(
        company_id=company_id,
        transaction_type='revenue',
        period=period,
        start_date=date_from,
        end_date=date_to
    )

    summary = AnalyticsService.get_executive_summary(company_id)
    # Enhance executive summary with period-bounded metrics
    summary['revenue_30d'] = metrics['period_revenue']
    summary['profit_30d'] = metrics['period_profit']
    summary['margin'] = metrics['period_margin']
    summary['revenue_period_formatted'] = metrics['period_revenue_formatted']
    summary['profit_period_formatted'] = metrics['period_profit_formatted']
    summary['margin_period_formatted'] = metrics['period_margin_formatted']
    summary['all_time_revenue_formatted'] = metrics['all_time_revenue_formatted']
    summary['all_time_revenue'] = metrics['all_time_revenue']
    summary['all_time_revenue_count'] = metrics['all_time_revenue_count']
    summary['period_revenue_count'] = metrics['period_revenue_count']

    trend = AnalyticsService.get_trend_data(company_id, 180)
    departments = Department.query.filter_by(company_id=company_id, is_active=True).all()
    accounts = FinancialAccount.query.filter_by(company_id=company_id, is_active=True).all()

    # Custom field definitions configured for this twin (per-company)
    core_cfg = _get_twins_config(company_id)
    core_entry = core_cfg.get('revenue') or {}
    core_fields = core_entry.get('fields') or []

    extra_map = _get_core_extra_batch(company_id, 'revenue', [r.id for r in records])
    records_data = []
    for r in records:
        rd = r.to_dict()
        rd['extra'] = extra_map.get(r.id, {})
        records_data.append(rd)

    # Categories list for filter toolbar
    all_categories = sorted(list({r.category for r in FinancialRecord.query.filter_by(company_id=company_id, transaction_type='revenue').all() if r.category}))

    return render_template('business_twin/twin_revenue.html',
                         summary=summary, trend=trend,
                         records=records_data,
                         metrics=metrics,
                         departments=departments,
                         accounts=accounts,
                         categories=all_categories,
                         core_fields=core_fields,
                         current_period=period,
                         current_filters=filter_dict,
                         currency_symbol=_get_currency_symbol(company_id))


@business_twin_bp.route('/revenue/summary')
@login_required
def revenue_summary():
    """Real-time AJAX endpoint for period switching in Revenue Twin."""
    company_id = _get_active_company_id()
    period = request.args.get('period', '30d')
    date_from = request.args.get('date_from') or request.args.get('start_date')
    date_to = request.args.get('date_to') or request.args.get('end_date')

    metrics = UniversalFilterService.get_financial_summary_metrics(
        company_id=company_id,
        transaction_type='revenue',
        period=period,
        start_date=date_from,
        end_date=date_to
    )
    return jsonify({'success': True, 'metrics': metrics})


def _get_revenue_summary(company_id, period='30d'):
    """Compute real-time updated summary KPIs for revenue mutations."""
    try:
        metrics = UniversalFilterService.get_financial_summary_metrics(
            company_id=company_id,
            transaction_type='revenue',
            period=period
        )
        return {
            'revenue_30d': metrics.get('period_revenue', 0.0),
            'revenue_30d_formatted': metrics.get('period_revenue_formatted', '$0.00'),
            'profit_30d': metrics.get('period_profit', 0.0),
            'profit_30d_formatted': metrics.get('period_profit_formatted', '$0.00'),
            'margin': metrics.get('period_margin', 0.0),
            'margin_formatted': metrics.get('period_margin_formatted', '0.0%'),
            'all_time_revenue': metrics.get('all_time_revenue', 0.0),
            'all_time_revenue_formatted': metrics.get('all_time_revenue_formatted', '$0.00'),
            'all_time_profit': metrics.get('all_time_profit', 0.0),
            'all_time_profit_formatted': metrics.get('all_time_profit_formatted', '$0.00'),
            'all_time_margin': metrics.get('all_time_margin', 0.0),
        }
    except Exception:
        return {}


@business_twin_bp.route('/revenue/add', methods=['POST'])
@login_required
def add_revenue():
    company_id = session.get('company_id')
    try:
        amount = float(request.form.get('amount', 0))
        if amount <= 0:
            return jsonify({'success': False, 'error': 'Amount must be greater than 0'}), 400
        
        tx_date_str = request.form.get('transaction_date')
        if tx_date_str:
            tx_date = datetime.strptime(tx_date_str, '%Y-%m-%d').date()
        else:
            tx_date = date.today()
        
        dept_id = request.form.get('department_id')
        account_id = request.form.get('account_id')
        
        record = FinancialRecord(
            company_id=company_id,
            account_id=int(account_id) if account_id and account_id.strip() else None,
            transaction_date=tx_date,
            transaction_type='revenue',
            category=request.form.get('category', 'Revenue'),
            subcategory=request.form.get('subcategory', ''),
            amount=amount,
            description=request.form.get('description', ''),
            reference_number=request.form.get('reference_number', ''),
            department_id=int(dept_id) if dept_id and dept_id.strip() else None,
            is_recurring=request.form.get('is_recurring') == 'on',
            recurring_frequency=request.form.get('recurring_frequency', ''),
            created_by=current_user.id if hasattr(current_user, 'id') else None
        )
        db.session.add(record)
        db.session.commit()

        # Persist any custom-field values configured for this twin
        extra = _collect_extra_fields(company_id, 'revenue')
        if extra:
            _save_core_extra(company_id, 'revenue', record.id, extra)
            db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
                company_id=company_id,
                aggregate_type='financial_record',
                aggregate_id=str(record.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'transaction_type': 'revenue',
                    'amount': record.amount,
                    'category': record.category,
                    'description': record.description
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        symbol = _get_currency_symbol(company_id)
        return jsonify({
            'success': True,
            'message': f'Revenue of {symbol}{amount:,.2f} added successfully',
            'record': record.to_dict(),
            'summary': _get_revenue_summary(company_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/revenue/edit/<int:record_id>', methods=['POST', 'PUT'])
@login_required
def edit_revenue(record_id):
    company_id = session.get('company_id')
    record = FinancialRecord.query.filter_by(
        id=record_id, company_id=company_id, transaction_type='revenue'
    ).first()
    if not record:
        return jsonify({'success': False, 'error': 'Revenue record not found'}), 404
    
    try:
        amount = request.form.get('amount')
        if amount is not None and amount.strip():
            record.amount = float(amount)
        
        tx_date_str = request.form.get('transaction_date')
        if tx_date_str and tx_date_str.strip():
            record.transaction_date = datetime.strptime(tx_date_str, '%Y-%m-%d').date()
        
        record.category = request.form.get('category', record.category or 'Revenue')
        record.subcategory = request.form.get('subcategory', record.subcategory or '')
        record.description = request.form.get('description', record.description or '')
        record.reference_number = request.form.get('reference_number', record.reference_number or '')
        
        dept_id = request.form.get('department_id')
        if dept_id is not None:
            record.department_id = int(dept_id) if dept_id.strip() else None
        
        account_id = request.form.get('account_id')
        if account_id is not None:
            record.account_id = int(account_id) if account_id.strip() else None
        
        record.is_recurring = request.form.get('is_recurring') == 'on'
        record.recurring_frequency = request.form.get('recurring_frequency', record.recurring_frequency or '')
        
        db.session.commit()

        # Persist any custom-field values configured for this twin
        extra = _collect_extra_fields(company_id, 'revenue')
        if extra:
            _save_core_extra(company_id, 'revenue', record.id, extra)
            db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_UPDATED,
                company_id=company_id,
                aggregate_type='financial_record',
                aggregate_id=str(record.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'transaction_type': 'revenue',
                    'amount': record.amount,
                    'category': record.category,
                    'description': record.description
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({
            'success': True,
            'record': record.to_dict(),
            'summary': _get_revenue_summary(company_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/revenue/delete/<int:record_id>', methods=['DELETE', 'POST'])
@login_required
def delete_revenue(record_id):
    company_id = session.get('company_id')
    record = FinancialRecord.query.filter_by(
        id=record_id, company_id=company_id, transaction_type='revenue'
    ).first()
    if not record:
        return jsonify({'success': False, 'error': 'Revenue record not found'}), 404
    
    try:
        desc = record.description
        amt = record.amount
        db.session.delete(record)
        db.session.commit()
        _delete_core_extra(company_id, 'revenue', record_id)
        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_DELETED,
                company_id=company_id,
                aggregate_type='financial_record',
                aggregate_id=str(record_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'transaction_type': 'revenue', 'amount': amt, 'description': desc}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({
            'success': True,
            'message': 'Revenue record deleted successfully',
            'summary': _get_revenue_summary(company_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/revenue/delete-all', methods=['DELETE'])
@login_required
def delete_all_revenue():
    company_id = session.get('company_id')
    try:
        count = FinancialRecord.query.filter_by(
            company_id=company_id, transaction_type='revenue'
        ).count()
        FinancialRecord.query.filter_by(
            company_id=company_id, transaction_type='revenue'
        ).delete()
        db.session.commit()
        CoreTwinExtraRecord.query.filter_by(
            company_id=company_id, twin_key='revenue').delete(synchronize_session=False)
        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'All {count} revenue records deleted successfully',
            'summary': _get_revenue_summary(company_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500



@business_twin_bp.route('/revenue/import-csv', methods=['POST'])
@login_required
def import_revenue_csv():
    company_id = _get_active_company_id()
    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['csv_file']
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not file.filename.lower().endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV (.csv)'}), 400

    try:
        content = file.stream.read().decode('utf-8', errors='replace')
        stream = io.StringIO(content, newline=None)
        reader = csv.DictReader(stream)
        rows = [r for r in reader]
        mode = request.form.get('import_mode', 'upsert').strip().lower()

        res = TwinRecordService.process_financial_records_import(
            company_id=company_id,
            rows=rows,
            transaction_type='revenue',
            mode=mode
        )
        res['summary'] = _get_revenue_summary(company_id)
        return jsonify(res)
    except Exception as e:
        logger.error(f"Revenue CSV Import failed: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/revenue/import-excel', methods=['POST'])
@login_required
def import_revenue_excel():
    company_id = _get_active_company_id()
    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['excel_file']
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not (file.filename.lower().endswith('.xlsx') or file.filename.lower().endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400

    try:
        from openpyxl import load_workbook
        wb = load_workbook(filename=io.BytesIO(file.read()), data_only=True)
        ws = wb.active

        raw_rows = list(ws.iter_rows(values_only=True))
        if not raw_rows:
            return jsonify({'success': False, 'error': 'Excel sheet is empty'}), 400

        header_row = raw_rows[0]
        headers = []
        for cell in header_row:
            h = str(cell).strip().lower().replace(' ', '_').replace('-', '_') if cell is not None else ''
            headers.append(h)

        rows = []
        for r in raw_rows[1:]:
            if not any(r):
                continue
            row_dict = {}
            for idx, h in enumerate(headers):
                if h and idx < len(r):
                    row_dict[h] = r[idx]
            rows.append(row_dict)

        mode = request.form.get('import_mode', 'upsert').strip().lower()
        res = TwinRecordService.process_financial_records_import(
            company_id=company_id,
            rows=rows,
            transaction_type='revenue',
            mode=mode
        )
        res['summary'] = _get_revenue_summary(company_id)
        return jsonify(res)
    except Exception as e:
        logger.error(f"Revenue Excel Import failed: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/revenue/download-template')
@login_required
def download_revenue_csv_template():
    company_id = _get_active_company_id()
    CompanyService.ensure_company_financial_accounts(company_id)

    dept = Department.query.filter_by(company_id=company_id).first()
    acc = FinancialAccount.query.filter_by(company_id=company_id, account_category='Income').first() or FinancialAccount.query.filter_by(company_id=company_id).first()
    dept_name = dept.name if dept else 'Sales'
    acc_name = acc.account_name if acc else 'Commercial Sales & Enterprise Revenue'

    today = date.today()
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'transaction_date', 'category', 'subcategory', 'amount', 'description',
        'reference_number', 'department', 'account', 'is_recurring', 'recurring_frequency'
    ])

    sample_data = [
        [today.strftime('%Y-%m-%d'), 'Revenue', 'Product Sales', 12500, 'Q4 software licenses', 'INV-001', dept_name, acc_name, 'No', ''],
        [(today - timedelta(days=2)).strftime('%Y-%m-%d'), 'Revenue', 'Services', 45000, 'Consulting retainer', 'INV-002', dept_name, acc_name, 'Yes', 'monthly'],
        [(today - timedelta(days=5)).strftime('%Y-%m-%d'), 'Revenue', 'Subscription', 28000, 'Annual SaaS renewal', 'INV-003', dept_name, acc_name, 'No', ''],
        [(today - timedelta(days=10)).strftime('%Y-%m-%d'), 'Revenue', 'Licensing', 8500, 'Patent license fee', 'INV-004', dept_name, acc_name, 'Yes', 'yearly'],
        [(today - timedelta(days=16)).strftime('%Y-%m-%d'), 'Revenue', 'Product Sales', 15000, 'Hardware shipment', 'INV-005', dept_name, acc_name, 'No', ''],
        [(today - timedelta(days=24)).strftime('%Y-%m-%d'), 'Revenue', 'Services', 32000, 'Managed support contract', 'INV-006', dept_name, acc_name, 'Yes', 'monthly']
    ]

    writer.writerows(sample_data)
    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode('utf-8')), mimetype='text/csv',
                     as_attachment=True, download_name='revenue_import_template.csv')


@business_twin_bp.route('/revenue/download-excel-template')
@login_required
def download_revenue_excel_template():
    company_id = _get_active_company_id()
    CompanyService.ensure_company_financial_accounts(company_id)

    dept = Department.query.filter_by(company_id=company_id).first()
    acc = FinancialAccount.query.filter_by(company_id=company_id, account_category='Income').first() or FinancialAccount.query.filter_by(company_id=company_id).first()
    dept_name = dept.name if dept else 'Sales'
    acc_name = acc.account_name if acc else 'Commercial Sales & Enterprise Revenue'

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Revenue"

    headers = [
        'transaction_date', 'category', 'subcategory', 'amount', 'description',
        'reference_number', 'department', 'account', 'is_recurring', 'recurring_frequency'
    ]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    today = date.today()
    sample_data = [
        [today.strftime('%Y-%m-%d'), 'Revenue', 'Product Sales', 12500, 'Q4 software licenses', 'INV-001', dept_name, acc_name, 'No', ''],
        [(today - timedelta(days=2)).strftime('%Y-%m-%d'), 'Revenue', 'Services', 45000, 'Consulting retainer', 'INV-002', dept_name, acc_name, 'Yes', 'monthly'],
        [(today - timedelta(days=5)).strftime('%Y-%m-%d'), 'Revenue', 'Subscription', 28000, 'Annual SaaS renewal', 'INV-003', dept_name, acc_name, 'No', ''],
        [(today - timedelta(days=10)).strftime('%Y-%m-%d'), 'Revenue', 'Licensing', 8500, 'Patent license fee', 'INV-004', dept_name, acc_name, 'Yes', 'yearly'],
        [(today - timedelta(days=16)).strftime('%Y-%m-%d'), 'Revenue', 'Product Sales', 15000, 'Hardware shipment', 'INV-005', dept_name, acc_name, 'No', ''],
        [(today - timedelta(days=24)).strftime('%Y-%m-%d'), 'Revenue', 'Services', 32000, 'Managed support contract', 'INV-006', dept_name, acc_name, 'Yes', 'monthly']
    ]

    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=value)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except Exception:
                pass
        adjusted_width = min(max_length + 3, 50)
        ws.column_dimensions[column_letter].width = max(adjusted_width, 14)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='revenue_import_template.xlsx')


@business_twin_bp.route('/revenue/export-excel')
@login_required
def export_revenue_excel():
    company_id = session.get('company_id')
    records = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='revenue'
    ).order_by(FinancialRecord.transaction_date.desc()).all()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Revenue"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'Date', 'Category', 'Subcategory', 'Amount', 'Description',
               'Reference Number', 'Department', 'Recurring', 'Frequency']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    depts = {d.id: d.name for d in Department.query.filter_by(company_id=company_id).all()}

    for row_num, rec in enumerate(records, 2):
        ws.cell(row=row_num, column=1, value=rec.id)
        ws.cell(row=row_num, column=2, value=rec.transaction_date.strftime('%Y-%m-%d') if rec.transaction_date else '')
        ws.cell(row=row_num, column=3, value=rec.category or '')
        ws.cell(row=row_num, column=4, value=rec.subcategory or '')
        ws.cell(row=row_num, column=5, value=rec.amount or 0.0)
        ws.cell(row=row_num, column=6, value=rec.description or '')
        ws.cell(row=row_num, column=7, value=rec.reference_number or '')
        ws.cell(row=row_num, column=8, value=depts.get(rec.department_id, '') if rec.department_id else '')
        ws.cell(row=row_num, column=9, value='Yes' if rec.is_recurring else 'No')
        ws.cell(row=row_num, column=10, value=rec.recurring_frequency or '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='revenue_export.xlsx')


@business_twin_bp.route('/revenue/export-csv')
@login_required
def export_revenue_csv():
    company_id = session.get('company_id')
    records = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='revenue'
    ).order_by(FinancialRecord.transaction_date.desc()).all()

    depts = {d.id: d.name for d in Department.query.filter_by(company_id=company_id).all()}

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Date', 'Category', 'Subcategory', 'Amount', 'Description',
                     'Reference Number', 'Department', 'Recurring', 'Frequency'])

    for rec in records:
        writer.writerow([
            rec.id,
            rec.transaction_date.strftime('%Y-%m-%d') if rec.transaction_date else '',
            rec.category or '',
            rec.subcategory or '',
            rec.amount or 0.0,
            rec.description or '',
            rec.reference_number or '',
            depts.get(rec.department_id, '') if rec.department_id else '',
            'Yes' if rec.is_recurring else 'No',
            rec.recurring_frequency or ''
        ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode('utf-8')), mimetype='text/csv',
                     as_attachment=True, download_name='revenue_export.csv')


@business_twin_bp.route('/revenue/export-pdf')
@login_required
def export_revenue_pdf():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    records = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='revenue'
    ).order_by(FinancialRecord.transaction_date.desc()).all()

    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER

    symbol = _get_currency_symbol(company_id)

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('RevTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a1f3a'), spaceAfter=20, alignment=TA_CENTER)
    elements.append(Paragraph(f"{company.company_name if company else 'Company'} - Revenue Report", title_style))
    elements.append(Spacer(1, 0.2*inch))

    total_amount = sum(r.amount or 0.0 for r in records)
    summary_style = ParagraphStyle('RevSummary', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'), spaceAfter=15)
    elements.append(Paragraph(f"Total Transactions: {len(records)} | Total Revenue: {symbol}{total_amount:,.2f} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}", summary_style))
    elements.append(Spacer(1, 0.1*inch))

    table_data = [['Date', 'Category', 'Subcategory', 'Amount', 'Ref Number', 'Recurring']]
    for r in records[:200]:  # Cap at 200 rows for PDF generation stability
        table_data.append([
            r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '-',
            r.category or '-',
            r.subcategory or '-',
            f"{symbol}{r.amount:,.2f}" if r.amount else f'{symbol}0.00',
            r.reference_number or '-',
            'Yes' if r.is_recurring else 'No'
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1f3a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dee2e6')),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8f9fa')])
    ]))
    elements.append(table)
    doc.build(elements)
    output.seek(0)

    return send_file(output, mimetype='application/pdf',
                     as_attachment=True, download_name='revenue_report.pdf')


# =============================================================================
# EXPENSES
# =============================================================================

@business_twin_bp.route('/expenses')
@login_required
def expenses():
    company_id = _get_active_company_id()
    if not company_id:
        return redirect('/login')

    CompanyService.ensure_company_financial_accounts(company_id)
    company = Company.query.get(company_id)
    departments = Department.query.filter_by(company_id=company_id, is_active=True).all()
    accounts = FinancialAccount.query.filter_by(company_id=company_id, is_active=True).all()

    dept_perf = []
    total_budget = 0
    total_spent = 0

    for dept in departments:
        actual_spent = db.session.query(func.sum(FinancialRecord.amount)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.department_id == dept.id,
            FinancialRecord.transaction_type == 'expense'
        ).scalar() or 0.0

        dept.spent = float(actual_spent)
        utilization = round((dept.spent / dept.budget * 100), 2) if dept.budget > 0 else 0
        remaining = dept.budget - dept.spent

        dept_perf.append({
            'id': dept.id,
            'name': dept.name,
            'code': dept.code,
            'budget': dept.budget,
            'spent': dept.spent,
            'remaining': round(remaining, 2),
            'utilization': utilization,
            'employee_count': dept.employee_count,
            'color': dept.color or '#00D4FF',
            'variance': round(remaining, 2)
        })

        total_budget += dept.budget
        total_spent += dept.spent

    db.session.commit()

    recent_expenses = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='expense'
    ).order_by(FinancialRecord.transaction_date.desc()).limit(50).all()

    category_breakdown = db.session.query(
        FinancialRecord.category,
        func.sum(FinancialRecord.amount).label('total')
    ).filter(
        FinancialRecord.company_id == company_id,
        FinancialRecord.transaction_type == 'expense'
    ).group_by(FinancialRecord.category).all()

    monthly_trend = db.session.query(
        func.strftime('%Y-%m', FinancialRecord.transaction_date).label('month'),
        func.sum(FinancialRecord.amount).label('total')
    ).filter(
        FinancialRecord.company_id == company_id,
        FinancialRecord.transaction_type == 'expense'
    ).group_by('month').order_by('month').all()

    summary = {
        'total_budget': total_budget,
        'total_spent': total_spent,
        'total_remaining': total_budget - total_spent,
        'overall_utilization': round((total_spent / total_budget * 100), 2) if total_budget > 0 else 0
    }

    return render_template('business_twin/twin_expenses.html', 
                         summary=summary, 
                         dept_perf=dept_perf,
                         recent_expenses=recent_expenses,
                         recent_expenses_json=[e.to_dict() for e in recent_expenses],
                         category_breakdown=category_breakdown,
                         monthly_trend=monthly_trend,
                         departments=departments,
                         accounts=accounts)


def _get_expense_summary(company_id):
    """Compute real-time updated summary KPIs for expense mutations."""
    try:
        symbol = _get_currency_symbol(company_id)
        departments = Department.query.filter_by(company_id=company_id, is_active=True).all()
        total_budget = sum(d.budget or 0 for d in departments)
        total_spent = db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter(
            FinancialRecord.company_id == company_id,
            FinancialRecord.transaction_type == 'expense'
        ).scalar() or 0.0
        total_remaining = total_budget - total_spent
        utilization = round((total_spent / total_budget * 100), 1) if total_budget > 0 else 0.0
        return {
            'total_budget': total_budget,
            'total_budget_formatted': f"{symbol}{total_budget:,.2f}",
            'total_spent': total_spent,
            'total_spent_formatted': f"{symbol}{total_spent:,.2f}",
            'total_remaining': total_remaining,
            'total_remaining_formatted': f"{symbol}{total_remaining:,.2f}",
            'overall_utilization': utilization,
            'overall_utilization_formatted': f"{utilization:.1f}%"
        }
    except Exception:
        return {}


@business_twin_bp.route('/expenses/add', methods=['POST'])
@login_required
def add_expense():
    company_id = session.get('company_id')

    try:
        dept_id = request.form.get('department_id')
        amount = float(request.form.get('amount', 0))

        if amount <= 0:
            return jsonify({'success': False, 'error': 'Amount must be greater than 0'}), 400

        tx_date_str = request.form.get('transaction_date')
        if tx_date_str:
            tx_date = datetime.strptime(tx_date_str, '%Y-%m-%d').date()
        else:
            tx_date = date.today()

        expense = FinancialRecord(
            company_id=company_id,
            department_id=int(dept_id) if dept_id else None,
            transaction_date=tx_date,
            transaction_type='expense',
            category=request.form.get('category', 'Operating Expenses'),
            subcategory=request.form.get('subcategory', 'General'),
            amount=amount,
            description=request.form.get('description', ''),
            reference_number=request.form.get('reference_number', ''),
            is_recurring=request.form.get('is_recurring') == 'on',
            recurring_frequency=request.form.get('recurring_frequency', ''),
            created_by=current_user.id if hasattr(current_user, 'id') else None
        )

        db.session.add(expense)

        if dept_id:
            dept = Department.query.filter_by(id=int(dept_id), company_id=company_id).first()
            if dept:
                dept.spent = (dept.spent or 0) + amount

        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
                company_id=company_id,
                aggregate_type='financial_record',
                aggregate_id=str(expense.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'transaction_type': 'expense',
                    'amount': expense.amount,
                    'category': expense.category,
                    'description': expense.description
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        symbol = _get_currency_symbol(company_id)

        return jsonify({
            'success': True, 
            'message': f'Expense of {symbol}{amount:,.2f} added successfully',
            'expense': expense.to_dict(),
            'summary': _get_expense_summary(company_id)
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/expenses/edit/<int:expense_id>', methods=['POST'])
@login_required
def edit_expense(expense_id):
    company_id = session.get('company_id')
    expense = FinancialRecord.query.filter_by(
        id=expense_id, company_id=company_id, transaction_type='expense'
    ).first()
    if not expense:
        return jsonify({'success': False, 'error': 'Expense not found'}), 404

    try:
        old_dept_id = expense.department_id
        old_amount = expense.amount

        amount = request.form.get('amount')
        if amount is not None and amount.strip():
            expense.amount = float(amount)

        tx_date_str = request.form.get('transaction_date')
        if tx_date_str and tx_date_str.strip():
            expense.transaction_date = datetime.strptime(tx_date_str, '%Y-%m-%d').date()

        expense.category = request.form.get('category', expense.category or 'Operating Expenses')
        expense.subcategory = request.form.get('subcategory', expense.subcategory or '')
        expense.description = request.form.get('description', expense.description or '')
        expense.reference_number = request.form.get('reference_number', expense.reference_number or '')

        dept_id = request.form.get('department_id')
        if dept_id is not None:
            expense.department_id = int(dept_id) if dept_id.strip() else None

        expense.is_recurring = request.form.get('is_recurring') == 'on'
        expense.recurring_frequency = request.form.get('recurring_frequency', expense.recurring_frequency or '')

        new_amount = expense.amount
        new_dept_id = expense.department_id

        # Adjust department spending
        if old_dept_id and old_dept_id == new_dept_id:
            dept = Department.query.filter_by(id=old_dept_id, company_id=company_id).first()
            if dept:
                dept.spent = (dept.spent or 0) + (new_amount - old_amount)
        elif old_dept_id and new_dept_id and old_dept_id != new_dept_id:
            old_dept = Department.query.filter_by(id=old_dept_id, company_id=company_id).first()
            if old_dept:
                old_dept.spent = max(0, (old_dept.spent or 0) - old_amount)
            new_dept = Department.query.filter_by(id=new_dept_id, company_id=company_id).first()
            if new_dept:
                new_dept.spent = (new_dept.spent or 0) + new_amount
        elif not old_dept_id and new_dept_id:
            new_dept = Department.query.filter_by(id=new_dept_id, company_id=company_id).first()
            if new_dept:
                new_dept.spent = (new_dept.spent or 0) + new_amount
        elif old_dept_id and not new_dept_id:
            old_dept = Department.query.filter_by(id=old_dept_id, company_id=company_id).first()
            if old_dept:
                old_dept.spent = max(0, (old_dept.spent or 0) - old_amount)

        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_UPDATED,
                company_id=company_id,
                aggregate_type='financial_record',
                aggregate_id=str(expense.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'transaction_type': 'expense',
                    'amount': expense.amount,
                    'category': expense.category,
                    'description': expense.description
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({
            'success': True, 
            'expense': expense.to_dict(),
            'summary': _get_expense_summary(company_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/expenses/delete/<int:expense_id>', methods=['DELETE'])
@login_required
def delete_expense(expense_id):
    company_id = session.get('company_id')

    expense = FinancialRecord.query.filter_by(id=expense_id, company_id=company_id).first()
    if not expense:
        return jsonify({'success': False, 'error': 'Expense not found'}), 404

    try:
        desc = expense.description
        amt = expense.amount
        if expense.department_id:
            dept = Department.query.filter_by(id=expense.department_id, company_id=company_id).first()
            if dept and dept.spent:
                dept.spent = max(0, dept.spent - expense.amount)

        db.session.delete(expense)
        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_DELETED,
                company_id=company_id,
                aggregate_type='financial_record',
                aggregate_id=str(expense_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'transaction_type': 'expense', 'amount': amt, 'description': desc}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({
            'success': True, 
            'message': 'Expense deleted successfully',
            'summary': _get_expense_summary(company_id)
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/expenses/delete-all', methods=['DELETE'])
@login_required
def delete_all_expenses():
    company_id = session.get('company_id')
    try:
        count = FinancialRecord.query.filter_by(
            company_id=company_id, transaction_type='expense'
        ).count()
        FinancialRecord.query.filter_by(
            company_id=company_id, transaction_type='expense'
        ).delete()

        # Reset all department spent to 0
        departments = Department.query.filter_by(company_id=company_id).all()
        for dept in departments:
            dept.spent = 0

        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'All {count} expense records deleted successfully',
            'summary': _get_expense_summary(company_id)
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/expenses/import-csv', methods=['POST'])
@login_required
def import_expenses_csv():
    company_id = _get_active_company_id()
    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['csv_file']
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not file.filename.lower().endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV (.csv)'}), 400

    try:
        content = file.stream.read().decode('utf-8', errors='replace')
        stream = io.StringIO(content, newline=None)
        reader = csv.DictReader(stream)
        rows = [r for r in reader]
        mode = request.form.get('import_mode', 'upsert').strip().lower()

        res = TwinRecordService.process_financial_records_import(
            company_id=company_id,
            rows=rows,
            transaction_type='expense',
            mode=mode
        )

        # Sync actual department expenditure
        depts = Department.query.filter_by(company_id=company_id).all()
        for d in depts:
            tot = db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter_by(
                company_id=company_id, department_id=d.id, transaction_type='expense'
            ).scalar()
            d.spent = float(tot or 0.0)
        db.session.commit()

        res['summary'] = _get_expense_summary(company_id)
        return jsonify(res)
    except Exception as e:
        logger.error(f"Expense CSV Import failed: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/expenses/import-excel', methods=['POST'])
@login_required
def import_expenses_excel():
    company_id = _get_active_company_id()
    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['excel_file']
    if not file or not file.filename:
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not (file.filename.lower().endswith('.xlsx') or file.filename.lower().endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400

    try:
        from openpyxl import load_workbook
        wb = load_workbook(filename=io.BytesIO(file.read()), data_only=True)
        ws = wb.active

        raw_rows = list(ws.iter_rows(values_only=True))
        if not raw_rows:
            return jsonify({'success': False, 'error': 'Excel sheet is empty'}), 400

        header_row = raw_rows[0]
        headers = []
        for cell in header_row:
            h = str(cell).strip().lower().replace(' ', '_').replace('-', '_') if cell is not None else ''
            headers.append(h)

        rows = []
        for r in raw_rows[1:]:
            if not any(r):
                continue
            row_dict = {}
            for idx, h in enumerate(headers):
                if h and idx < len(r):
                    row_dict[h] = r[idx]
            rows.append(row_dict)

        mode = request.form.get('import_mode', 'upsert').strip().lower()
        res = TwinRecordService.process_financial_records_import(
            company_id=company_id,
            rows=rows,
            transaction_type='expense',
            mode=mode
        )

        # Sync actual department expenditure
        depts = Department.query.filter_by(company_id=company_id).all()
        for d in depts:
            tot = db.session.query(func.coalesce(func.sum(FinancialRecord.amount), 0.0)).filter_by(
                company_id=company_id, department_id=d.id, transaction_type='expense'
            ).scalar()
            d.spent = float(tot or 0.0)
        db.session.commit()

        res['summary'] = _get_expense_summary(company_id)
        return jsonify(res)
    except Exception as e:
        logger.error(f"Expense Excel Import failed: {e}", exc_info=True)
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/expenses/download-template')
@login_required
def download_expense_template():
    company_id = _get_active_company_id()
    CompanyService.ensure_company_financial_accounts(company_id)

    dept = Department.query.filter_by(company_id=company_id).first()
    dept_name = dept.name if dept else 'Operations'
    acc = FinancialAccount.query.filter_by(company_id=company_id, account_category='Expense').first() or FinancialAccount.query.filter_by(company_id=company_id).first()
    acc_name = acc.account_name if acc else 'Operational Expenditure & Vendor Clearing'

    today = date.today()
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'department', 'category', 'subcategory', 'amount', 'description',
        'transaction_date', 'reference_number', 'account', 'is_recurring', 'recurring_frequency'
    ])

    sample_data = [
        [dept_name, 'Operating Expenses', 'Travel & Entertainment', 12500, 'Client on-site discovery', today.strftime('%Y-%m-%d'), 'EXP-001', acc_name, 'No', ''],
        [dept_name, 'Operating Expenses', 'Digital Advertising', 45000, 'Performance marketing budget', (today - timedelta(days=2)).strftime('%Y-%m-%d'), 'EXP-002', acc_name, 'Yes', 'monthly'],
        [dept_name, 'Operating Expenses', 'Logistics', 28000, 'Supply chain delivery', (today - timedelta(days=5)).strftime('%Y-%m-%d'), 'EXP-003', acc_name, 'No', ''],
        [dept_name, 'Operating Expenses', 'Software', 8500, 'Cloud platform subscription', (today - timedelta(days=10)).strftime('%Y-%m-%d'), 'EXP-004', acc_name, 'Yes', 'yearly'],
        [dept_name, 'Operating Expenses', 'Infrastructure', 15000, 'Data center connectivity', (today - timedelta(days=16)).strftime('%Y-%m-%d'), 'EXP-005', acc_name, 'No', ''],
        [dept_name, 'Operating Expenses', 'Cloud', 32000, 'Compute and cluster nodes', (today - timedelta(days=24)).strftime('%Y-%m-%d'), 'EXP-006', acc_name, 'Yes', 'monthly']
    ]

    writer.writerows(sample_data)
    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode('utf-8')), mimetype='text/csv',
                     as_attachment=True, download_name='expense_import_template.csv')


@business_twin_bp.route('/expenses/download-excel-template')
@login_required
def download_expense_excel_template():
    company_id = _get_active_company_id()
    CompanyService.ensure_company_financial_accounts(company_id)

    dept = Department.query.filter_by(company_id=company_id).first()
    dept_name = dept.name if dept else 'Operations'
    acc = FinancialAccount.query.filter_by(company_id=company_id, account_category='Expense').first() or FinancialAccount.query.filter_by(company_id=company_id).first()
    acc_name = acc.account_name if acc else 'Operational Expenditure & Vendor Clearing'

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Expenses"

    headers = [
        'department', 'category', 'subcategory', 'amount', 'description',
        'transaction_date', 'reference_number', 'account', 'is_recurring', 'recurring_frequency'
    ]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    today = date.today()
    sample_data = [
        [dept_name, 'Operating Expenses', 'Travel & Entertainment', 12500, 'Client on-site discovery', today.strftime('%Y-%m-%d'), 'EXP-001', acc_name, 'No', ''],
        [dept_name, 'Operating Expenses', 'Digital Advertising', 45000, 'Performance marketing budget', (today - timedelta(days=2)).strftime('%Y-%m-%d'), 'EXP-002', acc_name, 'Yes', 'monthly'],
        [dept_name, 'Operating Expenses', 'Logistics', 28000, 'Supply chain delivery', (today - timedelta(days=5)).strftime('%Y-%m-%d'), 'EXP-003', acc_name, 'No', ''],
        [dept_name, 'Operating Expenses', 'Software', 8500, 'Cloud platform subscription', (today - timedelta(days=10)).strftime('%Y-%m-%d'), 'EXP-004', acc_name, 'Yes', 'yearly'],
        [dept_name, 'Operating Expenses', 'Infrastructure', 15000, 'Data center connectivity', (today - timedelta(days=16)).strftime('%Y-%m-%d'), 'EXP-005', acc_name, 'No', ''],
        [dept_name, 'Operating Expenses', 'Cloud', 32000, 'Compute and cluster nodes', (today - timedelta(days=24)).strftime('%Y-%m-%d'), 'EXP-006', acc_name, 'Yes', 'monthly']
    ]

    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=value)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except Exception:
                pass
        adjusted_width = min(max_length + 3, 50)
        ws.column_dimensions[column_letter].width = max(adjusted_width, 14)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='expense_import_template.xlsx')


@business_twin_bp.route('/expenses/export-excel')
@login_required
def export_expenses_excel():
    company_id = session.get('company_id')
    records = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='expense'
    ).order_by(FinancialRecord.transaction_date.desc()).all()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Expenses"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'Date', 'Category', 'Subcategory', 'Amount', 'Description',
               'Reference Number', 'Department', 'Recurring', 'Frequency']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    depts = {d.id: d.name for d in Department.query.filter_by(company_id=company_id).all()}

    for row_num, rec in enumerate(records, 2):
        ws.cell(row=row_num, column=1, value=rec.id)
        ws.cell(row=row_num, column=2, value=rec.transaction_date.strftime('%Y-%m-%d') if rec.transaction_date else '')
        ws.cell(row=row_num, column=3, value=rec.category or '')
        ws.cell(row=row_num, column=4, value=rec.subcategory or '')
        ws.cell(row=row_num, column=5, value=rec.amount or 0.0)
        ws.cell(row=row_num, column=6, value=rec.description or '')
        ws.cell(row=row_num, column=7, value=rec.reference_number or '')
        ws.cell(row=row_num, column=8, value=depts.get(rec.department_id, '') if rec.department_id else '')
        ws.cell(row=row_num, column=9, value='Yes' if rec.is_recurring else 'No')
        ws.cell(row=row_num, column=10, value=rec.recurring_frequency or '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        ws.column_dimensions[column_letter].width = min(max_length + 2, 50)

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)
    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='expenses_export.xlsx')


@business_twin_bp.route('/expenses/export-csv')
@login_required
def export_expenses_csv():
    company_id = session.get('company_id')
    records = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='expense'
    ).order_by(FinancialRecord.transaction_date.desc()).all()

    depts = {d.id: d.name for d in Department.query.filter_by(company_id=company_id).all()}

    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['ID', 'Date', 'Category', 'Subcategory', 'Amount', 'Description',
                     'Reference Number', 'Department', 'Recurring', 'Frequency'])

    for rec in records:
        writer.writerow([
            rec.id,
            rec.transaction_date.strftime('%Y-%m-%d') if rec.transaction_date else '',
            rec.category or '',
            rec.subcategory or '',
            rec.amount or 0.0,
            rec.description or '',
            rec.reference_number or '',
            depts.get(rec.department_id, '') if rec.department_id else '',
            'Yes' if rec.is_recurring else 'No',
            rec.recurring_frequency or ''
        ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode('utf-8')), mimetype='text/csv',
                     as_attachment=True, download_name='expenses_export.csv')


@business_twin_bp.route('/expenses/export-pdf')
@login_required
def export_expenses_pdf():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    records = FinancialRecord.query.filter_by(
        company_id=company_id, transaction_type='expense'
    ).order_by(FinancialRecord.transaction_date.desc()).all()

    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER

    symbol = _get_currency_symbol(company_id)
    depts = {d.id: d.name for d in Department.query.filter_by(company_id=company_id).all()}

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('ExpTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a1f3a'), spaceAfter=20, alignment=TA_CENTER)
    elements.append(Paragraph(f"{company.company_name if company else 'Company'} - Expense Report", title_style))
    elements.append(Spacer(1, 0.2*inch))

    total_amount = sum(r.amount or 0.0 for r in records)
    summary_style = ParagraphStyle('ExpSummary', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'), spaceAfter=15)
    elements.append(Paragraph(f"Total Transactions: {len(records)} | Total Expenses: {symbol}{total_amount:,.2f} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}", summary_style))
    elements.append(Spacer(1, 0.1*inch))

    table_data = [['Date', 'Category', 'Subcategory', 'Department', 'Amount', 'Ref Number']]
    for r in records[:200]:  # Cap at 200 rows for PDF generation stability
        table_data.append([
            r.transaction_date.strftime('%Y-%m-%d') if r.transaction_date else '-',
            r.category or '-',
            r.subcategory or '-',
            depts.get(r.department_id, '-') if r.department_id else '-',
            f"{symbol}{r.amount:,.2f}" if r.amount else f'{symbol}0.00',
            r.reference_number or '-'
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1f3a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dee2e6')),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8f9fa')])
    ]))
    elements.append(table)
    doc.build(elements)
    output.seek(0)

    return send_file(output, mimetype='application/pdf',
                     as_attachment=True, download_name='expenses_report.pdf')


@business_twin_bp.route('/customers')
@login_required
def customers():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    customers = Customer.query.filter_by(company_id=company_id).order_by(Customer.created_at.desc()).all()

    total_db_customers = len(customers)
    estimated_total = 0
    if total_db_customers == 0 and company:
        estimated_total = AnalyticsService._estimate_customers(company)

    active_count = len([c for c in customers if (c.status or 'active').lower() == 'active' and not c.is_churned])
    churned_count = len([c for c in customers if c.is_churned or (c.status or '').lower() == 'churned'])
    inactive_count = len([c for c in customers if (c.status or '').lower() == 'inactive' and not c.is_churned])
    total_ltv = sum(float(c.lifetime_value or 0) for c in customers)
    avg_ltv = (total_ltv / total_db_customers) if total_db_customers > 0 else 0.0

    # Build real segment breakdown from database records
    from collections import defaultdict
    seg_groups = defaultdict(list)
    for c in customers:
        seg = (c.segment or 'General').strip()
        seg_groups[seg].append(c)

    segment_data = []
    for seg, seg_custs in seg_groups.items():
        seg_cnt = len(seg_custs)
        seg_avg_val = sum(float(c.lifetime_value or 0) for c in seg_custs) / seg_cnt if seg_cnt else 0.0
        segment_data.append({
            'name': seg,
            'count': seg_cnt,
            'avg_ltv': round(seg_avg_val, 2)
        })
    segment_data.sort(key=lambda x: x['count'], reverse=True)

    currency_symbol = _get_currency_symbol(company_id)

    return render_template('business_twin/twin_customers.html', 
                         customers=customers, 
                         company=company,
                         total_db_customers=total_db_customers,
                         estimated_total=estimated_total,
                         active_count=active_count,
                         churned_count=churned_count,
                         inactive_count=inactive_count,
                         total_ltv=total_ltv,
                         avg_ltv=avg_ltv,
                         segment_data=segment_data,
                         currency_symbol=currency_symbol)


@business_twin_bp.route('/customers/add', methods=['POST'])
@login_required
def add_customer():
    company_id = session.get('company_id')

    status_val = request.form.get('status', 'active')
    is_churn_param = request.form.get('is_churned')
    is_churn = (status_val == 'churned') or is_churn_param in ('true', 'True', '1', True)
    churn_date = date.today() if is_churn else None

    customer = Customer(
        company_id=company_id,
        customer_code=request.form.get('customer_code', 'CUST-' + str(datetime.utcnow().timestamp())[-6:]),
        first_name=request.form.get('first_name', ''),
        last_name=request.form.get('last_name', ''),
        company_name=request.form.get('company_name', ''),
        email=request.form.get('email', ''),
        phone=request.form.get('phone', ''),
        address=request.form.get('address', ''),
        city=request.form.get('city', ''),
        country=request.form.get('country', ''),
        segment=request.form.get('segment', 'General'),
        lifetime_value=float(request.form.get('lifetime_value', 0)),
        acquisition_cost=float(request.form.get('acquisition_cost', 0)),
        total_orders=int(request.form.get('total_orders', 0)),
        total_spent=float(request.form.get('total_spent', 0)),
        satisfaction_score=float(request.form.get('satisfaction_score', 0)) if request.form.get('satisfaction_score') else None,
        nps_score=float(request.form.get('nps_score', 0)) if request.form.get('nps_score') else None,
        status=status_val,
        is_churned=is_churn,
        churn_date=churn_date
    )

    db.session.add(customer)
    db.session.flush()  # assign customer.id before twin mirroring
    
    # ENTERPRISE INTERCONNECTION: mirror into customer-linked twins and
    # recompute authoritative company metrics + health score.
    _mirror_customer_to_twin(company_id, customer, 'on_create',
                             user_id=current_user.id if hasattr(current_user, 'id') else None)

    db.session.commit()

    company = Company.query.get(company_id)
    if company:
        company.customer_count = Customer.query.filter_by(
            company_id=company_id, status='active').count()
        try:
            from services.twin_service import TwinService
            TwinService.recalculate_company_metrics(company_id)
        except Exception:
            pass
        db.session.commit()

    flash('Customer added successfully!', 'success')

    try:
        publish_event(DomainEvent.create(
            event_type=EventTypes.CUSTOMER_CREATED,
            company_id=company_id,
            aggregate_type='customer',
            aggregate_id=str(customer.id),
            actor_id=current_user.id if hasattr(current_user, 'id') else None,
            actor_name=getattr(current_user, 'username', 'System'),
            payload={
                'name': f"{customer.first_name} {customer.last_name}".strip() or customer.company_name,
                'email': customer.email,
                'segment': customer.segment
            }
        ))
    except Exception as ev_err:
        logger.warning(f"Event publication warning: {ev_err}")

    return jsonify({'success': True, 'customer': customer.to_dict()})


@business_twin_bp.route('/customers/edit/<int:customer_id>', methods=['POST'])
@business_twin_bp.route('/customers/<int:customer_id>/edit', methods=['POST'])
@login_required
def edit_customer(customer_id):
    company_id = session.get('company_id')
    customer = Customer.query.filter_by(id=customer_id, company_id=company_id).first()
    
    if not customer:
        return jsonify({'success': False, 'error': 'Customer not found'}), 404
    
    try:
        customer.customer_code = request.form.get('customer_code') or customer.customer_code
        customer.first_name = request.form.get('first_name', customer.first_name or '')
        customer.last_name = request.form.get('last_name', customer.last_name or '')
        customer.company_name = request.form.get('company_name', customer.company_name or '')
        customer.email = request.form.get('email', customer.email or '')
        customer.phone = request.form.get('phone', customer.phone or '')
        customer.address = request.form.get('address', customer.address or '')
        customer.city = request.form.get('city', customer.city or '')
        customer.country = request.form.get('country', customer.country or '')
        customer.segment = request.form.get('segment', customer.segment or 'General')
        customer.lifetime_value = float(request.form.get('lifetime_value', customer.lifetime_value or 0) or 0)
        customer.acquisition_cost = float(request.form.get('acquisition_cost', customer.acquisition_cost or 0) or 0)
        customer.total_orders = int(request.form.get('total_orders', customer.total_orders or 0) or 0)
        customer.total_spent = float(request.form.get('total_spent', customer.total_spent or 0) or 0)
        
        satisfaction = request.form.get('satisfaction_score', '')
        customer.satisfaction_score = float(satisfaction) if satisfaction and satisfaction.strip() else None
        
        nps = request.form.get('nps_score', '')
        customer.nps_score = float(nps) if nps and nps.strip() else None
        
        new_status = request.form.get('status', customer.status or 'active')
        customer.status = new_status
        is_churn_param = request.form.get('is_churned')
        if new_status.lower() == 'churned' or is_churn_param in ('true', 'True', '1', True):
            customer.is_churned = True
            if not customer.churn_date:
                customer.churn_date = date.today()
        elif new_status.lower() == 'active' or is_churn_param in ('false', 'False', '0', False):
            customer.is_churned = False
            customer.churn_date = None
        
        db.session.commit()
        
        # ENTERPRISE INTERCONNECTION: mirror update into customer-linked twins
        _mirror_customer_to_twin(company_id, customer, 'on_update',
                                 user_id=current_user.id if hasattr(current_user, 'id') else None)
        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOMER_UPDATED,
                company_id=company_id,
                aggregate_type='customer',
                aggregate_id=str(customer.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'name': f"{customer.first_name} {customer.last_name}".strip() or customer.company_name,
                    'email': customer.email,
                    'segment': customer.segment
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({'success': True, 'customer': customer.to_dict()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/customers/delete/<int:customer_id>', methods=['DELETE'])
@login_required
def delete_customer(customer_id):
    company_id = session.get('company_id')
    customer = Customer.query.filter_by(id=customer_id, company_id=company_id).first()
    
    if not customer:
        return jsonify({'success': False, 'error': 'Customer not found'}), 404
    
    try:
        cust_name = f"{customer.first_name} {customer.last_name}".strip() or customer.company_name
        # Reverse twin impacts BEFORE the row is gone
        _mirror_customer_to_twin(company_id, customer, 'on_delete',
                                 user_id=current_user.id if hasattr(current_user, 'id') else None)
        
        db.session.delete(customer)
        db.session.commit()
        
        company = Company.query.get(company_id)
        if company:
            company.customer_count = Customer.query.filter_by(
                company_id=company_id, status='active').count()
            try:
                from services.twin_service import TwinService
                TwinService.recalculate_company_metrics(company_id)
            except Exception:
                pass
            db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.CUSTOMER_DELETED,
                company_id=company_id,
                aggregate_type='customer',
                aggregate_id=str(customer_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': cust_name}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({'success': True, 'message': 'Customer deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/customers/delete-all', methods=['DELETE'])
@login_required
def delete_all_customers():
    company_id = session.get('company_id')
    try:
        count = Customer.query.filter_by(company_id=company_id).count()
        Customer.query.filter_by(company_id=company_id).delete()
        db.session.commit()
        
        company = Company.query.get(company_id)
        if company and hasattr(company, 'customer_count'):
            company.customer_count = 0
            db.session.commit()
        
        return jsonify({'success': True, 'message': f'All {count} customers deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/customers/import-csv', methods=['POST'])
@login_required
def import_customers_csv():
    company_id = session.get('company_id')

    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not file.filename.endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV'}), 400

    try:
        stream = io.StringIO(file.stream.read().decode('UTF-8'), newline=None)
        csv_reader = csv.DictReader(stream)

        added_count = 0
        updated_count = 0
        errors = []

        for row_num, row in enumerate(csv_reader, start=2):
            try:
                if not row.get('first_name') or not row.get('last_name') or not row.get('email'):
                    errors.append(f"Row {row_num}: Missing required fields (first_name, last_name, email)")
                    continue

                email = row.get('email', '').strip()
                existing = Customer.query.filter_by(company_id=company_id, email=email).first()
                
                if existing:
                    existing.customer_code = row.get('customer_code', existing.customer_code or '').strip() or existing.customer_code
                    existing.first_name = row.get('first_name', '').strip()
                    existing.last_name = row.get('last_name', '').strip()
                    existing.company_name = row.get('company_name', '').strip()
                    existing.phone = row.get('phone', '').strip()
                    existing.address = row.get('address', '').strip()
                    existing.city = row.get('city', '').strip()
                    existing.country = row.get('country', '').strip()
                    existing.segment = row.get('segment', 'General').strip()
                    existing.lifetime_value = float(row.get('lifetime_value', 0) or 0)
                    existing.acquisition_cost = float(row.get('acquisition_cost', 0) or 0)
                    existing.total_orders = int(row.get('total_orders', 0) or 0)
                    existing.total_spent = float(row.get('total_spent', 0) or 0)
                    existing.satisfaction_score = float(row.get('satisfaction_score', 0)) if row.get('satisfaction_score') else None
                    existing.nps_score = float(row.get('nps_score', 0)) if row.get('nps_score') else None
                    stat = row.get('status', 'active').strip()
                    existing.status = stat
                    is_churn = stat.lower() == 'churned'
                    existing.is_churned = is_churn
                    if is_churn and not existing.churn_date:
                        existing.churn_date = date.today()
                    elif not is_churn:
                        existing.churn_date = None
                    updated_count += 1
                else:
                    stat = row.get('status', 'active').strip()
                    is_churn = stat.lower() == 'churned'
                    customer = Customer(
                        company_id=company_id,
                        customer_code=row.get('customer_code', 'CUST-' + str(datetime.utcnow().timestamp())[-6:] + str(row_num)),
                        first_name=row.get('first_name', '').strip(),
                        last_name=row.get('last_name', '').strip(),
                        company_name=row.get('company_name', '').strip(),
                        email=email,
                        phone=row.get('phone', '').strip(),
                        address=row.get('address', '').strip(),
                        city=row.get('city', '').strip(),
                        country=row.get('country', '').strip(),
                        segment=row.get('segment', 'General').strip(),
                        lifetime_value=float(row.get('lifetime_value', 0) or 0),
                        acquisition_cost=float(row.get('acquisition_cost', 0) or 0),
                        total_orders=int(row.get('total_orders', 0) or 0),
                        total_spent=float(row.get('total_spent', 0) or 0),
                        satisfaction_score=float(row.get('satisfaction_score', 0)) if row.get('satisfaction_score') else None,
                        nps_score=float(row.get('nps_score', 0)) if row.get('nps_score') else None,
                        status=stat,
                        is_churned=is_churn,
                        churn_date=date.today() if is_churn else None
                    )
                    db.session.add(customer)
                    added_count += 1

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()

        company = Company.query.get(company_id)
        if company and hasattr(company, 'customer_count'):
            company.customer_count = Customer.query.filter_by(company_id=company_id).count()
            db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/customers/import-excel', methods=['POST'])
@login_required
def import_customers_excel():
    company_id = session.get('company_id')

    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['excel_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not (file.filename.endswith('.xlsx') or file.filename.endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400

    try:
        from openpyxl import load_workbook

        wb = load_workbook(filename=io.BytesIO(file.read()))
        ws = wb.active

        headers = []
        for cell in ws[1]:
            val = cell.value
            if val:
                h = str(val).strip().lower().replace(' ', '_').replace('-', '_')
                headers.append(h)
            else:
                headers.append('')

        header_map = {}
        for idx, h in enumerate(headers):
            if h in ['customer_code', 'code', 'cust_code', 'id']:
                header_map['customer_code'] = idx
            elif h in ['first_name', 'firstname', 'first_name']:
                header_map['first_name'] = idx
            elif h in ['last_name', 'lastname', 'last_name']:
                header_map['last_name'] = idx
            elif h in ['company_name', 'company', 'organization', 'org_name']:
                header_map['company_name'] = idx
            elif h in ['email', 'email_address', 'e_mail', 'e-mail', 'mail']:
                header_map['email'] = idx
            elif h in ['phone', 'phone_number', 'telephone', 'mobile', 'contact']:
                header_map['phone'] = idx
            elif h in ['address', 'street', 'street_address']:
                header_map['address'] = idx
            elif h in ['city', 'town']:
                header_map['city'] = idx
            elif h in ['country', 'nation', 'region']:
                header_map['country'] = idx
            elif h in ['segment', 'category', 'type', 'customer_segment']:
                header_map['segment'] = idx
            elif h in ['lifetime_value', 'ltv', 'lifetime_value', 'customer_lifetime_value']:
                header_map['lifetime_value'] = idx
            elif h in ['acquisition_cost', 'acq_cost', 'cost', 'cac', 'customer_acquisition_cost']:
                header_map['acquisition_cost'] = idx
            elif h in ['total_orders', 'orders', 'order_count', 'num_orders']:
                header_map['total_orders'] = idx
            elif h in ['total_spent', 'spent', 'revenue', 'amount_spent']:
                header_map['total_spent'] = idx
            elif h in ['satisfaction_score', 'satisfaction', 'csat', 'customer_satisfaction']:
                header_map['satisfaction_score'] = idx
            elif h in ['nps_score', 'nps', 'net_promoter_score', 'promoter_score']:
                header_map['nps_score'] = idx
            elif h in ['status', 'state', 'customer_status']:
                header_map['status'] = idx

        if 'first_name' not in header_map or 'last_name' not in header_map or 'email' not in header_map:
            return jsonify({'success': False, 'error': 'Excel file must have columns: first_name, last_name, email'}), 400

        added_count = 0
        updated_count = 0
        errors = []

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            try:
                first_name_idx = header_map.get('first_name', 0)
                last_name_idx = header_map.get('last_name', 1)
                email_idx = header_map.get('email', 2)

                first_name = str(row[first_name_idx] if first_name_idx < len(row) else '').strip()
                last_name = str(row[last_name_idx] if last_name_idx < len(row) else '').strip()
                email = str(row[email_idx] if email_idx < len(row) else '').strip()

                if not first_name or not last_name or not email:
                    errors.append(f"Row {row_num}: Missing required fields (first_name, last_name, email)")
                    continue

                def get_val(key, default=''):
                    idx = header_map.get(key)
                    if idx is not None and idx < len(row):
                        val = row[idx]
                        return str(val).strip() if val is not None else default
                    return default

                def get_float_val(key, default=0.0):
                    idx = header_map.get(key)
                    if idx is not None and idx < len(row):
                        val = row[idx]
                        if val is not None:
                            try:
                                return float(val)
                            except (ValueError, TypeError):
                                return default
                    return default

                def get_int_val(key, default=0):
                    idx = header_map.get(key)
                    if idx is not None and idx < len(row):
                        val = row[idx]
                        if val is not None:
                            try:
                                return int(float(val))
                            except (ValueError, TypeError):
                                return default
                    return default

                existing = Customer.query.filter_by(company_id=company_id, email=email).first()
                
                if existing:
                    existing.customer_code = get_val('customer_code', existing.customer_code or '') or existing.customer_code
                    existing.first_name = first_name
                    existing.last_name = last_name
                    existing.company_name = get_val('company_name')
                    existing.phone = get_val('phone')
                    existing.address = get_val('address')
                    existing.city = get_val('city')
                    existing.country = get_val('country')
                    existing.segment = get_val('segment', 'General')
                    existing.lifetime_value = get_float_val('lifetime_value')
                    existing.acquisition_cost = get_float_val('acquisition_cost')
                    existing.total_orders = get_int_val('total_orders')
                    existing.total_spent = get_float_val('total_spent')
                    existing.satisfaction_score = get_float_val('satisfaction_score') if get_val('satisfaction_score') else None
                    existing.nps_score = get_float_val('nps_score') if get_val('nps_score') else None
                    stat = get_val('status', 'active')
                    existing.status = stat
                    is_churn = stat.lower() == 'churned'
                    existing.is_churned = is_churn
                    if is_churn and not existing.churn_date:
                        existing.churn_date = date.today()
                    elif not is_churn:
                        existing.churn_date = None
                    updated_count += 1
                else:
                    stat = get_val('status', 'active')
                    is_churn = stat.lower() == 'churned'
                    customer = Customer(
                        company_id=company_id,
                        customer_code=get_val('customer_code', 'CUST-' + str(datetime.utcnow().timestamp())[-6:] + str(row_num)),
                        first_name=first_name,
                        last_name=last_name,
                        company_name=get_val('company_name'),
                        email=email,
                        phone=get_val('phone'),
                        address=get_val('address'),
                        city=get_val('city'),
                        country=get_val('country'),
                        segment=get_val('segment', 'General'),
                        lifetime_value=get_float_val('lifetime_value'),
                        acquisition_cost=get_float_val('acquisition_cost'),
                        total_orders=get_int_val('total_orders'),
                        total_spent=get_float_val('total_spent'),
                        satisfaction_score=get_float_val('satisfaction_score') if get_val('satisfaction_score') else None,
                        nps_score=get_float_val('nps_score') if get_val('nps_score') else None,
                        status=stat,
                        is_churned=is_churn,
                        churn_date=date.today() if is_churn else None
                    )
                    db.session.add(customer)
                    added_count += 1

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()

        company = Company.query.get(company_id)
        if company and hasattr(company, 'customer_count'):
            company.customer_count = Customer.query.filter_by(company_id=company_id).count()
            db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/customers/export-excel')
@login_required
def export_customers_excel():
    company_id = session.get('company_id')
    customers = Customer.query.filter_by(company_id=company_id).order_by(Customer.created_at.desc()).all()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Customers"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'Customer Code', 'First Name', 'Last Name', 'Company Name', 'Email', 
               'Phone', 'Address', 'City', 'Country', 'Segment', 'Lifetime Value', 
               'Acquisition Cost', 'Total Orders', 'Total Spent', 'Satisfaction Score', 
               'NPS Score', 'Status', 'Created At']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    for row_num, customer in enumerate(customers, 2):
        ws.cell(row=row_num, column=1, value=customer.id)
        ws.cell(row=row_num, column=2, value=customer.customer_code)
        ws.cell(row=row_num, column=3, value=customer.first_name)
        ws.cell(row=row_num, column=4, value=customer.last_name)
        ws.cell(row=row_num, column=5, value=customer.company_name)
        ws.cell(row=row_num, column=6, value=customer.email)
        ws.cell(row=row_num, column=7, value=customer.phone)
        ws.cell(row=row_num, column=8, value=customer.address)
        ws.cell(row=row_num, column=9, value=customer.city)
        ws.cell(row=row_num, column=10, value=customer.country)
        ws.cell(row=row_num, column=11, value=customer.segment)
        ws.cell(row=row_num, column=12, value=customer.lifetime_value)
        ws.cell(row=row_num, column=13, value=customer.acquisition_cost)
        ws.cell(row=row_num, column=14, value=customer.total_orders)
        ws.cell(row=row_num, column=15, value=customer.total_spent)
        ws.cell(row=row_num, column=16, value=customer.satisfaction_score)
        ws.cell(row=row_num, column=17, value=customer.nps_score)
        ws.cell(row=row_num, column=18, value=customer.status)
        ws.cell(row=row_num, column=19, value=customer.created_at.strftime('%Y-%m-%d %H:%M:%S') if customer.created_at else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='customers_export.xlsx')


@business_twin_bp.route('/customers/export-pdf')
@login_required
def export_customers_pdf():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    customers = Customer.query.filter_by(company_id=company_id).order_by(Customer.created_at.desc()).all()

    from reportlab.lib.pagesizes import letter, A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER, TA_LEFT

    symbol = _get_currency_symbol(company_id)

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)

    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a1f3a'), spaceAfter=20, alignment=TA_CENTER)
    elements.append(Paragraph(f"{company.company_name if company else 'Company'} - Customer Report", title_style))
    elements.append(Spacer(1, 0.2*inch))

    summary_style = ParagraphStyle('Summary', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'), spaceAfter=15)
    elements.append(Paragraph(f"Total Customers: {len(customers)} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}", summary_style))
    elements.append(Spacer(1, 0.1*inch))

    table_data = [['Name', 'Email', 'Segment', 'LTV', 'Orders', 'Spent', 'Status']]
    for c in customers:
        table_data.append([
            c.full_name() or '-',
            c.email or '-',
            c.segment or 'General',
            f"{symbol}{c.lifetime_value:,.0f}" if c.lifetime_value else f'{symbol}0',
            str(c.total_orders),
            f"{symbol}{c.total_spent:,.0f}" if c.total_spent else f'{symbol}0',
            c.status.title()
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1f3a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f8f9fa')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dee2e6')),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 0), (1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8f9fa')])
    ]))

    elements.append(table)
    doc.build(elements)
    output.seek(0)

    return send_file(output, mimetype='application/pdf',
                     as_attachment=True, download_name='customers_report.pdf')


@business_twin_bp.route('/customers/download-template')
@login_required
def download_csv_template():
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'customer_code', 'first_name', 'last_name', 'company_name', 'email', 'phone',
        'address', 'city', 'country', 'segment', 'lifetime_value', 'acquisition_cost',
        'total_orders', 'total_spent', 'satisfaction_score', 'nps_score', 'status'
    ])

    writer.writerow([
        'CUST-001', 'John', 'Doe', 'Acme Corp', 'john.doe@example.com', '+1-555-0101',
        '123 Main St', 'New York', 'USA', 'Enterprise', '50000', '500',
        '10', '45000', '4.5', '8', 'active'
    ])
    writer.writerow([
        'CUST-002', 'Jane', 'Smith', 'TechStart Inc', 'jane.smith@example.com', '+1-555-0102',
        '456 Oak Ave', 'San Francisco', 'USA', 'SMB', '15000', '200',
        '5', '12000', '4.2', '7', 'active'
    ])
    writer.writerow([
        'CUST-003', 'Ahmed', 'Khan', 'Global Solutions', 'ahmed.khan@example.com', '+91-88888-88888',
        '789 Park Road', 'Bangalore', 'India', 'Enterprise', '80000', '800',
        '15', '75000', '4.8', '9', 'active'
    ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv',
                     as_attachment=True, download_name='customer_import_template.csv')


@business_twin_bp.route('/customers/download-excel-template')
@login_required
def download_excel_template():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Customers"

    headers = [
        'customer_code', 'first_name', 'last_name', 'company_name', 'email', 'phone',
        'address', 'city', 'country', 'segment', 'lifetime_value', 'acquisition_cost',
        'total_orders', 'total_spent', 'satisfaction_score', 'nps_score', 'status'
    ]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    sample_data = [
        ['CUST-001', 'John', 'Doe', 'Acme Corp', 'john.doe@example.com', '+1-555-0101',
         '123 Main St', 'New York', 'USA', 'Enterprise', 50000, 500, 10, 45000, 4.5, 8, 'active'],
        ['CUST-002', 'Jane', 'Smith', 'TechStart Inc', 'jane.smith@example.com', '+1-555-0102',
         '456 Oak Ave', 'San Francisco', 'USA', 'SMB', 15000, 200, 5, 12000, 4.2, 7, 'active'],
        ['CUST-003', 'Ahmed', 'Khan', 'Global Solutions', 'ahmed.khan@example.com', '+91-88888-88888',
         '789 Park Road', 'Bangalore', 'India', 'Enterprise', 80000, 800, 15, 75000, 4.8, 9, 'active']
    ]

    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=value)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='customer_import_template.xlsx')


@business_twin_bp.route('/employees')
@login_required
def employees():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    employees = Employee.query.filter_by(company_id=company_id).options(
        joinedload(Employee.department)
    ).order_by(Employee.created_at.desc()).limit(100).all()
    departments = Department.query.filter_by(company_id=company_id, is_active=True).all()

    all_employees = Employee.query.filter_by(company_id=company_id).all()
    total_db_employees = len(all_employees)
    active_count = len([e for e in all_employees if (e.status or 'active').lower() == 'active'])
    contractor_count = len([e for e in all_employees if 'contract' in (e.status or '').lower()])
    on_leave_count = len([e for e in all_employees if 'leave' in (e.status or '').lower()])
    other_status_count = max(0, total_db_employees - active_count - contractor_count - on_leave_count)

    dept_count = len(set(e.department_id for e in all_employees if e.department_id))
    total_salary = sum(float(e.salary or 0) for e in all_employees)
    avg_salary = (total_salary / total_db_employees) if total_db_employees > 0 else 0.0

    dept_map = {d.id: d.name for d in departments}
    from collections import defaultdict
    dept_counts = defaultdict(lambda: {'count': 0, 'salary_sum': 0.0})
    for e in all_employees:
        d_name = dept_map.get(e.department_id, 'Unassigned')
        dept_counts[d_name]['count'] += 1
        dept_counts[d_name]['salary_sum'] += float(e.salary or 0)

    for d in departments:
        if d.name not in dept_counts:
            dept_counts[d.name] = {'count': 0, 'salary_sum': 0.0}

    dept_stats = []
    for d_name, d_data in dept_counts.items():
        c = d_data['count']
        avg_s = (d_data['salary_sum'] / c) if c > 0 else 0.0
        dept_stats.append({
            'name': d_name,
            'headcount': c,
            'avg_salary': round(avg_s, 2)
        })
    dept_stats.sort(key=lambda x: x['headcount'], reverse=True)

    currency_symbol = _get_currency_symbol(company_id)

    return render_template('business_twin/twin_employees.html', 
                         employees=employees, 
                         departments=departments,
                         dept_map=dept_map,
                         total_db_employees=total_db_employees,
                         active_count=active_count,
                         contractor_count=contractor_count,
                         on_leave_count=on_leave_count,
                         other_status_count=other_status_count,
                         dept_count=dept_count,
                         avg_salary=avg_salary,
                         dept_stats=dept_stats,
                         currency_symbol=currency_symbol,
                         company=company)


@business_twin_bp.route('/employees/add', methods=['POST'])
@login_required
def add_employee():
    company_id = session.get('company_id')

    try:
        dept_id = request.form.get('department_id')

        employee = Employee(
            company_id=company_id,
            employee_id=request.form.get('employee_id', ''),
            first_name=request.form.get('first_name', ''),
            last_name=request.form.get('last_name', ''),
            email=request.form.get('email', ''),
            phone=request.form.get('phone', ''),
            department_id=int(dept_id) if dept_id and dept_id.strip() else None,
            job_title=request.form.get('job_title', ''),
            employment_type=request.form.get('employment_type', 'full_time'),
            salary=float(request.form.get('salary', 0) or 0),
            benefits_cost=float(request.form.get('benefits_cost', 0) or 0),
            hire_date=datetime.strptime(request.form.get('hire_date'), '%Y-%m-%d').date() if request.form.get('hire_date') else None,
            status=request.form.get('status', 'active'),
            performance_rating=float(request.form.get('performance_rating', 0)) if request.form.get('performance_rating') else None
        )

        db.session.add(employee)
        db.session.flush()  # assign employee.id before twin mirroring
        
        # ENTERPRISE INTERCONNECTION: mirror into department twin so the
        # twin network stays real and company metrics recompute.
        _mirror_employee_to_twin(company_id, employee, 'on_create',
                                 user_id=current_user.id if hasattr(current_user, 'id') else None)
        
        db.session.commit()
        
        # Sync department headcount
        if dept_id:
            _sync_dept_headcount(company_id, int(dept_id))

        company = Company.query.get(company_id)
        if company and hasattr(company, 'employee_count'):
            company.employee_count = Employee.query.filter_by(company_id=company_id).count()
            db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.EMPLOYEE_CREATED,
                company_id=company_id,
                aggregate_type='employee',
                aggregate_id=str(employee.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'name': f"{employee.first_name} {employee.last_name}".strip(),
                    'job_title': employee.job_title,
                    'department_id': employee.department_id,
                    'salary': employee.salary
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({'success': True, 'employee': employee.to_dict()})

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/employees/edit/<int:employee_id>', methods=['POST'])
@login_required
def edit_employee(employee_id):
    company_id = session.get('company_id')
    employee = Employee.query.filter_by(id=employee_id, company_id=company_id).first()
    
    if not employee:
        return jsonify({'success': False, 'error': 'Employee not found'}), 404
    
    try:
        old_dept_id = employee.department_id
        
        employee.employee_id = request.form.get('employee_id') or employee.employee_id
        employee.first_name = request.form.get('first_name', employee.first_name or '')
        employee.last_name = request.form.get('last_name', employee.last_name or '')
        employee.email = request.form.get('email', employee.email or '')
        employee.phone = request.form.get('phone', employee.phone or '')
        employee.job_title = request.form.get('job_title', employee.job_title or '')
        
        dept_id = request.form.get('department_id')
        if dept_id and dept_id.strip():
            employee.department_id = int(dept_id)
        else:
            employee.department_id = None
            
        employee.employment_type = request.form.get('employment_type', employee.employment_type or 'full_time')
        employee.salary = float(request.form.get('salary', employee.salary or 0) or 0)
        employee.benefits_cost = float(request.form.get('benefits_cost', employee.benefits_cost or 0) or 0)
        
        hire_date_str = request.form.get('hire_date', '')
        if hire_date_str and hire_date_str.strip():
            employee.hire_date = datetime.strptime(hire_date_str, '%Y-%m-%d').date()
        else:
            employee.hire_date = None
        
        employee.status = request.form.get('status', employee.status or 'active')
        
        rating = request.form.get('performance_rating', '')
        employee.performance_rating = float(rating) if rating and rating.strip() else None
        
        db.session.commit()
        
        # Sync department headcounts
        if old_dept_id:
            _sync_dept_headcount(company_id, old_dept_id)
        if employee.department_id and employee.department_id != old_dept_id:
            _sync_dept_headcount(company_id, employee.department_id)
        
        # ENTERPRISE INTERCONNECTION: mirror update into department twin
        # (salary/status changes re-fire automation rules and recompute
        # company metrics + health score)
        _mirror_employee_to_twin(company_id, employee, 'on_update',
                                 user_id=current_user.id if hasattr(current_user, 'id') else None)
        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.EMPLOYEE_UPDATED,
                company_id=company_id,
                aggregate_type='employee',
                aggregate_id=str(employee.id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={
                    'name': f"{employee.first_name} {employee.last_name}".strip(),
                    'job_title': employee.job_title,
                    'department_id': employee.department_id,
                    'salary': employee.salary
                }
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({'success': True, 'employee': employee.to_dict()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/employees/delete/<int:employee_id>', methods=['DELETE'])
@login_required
def delete_employee(employee_id):
    company_id = session.get('company_id')
    employee = Employee.query.filter_by(id=employee_id, company_id=company_id).first()
    
    if not employee:
        return jsonify({'success': False, 'error': 'Employee not found'}), 404
    
    try:
        emp_name = f"{employee.first_name} {employee.last_name}".strip()
        old_dept_id = employee.department_id
        
        db.session.delete(employee)
        db.session.flush()
        
        # Reverse twin impacts (payroll expense etc.) BEFORE the row is gone
        _mirror_employee_to_twin(company_id, employee, 'on_delete',
                                 user_id=current_user.id if hasattr(current_user, 'id') else None)
        
        db.session.commit()
        
        # Sync department headcount
        if old_dept_id:
            _sync_dept_headcount(company_id, old_dept_id)
        
        # Sync company employee count
        company = Company.query.get(company_id)
        if company and hasattr(company, 'employee_count'):
            company.employee_count = Employee.query.filter_by(company_id=company_id).count()
            db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.EMPLOYEE_DELETED,
                company_id=company_id,
                aggregate_type='employee',
                aggregate_id=str(employee_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': emp_name}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")
        
        return jsonify({'success': True, 'message': 'Employee deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/employees/delete-all', methods=['DELETE'])
@login_required
def delete_all_employees():
    company_id = session.get('company_id')
    try:
        # Collect department IDs before deletion for sync
        dept_ids = set()
        employees = Employee.query.filter_by(company_id=company_id).all()
        for emp in employees:
            if emp.department_id:
                dept_ids.add(emp.department_id)
        
        count = Employee.query.filter_by(company_id=company_id).count()
        Employee.query.filter_by(company_id=company_id).delete()
        db.session.commit()
        
        # Sync all affected departments
        for dept_id in dept_ids:
            _sync_dept_headcount(company_id, dept_id)
        
        company = Company.query.get(company_id)
        if company:
            company.employee_count = 0
            try:
                from services.twin_service import TwinService
                TwinService.recalculate_company_metrics(company_id)
            except Exception:
                pass
            db.session.commit()
        
        return jsonify({'success': True, 'message': f'All {count} employees deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/employees/import-csv', methods=['POST'])
@login_required
def import_employees_csv():
    company_id = session.get('company_id')

    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not file.filename.endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV'}), 400

    try:
        stream = io.StringIO(file.stream.read().decode('UTF-8'), newline=None)
        csv_reader = csv.DictReader(stream)

        added_count = 0
        updated_count = 0
        errors = []
        affected_dept_ids = set()

        depts = {d.name.lower(): d.id for d in Department.query.filter_by(company_id=company_id).all()}

        for row_num, row in enumerate(csv_reader, start=2):
            try:
                first_name = row.get('first_name', '').strip()
                last_name = row.get('last_name', '').strip()

                if not first_name or not last_name:
                    errors.append(f"Row {row_num}: Missing required fields (first_name, last_name)")
                    continue

                email = row.get('email', '').strip()
                existing = Employee.query.filter_by(company_id=company_id, email=email).first() if email else None

                dept_id = None
                dept_name = row.get('department', '').strip()
                if dept_name:
                    dept_id = depts.get(dept_name.lower())

                hire_date = None
                date_str = row.get('hire_date', '').strip()
                if date_str:
                    try:
                        hire_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                    except:
                        try:
                            hire_date = datetime.strptime(date_str, '%m/%d/%Y').date()
                        except:
                            pass

                if existing:
                    old_dept_id = existing.department_id
                    existing.employee_id = row.get('employee_id', '').strip() or existing.employee_id
                    existing.first_name = first_name
                    existing.last_name = last_name
                    existing.email = email
                    existing.phone = row.get('phone', '').strip()
                    existing.job_title = row.get('job_title', '').strip()
                    existing.department_id = dept_id
                    existing.employment_type = row.get('employment_type', 'full_time').strip()
                    existing.salary = float(row.get('salary', 0) or 0)
                    existing.benefits_cost = float(row.get('benefits_cost', 0) or 0)
                    existing.hire_date = hire_date
                    existing.status = row.get('status', 'active').strip()
                    existing.performance_rating = float(row.get('performance_rating', 0)) if row.get('performance_rating') else None
                    updated_count += 1
                    if old_dept_id:
                        affected_dept_ids.add(old_dept_id)
                    if dept_id and dept_id != old_dept_id:
                        affected_dept_ids.add(dept_id)
                else:
                    employee = Employee(
                        company_id=company_id,
                        employee_id=row.get('employee_id', '').strip(),
                        first_name=first_name,
                        last_name=last_name,
                        email=email,
                        phone=row.get('phone', '').strip(),
                        department_id=dept_id,
                        job_title=row.get('job_title', '').strip(),
                        employment_type=row.get('employment_type', 'full_time').strip(),
                        salary=float(row.get('salary', 0) or 0),
                        benefits_cost=float(row.get('benefits_cost', 0) or 0),
                        hire_date=hire_date,
                        status=row.get('status', 'active').strip(),
                        performance_rating=float(row.get('performance_rating', 0)) if row.get('performance_rating') else None
                    )
                    db.session.add(employee)
                    added_count += 1
                    if dept_id:
                        affected_dept_ids.add(dept_id)

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()
        
        for dept_id in affected_dept_ids:
            _sync_dept_headcount(company_id, dept_id)

        company = Company.query.get(company_id)
        if company and hasattr(company, 'employee_count'):
            company.employee_count = Employee.query.filter_by(company_id=company_id).count()
            db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/employees/import-excel', methods=['POST'])
@login_required
def import_employees_excel():
    company_id = session.get('company_id')

    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['excel_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not (file.filename.endswith('.xlsx') or file.filename.endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400

    try:
        from openpyxl import load_workbook

        wb = load_workbook(filename=io.BytesIO(file.read()))
        ws = wb.active

        headers = []
        for cell in ws[1]:
            val = cell.value
            if val:
                h = str(val).strip().lower().replace(' ', '_').replace('-', '_')
                headers.append(h)
            else:
                headers.append('')

        header_map = {}
        for idx, h in enumerate(headers):
            if h in ['first_name', 'firstname', 'first']:
                header_map['first_name'] = idx
            elif h in ['last_name', 'lastname', 'last']:
                header_map['last_name'] = idx
            elif h in ['email', 'email_address', 'e_mail']:
                header_map['email'] = idx
            elif h in ['phone', 'phone_number', 'telephone', 'mobile']:
                header_map['phone'] = idx
            elif h in ['employee_id', 'emp_id', 'id', 'employee_code']:
                header_map['employee_id'] = idx
            elif h in ['job_title', 'title', 'position', 'role']:
                header_map['job_title'] = idx
            elif h in ['department', 'dept', 'department_name', 'dept_name']:
                header_map['department'] = idx
            elif h in ['employment_type', 'type', 'emp_type']:
                header_map['employment_type'] = idx
            elif h in ['salary', 'annual_salary', 'base_salary']:
                header_map['salary'] = idx
            elif h in ['benefits_cost', 'benefits', 'benefit_cost']:
                header_map['benefits_cost'] = idx
            elif h in ['hire_date', 'date_hired', 'start_date']:
                header_map['hire_date'] = idx
            elif h in ['status', 'state', 'employee_status']:
                header_map['status'] = idx
            elif h in ['performance_rating', 'rating', 'performance', 'score']:
                header_map['performance_rating'] = idx

        if 'first_name' not in header_map or 'last_name' not in header_map:
            return jsonify({'success': False, 'error': 'Excel file must have columns: first_name, last_name'}), 400

        depts = {d.name.lower(): d.id for d in Department.query.filter_by(company_id=company_id).all()}

        added_count = 0
        updated_count = 0
        errors = []
        affected_dept_ids = set()

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            try:
                first_name_idx = header_map.get('first_name', 0)
                last_name_idx = header_map.get('last_name', 1)

                first_name = str(row[first_name_idx] if first_name_idx < len(row) else '').strip()
                last_name = str(row[last_name_idx] if last_name_idx < len(row) else '').strip()

                if not first_name or not last_name:
                    errors.append(f"Row {row_num}: Missing required fields (first_name, last_name)")
                    continue

                def get_val(key, default=''):
                    idx = header_map.get(key)
                    if idx is not None and idx < len(row):
                        val = row[idx]
                        return str(val).strip() if val is not None else default
                    return default

                def get_float_val(key, default=0.0):
                    idx = header_map.get(key)
                    if idx is not None and idx < len(row):
                        val = row[idx]
                        if val is not None:
                            try:
                                return float(val)
                            except (ValueError, TypeError):
                                return default
                    return default

                email = get_val('email')
                existing = Employee.query.filter_by(company_id=company_id, email=email).first() if email else None

                dept_id = None
                dept_name = get_val('department')
                if dept_name:
                    dept_id = depts.get(dept_name.lower())
                    if not dept_id:
                        for d_name, d_id in depts.items():
                            if dept_name.lower() in d_name or d_name in dept_name.lower():
                                dept_id = d_id
                                break

                hire_date = None
                hire_idx = header_map.get('hire_date')
                if hire_idx is not None and hire_idx < len(row) and row[hire_idx]:
                    date_val = row[hire_idx]
                    if isinstance(date_val, datetime):
                        hire_date = date_val.date()
                    elif isinstance(date_val, date):
                        hire_date = date_val
                    else:
                        date_str = str(date_val).strip()
                        for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                            try:
                                hire_date = datetime.strptime(date_str, fmt).date()
                                break
                            except:
                                continue

                rating_val = get_val('performance_rating')
                performance_rating = None
                if rating_val:
                    try:
                        performance_rating = float(rating_val)
                    except:
                        pass

                if existing:
                    old_dept_id = existing.department_id
                    existing.employee_id = get_val('employee_id') or existing.employee_id
                    existing.first_name = first_name
                    existing.last_name = last_name
                    existing.email = email
                    existing.phone = get_val('phone')
                    existing.department_id = dept_id
                    existing.job_title = get_val('job_title')
                    existing.employment_type = get_val('employment_type', 'full_time')
                    existing.salary = get_float_val('salary')
                    existing.benefits_cost = get_float_val('benefits_cost')
                    existing.hire_date = hire_date
                    existing.status = get_val('status', 'active')
                    existing.performance_rating = performance_rating
                    updated_count += 1
                    if old_dept_id:
                        affected_dept_ids.add(old_dept_id)
                    if dept_id and dept_id != old_dept_id:
                        affected_dept_ids.add(dept_id)
                else:
                    employee = Employee(
                        company_id=company_id,
                        employee_id=get_val('employee_id'),
                        first_name=first_name,
                        last_name=last_name,
                        email=email,
                        phone=get_val('phone'),
                        department_id=dept_id,
                        job_title=get_val('job_title'),
                        employment_type=get_val('employment_type', 'full_time'),
                        salary=get_float_val('salary'),
                        benefits_cost=get_float_val('benefits_cost'),
                        hire_date=hire_date,
                        status=get_val('status', 'active'),
                        performance_rating=performance_rating
                    )
                    db.session.add(employee)
                    added_count += 1
                    if dept_id:
                        affected_dept_ids.add(dept_id)

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()
        
        for dept_id in affected_dept_ids:
            _sync_dept_headcount(company_id, dept_id)

        company = Company.query.get(company_id)
        if company and hasattr(company, 'employee_count'):
            company.employee_count = Employee.query.filter_by(company_id=company_id).count()
            db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/employees/export-excel')
@login_required
def export_employees_excel():
    company_id = session.get('company_id')
    employees = Employee.query.filter_by(company_id=company_id).order_by(Employee.created_at.desc()).all()
    departments = Department.query.filter_by(company_id=company_id).all()
    dept_map = {d.id: d.name for d in departments}

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Employees"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'Employee ID', 'First Name', 'Last Name', 'Email', 'Phone', 
               'Department', 'Job Title', 'Employment Type', 'Salary', 'Benefits Cost', 
               'Total Cost', 'Hire Date', 'Status', 'Performance Rating', 'Created At']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    for row_num, emp in enumerate(employees, 2):
        ws.cell(row=row_num, column=1, value=emp.id)
        ws.cell(row=row_num, column=2, value=emp.employee_id)
        ws.cell(row=row_num, column=3, value=emp.first_name)
        ws.cell(row=row_num, column=4, value=emp.last_name)
        ws.cell(row=row_num, column=5, value=emp.email)
        ws.cell(row=row_num, column=6, value=emp.phone)
        ws.cell(row=row_num, column=7, value=dept_map.get(emp.department_id, 'Unassigned'))
        ws.cell(row=row_num, column=8, value=emp.job_title)
        ws.cell(row=row_num, column=9, value=emp.employment_type)
        ws.cell(row=row_num, column=10, value=emp.salary)
        ws.cell(row=row_num, column=11, value=emp.benefits_cost)
        ws.cell(row=row_num, column=12, value=emp.total_cost())
        ws.cell(row=row_num, column=13, value=emp.hire_date.strftime('%Y-%m-%d') if emp.hire_date else '')
        ws.cell(row=row_num, column=14, value=emp.status)
        ws.cell(row=row_num, column=15, value=emp.performance_rating)
        ws.cell(row=row_num, column=16, value=emp.created_at.strftime('%Y-%m-%d %H:%M:%S') if emp.created_at else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='employees_export.xlsx')


@business_twin_bp.route('/employees/export-pdf')
@login_required
def export_employees_pdf():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    employees = Employee.query.filter_by(company_id=company_id).order_by(Employee.created_at.desc()).all()
    departments = Department.query.filter_by(company_id=company_id).all()
    dept_map = {d.id: d.name for d in departments}

    symbol = _get_currency_symbol(company_id)

    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)

    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a1f3a'), spaceAfter=20, alignment=TA_CENTER)
    elements.append(Paragraph(f"{company.company_name if company else 'Company'} - Employee Report", title_style))
    elements.append(Spacer(1, 0.2*inch))

    summary_style = ParagraphStyle('Summary', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'), spaceAfter=15)
    elements.append(Paragraph(f"Total Employees: {len(employees)} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}", summary_style))
    elements.append(Spacer(1, 0.1*inch))

    table_data = [['Name', 'Email', 'Department', 'Job Title', 'Salary', 'Status', 'Rating']]
    for e in employees:
        table_data.append([
            e.full_name() or '-',
            e.email or '-',
            dept_map.get(e.department_id, 'Unassigned'),
            e.job_title or '-',
            f"{symbol}{e.salary:,.0f}" if e.salary else f'{symbol}0',
            e.status.title(),
            str(e.performance_rating) if e.performance_rating else '-'
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1f3a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f8f9fa')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dee2e6')),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 0), (1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8f9fa')])
    ]))

    elements.append(table)
    doc.build(elements)
    output.seek(0)

    return send_file(output, mimetype='application/pdf',
                     as_attachment=True, download_name='employees_report.pdf')


@business_twin_bp.route('/employees/download-template')
@login_required
def download_employee_csv_template():
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'first_name', 'last_name', 'email', 'phone', 'employee_id', 'job_title',
        'department', 'employment_type', 'salary', 'benefits_cost', 'hire_date', 'status', 'performance_rating'
    ])

    writer.writerow([
        'John', 'Doe', 'john.doe@company.com', '+1-555-0101', 'EMP-001',
        'Software Engineer', 'IT', 'full_time', '85000', '12000', '2024-01-15', 'active', '4.5'
    ])
    writer.writerow([
        'Jane', 'Smith', 'jane.smith@company.com', '+1-555-0102', 'EMP-002',
        'Marketing Manager', 'Marketing', 'full_time', '75000', '10000', '2023-08-20', 'active', '4.2'
    ])
    writer.writerow([
        'Ahmed', 'Khan', 'ahmed.khan@company.com', '+91-88888-88888', 'EMP-003',
        'Sales Lead', 'Sales', 'full_time', '95000', '15000', '2022-05-10', 'active', '4.8'
    ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv',
                     as_attachment=True, download_name='employee_import_template.csv')


@business_twin_bp.route('/employees/download-excel-template')
@login_required
def download_employee_excel_template():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Employees"

    headers = [
        'first_name', 'last_name', 'email', 'phone', 'employee_id', 'job_title',
        'department', 'employment_type', 'salary', 'benefits_cost', 'hire_date', 'status', 'performance_rating'
    ]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    sample_data = [
        ['John', 'Doe', 'john.doe@company.com', '+1-555-0101', 'EMP-001',
         'Software Engineer', 'IT', 'full_time', 85000, 12000, '2024-01-15', 'active', 4.5],
        ['Jane', 'Smith', 'jane.smith@company.com', '+1-555-0102', 'EMP-002',
         'Marketing Manager', 'Marketing', 'full_time', 75000, 10000, '2023-08-20', 'active', 4.2],
        ['Ahmed', 'Khan', 'ahmed.khan@company.com', '+91-88888-88888', 'EMP-003',
         'Sales Lead', 'Sales', 'full_time', 95000, 15000, '2022-05-10', 'active', 4.8]
    ]

    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=value)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='employee_import_template.xlsx')


@business_twin_bp.route('/suppliers')
@login_required
def suppliers():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    suppliers = Supplier.query.filter_by(company_id=company_id).order_by(Supplier.created_at.desc()).all()

    total_db_suppliers = len(suppliers)
    active_count = len([s for s in suppliers if (s.status or 'active').lower() == 'active'])
    primary_count = len([s for s in suppliers if s.is_primary])
    secondary_count = max(0, total_db_suppliers - primary_count)

    rated_suppliers = [s for s in suppliers if (s.rating or 0) > 0]
    avg_rating = sum(float(s.rating) for s in rated_suppliers) / len(rated_suppliers) if rated_suppliers else 0.0
    total_spend = sum(float(s.total_spend or 0) for s in suppliers)

    # Real top suppliers by spend
    top_by_spend = sorted(suppliers, key=lambda s: float(s.total_spend or 0), reverse=True)[:8]
    supplier_rankings = []
    for s in top_by_spend:
        name = s.supplier_name if hasattr(s, 'supplier_name') and s.supplier_name else getattr(s, 'name', 'Vendor')
        supplier_rankings.append({
            'name': name,
            'spend': float(s.total_spend or 0),
            'rating': float(s.rating or 0)
        })

    return render_template('business_twin/twin_suppliers.html', 
                         suppliers=suppliers,
                         total_db_suppliers=total_db_suppliers,
                         active_count=active_count,
                         primary_count=primary_count,
                         secondary_count=secondary_count,
                         avg_rating=avg_rating,
                         total_spend=total_spend,
                         supplier_rankings=supplier_rankings,
                         company=company,
                         currency_symbol=_get_currency_symbol(company_id))


@business_twin_bp.route('/suppliers/<int:supplier_id>/json')
@login_required
def get_supplier_json(supplier_id):
    """Fresh supplier data as JSON for edit-modal prefill (fetched by ID so the
    template never has to embed JSON payloads inside HTML attributes)."""
    company_id = session.get('company_id')
    supplier = Supplier.query.filter_by(id=supplier_id, company_id=company_id).first()
    if not supplier:
        return jsonify({'success': False, 'error': 'Supplier not found'}), 404
    return jsonify({'success': True, 'supplier': supplier.to_dict()})


@business_twin_bp.route('/inventory/<int:item_id>/json')
@login_required
def get_inventory_json(item_id):
    """Fresh inventory item data as JSON for edit-modal prefill."""
    company_id = session.get('company_id')
    item = Inventory.query.filter_by(id=item_id, company_id=company_id).first()
    if not item:
        return jsonify({'success': False, 'error': 'Inventory item not found'}), 404
    return jsonify({'success': True, 'item': item.to_dict()})


@business_twin_bp.route('/suppliers/add', methods=['POST'])
@login_required
def add_supplier():
    company_id = session.get('company_id')

    try:
        supplier = Supplier(
            company_id=company_id,
            name=request.form.get('name', ''),
            contact_person=request.form.get('contact_person', ''),
            email=request.form.get('email', ''),
            phone=request.form.get('phone', ''),
            address=request.form.get('address', ''),
            city=request.form.get('city', ''),
            country=request.form.get('country', ''),
            category=request.form.get('category', 'General'),
            payment_terms=request.form.get('payment_terms', ''),
            lead_time_days=int(request.form.get('lead_time_days', 0) or 0),
            rating=float(request.form.get('rating', 0)) if request.form.get('rating') else None,
            quality_score=float(request.form.get('quality_score', 0)) if request.form.get('quality_score') else None,
            reliability_score=float(request.form.get('reliability_score', 0)) if request.form.get('reliability_score') else None,
            cost_rating=float(request.form.get('cost_rating', 0)) if request.form.get('cost_rating') else None,
            total_spend=float(request.form.get('total_spend', 0) or 0),
            total_orders=int(request.form.get('total_orders', 0) or 0),
            is_primary=request.form.get('is_primary') == 'true',
            status=request.form.get('status', 'active'),
            contract_start=datetime.strptime(request.form.get('contract_start'), '%Y-%m-%d').date() if request.form.get('contract_start') else None,
            contract_end=datetime.strptime(request.form.get('contract_end'), '%Y-%m-%d').date() if request.form.get('contract_end') else None
        )

        db.session.add(supplier)
        db.session.commit()

        return jsonify({'success': True, 'supplier': supplier.to_dict()})

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/suppliers/edit/<int:supplier_id>', methods=['POST'])
@login_required
def edit_supplier(supplier_id):
    company_id = session.get('company_id')
    supplier = Supplier.query.filter_by(id=supplier_id, company_id=company_id).first()
    if not supplier:
        return jsonify({'success': False, 'error': 'Supplier not found'}), 404

    try:
        supplier.name = request.form.get('name', supplier.name)
        supplier.contact_person = request.form.get('contact_person', supplier.contact_person or '')
        supplier.email = request.form.get('email', supplier.email or '')
        supplier.phone = request.form.get('phone', supplier.phone or '')
        supplier.address = request.form.get('address', supplier.address or '')
        supplier.city = request.form.get('city', supplier.city or '')
        supplier.country = request.form.get('country', supplier.country or '')
        supplier.category = request.form.get('category', supplier.category or 'General')
        supplier.payment_terms = request.form.get('payment_terms', supplier.payment_terms or '')
        supplier.lead_time_days = int(request.form.get('lead_time_days', supplier.lead_time_days or 0) or 0)
        supplier.rating = float(request.form.get('rating', supplier.rating or 0)) if request.form.get('rating') else supplier.rating
        supplier.quality_score = float(request.form.get('quality_score', supplier.quality_score or 0)) if request.form.get('quality_score') else supplier.quality_score
        supplier.reliability_score = float(request.form.get('reliability_score', supplier.reliability_score or 0)) if request.form.get('reliability_score') else supplier.reliability_score
        supplier.cost_rating = float(request.form.get('cost_rating', supplier.cost_rating or 0)) if request.form.get('cost_rating') else supplier.cost_rating
        supplier.total_spend = float(request.form.get('total_spend', supplier.total_spend or 0) or 0)
        supplier.total_orders = int(request.form.get('total_orders', supplier.total_orders or 0) or 0)
        supplier.is_primary = request.form.get('is_primary') == 'true'
        supplier.status = request.form.get('status', supplier.status or 'active')

        contract_start = request.form.get('contract_start')
        if contract_start and contract_start.strip():
            supplier.contract_start = datetime.strptime(contract_start, '%Y-%m-%d').date()
        else:
            supplier.contract_start = None

        contract_end = request.form.get('contract_end')
        if contract_end and contract_end.strip():
            supplier.contract_end = datetime.strptime(contract_end, '%Y-%m-%d').date()
        else:
            supplier.contract_end = None

        db.session.commit()
        return jsonify({'success': True, 'supplier': supplier.to_dict()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/suppliers/delete/<int:supplier_id>', methods=['DELETE'])
@login_required
def delete_supplier(supplier_id):
    company_id = session.get('company_id')
    supplier = Supplier.query.filter_by(id=supplier_id, company_id=company_id).first()
    if not supplier:
        return jsonify({'success': False, 'error': 'Supplier not found'}), 404

    try:
        db.session.delete(supplier)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Supplier deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/suppliers/delete-all', methods=['DELETE'])
@login_required
def delete_all_suppliers():
    company_id = session.get('company_id')
    try:
        count = Supplier.query.filter_by(company_id=company_id).count()
        Supplier.query.filter_by(company_id=company_id).delete()
        db.session.commit()
        return jsonify({
            'success': True,
            'message': f'All {count} supplier records deleted successfully'
        })
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/suppliers/import-csv', methods=['POST'])
@login_required
def import_suppliers_csv():
    company_id = session.get('company_id')

    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not file.filename.endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV'}), 400

    try:
        stream = io.StringIO(file.stream.read().decode('UTF-8'), newline=None)
        csv_reader = csv.DictReader(stream)

        added_count = 0
        updated_count = 0
        errors = []

        def parse_date(date_str):
            if not date_str or not date_str.strip():
                return None
            for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                try:
                    return datetime.strptime(date_str.strip(), fmt).date()
                except:
                    continue
            return None

        for row_num, row in enumerate(csv_reader, start=2):
            try:
                name = row.get('name', '').strip()
                if not name:
                    errors.append(f"Row {row_num}: Missing required field (name)")
                    continue

                email = row.get('email', '').strip()

                # Upsert logic: match by email if present, otherwise by name
                existing = None
                if email:
                    existing = Supplier.query.filter_by(company_id=company_id, email=email).first()
                if not existing and name:
                    existing = Supplier.query.filter_by(company_id=company_id, name=name).first()

                if existing:
                    existing.name = name
                    if row.get('contact_person') and row['contact_person'].strip():
                        existing.contact_person = row['contact_person'].strip()
                    if email:
                        existing.email = email
                    if row.get('phone') and row['phone'].strip():
                        existing.phone = row['phone'].strip()
                    if row.get('address') and row['address'].strip():
                        existing.address = row['address'].strip()
                    if row.get('city') and row['city'].strip():
                        existing.city = row['city'].strip()
                    if row.get('country') and row['country'].strip():
                        existing.country = row['country'].strip()
                    if row.get('category') and row['category'].strip():
                        existing.category = row['category'].strip()
                    if row.get('payment_terms') and row['payment_terms'].strip():
                        existing.payment_terms = row['payment_terms'].strip()
                    if row.get('lead_time_days') and row['lead_time_days'].strip():
                        existing.lead_time_days = int(row['lead_time_days'].strip() or 0)
                    if row.get('rating') and row['rating'].strip():
                        existing.rating = float(row['rating'].strip())
                    if row.get('quality_score') and row['quality_score'].strip():
                        existing.quality_score = float(row['quality_score'].strip())
                    if row.get('reliability_score') and row['reliability_score'].strip():
                        existing.reliability_score = float(row['reliability_score'].strip())
                    if row.get('cost_rating') and row['cost_rating'].strip():
                        existing.cost_rating = float(row['cost_rating'].strip())
                    if row.get('total_spend') and row['total_spend'].strip():
                        existing.total_spend = float(row['total_spend'].strip() or 0)
                    if row.get('total_orders') and row['total_orders'].strip():
                        existing.total_orders = int(row['total_orders'].strip() or 0)
                    if row.get('is_primary') and row['is_primary'].strip():
                        existing.is_primary = row['is_primary'].strip().lower() in ['yes', 'true', '1', 'on']
                    if row.get('status') and row['status'].strip():
                        existing.status = row['status'].strip()
                    if row.get('contract_start') and row['contract_start'].strip():
                        existing.contract_start = parse_date(row['contract_start'].strip())
                    if row.get('contract_end') and row['contract_end'].strip():
                        existing.contract_end = parse_date(row['contract_end'].strip())
                    updated_count += 1
                else:
                    supplier = Supplier(
                        company_id=company_id,
                        name=name,
                        contact_person=row.get('contact_person', '').strip(),
                        email=email,
                        phone=row.get('phone', '').strip(),
                        address=row.get('address', '').strip(),
                        city=row.get('city', '').strip(),
                        country=row.get('country', '').strip(),
                        category=row.get('category', 'General').strip(),
                        payment_terms=row.get('payment_terms', '').strip(),
                        lead_time_days=int(row.get('lead_time_days', 0) or 0),
                        rating=float(row.get('rating', 0)) if row.get('rating') else None,
                        quality_score=float(row.get('quality_score', 0)) if row.get('quality_score') else None,
                        reliability_score=float(row.get('reliability_score', 0)) if row.get('reliability_score') else None,
                        cost_rating=float(row.get('cost_rating', 0)) if row.get('cost_rating') else None,
                        total_spend=float(row.get('total_spend', 0) or 0),
                        total_orders=int(row.get('total_orders', 0) or 0),
                        is_primary=row.get('is_primary', '').strip().lower() in ['yes', 'true', '1', 'on'],
                        status=row.get('status', 'active').strip(),
                        contract_start=parse_date(row.get('contract_start', '')),
                        contract_end=parse_date(row.get('contract_end', ''))
                    )
                    db.session.add(supplier)
                    added_count += 1

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/suppliers/import-excel', methods=['POST'])
@login_required
def import_suppliers_excel():
    company_id = session.get('company_id')

    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['excel_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not (file.filename.endswith('.xlsx') or file.filename.endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400

    try:
        from openpyxl import load_workbook

        wb = load_workbook(filename=io.BytesIO(file.read()))
        ws = wb.active

        headers = []
        for cell in ws[1]:
            val = cell.value
            if val:
                h = str(val).strip().lower().replace(' ', '_').replace('-', '_')
                headers.append(h)
            else:
                headers.append('')

        header_map = {}
        for idx, h in enumerate(headers):
            if h in ['name', 'supplier_name', 'company_name', 'vendor_name']:
                header_map['name'] = idx
            elif h in ['contact_person', 'contact', 'representative']:
                header_map['contact_person'] = idx
            elif h in ['email', 'email_address', 'e_mail']:
                header_map['email'] = idx
            elif h in ['phone', 'phone_number', 'telephone', 'mobile']:
                header_map['phone'] = idx
            elif h in ['address', 'street', 'street_address']:
                header_map['address'] = idx
            elif h in ['city', 'town']:
                header_map['city'] = idx
            elif h in ['country', 'nation', 'region']:
                header_map['country'] = idx
            elif h in ['category', 'type', 'supplier_category']:
                header_map['category'] = idx
            elif h in ['payment_terms', 'terms', 'payment']:
                header_map['payment_terms'] = idx
            elif h in ['lead_time_days', 'lead_time', 'delivery_days']:
                header_map['lead_time_days'] = idx
            elif h in ['rating', 'score', 'supplier_rating']:
                header_map['rating'] = idx
            elif h in ['quality_score', 'quality']:
                header_map['quality_score'] = idx
            elif h in ['reliability_score', 'reliability']:
                header_map['reliability_score'] = idx
            elif h in ['cost_rating', 'cost_score']:
                header_map['cost_rating'] = idx
            elif h in ['total_spend', 'spend', 'total_spent']:
                header_map['total_spend'] = idx
            elif h in ['total_orders', 'orders', 'order_count']:
                header_map['total_orders'] = idx
            elif h in ['is_primary', 'primary', 'is_primary_supplier']:
                header_map['is_primary'] = idx
            elif h in ['status', 'state', 'supplier_status']:
                header_map['status'] = idx
            elif h in ['contract_start', 'start_date', 'contract_start_date']:
                header_map['contract_start'] = idx
            elif h in ['contract_end', 'end_date', 'contract_end_date']:
                header_map['contract_end'] = idx

        if 'name' not in header_map:
            return jsonify({'success': False, 'error': 'Excel file must have a name column'}), 400

        added_count = 0
        updated_count = 0
        errors = []

        def parse_excel_date(date_val):
            if date_val is None:
                return None
            if isinstance(date_val, datetime):
                return date_val.date()
            elif isinstance(date_val, date):
                return date_val
            else:
                date_str = str(date_val).strip()
                for fmt in ['%Y-%m-%d', '%m/%d/%Y', '%d/%m/%Y']:
                    try:
                        return datetime.strptime(date_str, fmt).date()
                    except:
                        continue
                return None

        def get_str_val(row, key, default=''):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                return str(val).strip() if val is not None else default
            return default

        def get_float_val(row, key, default=None):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                if val is not None:
                    try:
                        return float(val)
                    except (ValueError, TypeError):
                        return default
            return default

        def get_int_val(row, key, default=0):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                if val is not None:
                    try:
                        return int(float(val))
                    except (ValueError, TypeError):
                        return default
            return default

        def get_bool_val(row, key):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                if val is not None:
                    return str(val).strip().lower() in ['yes', 'true', '1', 'on']
            return False

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            try:
                name_idx = header_map.get('name', 0)
                name = str(row[name_idx] if name_idx < len(row) else '').strip()

                if not name:
                    errors.append(f"Row {row_num}: Missing required field (name)")
                    continue

                email = get_str_val(row, 'email')
                
                # Upsert logic: match by email if present, otherwise by name
                existing = None
                if email:
                    existing = Supplier.query.filter_by(company_id=company_id, email=email).first()
                if not existing and name:
                    existing = Supplier.query.filter_by(company_id=company_id, name=name).first()

                if existing:
                    existing.name = name
                    existing.contact_person = get_str_val(row, 'contact_person') or existing.contact_person
                    existing.email = email or existing.email
                    existing.phone = get_str_val(row, 'phone') or existing.phone
                    existing.address = get_str_val(row, 'address') or existing.address
                    existing.city = get_str_val(row, 'city') or existing.city
                    existing.country = get_str_val(row, 'country') or existing.country
                    existing.category = get_str_val(row, 'category', 'General') or existing.category
                    existing.payment_terms = get_str_val(row, 'payment_terms') or existing.payment_terms
                    existing.lead_time_days = get_int_val(row, 'lead_time_days') or existing.lead_time_days
                    existing.rating = get_float_val(row, 'rating') if header_map.get('rating') is not None and header_map.get('rating') < len(row) and row[header_map.get('rating')] is not None else existing.rating
                    existing.quality_score = get_float_val(row, 'quality_score') if header_map.get('quality_score') is not None and header_map.get('quality_score') < len(row) and row[header_map.get('quality_score')] is not None else existing.quality_score
                    existing.reliability_score = get_float_val(row, 'reliability_score') if header_map.get('reliability_score') is not None and header_map.get('reliability_score') < len(row) and row[header_map.get('reliability_score')] is not None else existing.reliability_score
                    existing.cost_rating = get_float_val(row, 'cost_rating') if header_map.get('cost_rating') is not None and header_map.get('cost_rating') < len(row) and row[header_map.get('cost_rating')] is not None else existing.cost_rating
                    existing.total_spend = get_float_val(row, 'total_spend', 0.0) or existing.total_spend
                    existing.total_orders = get_int_val(row, 'total_orders') or existing.total_orders
                    existing.is_primary = get_bool_val(row, 'is_primary')
                    existing.status = get_str_val(row, 'status', 'active') or existing.status
                    existing.contract_start = parse_excel_date(row[header_map.get('contract_start')] if header_map.get('contract_start') is not None and header_map.get('contract_start') < len(row) else None) or existing.contract_start
                    existing.contract_end = parse_excel_date(row[header_map.get('contract_end')] if header_map.get('contract_end') is not None and header_map.get('contract_end') < len(row) else None) or existing.contract_end
                    updated_count += 1
                else:
                    supplier = Supplier(
                        company_id=company_id,
                        name=name,
                        contact_person=get_str_val(row, 'contact_person'),
                        email=email,
                        phone=get_str_val(row, 'phone'),
                        address=get_str_val(row, 'address'),
                        city=get_str_val(row, 'city'),
                        country=get_str_val(row, 'country'),
                        category=get_str_val(row, 'category', 'General'),
                        payment_terms=get_str_val(row, 'payment_terms'),
                        lead_time_days=get_int_val(row, 'lead_time_days'),
                        rating=get_float_val(row, 'rating'),
                        quality_score=get_float_val(row, 'quality_score'),
                        reliability_score=get_float_val(row, 'reliability_score'),
                        cost_rating=get_float_val(row, 'cost_rating'),
                        total_spend=get_float_val(row, 'total_spend', 0.0),
                        total_orders=get_int_val(row, 'total_orders'),
                        is_primary=get_bool_val(row, 'is_primary'),
                        status=get_str_val(row, 'status', 'active'),
                        contract_start=parse_excel_date(row[header_map.get('contract_start')] if header_map.get('contract_start') is not None and header_map.get('contract_start') < len(row) else None),
                        contract_end=parse_excel_date(row[header_map.get('contract_end')] if header_map.get('contract_end') is not None and header_map.get('contract_end') < len(row) else None)
                    )
                    db.session.add(supplier)
                    added_count += 1

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500

@business_twin_bp.route('/suppliers/export-excel')
@login_required
def export_suppliers_excel():
    company_id = session.get('company_id')
    suppliers = Supplier.query.filter_by(company_id=company_id).order_by(Supplier.created_at.desc()).all()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Suppliers"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'Name', 'Contact Person', 'Email', 'Phone', 'Address', 'City', 'Country',
               'Category', 'Payment Terms', 'Lead Time (days)', 'Rating', 'Quality Score',
               'Reliability Score', 'Cost Rating', 'Total Spend', 'Total Orders', 'Primary',
               'Status', 'Contract Start', 'Contract End', 'Created At']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    for row_num, s in enumerate(suppliers, 2):
        ws.cell(row=row_num, column=1, value=s.id)
        ws.cell(row=row_num, column=2, value=s.name)
        ws.cell(row=row_num, column=3, value=s.contact_person)
        ws.cell(row=row_num, column=4, value=s.email)
        ws.cell(row=row_num, column=5, value=s.phone)
        ws.cell(row=row_num, column=6, value=s.address)
        ws.cell(row=row_num, column=7, value=s.city)
        ws.cell(row=row_num, column=8, value=s.country)
        ws.cell(row=row_num, column=9, value=s.category)
        ws.cell(row=row_num, column=10, value=s.payment_terms)
        ws.cell(row=row_num, column=11, value=s.lead_time_days)
        ws.cell(row=row_num, column=12, value=s.rating)
        ws.cell(row=row_num, column=13, value=s.quality_score)
        ws.cell(row=row_num, column=14, value=s.reliability_score)
        ws.cell(row=row_num, column=15, value=s.cost_rating)
        ws.cell(row=row_num, column=16, value=s.total_spend)
        ws.cell(row=row_num, column=17, value=s.total_orders)
        ws.cell(row=row_num, column=18, value='Yes' if s.is_primary else 'No')
        ws.cell(row=row_num, column=19, value=s.status)
        ws.cell(row=row_num, column=20, value=s.contract_start.strftime('%Y-%m-%d') if s.contract_start else '')
        ws.cell(row=row_num, column=21, value=s.contract_end.strftime('%Y-%m-%d') if s.contract_end else '')
        ws.cell(row=row_num, column=22, value=s.created_at.strftime('%Y-%m-%d %H:%M:%S') if s.created_at else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='suppliers_export.xlsx')


@business_twin_bp.route('/suppliers/export-pdf')
@login_required
def export_suppliers_pdf():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    suppliers = Supplier.query.filter_by(company_id=company_id).order_by(Supplier.created_at.desc()).all()

    symbol = _get_currency_symbol(company_id)

    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)

    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a1f3a'), spaceAfter=20, alignment=TA_CENTER)
    elements.append(Paragraph(f"{company.company_name if company else 'Company'} - Supplier Report", title_style))
    elements.append(Spacer(1, 0.2*inch))

    summary_style = ParagraphStyle('Summary', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'), spaceAfter=15)
    elements.append(Paragraph(f"Total Suppliers: {len(suppliers)} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}", summary_style))
    elements.append(Spacer(1, 0.1*inch))

    table_data = [['Name', 'Category', 'Lead Time', 'Rating', 'Total Spend', 'Type', 'Status']]
    for s in suppliers:
        table_data.append([
            s.name or '-',
            s.category or 'General',
            f"{s.lead_time_days} days" if s.lead_time_days else '-',
            str(s.rating) if s.rating else '-',
            f"{symbol}{s.total_spend:,.0f}" if s.total_spend else f'{symbol}0',
            'Primary' if s.is_primary else 'Secondary',
            s.status.title()
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1f3a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f8f9fa')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dee2e6')),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 0), (0, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8f9fa')])
    ]))

    elements.append(table)
    doc.build(elements)
    output.seek(0)

    return send_file(output, mimetype='application/pdf',
                     as_attachment=True, download_name='suppliers_report.pdf')


@business_twin_bp.route('/suppliers/download-template')
@login_required
def download_supplier_csv_template():
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'name', 'contact_person', 'email', 'phone', 'address', 'city', 'country',
        'category', 'payment_terms', 'lead_time_days', 'rating', 'quality_score',
        'reliability_score', 'cost_rating', 'total_spend', 'total_orders',
        'is_primary', 'status', 'contract_start', 'contract_end'
    ])

    writer.writerow([
        'TechComponents Ltd', 'Ravi Menon', 'ravi@techcomponents.com', '+91-80-1234-5678',
        '42 Electronics Park, Whitefield', 'Bangalore', 'India', 'Hardware', 'Net 30',
        7, 4.5, 4.2, 4.8, 3.5, 450000, 120, 'Yes', 'active', '2024-01-01', '2026-12-31'
    ])
    writer.writerow([
        'CloudNine Services', 'Sarah Johnson', 'sarah@cloudnine.io', '+1-415-555-0199',
        '500 Cloud Way, Suite 300', 'San Francisco', 'USA', 'IT Services', 'Net 15',
        3, 4.8, 4.5, 4.9, 4.0, 320000, 48, 'Yes', 'active', '2023-06-01', '2025-05-31'
    ])
    writer.writerow([
        'Global Logistics Partners', 'Hassan Al-Rashid', 'hassan@glp.com', '+971-4-555-0123',
        'Jebel Ali Free Zone', 'Dubai', 'UAE', 'Logistics', 'Net 45',
        14, 3.9, 3.5, 4.2, 3.0, 180000, 85, 'No', 'active', '2024-03-15', '2025-03-14'
    ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv',
                     as_attachment=True, download_name='supplier_import_template.csv')


@business_twin_bp.route('/suppliers/download-excel-template')
@login_required
def download_supplier_excel_template():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Suppliers"

    headers = [
        'name', 'contact_person', 'email', 'phone', 'address', 'city', 'country',
        'category', 'payment_terms', 'lead_time_days', 'rating', 'quality_score',
        'reliability_score', 'cost_rating', 'total_spend', 'total_orders',
        'is_primary', 'status', 'contract_start', 'contract_end'
    ]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    sample_data = [
        ['TechComponents Ltd', 'Ravi Menon', 'ravi@techcomponents.com', '+91-80-1234-5678',
         '42 Electronics Park, Whitefield', 'Bangalore', 'India', 'Hardware', 'Net 30',
         7, 4.5, 4.2, 4.8, 3.5, 450000, 120, 'Yes', 'active', '2024-01-01', '2026-12-31'],
        ['CloudNine Services', 'Sarah Johnson', 'sarah@cloudnine.io', '+1-415-555-0199',
         '500 Cloud Way, Suite 300', 'San Francisco', 'USA', 'IT Services', 'Net 15',
         3, 4.8, 4.5, 4.9, 4.0, 320000, 48, 'Yes', 'active', '2023-06-01', '2025-05-31'],
        ['Global Logistics Partners', 'Hassan Al-Rashid', 'hassan@glp.com', '+971-4-555-0123',
         'Jebel Ali Free Zone', 'Dubai', 'UAE', 'Logistics', 'Net 45',
         14, 3.9, 3.5, 4.2, 3.0, 180000, 85, 'No', 'active', '2024-03-15', '2025-03-14']
    ]

    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=value)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='supplier_import_template.xlsx')


# =============================================================================
# INVENTORY TWIN
# =============================================================================

@business_twin_bp.route('/inventory')
@login_required
def inventory():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    items = Inventory.query.filter_by(company_id=company_id, is_active=True).order_by(Inventory.name).all()

    total_db_items = len(items)
    total_quantity = sum(int(i.quantity_on_hand or 0) for i in items)
    total_stock_value = sum(float(i.quantity_on_hand or 0) * float(i.unit_cost or 0) for i in items)

    low_stock_count = len([i for i in items if (i.quantity_available or 0) <= (i.reorder_point or 0)])
    overstock_count = len([i for i in items if (i.max_stock or 0) > 0 and (i.quantity_on_hand or 0) > (i.max_stock or 0)])
    optimal_stock_count = max(0, total_db_items - low_stock_count - overstock_count)

    from collections import defaultdict
    cat_map = defaultdict(lambda: {'valuation': 0.0, 'units': 0})
    for item in items:
        cat = (item.category or 'General').strip()
        val = float(item.quantity_on_hand or 0) * float(item.unit_cost or 0)
        u = int(item.quantity_on_hand or 0)
        cat_map[cat]['valuation'] += val
        cat_map[cat]['units'] += u

    category_stats = []
    for cat_name, cinfo in cat_map.items():
        category_stats.append({
            'name': cat_name,
            'valuation': round(cinfo['valuation'], 2),
            'units': cinfo['units']
        })
    category_stats.sort(key=lambda x: x['valuation'], reverse=True)

    return render_template('business_twin/twin_inventory.html', 
                         items=items,
                         total_db_items=total_db_items,
                         total_quantity=total_quantity,
                         low_stock_count=low_stock_count,
                         overstock_count=overstock_count,
                         optimal_stock_count=optimal_stock_count,
                         total_stock_value=total_stock_value,
                         category_stats=category_stats,
                         company=company,
                         currency_symbol=_get_currency_symbol(company_id))


@business_twin_bp.route('/inventory/add', methods=['POST'])
@login_required
def add_inventory():
    company_id = session.get('company_id')

    try:
        qoh = int(request.form.get('quantity_on_hand', 0) or 0)
        qres = int(request.form.get('quantity_reserved', 0) or 0)

        item = Inventory(
            company_id=company_id,
            sku=request.form.get('sku', ''),
            name=request.form.get('name', ''),
            description=request.form.get('description', ''),
            category=request.form.get('category', 'General'),
            location=request.form.get('location', ''),
            unit_cost=float(request.form.get('unit_cost', 0) or 0),
            selling_price=float(request.form.get('selling_price', 0) or 0),
            quantity_on_hand=qoh,
            quantity_reserved=qres,
            quantity_available=qoh - qres,
            reorder_point=int(request.form.get('reorder_point', 0) or 0),
            reorder_quantity=int(request.form.get('reorder_quantity', 0) or 0),
            max_stock=int(request.form.get('max_stock', 0) or 0),
            turnover_rate=float(request.form.get('turnover_rate', 0)) if request.form.get('turnover_rate') else None,
            days_on_hand=float(request.form.get('days_on_hand', 0)) if request.form.get('days_on_hand') else None,
            is_active=True
        )

        db.session.add(item)
        db.session.commit()

        return jsonify({'success': True, 'item': item.to_dict()})

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/inventory/edit/<int:item_id>', methods=['POST'])
@login_required
def edit_inventory(item_id):
    company_id = session.get('company_id')
    item = Inventory.query.filter_by(id=item_id, company_id=company_id).first()
    if not item:
        return jsonify({'success': False, 'error': 'Item not found'}), 404
    
    try:
        item.sku = request.form.get('sku', item.sku)
        item.name = request.form.get('name', item.name)
        item.description = request.form.get('description', item.description or '')
        item.category = request.form.get('category', item.category or 'General')
        item.location = request.form.get('location', item.location or '')
        item.unit_cost = float(request.form.get('unit_cost', item.unit_cost or 0) or 0)
        item.selling_price = float(request.form.get('selling_price', item.selling_price or 0) or 0)
        
        qoh = int(request.form.get('quantity_on_hand', item.quantity_on_hand or 0) or 0)
        qres = int(request.form.get('quantity_reserved', item.quantity_reserved or 0) or 0)
        item.quantity_on_hand = qoh
        item.quantity_reserved = qres
        item.quantity_available = qoh - qres
        
        item.reorder_point = int(request.form.get('reorder_point', item.reorder_point or 0) or 0)
        item.reorder_quantity = int(request.form.get('reorder_quantity', item.reorder_quantity or 0) or 0)
        item.max_stock = int(request.form.get('max_stock', item.max_stock or 0) or 0)
        
        turnover = request.form.get('turnover_rate', '')
        item.turnover_rate = float(turnover) if turnover and turnover.strip() else item.turnover_rate
        
        days = request.form.get('days_on_hand', '')
        item.days_on_hand = float(days) if days and days.strip() else item.days_on_hand
        
        db.session.commit()
        return jsonify({'success': True, 'item': item.to_dict()})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/inventory/delete/<int:item_id>', methods=['DELETE'])
@login_required
def delete_inventory(item_id):
    company_id = session.get('company_id')
    item = Inventory.query.filter_by(id=item_id, company_id=company_id).first()
    if not item:
        return jsonify({'success': False, 'error': 'Item not found'}), 404
    
    try:
        db.session.delete(item)
        db.session.commit()
        return jsonify({'success': True, 'message': 'Item deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/departments/delete/<int:dept_id>', methods=['DELETE', 'POST'])
@login_required
def delete_department(dept_id):
    """Delete a department, detaching its employees/expense records first."""
    company_id = session.get('company_id')
    dept = Department.query.filter_by(id=dept_id, company_id=company_id).first()
    if not dept:
        return jsonify({'success': False, 'error': 'Department not found'}), 404
    try:
        Employee.query.filter_by(department_id=dept.id, company_id=company_id)\
            .update({'department_id': None})
        FinancialRecord.query.filter_by(department_id=dept.id, company_id=company_id)\
            .update({'department_id': None})
        Project.query.filter_by(department_id=dept.id, company_id=company_id)\
            .update({'department_id': None})
        CustomTwin.query.filter_by(company_id=company_id, linked_entity_type='department', linked_entity_id=dept.id)\
            .delete(synchronize_session=False)
        dept_name = dept.name
        db.session.delete(dept)
        db.session.commit()

        try:
            publish_event(DomainEvent.create(
                event_type=EventTypes.DEPARTMENT_DELETED,
                company_id=company_id,
                aggregate_type='department',
                aggregate_id=str(dept_id),
                actor_id=current_user.id if hasattr(current_user, 'id') else None,
                actor_name=getattr(current_user, 'username', 'System'),
                payload={'name': dept_name}
            ))
        except Exception as ev_err:
            logger.warning(f"Event publication warning: {ev_err}")

        return jsonify({'success': True, 'message': f'Department "{dept_name}" deleted'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


# Bulk-delete dispatch: every twin reuses its own single-record handler so
# twin-interconnection hooks (on_delete mirrors, dept spent reversal, etc.)
# run exactly as they do for individual deletes.
BULK_DELETE_HANDLERS = {
    'revenue': 'delete_revenue',
    'expenses': 'delete_expense',
    'customers': 'delete_customer',
    'employees': 'delete_employee',
    'suppliers': 'delete_supplier',
    'inventory': 'delete_inventory',
    'departments': 'delete_department',
}


@business_twin_bp.route('/bulk-delete', methods=['POST'])
@login_required
def bulk_delete_records():
    """Bulk delete selected records of any core twin in a high-speed atomic transaction."""
    company_id = _get_active_company_id()
    if not company_id:
        return jsonify({'success': False, 'error': 'Session expired or organization not found'}), 401

    data = request.get_json(silent=True) or {}
    twin = (data.get('twin') or data.get('entity_type') or '').strip().lower()
    raw_ids = data.get('ids') or []
    try:
        ids = sorted({int(i) for i in raw_ids})
    except (TypeError, ValueError):
        return jsonify({'success': False, 'error': 'Invalid record ids'}), 400

    if not ids:
        return jsonify({'success': False, 'error': 'No records selected for deletion'}), 400

    deleted_count = 0
    try:
        if twin == 'revenue':
            deleted_count = FinancialRecord.query.filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_type == 'revenue',
                FinancialRecord.id.in_(ids)
            ).delete(synchronize_session=False)
            CoreTwinExtraRecord.query.filter(
                CoreTwinExtraRecord.company_id == company_id,
                CoreTwinExtraRecord.twin_key == 'revenue',
                CoreTwinExtraRecord.record_id.in_(ids)
            ).delete(synchronize_session=False)

        elif twin == 'expenses':
            # Reverse department spent calculations
            expenses_to_delete = FinancialRecord.query.filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_type == 'expense',
                FinancialRecord.id.in_(ids)
            ).all()
            for exp in expenses_to_delete:
                if exp.department_id:
                    dept = Department.query.filter_by(id=exp.department_id, company_id=company_id).first()
                    if dept and dept.spent:
                        dept.spent = max(0.0, dept.spent - (exp.amount or 0.0))
            
            deleted_count = FinancialRecord.query.filter(
                FinancialRecord.company_id == company_id,
                FinancialRecord.transaction_type == 'expense',
                FinancialRecord.id.in_(ids)
            ).delete(synchronize_session=False)
            CoreTwinExtraRecord.query.filter(
                CoreTwinExtraRecord.company_id == company_id,
                CoreTwinExtraRecord.twin_key == 'expenses',
                CoreTwinExtraRecord.record_id.in_(ids)
            ).delete(synchronize_session=False)

        elif twin == 'customers':
            deleted_count = Customer.query.filter(
                Customer.company_id == company_id,
                Customer.id.in_(ids)
            ).delete(synchronize_session=False)
            company = Company.query.get(company_id)
            if company:
                company.customer_count = Customer.query.filter_by(company_id=company_id, status='active').count()

        elif twin == 'employees':
            deleted_count = Employee.query.filter(
                Employee.company_id == company_id,
                Employee.id.in_(ids)
            ).delete(synchronize_session=False)
            company = Company.query.get(company_id)
            if company:
                company.employee_count = Employee.query.filter_by(company_id=company_id, status='active').count()

        elif twin == 'suppliers':
            deleted_count = Supplier.query.filter(
                Supplier.company_id == company_id,
                Supplier.id.in_(ids)
            ).delete(synchronize_session=False)

        elif twin == 'inventory':
            deleted_count = Inventory.query.filter(
                Inventory.company_id == company_id,
                Inventory.id.in_(ids)
            ).delete(synchronize_session=False)

        elif twin == 'departments':
            Employee.query.filter(Employee.company_id == company_id, Employee.department_id.in_(ids)).update({'department_id': None}, synchronize_session=False)
            FinancialRecord.query.filter(FinancialRecord.company_id == company_id, FinancialRecord.department_id.in_(ids)).update({'department_id': None}, synchronize_session=False)
            Project.query.filter(Project.company_id == company_id, Project.department_id.in_(ids)).update({'department_id': None}, synchronize_session=False)
            DepartmentBudget.query.filter(DepartmentBudget.company_id == company_id, DepartmentBudget.department_id.in_(ids)).delete(synchronize_session=False)
            DepartmentInvitation.query.filter(DepartmentInvitation.company_id == company_id, DepartmentInvitation.department_id.in_(ids)).delete(synchronize_session=False)
            TwinDependency.query.filter(TwinDependency.company_id == company_id, (TwinDependency.source_dept_id.in_(ids) | TwinDependency.target_dept_id.in_(ids))).delete(synchronize_session=False)
            deleted_count = Department.query.filter(
                Department.company_id == company_id,
                Department.id.in_(ids)
            ).delete(synchronize_session=False)

        elif twin in ('custom-records', 'custom_records') or twin.startswith('custom_'):
            deleted_count = CustomTwinRecord.query.filter(
                CustomTwinRecord.company_id == company_id,
                CustomTwinRecord.id.in_(ids)
            ).delete(synchronize_session=False)

        else:
            return jsonify({'success': False, 'error': f'Unsupported twin category "{twin}"'}), 400

        db.session.commit()

        # Recalculate twin telemetry
        try:
            from services.twin_service import TwinService
            TwinService.recalculate_company_metrics(company_id)
        except Exception:
            pass

        return jsonify({
            'success': True,
            'deleted': deleted_count,
            'failed': [],
            'message': f"{deleted_count} record(s) deleted permanently."
        })

    except Exception as e:
        db.session.rollback()
        logger.error(f"Bulk delete error for twin {twin}: {e}", exc_info=True)
        return jsonify({'success': False, 'error': f"Database deletion error: {str(e)}"}), 500


@business_twin_bp.route('/inventory/delete-all', methods=['DELETE'])
@login_required
def delete_all_inventory():
    company_id = session.get('company_id')
    try:
        count = Inventory.query.filter_by(company_id=company_id).count()
        Inventory.query.filter_by(company_id=company_id).delete()
        db.session.commit()
        return jsonify({'success': True, 'message': f'All {count} inventory items deleted successfully'})
    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/inventory/import-csv', methods=['POST'])
@login_required
def import_inventory_csv():
    company_id = session.get('company_id')

    if 'csv_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['csv_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not file.filename.endswith('.csv'):
        return jsonify({'success': False, 'error': 'File must be a CSV'}), 400

    try:
        stream = io.StringIO(file.stream.read().decode('UTF-8'), newline=None)
        csv_reader = csv.DictReader(stream)

        added_count = 0
        updated_count = 0
        errors = []

        for row_num, row in enumerate(csv_reader, start=2):
            try:
                sku = row.get('sku', '').strip()
                name = row.get('name', '').strip()

                if not sku or not name:
                    errors.append(f"Row {row_num}: Missing required fields (sku, name)")
                    continue

                qoh = int(row.get('quantity_on_hand', 0) or 0)
                qres = int(row.get('quantity_reserved', 0) or 0)

                existing = Inventory.query.filter_by(company_id=company_id, sku=sku).first()

                if existing:
                    existing.name = name
                    existing.description = row.get('description', '').strip()
                    existing.category = row.get('category', 'General').strip()
                    existing.location = row.get('location', '').strip()
                    existing.unit_cost = float(row.get('unit_cost', 0) or 0)
                    existing.selling_price = float(row.get('selling_price', 0) or 0)
                    existing.quantity_on_hand = qoh
                    existing.quantity_reserved = qres
                    existing.quantity_available = qoh - qres
                    existing.reorder_point = int(row.get('reorder_point', 0) or 0)
                    existing.reorder_quantity = int(row.get('reorder_quantity', 0) or 0)
                    existing.max_stock = int(row.get('max_stock', 0) or 0)
                    existing.turnover_rate = float(row.get('turnover_rate', 0)) if row.get('turnover_rate') else existing.turnover_rate
                    existing.days_on_hand = float(row.get('days_on_hand', 0)) if row.get('days_on_hand') else existing.days_on_hand
                    existing.is_active = True
                    updated_count += 1
                else:
                    item = Inventory(
                        company_id=company_id,
                        sku=sku,
                        name=name,
                        description=row.get('description', '').strip(),
                        category=row.get('category', 'General').strip(),
                        location=row.get('location', '').strip(),
                        unit_cost=float(row.get('unit_cost', 0) or 0),
                        selling_price=float(row.get('selling_price', 0) or 0),
                        quantity_on_hand=qoh,
                        quantity_reserved=qres,
                        quantity_available=qoh - qres,
                        reorder_point=int(row.get('reorder_point', 0) or 0),
                        reorder_quantity=int(row.get('reorder_quantity', 0) or 0),
                        max_stock=int(row.get('max_stock', 0) or 0),
                        turnover_rate=float(row.get('turnover_rate', 0)) if row.get('turnover_rate') else None,
                        days_on_hand=float(row.get('days_on_hand', 0)) if row.get('days_on_hand') else None,
                        is_active=True
                    )
                    db.session.add(item)
                    added_count += 1

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/inventory/import-excel', methods=['POST'])
@login_required
def import_inventory_excel():
    company_id = session.get('company_id')

    if 'excel_file' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400

    file = request.files['excel_file']
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400

    if not (file.filename.endswith('.xlsx') or file.filename.endswith('.xls')):
        return jsonify({'success': False, 'error': 'File must be an Excel file (.xlsx or .xls)'}), 400

    try:
        from openpyxl import load_workbook

        wb = load_workbook(filename=io.BytesIO(file.read()))
        ws = wb.active

        headers = []
        for cell in ws[1]:
            val = cell.value
            if val:
                h = str(val).strip().lower().replace(' ', '_').replace('-', '_')
                headers.append(h)
            else:
                headers.append('')

        header_map = {}
        for idx, h in enumerate(headers):
            if h in ['sku', 'sku_code', 'item_code', 'product_code']:
                header_map['sku'] = idx
            elif h in ['name', 'item_name', 'product_name', 'item']:
                header_map['name'] = idx
            elif h in ['description', 'desc', 'details']:
                header_map['description'] = idx
            elif h in ['category', 'type', 'item_category']:
                header_map['category'] = idx
            elif h in ['location', 'warehouse', 'storage']:
                header_map['location'] = idx
            elif h in ['unit_cost', 'cost', 'purchase_price', 'buy_price']:
                header_map['unit_cost'] = idx
            elif h in ['selling_price', 'price', 'sale_price', 'retail_price']:
                header_map['selling_price'] = idx
            elif h in ['quantity_on_hand', 'on_hand', 'stock', 'qty_on_hand']:
                header_map['quantity_on_hand'] = idx
            elif h in ['quantity_reserved', 'reserved', 'qty_reserved']:
                header_map['quantity_reserved'] = idx
            elif h in ['reorder_point', 'reorder_pt', 'min_stock']:
                header_map['reorder_point'] = idx
            elif h in ['reorder_quantity', 'reorder_qty', 'order_qty']:
                header_map['reorder_quantity'] = idx
            elif h in ['max_stock', 'maximum_stock', 'max']:
                header_map['max_stock'] = idx
            elif h in ['turnover_rate', 'turnover']:
                header_map['turnover_rate'] = idx
            elif h in ['days_on_hand', 'days_in_stock']:
                header_map['days_on_hand'] = idx

        if 'sku' not in header_map or 'name' not in header_map:
            return jsonify({'success': False, 'error': 'Excel file must have columns: sku, name'}), 400

        added_count = 0
        updated_count = 0
        errors = []

        def get_str_val(row, key, default=''):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                return str(val).strip() if val is not None else default
            return default

        def get_float_val(row, key, default=0.0):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                if val is not None:
                    try:
                        return float(val)
                    except (ValueError, TypeError):
                        return default
            return default

        def get_int_val(row, key, default=0):
            idx = header_map.get(key)
            if idx is not None and idx < len(row):
                val = row[idx]
                if val is not None:
                    try:
                        return int(float(val))
                    except (ValueError, TypeError):
                        return default
            return default

        for row_num, row in enumerate(ws.iter_rows(min_row=2, values_only=True), start=2):
            try:
                sku_idx = header_map.get('sku', 0)
                name_idx = header_map.get('name', 1)

                sku = str(row[sku_idx] if sku_idx < len(row) else '').strip()
                name = str(row[name_idx] if name_idx < len(row) else '').strip()

                if not sku or not name:
                    errors.append(f"Row {row_num}: Missing required fields (sku, name)")
                    continue

                qoh = get_int_val(row, 'quantity_on_hand')
                qres = get_int_val(row, 'quantity_reserved')

                existing = Inventory.query.filter_by(company_id=company_id, sku=sku).first()

                if existing:
                    existing.name = name
                    existing.description = get_str_val(row, 'description')
                    existing.category = get_str_val(row, 'category', 'General')
                    existing.location = get_str_val(row, 'location')
                    existing.unit_cost = get_float_val(row, 'unit_cost')
                    existing.selling_price = get_float_val(row, 'selling_price')
                    existing.quantity_on_hand = qoh
                    existing.quantity_reserved = qres
                    existing.quantity_available = qoh - qres
                    existing.reorder_point = get_int_val(row, 'reorder_point')
                    existing.reorder_quantity = get_int_val(row, 'reorder_quantity')
                    existing.max_stock = get_int_val(row, 'max_stock')
                    turnover = get_str_val(row, 'turnover_rate')
                    existing.turnover_rate = float(turnover) if turnover else existing.turnover_rate
                    days = get_str_val(row, 'days_on_hand')
                    existing.days_on_hand = float(days) if days else existing.days_on_hand
                    existing.is_active = True
                    updated_count += 1
                else:
                    item = Inventory(
                        company_id=company_id,
                        sku=sku,
                        name=name,
                        description=get_str_val(row, 'description'),
                        category=get_str_val(row, 'category', 'General'),
                        location=get_str_val(row, 'location'),
                        unit_cost=get_float_val(row, 'unit_cost'),
                        selling_price=get_float_val(row, 'selling_price'),
                        quantity_on_hand=qoh,
                        quantity_reserved=qres,
                        quantity_available=qoh - qres,
                        reorder_point=get_int_val(row, 'reorder_point'),
                        reorder_quantity=get_int_val(row, 'reorder_quantity'),
                        max_stock=get_int_val(row, 'max_stock'),
                        turnover_rate=get_float_val(row, 'turnover_rate') if get_str_val(row, 'turnover_rate') else None,
                        days_on_hand=get_float_val(row, 'days_on_hand') if get_str_val(row, 'days_on_hand') else None,
                        is_active=True
                    )
                    db.session.add(item)
                    added_count += 1

            except Exception as e:
                errors.append(f"Row {row_num}: {str(e)}")

        db.session.commit()

        return jsonify({
            'success': True, 
            'added': added_count,
            'updated': updated_count,
            'errors': errors,
            'message': f'Import complete: {added_count} new, {updated_count} updated'
        })

    except Exception as e:
        db.session.rollback()
        return jsonify({'success': False, 'error': str(e)}), 500


@business_twin_bp.route('/inventory/export-excel')
@login_required
def export_inventory_excel():
    company_id = session.get('company_id')
    items = Inventory.query.filter_by(company_id=company_id, is_active=True).order_by(Inventory.name).all()

    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Inventory"

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    headers = ['ID', 'SKU', 'Name', 'Description', 'Category', 'Location', 'Unit Cost',
               'Selling Price', 'On Hand', 'Reserved', 'Available', 'Reorder Point',
               'Reorder Qty', 'Max Stock', 'Stock Value', 'Turnover Rate', 'Days On Hand', 'Created At']

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    for row_num, item in enumerate(items, 2):
        ws.cell(row=row_num, column=1, value=item.id)
        ws.cell(row=row_num, column=2, value=item.sku)
        ws.cell(row=row_num, column=3, value=item.name)
        ws.cell(row=row_num, column=4, value=item.description)
        ws.cell(row=row_num, column=5, value=item.category)
        ws.cell(row=row_num, column=6, value=item.location)
        ws.cell(row=row_num, column=7, value=item.unit_cost)
        ws.cell(row=row_num, column=8, value=item.selling_price)
        ws.cell(row=row_num, column=9, value=item.quantity_on_hand)
        ws.cell(row=row_num, column=10, value=item.quantity_reserved)
        ws.cell(row=row_num, column=11, value=item.quantity_available)
        ws.cell(row=row_num, column=12, value=item.reorder_point)
        ws.cell(row=row_num, column=13, value=item.reorder_quantity)
        ws.cell(row=row_num, column=14, value=item.max_stock)
        ws.cell(row=row_num, column=15, value=item.stock_value())
        ws.cell(row=row_num, column=16, value=item.turnover_rate)
        ws.cell(row=row_num, column=17, value=item.days_on_hand)
        ws.cell(row=row_num, column=18, value=item.created_at.strftime('%Y-%m-%d %H:%M:%S') if item.created_at else '')

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='inventory_export.xlsx')


@business_twin_bp.route('/inventory/export-pdf')
@login_required
def export_inventory_pdf():
    company_id = session.get('company_id')
    company = Company.query.get(company_id)
    items = Inventory.query.filter_by(company_id=company_id, is_active=True).order_by(Inventory.name).all()

    symbol = _get_currency_symbol(company_id)

    from reportlab.lib.pagesizes import A4
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER

    output = io.BytesIO()
    doc = SimpleDocTemplate(output, pagesize=A4, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)

    elements = []
    styles = getSampleStyleSheet()

    title_style = ParagraphStyle('CustomTitle', parent=styles['Heading1'], fontSize=18, textColor=colors.HexColor('#1a1f3a'), spaceAfter=20, alignment=TA_CENTER)
    elements.append(Paragraph(f"{company.company_name if company else 'Company'} - Inventory Report", title_style))
    elements.append(Spacer(1, 0.2*inch))

    summary_style = ParagraphStyle('Summary', parent=styles['Normal'], fontSize=10, textColor=colors.HexColor('#555555'), spaceAfter=15)
    elements.append(Paragraph(f"Total Items: {len(items)} | Generated: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}", summary_style))
    elements.append(Spacer(1, 0.1*inch))

    table_data = [['SKU', 'Name', 'Category', 'On Hand', 'Available', 'Unit Cost', 'Status', 'Value']]
    for item in items:
        status = 'Low' if item.is_low_stock() else ('Over' if item.is_overstock() else 'OK')
        table_data.append([
            item.sku or '-',
            item.name or '-',
            item.category or 'General',
            str(item.quantity_on_hand),
            str(item.quantity_available),
            f"{symbol}{item.unit_cost:,.2f}" if item.unit_cost else f'{symbol}0',
            status,
            f"{symbol}{item.stock_value():,.0f}" if item.stock_value() else f'{symbol}0'
        ])

    table = Table(table_data, repeatRows=1)
    table.setStyle(TableStyle([
        ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a1f3a')),
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
        ('FONTSIZE', (0, 0), (-1, 0), 10),
        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
        ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f8f9fa')),
        ('GRID', (0, 0), (-1, -1), 1, colors.HexColor('#dee2e6')),
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
        ('FONTSIZE', (0, 1), (-1, -1), 9),
        ('ALIGN', (0, 0), (1, -1), 'LEFT'),
        ('VALIGN', (0, 0), (-1, -1), 'MIDDLE'),
        ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.HexColor('#ffffff'), colors.HexColor('#f8f9fa')])
    ]))

    elements.append(table)
    doc.build(elements)
    output.seek(0)

    return send_file(output, mimetype='application/pdf',
                     as_attachment=True, download_name='inventory_report.pdf')


@business_twin_bp.route('/inventory/download-template')
@login_required
def download_inventory_csv_template():
    output = io.StringIO()
    writer = csv.writer(output)

    writer.writerow([
        'sku', 'name', 'description', 'category', 'location', 'unit_cost', 'selling_price',
        'quantity_on_hand', 'quantity_reserved', 'reorder_point', 'reorder_quantity', 'max_stock',
        'turnover_rate', 'days_on_hand'
    ])

    writer.writerow([
        'SKU-001', 'MacBook Pro 16"', 'Apple laptop with M3 chip', 'Electronics', 'Warehouse A, Shelf 1',
        1999.00, 2499.00, 45, 5, 10, 20, 100, 8.5, 15
    ])
    writer.writerow([
        'SKU-002', 'Dell UltraSharp Monitor', '27-inch 4K USB-C monitor', 'Electronics', 'Warehouse A, Shelf 2',
        450.00, 599.00, 30, 3, 8, 15, 60, 6.2, 22
    ])
    writer.writerow([
        'SKU-003', 'Steel Rebar Grade 60', 'Construction rebar #4', 'Raw Materials', 'Yard B, Section 3',
        18.50, 24.00, 500, 50, 100, 200, 1000, 12.0, 8
    ])
    writer.writerow([
        'SKU-004', 'A4 Copy Paper (500 sheets)', 'Premium quality office paper', 'Office Supplies', 'Warehouse C, Rack 1',
        3.50, 5.00, 2000, 200, 500, 1000, 5000, 24.0, 4
    ])
    writer.writerow([
        'SKU-005', 'AWS EC2 Reserved Instance', 't3.large 1-year reserved', 'Software License', 'Digital',
        850.00, 1200.00, 10, 0, 2, 5, 50, 3.5, 45
    ])

    output.seek(0)
    return send_file(io.BytesIO(output.getvalue().encode()), mimetype='text/csv',
                     as_attachment=True, download_name='inventory_import_template.csv')


@business_twin_bp.route('/inventory/download-excel-template')
@login_required
def download_inventory_excel_template():
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = Workbook()
    ws = wb.active
    ws.title = "Inventory"

    headers = [
        'sku', 'name', 'description', 'category', 'location', 'unit_cost', 'selling_price',
        'quantity_on_hand', 'quantity_reserved', 'reorder_point', 'reorder_quantity', 'max_stock',
        'turnover_rate', 'days_on_hand'
    ]

    header_font = Font(bold=True, color="FFFFFF", size=11)
    header_fill = PatternFill(start_color="1a1f3a", end_color="1a1f3a", fill_type="solid")
    header_align = Alignment(horizontal="center", vertical="center")

    for col, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_align

    sample_data = [
        ['SKU-001', 'MacBook Pro 16"', 'Apple laptop with M3 chip', 'Electronics', 'Warehouse A, Shelf 1',
         1999.00, 2499.00, 45, 5, 10, 20, 100, 8.5, 15],
        ['SKU-002', 'Dell UltraSharp Monitor', '27-inch 4K USB-C monitor', 'Electronics', 'Warehouse A, Shelf 2',
         450.00, 599.00, 30, 3, 8, 15, 60, 6.2, 22],
        ['SKU-003', 'Steel Rebar Grade 60', 'Construction rebar #4', 'Raw Materials', 'Yard B, Section 3',
         18.50, 24.00, 500, 50, 100, 200, 1000, 12.0, 8],
        ['SKU-004', 'A4 Copy Paper (500 sheets)', 'Premium quality office paper', 'Office Supplies', 'Warehouse C, Rack 1',
         3.50, 5.00, 2000, 200, 500, 1000, 5000, 24.0, 4],
        ['SKU-005', 'AWS EC2 Reserved Instance', 't3.large 1-year reserved', 'Software License', 'Digital',
         850.00, 1200.00, 10, 0, 2, 5, 50, 3.5, 45]
    ]

    for row_num, row_data in enumerate(sample_data, 2):
        for col_num, value in enumerate(row_data, 1):
            ws.cell(row=row_num, column=col_num, value=value)

    for column in ws.columns:
        max_length = 0
        column_letter = column[0].column_letter
        for cell in column:
            try:
                if cell.value:
                    max_length = max(max_length, len(str(cell.value)))
            except:
                pass
        adjusted_width = min(max_length + 2, 50)
        ws.column_dimensions[column_letter].width = adjusted_width

    output = io.BytesIO()
    wb.save(output)
    output.seek(0)

    return send_file(output, mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                     as_attachment=True, download_name='inventory_import_template.xlsx')