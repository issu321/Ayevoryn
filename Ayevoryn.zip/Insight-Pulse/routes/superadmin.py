"""
AEVORYN GLOBAL SUPERADMIN CONTROL PLANE ROUTES
Strictly separated from tenant company routes and protected by @superadmin_required.
"""

import json
from datetime import datetime
from flask import Blueprint, Response, render_template, request, redirect, url_for, flash, jsonify, session, abort
from flask_login import login_required, current_user, login_user

from database.db import db
from database.models.user import User
from database.models.company import Company
from database.models.department import Department
from database.models.superadmin import GlobalAuditLog, PlatformSetting, UserSessionRecord
from security.rbac import superadmin_required, COMPANY_ROLES, Role
from security.password_hash import verify_password, hash_password
from services.superadmin_service import SuperadminService, VALID_PLAN_TIERS
from config.constants import CURRENCY_SYMBOLS, COUNTRY_DATA

superadmin_bp = Blueprint('superadmin', __name__, url_prefix='/superadmin')


def _parse_id_list(raw_input) -> list:
    """Parse a list of integer IDs from JSON array, form list, or comma-separated string."""
    if not raw_input:
        return []
    if isinstance(raw_input, (list, tuple)):
        items = raw_input
    elif isinstance(raw_input, str):
        raw_str = raw_input.strip()
        if raw_str.startswith('['):
            try:
                items = json.loads(raw_str)
            except Exception:
                items = raw_str.split(',')
        else:
            items = raw_str.split(',')
    else:
        items = [raw_input]

    result = []
    for item in items:
        try:
            val = int(str(item).strip())
            if val not in result:
                result.append(val)
        except (ValueError, TypeError):
            continue
    return result


@superadmin_bp.route('/')
@superadmin_bp.route('/dashboard')
@superadmin_required
def dashboard():
    """Global Superadmin Control Center Overview Dashboard."""
    recent_limit = request.args.get('limit', 12, type=int)
    metrics = SuperadminService.get_dashboard_metrics(recent_limit=max(6, min(recent_limit, 200)))
    return render_template(
        'superadmin/dashboard.html',
        metrics=metrics,
        plan_tiers=VALID_PLAN_TIERS,
        currencies=list(CURRENCY_SYMBOLS.keys()),
        countries=sorted(list(COUNTRY_DATA.keys())),
        active_nav='dashboard'
    )


@superadmin_bp.route('/force-password-change', methods=['GET', 'POST'])
@login_required
def force_password_change():
    """Mandatory first-login password change workflow for the Global Superadmin."""
    if not getattr(current_user, 'is_global_superadmin', False):
        return redirect(url_for('auth.force_user_password_change'))

    if request.method == 'POST':
        current_pw = (request.form.get('current_password') or '').strip()
        new_pw = (request.form.get('new_password') or '').strip()
        confirm_pw = (request.form.get('confirm_password') or '').strip()

        if not verify_password(current_pw, current_user.password_hash):
            flash('Current password is incorrect.', 'danger')
        elif len(new_pw) < 8:
            flash('New password must be at least 8 characters long.', 'danger')
        elif new_pw != confirm_pw:
            flash('New password and confirmation do not match.', 'danger')
        elif verify_password(new_pw, current_user.password_hash):
            flash('New password must be different from the initial bootstrap password.', 'danger')
        else:
            current_user.set_password(new_pw)
            current_user.must_change_password = False
            current_user.updated_at = datetime.utcnow()
            db.session.commit()

            SuperadminService.record_audit(
                action='SUPERADMIN_INITIAL_PASSWORD_CHANGED',
                category='SECURITY',
                target_user_id=current_user.id,
                target_username=current_user.username,
                updated_values={'must_change_password': False},
                details=f"Global Superadmin '{current_user.username}' completed mandatory first-login password rotation."
            )
            flash('Your Global Superadmin password has been securely updated.', 'success')
            return redirect(url_for('superadmin.dashboard'))

    return render_template('superadmin/force_password_change.html', is_tenant_user=False)


@superadmin_bp.route('/mfa-verify', methods=['GET', 'POST'])
@login_required
def mfa_verify():
    """Verify TOTP MFA code or backup code for Global Superadmin when MFA is enabled."""
    if not getattr(current_user, 'is_global_superadmin', False):
        abort(403)

    if request.method == 'POST':
        code = (request.form.get('totp_code') or '').strip()
        verified = False
        if current_user.mfa_secret and SuperadminService.verify_totp_code(current_user.mfa_secret, code):
            verified = True
        elif current_user.mfa_backup_codes:
            try:
                codes = json.loads(current_user.mfa_backup_codes)
                if code.upper() in codes:
                    codes.remove(code.upper())
                    current_user.mfa_backup_codes = json.dumps(codes)
                    db.session.commit()
                    verified = True
            except Exception:
                pass

        if verified:
            session['mfa_verified'] = True
            SuperadminService.record_audit(
                action='SUPERADMIN_MFA_VERIFIED',
                category='SECURITY',
                target_user_id=current_user.id,
                target_username=current_user.username,
                details='Global Superadmin completed Multi-Factor Authentication challenge.'
            )
            if getattr(current_user, 'must_change_password', False):
                return redirect(url_for('superadmin.force_password_change'))
            return redirect(url_for('superadmin.dashboard'))
        else:
            SuperadminService.record_audit(
                action='SUPERADMIN_MFA_FAILED',
                category='SECURITY',
                target_user_id=current_user.id,
                target_username=current_user.username,
                result_status='FAILED',
                details='Invalid MFA verification code submitted.'
            )
            flash('Invalid authentication code. Please try again.', 'danger')

    return render_template('superadmin/mfa_verify.html')


# ══════════════════════════════════════════════════════════════════════════
# GLOBAL COMPANIES MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════
@superadmin_bp.route('/companies')
@superadmin_required
def companies():
    search = request.args.get('q', '').strip()
    status_filter = request.args.get('status', 'all').strip()
    industry_filter = request.args.get('industry', '').strip()
    tier_filter = request.args.get('tier', '').strip()
    sort_by = request.args.get('sort', 'created_desc').strip()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 15, type=int)

    listing = SuperadminService.list_companies(
        search=search,
        status_filter=status_filter,
        industry_filter=industry_filter,
        tier_filter=tier_filter,
        sort_by=sort_by,
        page=page,
        per_page=per_page
    )

    industries = [r[0] for r in db.session.query(Company.industry).distinct().all() if r[0]]
    return render_template(
        'superadmin/companies.html',
        listing=listing,
        search=search,
        status_filter=status_filter,
        industry_filter=industry_filter,
        tier_filter=tier_filter,
        sort_by=sort_by,
        per_page=per_page,
        industries=sorted(industries),
        plan_tiers=VALID_PLAN_TIERS,
        currencies=list(CURRENCY_SYMBOLS.keys()),
        countries=sorted(list(COUNTRY_DATA.keys())),
        active_nav='companies'
    )


@superadmin_bp.route('/companies/create', methods=['POST'])
@superadmin_required
def company_create():
    payload = request.get_json(silent=True) if request.is_json else request.form
    ok, msg, comp = SuperadminService.create_company_by_superadmin(payload or {}, actor_user=current_user)
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({
            'success': ok,
            'message': msg,
            'company_id': comp.id if comp else None
        }), (200 if ok else 400)
    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.companies'))


@superadmin_bp.route('/companies/bulk-action', methods=['POST'])
@superadmin_required
def companies_bulk_action():
    """Execute bulk lifecycle, tier, or permanent delete actions on selected organizations."""
    if request.is_json:
        data = request.get_json(silent=True) or {}
        raw_ids = data.get('company_ids') or data.get('ids') or []
        action = (data.get('action') or '').strip()
        reason = (data.get('reason') or '').strip()
        plan_tier = (data.get('plan_tier') or '').strip()
        superadmin_password = (data.get('superadmin_password') or '').strip()
        select_all_matching = bool(data.get('select_all_matching'))
        filter_q = (data.get('q') or '').strip()
        filter_status = (data.get('status') or 'all').strip()
        filter_industry = (data.get('industry') or '').strip()
        filter_tier = (data.get('tier') or '').strip()
    else:
        raw_ids = request.form.getlist('company_ids') or request.form.get('company_ids') or request.form.get('ids') or []
        action = (request.form.get('action') or '').strip()
        reason = (request.form.get('reason') or '').strip()
        plan_tier = (request.form.get('plan_tier') or '').strip()
        superadmin_password = (request.form.get('superadmin_password') or '').strip()
        select_all_matching = request.form.get('select_all_matching') in ('1', 'true', 'yes', 'on')
        filter_q = (request.form.get('q') or '').strip()
        filter_status = (request.form.get('status') or 'all').strip()
        filter_industry = (request.form.get('industry') or '').strip()
        filter_tier = (request.form.get('tier') or '').strip()

    if select_all_matching:
        q_obj = SuperadminService._build_companies_query(
            search=filter_q,
            status_filter=filter_status,
            industry_filter=filter_industry,
            tier_filter=filter_tier
        )
        company_ids = [r[0] for r in q_obj.with_entities(Company.id).all()]
    else:
        company_ids = _parse_id_list(raw_ids)

    ok, msg, count = SuperadminService.bulk_companies_action(
        company_ids=company_ids,
        action=action,
        actor_user=current_user,
        reason=reason,
        plan_tier=plan_tier,
        superadmin_password=superadmin_password
    )

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        if ok:
            flash(msg, 'success')
        return jsonify({
            'success': ok,
            'message': msg,
            'affected_count': count
        }), (200 if ok else 400)

    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.companies'))


@superadmin_bp.route('/companies/export', methods=['GET', 'POST'])
@superadmin_required
def companies_export():
    """Export selected or filtered organization records as a downloadable CSV."""
    if request.method == 'POST':
        raw_ids = request.form.getlist('company_ids') or request.form.get('company_ids') or (
            (request.get_json(silent=True) or {}).get('company_ids') if request.is_json else None
        )
    else:
        raw_ids = request.args.get('ids') or request.args.getlist('company_ids')

    company_ids = _parse_id_list(raw_ids)
    search = request.values.get('q', '').strip()
    status_filter = request.values.get('status', 'all').strip()
    industry_filter = request.values.get('industry', '').strip()
    tier_filter = request.values.get('tier', '').strip()
    sort_by = request.values.get('sort', 'created_desc').strip()

    csv_data = SuperadminService.export_companies_csv(
        company_ids=company_ids if company_ids else None,
        search=search,
        status_filter=status_filter,
        industry_filter=industry_filter,
        tier_filter=tier_filter,
        sort_by=sort_by
    )

    SuperadminService.record_audit(
        action='COMPANY_RECORDS_EXPORTED',
        category='COMPANY',
        updated_values={'selected_count': len(company_ids) if company_ids else 'all_filtered'},
        details=f"Exported {'selected (' + str(len(company_ids)) + ')' if company_ids else 'filtered'} organization records to CSV.",
        actor_user=current_user
    )

    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    filename = f"aevoryn_organizations_{timestamp}.csv"
    return Response(
        csv_data,
        mimetype='text/csv; charset=utf-8',
        headers={'Content-Disposition': f'attachment; filename="{filename}"'}
    )


@superadmin_bp.route('/companies/<int:company_id>', methods=['GET', 'POST'])
@superadmin_required
def company_detail(company_id):
    if request.method == 'POST':
        logo_file = request.files.get('logo_file')
        form_data = request.get_json(silent=True) if request.is_json else request.form
        ok, msg = SuperadminService.update_company(company_id, form_data or {}, logo_file=logo_file)
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            if ok:
                flash(msg, 'success')
            return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
        flash(msg, 'success' if ok else 'danger')
        return redirect(request.referrer or url_for('superadmin.company_detail', company_id=company_id))

    detail = SuperadminService.get_company_detail(company_id)
    if not detail:
        abort(404)

    return render_template(
        'superadmin/company_detail.html',
        detail=detail,
        company=detail['company'],
        currencies=list(CURRENCY_SYMBOLS.keys()),
        countries=sorted(list(COUNTRY_DATA.keys())),
        company_roles=COMPANY_ROLES,
        active_nav='companies'
    )


@superadmin_bp.route('/companies/<int:company_id>/status', methods=['POST'])
@superadmin_required
def company_status(company_id):
    new_status = request.form.get('status') or (request.json.get('status') if request.is_json else '')
    reason = request.form.get('reason') or (request.json.get('reason') if request.is_json else '')
    ok, msg = SuperadminService.change_company_status(company_id, new_status, reason=reason)
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.company_detail', company_id=company_id))


@superadmin_bp.route('/companies/<int:company_id>/delete', methods=['POST'])
@superadmin_required
def company_delete(company_id):
    if request.is_json:
        data = request.get_json(silent=True) or {}
        confirmation_name = (data.get('confirm_company_name') or '').strip()
        superadmin_password = (data.get('superadmin_password') or '').strip()
        quick_delete = bool(data.get('quick_delete'))
    else:
        confirmation_name = (request.form.get('confirm_company_name') or '').strip()
        superadmin_password = (request.form.get('superadmin_password') or '').strip()
        quick_delete = request.form.get('quick_delete') in ('1', 'true', 'yes', 'on')

    ok, msg = SuperadminService.delete_company_permanently(
        company_id=company_id,
        confirmation_name=confirmation_name,
        superadmin_password=superadmin_password,
        actor_user=current_user,
        require_exact_name=not quick_delete,
        require_password=not quick_delete
    )
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        if ok:
            flash(msg, 'success')
        return jsonify({'success': ok, 'message': msg, 'redirect': url_for('superadmin.companies') if ok else None}), (200 if ok else 400)

    flash(msg, 'success' if ok else 'danger')
    if ok:
        ref = request.referrer or ''
        if '/dashboard' in ref:
            return redirect(url_for('superadmin.dashboard'))
        return redirect(url_for('superadmin.companies'))
    return redirect(request.referrer or url_for('superadmin.company_detail', company_id=company_id))


# ══════════════════════════════════════════════════════════════════════════
# GLOBAL USERS MANAGEMENT
# ══════════════════════════════════════════════════════════════════════════
@superadmin_bp.route('/users')
@superadmin_required
def users():
    search = request.args.get('q', '').strip()
    company_id = request.args.get('company_id', type=int)
    role_filter = request.args.get('role', '').strip()
    status_filter = request.args.get('status', 'all').strip()
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)

    listing = SuperadminService.list_users(
        search=search,
        company_id=company_id,
        role_filter=role_filter,
        status_filter=status_filter,
        page=page,
        per_page=per_page
    )
    all_companies = Company.query.order_by(Company.company_name.asc()).all()

    return render_template(
        'superadmin/users.html',
        listing=listing,
        all_companies=all_companies,
        company_roles=COMPANY_ROLES,
        search=search,
        selected_company_id=company_id,
        role_filter=role_filter,
        status_filter=status_filter,
        per_page=per_page,
        active_nav='users'
    )


@superadmin_bp.route('/users/bulk-action', methods=['POST'])
@superadmin_required
def users_bulk_action():
    """Execute bulk status, role, session revocation, or delete actions across selected users."""
    if request.is_json:
        data = request.get_json(silent=True) or {}
        raw_ids = data.get('user_ids') or data.get('ids') or []
        action = (data.get('action') or '').strip()
        role = (data.get('role') or '').strip()
    else:
        raw_ids = request.form.getlist('user_ids') or request.form.get('user_ids') or request.form.get('ids') or []
        action = (request.form.get('action') or '').strip()
        role = (request.form.get('role') or '').strip()

    user_ids = _parse_id_list(raw_ids)
    ok, msg, count = SuperadminService.bulk_users_action(
        user_ids=user_ids,
        action=action,
        actor_user=current_user,
        role=role
    )

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        if ok:
            flash(msg, 'success')
        return jsonify({
            'success': ok,
            'message': msg,
            'affected_count': count
        }), (200 if ok else 400)

    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.users'))


@superadmin_bp.route('/users/<int:user_id>', methods=['GET', 'POST'])
@superadmin_required
def user_detail(user_id):
    target_user = db.session.get(User, user_id)
    if not target_user:
        abort(404)

    if request.method == 'POST':
        ok, msg = SuperadminService.update_user_by_superadmin(user_id, request.form)
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
        flash(msg, 'success' if ok else 'danger')
        return redirect(url_for('superadmin.user_detail', user_id=user_id))

    all_companies = Company.query.order_by(Company.company_name.asc()).all()
    sessions = UserSessionRecord.query.filter_by(user_id=target_user.id).order_by(UserSessionRecord.created_at.desc()).limit(15).all()
    user_audits = GlobalAuditLog.query.filter(
        (GlobalAuditLog.target_user_id == target_user.id) | (GlobalAuditLog.actor_user_id == target_user.id)
    ).order_by(GlobalAuditLog.created_at.desc()).limit(25).all()

    return render_template(
        'superadmin/user_detail.html',
        target_user=target_user,
        all_companies=all_companies,
        company_roles=COMPANY_ROLES,
        sessions=sessions,
        user_audits=user_audits,
        active_nav='users'
    )


@superadmin_bp.route('/users/<int:user_id>/status', methods=['POST'])
@superadmin_required
def user_status(user_id):
    new_status = request.form.get('status') or (request.json.get('status') if request.is_json else '')
    ok, msg = SuperadminService.change_user_status(user_id, new_status)
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.user_detail', user_id=user_id))


@superadmin_bp.route('/users/<int:user_id>/delete', methods=['POST'])
@superadmin_required
def user_delete(user_id):
    ok, msg = SuperadminService.delete_user_by_superadmin(user_id, actor_user=current_user)
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        if ok:
            flash(msg, 'success')
        return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.users'))


@superadmin_bp.route('/users/<int:user_id>/revoke-sessions', methods=['POST'])
@superadmin_required
def user_revoke_sessions(user_id):
    ok, msg = SuperadminService.revoke_user_sessions(user_id)
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.user_detail', user_id=user_id))


@superadmin_bp.route('/users/<int:user_id>/reset-password', methods=['POST'])
@superadmin_required
def user_reset_password(user_id):
    if request.is_json:
        data = request.get_json(silent=True) or {}
        new_password = data.get('new_password') or data.get('temporary_password') or ''
        superadmin_password = data.get('superadmin_password') or ''
        force_change = bool(data.get('force_change'))
    else:
        new_password = request.form.get('new_password') or request.form.get('temporary_password') or ''
        superadmin_password = request.form.get('superadmin_password') or ''
        force_change = request.form.get('force_change') in ('1', 'true', 'yes', 'on')

    ok, msg = SuperadminService.set_temporary_password_by_superadmin(
        target_user_id=user_id,
        temp_password=new_password,
        superadmin_password=superadmin_password,
        actor_user=current_user,
        force_change=force_change
    )
    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': ok, 'message': msg}), (200 if ok else 400)
    flash(msg, 'success' if ok else 'danger')
    return redirect(request.referrer or url_for('superadmin.user_detail', user_id=user_id))


@superadmin_bp.route('/users/<int:user_id>/impersonate', methods=['POST'])
@superadmin_required
def impersonate_user(user_id):
    target_user = db.session.get(User, user_id)
    if not target_user:
        flash('Target user account not found.', 'danger')
        return redirect(url_for('superadmin.users'))

    if target_user.id == current_user.id:
        flash('You are already active on this account.', 'info')
        return redirect(url_for('superadmin.dashboard'))

    # Store superadmin credential markers in session to facilitate 1-click return
    session['impersonator_superadmin_id'] = current_user.id
    session['impersonator_superadmin_username'] = current_user.username

    SuperadminService.record_audit(
        action='USER_IMPERSONATION_STARTED',
        category='SECURITY',
        target_company_id=target_user.company_id,
        target_company_name=target_user.company.company_name if target_user.company else None,
        target_user_id=target_user.id,
        target_username=target_user.username,
        details=f"Global Superadmin '{current_user.username}' assumed executive session control as '{target_user.username}'.",
        actor_user=current_user
    )

    login_user(target_user)
    if target_user.company_id:
        session['company_id'] = target_user.company_id
        if target_user.company:
            session['company_name'] = target_user.company.company_name
            session['company_currency'] = target_user.company.currency
            session['currency_symbol'] = CURRENCY_SYMBOLS.get(target_user.company.currency, '$')

    flash(f"Executive Impersonation Activated: You are now logged in as '{target_user.username}' with full tenant access.", 'warning')
    return redirect(url_for('dashboard.index'))


@superadmin_bp.route('/exit-impersonation')
def exit_impersonation():
    sa_id = session.get('impersonator_superadmin_id')
    if not sa_id:
        flash('No active impersonation session found.', 'info')
        return redirect(url_for('superadmin.dashboard'))

    superadmin = db.session.get(User, sa_id)
    if not superadmin or not getattr(superadmin, 'is_global_superadmin', False):
        flash('Global Superadmin session could not be restored.', 'danger')
        return redirect(url_for('auth.login'))

    session.pop('impersonator_superadmin_id', None)
    session.pop('impersonator_superadmin_username', None)
    login_user(superadmin)

    SuperadminService.record_audit(
        action='USER_IMPERSONATION_ENDED',
        category='SECURITY',
        details=f"Global Superadmin '{superadmin.username}' exited user session and returned to the Global Control Plane.",
        actor_user=superadmin
    )

    flash(f"Returned to Global Superadmin '{superadmin.username}'.", 'success')
    return redirect(url_for('superadmin.users'))


# ══════════════════════════════════════════════════════════════════════════
# GLOBAL PLATFORM CONTROL
# ══════════════════════════════════════════════════════════════════════════
@superadmin_bp.route('/platform', methods=['GET', 'POST'])
@superadmin_required
def platform_control():
    if request.method == 'POST':
        SuperadminService.ensure_default_platform_settings()
        rows = PlatformSetting.query.all()
        prev_dict = {r.key: r.value for r in rows}
        updated_dict = {}

        for row in rows:
            if row.value_type == 'bool':
                # Checkbox fields or explicit form flags
                if f"present_{row.key}" in request.form or row.key in request.form:
                    val = 'true' if request.form.get(row.key) in ('true', 'on', '1', 'yes') else 'false'
                    if row.value != val:
                        row.value = val
                        row.updated_by_user_id = current_user.id
                        updated_dict[row.key] = val
            else:
                if row.key in request.form:
                    val = request.form.get(row.key, '').strip()
                    if row.value != val:
                        row.value = val
                        row.updated_by_user_id = current_user.id
                        updated_dict[row.key] = val

        db.session.commit()
        if updated_dict:
            SuperadminService.record_audit(
                action='PLATFORM_CONFIGURATION_UPDATED',
                category='PLATFORM',
                previous_values={k: prev_dict.get(k) for k in updated_dict},
                updated_values=updated_dict,
                details=f"Updated {len(updated_dict)} global platform setting(s)."
            )
        flash('Global platform configuration saved and applied.', 'success')
        return redirect(url_for('superadmin.platform_control'))

    settings_dict = SuperadminService.get_all_settings_dict()
    health_summary = SuperadminService.get_system_health_summary()
    storage_info = SuperadminService.calculate_storage_utilization()

    from database.models.job import BackgroundJob
    jobs_total = BackgroundJob.query.count()
    jobs_recent = BackgroundJob.query.order_by(BackgroundJob.created_at.desc()).limit(8).all()

    return render_template(
        'superadmin/platform_control.html',
        settings=settings_dict,
        health=health_summary,
        storage=storage_info,
        jobs_total=jobs_total,
        jobs_recent=jobs_recent,
        active_nav='platform'
    )


# ══════════════════════════════════════════════════════════════════════════
# SUPERADMIN PROFILE & ACCOUNT SETTINGS
# ══════════════════════════════════════════════════════════════════════════
@superadmin_bp.route('/profile', methods=['GET', 'POST'])
@superadmin_required
def profile():
    if request.method == 'POST':
        action_type = request.form.get('action_type', 'update_profile')

        if action_type == 'update_profile':
            prev = {
                'full_name': current_user.display_name,
                'email': current_user.email,
                'job_title': current_user.job_title,
                'bio': current_user.bio,
                'phone': current_user.phone
            }
            full_name = (request.form.get('full_name') or '').strip()
            email = (request.form.get('email') or '').strip()
            job_title = (request.form.get('job_title') or '').strip()
            bio = (request.form.get('bio') or '').strip()
            phone = (request.form.get('phone') or '').strip()

            if email and email.lower() != current_user.email.lower():
                clash = User.query.filter(db.func.lower(User.email) == email.lower(), User.id != current_user.id).first()
                if clash:
                    flash('That email address is already associated with another account.', 'danger')
                    return redirect(url_for('superadmin.profile'))
                current_user.email = email

            if full_name:
                current_user.full_name = full_name
                parts = full_name.split(' ', 1)
                current_user.first_name = parts[0]
                current_user.last_name = parts[1] if len(parts) > 1 else ''

            current_user.job_title = job_title
            current_user.bio = bio
            current_user.phone = phone

            notif_prefs = {
                'security_alerts': request.form.get('notif_security') in ('on', 'true', '1'),
                'company_registrations': request.form.get('notif_registrations') in ('on', 'true', '1'),
                'audit_digests': request.form.get('notif_audit') in ('on', 'true', '1'),
                'system_health_warnings': request.form.get('notif_health') in ('on', 'true', '1'),
            }
            current_user.notification_prefs = json.dumps(notif_prefs)

            avatar_file = request.files.get('avatar_file')
            if avatar_file and getattr(avatar_file, 'filename', ''):
                from routes.uploads import validate_and_extract_image, persist_image_asset
                raw_bytes, ext, mime_type, err = validate_and_extract_image(avatar_file)
                if err:
                    flash(f'Profile photo error: {err}', 'danger')
                    return redirect(url_for('superadmin.profile'))
                rel_path, b64_data = persist_image_asset(raw_bytes, ext, 'avatars', f"superadmin_{current_user.id}")
                current_user.avatar_path = rel_path
                current_user.avatar_data = b64_data
                current_user.avatar_mime = mime_type
                current_user.avatar_updated_at = datetime.utcnow()

            current_user.updated_at = datetime.utcnow()
            db.session.commit()

            SuperadminService.record_audit(
                action='SUPERADMIN_PROFILE_UPDATED',
                category='USER',
                target_user_id=current_user.id,
                target_username=current_user.username,
                previous_values=prev,
                updated_values={
                    'full_name': current_user.display_name,
                    'email': current_user.email,
                    'job_title': current_user.job_title,
                    'has_avatar': current_user.has_avatar
                },
                details='Updated Global Superadmin profile and preferences.'
            )
            flash('Superadmin profile updated and persisted.', 'success')

        elif action_type == 'change_password':
            cur_pw = (request.form.get('current_password') or '').strip()
            new_pw = (request.form.get('new_password') or '').strip()
            conf_pw = (request.form.get('confirm_password') or '').strip()

            if not verify_password(cur_pw, current_user.password_hash):
                flash('Current password verification failed.', 'danger')
            elif len(new_pw) < 8:
                flash('New password must be at least 8 characters long.', 'danger')
            elif new_pw != conf_pw:
                flash('New passwords do not match.', 'danger')
            else:
                current_user.set_password(new_pw)
                current_user.must_change_password = False
                db.session.commit()
                SuperadminService.record_audit(
                    action='SUPERADMIN_PASSWORD_CHANGED',
                    category='SECURITY',
                    target_user_id=current_user.id,
                    target_username=current_user.username,
                    details='Global Superadmin changed account password.'
                )
                flash('Password updated successfully.', 'success')

        elif action_type == 'configure_mfa':
            enable_mfa = request.form.get('mfa_action') == 'enable'
            if enable_mfa:
                secret = request.form.get('mfa_secret') or SuperadminService.generate_totp_secret()
                backup_codes = [f"AEV-{i:02d}{datetime.utcnow().microsecond % 10000:04d}" for i in range(1, 5)]
                current_user.mfa_secret = secret
                current_user.mfa_enabled = True
                current_user.mfa_backup_codes = json.dumps(backup_codes)
                session['mfa_verified'] = True
                db.session.commit()
                SuperadminService.record_audit(
                    action='SUPERADMIN_MFA_ENABLED',
                    category='SECURITY',
                    target_user_id=current_user.id,
                    target_username=current_user.username,
                    details='Enabled TOTP Multi-Factor Authentication on Global Superadmin account.'
                )
                flash('Multi-Factor Authentication enabled for Global Superadmin.', 'success')
            else:
                current_user.mfa_enabled = False
                db.session.commit()
                SuperadminService.record_audit(
                    action='SUPERADMIN_MFA_DISABLED',
                    category='SECURITY',
                    target_user_id=current_user.id,
                    target_username=current_user.username,
                    details='Disabled Multi-Factor Authentication on Global Superadmin account.'
                )
                flash('Multi-Factor Authentication disabled.', 'info')

        elif action_type == 'terminate_other_sessions':
            cur_tok = session.get('session_record_token')
            count = SuperadminService.terminate_other_sessions(current_user, current_token=cur_tok)
            flash(f'Terminated {count} other session(s) and rotated session version token.', 'success')

        return redirect(url_for('superadmin.profile'))

    candidate_secret = current_user.mfa_secret or SuperadminService.generate_totp_secret()
    sample_totp = SuperadminService.compute_totp_code(candidate_secret)
    backup_codes = []
    if current_user.mfa_backup_codes:
        try:
            backup_codes = json.loads(current_user.mfa_backup_codes)
        except Exception:
            pass

    active_sessions = UserSessionRecord.query.filter_by(user_id=current_user.id, is_active=True).order_by(UserSessionRecord.last_seen_at.desc()).all()
    session_history = UserSessionRecord.query.filter_by(user_id=current_user.id).order_by(UserSessionRecord.created_at.desc()).limit(15).all()
    security_activity = GlobalAuditLog.query.filter(
        (GlobalAuditLog.actor_user_id == current_user.id) | (GlobalAuditLog.target_user_id == current_user.id)
    ).order_by(GlobalAuditLog.created_at.desc()).limit(20).all()

    return render_template(
        'superadmin/profile.html',
        candidate_secret=candidate_secret,
        sample_totp=sample_totp,
        backup_codes=backup_codes,
        notif_prefs=current_user.get_notification_prefs(),
        active_sessions=active_sessions,
        session_history=session_history,
        security_activity=security_activity,
        current_session_token=session.get('session_record_token'),
        active_nav='profile'
    )


# ══════════════════════════════════════════════════════════════════════════
# GLOBAL IMMUTABLE AUDIT TRAIL
# ══════════════════════════════════════════════════════════════════════════
@superadmin_bp.route('/audit')
@superadmin_required
def audit_trail():
    search = request.args.get('q', '').strip()
    category = request.args.get('category', '').strip()
    status = request.args.get('status', '').strip()
    company_id = request.args.get('company_id', type=int)
    page = request.args.get('page', 1, type=int)
    per_page = 30

    query = GlobalAuditLog.query
    if search:
        like_q = f"%{search}%"
        query = query.filter(
            (GlobalAuditLog.action.ilike(like_q)) |
            (GlobalAuditLog.actor_username.ilike(like_q)) |
            (GlobalAuditLog.target_company_name.ilike(like_q)) |
            (GlobalAuditLog.target_username.ilike(like_q)) |
            (GlobalAuditLog.details.ilike(like_q)) |
            (GlobalAuditLog.correlation_id.ilike(like_q))
        )
    if category:
        query = query.filter(GlobalAuditLog.category == category)
    if status:
        query = query.filter(GlobalAuditLog.result_status == status)
    if company_id:
        query = query.filter(GlobalAuditLog.target_company_id == company_id)

    query = query.order_by(GlobalAuditLog.created_at.desc())
    total = query.count()
    logs = query.offset((max(1, page) - 1) * per_page).limit(per_page).all()
    all_companies = Company.query.order_by(Company.company_name.asc()).all()

    return render_template(
        'superadmin/audit.html',
        logs=logs,
        total=total,
        page=page,
        per_page=per_page,
        pages=max(1, (total + per_page - 1) // per_page),
        search=search,
        category=category,
        status=status,
        selected_company_id=company_id,
        all_companies=all_companies,
        active_nav='audit'
    )
