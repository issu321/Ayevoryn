"""
AEVORYN / INSIGHT-PULSE
ENTERPRISE RISK ENGINE ROUTES (STAGE 17)
Provides secure, RBAC-guarded, multi-tenant controllers for operational threshold scans,
interactive heatmap visualization, mitigation tracking, and risk lifecycle management.
"""

from flask import Blueprint, render_template, request, jsonify, session, flash, redirect, url_for, abort
from flask_login import login_required, current_user
from database.models.risk import Risk, RiskFactor, RiskSource, RiskStatus
from services.risk_service import RiskService
from services.risk import OperationalRiskEngine
from config.constants import RISK_CATEGORIES, RISK_LABELS
from security.rbac import Permission, permission_required
from database.db import db

risk_engine_bp = Blueprint('risk_engine', __name__)


@risk_engine_bp.route('/')
@login_required
def index():
    company_id = session.get('company_id')
    # Assess risks with light evaluation
    risks = RiskService.assess_all_risks(company_id, run_operational_scan=False)
    summary = RiskService.get_risk_summary(company_id)
    evaluations = OperationalRiskEngine.evaluate_all(company_id)
    
    # Filter support
    filter_status = request.args.get('filter', 'all')
    if filter_status == 'active':
        display_risks = [r for r in risks if r.status == RiskStatus.ACTIVE]
    elif filter_status == 'automated':
        display_risks = [r for r in risks if r.is_automated and r.status == RiskStatus.ACTIVE]
    elif filter_status == 'manual':
        display_risks = [r for r in risks if not r.is_automated and r.status == RiskStatus.ACTIVE]
    elif filter_status == 'mitigated':
        display_risks = [r for r in risks if r.status == RiskStatus.MITIGATED]
    elif filter_status == 'resolved':
        display_risks = [r for r in risks if r.status == RiskStatus.RESOLVED]
    else:
        display_risks = risks

    risks_data = [r.to_dict() for r in display_risks]
    
    risks_by_category = {}
    for cat in RISK_CATEGORIES:
        risks_by_category[cat] = [r for r in display_risks if r.category == cat]
    
    return render_template('risk/risk_engine.html',
                         risks=display_risks,
                         all_risks_count=len(risks),
                         summary=summary,
                         evaluations=evaluations,
                         categories=RISK_CATEGORIES,
                         category_labels=RISK_LABELS,
                         risks_by_category=risks_by_category,
                         risks_data=risks_data,
                         current_filter=filter_status)


@risk_engine_bp.route('/heatmap')
@login_required
def heatmap():
    company_id = session.get('company_id')
    risks = Risk.query.filter_by(company_id=company_id).all()
    heatmap_data = [{
        'id': r.id,
        'name': r.name,
        'category': r.category,
        'probability': r.probability,
        'impact': r.impact,
        'score': r.risk_score,
        'level': r.risk_level,
        'status': r.status,
        'is_automated': r.is_automated,
        'source': r.source,
        'trigger_metric': r.trigger_metric,
        'evidence': r.get_evidence()
    } for r in risks]
    summary = RiskService.get_risk_summary(company_id)
    return render_template('risk/risk_heatmap.html', heatmap_data=heatmap_data, summary=summary)


@risk_engine_bp.route('/evaluate', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def evaluate_operational_risks():
    """Trigger an immediate live operational threshold scan for the active tenant."""
    company_id = session.get('company_id')
    result = RiskService.evaluate_operational_risks(company_id, actor_user_id=current_user.id, publish_events=True)

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(result)

    breached = result.get('breached_count', 0)
    resolved = result.get('resolved_count', 0)
    flash(f"Operational risk evaluation complete: {breached} active threshold breach(es) identified, {resolved} resolved.", "info")
    return redirect(url_for('risk_engine.index'))


@risk_engine_bp.route('/create', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def create_risk():
    """Create a manual enterprise risk assessment with RBAC and CSRF protection."""
    company_id = session.get('company_id')
    name = request.form.get('name', '').strip()
    category = request.form.get('category', 'operational')
    description = request.form.get('description', '').strip()
    probability = float(request.form.get('probability', 0.5))
    impact = float(request.form.get('impact', 0.5))
    mitigation_plan = request.form.get('mitigation_plan', '').strip()

    if not name:
        if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': False, 'error': 'Risk name is required'}), 400
        flash('Risk name is required.', 'danger')
        return redirect(url_for('risk_engine.index'))

    risk = RiskService.create_risk(
        company_id=company_id,
        name=name,
        category=category,
        description=description,
        probability=probability,
        impact=impact,
        mitigation_plan=mitigation_plan,
        owner_id=current_user.id
    )

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'risk': risk.to_dict()})

    flash(f'Risk assessment "{risk.name}" created successfully.', 'success')
    return redirect(url_for('risk_engine.index'))


@risk_engine_bp.route('/update/<int:risk_id>', methods=['POST'])
@login_required
@permission_required(Permission.DATA_WRITE)
def update_risk(risk_id):
    """Update risk status, parameters, or mitigation plan with tenant IDOR protection."""
    company_id = session.get('company_id')
    risk = Risk.query.get_or_404(risk_id)
    if risk.company_id != company_id:
        abort(404)

    kwargs = {}
    if 'status' in request.form:
        kwargs['status'] = request.form.get('status')
    if 'mitigation_plan' in request.form:
        kwargs['mitigation_plan'] = request.form.get('mitigation_plan')
    if 'probability' in request.form and request.form.get('probability'):
        kwargs['probability'] = float(request.form.get('probability'))
    if 'impact' in request.form and request.form.get('impact'):
        kwargs['impact'] = float(request.form.get('impact'))

    updated_risk = RiskService.update_risk(risk_id, company_id, **kwargs)

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'risk': updated_risk.to_dict()})

    flash(f'Risk "{risk.name}" updated successfully.', 'success')
    return redirect(url_for('risk_engine.index'))


@risk_engine_bp.route('/delete/<int:risk_id>', methods=['POST'])
@login_required
@permission_required(Permission.DATA_DELETE)
def delete_risk(risk_id):
    """Delete a risk assessment with tenant IDOR protection."""
    company_id = session.get('company_id')
    risk = Risk.query.get_or_404(risk_id)
    if risk.company_id != company_id:
        abort(404)

    name = risk.name
    RiskService.delete_risk(risk_id, company_id)

    if request.is_json or request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': True, 'deleted_id': risk_id})

    flash(f'Risk "{name}" deleted successfully.', 'info')
    return redirect(url_for('risk_engine.index'))


@risk_engine_bp.route('/api/assess', methods=['POST'])
@login_required
def api_assess():
    company_id = session.get('company_id')
    summary = RiskService.get_risk_summary(company_id)
    return jsonify(summary)


@risk_engine_bp.route('/api/summary', methods=['GET'])
@login_required
def api_summary():
    company_id = session.get('company_id')
    summary = RiskService.get_risk_summary(company_id)
    return jsonify(summary)


@risk_engine_bp.route('/api/evaluations', methods=['GET'])
@login_required
def api_evaluations():
    company_id = session.get('company_id')
    evaluations = OperationalRiskEngine.evaluate_all(company_id)
    return jsonify([ev.to_dict() for ev in evaluations])
