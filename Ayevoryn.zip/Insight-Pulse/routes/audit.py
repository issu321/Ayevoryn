"""
AUDIT ROUTES - Immutable Audit Trail, Event Inspection & Compliance Feeds.
"""

from flask import Blueprint, render_template, request, jsonify, session, Response
from flask_login import login_required, current_user
from security.tenant import get_current_company_id
from security.rbac import permission_required, Permission
from services.audit_service import AuditService
from datetime import datetime

audit_bp = Blueprint('audit', __name__)


@audit_bp.route('/')
@login_required
@permission_required(Permission.AUDIT_VIEW)
def index():
    """Render the Enterprise Audit Trail & Timeline interface."""
    company_id = get_current_company_id()
    summary = AuditService.get_audit_summary(company_id)
    initial_events = AuditService.get_events(company_id, page=1, per_page=20)
    
    return render_template(
        'audit/audit_trail.html',
        summary=summary,
        initial_events=initial_events
    )


@audit_bp.route('/api/events')
@login_required
@permission_required(Permission.AUDIT_VIEW)
def api_events():
    """JSON API to query and filter domain events."""
    company_id = get_current_company_id()
    
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 25, type=int)
    actor_name = request.args.get('actor_name')
    aggregate_type = request.args.get('aggregate_type')
    aggregate_id = request.args.get('aggregate_id')
    event_type = request.args.get('event_type')
    search = request.args.get('search')
    
    start_str = request.args.get('start_date')
    end_str = request.args.get('end_date')
    start_date = None
    end_date = None
    
    if start_str:
        try:
            start_date = datetime.strptime(start_str, '%Y-%m-%d')
        except ValueError:
            pass
            
    if end_str:
        try:
            end_date = datetime.strptime(end_str, '%Y-%m-%d')
        except ValueError:
            pass

    result = AuditService.get_events(
        company_id=company_id,
        page=page,
        per_page=per_page,
        actor_name=actor_name,
        aggregate_type=aggregate_type,
        aggregate_id=aggregate_id,
        event_type=event_type,
        start_date=start_date,
        end_date=end_date,
        search=search
    )
    
    return jsonify({
        'success': True,
        'data': result['items'],
        'pagination': {
            'total': result['total'],
            'page': result['page'],
            'per_page': result['per_page'],
            'pages': result['pages']
        }
    })


@audit_bp.route('/api/entity/<aggregate_type>/<aggregate_id>')
@login_required
@permission_required(Permission.AUDIT_VIEW)
def api_entity_timeline(aggregate_type, aggregate_id):
    """Retrieve chronological mutation timeline with state diffs for a specific entity."""
    company_id = get_current_company_id()
    timeline = AuditService.get_entity_timeline(
        company_id=company_id,
        aggregate_type=aggregate_type,
        aggregate_id=aggregate_id
    )
    return jsonify({'success': True, 'timeline': timeline})


@audit_bp.route('/api/summary')
@login_required
@permission_required(Permission.AUDIT_VIEW)
def api_summary():
    """Retrieve 30-day activity overview and actor breakdown."""
    company_id = get_current_company_id()
    days = request.args.get('days', 30, type=int)
    summary = AuditService.get_audit_summary(company_id=company_id, days=days)
    return jsonify({'success': True, 'summary': summary})


@audit_bp.route('/export-csv')
@login_required
@permission_required(Permission.AUDIT_VIEW)
def export_csv():
    """Export filtered audit events as an RFC 4180 CSV attachment."""
    company_id = get_current_company_id()
    aggregate_type = request.args.get('aggregate_type')
    event_type = request.args.get('event_type')
    search = request.args.get('search')

    csv_data = AuditService.export_events_csv(
        company_id=company_id,
        aggregate_type=aggregate_type,
        event_type=event_type,
        search=search
    )

    timestamp = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    filename = f"audit_trail_{timestamp}.csv"

    return Response(
        csv_data,
        mimetype="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )
