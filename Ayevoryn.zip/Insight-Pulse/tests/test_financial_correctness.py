"""
Unit and integration tests for Stage 6 - Financial Correctness.
Verifies:
1. Elimination of the 30x runway month calculation error.
2. Reconciliation between Dashboard and Analytics runway methodologies.
3. Dashboard does not override real Employee/Customer counts with setup targets.
4. SimulationService preserves real negative and high-margin cost structures (removal of silent 80% cost override).
5. EnterpriseService does not double-count operating expenses in EBIT.
"""

import pytest
from datetime import datetime, date, timedelta
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.employee import Employee
from database.models.customer import Customer
from services.analytics_service import AnalyticsService
from services.simulation_service import SimulationService
from services.enterprise_service import EnterpriseService


@pytest.fixture
def app_and_client():
    """Create test application and test client."""
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    with app.test_client() as client:
        yield app, client


@pytest.fixture
def financial_fixture(app_and_client):
    """Create a company with specific financial records to test edge cases."""
    import uuid
    u_suffix = uuid.uuid4().hex[:8]
    username = f"cfo_{u_suffix}"
    email = f"cfo_{u_suffix}@solvencytech.com"
    app, client = app_and_client

    with app.app_context():
        company = Company(
            company_name=f"Solvency Tech Corp {u_suffix}",
            business_name=f"Solvency Tech Corp {u_suffix}",
            owner_name="CFO Jane",
            ceo_name="CEO John",
            industry="Software",
            currency="USD",
            annual_revenue=1200000.0,
            annual_revenue_target=1500000.0,
            annual_expenses_plan=900000.0,
            employee_count=100,      # Onboarding target: 100
            customer_count=500,      # Onboarding target: 500
            total_equity=100000.0    # $100,000 cash balance
        )
        db.session.add(company)
        db.session.commit()
        cid = company.id

        user = User(
            username=username,
            email=email,
            role="Admin",
            company_id=cid
        )
        user.set_password("SecurePassword123!")
        db.session.add(user)
        db.session.commit()
        uid = user.id

        yield {
            'company_id': cid,
            'user_id': uid,
            'username': username,
            'password': 'SecurePassword123!'
        }

        # Cleanup
        try:
            FinancialRecord.query.filter_by(company_id=cid).delete()
            FinancialAccount.query.filter_by(company_id=cid).delete()
            Employee.query.filter_by(company_id=cid).delete()
            Customer.query.filter_by(company_id=cid).delete()
            User.query.filter_by(id=uid).delete()
            Company.query.filter_by(id=cid).delete()
            db.session.commit()
        except Exception:
            db.session.rollback()


def test_runway_no_30x_overstatement(app_and_client, financial_fixture):
    """
    CRITICAL P0 TEST: Fix 30x runway bug.
    Given: Cash = $100,000, 30-day Expenses = $30,000 ($1,000/day).
    Buggy calculation: $100,000 / ($30,000 / 30) = 100.0 months (overstated by ~30x!).
    Correct calculation: $100,000 / $30,000 = 3.33 months.
    """
    app, client = app_and_client
    cid = financial_fixture['company_id']
    today = datetime.utcnow().date()

    with app.app_context():
        # Insert $30,000 of expenses over the trailing 30 days
        exp1 = FinancialRecord(company_id=cid, transaction_type='expense', amount=15000.0, transaction_date=today - timedelta(days=5))
        exp2 = FinancialRecord(company_id=cid, transaction_type='expense', amount=15000.0, transaction_date=today - timedelta(days=15))
        db.session.add_all([exp1, exp2])
        db.session.commit()

        summary = AnalyticsService.get_executive_summary(cid)
        runway_months = summary.get('runway_months')

        # Runway MUST be approximately 3.3 months, NOT 100 months
        assert runway_months is not None
        assert runway_months == pytest.approx(3.3, 0.1)
        assert runway_months < 10.0, "Runway must not exhibit 30x day-to-month inflation error!"


def test_dashboard_does_not_override_real_counts(app_and_client, financial_fixture):
    """
    Dashboard must NOT overwrite real Employee or Customer records with onboarding targets.
    Given: Target employees = 100, Target customers = 500.
    Actual in DB: 2 employees, 1 customer.
    """
    app, client = app_and_client
    cid = financial_fixture['company_id']

    with app.app_context():
        # Add 2 real employees
        e1 = Employee(company_id=cid, first_name="Dev1", last_name="Smith", status="active", salary=90000.0)
        e2 = Employee(company_id=cid, first_name="Dev2", last_name="Jones", status="active", salary=95000.0)
        # Add 1 real customer
        c1 = Customer(company_id=cid, first_name="Client1", company_name="Acme Corp", status="active", lifetime_value=3000.0)
        db.session.add_all([e1, e2, c1])
        db.session.commit()

    # Log in and check GET /dashboard
    login_resp = client.post('/login', data={
        'username': financial_fixture['username'],
        'password': financial_fixture['password']
    }, follow_redirects=True)
    assert login_resp.status_code == 200

    dash_resp = client.get('/dashboard')
    assert dash_resp.status_code == 200

    # Summary rendered in dashboard must reflect the actual 2 employees and 1 customer
    with app.app_context():
        summary = AnalyticsService.get_executive_summary(cid)
        assert summary['total_employees'] == 2, "Real employee count must not be overwritten by target (100)!"
        assert summary['total_customers'] == 1, "Real customer count must not be overwritten by target (500)!"
        assert summary['plan_headcount'] == 100
        assert summary['plan_customers'] == 500


def test_simulation_engine_preserves_negative_margin_unprofitable_company(app_and_client, financial_fixture):
    """
    P1 Finding 8.3: Silent erasure of real costs in SimulationService.
    When a company is operating at a loss (annual revenue $1,000,000, annual costs $1,500,000),
    margin is -50%. The simulation must NOT silently overwrite costs with 80% ($800,000).
    """
    app, client = app_and_client
    cid = financial_fixture['company_id']
    today = datetime.utcnow().date()

    with app.app_context():
        # Clear out records and add 12-month trailing actuals
        FinancialRecord.query.filter_by(company_id=cid).delete()
        # Revenue $1,000,000
        r = FinancialRecord(company_id=cid, transaction_type='revenue', amount=1000000.0, transaction_date=today - timedelta(days=60))
        # Expense $1,500,000 (Loss-making enterprise)
        e = FinancialRecord(company_id=cid, transaction_type='expense', amount=1500000.0, transaction_date=today - timedelta(days=60))
        db.session.add_all([r, e])
        db.session.commit()

        # Fetch baseline from SimulationService
        baseline = SimulationService._get_company_baseline(cid)

        # Baseline costs must reflect the real $1,500,000 expenses, NOT silently overridden with 80% ($800,000)
        assert baseline['revenue'] == 1000000.0
        assert baseline['costs'] == 1500000.0
        assert baseline['profit'] == -500000.0
        assert baseline['costs'] > baseline['revenue'], "Actual unprofitable costs must not be silently replaced with 80% of revenue!"


def test_simulation_engine_preserves_high_margin_saas_company(app_and_client, financial_fixture):
    """
    When a company has 92% gross margin (Revenue $1,000,000, Cost $80,000),
    SimulationService must NOT overwrite costs with 80% of revenue ($800,000).
    """
    app, client = app_and_client
    cid = financial_fixture['company_id']
    today = datetime.utcnow().date()

    with app.app_context():
        FinancialRecord.query.filter_by(company_id=cid).delete()
        r = FinancialRecord(company_id=cid, transaction_type='revenue', amount=1000000.0, transaction_date=today - timedelta(days=60))
        e = FinancialRecord(company_id=cid, transaction_type='expense', amount=80000.0, transaction_date=today - timedelta(days=60))
        db.session.add_all([r, e])
        db.session.commit()

        baseline = SimulationService._get_company_baseline(cid)

        # Baseline costs must reflect real $80,000 costs, NOT overridden to $800,000
        assert baseline['revenue'] == 1000000.0
        assert baseline['costs'] == 80000.0
        assert baseline['profit'] == 920000.0
        assert baseline['costs'] < 200000.0, "High-margin cost structure must not be silently replaced with 80% of revenue!"


def test_enterprise_service_no_double_deduction(app_and_client, financial_fixture):
    """
    Finding 8.4: Verify that EnterpriseService does not double-count operating expenses in EBIT.
    """
    app, client = app_and_client
    cid = financial_fixture['company_id']
    today = datetime.utcnow().date()

    with app.app_context():
        comp = Company.query.get(cid)
        FinancialRecord.query.filter_by(company_id=cid).delete()

        # Revenue: $500,000
        r = FinancialRecord(company_id=cid, transaction_type='revenue', category='SaaS', amount=500000.0, transaction_date=today - timedelta(days=30))
        # Expenses: $100,000 COGS, $150,000 OpEx (Total: $250,000)
        e1 = FinancialRecord(company_id=cid, transaction_type='expense', category='cogs', amount=100000.0, transaction_date=today - timedelta(days=30))
        e2 = FinancialRecord(company_id=cid, transaction_type='expense', category='marketing', amount=150000.0, transaction_date=today - timedelta(days=30))
        db.session.add_all([r, e1, e2])
        db.session.commit()

        EnterpriseService._calculate_financial_ratios_fortune500(comp)

        # EBIT must equal Revenue - Total Expenses = 500,000 - 250,000 = 250,000
        # Expected Operating Margin = 250,000 / 500,000 * 100 = 50.0%
        # Gross profit margin = (500,000 - 100,000 COGS) / 500,000 * 100 = 80.0%
        assert comp.operating_margin == pytest.approx(50.0, 0.5)
        assert comp.gross_profit_margin == pytest.approx(80.0, 0.5)
