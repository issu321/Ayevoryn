"""
AEVORYN / INSIGHT-PULSE
STAGE 15: SIMULATION ENGINE REALISM AUTOMATED TEST SUITE
Validates:
1. Monte Carlo stochastic simulation engine (distributions, percentiles P10/P50/P90, 95% CI, reproducibility, convergence).
2. Domain event emission (EventTypes.SIMULATION_EXECUTED dispatched to EventBus).
3. Zero mutation of live operational/financial state during simulation runs.
4. Computational backing of Customer Simulator (/customer/simulator/run).
5. Computational backing of Employee Simulator (/employee/simulator/run).
6. Computational backing of Supply Chain Simulator (/supply-chain/simulator/run).
7. Computational backing of Operations Simulator (/operations/simulator/run).
8. Multi-tenant isolation and IDOR protection on department/supplier references.
9. RBAC permission enforcement (Viewer rejected with 403 Forbidden).
"""

import pytest
from datetime import datetime, date
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.supplier import Supplier
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.financial import FinancialRecord
from database.models.simulation import Simulation
from database.models.business_event import BusinessEvent
from services.simulation_service import SimulationService
from services.events.types import EventTypes
from security.rbac import Role, Permission


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage15'
    })
    with app.app_context():
        db.create_all()

        comp_a = Company(
            company_name='Sim Alpha Corp',
            business_name='Sim Alpha',
            owner_name='Alice Simulator',
            ceo_name='Arthur Simulator',
            industry='Software',
            company_size='Medium',
            currency='USD',
            annual_revenue=2000000.0,
            annual_expenses_plan=1400000.0,
            customer_count=50,
            employee_count=10
        )
        comp_b = Company(
            company_name='Sim Beta Ltd',
            business_name='Sim Beta',
            owner_name='Bob Simulator',
            ceo_name='Boris Simulator',
            industry='Manufacturing',
            company_size='Small',
            currency='EUR',
            annual_revenue=800000.0,
            annual_expenses_plan=600000.0
        )
        db.session.add_all([comp_a, comp_b])
        db.session.commit()

        admin_a = User(
            username='sim_admin_a',
            email='admin@sim-alpha.com',
            role=Role.ADMIN,
            company_id=comp_a.id,
            is_active=True
        )
        admin_a.set_password('password123')

        viewer_a = User(
            username='sim_viewer_a',
            email='viewer@sim-alpha.com',
            role=Role.VIEWER,
            company_id=comp_a.id,
            is_active=True
        )
        viewer_a.set_password('password123')

        admin_b = User(
            username='sim_admin_b',
            email='admin@sim-beta.com',
            role=Role.ADMIN,
            company_id=comp_b.id,
            is_active=True
        )
        admin_b.set_password('password123')

        db.session.add_all([admin_a, viewer_a, admin_b])
        db.session.commit()

        dept_a = Department(
            company_id=comp_a.id,
            name='Alpha Engineering',
            code='AENG',
            budget=500000.0
        )
        dept_b = Department(
            company_id=comp_b.id,
            name='Beta Operations',
            code='BOPS',
            budget=300000.0
        )
        db.session.add_all([dept_a, dept_b])
        db.session.commit()

        supp_a = Supplier(
            company_id=comp_a.id,
            name='Alpha Cloud Services',
            category='Infrastructure',
            reliability_score=4.8
        )
        supp_b = Supplier(
            company_id=comp_b.id,
            name='Beta Raw Materials',
            category='Hardware',
            reliability_score=3.9
        )
        db.session.add_all([supp_a, supp_b])
        db.session.commit()

        cust_a = Customer(
            company_id=comp_a.id,
            first_name='Enterprise',
            last_name='Client X',
            company_name='Enterprise Client X',
            status='active',
            total_spent=10000.0
        )
        emp_a = Employee(
            company_id=comp_a.id,
            department_id=dept_a.id,
            first_name='Alice',
            last_name='Engineer',
            job_title='Lead Architect',
            salary=120000.0,
            status='active'
        )
        rec_rev = FinancialRecord(
            company_id=comp_a.id,
            transaction_type='revenue',
            amount=150000.0,
            transaction_date=date(2025, 6, 1)
        )
        rec_exp = FinancialRecord(
            company_id=comp_a.id,
            transaction_type='expense',
            amount=90000.0,
            transaction_date=date(2025, 6, 1)
        )
        db.session.add_all([cust_a, emp_a, rec_rev, rec_exp])
        db.session.commit()

        yield app

        db.session.remove()
        db.drop_all()


@pytest.fixture
def sim_context(app):
    """Provides IDs for testing."""
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Sim Alpha Corp').first()
        comp_b = Company.query.filter_by(company_name='Sim Beta Ltd').first()
        admin_a = User.query.filter_by(username='sim_admin_a').first()
        viewer_a = User.query.filter_by(username='sim_viewer_a').first()
        admin_b = User.query.filter_by(username='sim_admin_b').first()
        dept_a = Department.query.filter_by(code='AENG').first()
        dept_b = Department.query.filter_by(code='BOPS').first()
        supp_a = Supplier.query.filter_by(name='Alpha Cloud Services').first()
        supp_b = Supplier.query.filter_by(name='Beta Raw Materials').first()

        return {
            'comp_a_id': comp_a.id,
            'comp_b_id': comp_b.id,
            'admin_a_id': admin_a.id,
            'viewer_a_id': viewer_a.id,
            'admin_b_id': admin_b.id,
            'dept_a_id': dept_a.id,
            'dept_b_id': dept_b.id,
            'supp_a_id': supp_a.id,
            'supp_b_id': supp_b.id
        }


@pytest.fixture
def admin_client(app, sim_context):
    client = app.test_client()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(sim_context['admin_a_id'])
        sess['user_id'] = sim_context['admin_a_id']
        sess['company_id'] = sim_context['comp_a_id']
    return client


@pytest.fixture
def viewer_client(app, sim_context):
    client = app.test_client()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(sim_context['viewer_a_id'])
        sess['user_id'] = sim_context['viewer_a_id']
        sess['company_id'] = sim_context['comp_a_id']
    return client


def test_monte_carlo_statistical_properties():
    """Verify mathematical properties of the Monte Carlo stochastic engine."""
    mc = SimulationService.run_monte_carlo(
        revenue_before=1000000.0,
        cost_before=700000.0,
        revenue_after=1250000.0,
        cost_after=800000.0,
        iterations=1000,
        volatility=0.15,
        seed=42
    )

    assert mc['iterations'] == 1000
    assert mc['volatility'] == 0.15

    # Percentile ordering monotonicity
    assert mc['confidence_low_profit'] <= mc['p10_profit']
    assert mc['p10_profit'] <= mc['p25_profit']
    assert mc['p25_profit'] <= mc['p50_profit']
    assert mc['p50_profit'] <= mc['p75_profit']
    assert mc['p75_profit'] <= mc['p90_profit']
    assert mc['p90_profit'] <= mc['confidence_high_profit']

    # Revenue and Cost percentiles
    assert mc['confidence_low_revenue'] <= mc['p10_revenue'] <= mc['p50_revenue'] <= mc['p90_revenue'] <= mc['confidence_high_revenue']
    assert mc['p10_cost'] <= mc['p50_cost'] <= mc['p90_cost']

    # Empirical histogram bins
    assert len(mc['histogram_bins']) == 10
    total_count = sum(b['count'] for b in mc['histogram_bins'])
    assert total_count == 1000
    total_pct = sum(b['pct'] for b in mc['histogram_bins'])
    assert 99.0 <= total_pct <= 101.0

    # Probabilities
    assert 0.0 <= mc['prob_profitable'] <= 100.0
    assert 0.0 <= mc['prob_beat_baseline'] <= 100.0


def test_simulation_service_run_simulation_monte_carlo_enrichment(app, sim_context):
    """Verify that run_simulation executes Monte Carlo and emits SIMULATION_EXECUTED domain event."""
    with app.app_context():
        comp_id = sim_context['comp_a_id']
        user_id = sim_context['admin_a_id']

        sim = SimulationService.run_simulation(
            company_id=comp_id,
            user_id=user_id,
            sim_type='price_increase',
            name='Test Price Increase Monte Carlo',
            parameters={'current_price': 100.0, 'new_price': 115.0, 'elasticity': -1.2, 'iterations': 500, 'seed': 123},
            currency_symbol='$'
        )

        assert sim.id is not None
        assert sim.status == 'completed'
        assert sim.confidence_low is not None
        assert sim.confidence_high is not None
        assert sim.confidence_low < sim.confidence_high

        # Verify parsed results contain Monte Carlo
        res = sim.get_results()
        assert 'monte_carlo' in res
        mc = res['monte_carlo']
        assert mc['iterations'] == 500
        assert 'p10_profit' in mc
        assert 'p50_profit' in mc
        assert 'p90_profit' in mc

        # Verify domain event in business_events
        ev = BusinessEvent.query.filter_by(
            company_id=comp_id,
            event_type=EventTypes.SIMULATION_EXECUTED,
            aggregate_id=str(sim.id)
        ).first()

        assert ev is not None
        assert ev.get_payload()['sim_type'] == 'price_increase'
        assert 'p50_profit' in ev.get_payload()


def test_zero_mutation_of_live_operational_state(app, admin_client, sim_context):
    """Confirm executing simulations leaves live database records completely unmutated."""
    with app.app_context():
        comp_id = sim_context['comp_a_id']
        initial_fin_count = FinancialRecord.query.filter_by(company_id=comp_id).count()
        initial_emp_count = Employee.query.filter_by(company_id=comp_id).count()
        initial_cust_count = Customer.query.filter_by(company_id=comp_id).count()
        comp = db.session.get(Company, comp_id)
        initial_rev = comp.annual_revenue
        initial_exp = comp.annual_expenses_plan

    # Run customer simulation
    r1 = admin_client.post('/customer/simulator/run', json={'growth_rate': 25, 'retention_improvement': 10})
    assert r1.status_code == 200

    # Run employee simulation
    r2 = admin_client.post('/employee/simulator/run', json={'role': 'Director', 'salary': 180000, 'headcount': 2})
    assert r2.status_code == 200

    # Run supplier simulation
    r3 = admin_client.post('/supply-chain/simulator/run', json={'current_cost': 50, 'new_cost': 40, 'volume': 5000})
    assert r3.status_code == 200

    # Run operations simulation
    r4 = admin_client.post('/operations/simulator/run', json={'demand_increase_percent': 30})
    assert r4.status_code == 200

    # Verify zero mutations
    with app.app_context():
        comp_id = sim_context['comp_a_id']
        assert FinancialRecord.query.filter_by(company_id=comp_id).count() == initial_fin_count
        assert Employee.query.filter_by(company_id=comp_id).count() == initial_emp_count
        assert Customer.query.filter_by(company_id=comp_id).count() == initial_cust_count
        comp_after = db.session.get(Company, comp_id)
        assert comp_after.annual_revenue == initial_rev
        assert comp_after.annual_expenses_plan == initial_exp


def test_customer_simulator_run_endpoint(app, admin_client, sim_context):
    """Test customer simulator POST endpoint executes real model and creates DB record."""
    resp = admin_client.post('/customer/simulator/run', json={
        'growth_rate': 20.0,
        'retention_improvement': 6.0,
        'acquisition_channels': 'paid',
        'iterations': 500,
        'seed': 42
    })

    assert resp.status_code == 200
    data = resp.get_json()
    assert data['success'] is True
    assert data['sim_id'] is not None
    assert data['projected_customers'] > data['current_customers']
    assert data['net_customer_growth'] > 0
    assert 'monte_carlo' in data
    assert data['p10_profit'] <= data['p50_profit'] <= data['p90_profit']

    # Confirm Simulation record exists in DB
    with app.app_context():
        persisted = db.session.get(Simulation, data['sim_id'])
        assert persisted is not None
        assert persisted.company_id == sim_context['comp_a_id']
        assert persisted.sim_type == 'customer_growth'


def test_employee_simulator_run_endpoint(app, admin_client, sim_context):
    """Test employee simulator POST endpoint executes real model with department validation."""
    resp = admin_client.post('/employee/simulator/run', json={
        'role': 'Fullstack Engineer',
        'salary': 100000.0,
        'benefits': 20000.0,
        'department_id': sim_context['dept_a_id'],
        'headcount': 2,
        'iterations': 500,
        'seed': 99
    })

    assert resp.status_code == 200
    data = resp.get_json()
    assert data['success'] is True
    assert data['total_cost'] == 240000.0
    assert data['productivity_gain'] > data['total_cost']
    assert data['roi_pct'] > 0
    assert 'monte_carlo' in data
    assert data['p10_profit'] <= data['p50_profit'] <= data['p90_profit']


def test_supply_chain_simulator_run_endpoint(app, admin_client, sim_context):
    """Test supply chain simulator POST endpoint executes real model with supplier validation."""
    resp = admin_client.post('/supply-chain/simulator/run', json={
        'supplier_id': sim_context['supp_a_id'],
        'current_cost': 150.0,
        'new_cost': 110.0,
        'volume': 1200.0,
        'quality_rating': 4.5,
        'transition_cost': 6000.0,
        'lead_time_days': 10,
        'iterations': 500,
        'seed': 77
    })

    assert resp.status_code == 200
    data = resp.get_json()
    assert data['success'] is True
    assert data['monthly_savings'] == (150.0 - 110.0) * 1200.0
    assert data['annual_savings'] == data['monthly_savings'] * 12
    assert data['net_savings'] == data['annual_savings'] - 6000.0
    assert 'monte_carlo' in data


def test_operations_simulator_run_endpoint(app, admin_client, sim_context):
    """Test operations simulator POST endpoint executes real model with capacity calculations."""
    resp = admin_client.post('/operations/simulator/run', json={
        'department_id': sim_context['dept_a_id'],
        'demand_increase_percent': 25.0,
        'product_lines': 4,
        'seasonality_factor': 1.25,
        'iterations': 500,
        'seed': 55
    })

    assert resp.status_code == 200
    data = resp.get_json()
    assert data['success'] is True
    assert data['revenue_after'] > data['revenue_before']
    assert 'monte_carlo' in data
    assert data['p10_profit'] <= data['p50_profit'] <= data['p90_profit']


def test_simulator_cross_tenant_idor_protection(app, admin_client, sim_context):
    """Ensure Tenant Alpha cannot reference Tenant Beta's departments or suppliers."""
    # Cross-tenant department in employee simulator -> 404
    r1 = admin_client.post('/employee/simulator/run', json={
        'department_id': sim_context['dept_b_id'],
        'salary': 80000
    })
    assert r1.status_code == 404

    # Cross-tenant supplier in supply chain simulator -> 404
    r2 = admin_client.post('/supply-chain/simulator/run', json={
        'supplier_id': sim_context['supp_b_id'],
        'current_cost': 100,
        'new_cost': 80
    })
    assert r2.status_code == 404

    # Cross-tenant department in operations simulator -> 404
    r3 = admin_client.post('/operations/simulator/run', json={
        'department_id': sim_context['dept_b_id'],
        'demand_increase_percent': 20
    })
    assert r3.status_code == 404


def test_simulator_viewer_rbac_rejection(app, viewer_client, sim_context):
    """Verify that users with Viewer role (lacking Permission.SIMULATION_RUN) receive 403 Forbidden."""
    # Viewer cannot run customer simulator
    r1 = viewer_client.post('/customer/simulator/run', json={'growth_rate': 10})
    assert r1.status_code == 403

    # Viewer cannot run employee simulator
    r2 = viewer_client.post('/employee/simulator/run', json={'role': 'Dev', 'salary': 60000})
    assert r2.status_code == 403

    # Viewer cannot run supply chain simulator
    r3 = viewer_client.post('/supply-chain/simulator/run', json={'current_cost': 100, 'new_cost': 90})
    assert r3.status_code == 403

    # Viewer cannot run operations simulator
    r4 = viewer_client.post('/operations/simulator/run', json={'demand_increase_percent': 15})
    assert r4.status_code == 403
