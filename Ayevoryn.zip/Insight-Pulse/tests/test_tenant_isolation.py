"""
AEVORYN / INSIGHT-PULSE
STAGE 2: MULTI-TENANT ISOLATION AND IDOR REMEDIATION TEST SUITE
Verifies:
1. User-to-Company binding and relationship.
2. Tenant context resolution on login (no hardcoded Company 1).
3. Session tampering prevention (non-admin locked to tenant).
4. Simulation IDOR prevention (results, save, delete).
5. Document IDOR prevention (download, delete).
6. Report IDOR prevention (download, delete).
7. Custom Twin IDOR prevention (view, edit, delete, records).
"""

import pytest
from flask import session
from database.db import db
from database.models.user import User
from database.models.company import Company
from database.models.simulation import Simulation
from database.models.document import Document
from database.models.report import Report
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from security.tenant import TenantContext, get_current_company_id, set_current_company


@pytest.fixture
def tenant_fixture(app):
    """Setup two distinct test companies and two distinct users."""
    with app.app_context():
        # Company A
        comp_a = Company.query.filter_by(company_name="Tenant Alpha Corp").first()
        if not comp_a:
            comp_a = Company(
                company_name="Tenant Alpha Corp",
                business_name="Tenant Alpha",
                owner_name="Alice Alpha",
                ceo_name="Alice Alpha",
                currency="USD",
                is_active=True
            )
            db.session.add(comp_a)
            db.session.commit()

        # Company B
        comp_b = Company.query.filter_by(company_name="Tenant Beta Ltd").first()
        if not comp_b:
            comp_b = Company(
                company_name="Tenant Beta Ltd",
                business_name="Tenant Beta",
                owner_name="Bob Beta",
                ceo_name="Bob Beta",
                currency="EUR",
                is_active=True
            )
            db.session.add(comp_b)
            db.session.commit()

        # User A (belongs to Company A)
        user_a = User.query.filter_by(username="tenant_user_a").first()
        if not user_a:
            user_a = User(
                username="tenant_user_a",
                email="alice@alpha.corp",
                role="Analyst",
                is_admin=False,
                company_id=comp_a.id
            )
            user_a.set_password("Password@123")
            db.session.add(user_a)
            db.session.commit()
        else:
            user_a.company_id = comp_a.id
            db.session.commit()

        # User B (belongs to Company B)
        user_b = User.query.filter_by(username="tenant_user_b").first()
        if not user_b:
            user_b = User(
                username="tenant_user_b",
                email="bob@beta.ltd",
                role="Analyst",
                is_admin=False,
                company_id=comp_b.id
            )
            user_b.set_password("Password@123")
            db.session.add(user_b)
            db.session.commit()
        else:
            user_b.company_id = comp_b.id
            db.session.commit()

        yield {
            'comp_a_id': comp_a.id,
            'comp_b_id': comp_b.id,
            'user_a_id': user_a.id,
            'user_b_id': user_b.id
        }


def test_user_company_relationship(app, tenant_fixture):
    """Verify User.company_id and User.company ORM relationship."""
    with app.app_context():
        user_a = User.query.get(tenant_fixture['user_a_id'])
        user_b = User.query.get(tenant_fixture['user_b_id'])
        
        assert user_a.company_id == tenant_fixture['comp_a_id']
        assert user_a.company is not None
        assert user_a.company.company_name == "Tenant Alpha Corp"
        
        assert user_b.company_id == tenant_fixture['comp_b_id']
        assert user_b.company is not None
        assert user_b.company.company_name == "Tenant Beta Ltd"
        
        dict_a = user_a.to_dict()
        assert dict_a['company_id'] == tenant_fixture['comp_a_id']


def test_login_assigns_correct_tenant_context(client, tenant_fixture):
    """Verify logging in as User B sets session['company_id'] to Company B, NOT Company 1."""
    # Login as User B
    resp = client.post('/login', data={
        'username': 'tenant_user_b',
        'password': 'Password@123'
    }, follow_redirects=False)
    
    assert resp.status_code == 302
    with client.session_transaction() as sess:
        assert sess.get('company_id') == tenant_fixture['comp_b_id']
        assert sess.get('company_currency') == 'EUR'


def test_session_tampering_locked_for_non_admin(client, tenant_fixture):
    """Verify non-admin user cannot hijack or switch their session company_id."""
    # Login as User A
    client.post('/login', data={
        'username': 'tenant_user_a',
        'password': 'Password@123'
    }, follow_redirects=True)
    
    # Tamper with session to inject Company B
    with client.session_transaction() as sess:
        sess['company_id'] = tenant_fixture['comp_b_id']
    
    # Send a request - TenantContext should detect mismatch and enforce Company A
    resp = client.get('/dashboard')
    assert resp.status_code == 200
    with client.session_transaction() as sess:
        assert sess.get('company_id') == tenant_fixture['comp_a_id']


def test_simulation_idor_protection(client, app, tenant_fixture):
    """Verify User A cannot read, save, or delete a simulation belonging to Company B."""
    # Create simulation belonging to Company B
    sim_id = None
    with app.app_context():
        sim = Simulation(
            company_id=tenant_fixture['comp_b_id'],
            user_id=tenant_fixture['user_b_id'],
            name='Revenue Shock Test',
            sim_type='revenue_shock',
            parameters='{}',
            is_saved=False
        )
        db.session.add(sim)
        db.session.commit()
        sim_id = sim.id

    # Login as User A (Company A)
    client.post('/login', data={
        'username': 'tenant_user_a',
        'password': 'Password@123'
    }, follow_redirects=True)

    # 1. Try to read API results for Company B's simulation
    resp = client.get(f'/simulation/api/results/{sim_id}')
    assert resp.status_code == 403

    # 2. Try to save Company B's simulation
    resp = client.post(f'/simulation/save/{sim_id}')
    assert resp.status_code == 403

    # 3. Try to delete Company B's simulation
    resp = client.post(f'/simulation/delete/{sim_id}')
    assert resp.status_code == 403

    # Verify simulation still exists in Company B
    with app.app_context():
        persisted = Simulation.query.get(sim_id)
        assert persisted is not None
        assert persisted.company_id == tenant_fixture['comp_b_id']


def test_document_idor_protection(client, app, tenant_fixture):
    """Verify User A cannot delete a document belonging to Company B."""
    doc_id = None
    with app.app_context():
        doc = Document(
            company_id=tenant_fixture['comp_b_id'],
            user_id=tenant_fixture['user_b_id'],
            name='Secret Plan B',
            original_filename='plan_b.pdf',
            file_path='uploads/pdfs/plan_b.pdf',
            file_type='pdf',
            is_deleted=False
        )
        db.session.add(doc)
        db.session.commit()
        doc_id = doc.id

    # Login as User A
    client.post('/login', data={
        'username': 'tenant_user_a',
        'password': 'Password@123'
    }, follow_redirects=True)

    # Attempt to delete document of Company B
    resp = client.post(f'/documents/delete/{doc_id}')
    assert resp.status_code == 403

    # Verify document not deleted
    with app.app_context():
        persisted = Document.query.get(doc_id)
        assert persisted.is_deleted is False


def test_custom_twin_idor_protection(client, app, tenant_fixture):
    """Verify User A cannot access or mutate Custom Twins belonging to Company B."""
    twin_id = None
    with app.app_context():
        twin = CustomTwin(
            company_id=tenant_fixture['comp_b_id'],
            name='Beta Production Line',
            slug='beta-production-line',
            is_active=True
        )
        twin.set_field_definitions([{'name': 'Capacity', 'type': 'number'}])
        db.session.add(twin)
        db.session.commit()
        twin_id = twin.id

    # Login as User A
    client.post('/login', data={
        'username': 'tenant_user_a',
        'password': 'Password@123'
    }, follow_redirects=True)

    # Access Company B's twin JSON
    resp = client.get(f'/custom-twins/{twin_id}/json')
    assert resp.status_code == 404

    # Attempt to edit Company B's twin
    resp = client.post(f'/custom-twins/{twin_id}/edit', data={'name': 'Hacked Twin'})
    assert resp.status_code == 404

    # Attempt to delete Company B's twin
    resp = client.delete(f'/custom-twins/{twin_id}/delete')
    assert resp.status_code == 404

    # Verify twin name was NOT altered
    with app.app_context():
        persisted = CustomTwin.query.get(twin_id)
        assert persisted is not None
        assert persisted.name == 'Beta Production Line'
