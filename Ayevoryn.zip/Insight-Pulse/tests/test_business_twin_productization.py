"""
Unit and integration tests for Stage 7 - Business Twin Productization & 7-Pillar Symmetry.
Verifies:
1. Overview honest observation (no synthetic override of raw counts).
2. Revenue export routes (Excel, CSV, PDF).
3. Expense export routes (Excel, CSV, PDF).
4. Department lifecycle symmetry:
   - Add department
   - Edit department
   - Export Excel & CSV
   - Download CSV & Excel templates
   - Import CSV
   - Delete single department with safe FK detachment (Employee, FinancialRecord, Project)
   - Delete all departments with cascade/detachment
"""

import pytest
import io
import csv
import uuid
from datetime import date, datetime
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.employee import Employee
from database.models.financial import FinancialRecord
from database.models.project import Project


@pytest.fixture
def twin_app_client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    with app.test_client() as client:
        yield app, client


@pytest.fixture
def twin_fixture(twin_app_client):
    app, client = twin_app_client
    u_suffix = uuid.uuid4().hex[:8]
    username = f"twinuser_{u_suffix}"
    email = f"twinuser_{u_suffix}@acmetwin.com"

    with app.app_context():
        company = Company(
            company_name=f"Acme Twin {u_suffix}",
            business_name=f"Acme Twin {u_suffix}",
            owner_name=f"Twin Owner {u_suffix}",
            ceo_name=f"Twin CEO {u_suffix}",
            industry="Technology",
            currency="USD",
            employee_count=75,    # Target/setup count
            customer_count=300    # Target/setup count
        )
        db.session.add(company)
        db.session.commit()

        user = User(
            username=username,
            email=email,
            company_id=company.id,
            role="admin",
            is_active=True
        )
        user.set_password("SecurePass123!")
        db.session.add(user)
        db.session.commit()

        company_id = company.id
        user_id = user.id

    with client.session_transaction() as sess:
        sess['_user_id'] = str(user_id)
        sess['company_id'] = company_id
        sess['tenant_company_id'] = company_id
        sess['role'] = 'admin'

    return {
        'company_id': company_id,
        'user_id': user_id,
        'username': username
    }


def test_overview_honest_counts(twin_app_client, twin_fixture):
    """Twin overview must report 0 active employees/customers when 0 exist in DB (no fake override)."""
    app, client = twin_app_client
    cid = twin_fixture['company_id']

    with app.app_context():
        assert Employee.query.filter_by(company_id=cid, status='active').count() == 0

    response = client.get('/business-twin/')
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "Overview" in html or "Business Twin" in html


def test_revenue_export_routes(twin_app_client, twin_fixture):
    """Test revenue exports: Excel, CSV, and PDF."""
    app, client = twin_app_client
    cid = twin_fixture['company_id']

    with app.app_context():
        rec1 = FinancialRecord(
            company_id=cid,
            transaction_type='revenue',
            amount=5000.0,
            category='Software',
            subcategory='Subscription',
            description='Client SaaS renewal',
            reference_number='REV-001',
            transaction_date=date.today(),
            is_recurring=True,
            recurring_frequency='monthly'
        )
        rec2 = FinancialRecord(
            company_id=cid,
            transaction_type='revenue',
            amount=12000.0,
            category='Services',
            subcategory='Consulting',
            description='Architecture assessment',
            reference_number='REV-002',
            transaction_date=date.today()
        )
        db.session.add_all([rec1, rec2])
        db.session.commit()

    # 1. Export Excel
    res_excel = client.get('/business-twin/revenue/export-excel')
    assert res_excel.status_code == 200
    assert 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' in res_excel.headers['Content-Type']
    assert 'revenue_export.xlsx' in res_excel.headers.get('Content-Disposition', '')
    assert len(res_excel.data) > 0

    # 2. Export CSV
    res_csv = client.get('/business-twin/revenue/export-csv')
    assert res_csv.status_code == 200
    assert 'text/csv' in res_csv.headers['Content-Type']
    assert 'revenue_export.csv' in res_csv.headers.get('Content-Disposition', '')
    csv_content = res_csv.data.decode('utf-8')
    assert 'REV-001' in csv_content
    assert 'REV-002' in csv_content
    assert '5000.0' in csv_content or '5000' in csv_content

    # 3. Export PDF
    res_pdf = client.get('/business-twin/revenue/export-pdf')
    assert res_pdf.status_code == 200
    assert 'application/pdf' in res_pdf.headers['Content-Type']
    assert 'revenue_report.pdf' in res_pdf.headers.get('Content-Disposition', '')
    assert len(res_pdf.data) > 0


def test_expenses_export_routes(twin_app_client, twin_fixture):
    """Test expenses exports: Excel, CSV, and PDF."""
    app, client = twin_app_client
    cid = twin_fixture['company_id']

    with app.app_context():
        rec1 = FinancialRecord(
            company_id=cid,
            transaction_type='expense',
            amount=3200.0,
            category='Operations',
            subcategory='Cloud',
            description='AWS Hosting and Database',
            reference_number='EXP-001',
            transaction_date=date.today(),
            is_recurring=True,
            recurring_frequency='monthly'
        )
        db.session.add(rec1)
        db.session.commit()

    # 1. Export Excel
    res_excel = client.get('/business-twin/expenses/export-excel')
    assert res_excel.status_code == 200
    assert 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' in res_excel.headers['Content-Type']
    assert 'expenses_export.xlsx' in res_excel.headers.get('Content-Disposition', '')

    # 2. Export CSV
    res_csv = client.get('/business-twin/expenses/export-csv')
    assert res_csv.status_code == 200
    assert 'text/csv' in res_csv.headers['Content-Type']
    csv_content = res_csv.data.decode('utf-8')
    assert 'AWS Hosting' in csv_content
    assert 'EXP-001' in csv_content

    # 3. Export PDF
    res_pdf = client.get('/business-twin/expenses/export-pdf')
    assert res_pdf.status_code == 200
    assert 'application/pdf' in res_pdf.headers['Content-Type']
    assert 'expenses_report.pdf' in res_pdf.headers.get('Content-Disposition', '')


def test_department_crud_and_symmetry(twin_app_client, twin_fixture):
    """Test Department add, edit, templates, export, and import."""
    app, client = twin_app_client
    cid = twin_fixture['company_id']

    # 1. Add Department
    res_add = client.post('/business-twin/departments/add', data={
        'name': 'Cloud Infrastructure',
        'code': 'CLD',
        'description': 'DevOps and cloud platforms',
        'head_name': 'Sarah Connor',
        'budget': '150000',
        'color': '#00D4FF'
    })
    assert res_add.status_code == 200
    data_add = res_add.get_json()
    assert data_add['success'] is True
    dept_id = data_add['department']['id']

    # 2. Edit Department
    res_edit = client.post(f'/business-twin/departments/edit/{dept_id}', json={
        'name': 'Cloud Platform & Security',
        'budget': 175000,
        'head_name': 'Sarah Connor-Reese'
    })
    assert res_edit.status_code == 200
    data_edit = res_edit.get_json()
    assert data_edit['success'] is True
    assert data_edit['department']['name'] == 'Cloud Platform & Security'
    assert data_edit['department']['budget'] == 175000.0

    # 3. Download Templates
    res_csv_tpl = client.get('/business-twin/departments/download-template')
    assert res_csv_tpl.status_code == 200
    assert 'text/csv' in res_csv_tpl.headers['Content-Type']

    res_xl_tpl = client.get('/business-twin/departments/download-excel-template')
    assert res_xl_tpl.status_code == 200
    assert 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' in res_xl_tpl.headers['Content-Type']

    # 4. Export Excel and CSV
    res_exp_xl = client.get('/business-twin/departments/export-excel')
    assert res_exp_xl.status_code == 200
    assert 'departments_export.xlsx' in res_exp_xl.headers.get('Content-Disposition', '')

    res_exp_csv = client.get('/business-twin/departments/export-csv')
    assert res_exp_csv.status_code == 200
    assert 'Cloud Platform & Security' in res_exp_csv.data.decode('utf-8')

    # 5. Import CSV
    csv_data = "name,code,description,head_name,budget,color\n" \
               "Robotics,ROB,Automation engineering,Miles Dyson,300000,#7C3AED\n" \
               "Quality Assurance,QA,Test engineering,John Connor,120000,#10B981\n"
    res_import = client.post(
        '/business-twin/departments/import-csv',
        data={'csv_file': (io.BytesIO(csv_data.encode('utf-8')), 'departments.csv')},
        content_type='multipart/form-data'
    )
    assert res_import.status_code == 200
    data_imp = res_import.get_json()
    assert data_imp['success'] is True
    assert data_imp['added'] == 2

    with app.app_context():
        rob = Department.query.filter_by(company_id=cid, name='Robotics').first()
        assert rob is not None
        assert rob.budget == 300000.0


def test_department_delete_and_fk_detachment(twin_app_client, twin_fixture):
    """Test deleting single department and delete-all with foreign key detachment."""
    app, client = twin_app_client
    cid = twin_fixture['company_id']

    with app.app_context():
        dept = Department(
            company_id=cid,
            name='Temporary Operations',
            code='TOP',
            budget=50000.0,
            is_active=True
        )
        db.session.add(dept)
        db.session.commit()
        dept_id = dept.id

        emp = Employee(
            company_id=cid,
            first_name='Kyle',
            last_name='Reese',
            email=f'kyle_{uuid.uuid4().hex[:6]}@skynet.com',
            department_id=dept_id,
            status='active'
        )
        fin = FinancialRecord(
            company_id=cid,
            transaction_type='expense',
            amount=400.0,
            department_id=dept_id,
            transaction_date=date.today()
        )
        proj = Project(
            company_id=cid,
            name='Resistance Project',
            department_id=dept_id
        )
        db.session.add_all([emp, fin, proj])
        db.session.commit()
        emp_id = emp.id
        fin_id = fin.id
        proj_id = proj.id

    # Delete single department via endpoint
    res_del = client.delete(f'/business-twin/departments/delete/{dept_id}')
    assert res_del.status_code == 200
    assert res_del.get_json()['success'] is True

    # Verify FK detachment and department removal
    with app.app_context():
        assert db.session.get(Department, dept_id) is None
        detached_emp = db.session.get(Employee, emp_id)
        assert detached_emp is not None
        assert detached_emp.department_id is None

        detached_fin = db.session.get(FinancialRecord, fin_id)
        assert detached_fin is not None
        assert detached_fin.department_id is None

        detached_proj = db.session.get(Project, proj_id)
        assert detached_proj is not None
        assert detached_proj.department_id is None

    # Test delete-all departments
    with app.app_context():
        d1 = Department(company_id=cid, name='Dept A', budget=10000.0)
        d2 = Department(company_id=cid, name='Dept B', budget=20000.0)
        db.session.add_all([d1, d2])
        db.session.commit()

    res_del_all = client.delete('/business-twin/departments/delete-all')
    assert res_del_all.status_code == 200
    assert res_del_all.get_json()['success'] is True

    with app.app_context():
        remaining = Department.query.filter_by(company_id=cid).count()
        assert remaining == 0
