"""
AEVORYN / INSIGHT-PULSE
STAGE 18: DECISION INTELLIGENCE & HONEST INSIGHTS AUTOMATED TEST SUITE

Validates:
1. Complete elimination of deceptive hardcoded confidence integers (92%, 88%, etc.).
2. Transparent provenance and source classification (RULE, STATISTICAL_MODEL, SIMULATION, SYSTEMIC_IMPACT).
3. Real statistical confidence metrics grounded in sample size (N), standard deviation, and variance.
4. Honest data readiness warnings when transaction history is sparse (< 14 days).
5. Deterministic rule-based insights for liquidity boundaries, stockouts, and overruns.
6. Customer and supplier concentration threshold detection.
7. Digital twin causal cascade synthesis from recent high-severity ImpactTrace events.
8. Multi-tenant IDOR protection on explainability endpoints (HTTP 404).
9. RBAC authorization enforcement (Viewer role receives HTTP 403 on scan triggers).
10. Backward compatibility with BusinessAgent, Command Center, and DomainEvent emission.
"""

import pytest
from datetime import datetime, timedelta, date
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.financial import FinancialRecord
from database.models.inventory import Inventory
from database.models.supplier import Supplier
from database.models.customer import Customer
from database.models.department import Department
from database.models.impact_trace import ImpactTrace, ImpactSeverity
from database.models.simulation import Simulation
from services.decision_intelligence import (
    DecisionIntelligenceEngine, DecisionInsight,
    InsightSource, InsightCategory, InsightSeverity
)
from services.decision_intelligence_service import DecisionIntelligenceService
from services.business_agent import BusinessAgent
from services.events import EventBus, EventTypes, DomainEvent
from security.rbac import Role


def _clean_s18_data():
    """Safely delete Stage 18 test tenants and all child records across all tables."""
    try:
        db.session.rollback()
        db.session.close()
    except Exception:
        pass
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE business_name IN ('Stage18 Alpha Corp', 'Stage18 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] not in ('companies', 'sqlite_sequence')]
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's18_%' OR email LIKE 's18_%'")
        conn.commit()
        cursor.execute("PRAGMA foreign_keys = ON")
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def decision_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users and initial ledger data."""
    with app.app_context():
        _clean_s18_data()

        # Tenant Alpha
        comp_a = Company(
            company_name='Stage18 Alpha Corp',
            business_name='Stage18 Alpha Corp',
            owner_name='Alpha Intelligence Owner',
            ceo_name='Alpha Intelligence CEO',
            industry='Technology',
            currency='USD',
            annual_revenue=1500000.0,
            annual_expenses_plan=1000000.0,
            customer_count=25,
            employee_count=12
        )
        db.session.add(comp_a)
        db.session.flush()

        user_admin_a = User(
            username='s18_admin_a',
            email='s18_admin_a@alpha.com',
            company_id=comp_a.id,
            role=Role.ADMIN
        )
        user_admin_a.set_password('Secret123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s18_viewer_a',
            email='s18_viewer_a@alpha.com',
            company_id=comp_a.id,
            role=Role.VIEWER
        )
        user_viewer_a.set_password('Secret123!')
        db.session.add(user_viewer_a)

        # Tenant Beta
        comp_b = Company(
            company_name='Stage18 Beta Corp',
            business_name='Stage18 Beta Corp',
            owner_name='Beta Intelligence Owner',
            ceo_name='Beta Intelligence CEO',
            industry='Consulting',
            currency='USD',
            annual_revenue=400000.0,
            annual_expenses_plan=300000.0,
            customer_count=8,
            employee_count=4
        )
        db.session.add(comp_b)
        db.session.flush()

        user_admin_b = User(
            username='s18_admin_b',
            email='s18_admin_b@beta.com',
            company_id=comp_b.id,
            role=Role.ADMIN
        )
        user_admin_b.set_password('Secret123!')
        db.session.add(user_admin_b)

        db.session.commit()

        yield {
            'comp_a_id': comp_a.id,
            'user_admin_a_id': user_admin_a.id,
            'user_viewer_a_id': user_viewer_a.id,
            'comp_b_id': comp_b.id,
            'user_admin_b_id': user_admin_b.id
        }

        # Cleanup
        try:
            _clean_s18_data()
        except Exception:
            db.session.rollback()


def test_elimination_of_hardcoded_confidence_integers(app, decision_tenants):
    """Verifies that no generated insights contain hardcoded integers (92, 88, 95, 90, 85, 75)."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        # Test DecisionIntelligenceService insights
        insights = DecisionIntelligenceService.get_insights(comp_a_id)
        assert len(insights) >= 1

        for insight in insights:
            ins_dict = insight.to_dict()
            conf_obj = ins_dict.get('confidence', {})
            # Confidence score must either be None (for deterministic rules) or float 0.0 - 1.0
            if conf_obj.get('score') is not None:
                assert isinstance(conf_obj['score'], float)
                assert 0.0 <= conf_obj['score'] <= 1.0
                assert conf_obj['score'] not in (92, 88, 95, 90, 85, 75)
            # Label must be descriptive
            assert isinstance(conf_obj.get('label'), str)
            assert len(conf_obj['label']) > 0

        # Test BusinessAgent._generate_insights backward compatibility
        test_kpis = {
            'margin': 25.0,
            'revenue_growth': 8.0,
            'churn_rate': 14.0,
            'revenue_per_employee': 3000.0,
            'low_stock_items': 2
        }
        ba_insights = BusinessAgent._generate_insights(test_kpis)
        assert len(ba_insights) >= 3

        for bi in ba_insights:
            # Must not have fake integer confidence
            assert bi.get('confidence') is None or (isinstance(bi.get('confidence'), float) and bi.get('confidence') <= 1.0)
            assert bi.get('confidence') not in (92, 88, 95, 90, 85, 75)
            # Must provide honest source and confidence label
            assert 'source' in bi
            assert 'confidence_label' in bi
            assert len(bi['confidence_label']) > 0


def test_insight_provenance_and_source_labeling(app, decision_tenants):
    """Verifies that all insights carry canonical source tags and transparent methodology descriptions."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        insights = DecisionIntelligenceService.get_insights(comp_a_id)
        for insight in insights:
            assert insight.source in InsightSource.ALL
            assert len(insight.source_label) > 0
            assert insight.category in InsightCategory.ALL
            assert insight.severity in InsightSeverity.ALL
            assert isinstance(insight.evidence, dict)


def test_statistical_confidence_bounds_with_sample_variance(app, decision_tenants):
    """Verifies empirical variance analysis across daily observations without synthetic guesswork."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        today = date.today()
        # Seed 25 days of daily transactions
        for i in range(25):
            d = today - timedelta(days=25 - i)
            # Expenses exceed revenue -> negative margin
            db.session.add(FinancialRecord(
                company_id=comp_a_id,
                transaction_date=d,
                transaction_type='revenue',
                amount=1000.0 + (i * 10.0),
                category='Sales'
            ))
            db.session.add(FinancialRecord(
                company_id=comp_a_id,
                transaction_date=d,
                transaction_type='expense',
                amount=1500.0 + (i * 15.0),
                category='Operations'
            ))
        db.session.commit()

        insights = DecisionIntelligenceService.get_insights(comp_a_id, category='PROFITABILITY')
        margin_insight = next((i for i in insights if i.category == InsightCategory.PROFITABILITY), None)

        assert margin_insight is not None
        assert margin_insight.source == InsightSource.STATISTICAL_MODEL
        assert margin_insight.severity == InsightSeverity.HIGH
        ev = margin_insight.evidence
        assert ev['sample_size_days'] == 25
        assert ev['margin_pct'] < 0.0
        assert 'daily_revenue_mean' in ev
        assert 'daily_revenue_std' in ev
        assert 'coefficient_of_variation' in ev

        conf = margin_insight.confidence
        assert conf.sample_size == 25
        assert conf.is_heuristic_estimate is False
        assert conf.score is not None
        assert 0.50 <= conf.score <= 1.0
        assert "Empirical Model" in conf.label


def test_sparse_data_readiness_warning(app, decision_tenants):
    """Verifies that sparse transaction history (< 14 days) triggers a data readiness warning."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        # Only 3 days of transactions
        today = date.today()
        for i in range(3):
            db.session.add(FinancialRecord(
                company_id=comp_a_id,
                transaction_date=today - timedelta(days=i),
                transaction_type='revenue',
                amount=500.0,
                category='Sales'
            ))
        db.session.commit()

        insights = DecisionIntelligenceService.get_insights(comp_a_id, category='GOVERNANCE')
        readiness = next((i for i in insights if 'Sparse' in i.title or i.confidence.is_heuristic_estimate), None)

        assert readiness is not None
        assert readiness.confidence.is_heuristic_estimate is True
        assert readiness.confidence.sample_size == 3
        assert "Heuristic Mode" in readiness.confidence.label


def test_deterministic_rule_insights(app, decision_tenants):
    """Verifies that deterministic rules evaluate boundary violations with 100% threshold certainty."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        # 1. Stockout trigger
        db.session.add(Inventory(
            company_id=comp_a_id,
            sku='SKU-DECISION-01',
            name='Precision Valve',
            category='Mechanical',
            quantity_on_hand=0,
            reorder_point=10,
            unit_cost=50.0,
            selling_price=120.0,
            is_active=True
        ))
        db.session.commit()

        insights = DecisionIntelligenceService.get_insights(comp_a_id, category='SUPPLY_CHAIN')
        stockout_insight = next((i for i in insights if 'Stockout' in i.title), None)

        assert stockout_insight is not None
        assert stockout_insight.source == InsightSource.RULE
        assert stockout_insight.confidence.label == "Deterministic (100% Rule Match)"
        assert stockout_insight.confidence.score is None
        assert any('SKU-DECISION-01' in s for s in stockout_insight.evidence['depleted_skus'])


def test_customer_and_supplier_concentration_insights(app, decision_tenants):
    """Verifies customer revenue (>40%) and supplier spend (>60%) concentration detection."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        # Customers: 80% with Anchor Customer
        c1 = Customer(
            company_id=comp_a_id,
            first_name='Anchor',
            last_name='Client',
            total_spent=80000.0,
            status='active'
        )
        c2 = Customer(
            company_id=comp_a_id,
            first_name='Secondary',
            last_name='Client',
            total_spent=20000.0,
            status='active'
        )
        # Suppliers: 90% with Primary Supplier
        s1 = Supplier(
            company_id=comp_a_id,
            name='Dominant Materials LLC',
            total_spend=90000.0,
            status='active'
        )
        s2 = Supplier(
            company_id=comp_a_id,
            name='Backup Materials LLC',
            total_spend=10000.0,
            status='active'
        )
        db.session.add_all([c1, c2, s1, s2])
        db.session.commit()

        insights = DecisionIntelligenceService.get_insights(comp_a_id)

        # Customer concentration
        cust_ins = next((i for i in insights if i.category == InsightCategory.CUSTOMERS and 'Concentration' in i.title), None)
        assert cust_ins is not None
        assert cust_ins.source == InsightSource.RULE
        assert cust_ins.evidence['concentration_pct'] == 80.0
        assert 'Anchor Client' in cust_ins.evidence['top_customer']

        # Supplier concentration
        sup_ins = next((i for i in insights if 'Supplier Concentration' in i.title), None)
        assert sup_ins is not None
        assert sup_ins.source == InsightSource.RULE
        assert sup_ins.evidence['concentration_pct'] == 90.0


def test_systemic_twin_cascade_insight(app, decision_tenants):
    """Verifies that high-severity impact traces surface as SYSTEMIC_IMPACT decision insights."""
    comp_a_id = decision_tenants['comp_a_id']
    with app.app_context():
        trace = ImpactTrace(
            trace_id='trace-s18-cascade-01',
            company_id=comp_a_id,
            trigger_type='inventory.item.deleted',
            root_entity_type='inventory',
            root_entity_id='55',
            severity=ImpactSeverity.CRITICAL,
            affected_nodes_count=9,
            max_depth=3,
            summary_text='Depletion of critical SKU propagated delays to 9 downstream manufacturing nodes.',
            created_at=datetime.utcnow()
        )
        db.session.add(trace)
        db.session.commit()

        insights = DecisionIntelligenceService.get_insights(comp_a_id, source=InsightSource.SYSTEMIC_IMPACT)
        assert len(insights) >= 1

        cascade_ins = insights[0]
        assert cascade_ins.source == InsightSource.SYSTEMIC_IMPACT
        assert cascade_ins.severity == InsightSeverity.CRITICAL
        assert cascade_ins.evidence['affected_nodes_count'] == 9
        assert "Twin Causal Graph" in cascade_ins.confidence.label


def test_cross_tenant_insight_idor_protection(client, app, decision_tenants):
    """Verifies that cross-tenant access to /ai-insights/api/explain/<id> returns HTTP 404."""
    comp_a_id = decision_tenants['comp_a_id']
    comp_b_id = decision_tenants['comp_b_id']
    user_admin_b_id = decision_tenants['user_admin_b_id']

    with app.app_context():
        # Get Tenant A insight
        insights_a = DecisionIntelligenceService.get_insights(comp_a_id)
        assert len(insights_a) >= 1
        target_id = insights_a[0].id

    # Authenticate as Tenant Beta Admin
    with client.session_transaction() as sess:
        sess['user_id'] = user_admin_b_id
        sess['_user_id'] = str(user_admin_b_id)
        sess['company_id'] = comp_b_id
        sess['role'] = Role.ADMIN

    # Attempt to access Tenant A insight explanation -> 404
    resp = client.get(f'/ai-insights/api/explain/{target_id}')
    assert resp.status_code == 404


def test_viewer_rbac_rejection_on_scan(client, app, decision_tenants):
    """Verifies that users with Viewer role receive HTTP 403 Forbidden on scan triggers."""
    comp_a_id = decision_tenants['comp_a_id']
    viewer_a_id = decision_tenants['user_viewer_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = viewer_a_id
        sess['_user_id'] = str(viewer_a_id)
        sess['company_id'] = comp_a_id
        sess['role'] = Role.VIEWER

    # 1. POST /scan -> 403
    resp1 = client.post('/ai-insights/scan')
    assert resp1.status_code == 403

    # 2. POST /api/scan -> 403
    resp2 = client.post('/ai-insights/api/scan')
    assert resp2.status_code == 403

    # Viewing is allowed
    resp_view = client.get('/ai-insights/')
    assert resp_view.status_code == 200


def test_business_agent_and_command_center_backward_compatibility(app, decision_tenants):
    """Verifies BusinessAgent, Command Center data structures, and DECISION_SCAN_COMPLETED event emission."""
    comp_a_id = decision_tenants['comp_a_id']
    admin_a_id = decision_tenants['user_admin_a_id']

    with app.app_context():
        # 1. Test Command Center payload
        cc = BusinessAgent.get_command_center(comp_a_id)
        assert 'kpis' in cc
        assert 'insights' in cc
        assert 'alerts' in cc
        assert 'health' in cc
        assert isinstance(cc['insights'], list)
        for ins in cc['insights']:
            assert 'title' in ins
            assert 'type' in ins
            assert 'category' in ins
            # Assert no hardcoded confidence integers
            assert ins.get('confidence') not in (92, 88, 95, 90, 85, 75)

        # 2. Test run_decision_scan and event emission
        result = DecisionIntelligenceService.run_decision_scan(
            company_id=comp_a_id,
            actor_user_id=admin_a_id,
            publish_events=True
        )
        assert result['success'] is True
        assert 'total_insights' in result
        assert 'by_severity' in result
        assert 'by_source' in result
        assert len(result['insights']) >= 1
