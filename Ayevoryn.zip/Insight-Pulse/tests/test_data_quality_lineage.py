"""
TEST SUITE: Stage 21 - Data Quality & Lineage Engine
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. Deterministic quality score calculation across 6 dimensions.
2. Statistical anomaly detection (3-sigma, IQR, negative stock).
3. Metric lineage DAG construction (revenue, expenses, runway, inventory).
4. Entity lineage trace with origin, mutations, and consumers.
5. Data freshness decay logic across varied age brackets.
6. Multi-tenant isolation and cross-tenant entity lineage IDOR prevention.
7. Viewer RBAC rejection on mutation scan (HTTP 403) vs Admin success.
8. Auditable quality rule evaluations with violation tracking and sample IDs.
9. Domain events dispatched on quality evaluation (DATA_QUALITY_EVALUATED).
10. Data Lake UI rendering and JSON API consistency.
"""

import pytest
import json
from datetime import datetime, timedelta, date
from database.db import db
from database.models.company import Company
from database.models.user import User
from security.rbac import Role
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.customer import Customer
from database.models.employee import Employee
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.department import Department
from database.models.custom_twin import CustomTwin
from database.models.business_event import BusinessEvent
from services.data_quality_service import DataQualityService
from services.events import EventBus, EventTypes
from conftest import CSRFTestClient


def _clean_s21_data():
    db.session.remove()
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE business_name IN ('Stage21 Alpha Quality Corp', 'Stage21 Beta Quality Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] not in ('companies', 'sqlite_sequence')]
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's21_%' OR email LIKE 's21_%'")
        cursor.execute("PRAGMA foreign_keys = ON")
        conn.commit()
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def quality_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users and sample data."""
    with app.app_context():
        _clean_s21_data()

        # Tenant Alpha
        comp_a = Company(
            company_name='Stage21 Alpha Quality Corp',
            business_name='Stage21 Alpha Quality Corp',
            owner_name='Alpha Data Director',
            ceo_name='Alpha CEO',
            industry='Technology',
            country='United States',
            annual_revenue=10000000.0,
            employee_count=30,
            currency='USD',
            health_score=80
        )
        db.session.add(comp_a)
        db.session.commit()

        user_admin_a = User(
            username='s21_admin_a',
            email='s21_admin_a@alpha.corp',
            role=Role.ADMIN,
            is_admin=True,
            company_id=comp_a.id,
            first_name='Admin',
            last_name='Alpha'
        )
        user_admin_a.set_password('SecretPass123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s21_viewer_a',
            email='s21_viewer_a@alpha.corp',
            role=Role.VIEWER,
            is_admin=False,
            company_id=comp_a.id,
            first_name='Viewer',
            last_name='Alpha'
        )
        user_viewer_a.set_password('SecretPass123!')
        db.session.add(user_viewer_a)

        # Department
        dept_a = Department(
            company_id=comp_a.id,
            name='Engineering'
        )
        db.session.add(dept_a)
        db.session.commit()

        # Supplier
        supp_a = Supplier(
            company_id=comp_a.id,
            name='Alpha Global Parts',
            email='sales@alphaparts.com',
            phone='555-0101'
        )
        db.session.add(supp_a)
        db.session.commit()

        # Tenant Beta
        comp_b = Company(
            company_name='Stage21 Beta Quality Corp',
            business_name='Stage21 Beta Quality Corp',
            owner_name='Beta Data Director',
            ceo_name='Beta CEO',
            industry='Manufacturing',
            country='United States',
            annual_revenue=5000000.0,
            employee_count=15,
            currency='USD',
            health_score=70
        )
        db.session.add(comp_b)
        db.session.commit()

        user_admin_b = User(
            username='s21_admin_b',
            email='s21_admin_b@beta.corp',
            role=Role.ADMIN,
            is_admin=True,
            company_id=comp_b.id,
            first_name='Admin',
            last_name='Beta'
        )
        user_admin_b.set_password('SecretPass123!')
        db.session.add(user_admin_b)
        db.session.commit()

        # Seed initial baseline data for Alpha
        today = date.today()
        f1 = FinancialRecord(company_id=comp_a.id, transaction_type='revenue', amount=50000.0, transaction_date=today - timedelta(days=2), description='Enterprise License')
        f2 = FinancialRecord(company_id=comp_a.id, transaction_type='revenue', amount=45000.0, transaction_date=today - timedelta(days=4), description='SaaS Monthly')
        f3 = FinancialRecord(company_id=comp_a.id, transaction_type='expense', amount=15000.0, transaction_date=today - timedelta(days=3), description='Cloud Infrastructure')
        f4 = FinancialRecord(company_id=comp_a.id, transaction_type='expense', amount=12000.0, transaction_date=today - timedelta(days=5), description='Office Lease')
        db.session.add_all([f1, f2, f3, f4])

        e1 = Employee(company_id=comp_a.id, first_name='John', last_name='Doe', email='john.doe@alpha.corp', department_id=dept_a.id, salary=120000.0, status='active')
        e2 = Employee(company_id=comp_a.id, first_name='Jane', last_name='Smith', email='jane.smith@alpha.corp', department_id=dept_a.id, salary=130000.0, status='active')
        db.session.add_all([e1, e2])

        c1 = Customer(company_id=comp_a.id, company_name='Acme Global', email='contact@acmeglobal.com', phone='555-1234')
        c2 = Customer(company_id=comp_a.id, company_name='Zenith Corp', email='info@zenithcorp.com', phone='555-5678')
        db.session.add_all([c1, c2])

        inv1 = Inventory(company_id=comp_a.id, sku='SKU-A100', name='Edge Compute Gateway', unit_cost=350.0, quantity_on_hand=50, supplier_id=supp_a.id)
        inv2 = Inventory(company_id=comp_a.id, sku='SKU-A200', name='Sensor Hub Module', unit_cost=75.0, quantity_on_hand=120, supplier_id=supp_a.id)
        db.session.add_all([inv1, inv2])

        acct = FinancialAccount(company_id=comp_a.id, account_name='Operating Checking', account_type='asset', current_balance=750000.0, opening_balance=750000.0)
        db.session.add(acct)

        db.session.commit()

        yield {
            'comp_a': comp_a,
            'comp_b': comp_b,
            'admin_a': user_admin_a,
            'viewer_a': user_viewer_a,
            'admin_b': user_admin_b,
            'dept_a': dept_a,
            'supp_a': supp_a,
            'f1': f1,
            'e1': e1,
            'inv1': inv1
        }

        _clean_s21_data()


# -----------------------------------------------------------------------------
# TEST 1: Deterministic Quality Score Calculation
# -----------------------------------------------------------------------------
def test_deterministic_quality_score_calculation(app, quality_tenants):
    """Validate 6-dimension evaluation, weighting, and deterministic composite quality score."""
    with app.app_context():
        comp_id = quality_tenants['comp_a'].id
        res = DataQualityService.evaluate_quality(comp_id)

        assert res['company_id'] == comp_id
        assert 'composite_score' in res
        assert 0.0 <= res['composite_score'] <= 100.0
        assert res['rating'] in ('EXCELLENT', 'GOOD', 'FAIR', 'POOR')

        dims = res['dimensions']
        assert 'completeness' in dims
        assert 'freshness' in dims
        assert 'consistency' in dims
        assert 'uniqueness' in dims
        assert 'integrity' in dims
        assert 'coverage' in dims

        weights = res['weights']
        assert round(sum(weights.values()), 2) == 1.0

        expected_composite = round(
            dims['completeness'] * weights['completeness'] +
            dims['freshness'] * weights['freshness'] +
            dims['consistency'] * weights['consistency'] +
            dims['uniqueness'] * weights['uniqueness'] +
            dims['integrity'] * weights['integrity'] +
            dims['coverage'] * weights['coverage'],
            1
        )
        assert res['composite_score'] == expected_composite
        assert res['days_since_latest_record'] <= 7
        assert dims['freshness'] == 100.0


# -----------------------------------------------------------------------------
# TEST 2: Statistical Anomaly Detection (3-Sigma, IQR, Negative Stock)
# -----------------------------------------------------------------------------
def test_anomaly_detection_financial_and_payroll_outliers(app, quality_tenants):
    """Validate detection of statistical outliers: 3-sigma financial spikes, salary IQR outliers, negative stock."""
    with app.app_context():
        comp_id = quality_tenants['comp_a'].id
        today = date.today()

        for i in range(4):
            db.session.add(FinancialRecord(
                company_id=comp_id,
                transaction_type='revenue',
                amount=1000.0 + (i * 50),
                transaction_date=today - timedelta(days=i + 1),
                description=f'Routine Rev {i}'
            ))
        db.session.add(FinancialRecord(
            company_id=comp_id,
            transaction_type='revenue',
            amount=500000.0,
            transaction_date=today,
            description='Giant Revenue Spike'
        ))

        dept_id = quality_tenants['dept_a'].id
        for i in range(4):
            db.session.add(Employee(
                company_id=comp_id,
                first_name=f'Dev_{i}',
                last_name='Staff',
                email=f'dev{i}@alpha.corp',
                department_id=dept_id,
                salary=75000.0 + (i * 2000),
                status='active'
            ))
        db.session.add(Employee(
            company_id=comp_id,
            first_name='Mega',
            last_name='Executive',
            email=f'mega@alpha.corp',
            department_id=dept_id,
            salary=2500000.0,
            status='active'
        ))

        db.session.add(Inventory(
            company_id=comp_id,
            sku='SKU-NEG-1',
            name='Defective Sensor',
            unit_cost=10.0,
            quantity_on_hand=-25
        ))
        db.session.commit()

        anomalies = DataQualityService.detect_anomalies(comp_id)
        assert len(anomalies) >= 3

        types = [a['anomaly_type'] for a in anomalies]
        assert 'extreme_revenue_spike' in types
        assert 'extreme_compensation_outlier' in types
        assert 'negative_stock_anomaly' in types

        neg_item = next(a for a in anomalies if a['anomaly_type'] == 'negative_stock_anomaly')
        assert neg_item['severity'] == 'HIGH'
        assert neg_item['observed_value'] == -25


# -----------------------------------------------------------------------------
# TEST 3: Metric Lineage DAG Generation
# -----------------------------------------------------------------------------
def test_metric_lineage_dag_generation(app, quality_tenants):
    """Validate directed acyclic graph generation for canonical metrics."""
    with app.app_context():
        comp_id = quality_tenants['comp_a'].id

        for metric in ['revenue_30d', 'expenses_30d', 'cash_runway', 'inventory_value']:
            dag = DataQualityService.get_metric_lineage(comp_id, metric)
            assert dag['metric'] in ('revenue_30d', 'expenses_30d', 'runway_months', 'inventory_value')
            assert 'nodes' in dag and len(dag['nodes']) >= 3
            assert 'edges' in dag and len(dag['edges']) >= 2

            node_types = {n['type'] for n in dag['nodes']}
            assert 'canonical_metric' in node_types
            assert 'consumer' in node_types

            node_ids = {n['id'] for n in dag['nodes']}
            for edge in dag['edges']:
                assert edge['from'] in node_ids
                assert edge['to'] in node_ids


# -----------------------------------------------------------------------------
# TEST 4: Entity Lineage Trace (Origin, Mutations, Downstream Consumers)
# -----------------------------------------------------------------------------
def test_entity_lineage_trace(app, quality_tenants):
    """Validate entity provenance tracing, event replay, and consumer mapping."""
    with app.app_context():
        comp_id = quality_tenants['comp_a'].id
        f1 = quality_tenants['f1']
        admin = quality_tenants['admin_a']

        # Add business events for f1 with payload_json
        ev1 = BusinessEvent(
            company_id=comp_id,
            event_type='financial.record_created',
            aggregate_type='financial_record',
            aggregate_id=str(f1.id),
            actor_id=admin.id,
            actor_name='Admin Alpha',
            payload_json=json.dumps({'amount': 50000.0})
        )
        ev2 = BusinessEvent(
            company_id=comp_id,
            event_type='financial.record_verified',
            aggregate_type='financial_record',
            aggregate_id=str(f1.id),
            actor_id=admin.id,
            actor_name='Admin Alpha',
            payload_json=json.dumps({'verified': True})
        )
        db.session.add_all([ev1, ev2])
        db.session.commit()

        lineage = DataQualityService.get_entity_lineage(comp_id, 'financial_record', f1.id)
        assert lineage['company_id'] == comp_id
        assert lineage['entity_id'] == f1.id
        assert lineage['events_count'] >= 2

        node_types = [n['type'] for n in lineage['nodes']]
        assert 'source' in node_types
        assert 'entity' in node_types
        assert 'event' in node_types
        assert 'consumer' in node_types


# -----------------------------------------------------------------------------
# TEST 5: Data Freshness Decay Logic
# -----------------------------------------------------------------------------
def test_data_freshness_decay_logic(app, quality_tenants):
    """Validate freshness score decay as data ages beyond 7, 30, 60, 90, 180 days."""
    with app.app_context():
        comp_b_id = quality_tenants['comp_b'].id
        today = date.today()

        # No records => score 0.0
        res0 = DataQualityService.evaluate_quality(comp_b_id)
        assert res0['dimensions']['freshness'] == 0.0

        rec1 = FinancialRecord(company_id=comp_b_id, transaction_type='revenue', amount=100.0, transaction_date=today - timedelta(days=10))
        db.session.add(rec1)
        db.session.commit()
        res1 = DataQualityService.evaluate_quality(comp_b_id)
        assert res1['dimensions']['freshness'] == 85.0

        rec1.transaction_date = today - timedelta(days=50)
        db.session.commit()
        res2 = DataQualityService.evaluate_quality(comp_b_id)
        assert res2['dimensions']['freshness'] == 65.0

        rec1.transaction_date = today - timedelta(days=80)
        db.session.commit()
        res3 = DataQualityService.evaluate_quality(comp_b_id)
        assert res3['dimensions']['freshness'] == 40.0

        rec1.transaction_date = today - timedelta(days=150)
        db.session.commit()
        res4 = DataQualityService.evaluate_quality(comp_b_id)
        assert res4['dimensions']['freshness'] == 20.0

        rec1.transaction_date = today - timedelta(days=250)
        db.session.commit()
        res5 = DataQualityService.evaluate_quality(comp_b_id)
        assert res5['dimensions']['freshness'] == 5.0


# -----------------------------------------------------------------------------
# TEST 6: Multi-Tenant Lineage and Quality Isolation
# -----------------------------------------------------------------------------
def test_multi_tenant_lineage_and_quality_isolation(client, quality_tenants):
    """Validate that quality evaluations and entity lineage are strictly tenant-isolated."""
    admin_a = quality_tenants['admin_a']
    f1_a = quality_tenants['f1']
    comp_b = quality_tenants['comp_b']

    with client.application.app_context():
        rec_b = FinancialRecord(
            company_id=comp_b.id,
            transaction_type='revenue',
            amount=9999.0,
            transaction_date=date.today()
        )
        db.session.add(rec_b)
        db.session.commit()
        rec_b_id = rec_b.id

    with client.session_transaction() as sess:
        sess['user_id'] = admin_a.id
        sess['_user_id'] = str(admin_a.id)
        sess['_fresh'] = True
        sess['company_id'] = admin_a.company_id
        sess['role'] = Role.ADMIN

    res_own = client.get(f'/data-lake/api/lineage/entity/financial/{f1_a.id}')
    assert res_own.status_code == 200
    data_own = res_own.get_json()
    assert data_own['company_id'] == admin_a.company_id

    res_cross = client.get(f'/data-lake/api/lineage/entity/financial/{rec_b_id}')
    assert res_cross.status_code == 404
    data_cross = res_cross.get_json()
    assert 'not found for this tenant' in data_cross['error']


# -----------------------------------------------------------------------------
# TEST 7: Viewer RBAC Rejection on Quality Scan (HTTP 403)
# -----------------------------------------------------------------------------
def test_viewer_rbac_rejection_on_quality_scan(client, quality_tenants):
    """Validate that VIEWER can read quality endpoints, but is forbidden (403) from triggering scans."""
    viewer = quality_tenants['viewer_a']

    # Log in as Viewer
    with client.session_transaction() as sess:
        sess['user_id'] = viewer.id
        sess['_user_id'] = str(viewer.id)
        sess['_fresh'] = True
        sess['company_id'] = viewer.company_id
        sess['role'] = Role.VIEWER

    # Viewer can read summary & rules
    res_summary = client.get('/data-lake/api/quality-summary')
    assert res_summary.status_code == 200
    res_rules = client.get('/data-lake/api/rules')
    assert res_rules.status_code == 200

    # Viewer CANNOT trigger scan mutation
    res_scan_viewer = client.post('/data-lake/api/scan')
    assert res_scan_viewer.status_code == 403


# -----------------------------------------------------------------------------
# TEST 7b: Admin RBAC Acceptance on Quality Scan (HTTP 200)
# -----------------------------------------------------------------------------
def test_admin_rbac_acceptance_on_quality_scan(client, quality_tenants):
    """Validate that ADMIN is authorized to trigger data quality scans."""
    admin = quality_tenants['admin_a']

    # Log in as Admin
    with client.session_transaction() as sess:
        sess['user_id'] = admin.id
        sess['_user_id'] = str(admin.id)
        sess['_fresh'] = True
        sess['company_id'] = admin.company_id
        sess['role'] = Role.ADMIN

    # Admin CAN trigger scan mutation
    res_scan_admin = client.post('/data-lake/api/scan')
    assert res_scan_admin.status_code == 200
    data_admin = res_scan_admin.get_json()
    assert data_admin['success'] is True
    assert 'quality' in data_admin


# -----------------------------------------------------------------------------
# TEST 8: Auditable Quality Rule Evaluations & Violation Tracking
# -----------------------------------------------------------------------------
def test_quality_rule_evaluations_and_violation_tracking(app, quality_tenants):
    """Validate detection and reporting of individual domain rules with exact failing IDs."""
    with app.app_context():
        comp_id = quality_tenants['comp_a'].id
        today = date.today()

        # 1. Rule FIN_001: Future transaction date
        f_future = FinancialRecord(company_id=comp_id, transaction_type='revenue', amount=1000.0, transaction_date=today + timedelta(days=10))
        # 2. Rule FIN_002: Negative amount
        f_neg = FinancialRecord(company_id=comp_id, transaction_type='expense', amount=-500.0, transaction_date=today)
        # 3. Rule INV_001: Negative stock
        inv_neg = Inventory(company_id=comp_id, sku='SKU-BAD-1', name='Damaged Gear', unit_cost=5.0, quantity_on_hand=-10)
        # 4. Rule INV_002: Duplicate SKUs
        inv_dup1 = Inventory(company_id=comp_id, sku='SKU-DUP-99', name='Part 1', unit_cost=10.0, quantity_on_hand=5)
        inv_dup2 = Inventory(company_id=comp_id, sku='SKU-DUP-99', name='Part 2', unit_cost=10.0, quantity_on_hand=5)
        # 5. Rule EMP_001: Active employee with zero salary
        emp_zero = Employee(company_id=comp_id, first_name='Unpaid', last_name='Intern', email='unpaid@alpha.corp', salary=0.0, status='active')
        # 6. Rule CUST_002: Duplicate customer emails
        cust_dup1 = Customer(company_id=comp_id, company_name='Dup One', email='duplicate@email.com')
        cust_dup2 = Customer(company_id=comp_id, company_name='Dup Two', email='duplicate@email.com')

        db.session.add_all([f_future, f_neg, inv_neg, inv_dup1, inv_dup2, emp_zero, cust_dup1, cust_dup2])
        db.session.commit()

        # 7. Rule REL_001 & REL_002: Orphaned foreign keys (using raw cursor with PRAGMA foreign_keys = OFF to simulate external dirty import)
        conn = db.engine.raw_connection()
        cur = conn.cursor()
        try:
            cur.execute("PRAGMA foreign_keys = OFF")
            cur.execute(
                "INSERT INTO employees (company_id, first_name, last_name, email, department_id, salary, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (comp_id, 'Lost', 'Worker', 'lost@alpha.corp', 999999, 50000.0, 'active', datetime.utcnow(), datetime.utcnow())
            )
            emp_orph_id = cur.lastrowid
            cur.execute(
                "INSERT INTO inventory (company_id, sku, name, unit_cost, quantity_on_hand, supplier_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (comp_id, 'SKU-LOST', 'Lost Stock', 1.0, 10, 999999, datetime.utcnow(), datetime.utcnow())
            )
            inv_orph_id = cur.lastrowid
            conn.commit()
            cur.execute("PRAGMA foreign_keys = ON")
        finally:
            cur.close()
            conn.close()

        eval_res = DataQualityService.evaluate_quality(comp_id)
        rules = {r['rule_id']: r for r in eval_res['rules']}

        assert rules['FIN_001']['passed'] is False
        assert f_future.id in rules['FIN_001']['sample_ids']

        assert rules['FIN_002']['passed'] is False
        assert f_neg.id in rules['FIN_002']['sample_ids']

        assert rules['INV_001']['passed'] is False
        assert inv_neg.id in rules['INV_001']['sample_ids']

        assert rules['INV_002']['passed'] is False
        assert inv_dup1.id in rules['INV_002']['sample_ids'] or inv_dup2.id in rules['INV_002']['sample_ids']

        assert rules['EMP_001']['passed'] is False
        assert emp_zero.id in rules['EMP_001']['sample_ids']

        assert rules['CUST_002']['passed'] is False
        assert cust_dup1.id in rules['CUST_002']['sample_ids'] or cust_dup2.id in rules['CUST_002']['sample_ids']

        assert rules['REL_001']['passed'] is False
        assert emp_orph_id in rules['REL_001']['sample_ids']

        assert rules['REL_002']['passed'] is False
        assert inv_orph_id in rules['REL_002']['sample_ids']


# -----------------------------------------------------------------------------
# TEST 9: Domain Events Published on Quality Scan
# -----------------------------------------------------------------------------
def test_domain_events_published_on_quality_scan(app, quality_tenants):
    """Validate that DATA_QUALITY_EVALUATED event is emitted onto the EventBus."""
    with app.app_context():
        comp_id = quality_tenants['comp_a'].id
        admin_id = quality_tenants['admin_a'].id

        dispatched_events = []

        def handle_event(event):
            dispatched_events.append(event)

        EventBus.subscribe(EventTypes.DATA_QUALITY_EVALUATED, handle_event)

        try:
            DataQualityService.evaluate_quality(comp_id, user_id=admin_id)

            assert len(dispatched_events) >= 1
            ev = dispatched_events[-1]
            assert ev.event_type == EventTypes.DATA_QUALITY_EVALUATED
            assert ev.company_id == comp_id
            assert ev.actor_id == admin_id
            assert 'score' in ev.payload
            assert 'dimensions' in ev.payload
        finally:
            EventBus.unsubscribe(EventTypes.DATA_QUALITY_EVALUATED, handle_event)


# -----------------------------------------------------------------------------
# TEST 10: Data Lake UI and API Consistency
# -----------------------------------------------------------------------------
def test_data_lake_ui_and_api_consistency(client, quality_tenants):
    """Validate that Data Lake HTML view renders with scorecards, meters, and API endpoints respond."""
    admin = quality_tenants['admin_a']

    with client.session_transaction() as sess:
        sess['user_id'] = admin.id
        sess['_user_id'] = str(admin.id)
        sess['_fresh'] = True
        sess['company_id'] = admin.company_id
        sess['role'] = Role.ADMIN

    # 1. UI Page
    res_ui = client.get('/data-lake/')
    assert res_ui.status_code == 200
    html = res_ui.get_data(as_text=True)
    assert 'Data Quality &amp; Lineage' in html or 'Data Quality & Lineage' in html
    assert 'Lineage Trace' in html or 'Lineage' in html
    assert 'Rules Engine' in html or 'Rule Audit' in html
    assert 'Run Quality Scan' in html

    # 2. Metric Lineage API
    res_lineage = client.get('/data-lake/api/lineage/metric/revenue_30d')
    assert res_lineage.status_code == 200
    lineage_data = res_lineage.get_json()
    assert lineage_data['metric'] == 'revenue_30d'
    assert len(lineage_data['nodes']) >= 4

    # 3. Anomalies API
    res_anomalies = client.get('/data-lake/api/anomalies')
    assert res_anomalies.status_code == 200
    anomalies_data = res_anomalies.get_json()
    assert 'anomalies' in anomalies_data
    assert 'count' in anomalies_data
