"""
Stage 30: Dead Code Cleanup & Archival Tests
Validates:
1. Removal of orphaned templates (e.g. templates/dashboard_goated.html).
2. Syntactic validity and compile check for 100% of active Jinja2 templates.
3. Clean repository root hygiene with legacy prototype scripts moved to archive/.
4. Clean application factory blueprint registration with zero dead blueprint references.
"""

import os
import pytest
from jinja2 import Environment, FileSystemLoader
from app import create_app

def test_1_orphaned_dashboard_goated_removed():
    """Verify templates/dashboard_goated.html is permanently removed from templates/."""
    assert not os.path.exists('templates/dashboard_goated.html'), "dashboard_goated.html must be removed"
    for root, _, files in os.walk('templates'):
        assert 'dashboard_goated.html' not in files

def test_2_all_active_templates_syntactically_valid():
    """Verify every HTML template in templates/ parses and compiles cleanly with Jinja2."""
    template_dir = os.path.abspath('templates')
    env = Environment(loader=FileSystemLoader(template_dir))
    
    html_count = 0
    for root, _, files in os.walk(template_dir):
        for file in files:
            if file.endswith('.html'):
                html_count += 1
                rel_path = os.path.relpath(os.path.join(root, file), template_dir).replace(chr(92), '/')
                # Check that template compiles without SyntaxError
                try:
                    with open(os.path.join(root, file), 'r', encoding='utf-8') as f:
                        source = f.read()
                    env.parse(source)
                except Exception as ex:
                    pytest.fail(f"Template {rel_path} failed Jinja2 syntax validation: {ex}")

    assert html_count > 20, f"Expected at least 20 active HTML templates, found {html_count}"

def test_3_root_directory_hygiene_and_archival():
    """Verify obsolete ad-hoc prototype scripts are removed from root and cataloged in archive/."""
    # Obsolete scripts that must NOT be in project root
    purged_root_scripts = [
        'dashboard_goated.html',
        'verify_live_fixes.py',
        'verify_enterprise.py',
        'verify_twin_tables.py',
        'smoke_test_fixes.py',
        'migrate_advanced_financials.py',
        'migrate_db.py',
        'migrate_enterprise.py',
        'migrate_twin_interconnection.py',
        'test_enterprise.py',
        'test_twin_interconnection.py',
        'add_columns.py',
        'check_db.py'
    ]
    for script in purged_root_scripts:
        assert not os.path.exists(script), f"Root directory must not contain obsolete script {script}"

    # Verify archive exists and contains cataloged scripts
    assert os.path.exists('archive/legacy_scripts'), "archive/legacy_scripts directory must exist"
    assert os.path.exists('archive/developer_tools'), "archive/developer_tools directory must exist"
    
    archived_files = os.listdir('archive/legacy_scripts')
    assert len(archived_files) >= 10, "Expected at least 10 legacy scripts in archive/legacy_scripts"
    assert 'verify_live_fixes.py' in archived_files
    assert 'smoke_test_fixes.py' in archived_files

def test_4_app_clean_blueprint_registration():
    """Verify application factory initializes without dead developer blueprint."""
    test_app = create_app({
        'TESTING': True,
        'WTF_CSRF_ENABLED': False,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:'
    })

    blueprints = set(test_app.blueprints.keys())

    # Dead blueprint must NOT be registered
    assert 'developer' not in blueprints, "Developer blueprint must not be registered in production factory"

    # Core production blueprints must be active
    required_blueprints = {
        'public', 'auth', 'dashboard', 'business_twin', 'simulation',
        'forecasting', 'risk_engine', 'analytics', 'reports', 'documents',
        'settings', 'scenario_builder', 'market_intelligence', 'financial_modeling',
        'customer_simulator', 'employee_simulator', 'supply_chain_simulator',
        'operations_simulator', 'ai_insights', 'data_lake', 'competition',
        'custom_twin', 'command_center', 'uploads', 'audit', 'twin_graph',
        'temporal', 'api_v1', 'jobs', 'health'
    }
    for bp in required_blueprints:
        assert bp in blueprints, f"Missing required production blueprint: {bp}"
