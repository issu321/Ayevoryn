"""
AEVORYN / INSIGHT-PULSE
STAGE 14: SCENARIO BRANCHING & SANDBOXED SIMULATION AUTOMATED TEST SUITE
Validates isolated sandbox scenario branching, zero mutation of live database records,
snapshot-based baselines, branch lineage trees, comparative variance analysis,
merge-to-plan governance, and RBAC / IDOR security.
"""

import pytest
from datetime import datetime, date, timedelta
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.financial import FinancialRecord
from database.models.scenario import Scenario, ScenarioStep, ScenarioStatus, BranchType
from database.models.twin_snapshot import TwinSnapshot, SnapshotType
from services.events import DomainEvent, EventBus, EventTypes
from services.temporal_service import TemporalService
from services.scenario_branching_service import ScenarioBranchingService
from security.rbac import Role, Permission


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage14'
    })
    with app.app_context():
        db.create_all()

        # Seed Tenant Alpha (Company 1)
        comp_a = Company(
            company_name='Branching Alpha Corp',
            business_name='Branching Alpha',
            owner_name='Alice Brancher',
            ceo_name='Arthur Brancher',
            total_equity=150000.0,
            annual_revenue_target=0.0,
            annual_expenses_plan=0.0
        )
        db.session.add(comp_a)

        # Seed Tenant Beta (Company 2)
        comp_b = Company(
            company_name='Branching Beta Corp',
            business_name='Branching Beta',
            owner_name='Bob Brancher',
            ceo_name='Boris Brancher',
            total_equity=60000.0,
            annual_revenue_target=0.0,
            annual_expenses_plan=0.0
        )
        db.session.add(comp_b)
        db.session.commit()

        # Seed Users for Company 1
        admin_a = User(
            username='alpha_admin_stage14',
            email='admin@branching-alpha.com',
            role=Role.ADMIN,
            company_id=comp_a.id,
            is_active=True
        )
        admin_a.set_password('password123')
        db.session.add(admin_a)

        viewer_a = User(
            username='alpha_viewer_stage14',
            email='viewer@branching-alpha.com',
            role=Role.VIEWER,
            company_id=comp_a.id,
            is_active=True
        )
        viewer_a.set_password('password123')
        db.session.add(viewer_a)

        # Seed Admin for Company 2
        admin_b = User(
            username='beta_admin_stage14',
            email='admin@branching-beta.com',
            role=Role.ADMIN,
            company_id=comp_b.id,
            is_active=True
        )
        admin_b.set_password('password123')
        db.session.add(admin_b)

        # Seed Baseline records for Company 1
        emp1 = Employee(
            company_id=comp_a.id,
            first_name='John',
            last_name='Doe',
            job_title='Software Engineer',
            salary=100000.0,
            hire_date=date(2025, 1, 1),
            status='active'
        )
        emp2 = Employee(
            company_id=comp_a.id,
            first_name='Jane',
            last_name='Smith',
            job_title='Sales Director',
            salary=120000.0,
            hire_date=date(2025, 2, 1),
            status='active'
        )
        db.session.add_all([emp1, emp2])

        # Revenue and Expense records for Company 1
        rec_rev = FinancialRecord(
            company_id=comp_a.id,
            transaction_type='revenue',
            amount=50000.0,
            transaction_date=date(2026, 3, 1),
            description='Q1 Enterprise Contract'
        )
        rec_exp = FinancialRecord(
            company_id=comp_a.id,
            transaction_type='expense',
            amount=30000.0,
            transaction_date=date(2026, 3, 5),
            description='Operating Costs'
        )
        db.session.add_all([rec_rev, rec_exp])
        db.session.commit()

        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def admin_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_admin_stage14').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def viewer_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_viewer_stage14').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def beta_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='beta_admin_stage14').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


# ============================================================================
# 1. MULTI-TENANT ISOLATION
# ============================================================================
def test_multi_tenant_scenario_isolation(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        comp_b = Company.query.filter_by(company_name='Branching Beta Corp').first()
        user_a = User.query.filter_by(username='alpha_admin_stage14').first()

        # Tenant A branches a scenario
        scen_a = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Alpha Project Titan',
            branch_type=BranchType.GROWTH,
            parameters={'revenue_delta_pct': 25.0, 'expense_delta_pct': 10.0}
        )
        assert scen_a.id is not None
        assert scen_a.company_id == comp_a.id

        # Tenant B cannot see Tenant A's scenarios
        scenarios_b = ScenarioBranchingService.get_scenarios(comp_b.id)
        assert len(scenarios_b) == 0

        # Tenant B cannot lookup Tenant A's scenario
        scen_lookup_b = ScenarioBranchingService.get_scenario_by_id(comp_b.id, scen_a.id)
        assert scen_lookup_b is None

        # Tenant B cannot evaluate Tenant A's scenario
        with pytest.raises(ValueError):
            ScenarioBranchingService.evaluate_branch(comp_b.id, scen_a.id)

        # Tenant B cannot delete Tenant A's scenario
        res_del = ScenarioBranchingService.delete_scenario(comp_b.id, scen_a.id)
        assert res_del is False


# ============================================================================
# 2. ZERO MUTATION OF LIVE DATABASE RECORDS
# ============================================================================
def test_zero_mutation_of_live_state(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        user_a = User.query.filter_by(username='alpha_admin_stage14').first()

        # Measure baseline live table row counts
        initial_financials = FinancialRecord.query.filter_by(company_id=comp_a.id).count()
        initial_employees = Employee.query.filter_by(company_id=comp_a.id).count()

        # Create scenario with heavy alterations (+50% rev, +10 headcount, +100k capex)
        scen = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Alpha Massive Scale',
            branch_type=BranchType.GROWTH,
            parameters={
                'revenue_delta_pct': 50.0,
                'expense_delta_pct': 30.0,
                'headcount_delta': 10,
                'capex_investment': 100000.0,
                'duration_months': 24
            }
        )

        # Evaluate scenario
        eval_result = ScenarioBranchingService.evaluate_branch(comp_a.id, scen.id)
        assert eval_result is not None
        assert eval_result['projected']['revenue'] > eval_result['baseline']['revenue']
        assert eval_result['projected']['headcount'] == initial_employees + 10

        # Verify live database records were completely unmutated
        assert FinancialRecord.query.filter_by(company_id=comp_a.id).count() == initial_financials
        assert Employee.query.filter_by(company_id=comp_a.id).count() == initial_employees


# ============================================================================
# 3. BRANCHING FROM SNAPSHOT VS LIVE BASELINE
# ============================================================================
def test_branch_from_snapshot_vs_live_baseline(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        user_a = User.query.filter_by(username='alpha_admin_stage14').first()

        # Create a frozen milestone snapshot
        snap = TemporalService.create_snapshot(
            company_id=comp_a.id,
            name='Q1 Freeze Milestone',
            snapshot_type=SnapshotType.MILESTONE,
            user_id=user_a.id
        )

        # Branch 1 off Live Digital Twin
        scen_live = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Live Baseline Branch',
            branch_type=BranchType.SANDBOX
        )

        # Branch 2 off Frozen Snapshot
        scen_snap = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Snapshot Milestone Branch',
            baseline_snapshot_id=snap.snapshot_id,
            branch_type=BranchType.STRATEGIC
        )

        # Evaluate both
        eval_live = ScenarioBranchingService.evaluate_branch(comp_a.id, scen_live.id)
        eval_snap = ScenarioBranchingService.evaluate_branch(comp_a.id, scen_snap.id)

        assert eval_live['baseline_source'] == 'Live Digital Twin'
        assert 'Snapshot: Q1 Freeze Milestone' in eval_snap['baseline_source']


# ============================================================================
# 4. BRANCH LINEAGE & HIERARCHICAL TREE
# ============================================================================
def test_branch_lineage_and_hierarchical_tree(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        user_a = User.query.filter_by(username='alpha_admin_stage14').first()

        # Create Root Branch
        root = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Main Growth Program',
            branch_type=BranchType.GROWTH,
            parameters={'revenue_delta_pct': 15.0, 'expense_delta_pct': 5.0}
        )

        # Create Child Branch 1 (Hiring Focus)
        child1 = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Aggressive Hiring Sub-Branch',
            parent_scenario_id=root.id,
            branch_type=BranchType.SANDBOX,
            parameters={'headcount_delta': 5}
        )

        # Create Child Branch 2 (Cost Cutting Focus)
        child2 = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Cost Containment Sub-Branch',
            parent_scenario_id=root.id,
            branch_type=BranchType.DOWNTURN,
            parameters={'expense_delta_pct': -15.0}
        )

        tree = ScenarioBranchingService.get_branch_lineage_tree(comp_a.id)
        assert len(tree) >= 1

        root_in_tree = next((r for r in tree if r['id'] == root.id), None)
        assert root_in_tree is not None
        assert 'children' in root_in_tree
        child_ids = [c['id'] for c in root_in_tree['children']]
        assert child1.id in child_ids
        assert child2.id in child_ids


# ============================================================================
# 5. MULTI-SCENARIO COMPARATIVE VARIANCE
# ============================================================================
def test_compare_branches_variance(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        user_a = User.query.filter_by(username='alpha_admin_stage14').first()

        # Branch A: Aggressive Growth
        scen_a = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Option A: Aggressive',
            branch_type=BranchType.GROWTH,
            parameters={'revenue_delta_pct': 30.0, 'expense_delta_pct': 20.0, 'capex_investment': 50000.0}
        )

        # Branch B: Lean Efficiency
        scen_b = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Option B: Lean',
            branch_type=BranchType.STRATEGIC,
            parameters={'revenue_delta_pct': 10.0, 'expense_delta_pct': -10.0, 'capex_investment': 10000.0}
        )

        # Compare A against Baseline
        comp_base = ScenarioBranchingService.compare_branches(comp_a.id, scen_a.id)
        assert comp_base['mode'] == 'BASELINE_VS_BRANCH'
        assert comp_base['variance']['revenue_delta'] > 0

        # Compare A against B
        comp_pair = ScenarioBranchingService.compare_branches(comp_a.id, scen_a.id, scen_b.id)
        assert comp_pair['mode'] == 'BRANCH_VS_BRANCH'
        assert 'comparison' in comp_pair
        assert 'revenue_diff' in comp_pair['comparison']
        assert 'profit_diff' in comp_pair['comparison']
        assert len(comp_pair['comparison']['recommendation']) > 0


# ============================================================================
# 6. MERGE SCENARIO TO PLAN GOVERNANCE
# ============================================================================
def test_merge_scenario_to_plan_governance(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        user_a = User.query.filter_by(username='alpha_admin_stage14').first()

        assert comp_a.annual_revenue_target == 0.0

        scen = ScenarioBranchingService.branch_scenario(
            company_id=comp_a.id,
            user_id=user_a.id,
            name='Strategic Approved Plan',
            branch_type=BranchType.STRATEGIC,
            parameters={'revenue_delta_pct': 20.0, 'expense_delta_pct': 5.0}
        )
        assert scen.status == ScenarioStatus.DRAFT

        # Merge to plan
        merge_res = ScenarioBranchingService.merge_to_plan(comp_a.id, scen.id, user_a.id)
        assert merge_res['success'] is True
        assert merge_res['status'] == ScenarioStatus.MERGED

        # Verify company targets were updated to projected values
        reloaded_comp = Company.query.get(comp_a.id)
        assert reloaded_comp.annual_revenue_target > 0.0
        assert reloaded_comp.annual_expenses_plan > 0.0

        # Verify zero mutation of historical ledger records
        assert FinancialRecord.query.filter_by(company_id=comp_a.id).count() == 2


# ============================================================================
# 7. ROUTE RBAC PERMISSIONS (ADMIN VS VIEWER)
# ============================================================================
def test_scenario_routes_admin_access(app, admin_client):
    # Admin visits scenario studio
    res_index = admin_client.get('/scenario/')
    assert res_index.status_code == 200
    assert b'Scenario' in res_index.data

    # Admin branches a scenario via JSON API
    res_branch = admin_client.post('/scenario/api/branch', json={
        'name': 'API Admin Branch',
        'branch_type': 'SANDBOX',
        'parameters': {'revenue_delta_pct': 10.0}
    })
    assert res_branch.status_code == 201
    branch_data = res_branch.get_json()
    scen_id = branch_data['scenario']['id']

    # Admin evaluates branch
    res_eval = admin_client.post(f'/scenario/api/evaluate/{scen_id}')
    assert res_eval.status_code == 200
    assert res_eval.get_json()['success'] is True

    # Admin merges branch
    res_merge = admin_client.post(f'/scenario/api/merge/{scen_id}')
    assert res_merge.status_code == 200
    assert res_merge.get_json()['status'] == 'MERGED'


def test_scenario_routes_viewer_forbidden(app, viewer_client):
    # Seed a scenario directly in database for testing viewer restrictions
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Branching Alpha Corp').first()
        user_v = User.query.filter_by(username='alpha_viewer_stage14').first()
        scen = Scenario(
            company_id=comp_a.id,
            user_id=user_v.id,
            name='Viewer Target Scenario',
            status=ScenarioStatus.EVALUATED
        )
        db.session.add(scen)
        db.session.commit()
        scen_id = scen.id

    # Viewer can view studio
    res_vindex = viewer_client.get('/scenario/')
    assert res_vindex.status_code == 200

    # Viewer cannot branch scenario (Forbidden 403)
    res_vbranch = viewer_client.post('/scenario/api/branch', json={
        'name': 'Unauthorized Branch'
    })
    assert res_vbranch.status_code == 403

    # Viewer cannot merge scenario (Forbidden 403)
    res_vmerge = viewer_client.post(f'/scenario/api/merge/{scen_id}')
    assert res_vmerge.status_code == 403


# ============================================================================
# 8. TENANT IDOR PROTECTION ACROSS SCENARIO ROUTES
# ============================================================================
def test_scenario_tenant_idor_forbidden(app, admin_client, beta_client):
    # Admin A creates scenario
    res_branch = admin_client.post('/scenario/api/branch', json={
        'name': 'Tenant Alpha Confidential Branch'
    })
    assert res_branch.status_code == 201
    scen_id = res_branch.get_json()['scenario']['id']

    # Admin B attempts to access / evaluate / merge / delete Tenant A scenario
    # Run / evaluate
    res_run = beta_client.post(f'/scenario/run/{scen_id}')
    assert res_run.status_code == 404

    res_eval = beta_client.post(f'/scenario/api/evaluate/{scen_id}')
    assert res_eval.status_code == 404

    # Compare
    res_comp = beta_client.get(f'/scenario/api/compare/{scen_id}')
    assert res_comp.status_code == 404

    # Merge
    res_merge = beta_client.post(f'/scenario/api/merge/{scen_id}')
    assert res_merge.status_code == 404

    # Delete
    res_del = beta_client.post(f'/scenario/delete/{scen_id}')
    assert res_del.status_code == 404
