"""
Stage 29: Comprehensive Regression Test Suite
Executes end-to-end integration workflows against a dedicated, isolated test database environment.
Validates:
1. Isolated test database harness & schema/index integrity (zero pollution of live DB)
2. Multi-tenant lifecycle & RBAC boundary enforcement (IDOR prevention, role permissions)
3. Full 7-pillar Digital Twin CRUD lifecycle (Revenue, Expense, Dept, Employee, Supplier, Inventory, Custom Twin)
4. Financial correctness & canonical state propagation (mathematical runway, provenance)
5. Domain events & immutable audit trail (EventBus, BusinessEvent, ActivityLog)
6. Twin dependency graph & impact propagation (blast radius, operational risk triggers)
7. Temporal snapshotting & scenario branching (sandbox isolation, zero mutation of live baseline)
8. Background job execution & telemetry observability (/healthz, /readiness, /health/metrics)
"""

import os
import pytest
from datetime import datetime, date, timedelta
from flask import session
from sqlalchemy import text, inspect

from app import create_app
from database.db import db, _heal_schema
from database.models import (
    Company, User, Department, Employee, Customer, Supplier,
    Inventory, FinancialRecord, FinancialAccount, Risk, ActivityLog,
    CustomTwin, CustomTwinRecord, CoreTwinExtraRecord,
    BusinessEvent, TwinDependency, DependencyType,
    ImpactTrace, ImpactSeverity, TwinSnapshot, SnapshotType,
    Scenario, ScenarioStep, ScenarioStatus, BranchType, BackgroundJob
)
from security.rbac import RBACService, Role, Permission
from services.business_state_service import BusinessStateService, ProvenanceType
from services.events import DomainEvent, EventBus, EventTypes
from services.twin_dependency_service import TwinDependencyService
from services.impact_engine import ImpactEngine
from services.temporal_service import TemporalService
from services.scenario_branching_service import ScenarioBranchingService
from services.job_service import JobService

TEST_DB_PATH = os.path.abspath('instance/test_isolated_regression.db').replace(chr(92), '/')

@pytest.fixture(scope='module')
def isolated_env():
    """Module-scoped isolated test environment targeting instance/test_isolated_regression.db."""
    test_app = create_app({
        'TESTING': True,
        'WTF_CSRF_ENABLED': False,
        'SQLALCHEMY_DATABASE_URI': f'sqlite:///{TEST_DB_PATH}',
        'SQLALCHEMY_TRACK_MODIFICATIONS': False
    })

    with test_app.app_context():
        # Clean slate
        db.session.remove()
        db.drop_all()
        db.create_all()
        _heal_schema()

        # Enforce foreign keys
        with db.engine.connect() as conn:
            conn.execute(text("PRAGMA foreign_keys = ON;"))
            conn.commit()

        yield test_app

        # Teardown
        db.session.remove()
        db.engine.dispose()
        if os.path.exists(TEST_DB_PATH):
            try:
                os.remove(TEST_DB_PATH)
            except Exception:
                pass

@pytest.fixture
def client(isolated_env):
    """Test client bound to the isolated test application."""
    with isolated_env.test_client() as c:
        yield c

def test_1_isolated_db_harness_and_schema_integrity(isolated_env):
    """Verify isolated database harness, table creation, composite indexes, and foreign keys."""
    with isolated_env.app_context():
        # 1. Verify we are not targeting production database
        assert 'test_isolated_regression.db' in str(db.engine.url)
        assert 'business_simulator.db' not in str(db.engine.url)

        # 2. Verify all core tables exist in schema
        insp = inspect(db.engine)
        tables = set(insp.get_table_names())
        required_tables = {
            'companies', 'users', 'departments', 'employees', 'customers',
            'suppliers', 'inventory', 'financial_records', 'financial_accounts',
            'risks', 'activity_logs', 'custom_twins', 'custom_twin_records',
            'business_events', 'background_jobs', 'scenarios', 'scenario_steps',
            'twin_snapshots', 'twin_dependencies', 'impact_traces'
        }
        for tbl in required_tables:
            assert tbl in tables, f"Missing table: {tbl}"

        # 3. Verify Stage 28 composite indexes exist in SQLite catalog
        with db.engine.connect() as conn:
            idx_rows = conn.execute(text("SELECT name FROM sqlite_master WHERE type='index'")).fetchall()
            catalog_indexes = {r[0] for r in idx_rows}

        expected_indexes = [
            'idx_employees_company_status',
            'idx_employees_company_dept',
            'idx_inventory_company_active',
            'idx_inventory_company_supplier',
            'idx_customers_company_status',
            'idx_customers_company_churn',
            'idx_suppliers_company_status',
            'idx_suppliers_company_primary',
            'idx_departments_company_active',
            'idx_activity_logs_company_created',
            'idx_financial_records_company_dept_type',
            'idx_risks_company_status_score'
        ]
        for idx in expected_indexes:
            assert idx in catalog_indexes, f"Index {idx} not found in sqlite_master"

def test_2_workflow_tenant_lifecycle_and_rbac_boundaries(isolated_env, client):
    """Workflow 1: Multi-tenant onboarding, IDOR prevention, and RBAC boundary enforcement."""
    with isolated_env.app_context():
        # Create Tenant Alpha
        comp_a = Company(
            company_name="Alpha Corp", business_name="Alpha Corp",
            owner_name="Alice Owner", ceo_name="Alice CEO", currency="USD"
        )
        # Create Tenant Beta
        comp_b = Company(
            company_name="Beta Inc", business_name="Beta Inc",
            owner_name="Bob Owner", ceo_name="Bob CEO", currency="EUR"
        )
        db.session.add_all([comp_a, comp_b])
        db.session.commit()

        # Create Tenant Alpha Owner
        u_a_owner = User(username='alpha_owner', email='alpha_owner@test.com', role='Owner', company_id=comp_a.id)
        u_a_owner.set_password('Secret123!')

        # Create Tenant Alpha Viewer
        u_a_viewer = User(username='alpha_viewer', email='alpha_viewer@test.com', role='Viewer', company_id=comp_a.id)
        u_a_viewer.set_password('Secret123!')

        # Create Tenant Beta Owner
        u_b_owner = User(username='beta_owner', email='beta_owner@test.com', role='Owner', company_id=comp_b.id)
        u_b_owner.set_password('Secret123!')

        db.session.add_all([u_a_owner, u_a_viewer, u_b_owner])
        db.session.commit()

        # Add an asset to Tenant Alpha
        dept_a = Department(company_id=comp_a.id, name="Alpha Engineering", budget=100000.0)
        db.session.add(dept_a)
        db.session.commit()
        dept_a_id = dept_a.id
        u_b_id = u_b_owner.id
        comp_b_id = comp_b.id
        u_a_id = u_a_owner.id
        comp_a_id = comp_a.id

        # RBAC programmatic enforcement
        assert RBACService.has_permission(Permission.DATA_WRITE, u_a_owner) is True
        assert RBACService.has_permission(Permission.DATA_WRITE, u_a_viewer) is False
        assert RBACService.has_role(Role.ADMIN, u_a_owner) is True
        assert RBACService.has_role(Role.ADMIN, u_a_viewer) is False

    # 1. Test Tenant Beta cannot access or mutate Tenant Alpha department (IDOR protection)
    with client.session_transaction() as sess:
        sess['_user_id'] = str(u_b_id)
        sess['user_id'] = u_b_id
        sess['company_id'] = comp_b_id
        sess['role'] = 'Owner'

    res = client.post(f'/business-twin/departments/edit/{dept_a_id}', json={'name': 'Hacked Dept', 'budget': 999999})
    assert res.status_code in (403, 404), "Tenant Beta must not be able to edit Tenant Alpha's department"

    # Verify department was not altered
    with isolated_env.app_context():
        d = db.session.get(Department, dept_a_id)
        assert d.name == "Alpha Engineering"

    # 2. Test Tenant Alpha Owner can access authenticated dashboard
    with client.session_transaction() as sess:
        sess['_user_id'] = str(u_a_id)
        sess['user_id'] = u_a_id
        sess['company_id'] = comp_a_id
        sess['role'] = 'Owner'

    res = client.get('/dashboard')
    assert res.status_code in (200, 302)

def test_3_workflow_7_pillar_digital_twin_crud_lifecycle(isolated_env):
    """Workflow 2: Full CRUD and relationship integrity across all 7 Digital Twin pillars."""
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Alpha Corp").first()
        cid = comp.id

        # 1. Pillar 1: Departments
        dept = Department(company_id=cid, name="Product R&D", budget=250000.0, is_active=True)
        db.session.add(dept)
        db.session.flush()

        # 2. Pillar 2: Employees
        emp = Employee(
            company_id=cid, department_id=dept.id, first_name="Elena", last_name="Rostova",
            email="elena@alpha.com", job_title="Lead Architect", salary=140000.0, status="active"
        )
        db.session.add(emp)
        db.session.flush()

        # 3. Pillar 3: Suppliers
        sup = Supplier(
            company_id=cid, name="Quantum Chipsets Ltd", category="Hardware",
            status="active", is_primary=True, rating=4.8, total_spend=75000.0
        )
        db.session.add(sup)
        db.session.flush()

        # 4. Pillar 4: Inventory
        item = Inventory(
            company_id=cid, supplier_id=sup.id, sku="QPU-9000", name="Quantum Core Processor",
            category="Semiconductors", quantity_on_hand=50, quantity_available=45,
            reorder_point=20, max_stock=100, unit_cost=450.0, is_active=True
        )
        db.session.add(item)
        db.session.flush()

        # 5. Pillar 5: Customers
        cust = Customer(
            company_id=cid, first_name="Global", last_name="Logistics",
            email="ops@globallogistics.com", status="active", lifetime_value=120000.0, acquisition_cost=5000.0
        )
        db.session.add(cust)
        db.session.flush()

        # 6. Pillar 6: Financials
        rev_tx = FinancialRecord(
            company_id=cid, department_id=dept.id, transaction_type="revenue",
            amount=85000.0, transaction_date=date.today(), description="Q3 Enterprise License"
        )
        exp_tx = FinancialRecord(
            company_id=cid, department_id=dept.id, transaction_type="expense",
            amount=35000.0, transaction_date=date.today(), description="Server Cluster Lease"
        )
        db.session.add_all([rev_tx, exp_tx])
        db.session.flush()

        # 7. Pillar 7: Custom Twins
        custom_twin = CustomTwin(
            company_id=cid,
            name="Satellite Constellations",
            slug="satellite-constellations",
            description="Orbital asset digital twin",
            icon="fa-satellite"
        )
        custom_twin.set_field_definitions([
            {"name": "orbit_altitude_km", "type": "number"},
            {"name": "status", "type": "string"}
        ])
        db.session.add(custom_twin)
        db.session.flush()

        twin_rec = CustomTwinRecord(
            twin_id=custom_twin.id,
            company_id=cid
        )
        twin_rec.set_data({"orbit_altitude_km": 550, "status": "operational"})
        db.session.add(twin_rec)
        db.session.commit()

        # Verify all 7 pillars exist and are queryable
        assert Department.query.filter_by(company_id=cid).count() >= 1
        assert Employee.query.filter_by(company_id=cid).count() >= 1
        assert Supplier.query.filter_by(company_id=cid).count() >= 1
        assert Inventory.query.filter_by(company_id=cid).count() >= 1
        assert Customer.query.filter_by(company_id=cid).count() >= 1
        assert FinancialRecord.query.filter_by(company_id=cid).count() >= 2
        assert CustomTwin.query.filter_by(company_id=cid).count() >= 1
        assert CustomTwinRecord.query.filter_by(company_id=cid).count() >= 1

def test_4_workflow_financial_correctness_and_canonical_state(isolated_env):
    """Workflow 3: Mathematical correctness of canonical state, cash runway, and provenance."""
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Alpha Corp").first()
        cid = comp.id

        # Setup cash reserve
        acc = FinancialAccount(
            company_id=cid, account_name="Main Treasury Checking",
            account_type="checking", current_balance=150000.0, is_active=True
        )
        db.session.add(acc)
        db.session.commit()

        # Evaluate canonical state
        state = BusinessStateService.get_canonical_state(cid)
        metrics = state['metrics']

        # Revenue & Expense resolution
        assert metrics['revenue'].value == 85000.0
        assert metrics['revenue'].provenance == ProvenanceType.OBSERVED
        assert metrics['expenses'].value == 35000.0
        assert metrics['expenses'].provenance == ProvenanceType.OBSERVED

        # Profit & Margin
        assert metrics['profit'].value == 50000.0
        assert round(metrics['margin'].value, 1) == 58.8  # (50000 / 85000) * 100

        # Cash balance provenance
        assert metrics['cash_balance'].value == 150000.0
        assert metrics['cash_balance'].provenance == ProvenanceType.OBSERVED

        # Runway: Profitable state is self-sustaining (runway is sustainable)
        assert metrics['runway'].metadata['is_sustainable'] is True

        # Now test cash-burning scenario (expenses > revenue)
        # Add high expense to induce burn
        burn_exp = FinancialRecord(
            company_id=cid, transaction_type="expense",
            amount=150000.0, transaction_date=date.today(), description="Emergency Capex"
        )
        db.session.add(burn_exp)
        db.session.commit()

        burning_state = BusinessStateService.get_canonical_state(cid)
        burn_runway = burning_state['metrics']['runway']
        
        # Monthly net burn: (185000 - 85000) = 100,000/month
        # Runway: 150,000 cash / 100,000 monthly burn = 1.5 months
        # Verifies NO 30x overstatement!
        assert burn_runway.value == pytest.approx(1.5, 0.1)
        assert burn_runway.value < 10.0, "Runway must not exhibit 30x overstatement bug"

def test_5_workflow_domain_events_and_audit_trail(isolated_env):
    """Workflow 4: Domain event publishing and ActivityLog audit synchronization."""
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Alpha Corp").first()
        cid = comp.id

        # Publish a domain event
        event_name = "employee.promoted"
        payload = {"employee_id": 1, "previous_salary": 140000, "new_salary": 165000}
        
        domain_ev = DomainEvent.create(
            event_type=event_name,
            company_id=cid,
            aggregate_type="employee",
            aggregate_id="1",
            actor_id=1,
            actor_name="Admin",
            payload=payload
        )
        EventBus.publish(domain_ev)

        # Verify BusinessEvent record exists
        evt = BusinessEvent.query.filter_by(company_id=cid, event_type=event_name).first()
        assert evt is not None
        assert evt.get_payload()['new_salary'] == 165000

        # Verify ActivityLog record was automatically synchronized with correct tenant binding
        log = ActivityLog.query.filter_by(company_id=cid, activity_type=event_name).first()
        assert log is not None
        assert log.module == "employee"

def test_6_workflow_dependency_graph_and_impact_propagation(isolated_env):
    """Workflow 5: Twin dependency graph resolution, blast radius, and impact propagation."""
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Alpha Corp").first()
        cid = comp.id

        # 1. Build multi-layer digital twin graph
        graph = TwinDependencyService.build_graph(cid)
        assert 'nodes' in graph
        assert 'edges' in graph
        assert 'summary' in graph
        assert graph['summary']['total_nodes'] > 0
        assert graph['summary']['total_edges'] > 0

        # 2. Topological order evaluation
        topo = TwinDependencyService.get_topological_order(graph['nodes'], graph['edges'])
        assert len(topo['ordered_nodes']) > 0

        # 3. Simulate impact propagation on inventory stockout trigger
        item = Inventory.query.filter_by(company_id=cid).first()
        assert item is not None, "Inventory item must exist from test 3"
        item.quantity_on_hand = 0
        item.quantity_available = 0
        db.session.commit()

        stockout_event = DomainEvent.create(
            event_type=EventTypes.INVENTORY_ITEM_UPDATED,
            company_id=cid,
            aggregate_type='inventory',
            aggregate_id=str(item.id),
            actor_id=1,
            payload={'sku': item.sku, 'quantity': 0, 'name': item.name}
        )
        trace = ImpactEngine.propagate_event(stockout_event, dry_run=False)
        assert trace is not None
        assert trace.severity in (ImpactSeverity.HIGH, ImpactSeverity.CRITICAL)

        # Verify operational risk trigger was registered
        risk = Risk.query.filter_by(company_id=cid).first()
        assert risk is not None
        assert "Stockout" in risk.name or risk.category == "Operational"

def test_7_workflow_temporal_snapshot_and_scenario_branching(isolated_env):
    """Workflow 6: Point-in-time snapshot, isolated sandbox branching, and zero live mutations."""
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Alpha Corp").first()
        cid = comp.id
        initial_revenue = comp.annual_revenue

        # 1. Capture snapshot of live state
        snapshot = TemporalService.create_snapshot(
            company_id=cid,
            name="Q3 Basepoint Snapshot",
            description="Pre-expansion baseline snapshot",
            user_id=1,
            actor_name="Admin"
        )
        assert snapshot is not None
        assert snapshot.company_id == cid
        assert snapshot.snapshot_id is not None

        # 2. Branch into isolated scenario sandbox
        branch = ScenarioBranchingService.branch_scenario(
            company_id=cid,
            user_id=1,
            name="Hyper-Growth Scenario",
            description="Simulating 2x hiring and marketing expansion",
            baseline_snapshot_id=snapshot.snapshot_id,
            parameters={
                'revenue_delta_pct': 50.0,
                'expense_delta_pct': 20.0,
                'headcount_delta': 5,
                'capex_investment': 50000.0
            }
        )
        assert branch is not None
        assert branch.company_id == cid

        # 3. Evaluate forward projection and scenario variance
        evaluation = ScenarioBranchingService.evaluate_branch(
            company_id=cid,
            scenario_id=branch.id
        )
        assert evaluation is not None
        assert 'variance' in evaluation
        assert 'projected' in evaluation
        assert evaluation['variance']['revenue_delta_pct'] == 50.0
        assert evaluation['variance']['net_benefit'] is not None

        # 4. CRITICAL INVARIANT: Verify live operational Company record was NOT mutated
        live_comp = db.session.get(Company, cid)
        assert live_comp.annual_revenue == initial_revenue, "Live Company record must not be mutated by scenario simulation"

def test_8_workflow_background_jobs_and_observability(isolated_env, client):
    """Workflow 7: Background job lifecycle execution and observability health endpoints."""
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Alpha Corp").first()
        cid = comp.id

        # Submit and execute background job synchronously for deterministic assertion
        job = JobService.submit_job(
            company_id=cid,
            user_id=1,
            job_type="batch_import",
            payload={"domain": "general", "records": [{"name": "item1"}, {"name": "item2"}]},
            synchronous=True
        )
        assert job is not None
        assert job.company_id == cid
        assert job.status == 'completed'
        assert job.progress == 100

    # Test observability endpoints
    # 1. /healthz (liveness)
    res_liveness = client.get('/healthz')
    assert res_liveness.status_code == 200
    data_liveness = res_liveness.get_json()
    assert data_liveness.get('status') == 'healthy'

    # 2. /readiness (deep database readiness probe)
    res_readiness = client.get('/readiness')
    assert res_readiness.status_code == 200
    data_readiness = res_readiness.get_json()
    assert data_readiness.get('status') == 'ready'

    # 3. /health/metrics (telemetry metrics)
    res_metrics = client.get('/health/metrics')
    assert res_metrics.status_code == 200
    data_metrics = res_metrics.get_json()
    assert 'uptime_seconds' in data_metrics
