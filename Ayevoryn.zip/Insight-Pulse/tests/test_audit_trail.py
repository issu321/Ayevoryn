import pytest
import io
import csv
from datetime import datetime, timedelta
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.business_event import BusinessEvent
from database.models.audit_log import AuditLog
from services.events import DomainEvent, EventBus, EventTypes
from services.audit_service import AuditService
from security.rbac import Role, Permission


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage10'
    })
    with app.app_context():
        db.create_all()

        # Seed Company 1 (Tenant A)
        comp_a = Company(
            company_name='Audit Corp Alpha',
            business_name='Audit Corp Alpha',
            owner_name='Alpha Owner',
            ceo_name='Alpha CEO'
        )
        db.session.add(comp_a)
        db.session.commit()

        # Seed Company 2 (Tenant B)
        comp_b = Company(
            company_name='Audit Corp Beta',
            business_name='Audit Corp Beta',
            owner_name='Beta Owner',
            ceo_name='Beta CEO'
        )
        db.session.add(comp_b)
        db.session.commit()

        # Seed Admin user for Company 1
        admin_user = User(
            username='alpha_admin',
            email='admin@alpha.org',
            role=Role.ADMIN,
            company_id=comp_a.id
        )
        admin_user.set_password('password123')
        db.session.add(admin_user)

        # Seed Viewer user for Company 1 (no audit:view permission)
        viewer_user = User(
            username='alpha_viewer',
            email='viewer@alpha.org',
            role=Role.VIEWER,
            company_id=comp_a.id
        )
        viewer_user.set_password('password123')
        db.session.add(viewer_user)
        db.session.commit()

        EventBus.clear_subscribers()
        yield app
        EventBus.clear_subscribers()
        db.session.remove()
        db.drop_all()


@pytest.fixture
def admin_client(app):
    client = app.test_client()
    with client.session_transaction() as sess:
        with app.app_context():
            user = User.query.filter_by(username='alpha_admin').first()
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def viewer_client(app):
    client = app.test_client()
    with client.session_transaction() as sess:
        with app.app_context():
            user = User.query.filter_by(username='alpha_viewer').first()
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


# =============================================================================
# 1. MULTI-TENANT ISOLATION
# =============================================================================

def test_audit_multi_tenant_isolation(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Audit Corp Alpha').first()
        comp_b = Company.query.filter_by(company_name='Audit Corp Beta').first()

        # Create event for Tenant A
        ev_a = DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=comp_a.id,
            aggregate_type='financial_record',
            aggregate_id='101',
            payload={'amount': 1000}
        )
        EventBus.publish(ev_a)

        # Create event for Tenant B
        ev_b = DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=comp_b.id,
            aggregate_type='financial_record',
            aggregate_id='202',
            payload={'amount': 9999}
        )
        EventBus.publish(ev_b)

        # Tenant A query
        res_a = AuditService.get_events(company_id=comp_a.id)
        assert res_a['total'] == 1
        assert res_a['items'][0]['aggregate_id'] == '101'

        # Tenant B query
        res_b = AuditService.get_events(company_id=comp_b.id)
        assert res_b['total'] == 1
        assert res_b['items'][0]['aggregate_id'] == '202'


# =============================================================================
# 2. FILTERING & SEARCH
# =============================================================================

def test_audit_service_filtering_and_search(app):
    with app.app_context():
        comp = Company.query.first()
        now = datetime.utcnow()

        # Seed 3 events with different actors and aggregates
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=comp.id,
            aggregate_type='financial_record',
            aggregate_id='1',
            actor_name='Alice Analyst',
            payload={'amount': 500.0, 'category': 'Supplies'}
        ))

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.EMPLOYEE_CREATED,
            company_id=comp.id,
            aggregate_type='employee',
            aggregate_id='2',
            actor_name='Bob HR',
            payload={'name': 'Charlie', 'role': 'Developer'}
        ))

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.DEPARTMENT_CREATED,
            company_id=comp.id,
            aggregate_type='department',
            aggregate_id='3',
            actor_name='Alice Analyst',
            payload={'name': 'Engineering'}
        ))

        # Filter by actor_name
        alice_res = AuditService.get_events(company_id=comp.id, actor_name='Alice')
        assert alice_res['total'] == 2

        # Filter by aggregate_type
        emp_res = AuditService.get_events(company_id=comp.id, aggregate_type='employee')
        assert emp_res['total'] == 1
        assert emp_res['items'][0]['aggregate_id'] == '2'

        # Search term in payload
        search_res = AuditService.get_events(company_id=comp.id, search='Developer')
        assert search_res['total'] == 1
        assert search_res['items'][0]['aggregate_type'] == 'employee'

        # Wildcard event type search
        fin_res = AuditService.get_events(company_id=comp.id, event_type='financial.*')
        assert fin_res['total'] == 1


# =============================================================================
# 3. ENTITY MUTATION TIMELINE & DIFFS
# =============================================================================

def test_entity_timeline_diff_reconstruction(app):
    with app.app_context():
        comp = Company.query.first()
        now = datetime.utcnow()

        # Event 1: Record created
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.CUSTOM_RECORD_CREATED,
            company_id=comp.id,
            aggregate_type='custom_record',
            aggregate_id='500',
            occurred_at=now,
            payload={'price': 100, 'status': 'Pending', 'qty': 5}
        ))

        # Event 2: Record updated (price changed to 150, status changed to Approved)
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.CUSTOM_RECORD_UPDATED,
            company_id=comp.id,
            aggregate_type='custom_record',
            aggregate_id='500',
            occurred_at=now + timedelta(minutes=5),
            payload={'price': 150, 'status': 'Approved', 'qty': 5}
        ))

        timeline = AuditService.get_entity_timeline(
            company_id=comp.id,
            aggregate_type='custom_record',
            aggregate_id='500'
        )

        assert len(timeline) == 2
        # First event has no diff (initial state)
        assert timeline[0]['diff'] == {}
        # Second event computes diff accurately
        diff = timeline[1]['diff']
        assert 'price' in diff
        assert diff['price']['old'] == 100
        assert diff['price']['new'] == 150
        assert 'status' in diff
        assert diff['status']['old'] == 'Pending'
        assert diff['status']['new'] == 'Approved'
        # Unchanged field 'qty' is not in diff
        assert 'qty' not in diff


# =============================================================================
# 4. AUDIT SUMMARY & CSV EXPORT
# =============================================================================

def test_audit_summary_and_csv_export(app):
    with app.app_context():
        comp = Company.query.first()

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=comp.id,
            aggregate_type='financial_record',
            aggregate_id='77',
            actor_name='Super Admin',
            payload={'amount': 25000}
        ))

        # Seed a security log
        sec_log = AuditLog(
            company_id=comp.id,
            username='superadmin',
            action='password_changed',
            status='success'
        )
        db.session.add(sec_log)
        db.session.commit()

        summary = AuditService.get_audit_summary(company_id=comp.id, days=7)
        assert summary['total_events'] == 1
        assert summary['security_events_count'] == 1
        assert summary['top_module'] == 'financial_record'

        csv_text = AuditService.export_events_csv(company_id=comp.id)
        assert 'Event ID,Occurred At (UTC),Event Type,Aggregate Type' in csv_text
        assert 'financial.transaction.created' in csv_text
        assert 'financial_record' in csv_text
        assert '25000' in csv_text


# =============================================================================
# 5. ROUTE INTEGRATION & RBAC AUTHORIZATION
# =============================================================================

def test_audit_routes_admin_access(admin_client, app):
    with app.app_context():
        comp = Company.query.first()

        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.CUSTOMER_CREATED,
            company_id=comp.id,
            aggregate_type='customer',
            aggregate_id='888',
            payload={'name': 'Wayne Enterprises'}
        ))

    # 1. Admin access to UI
    res_ui = admin_client.get('/audit/')
    assert res_ui.status_code == 200
    assert b'Enterprise Audit Trail' in res_ui.data

    # 2. Admin access to API events
    res_api = admin_client.get('/audit/api/events?aggregate_type=customer')
    assert res_api.status_code == 200
    api_data = res_api.get_json()
    assert api_data['success'] is True
    assert len(api_data['data']) == 1
    assert api_data['data'][0]['aggregate_id'] == '888'

    # 3. Admin access to API entity history
    res_history = admin_client.get('/audit/api/entity/customer/888')
    assert res_history.status_code == 200
    hist_data = res_history.get_json()
    assert hist_data['success'] is True
    assert len(hist_data['timeline']) == 1

    # 4. Admin access to CSV export
    res_csv = admin_client.get('/audit/export-csv')
    assert res_csv.status_code == 200
    assert 'text/csv' in res_csv.content_type
    assert 'attachment; filename=audit_trail_' in res_csv.headers.get('Content-Disposition', '')
    assert b'Wayne Enterprises' in res_csv.data


def test_audit_routes_viewer_forbidden(viewer_client):
    # Viewer role forbidden (HTTP 403)
    res_viewer = viewer_client.get('/audit/')
    assert res_viewer.status_code == 403

