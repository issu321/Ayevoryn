"""
TEST SUITE: Stage 22 - Versioned API Foundation & Webhooks
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. Standardized JSON envelope schema (success, data, meta, error).
2. Unauthenticated request rejection (HTTP 401 with standard error envelope).
3. API key generation, hashing, and authentication via X-API-Key and Bearer headers.
4. JWT token issuance via /api/v1/auth/token and bearer authentication.
5. Strict multi-tenant isolation across all /api/v1 endpoints (cross-tenant IDOR prevention).
6. RBAC authorization enforcement on API keys and tokens (Viewer rejection on writes).
7. Canonical business state endpoint (/api/v1/state/canonical).
8. Digital twin entity pagination and CRUD (/api/v1/twins/<domain>).
9. Monte Carlo simulation API execution (/api/v1/simulations/run).
10. Data quality and metric lineage DAG endpoints.
11. Webhook subscription lifecycle (CRUD) and tenant isolation.
12. Webhook HMAC-SHA256 signature verification and delivery audit logging.
13. EventBus domain event triggering webhook delivery.
"""

import pytest
import json
import hmac
import hashlib
from unittest.mock import patch, MagicMock
from datetime import datetime, timedelta

from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.api_key import ApiKey
from database.models.webhook import WebhookSubscription, WebhookDelivery
from database.models.financial import FinancialRecord
from database.models.customer import Customer
from security.rbac import Role, Permission
from services.events import EventBus, DomainEvent, EventTypes
from services.webhook_service import WebhookService


def _clean_s22_data():
    """Wipe any pre-existing stage 22 test data cleanly."""
    db.session.remove()
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE company_name IN ('Stage22 Alpha Corp', 'Stage22 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] not in ('companies', 'sqlite_sequence')]
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's22_%' OR email LIKE 's22_%'")
        cursor.execute("PRAGMA foreign_keys = ON")
        conn.commit()
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def api_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users, keys, and twin records."""
    with app.app_context():
        _clean_s22_data()

        # Tenant Alpha
        comp_a = Company(
            company_name='Stage22 Alpha Corp',
            business_name='Stage22 Alpha Corp',
            owner_name='Alpha API Owner',
            ceo_name='Alpha CEO',
            industry='Technology',
            country='United States',
            annual_revenue=5000000.0,
            employee_count=20,
            currency='USD'
        )
        db.session.add(comp_a)
        db.session.commit()

        user_admin_a = User(
            username='s22_admin_a',
            email='s22_admin_a@alpha.corp',
            role=Role.ADMIN,
            is_admin=True,
            company_id=comp_a.id,
            first_name='Admin',
            last_name='Alpha'
        )
        user_admin_a.set_password('SecretPass123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s22_viewer_a',
            email='s22_viewer_a@alpha.corp',
            role=Role.VIEWER,
            is_admin=False,
            company_id=comp_a.id,
            first_name='Viewer',
            last_name='Alpha'
        )
        user_viewer_a.set_password('SecretPass123!')
        db.session.add(user_viewer_a)

        # Financial records for Alpha
        fin_a = FinancialRecord(
            company_id=comp_a.id,
            transaction_date=datetime.utcnow().date(),
            transaction_type='revenue',
            category='SaaS',
            amount=50000.0,
            description='Alpha SaaS Subscription'
        )
        db.session.add(fin_a)

        # Customer for Alpha
        cust_a = Customer(
            company_id=comp_a.id,
            company_name='Alpha Client One',
            email='client1@alpha.corp',
            status='Active'
        )
        db.session.add(cust_a)
        db.session.commit()

        # API Keys for Alpha
        key_admin_a, raw_admin_key_a = ApiKey.generate(
            company_id=comp_a.id,
            user_id=user_admin_a.id,
            name='Alpha Admin Key',
            role=Role.ADMIN
        )
        key_viewer_a, raw_viewer_key_a = ApiKey.generate(
            company_id=comp_a.id,
            user_id=user_viewer_a.id,
            name='Alpha Viewer Key',
            role=Role.VIEWER
        )

        # Tenant Beta
        comp_b = Company(
            company_name='Stage22 Beta Corp',
            business_name='Stage22 Beta Corp',
            owner_name='Beta API Owner',
            ceo_name='Beta CEO',
            industry='Logistics',
            country='Canada',
            annual_revenue=2000000.0,
            employee_count=10,
            currency='CAD'
        )
        db.session.add(comp_b)
        db.session.commit()

        user_admin_b = User(
            username='s22_admin_b',
            email='s22_admin_b@beta.corp',
            role=Role.ADMIN,
            is_admin=True,
            company_id=comp_b.id,
            first_name='Admin',
            last_name='Beta'
        )
        user_admin_b.set_password('SecretPass123!')
        db.session.add(user_admin_b)

        # Financial record for Beta
        fin_b = FinancialRecord(
            company_id=comp_b.id,
            transaction_date=datetime.utcnow().date(),
            transaction_type='revenue',
            category='Freight',
            amount=30000.0,
            description='Beta Freight Service'
        )
        db.session.add(fin_b)
        db.session.commit()

        key_admin_b, raw_admin_key_b = ApiKey.generate(
            company_id=comp_b.id,
            user_id=user_admin_b.id,
            name='Beta Admin Key',
            role=Role.ADMIN
        )

        yield {
            'comp_a': comp_a,
            'comp_b': comp_b,
            'user_admin_a': user_admin_a,
            'user_viewer_a': user_viewer_a,
            'raw_admin_key_a': raw_admin_key_a,
            'raw_viewer_key_a': raw_viewer_key_a,
            'raw_admin_key_b': raw_admin_key_b,
            'key_admin_a': key_admin_a,
            'key_admin_b': key_admin_b,
            'fin_a': fin_a,
            'fin_b': fin_b,
            'cust_a': cust_a
        }

        _clean_s22_data()


# ==================== 1. JSON ENVELOPE STANDARDIZATION ====================

def test_json_envelope_standardization(app, api_tenants):
    """Verify that successful API calls return standard {success, data, meta, error} envelope."""
    client = app.test_client()
    key = api_tenants['raw_admin_key_a']
    cid = api_tenants['comp_a'].id

    resp = client.get('/api/v1/auth/me', headers={'X-API-Key': key})
    assert resp.status_code == 200
    res = resp.get_json()

    assert res['success'] is True
    assert 'data' in res
    assert 'meta' in res
    assert res['error'] is None

    # Check meta fields
    assert res['meta']['version'] == '1.0'
    assert res['meta']['tenant_id'] == cid
    assert 'timestamp' in res['meta']


# ==================== 2. UNAUTHENTICATED API REJECTION ====================

def test_unauthenticated_api_rejection(app, api_tenants):
    """Verify that requests missing credentials return HTTP 401 with standard error envelope."""
    client = app.test_client()
    resp = client.get('/api/v1/state/canonical')
    assert resp.status_code == 401
    res = resp.get_json()

    assert res['success'] is False
    assert res['data'] is None
    assert res['error']['code'] == 'UNAUTHORIZED'
    assert 'meta' in res


# ==================== 3. API KEY AUTHENTICATION (X-API-Key & Bearer) ====================

def test_api_key_generation_and_authentication(app, api_tenants):
    """Verify authentication via X-API-Key and Authorization: Bearer aev_live_... headers."""
    client = app.test_client()
    key = api_tenants['raw_admin_key_a']

    # Test X-API-Key header
    resp1 = client.get('/api/v1/auth/me', headers={'X-API-Key': key})
    assert resp1.status_code == 200
    data1 = resp1.get_json()['data']
    assert data1['authenticated_via'] == 'api_key'
    assert data1['tenant']['id'] == api_tenants['comp_a'].id

    # Test Authorization: Bearer aev_live_...
    resp2 = client.get('/api/v1/auth/me', headers={'Authorization': f'Bearer {key}'})
    assert resp2.status_code == 200
    data2 = resp2.get_json()['data']
    assert data2['tenant']['id'] == api_tenants['comp_a'].id

    # Test Revocation
    key_record = api_tenants['key_admin_a']
    key_record.revoke()

    resp3 = client.get('/api/v1/auth/me', headers={'X-API-Key': key})
    assert resp3.status_code == 401
    assert resp3.get_json()['error']['code'] == 'UNAUTHORIZED'


# ==================== 4. JWT TOKEN ISSUANCE & BEARER AUTH ====================

def test_jwt_token_issuance_and_auth(app, api_tenants):
    """Verify POST /api/v1/auth/token generates valid JWT access tokens accepted by Bearer auth."""
    client = app.test_client()

    # Invalid login
    bad_resp = client.post('/api/v1/auth/token', json={'username': 's22_admin_a', 'password': 'wrongpassword'})
    assert bad_resp.status_code == 401
    assert bad_resp.get_json()['error']['code'] == 'INVALID_CREDENTIALS'

    # Valid login
    good_resp = client.post('/api/v1/auth/token', json={'username': 's22_admin_a', 'password': 'SecretPass123!'})
    assert good_resp.status_code == 200
    res = good_resp.get_json()
    token = res['data']['access_token']
    assert token is not None
    assert res['data']['token_type'] == 'Bearer'

    # Access endpoint with JWT
    auth_resp = client.get('/api/v1/auth/me', headers={'Authorization': f'Bearer {token}'})
    assert auth_resp.status_code == 200, f"Got {auth_resp.status_code}: {auth_resp.get_json()}"
    user_data = auth_resp.get_json()['data']
    assert user_data['user']['username'] == 's22_admin_a'
    assert user_data['tenant']['id'] == api_tenants['comp_a'].id


# ==================== 5. MULTI-TENANT ISOLATION ====================

def test_multi_tenant_api_isolation(app, api_tenants):
    """Verify that Tenant A cannot access Tenant B records via list or direct IDOR access."""
    client = app.test_client()
    key_a = api_tenants['raw_admin_key_a']
    key_b = api_tenants['raw_admin_key_b']
    fin_b_id = api_tenants['fin_b'].id

    # Tenant A list query only returns Tenant A data
    resp_a = client.get('/api/v1/twins/financials', headers={'X-API-Key': key_a})
    assert resp_a.status_code == 200
    items_a = resp_a.get_json()['data']
    assert len(items_a) == 1
    assert items_a[0]['description'] == 'Alpha SaaS Subscription'

    # Tenant B list query only returns Tenant B data
    resp_b = client.get('/api/v1/twins/financials', headers={'X-API-Key': key_b})
    assert resp_b.status_code == 200
    items_b = resp_b.get_json()['data']
    assert len(items_b) == 1
    assert items_b[0]['description'] == 'Beta Freight Service'

    # IDOR check: Tenant A attempts to read Tenant B's financial record
    resp_idor = client.get(f'/api/v1/twins/financials/{fin_b_id}', headers={'X-API-Key': key_a})
    assert resp_idor.status_code == 404
    assert resp_idor.get_json()['error']['code'] == 'NOT_FOUND'


# ==================== 6. RBAC AUTHORIZATION ENFORCEMENT ====================

def test_rbac_permission_rejection_on_api(app, api_tenants):
    """Verify that Viewer API key can read but cannot perform mutation operations (HTTP 403)."""
    client = app.test_client()
    viewer_key = api_tenants['raw_viewer_key_a']
    admin_key = api_tenants['raw_admin_key_a']

    # Viewer read succeeds
    r_read = client.get('/api/v1/twins/customers', headers={'X-API-Key': viewer_key})
    assert r_read.status_code == 200

    # Viewer write rejected (403 Forbidden)
    r_write = client.post('/api/v1/twins/customers', headers={'X-API-Key': viewer_key}, json={
        'name': 'Unauthorized Customer',
        'email': 'unauth@test.com'
    })
    assert r_write.status_code == 403
    assert r_write.get_json()['error']['code'] == 'FORBIDDEN'

    # Admin write succeeds (201 Created)
    r_admin_write = client.post('/api/v1/twins/customers', headers={'X-API-Key': admin_key}, json={
        'name': 'Authorized Customer',
        'email': 'auth@test.com'
    })
    assert r_admin_write.status_code == 201
    assert r_admin_write.get_json()['data']['company_name'] == 'Authorized Customer'


# ==================== 7. CANONICAL STATE API ENDPOINT ====================

def test_canonical_state_api_endpoint(app, api_tenants):
    """Verify /api/v1/state/canonical returns complete canonical digital twin metrics."""
    client = app.test_client()
    admin_key = api_tenants['raw_admin_key_a']

    resp = client.get('/api/v1/state/canonical', headers={'X-API-Key': admin_key})
    assert resp.status_code == 200
    res = resp.get_json()
    assert res['success'] is True
    data = res['data']
    assert 'metrics' in data
    assert 'summary' in data
    metrics = data['metrics']
    assert 'revenue' in metrics
    assert 'expenses' in metrics
    assert 'runway' in metrics
    assert 'provenance' in metrics['revenue']
    assert 'revenue_30d' in data['summary']


# ==================== 8. TWIN ENTITIES PAGINATION ====================

def test_twin_entities_pagination_and_read(app, api_tenants):
    """Verify pagination metadata and query limits across twin entities."""
    client = app.test_client()
    admin_key = api_tenants['raw_admin_key_a']

    # Create 3 additional customers for Tenant Alpha
    for i in range(2, 5):
        c = Customer(
            company_id=api_tenants['comp_a'].id,
            company_name=f'Alpha Customer {i}',
            email=f'client{i}@alpha.corp',
            status='Active'
        )
        db.session.add(c)
    db.session.commit()

    resp = client.get('/api/v1/twins/customers?page=1&per_page=2', headers={'X-API-Key': admin_key})
    assert resp.status_code == 200
    res = resp.get_json()
    assert len(res['data']) == 2
    assert res['meta']['pagination']['page'] == 1
    assert res['meta']['pagination']['per_page'] == 2
    assert res['meta']['pagination']['total'] >= 4
    assert res['meta']['pagination']['has_next'] is True


# ==================== 9. SIMULATION API EXECUTION ====================

def test_simulations_api_run(app, api_tenants):
    """Verify POST /api/v1/simulations/run executes stochastic Monte Carlo projection."""
    client = app.test_client()
    admin_key = api_tenants['raw_admin_key_a']

    sim_payload = {
        "revenue_before": 100000,
        "cost_before": 60000,
        "revenue_after": 130000,
        "cost_after": 75000,
        "iterations": 500,
        "volatility": 0.12,
        "seed": 42
    }
    resp = client.post('/api/v1/simulations/run', headers={'X-API-Key': admin_key}, json=sim_payload)
    assert resp.status_code == 200
    res = resp.get_json()
    assert res['success'] is True
    data = res['data']
    assert data['iterations'] == 500
    assert 'p10_profit' in data
    assert 'p50_profit' in data
    assert 'p90_profit' in data
    assert 'prob_profitable' in data


# ==================== 10. DATA QUALITY & LINEAGE API ====================

def test_quality_and_lineage_api(app, api_tenants):
    """Verify data quality summary and metric lineage DAG endpoints."""
    client = app.test_client()
    admin_key = api_tenants['raw_admin_key_a']

    # Quality summary
    q_resp = client.get('/api/v1/quality/summary', headers={'X-API-Key': admin_key})
    assert q_resp.status_code == 200
    q_data = q_resp.get_json()['data']
    assert 'score' in q_data
    assert 'dimensions' in q_data

    # Metric lineage DAG
    lin_resp = client.get('/api/v1/quality/lineage/metric/revenue_30d', headers={'X-API-Key': admin_key})
    assert lin_resp.status_code == 200
    lin_data = lin_resp.get_json()['data']
    assert 'nodes' in lin_data
    assert 'edges' in lin_data


# ==================== 11. WEBHOOK SUBSCRIPTION CRUD ====================

def test_webhook_subscription_crud(app, api_tenants):
    """Verify complete CRUD lifecycle of webhook subscriptions."""
    client = app.test_client()
    admin_key = api_tenants['raw_admin_key_a']

    # Create webhook
    create_resp = client.post('/api/v1/webhooks', headers={'X-API-Key': admin_key}, json={
        'url': 'https://api.external.com/webhooks/aevoryn',
        'event_types': 'customer.created,financial.transaction.created',
        'description': 'Production CRM webhook'
    })
    assert create_resp.status_code == 201
    created_data = create_resp.get_json()['data']
    sub_id = created_data['id']
    assert 'secret' in created_data

    # List webhooks
    list_resp = client.get('/api/v1/webhooks', headers={'X-API-Key': admin_key})
    assert list_resp.status_code == 200
    assert any(s['id'] == sub_id for s in list_resp.get_json()['data'])

    # Update webhook
    upd_resp = client.put(f'/api/v1/webhooks/{sub_id}', headers={'X-API-Key': admin_key}, json={
        'description': 'Updated CRM Webhook Description'
    })
    assert upd_resp.status_code == 200
    assert upd_resp.get_json()['data']['description'] == 'Updated CRM Webhook Description'

    # Delete webhook
    del_resp = client.delete(f'/api/v1/webhooks/{sub_id}', headers={'X-API-Key': admin_key})
    assert del_resp.status_code == 200
    assert del_resp.get_json()['data']['deleted'] is True

    # Confirm 404 after deletion
    get_resp = client.get(f'/api/v1/webhooks/{sub_id}', headers={'X-API-Key': admin_key})
    assert get_resp.status_code == 404


# ==================== 12. WEBHOOK HMAC SIGNING & DISPATCH ====================

def test_webhook_hmac_signing_and_mock_dispatch(app, api_tenants):
    """Verify HMAC-SHA256 signature generation and delivery recording during webhook execution."""
    client = app.test_client()
    admin_key = api_tenants['raw_admin_key_a']
    cid = api_tenants['comp_a'].id

    # Create a test subscription
    sub = WebhookSubscription.create(
        company_id=cid,
        url='https://webhook.site/test-endpoint',
        event_types='*',
        secret='super_secret_webhook_key_123'
    )

    # Mock requests.post
    mock_resp = MagicMock()
    mock_resp.status_code = 200
    mock_resp.text = '{"received": true}'

    with patch('requests.post', return_value=mock_resp) as mock_post:
        test_resp = client.post(f'/api/v1/webhooks/{sub.id}/test', headers={'X-API-Key': admin_key})
        assert test_resp.status_code == 200
        assert mock_post.called

        # Inspect request arguments
        called_args, called_kwargs = mock_post.call_args
        assert called_args[0] == 'https://webhook.site/test-endpoint'
        headers = called_kwargs['headers']
        assert 'X-Aevoryn-Signature' in headers
        assert 'X-Aevoryn-Event' in headers

        # Verify HMAC-SHA256 signature
        sent_body = called_kwargs['data']
        computed_sig = f"sha256={hmac.new(b'super_secret_webhook_key_123', sent_body, hashlib.sha256).hexdigest()}"
        assert headers['X-Aevoryn-Signature'] == computed_sig

    # Inspect deliveries list
    deliv_resp = client.get(f'/api/v1/webhooks/{sub.id}/deliveries', headers={'X-API-Key': admin_key})
    assert deliv_resp.status_code == 200
    deliveries = deliv_resp.get_json()['data']
    assert len(deliveries) >= 1
    assert deliveries[0]['status_code'] == 200
    assert deliveries[0]['success'] is True


# ==================== 13. EVENTBUS DISPATCH INTEGRATION ====================

def test_eventbus_triggers_webhook_dispatch(app, api_tenants):
    """Verify that domain events published on EventBus trigger matching webhook deliveries."""
    cid = api_tenants['comp_a'].id

    sub = WebhookSubscription.create(
        company_id=cid,
        url='https://listener.corp/api/events',
        event_types='customer.created',
        secret='sec_customer_created'
    )

    mock_resp = MagicMock()
    mock_resp.status_code = 202
    mock_resp.text = 'Accepted'

    with patch('requests.post', return_value=mock_resp) as mock_post:
        # Publish customer created event
        EventBus.publish(DomainEvent.create(
            event_type=EventTypes.CUSTOMER_CREATED,
            company_id=cid,
            aggregate_type="Customer",
            aggregate_id="999",
            payload={"name": "Event Driven Corp"}
        ))

        # Check if webhook was dispatched
        assert mock_post.called
        headers = mock_post.call_args[1]['headers']
        assert headers['X-Aevoryn-Event'] == 'customer.created'
