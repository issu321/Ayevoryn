import pytest
import uuid
from datetime import datetime, timedelta
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.business_event import BusinessEvent
from database.models.activity_log import ActivityLog
from services.events import DomainEvent, EventBus, EventTypes, publish_event, subscribe


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage9'
    })
    with app.app_context():
        db.create_all()
        # Seed test user and company
        user = User(username='stage9_admin', email='stage9@example.com', role='admin')
        user.set_password('password123')
        db.session.add(user)
        db.session.commit()

        company = Company(
            company_name='Event Corp',
            business_name='Event Corp',
            owner_name='Event Owner',
            ceo_name='Event CEO'
        )
        db.session.add(company)
        db.session.commit()

        EventBus.clear_subscribers()
        yield app
        EventBus.clear_subscribers()
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def auth_client(client, app):
    with client.session_transaction() as sess:
        with app.app_context():
            user = User.query.filter_by(username='stage9_admin').first()
            company = Company.query.first()
            sess['_user_id'] = str(user.id)
            sess['company_id'] = company.id
    return client


# =============================================================================
# 1. DOMAIN EVENT FACTORY & DATACLASS
# =============================================================================

def test_domain_event_create_factory():
    event = DomainEvent.create(
        event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
        company_id=1,
        aggregate_type='financial_record',
        aggregate_id=42,
        actor_id=7,
        actor_name='Alice',
        payload={'amount': 1500.0, 'category': 'Sales'}
    )

    assert event.event_type == EventTypes.FINANCIAL_TRANSACTION_CREATED
    assert event.company_id == 1
    assert event.aggregate_type == 'financial_record'
    assert event.aggregate_id == '42'
    assert event.actor_id == 7
    assert event.actor_name == 'Alice'
    assert event.payload['amount'] == 1500.0
    assert isinstance(event.event_id, str)
    assert len(event.event_id) == 36
    assert isinstance(event.correlation_id, str)
    assert len(event.correlation_id) == 36
    assert isinstance(event.occurred_at, datetime)

    d = event.to_dict()
    assert d['event_id'] == event.event_id
    assert d['aggregate_type'] == 'financial_record'
    assert d['payload']['amount'] == 1500.0


# =============================================================================
# 2. BUSINESS EVENT MODEL & ACTIVITY LOG SYNC
# =============================================================================

def test_event_bus_publish_persists_event_and_activity_log(app):
    with app.app_context():
        company = Company.query.first()
        user = User.query.first()

        event = DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=company.id,
            aggregate_type='financial_record',
            aggregate_id='99',
            actor_id=user.id,
            actor_name=user.username,
            payload={'amount': 5000.0, 'category': 'Consulting', 'description': 'Q3 Retainer'}
        )

        biz_event = EventBus.publish(event)
        assert biz_event.id is not None
        assert biz_event.event_id == event.event_id
        assert biz_event.company_id == company.id
        assert biz_event.get_payload()['amount'] == 5000.0

        # Verify BusinessEvent in database
        saved = BusinessEvent.query.filter_by(event_id=event.event_id).first()
        assert saved is not None
        assert saved.aggregate_type == 'financial_record'
        assert saved.aggregate_id == '99'
        assert saved.actor_name == 'stage9_admin'

        # Verify ActivityLog entry was automatically populated (Resolving Finding 16)
        activity = ActivityLog.query.filter_by(company_id=company.id, activity_type=event.event_type).first()
        assert activity is not None
        assert activity.module == 'financial_record'
        assert 'stage9_admin' in activity.description
        assert 'Retainer' in activity.description or '99' in activity.description


# =============================================================================
# 3. DISPATCH LISTENERS & SUBSCRIBERS
# =============================================================================

def test_exact_and_wildcard_listeners(app):
    with app.app_context():
        company = Company.query.first()
        received_exact = []
        received_wildcard = []
        received_category = []

        def on_exact(ev: DomainEvent):
            received_exact.append(ev)

        def on_wildcard(ev: DomainEvent):
            received_wildcard.append(ev)

        def on_category(ev: DomainEvent):
            received_category.append(ev)

        EventBus.subscribe(EventTypes.CUSTOM_TWIN_CREATED, on_exact)
        EventBus.subscribe('*', on_wildcard)
        EventBus.subscribe('custom_twin.*', on_category)

        # Publish matching event
        ev1 = DomainEvent.create(
            event_type=EventTypes.CUSTOM_TWIN_CREATED,
            company_id=company.id,
            aggregate_type='custom_twin',
            aggregate_id='10',
            payload={'name': 'Production Line Twin'}
        )
        EventBus.publish(ev1)

        assert len(received_exact) == 1
        assert received_exact[0].event_id == ev1.event_id
        assert len(received_wildcard) == 1
        assert len(received_category) == 1

        # Publish different event (department)
        ev2 = DomainEvent.create(
            event_type=EventTypes.DEPARTMENT_CREATED,
            company_id=company.id,
            aggregate_type='department',
            aggregate_id='20',
            payload={'name': 'Operations'}
        )
        EventBus.publish(ev2)

        # Exact and category should not have received ev2, but wildcard should
        assert len(received_exact) == 1
        assert len(received_category) == 1
        assert len(received_wildcard) == 2


def test_listener_exception_isolation(app):
    with app.app_context():
        company = Company.query.first()
        called = []

        def failing_handler(ev: DomainEvent):
            raise RuntimeError("Handler crash test")

        def successful_handler(ev: DomainEvent):
            called.append(ev)

        EventBus.subscribe(EventTypes.EMPLOYEE_CREATED, failing_handler)
        EventBus.subscribe(EventTypes.EMPLOYEE_CREATED, successful_handler)

        event = DomainEvent.create(
            event_type=EventTypes.EMPLOYEE_CREATED,
            company_id=company.id,
            aggregate_type='employee',
            aggregate_id='55'
        )

        # Publish should succeed and not crash despite failing_handler
        biz_event = EventBus.publish(event)
        assert biz_event is not None
        assert len(called) == 1


# =============================================================================
# 4. EVENT QUERIES & TIME TRAVEL STREAMS
# =============================================================================

def test_get_recent_events_and_stream(app):
    with app.app_context():
        company = Company.query.first()
        now = datetime.utcnow()

        # Create sequential events
        for i in range(5):
            ev = DomainEvent.create(
                event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED if i % 2 == 0 else EventTypes.EMPLOYEE_CREATED,
                company_id=company.id,
                aggregate_type='financial_record' if i % 2 == 0 else 'employee',
                aggregate_id=str(i + 1),
                occurred_at=now + timedelta(minutes=i)
            )
            EventBus.publish(ev)

        recent = EventBus.get_recent_events(company_id=company.id, limit=10)
        assert len(recent) == 5

        # Filter by event type
        fin_recent = EventBus.get_recent_events(
            company_id=company.id, event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED
        )
        assert len(fin_recent) == 3

        # Stream order should be ascending
        stream = EventBus.get_event_stream(company_id=company.id)
        assert len(stream) == 5
        assert stream[0]['aggregate_id'] == '1'
        assert stream[-1]['aggregate_id'] == '5'


# =============================================================================
# 5. ROUTE MUTATION EVENT TRIGGERS
# =============================================================================

def test_custom_twin_routes_emit_events(auth_client, app):
    with app.app_context():
        company = Company.query.first()

        # 1. Create twin
        res = auth_client.post('/business-twin/custom-twins/create', json={
            'name': 'Fleet Twin',
            'field_definitions': [
                {'name': 'vehicle_id', 'label': 'Vehicle ID', 'type': 'text', 'required': True},
                {'name': 'mileage', 'label': 'Mileage', 'type': 'number', 'required': False}
            ]
        })
        assert res.status_code == 200
        twin_id = res.get_json()['twin']['id']

        event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.CUSTOM_TWIN_CREATED
        ).first()
        assert event is not None
        assert event.aggregate_id == str(twin_id)
        assert event.get_payload()['name'] == 'Fleet Twin'

        # 2. Add record
        res_rec = auth_client.post(f'/business-twin/custom-twins/{twin_id}/records', json={
            'vehicle_id': 'TRUCK-101',
            'mileage': 45000
        })
        assert res_rec.status_code == 200
        rec_id = res_rec.get_json()['record']['id']

        rec_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.CUSTOM_RECORD_CREATED
        ).first()
        assert rec_event is not None
        assert rec_event.aggregate_id == str(rec_id)

        # 3. Edit record
        res_edit_rec = auth_client.post(f'/business-twin/custom-twins/records/{rec_id}', json={
            'vehicle_id': 'TRUCK-101',
            'mileage': 47500
        })
        assert res_edit_rec.status_code == 200

        edit_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.CUSTOM_RECORD_UPDATED
        ).first()
        assert edit_event is not None

        # 4. Delete record
        res_del_rec = auth_client.delete(f'/business-twin/custom-twins/records/{rec_id}')
        assert res_del_rec.status_code == 200

        del_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.CUSTOM_RECORD_DELETED
        ).first()
        assert del_event is not None


def test_financial_and_dept_routes_emit_events(auth_client, app):
    with app.app_context():
        company = Company.query.first()

        # 1. Add department
        res_dept = auth_client.post('/business-twin/departments/add', data={
            'name': 'Logistics',
            'code': 'LOG',
            'budget': '150000'
        })
        assert res_dept.status_code == 200
        dept_id = res_dept.get_json()['department']['id']

        dept_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.DEPARTMENT_CREATED
        ).first()
        assert dept_event is not None
        assert dept_event.aggregate_id == str(dept_id)

        # 2. Add revenue
        res_rev = auth_client.post('/business-twin/revenue/add', data={
            'amount': '12500',
            'category': 'Freight',
            'description': 'Route A Delivery',
            'department_id': str(dept_id)
        })
        assert res_rev.status_code == 200
        rev_id = res_rev.get_json()['record']['id']

        rev_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED
        ).first()
        assert rev_event is not None
        assert rev_event.aggregate_id == str(rev_id)
        assert rev_event.get_payload()['transaction_type'] == 'revenue'

        # 3. Add expense
        res_exp = auth_client.post('/business-twin/expenses/add', data={
            'amount': '3200',
            'category': 'Fuel',
            'description': 'Diesel Fuel Q3',
            'department_id': str(dept_id)
        })
        assert res_exp.status_code == 200
        exp_id = res_exp.get_json()['expense']['id']

        exp_events = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED
        ).all()
        assert len(exp_events) == 2  # 1 revenue + 1 expense


def test_people_routes_emit_events(auth_client, app):
    with app.app_context():
        company = Company.query.first()

        # 1. Add customer
        res_cust = auth_client.post('/business-twin/customers/add', data={
            'first_name': 'Sarah',
            'last_name': 'Connor',
            'email': 'sarah@resistance.org',
            'company_name': 'Cyberdyne Resistance',
            'segment': 'Enterprise',
            'lifetime_value': '50000'
        })
        assert res_cust.status_code == 200
        cust_id = res_cust.get_json()['customer']['id']

        cust_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.CUSTOMER_CREATED
        ).first()
        assert cust_event is not None
        assert cust_event.aggregate_id == str(cust_id)

        # 2. Add employee
        res_emp = auth_client.post('/business-twin/employees/add', data={
            'first_name': 'John',
            'last_name': 'Connor',
            'email': 'john@resistance.org',
            'job_title': 'Field Director',
            'salary': '85000'
        })
        assert res_emp.status_code == 200
        emp_id = res_emp.get_json()['employee']['id']

        emp_event = BusinessEvent.query.filter_by(
            company_id=company.id, event_type=EventTypes.EMPLOYEE_CREATED
        ).first()
        assert emp_event is not None
        assert emp_event.aggregate_id == str(emp_id)
