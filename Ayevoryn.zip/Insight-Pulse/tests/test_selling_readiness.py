"""
Stage 32: Enterprise Selling Readiness Verification Suite
End-to-end integration and selling readiness verification covering Workflows A through G:
- Workflow A: Executive Onboarding, Multi-tenant Registration & 6 RBAC Roles
- Workflow B: Seven-Pillar Twin Ingestion & Inter-Twin Dependency Graph Linking
- Workflow C: Canonical State & Financial Truth Verification (Runway without 30x bug, Margins, Provenance)
- Workflow D: Event Bus, Causal Blast Radius Traversal, Autonomous Risk Triggers & Activity Log Synchronization
- Workflow E: Temporal Branching, Immutable Snapshot Sandboxing & Zero Live Mutation Invariant
- Workflow F: Asynchronous Job Worker Execution, REST API v1 Endpoints & Telemetry Observability
- Workflow G: Security Isolation, Threat Resistance & Live Production Database Integrity
"""

import os
import pytest
from datetime import datetime, date, timedelta
from sqlalchemy import text, inspect

from app import create_app
from database.db import db, _heal_schema
from database.models import (
    Company, User, Department, Employee, Customer, Supplier,
    Inventory, FinancialRecord, FinancialAccount, Risk, ActivityLog,
    CustomTwin, CustomTwinRecord, CoreTwinExtraRecord,
    BusinessEvent, TwinDependency, DependencyType,
    ImpactTrace, ImpactSeverity, TwinSnapshot, SnapshotType,
    Scenario, ScenarioStep, ScenarioStatus, BranchType, BackgroundJob,
    ApiKey
)
from security.rbac import RBACService, Role, Permission
from services.business_state_service import BusinessStateService, ProvenanceType
from services.events import DomainEvent, EventBus, EventTypes
from services.twin_dependency_service import TwinDependencyService
from services.impact_engine import ImpactEngine
from services.temporal_service import TemporalService
from services.scenario_branching_service import ScenarioBranchingService
from services.job_service import JobService

TEST_DB_PATH = os.path.abspath('instance/test_isolated_selling_readiness.db').replace(chr(92), '/')


@pytest.fixture(scope='module')
def isolated_env():
    """Module-scoped isolated test environment targeting instance/test_isolated_selling_readiness.db."""
    test_app = create_app({
        'TESTING': True,
        'WTF_CSRF_ENABLED': False,
        'SQLALCHEMY_DATABASE_URI': f'sqlite:///{TEST_DB_PATH}',
        'SQLALCHEMY_TRACK_MODIFICATIONS': False
    })

    with test_app.app_context():
        # Clean slate
        db.session.remove()
        db.drop_all()
        db.create_all()
        _heal_schema()

        # Enforce SQLite foreign key constraints
        with db.engine.connect() as conn:
            conn.execute(text("PRAGMA foreign_keys = ON;"))
            conn.commit()

        yield test_app

        # Teardown
        db.session.remove()
        db.engine.dispose()
        if os.path.exists(TEST_DB_PATH):
            try:
                os.remove(TEST_DB_PATH)
            except Exception:
                pass


@pytest.fixture
def client(isolated_env):
    """Test client bound to the isolated test application."""
    with isolated_env.test_client() as c:
        yield c


# =========================================================================
# WORKFLOW A: EXECUTIVE ONBOARDING & RBAC
# =========================================================================

def test_workflow_a_executive_onboarding_and_rbac(isolated_env, client):
    """
    Workflow A: Multi-tenant tenant registration, company creation, and user provisioning
    across all 6 RBAC roles with strict hierarchical and granular permission enforcement.
    """
    with isolated_env.app_context():
        # 1. Register Tenant Alpha and Tenant Beta
        comp_a = Company(
            company_name="Apex Global Enterprises",
            business_name="Apex Global Enterprises Inc.",
            owner_name="Victoria Sterling",
            ceo_name="Victoria Sterling",
            currency="USD"
        )
        comp_b = Company(
            company_name="Vanguard Synergy Labs",
            business_name="Vanguard Synergy Labs LLC",
            owner_name="Julian Thorne",
            ceo_name="Julian Thorne",
            currency="EUR"
        )
        db.session.add_all([comp_a, comp_b])
        db.session.commit()

        # 2. Provision users for Company A covering all 6 RBAC roles
        users_a = {
            'owner': User(username='apex_owner', email='owner@apexglobal.io', role=Role.OWNER, company_id=comp_a.id),
            'admin': User(username='apex_admin', email='admin@apexglobal.io', role=Role.ADMIN, company_id=comp_a.id),
            'manager': User(username='apex_manager', email='manager@apexglobal.io', role=Role.MANAGER, company_id=comp_a.id),
            'analyst': User(username='apex_analyst', email='analyst@apexglobal.io', role=Role.ANALYST, company_id=comp_a.id),
            'auditor': User(username='apex_auditor', email='auditor@apexglobal.io', role=Role.AUDITOR, company_id=comp_a.id),
            'viewer': User(username='apex_viewer', email='viewer@apexglobal.io', role=Role.VIEWER, company_id=comp_a.id),
        }
        for u in users_a.values():
            u.set_password('ProductionReady2026!')
        db.session.add_all(users_a.values())

        # Provision single owner user for Company B
        user_b = User(username='vanguard_owner', email='owner@vanguard.io', role=Role.OWNER, company_id=comp_b.id)
        user_b.set_password('VanguardSecret99!')
        db.session.add(user_b)
        db.session.commit()

        # 3. Assert Tenant Isolation in Database
        assert User.query.filter_by(company_id=comp_a.id).count() == 6
        assert User.query.filter_by(company_id=comp_b.id).count() == 1

        # 4. Assert RBAC Role Hierarchy
        assert RBACService.has_role(Role.VIEWER, users_a['owner']) is True
        assert RBACService.has_role(Role.ADMIN, users_a['owner']) is True
        assert RBACService.has_role(Role.OWNER, users_a['admin']) is False
        assert RBACService.has_role(Role.MANAGER, users_a['analyst']) is False
        assert RBACService.has_role(Role.VIEWER, users_a['auditor']) is True

        # 5. Assert Granular Permission Mapping Across All 6 Roles
        # Owner
        assert RBACService.has_permission(Permission.COMPANY_MANAGE, users_a['owner']) is True
        assert RBACService.has_permission(Permission.USER_MANAGE, users_a['owner']) is True
        assert RBACService.has_permission(Permission.DATA_WRITE, users_a['owner']) is True
        assert RBACService.has_permission(Permission.DATA_DELETE, users_a['owner']) is True
        assert RBACService.has_permission(Permission.SIMULATION_RUN, users_a['owner']) is True
        assert RBACService.has_permission(Permission.AUDIT_VIEW, users_a['owner']) is True

        # Admin
        assert RBACService.has_permission(Permission.COMPANY_MANAGE, users_a['admin']) is True
        assert RBACService.has_permission(Permission.USER_MANAGE, users_a['admin']) is True
        assert RBACService.has_permission(Permission.DATA_WRITE, users_a['admin']) is True

        # Manager
        assert RBACService.has_permission(Permission.DATA_WRITE, users_a['manager']) is True
        assert RBACService.has_permission(Permission.DATA_DELETE, users_a['manager']) is True
        assert RBACService.has_permission(Permission.COMPANY_MANAGE, users_a['manager']) is False
        assert RBACService.has_permission(Permission.USER_MANAGE, users_a['manager']) is False

        # Analyst
        assert RBACService.has_permission(Permission.SIMULATION_RUN, users_a['analyst']) is True
        assert RBACService.has_permission(Permission.DATA_WRITE, users_a['analyst']) is True
        assert RBACService.has_permission(Permission.DATA_DELETE, users_a['analyst']) is False
        assert RBACService.has_permission(Permission.USER_MANAGE, users_a['analyst']) is False

        # Auditor
        assert RBACService.has_permission(Permission.AUDIT_VIEW, users_a['auditor']) is True
        assert RBACService.has_permission(Permission.REPORT_EXPORT, users_a['auditor']) is True
        assert RBACService.has_permission(Permission.DATA_WRITE, users_a['auditor']) is False
        assert RBACService.has_permission(Permission.SIMULATION_RUN, users_a['auditor']) is False

        # Viewer
        assert RBACService.has_permission(Permission.VIEW_DASHBOARD, users_a['viewer']) is True
        assert RBACService.has_permission(Permission.REPORT_EXPORT, users_a['viewer']) is True
        assert RBACService.has_permission(Permission.DATA_WRITE, users_a['viewer']) is False
        assert RBACService.has_permission(Permission.SIMULATION_RUN, users_a['viewer']) is False
        assert RBACService.has_permission(Permission.USER_MANAGE, users_a['viewer']) is False


# =========================================================================
# WORKFLOW B: SEVEN-PILLAR TWIN INGESTION & INTER-TWIN DEPENDENCY LINKING
# =========================================================================

def test_workflow_b_seven_pillar_twin_ingestion(isolated_env):
    """
    Workflow B: Full ingestion and entity modeling across all 7 Digital Twin pillars
    (Departments, Employees, Customers, Suppliers, Inventory, Financials, Custom Twins)
    and dependency graph assembly.
    """
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Apex Global Enterprises").first()
        cid = comp.id

        # Pillar 1: Departments
        dept_rd = Department(company_id=cid, name="Strategic R&D", budget=350000.0, is_active=True)
        dept_ops = Department(company_id=cid, name="Global Operations", budget=180000.0, is_active=True)
        db.session.add_all([dept_rd, dept_ops])
        db.session.flush()

        # Pillar 2: Employees
        emp = Employee(
            company_id=cid,
            department_id=dept_rd.id,
            first_name="Dr. Aris",
            last_name="Thorne",
            email="aris.thorne@apexglobal.io",
            job_title="Chief Scientist & AI Director",
            salary=220000.0,
            status="active"
        )
        db.session.add(emp)
        db.session.flush()

        # Pillar 3: Customers
        cust = Customer(
            company_id=cid,
            first_name="Nexus",
            last_name="Holdings",
            company_name="Nexus Enterprise Corp",
            email="procurement@nexus.io",
            status="active",
            lifetime_value=450000.0,
            acquisition_cost=15000.0
        )
        db.session.add(cust)
        db.session.flush()

        # Pillar 4: Suppliers
        sup = Supplier(
            company_id=cid,
            name="HyperScale Foundry Ltd",
            category="Hardware Fabrication",
            status="active",
            is_primary=True,
            rating=4.95,
            total_spend=180000.0
        )
        db.session.add(sup)
        db.session.flush()

        # Pillar 5: Inventory
        inv = Inventory(
            company_id=cid,
            supplier_id=sup.id,
            sku="NX-ACCEL-01",
            name="ASIC-X1 Neural Accelerator Rack",
            category="High-Performance Hardware",
            quantity_on_hand=120,
            quantity_available=115,
            reorder_point=30,
            max_stock=250,
            unit_cost=650.0,
            is_active=True
        )
        db.session.add(inv)
        db.session.flush()

        # Pillar 6: Financials
        rev_record = FinancialRecord(
            company_id=cid,
            department_id=dept_rd.id,
            transaction_type="revenue",
            amount=300000.0,
            transaction_date=date.today(),
            description="Enterprise AI Tier-1 Subscription"
        )
        exp_record = FinancialRecord(
            company_id=cid,
            department_id=dept_ops.id,
            transaction_type="expense",
            amount=120000.0,
            transaction_date=date.today(),
            description="Tier-4 Data Center Co-Location Lease"
        )
        db.session.add_all([rev_record, exp_record])
        db.session.flush()

        # Pillar 7: Custom Digital Twins
        custom_twin = CustomTwin(
            company_id=cid,
            name="Edge Micro-Datacenter",
            slug="edge-micro-datacenter",
            description="Modular edge computing node digital twin",
            icon="fa-server"
        )
        custom_twin.set_field_definitions([
            {"name": "rack_units", "type": "number"},
            {"name": "cooling_efficiency_pue", "type": "number"},
            {"name": "firmware_version", "type": "string"}
        ])
        db.session.add(custom_twin)
        db.session.flush()

        twin_record = CustomTwinRecord(
            twin_id=custom_twin.id,
            company_id=cid
        )
        twin_record.set_data({
            "rack_units": 42,
            "cooling_efficiency_pue": 1.15,
            "firmware_version": "v4.2.1-prod"
        })
        db.session.add(twin_record)
        db.session.commit()

        # Assert all 7 pillars exist and are queryable
        assert Department.query.filter_by(company_id=cid).count() == 2
        assert Employee.query.filter_by(company_id=cid).count() == 1
        assert Customer.query.filter_by(company_id=cid).count() == 1
        assert Supplier.query.filter_by(company_id=cid).count() == 1
        assert Inventory.query.filter_by(company_id=cid).count() == 1
        assert FinancialRecord.query.filter_by(company_id=cid).count() == 2
        assert CustomTwin.query.filter_by(company_id=cid).count() == 1
        assert CustomTwinRecord.query.filter_by(company_id=cid).count() == 1

        # Build Digital Twin graph and assert cross-pillar topology
        graph = TwinDependencyService.build_graph(cid)
        assert graph['summary']['total_nodes'] >= 7
        assert graph['summary']['total_edges'] >= 2
        topo = TwinDependencyService.get_topological_order(graph['nodes'], graph['edges'])
        assert len(topo['ordered_nodes']) > 0


# =========================================================================
# WORKFLOW C: CANONICAL STATE & FINANCIAL TRUTH
# =========================================================================

def test_workflow_c_canonical_state_and_financial_truth(isolated_env):
    """
    Workflow C: Canonical business state evaluation, mathematical cash runway verification
    (confirming resolution of the 30x runway bug), margin precision, and data provenance.
    """
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Apex Global Enterprises").first()
        cid = comp.id

        # Setup primary cash checking account
        treasury = FinancialAccount(
            company_id=cid,
            account_name="Apex Global Treasury Reserves",
            account_type="checking",
            current_balance=1500000.0,
            is_active=True
        )
        db.session.add(treasury)
        db.session.commit()

        # 1. Evaluate baseline canonical state
        state = BusinessStateService.get_canonical_state(cid)
        metrics = state['metrics']

        assert metrics['revenue'].value == 300000.0
        assert metrics['revenue'].provenance == ProvenanceType.OBSERVED
        assert metrics['expenses'].value == 120000.0
        assert metrics['expenses'].provenance == ProvenanceType.OBSERVED
        assert metrics['profit'].value == 180000.0
        assert round(metrics['margin'].value, 1) == 60.0
        assert metrics['cash_balance'].value == 1500000.0
        assert metrics['cash_balance'].provenance == ProvenanceType.OBSERVED

        # 2. Inject high-burn operational shock to stress-test runway mathematics
        # Prior expenses: 120,000. Add 400,000 capex/opex shock. Total expenses = 520,000.
        # Revenue = 300,000. Net monthly burn = 520,000 - 300,000 = 220,000.
        burn_shock = FinancialRecord(
            company_id=cid,
            transaction_type="expense",
            amount=400000.0,
            transaction_date=date.today(),
            description="High-Speed GPU Cluster Expansion"
        )
        db.session.add(burn_shock)
        db.session.commit()

        # Re-evaluate canonical state
        shocked_state = BusinessStateService.get_canonical_state(cid)
        runway_metric = shocked_state['metrics']['runway']

        # Expected runway: 1,500,000 / 220,000 = 6.818 months
        # Under legacy 30x bug (dividing by daily burn 220,000/30 = 7,333.33): runway would be 204.5 "months"
        assert runway_metric.value == pytest.approx(6.82, rel=0.05)
        assert runway_metric.value < 20.0, "Runway must NEVER exhibit the legacy 30x overstatement bug"
        assert runway_metric.provenance == ProvenanceType.OBSERVED


# =========================================================================
# WORKFLOW D: EVENT BUS, CAUSAL BLAST RADIUS & RISK TRIGGERS
# =========================================================================

def test_workflow_d_event_bus_causal_impact_and_risk(isolated_env):
    """
    Workflow D: EventBus publish-subscribe cycle, automated ActivityLog synchronization,
    causal blast radius traversal, and autonomous operational risk creation.
    """
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Apex Global Enterprises").first()
        cid = comp.id

        # 1. Publish Domain Event via EventBus
        event_name = "strategic.expansion.announced"
        domain_ev = DomainEvent.create(
            event_type=event_name,
            company_id=cid,
            aggregate_type="company",
            aggregate_id=str(cid),
            actor_id=1,
            actor_name="Victoria Sterling",
            payload={"market": "EMEA", "allocated_capital": 500000.0}
        )
        EventBus.publish(domain_ev)

        # Assert BusinessEvent persisted to immutable ledger
        bus_evt = BusinessEvent.query.filter_by(company_id=cid, event_type=event_name).first()
        assert bus_evt is not None
        assert bus_evt.get_payload()["market"] == "EMEA"

        # Assert ActivityLog audit synchronization
        audit_entry = ActivityLog.query.filter_by(company_id=cid, activity_type=event_name).first()
        assert audit_entry is not None
        assert audit_entry.module == "company"

        # 2. Trigger inventory supply chain disruption & propagate causal blast radius
        inv_item = Inventory.query.filter_by(company_id=cid, sku="NX-ACCEL-01").first()
        assert inv_item is not None
        inv_item.quantity_on_hand = 0
        inv_item.quantity_available = 0
        db.session.commit()

        stockout_event = DomainEvent.create(
            event_type=EventTypes.INVENTORY_ITEM_UPDATED,
            company_id=cid,
            aggregate_type="inventory",
            aggregate_id=str(inv_item.id),
            actor_id=1,
            payload={"sku": inv_item.sku, "quantity": 0, "name": inv_item.name}
        )
        trace = ImpactEngine.propagate_event(stockout_event, dry_run=False)

        # Assert ImpactTrace generated with elevated severity
        assert trace is not None
        assert trace.severity in (ImpactSeverity.HIGH, ImpactSeverity.CRITICAL)

        # Assert Autonomous Risk Trigger registered in risks table
        risk = Risk.query.filter_by(company_id=cid).first()
        assert risk is not None
        assert risk.status in ("identified", "open", "active")


# =========================================================================
# WORKFLOW E: TEMPORAL BRANCHING & ZERO LIVE MUTATION
# =========================================================================

def test_workflow_e_temporal_branching_and_governance(isolated_env):
    """
    Workflow E: Point-in-time baseline snapshot creation, isolated sandbox scenario branching,
    forward projection variance evaluation, and strict proof of zero live database mutation.
    """
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Apex Global Enterprises").first()
        cid = comp.id
        initial_revenue = comp.annual_revenue
        initial_cust_count = Customer.query.filter_by(company_id=cid).count()
        initial_emp_count = Employee.query.filter_by(company_id=cid).count()

        # 1. Capture point-in-time immutable baseline snapshot
        snapshot = TemporalService.create_snapshot(
            company_id=cid,
            name="Q4 Enterprise Baseline",
            description="Pre-expansion corporate baseline snapshot",
            user_id=1,
            actor_name="Victoria Sterling"
        )
        assert snapshot is not None
        assert snapshot.company_id == cid
        assert snapshot.snapshot_id is not None
        assert len(snapshot.get_metrics()) > 0

        # 2. Branch into isolated scenario sandbox
        branch = ScenarioBranchingService.branch_scenario(
            company_id=cid,
            user_id=1,
            name="Project Titan Hyper-Growth",
            description="Simulating 40% enterprise expansion with capex injection",
            baseline_snapshot_id=snapshot.snapshot_id,
            parameters={
                'revenue_delta_pct': 40.0,
                'expense_delta_pct': 15.0,
                'headcount_delta': 10,
                'capex_investment': 150000.0
            }
        )
        assert branch is not None
        assert branch.company_id == cid

        # 3. Evaluate forward projection and scenario variance
        evaluation = ScenarioBranchingService.evaluate_branch(
            company_id=cid,
            scenario_id=branch.id
        )
        assert evaluation is not None
        assert 'variance' in evaluation
        assert 'projected' in evaluation
        assert evaluation['variance']['revenue_delta_pct'] == 40.0
        assert evaluation['variance']['net_benefit'] is not None

        # 4. CRITICAL INVARIANT: Verify live operational Company records were NOT mutated
        live_comp = db.session.get(Company, cid)
        assert live_comp.annual_revenue == initial_revenue, "Live Company revenue must not be altered by scenario"
        assert Customer.query.filter_by(company_id=cid).count() == initial_cust_count
        assert Employee.query.filter_by(company_id=cid).count() == initial_emp_count


# =========================================================================
# WORKFLOW F: ASYNC JOBS, REST API & TELEMETRY OBSERVABILITY
# =========================================================================

def test_workflow_f_async_jobs_rest_api_and_telemetry(isolated_env, client):
    """
    Workflow F: Background job lifecycle (submission, execution, completion),
    REST API v1 endpoint authorization, and telemetry observability probes (/healthz, /readiness, /health/metrics).
    """
    with isolated_env.app_context():
        comp = Company.query.filter_by(company_name="Apex Global Enterprises").first()
        cid = comp.id
        admin_user = User.query.filter_by(username='apex_admin').first()

        # 1. Execute Background Job synchronously for deterministic assertion
        job = JobService.submit_job(
            company_id=cid,
            user_id=admin_user.id,
            job_type="simulation_monte_carlo",
            payload={"runs": 50, "variance": 0.1},
            synchronous=True
        )
        assert job is not None
        assert job.company_id == cid
        assert job.status == 'completed'
        assert job.progress == 100
        assert job.completed_at is not None

        # 2. Provision an API Key for API v1 access
        key_obj, raw_key = ApiKey.generate(company_id=cid, user_id=admin_user.id, name="Readiness Audit Key")
        db.session.add(key_obj)
        db.session.commit()

    headers = {'X-API-Key': raw_key}

    # 3. Test REST API v1 Endpoints
    # GET /api/v1/jobs/types (registered handlers)
    res_types = client.get('/api/v1/jobs/types', headers=headers)
    assert res_types.status_code == 200
    types_json = res_types.get_json()
    assert types_json['success'] is True

    # GET /api/v1/jobs (list jobs for active tenant)
    res_jobs = client.get('/api/v1/jobs', headers=headers)
    assert res_jobs.status_code == 200
    jobs_json = res_jobs.get_json()
    assert jobs_json['success'] is True
    assert len(jobs_json['data']) >= 1
    assert jobs_json['meta']['tenant_id'] == cid

    # 4. Test Telemetry and Health Probes
    # Liveness Probe: /healthz
    res_liveness = client.get('/healthz')
    assert res_liveness.status_code == 200
    assert res_liveness.get_json().get('status') == 'healthy'

    # Readiness Probe: /readiness
    res_readiness = client.get('/readiness')
    assert res_readiness.status_code == 200
    assert res_readiness.get_json().get('status') == 'ready'

    # Telemetry Metrics Probe: /health/metrics
    res_metrics = client.get('/health/metrics')
    assert res_metrics.status_code == 200
    metrics_data = res_metrics.get_json()
    assert 'uptime_seconds' in metrics_data


# =========================================================================
# WORKFLOW G: SECURITY ISOLATION, THREAT RESISTANCE & ZERO DATA LOSS
# =========================================================================

def test_workflow_g_security_isolation_and_zero_data_loss(isolated_env, client):
    """
    Workflow G: Unauthenticated path traversal resistance, CSRF protection,
    cross-tenant IDOR prevention, and live production database zero-data-loss verification.
    """
    # 1. Path Traversal Defense: Unauthenticated and authenticated traversal attempts must be rejected
    traversal_targets = [
        '/uploads/../../.env',
        '/uploads/..%2f..%2f.env',
        '/uploads/instance/business_simulator.db',
        '/uploads/..%2finstance%2fbusiness_simulator.db',
        '/uploads/config/settings.py'
    ]
    for target in traversal_targets:
        res = client.get(target)
        # Must be rejected via redirect to login (302), unauthorized (401), or not found (404)
        assert res.status_code in (302, 401, 403, 404), f"Path traversal target {target} was not safely rejected: {res.status_code}"

    # 2. CSRF Protection Rejection Test
    # Create isolated sub-app with WTF_CSRF_ENABLED=True
    csrf_app = create_app({
        'TESTING': True,
        'WTF_CSRF_ENABLED': True,
        'SQLALCHEMY_DATABASE_URI': f'sqlite:///{TEST_DB_PATH}',
        'SQLALCHEMY_TRACK_MODIFICATIONS': False
    })
    with csrf_app.test_client() as csrf_client:
        # State-mutating POST request without CSRF token must be rejected with HTTP 400
        bad_post = csrf_client.post('/login', data={'username': 'apex_admin', 'password': 'ProductionReady2026!'})
        assert bad_post.status_code == 400, f"Expected CSRF 400 Bad Request, got {bad_post.status_code}"

    # 3. Cross-Tenant IDOR Prevention
    with isolated_env.app_context():
        comp_a = Company.query.filter_by(company_name="Apex Global Enterprises").first()
        comp_b = Company.query.filter_by(company_name="Vanguard Synergy Labs").first()
        user_b = User.query.filter_by(username='vanguard_owner').first()
        dept_a = Department.query.filter_by(company_id=comp_a.id).first()

        user_b_id = user_b.id
        comp_b_id = comp_b.id
        dept_a_id = dept_a.id
        dept_a_name = dept_a.name

        # Provision API key for Tenant B
        key_obj_b, raw_key_b = ApiKey.generate(company_id=comp_b_id, user_id=user_b_id, name="Tenant B Key")
        db.session.add(key_obj_b)
        db.session.commit()

        # Job belonging to Tenant A
        job_a = BackgroundJob.query.filter_by(company_id=comp_a.id).first()
        assert job_a is not None
        job_a_id = job_a.id

    # Tenant B attempts to inspect Tenant A's background job via API v1
    res_idor = client.get(f'/api/v1/jobs/{job_a_id}', headers={'X-API-Key': raw_key_b})
    assert res_idor.status_code in (403, 404), f"Expected cross-tenant IDOR to be rejected with 403/404, got {res_idor.status_code}"

    # Tenant B authenticates via login route
    login_res = client.post('/login', data={'username': 'vanguard_owner', 'password': 'VanguardSecret99!'}, follow_redirects=True)
    assert login_res.status_code in (200, 302)

    # Tenant B attempts to edit Tenant A's department via UI route
    res_dept_idor = client.post(f'/business-twin/departments/edit/{dept_a_id}', json={'name': 'Hijacked Dept', 'budget': 1})
    assert res_dept_idor.status_code in (403, 404), f"Expected department IDOR rejection, got {res_dept_idor.status_code}"

    # Verify department in Tenant A was not modified
    with isolated_env.app_context():
        d = db.session.get(Department, dept_a_id)
        assert d.name == dept_a_name, "Tenant A department name must remain untouched by Tenant B"

    # 4. Live Production Database Zero-Data-Loss Verification
    prod_db_path = os.path.abspath('instance/business_simulator.db')
    assert os.path.exists(prod_db_path), "Production database instance/business_simulator.db must exist"
    prod_size = os.path.getsize(prod_db_path)
    assert prod_size > 4000000, f"Production database size ({prod_size} bytes) indicates corruption or data loss"
