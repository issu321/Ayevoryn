"""
AEVORYN / INSIGHT-PULSE
STAGE 17: RISK ENGINE CONNECTION & OPERATIONAL THRESHOLDS AUTOMATED TEST SUITE

Validates:
1. Financial liquidity runway triggers (Severe < 1m & Warning < 3m) with auditable evidence.
2. Inventory stockout (QOH <= 0) and reorder point threshold triggers.
3. Supplier and Customer concentration breach triggers (>60% spend, >40% revenue).
4. Departmental budget overrun and unstaffed department risk triggers.
5. Cross-domain systemic impact cascade triggers from critical twin mutations.
6. Automatic risk resolution when live operational metrics recover.
7. Multi-tenant IDOR protection (HTTP 404 on cross-tenant risk mutation).
8. RBAC authorization enforcement (Viewer role receives HTTP 403 on all mutations).
9. Manual risk CRUD lifecycle and status transitions (active -> mitigated -> resolved).
10. API endpoints (/api/summary, /api/evaluations), heatmap consistency, and EventBus listener.
"""

import pytest
from datetime import datetime, timedelta, date
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.financial import FinancialRecord
from database.models.inventory import Inventory
from database.models.supplier import Supplier
from database.models.customer import Customer
from database.models.department import Department
from database.models.employee import Employee
from database.models.impact_trace import ImpactTrace, ImpactSeverity
from database.models.risk import Risk, RiskSource, RiskStatus
from services.risk import OperationalRiskEngine
from services.risk_service import RiskService
from services.events import EventBus, EventTypes, DomainEvent
from security.rbac import Role


def _clean_s17_data():
    """Safely delete Stage 17 test tenants and all child records across all tables."""
    try:
        db.session.rollback()
        db.session.close()
    except Exception:
        pass
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE business_name IN ('Stage17 Alpha Corp', 'Stage17 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] not in ('companies', 'sqlite_sequence')]
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's17_%' OR email LIKE 's17_%'")
        conn.commit()
        cursor.execute("PRAGMA foreign_keys = ON")
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def risk_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users and operational entities."""
    with app.app_context():
        _clean_s17_data()

        # Tenant Alpha
        comp_a = Company(
            company_name='Stage17 Alpha Corp',
            business_name='Stage17 Alpha Corp',
            owner_name='Alpha Risk Owner',
            ceo_name='Alpha Risk CEO',
            industry='Manufacturing',
            currency='USD',
            annual_revenue=1200000.0,
            annual_expenses_plan=900000.0,
            customer_count=10,
            employee_count=15
        )
        db.session.add(comp_a)
        db.session.flush()

        user_admin_a = User(
            username='s17_admin_a',
            email='s17_admin_a@alpha.com',
            company_id=comp_a.id,
            role=Role.ADMIN
        )
        user_admin_a.set_password('Secret123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s17_viewer_a',
            email='s17_viewer_a@alpha.com',
            company_id=comp_a.id,
            role=Role.VIEWER
        )
        user_viewer_a.set_password('Secret123!')
        db.session.add(user_viewer_a)

        # Tenant Beta
        comp_b = Company(
            company_name='Stage17 Beta Corp',
            business_name='Stage17 Beta Corp',
            owner_name='Beta Risk Owner',
            ceo_name='Beta Risk CEO',
            industry='Retail',
            currency='USD',
            annual_revenue=500000.0,
            annual_expenses_plan=400000.0,
            customer_count=5,
            employee_count=5
        )
        db.session.add(comp_b)
        db.session.flush()

        user_admin_b = User(
            username='s17_admin_b',
            email='s17_admin_b@beta.com',
            company_id=comp_b.id,
            role=Role.ADMIN
        )
        user_admin_b.set_password('Secret123!')
        db.session.add(user_admin_b)

        db.session.commit()

        yield {
            'comp_a_id': comp_a.id,
            'user_admin_a_id': user_admin_a.id,
            'user_viewer_a_id': user_viewer_a.id,
            'comp_b_id': comp_b.id,
            'user_admin_b_id': user_admin_b.id
        }

        # Cleanup
        try:
            _clean_s17_data()
        except Exception:
            db.session.rollback()


def test_liquidity_runway_threshold_risk_trigger(app, risk_tenants):
    """Verifies that severe cash runway deficit (<1m) triggers automated critical risk with evidence."""
    comp_a_id = risk_tenants['comp_a_id']
    with app.app_context():
        # Seed cash of 5,000 and 30-day expenses of 15,000 (net burn 10,000 -> runway = 0.5 months)
        today = date.today()
        db.session.add(FinancialRecord(
            company_id=comp_a_id,
            transaction_date=today - timedelta(days=25),
            transaction_type='revenue',
            amount=5000.0,
            category='Sales'
        ))
        db.session.add(FinancialRecord(
            company_id=comp_a_id,
            transaction_date=today - timedelta(days=20),
            transaction_type='expense',
            amount=15000.0,
            category='Operations'
        ))
        db.session.commit()

        # Run operational threshold scan
        res = RiskService.evaluate_operational_risks(comp_a_id, actor_user_id=risk_tenants['user_admin_a_id'])
        assert res['success'] is True
        assert res['breached_count'] >= 1

        # Check the created automated risk
        risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='runway_months_severe'
        ).first()

        assert risk is not None
        assert risk.is_automated is True
        assert risk.source == RiskSource.AUTOMATED_THRESHOLD
        assert risk.status == RiskStatus.ACTIVE
        assert risk.risk_level == 'critical'
        assert risk.probability >= 0.90
        assert risk.impact >= 0.90
        assert risk.risk_score >= 80.0

        # Verify auditable evidence JSON
        evidence = risk.get_evidence()
        assert evidence['metric'] == 'cash_runway_months'
        assert evidence['observed_runway'] is not None
        assert evidence['observed_runway'] < 1.0
        assert 'net_monthly_burn' in evidence


def test_inventory_stockout_and_reorder_threshold_triggers(app, risk_tenants):
    """Verifies that stockouts (QOH <= 0) and reorder level breaches trigger automated inventory risks."""
    comp_a_id = risk_tenants['comp_a_id']
    with app.app_context():
        # Create a stocked out item and an item below reorder level
        item_stockout = Inventory(
            company_id=comp_a_id,
            sku='SKU-DEPLETED-01',
            name='Industrial Motor Bearing',
            category='Mechanical',
            quantity_on_hand=0,
            reorder_point=20,
            unit_cost=150.0,
            selling_price=300.0,
            is_active=True
        )
        item_reorder = Inventory(
            company_id=comp_a_id,
            sku='SKU-LOW-02',
            name='Hydraulic Valve',
            category='Mechanical',
            quantity_on_hand=5,
            reorder_point=25,
            unit_cost=80.0,
            selling_price=160.0,
            is_active=True
        )
        db.session.add_all([item_stockout, item_reorder])
        db.session.commit()

        res = RiskService.evaluate_operational_risks(comp_a_id)
        assert res['success'] is True

        # 1. Stockout risk
        stockout_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='inventory_stockout_count'
        ).first()
        assert stockout_risk is not None
        assert stockout_risk.status == RiskStatus.ACTIVE
        assert stockout_risk.risk_level in ('high', 'critical')
        stockout_ev = stockout_risk.get_evidence()
        assert stockout_ev['stockout_count'] >= 1
        assert any('SKU-DEPLETED-01' in s for s in stockout_ev['stockout_skus'])

        # 2. Reorder breach risk
        reorder_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='inventory_reorder_breach_count'
        ).first()
        assert reorder_risk is not None
        assert reorder_risk.status == RiskStatus.ACTIVE
        reorder_ev = reorder_risk.get_evidence()
        assert reorder_ev['breach_count'] >= 1


def test_supplier_and_customer_concentration_triggers(app, risk_tenants):
    """Verifies that high supplier spend (>60%) and customer revenue (>40%) concentration trigger risks."""
    comp_a_id = risk_tenants['comp_a_id']
    with app.app_context():
        # Suppliers: 85% spend with MegaSupplier
        sup1 = Supplier(
            company_id=comp_a_id,
            name='MegaSupplier Inc',
            total_spend=85000.0,
            status='active'
        )
        sup2 = Supplier(
            company_id=comp_a_id,
            name='Minor Supplier LLC',
            total_spend=15000.0,
            status='active'
        )
        db.session.add_all([sup1, sup2])

        # Customers: 75% revenue with BigCorp
        cust1 = Customer(
            company_id=comp_a_id,
            first_name='Big',
            last_name='Corp',
            total_spent=75000.0,
            status='active'
        )
        cust2 = Customer(
            company_id=comp_a_id,
            first_name='Small',
            last_name='Shop',
            total_spent=25000.0,
            status='active'
        )
        db.session.add_all([cust1, cust2])
        db.session.commit()

        res = RiskService.evaluate_operational_risks(comp_a_id)
        assert res['success'] is True

        # Supplier concentration risk
        sup_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='supplier_concentration_pct'
        ).first()
        assert sup_risk is not None
        assert sup_risk.is_automated is True
        assert sup_risk.status == RiskStatus.ACTIVE
        assert sup_risk.observed_value == 85.0
        assert sup_risk.get_evidence()['top_supplier'] == 'MegaSupplier Inc'

        # Customer concentration risk
        cust_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='customer_concentration_pct'
        ).first()
        assert cust_risk is not None
        assert cust_risk.is_automated is True
        assert cust_risk.status == RiskStatus.ACTIVE
        assert cust_risk.observed_value == 75.0
        assert 'Big Corp' in cust_risk.get_evidence()['top_customer']


def test_department_overrun_and_unstaffed_triggers(app, risk_tenants):
    """Verifies that department budget overruns and zero-staff departments trigger operational risks."""
    comp_a_id = risk_tenants['comp_a_id']
    with app.app_context():
        # Dept 1: Budget Overrun
        dept_overrun = Department(
            company_id=comp_a_id,
            name='Marketing & Growth',
            budget=50000.0,
            spent=75000.0,  # 50% overrun
            is_active=True,
            employee_count=3
        )
        # Dept 2: Unstaffed
        dept_empty = Department(
            company_id=comp_a_id,
            name='Quality Assurance',
            budget=80000.0,
            spent=10000.0,
            is_active=True,
            employee_count=0
        )
        db.session.add_all([dept_overrun, dept_empty])
        db.session.commit()

        res = RiskService.evaluate_operational_risks(comp_a_id)
        assert res['success'] is True

        # Overrun risk
        overrun_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='department_budget_overrun_count'
        ).first()
        assert overrun_risk is not None
        assert overrun_risk.status == RiskStatus.ACTIVE
        assert overrun_risk.observed_value >= 1.0
        assert overrun_risk.get_evidence()['max_overrun_pct'] == 50.0

        # Unstaffed risk
        unstaffed_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='unstaffed_department_count'
        ).first()
        assert unstaffed_risk is not None
        assert unstaffed_risk.status == RiskStatus.ACTIVE
        assert 'Quality Assurance' in unstaffed_risk.get_evidence()['unstaffed_departments']


def test_systemic_impact_cascade_trigger(app, risk_tenants):
    """Verifies that high-severity impact traces trigger cross-domain systemic risk."""
    comp_a_id = risk_tenants['comp_a_id']
    with app.app_context():
        trace = ImpactTrace(
            trace_id='trace-s17-test-99',
            company_id=comp_a_id,
            trigger_type='operations.machine_failure',
            root_entity_type='equipment',
            root_entity_id='101',
            severity=ImpactSeverity.CRITICAL,
            affected_nodes_count=7,
            max_depth=4,
            summary_text='Critical disruption propagated to 7 downstream operations and supply nodes.',
            created_at=datetime.utcnow()
        )
        db.session.add(trace)
        db.session.commit()

        res = RiskService.evaluate_operational_risks(comp_a_id)
        assert res['success'] is True

        cascade_risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='systemic_impact_nodes_affected'
        ).first()
        assert cascade_risk is not None
        assert cascade_risk.status == RiskStatus.ACTIVE
        assert cascade_risk.risk_level == 'critical'
        assert cascade_risk.risk_score >= 70.0
        assert cascade_risk.get_evidence()['trace_id'] == 'trace-s17-test-99'


def test_automatic_risk_resolution_on_metric_recovery(app, risk_tenants):
    """Verifies that when operational metrics recover within safe limits, breached risks auto-resolve."""
    comp_a_id = risk_tenants['comp_a_id']
    with app.app_context():
        # 1. Create depleted item
        item = Inventory(
            company_id=comp_a_id,
            sku='SKU-AUTO-RESOLVE',
            name='Titanium Fasteners',
            category='Hardware',
            quantity_on_hand=0,
            reorder_point=50,
            unit_cost=10.0,
            selling_price=25.0,
            is_active=True
        )
        db.session.add(item)
        db.session.commit()

        # 2. Trigger risk
        scan_1 = RiskService.evaluate_operational_risks(comp_a_id)
        assert scan_1['breached_count'] >= 1

        risk = Risk.query.filter_by(
            company_id=comp_a_id,
            trigger_metric='inventory_stockout_count'
        ).first()
        assert risk is not None
        assert risk.status == RiskStatus.ACTIVE
        assert risk.resolved_at is None

        # 3. Restock inventory (operational recovery)
        item.quantity_on_hand = 500
        db.session.commit()

        # 4. Re-evaluate operational thresholds
        scan_2 = RiskService.evaluate_operational_risks(comp_a_id)
        assert scan_2['resolved_count'] >= 1

        db.session.refresh(risk)
        assert risk.status == RiskStatus.RESOLVED
        assert risk.resolved_at is not None
        assert "Operational threshold cleared" in risk.get_evidence().get('resolution_notes', '')


def test_cross_tenant_risk_idor_protection(client, app, risk_tenants):
    """Verifies that cross-tenant risk mutation attempts are blocked with HTTP 404."""
    comp_a_id = risk_tenants['comp_a_id']
    comp_b_id = risk_tenants['comp_b_id']
    user_b_id = risk_tenants['user_admin_b_id']

    with app.app_context():
        # Tenant A risk
        risk_a = Risk(
            company_id=comp_a_id,
            name='Confidential Tenant A Exposure',
            category='compliance',
            probability=0.5,
            impact=0.6,
            status=RiskStatus.ACTIVE
        )
        db.session.add(risk_a)
        db.session.commit()
        target_id = risk_a.id

    # Authenticate as Tenant Beta Admin
    with client.session_transaction() as sess:
        sess['user_id'] = user_b_id
        sess['_user_id'] = str(user_b_id)
        sess['company_id'] = comp_b_id
        sess['role'] = Role.ADMIN

    # Attempt cross-tenant update -> 404
    resp_update = client.post(f'/risk/update/{target_id}', data={'status': 'mitigated'})
    assert resp_update.status_code == 404

    # Attempt cross-tenant delete -> 404
    resp_del = client.post(f'/risk/delete/{target_id}')
    assert resp_del.status_code == 404


def test_viewer_rbac_rejection_on_risk_mutations(client, app, risk_tenants):
    """Verifies that users with Viewer role receive HTTP 403 Forbidden on all risk mutation endpoints."""
    comp_a_id = risk_tenants['comp_a_id']
    viewer_a_id = risk_tenants['user_viewer_a_id']

    with app.app_context():
        risk_a = Risk(
            company_id=comp_a_id,
            name='Alpha Operational Risk',
            category='operational',
            probability=0.4,
            impact=0.5,
            status=RiskStatus.ACTIVE
        )
        db.session.add(risk_a)
        db.session.commit()
        risk_id = risk_a.id

    # Authenticate as Tenant Alpha Viewer
    with client.session_transaction() as sess:
        sess['user_id'] = viewer_a_id
        sess['_user_id'] = str(viewer_a_id)
        sess['company_id'] = comp_a_id
        sess['role'] = Role.VIEWER

    # 1. Trigger threshold evaluation -> 403
    resp1 = client.post('/risk/evaluate')
    assert resp1.status_code == 403

    # 2. Create manual risk -> 403
    resp2 = client.post('/risk/create', data={'name': 'Hacked Risk', 'category': 'market'})
    assert resp2.status_code == 403

    # 3. Update risk -> 403
    resp3 = client.post(f'/risk/update/{risk_id}', data={'status': 'resolved'})
    assert resp3.status_code == 403

    # 4. Delete risk -> 403
    resp4 = client.post(f'/risk/delete/{risk_id}')
    assert resp4.status_code == 403


def test_manual_risk_crud_and_status_transitions(client, app, risk_tenants):
    """Verifies manual risk creation, status progression (active -> mitigated -> resolved), and deletion."""
    comp_a_id = risk_tenants['comp_a_id']
    admin_a_id = risk_tenants['user_admin_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = admin_a_id
        sess['_user_id'] = str(admin_a_id)
        sess['company_id'] = comp_a_id
        sess['role'] = Role.ADMIN

    # 1. Create manual risk
    create_resp = client.post('/risk/create', data={
        'name': 'Regulatory Compliance Overhaul',
        'category': 'compliance',
        'description': 'Upcoming audit requires data residency documentation.',
        'probability': '0.6',
        'impact': '0.7',
        'mitigation_plan': 'Engage external legal counsel and implement residency tags.'
    }, follow_redirects=False)
    assert create_resp.status_code in (200, 302)

    with app.app_context():
        risk = Risk.query.filter_by(
            company_id=comp_a_id,
            name='Regulatory Compliance Overhaul'
        ).first()
        assert risk is not None
        assert risk.is_automated is False
        assert risk.source == RiskSource.MANUAL
        assert risk.status == RiskStatus.ACTIVE
        assert risk.risk_score == 42.0  # 0.6 * 0.7 * 100
        risk_id = risk.id

    # 2. Update to mitigated
    client.post(f'/risk/update/{risk_id}', data={'status': RiskStatus.MITIGATED})
    with app.app_context():
        risk = Risk.query.get(risk_id)
        assert risk.status == RiskStatus.MITIGATED

    # 3. Update to resolved
    client.post(f'/risk/update/{risk_id}', data={'status': RiskStatus.RESOLVED})
    with app.app_context():
        risk = Risk.query.get(risk_id)
        assert risk.status == RiskStatus.RESOLVED
        assert risk.resolved_at is not None

    # 4. Delete risk
    del_resp = client.post(f'/risk/delete/{risk_id}')
    assert del_resp.status_code in (200, 302)

    with app.app_context():
        assert Risk.query.get(risk_id) is None


def test_risk_engine_api_and_heatmap_consistency(client, app, risk_tenants):
    """Verifies /api/summary, /api/evaluations, HTML view rendering, and EventBus listener response."""
    comp_a_id = risk_tenants['comp_a_id']
    admin_a_id = risk_tenants['user_admin_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = admin_a_id
        sess['_user_id'] = str(admin_a_id)
        sess['company_id'] = comp_a_id
        sess['role'] = Role.ADMIN

    # 1. Test /risk/ main view
    resp_index = client.get('/risk/')
    assert resp_index.status_code == 200
    assert b'Operational Thresholds' in resp_index.data or b'Enterprise Risk' in resp_index.data

    # 2. Test /risk/heatmap view
    resp_heat = client.get('/risk/heatmap')
    assert resp_heat.status_code == 200
    assert b'Heatmap' in resp_heat.data

    # 3. Test /risk/api/evaluations
    resp_evals = client.get('/risk/api/evaluations')
    assert resp_evals.status_code == 200
    evals_json = resp_evals.get_json()
    assert isinstance(evals_json, list)
    assert len(evals_json) >= 3

    # 4. Test /risk/api/summary
    resp_sum = client.get('/risk/api/summary')
    assert resp_sum.status_code == 200
    sum_json = resp_sum.get_json()
    assert 'overall_score' in sum_json
    assert 'risk_level' in sum_json
    assert 'automated_count' in sum_json
    assert 'manual_count' in sum_json

    # 5. Test EventBus domain event reaction without recursion
    with app.app_context():
        event = DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=comp_a_id,
            aggregate_type='financial_record',
            aggregate_id='rec-999',
            actor_id=admin_a_id,
            payload={'amount': 1000.0, 'type': 'revenue'}
        )
        # Verify on_domain_event executes cleanly and does not raise
        RiskService.on_domain_event(event)
