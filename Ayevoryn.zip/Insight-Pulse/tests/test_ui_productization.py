import os
import re
import pytest
from flask import session, render_template_string
from app import app
from database.db import db
from database.models import (
    User, Company, Department, Employee, Customer, Supplier, Inventory, FinancialRecord, ThemePreference
)

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    with app.test_client() as client:
        with app.app_context():
            yield client

def login_test_user(client):
    with app.app_context():
        user = User.query.filter_by(username='admin').first()
        if not user:
            comp = Company.query.first()
            if not comp:
                comp = Company(business_name='Test Corp', owner_name='Owner', ceo_name='CEO')
                db.session.add(comp)
                db.session.flush()
            user = User(username='admin', email='admin@test.com', role='Owner')
            user.set_password('Admin1234!')
            user.company_id = comp.id
            db.session.add(user)
            db.session.commit()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(user.id)
        sess['_fresh'] = True
        sess['user_id'] = user.id
        sess['username'] = user.username
        sess['company_id'] = user.company_id
        sess['role'] = user.role or 'Owner'
        sess['theme'] = 'white_clay_glass'
    return user

def test_dark_mode_css_tokens_and_contrast():
    """Verify clay_glass.css contains robust dark mode tokens for badges, modals, tables, and toolbars."""
    with open('static/css/clay_glass.css', 'r', encoding='utf-8') as f:
        css = f.read()

    # Dark badges
    assert '[data-theme="dark_clay_glass"] .badge-success' in css
    assert '[data-theme="dark_clay_glass"] .badge-info' in css
    assert '[data-theme="dark_clay_glass"] .badge-warning' in css
    assert '[data-theme="dark_clay_glass"] .badge-danger' in css
    assert '[data-theme="dark_clay_glass"] .badge-glass' in css

    # Dark modals & popovers
    assert '[data-theme="dark_clay_glass"] .modal-content' in css
    assert 'filter: invert(1)' in css

    # Dark table & search controls
    assert '[data-theme="dark_clay_glass"] .table-glass thead th' in css
    assert '[data-theme="dark_clay_glass"] .tw-search input' in css

def test_no_root_in_child_templates():
    """Enforce strict architectural invariant: NO template extending base.html may define :root."""
    templates_dir = 'templates'
    violations = []
    for root, _, files in os.walk(templates_dir):
        for file in files:
            if not file.endswith('.html'):
                continue
            path = os.path.join(root, file)
            with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            if '{% extends' in content and ':root' in content:
                violations.append(path)
    assert violations == [], f"Found forbidden :root CSS rules in child templates: {violations}"

def test_table_tools_accessibility_attributes():
    """Verify _table_tools.html implements WCAG AA accessibility attributes."""
    with open('templates/business_twin/_table_tools.html', 'r', encoding='utf-8') as f:
        tools = f.read()

    assert 'scope' in tools and 'col' in tools
    assert 'columnheader' in tools
    assert 'tabindex' in tools
    assert 'aria-sort' in tools
    assert 'aria-label="Select all rows"' in tools
    assert 'role="searchbox"' in tools
    assert 'aria-label="Search records"' in tools
    assert 'role="status"' in tools
    assert 'aria-live="polite"' in tools
    assert "setAttribute('role', 'region')" in tools

def test_table_tools_keyboard_sorting_and_empty_search():
    """Verify keyboard sorting events (Enter/Space) and zero-match search row in _table_tools.html."""
    with open('templates/business_twin/_table_tools.html', 'r', encoding='utf-8') as f:
        tools = f.read()

    # Keyboard sorting handler
    assert "e.key === 'Enter' || e.key === ' '" in tools
    # Dynamic zero-match empty row
    assert 'tw-no-match-row' in tools
    assert 'No records matching your search' in tools
    # CSRF token in bulk delete
    assert 'X-CSRFToken' in tools

def test_data_states_macro_rendering(client):
    """Test Jinja2 rendering of empty_state, table_skeleton, and error_state macros."""
    template_str = (
        "{% from 'components/data_states.html' import render_empty_state, render_table_skeleton, render_error_state %}\n"
        "<div id=\"test-empty\">\n"
        "    {{ render_empty_state(\n"
        "        icon='fas fa-chart-line',\n"
        "        title='No Test Records',\n"
        "        message='Please add your first record to begin simulation.',\n"
        "        action_text='Create Record',\n"
        "        action_url='/test/create',\n"
        "        secondary_text='Import Data',\n"
        "        secondary_url='/test/import'\n"
        "    ) }}\n"
        "</div>\n"
        "<table id=\"test-skeleton\">\n"
        "    {{ render_table_skeleton(rows=3, cols=4) }}\n"
        "</table>\n"
        "<div id=\"test-error\">\n"
        "    {{ render_error_state(title='Telemetry Unavailable', message='Could not contact worker node.', retry_url='/retry') }}\n"
        "</div>"
    )
    with app.test_request_context():
        rendered = render_template_string(template_str)

    # Empty state assertions
    assert 'empty-state-card' in rendered
    assert 'role="status"' in rendered
    assert 'No Test Records' in rendered
    assert 'Please add your first record to begin simulation.' in rendered
    assert 'Create Record' in rendered
    assert 'href="/test/create"' in rendered
    assert 'Import Data' in rendered
    assert 'href="/test/import"' in rendered
    assert 'fas fa-chart-line' in rendered

    # Skeleton assertions
    assert 'table-skeleton-body' in rendered
    assert 'aria-busy="true"' in rendered
    assert 'skeleton-pill' in rendered

    # Error assertions
    assert 'error-state-card' in rendered
    assert 'role="alert"' in rendered
    assert 'Telemetry Unavailable' in rendered
    assert 'href="/retry"' in rendered

def test_twin_templates_render_empty_states(client):
    """Test that digital twin templates render the new empty state card when records are empty."""
    user = login_test_user(client)

    # Create an isolated temporary company with 0 records
    with app.app_context():
        empty_comp = Company(
            company_name='Empty State Test Corp',
            business_name='Empty State Test Corp',
            owner_name='Empty Owner',
            ceo_name='Empty CEO'
        )
        db.session.add(empty_comp)
        db.session.commit()
        empty_comp_id = empty_comp.id

    with client.session_transaction() as sess:
        sess['company_id'] = empty_comp_id

    routes_to_test = [
        '/business-twin/revenue',
        '/business-twin/expenses',
        '/business-twin/departments',
        '/business-twin/inventory',
        '/business-twin/suppliers',
        '/business-twin/employees',
    ]

    for route in routes_to_test:
        with app.app_context():
            # Clean any auto-seeded artifacts between route calls to maintain strict zero-state
            Department.query.filter_by(company_id=empty_comp_id).delete()
            Employee.query.filter_by(company_id=empty_comp_id).delete()
            Inventory.query.filter_by(company_id=empty_comp_id).delete()
            Supplier.query.filter_by(company_id=empty_comp_id).delete()
            FinancialRecord.query.filter_by(company_id=empty_comp_id).delete()
            db.session.commit()

        res = client.get(route)
        assert res.status_code == 200, f"Route {route} failed with status {res.status_code}"
        assert b'empty-state-card' in res.data, f"Route {route} did not render empty-state-card"
        assert b'role="status"' in res.data, f"Route {route} missing role='status' in empty state"

def test_cdn_assets_subresource_integrity():
    """Verify base.html contains SRI integrity and crossorigin attributes on CDN dependencies."""
    with open('templates/base.html', 'r', encoding='utf-8') as f:
        base = f.read()

    # Bootstrap CSS SRI
    assert 'integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"' in base
    assert 'crossorigin="anonymous"' in base

    # FontAwesome CSS SRI
    assert 'integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA=="' in base

    # Chart.js SRI
    assert 'integrity="sha512-WWG/QztPBvezaRo3WuRRhsIuvpBPq0jqrQhuD6neZjle2/Fwj/spneB5NxBptNJDdYU/+u2bztZlDpz0JCHyBQ=="' in base

    # Bootstrap JS SRI
    assert 'integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"' in base

def test_theme_switching_route_and_persistence(client):
    """Verify switching themes via /settings/theme persists dark_clay_glass and updates rendered DOM."""
    user = login_test_user(client)

    # Post dark theme
    res = client.post('/settings/theme', data={'theme_id': 'dark_clay_glass'}, headers={'X-Requested-With': 'XMLHttpRequest'})
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert data['theme_id'] == 'dark_clay_glass'

    # Verify session has dark_clay_glass
    with client.session_transaction() as sess:
        assert sess['theme'] == 'dark_clay_glass'

    # Request dashboard and assert data-theme="dark_clay_glass"
    dash_res = client.get('/dashboard')
    assert dash_res.status_code == 200
    assert b'data-theme="dark_clay_glass"' in dash_res.data
