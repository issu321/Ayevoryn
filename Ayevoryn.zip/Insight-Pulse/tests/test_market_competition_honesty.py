"""
TEST SUITE: STAGE 19 - MARKET & COMPETITION HONESTY
Tests the elimination of silent synthetic competitor database seeding,
honest manual & imported state management, deterministic calculations,
multi-tenant IDOR protection, and RBAC enforcement.
"""

import pytest
import json
from datetime import datetime
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.competitor import Competitor
from database.models.market_data import MarketData
from services.competition_service import CompetitionService
from services.market_intelligence_service import MarketIntelligenceService
from services.events import EventBus, EventTypes, DomainEvent
from security.rbac import Role


def _clean_s19_data():
    """Safely delete Stage 19 test tenants and child records."""
    try:
        db.session.rollback()
        db.session.close()
    except Exception:
        pass
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE business_name IN ('Stage19 Alpha Corp', 'Stage19 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] not in ('companies', 'sqlite_sequence')]
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's19_%' OR email LIKE 's19_%'")
        cursor.execute("PRAGMA foreign_keys = ON")
        conn.commit()
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def market_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users."""
    with app.app_context():
        _clean_s19_data()

        comp_a = Company(
            company_name='Stage19 Alpha Corp',
            business_name='Stage19 Alpha Corp',
            owner_name='Alpha Market Owner',
            ceo_name='Alpha Market CEO',
            industry='Technology',
            country='United States',
            annual_revenue=5000000.0,
            employee_count=35,
            currency='USD'
        )
        db.session.add(comp_a)
        db.session.commit()

        user_admin_a = User(
            username='s19_admin_a',
            email='s19_admin_a@alpha.corp',
            role=Role.ADMIN,
            company_id=comp_a.id,
            is_active=True
        )
        user_admin_a.set_password('AdminPass123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s19_viewer_a',
            email='s19_viewer_a@alpha.corp',
            role=Role.VIEWER,
            company_id=comp_a.id,
            is_active=True
        )
        user_viewer_a.set_password('ViewerPass123!')
        db.session.add(user_viewer_a)

        comp_b = Company(
            company_name='Stage19 Beta Corp',
            business_name='Stage19 Beta Corp',
            owner_name='Beta Market Owner',
            ceo_name='Beta Market CEO',
            industry='Healthcare',
            country='Germany',
            annual_revenue=12000000.0,
            employee_count=80,
            currency='EUR'
        )
        db.session.add(comp_b)
        db.session.commit()

        user_admin_b = User(
            username='s19_admin_b',
            email='s19_admin_b@beta.corp',
            role=Role.ADMIN,
            company_id=comp_b.id,
            is_active=True
        )
        user_admin_b.set_password('AdminPass123!')
        db.session.add(user_admin_b)
        db.session.commit()

        data = {
            'comp_a_id': comp_a.id,
            'comp_b_id': comp_b.id,
            'admin_a_id': user_admin_a.id,
            'viewer_a_id': user_viewer_a.id,
            'admin_b_id': user_admin_b.id,
        }

    yield data

    with app.app_context():
        _clean_s19_data()


def test_zero_silent_db_insertion_on_competition_and_market_get(client, market_tenants):
    """
    Test Finding [MKT-P1-02] & Item 13: Navigating to /competition/ or /market/
    must NEVER silently inject synthetic or randomized records into the database.
    """
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_a_id']
        sess['_user_id'] = str(market_tenants['admin_a_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_a_id']
        sess['role'] = Role.ADMIN

    # Verify initially 0 competitors and 0 market data
    assert Competitor.query.filter_by(company_id=market_tenants['comp_a_id']).count() == 0
    assert MarketData.query.filter_by(company_id=market_tenants['comp_a_id']).count() == 0

    # GET /competition/
    res_comp = client.get('/competition/')
    assert res_comp.status_code == 200
    assert b'Competition Analysis' in res_comp.data

    # Zero competitors should have been inserted into DB
    assert Competitor.query.filter_by(company_id=market_tenants['comp_a_id']).count() == 0

    # GET /market/
    res_mkt = client.get('/market/')
    assert res_mkt.status_code == 200
    assert b'Market Intelligence' in res_mkt.data

    # Zero market records should have been inserted into DB
    assert MarketData.query.filter_by(company_id=market_tenants['comp_a_id']).count() == 0


def test_manual_competitor_crud(client, market_tenants):
    """
    Test manual creation, update, and deletion of competitor records with provenance.
    """
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_a_id']
        sess['_user_id'] = str(market_tenants['admin_a_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_a_id']
        sess['role'] = Role.ADMIN

    # Create Competitor
    res_create = client.post('/competition/create', data={
        'name': 'CloudSphere Inc',
        'website': 'https://cloudsphere.io',
        'market_position': 'Challenger',
        'threat_level': 'high',
        'market_share': '14.5',
        'revenue_estimate': '7500000',
        'employee_count': '45',
        'strengths': 'Rapid microservices deployment',
        'weaknesses': 'High customer acquisition cost',
        'pricing_strategy': 'Usage-based'
    }, follow_redirects=True)
    assert res_create.status_code == 200
    assert b'CloudSphere Inc' in res_create.data

    comp = Competitor.query.filter_by(company_id=market_tenants['comp_a_id'], name='CloudSphere Inc').first()
    assert comp is not None
    assert comp.source == 'MANUAL'
    assert comp.is_benchmark is False
    assert comp.market_share == 14.5
    assert comp.revenue_estimate == 7500000.0

    # Update Competitor
    res_update = client.post(f'/competition/update/{comp.id}', data={
        'name': 'CloudSphere Global',
        'market_position': 'Market Leader',
        'threat_level': 'high',
        'market_share': '22.0',
        'revenue_estimate': '11000000',
        'employee_count': '65',
        'strengths': 'Enterprise ecosystem lock-in',
        'weaknesses': 'Legacy architecture overhead',
        'pricing_strategy': 'Enterprise Tier'
    }, follow_redirects=True)
    assert res_update.status_code == 200
    assert b'CloudSphere Global' in res_update.data

    updated_comp = Competitor.query.get(comp.id)
    assert updated_comp.name == 'CloudSphere Global'
    assert updated_comp.market_share == 22.0
    assert updated_comp.market_position == 'Market Leader'

    # Delete Competitor
    res_delete = client.post(f'/competition/delete/{comp.id}', data={
    }, follow_redirects=True)
    assert res_delete.status_code == 200
    assert Competitor.query.get(comp.id) is None


def test_manual_market_data_crud(client, market_tenants):
    """
    Test manual creation and deletion of custom market data records with provenance.
    """
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_a_id']
        sess['_user_id'] = str(market_tenants['admin_a_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_a_id']
        sess['role'] = Role.ADMIN

    # Create Market Datum
    res_create = client.post('/market/create', data={
        'metric_name': 'Custom TAM Projection',
        'metric_value': '45000000000',
        'market_name': 'Enterprise AI Solutions',
        'industry': 'Technology',
        'region': 'North America',
        'currency': 'USD',
        'period': 'FY 2026',
        'source': 'Gartner 2026 Report',
        'notes': 'Verified analyst projection'
    }, follow_redirects=True)
    assert res_create.status_code == 200
    assert b'Custom TAM Projection' in res_create.data

    md = MarketData.query.filter_by(company_id=market_tenants['comp_a_id'], metric_name='Custom TAM Projection').first()
    assert md is not None
    assert md.metric_value == 45000000000.0
    assert md.provenance == 'USER_ENTERED'
    assert md.is_benchmark is False

    # Delete Market Datum
    res_delete = client.post(f'/market/delete/{md.id}', data={
    }, follow_redirects=True)
    assert res_delete.status_code == 200
    assert MarketData.query.get(md.id) is None


def test_explicit_benchmark_templates_loading(client, market_tenants):
    """
    Test explicit opt-in loading of reference benchmark competitors and market data.
    Verifies that records are correctly stamped with benchmark provenance flags.
    """
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_a_id']
        sess['_user_id'] = str(market_tenants['admin_a_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_a_id']
        sess['role'] = Role.ADMIN

    # Explicit Competitor Template Loading
    res_comp_tmpl = client.post('/competition/load-templates', data={
    }, follow_redirects=True)
    assert res_comp_tmpl.status_code == 200

    loaded_competitors = Competitor.query.filter_by(company_id=market_tenants['comp_a_id']).all()
    assert len(loaded_competitors) >= 4
    for c in loaded_competitors:
        assert c.source == 'BENCHMARK_TEMPLATE'
        assert c.is_benchmark is True
        assert c.revenue_estimate > 0
        assert c.market_share > 0

    # Explicit Market Benchmark Loading
    res_mkt_bench = client.post('/market/load-benchmarks', data={
    }, follow_redirects=True)
    assert res_mkt_bench.status_code == 200

    loaded_market_data = MarketData.query.filter_by(company_id=market_tenants['comp_a_id']).all()
    assert len(loaded_market_data) == 12
    for m in loaded_market_data:
        assert m.provenance == 'INDUSTRY_REFERENCE'
        assert m.is_benchmark is True


def test_cross_tenant_competitor_idor_protection(client, market_tenants):
    """
    Verify strict IDOR boundary: Tenant B cannot update or delete Tenant A's competitors.
    """
    # Create Competitor under Tenant A
    with app_context_guard():
        comp_a = Competitor(
            company_id=market_tenants['comp_a_id'],
            name='Alpha Protected Rival',
            market_share=15.0,
            revenue_estimate=5000000.0,
            source='MANUAL'
        )
        db.session.add(comp_a)
        db.session.commit()
        comp_a_id = comp_a.id

    # Log in as Tenant B Admin
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_b_id']
        sess['_user_id'] = str(market_tenants['admin_b_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_b_id']
        sess['role'] = Role.ADMIN

    # Attempt cross-tenant update
    res_update = client.post(f'/competition/update/{comp_a_id}', data={
        'name': 'Hacked Rival Name'
    })
    assert res_update.status_code == 404

    # Attempt cross-tenant delete
    res_delete = client.post(f'/competition/delete/{comp_a_id}', data={
    })
    assert res_delete.status_code == 404

    # Verify Tenant A competitor unchanged
    reloaded = Competitor.query.get(comp_a_id)
    assert reloaded is not None
    assert reloaded.name == 'Alpha Protected Rival'


def test_cross_tenant_market_data_idor_protection(client, market_tenants):
    """
    Verify strict IDOR boundary: Tenant B cannot delete Tenant A's market data.
    """
    with app_context_guard():
        md_a = MarketData(
            company_id=market_tenants['comp_a_id'],
            metric_name='Alpha Proprietary SAM',
            metric_value=250000000.0,
            provenance='USER_ENTERED'
        )
        db.session.add(md_a)
        db.session.commit()
        md_a_id = md_a.id

    # Log in as Tenant B Admin
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_b_id']
        sess['_user_id'] = str(market_tenants['admin_b_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_b_id']
        sess['role'] = Role.ADMIN

    # Attempt cross-tenant delete
    res_delete = client.post(f'/market/delete/{md_a_id}', data={
    })
    assert res_delete.status_code == 404

    # Verify Tenant A metric unchanged
    reloaded = MarketData.query.get(md_a_id)
    assert reloaded is not None
    assert reloaded.metric_name == 'Alpha Proprietary SAM'


def test_viewer_rbac_rejection_on_competition_and_market_mutations(client, market_tenants):
    """
    Verify RBAC authorization: Users with VIEWER role can read but receive 403 Forbidden
    when attempting create, update, delete, import, or template loading actions.
    """
    with app_context_guard():
        comp = Competitor(
            company_id=market_tenants['comp_a_id'],
            name='Target Competitor',
            source='MANUAL'
        )
        md = MarketData(
            company_id=market_tenants['comp_a_id'],
            metric_name='Target Metric',
            metric_value=100.0
        )
        db.session.add_all([comp, md])
        db.session.commit()
        comp_id = comp.id
        md_id = md.id

    # Log in as Tenant A Viewer
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['viewer_a_id']
        sess['_user_id'] = str(market_tenants['viewer_a_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_a_id']
        sess['role'] = Role.VIEWER

    # Read access allowed
    assert client.get('/competition/').status_code == 200
    assert client.get('/market/').status_code == 200

    # Mutations rejected with 403 Forbidden
    assert client.post('/competition/create', data={'name': 'Illegal'}).status_code == 403
    assert client.post(f'/competition/update/{comp_id}', data={'name': 'Illegal'}).status_code == 403
    assert client.post(f'/competition/delete/{comp_id}', data={}).status_code == 403
    assert client.post('/competition/load-templates', data={}).status_code == 403
    assert client.post('/competition/import', data={'import_data': '[]'}).status_code == 403

    assert client.post('/market/create', data={'metric_name': 'Illegal', 'metric_value': '10'}).status_code == 403
    assert client.post(f'/market/delete/{md_id}', data={}).status_code == 403
    assert client.post('/market/load-benchmarks', data={}).status_code == 403
    assert client.post('/market/import', data={'import_data': '[]'}).status_code == 403


def test_deterministic_market_share_and_size_calculations(client, market_tenants):
    """
    Verify that market calculations are strictly deterministic and identical
    across repeated invocations, with zero random noise or jitter.
    """
    cid = market_tenants['comp_a_id']
    with app_context_guard():
        c1 = Competitor(company_id=cid, name='Alpha Rival 1', market_share=20.0, revenue_estimate=10000000.0, threat_level='high')
        c2 = Competitor(company_id=cid, name='Alpha Rival 2', market_share=10.0, revenue_estimate=3000000.0, threat_level='medium')
        db.session.add_all([c1, c2])
        db.session.commit()

    # Invoke summary calculation twice
    summary1 = CompetitionService.get_competition_summary(cid)
    summary2 = CompetitionService.get_competition_summary(cid)

    assert summary1 is not None and summary2 is not None
    assert summary1['total_market'] == summary2['total_market']
    assert summary1['company_share'] == summary2['company_share']
    assert summary1['company_rank'] == summary2['company_rank']
    assert summary1['revenue_gap'] == summary2['revenue_gap']
    assert summary1['gap_pct'] == summary2['gap_pct']
    assert summary1['avg_comp_revenue'] == summary2['avg_comp_revenue']
    assert summary1['total_tracked_share'] == summary2['total_tracked_share']
    assert summary1['company_rank'] == 2  # Leader $10M, Company $5M, Rival 2 $3M -> Rank 2!


def test_competitor_and_market_import_parsing(client, market_tenants):
    """
    Test structured batch import of competitors and market data via JSON.
    """
    with client.session_transaction() as sess:
        sess['user_id'] = market_tenants['admin_a_id']
        sess['_user_id'] = str(market_tenants['admin_a_id'])
        sess['_fresh'] = True
        sess['company_id'] = market_tenants['comp_a_id']
        sess['role'] = Role.ADMIN

    # Batch Competitor JSON Import
    competitors_payload = json.dumps([
        {'name': 'Imported Rival A', 'market_position': 'Challenger', 'market_share': 10.5, 'revenue_estimate': 4000000},
        {'name': 'Imported Rival B', 'market_position': 'Niche Player', 'market_share': 5.0, 'revenue_estimate': 1500000}
    ])
    res_comp_import = client.post('/competition/import', data={
        'import_data': competitors_payload
    }, follow_redirects=True)
    assert res_comp_import.status_code == 200

    imported_comps = Competitor.query.filter_by(company_id=market_tenants['comp_a_id'], source='IMPORT').all()
    assert len(imported_comps) == 2
    assert {c.name for c in imported_comps} == {'Imported Rival A', 'Imported Rival B'}

    # Batch Market Data JSON Import
    market_payload = json.dumps([
        {'metric_name': 'TAM 2026', 'metric_value': 80000000000, 'industry': 'Technology'},
        {'metric_name': 'SAM 2026', 'metric_value': 20000000000, 'industry': 'Technology'}
    ])
    res_mkt_import = client.post('/market/import', data={
        'import_data': market_payload
    }, follow_redirects=True)
    assert res_mkt_import.status_code == 200

    imported_mkt = MarketData.query.filter_by(company_id=market_tenants['comp_a_id'], provenance='IMPORT').all()
    assert len(imported_mkt) == 2
    assert {m.metric_name for m in imported_mkt} == {'TAM 2026', 'SAM 2026'}


def test_domain_events_published_on_competition_and_market_changes(market_tenants):
    """
    Test that canonical EventBus domain events are dispatched on mutations.
    """
    events_received = []

    def event_listener(event):
        events_received.append(event)

    EventBus.subscribe(EventTypes.COMPETITOR_CREATED, event_listener)
    EventBus.subscribe(EventTypes.COMPETITOR_UPDATED, event_listener)
    EventBus.subscribe(EventTypes.COMPETITOR_DELETED, event_listener)
    EventBus.subscribe(EventTypes.MARKET_DATA_UPDATED, event_listener)

    cid = market_tenants['comp_a_id']
    uid = market_tenants['admin_a_id']

    # Create competitor -> dispatches COMPETITOR_CREATED
    comp = CompetitionService.create_competitor(cid, {'name': 'Event Bus Rival'}, actor_user_id=uid)
    assert any(e.event_type == EventTypes.COMPETITOR_CREATED and e.company_id == cid for e in events_received)

    # Update competitor -> dispatches COMPETITOR_UPDATED
    CompetitionService.update_competitor(cid, comp.id, {'market_share': 18.0}, actor_user_id=uid)
    assert any(e.event_type == EventTypes.COMPETITOR_UPDATED and e.company_id == cid for e in events_received)

    # Delete competitor -> dispatches COMPETITOR_DELETED
    CompetitionService.delete_competitor(cid, comp.id, actor_user_id=uid)
    assert any(e.event_type == EventTypes.COMPETITOR_DELETED and e.company_id == cid for e in events_received)

    # Create market datum -> dispatches MARKET_DATA_UPDATED
    md = MarketIntelligenceService.create_market_datum(cid, {'metric_name': 'Event Metric', 'metric_value': 100}, actor_user_id=uid)
    assert any(e.event_type == EventTypes.MARKET_DATA_UPDATED and e.company_id == cid for e in events_received)


class app_context_guard:
    """Helper context manager to guarantee clean session commits within test steps."""
    def __enter__(self):
        return db.session

    def __exit__(self, exc_type, exc_val, exc_tb):
        if exc_type:
            db.session.rollback()
        else:
            db.session.commit()
