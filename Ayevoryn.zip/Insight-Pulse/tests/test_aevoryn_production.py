import pytest
from app import app
from database.models.user import User
from database.models.company import Company

# client fixture is provided by root conftest.py with CSRF injection

def test_home_page(client):
    """Test GET / renders public landing page with AEVORYN branding."""
    res = client.get('/')
    assert res.status_code == 200
    assert b'AEVORYN' in res.data
    assert b'Enterprise Digital Twin' in res.data
    assert b'Decision Intelligence' in res.data

def test_features_page(client):
    """Test GET /features renders deep dive on the 6 simulator engines."""
    res = client.get('/features')
    assert res.status_code == 200
    assert b'AEVORYN' in res.data
    assert b'Core Simulator Architecture' in res.data
    assert b'Real-Time Financial Digital Twin' in res.data
    assert b'AI Predictive Engine' in res.data

def test_login_page_glassy_ui_and_clearance(client):
    """Test GET /login has real glassy transparency, no demo chips, and flexbox icon slot clearance."""
    res = client.get('/login')
    assert res.status_code == 200
    assert b'AEVORYN' in res.data
    # Assert demo chips and auto-fill functions are completely absent
    assert b'demo-bar' not in res.data
    assert b'fillCredentials' not in res.data
    assert b'issu321' not in res.data
    
    # Assert dedicated flex icon slot and input container (guaranteed zero text overlap)
    assert b'input-group-glass' in res.data
    assert b'input-icon-slot' in res.data
    assert b'input-btn-slot' in res.data
    assert b'caps-alert' in res.data
    assert b'login-card-glass' in res.data
    assert b'backdrop-filter: blur(32px)' in res.data

def test_setup_provisioning_console(client):
    """Test GET /setup is a dedicated provisioning console with NO overlapping overlay."""
    res = client.get('/setup')
    assert res.status_code == 200
    assert b'AEVORYN' in res.data
    assert b'introOverlay' not in res.data
    assert b'Enterprise Provisioning Console' in res.data
    assert b'step-indicator' in res.data

def test_register_mirrors_setup(client):
    """Test GET /register also renders clean provisioning console without overlay."""
    res = client.get('/register')
    assert res.status_code == 200
    assert b'introOverlay' not in res.data

def test_multi_user_logins_with_same_password(client):
    """Test that multiple distinct users with the same password (123456) can authenticate cleanly."""
    users_to_test = ['issu321', 'admin', 'ussu', 'jaaf', 'ADMIN', 'Issu321 ']
    for username in users_to_test:
        res = client.post('/login', data={'username': username, 'password': '123456'}, follow_redirects=False)
        assert res.status_code == 302, f"Failed login for '{username}': expected 302 redirect, got {res.status_code}"
        assert res.headers['Location'] in ['/dashboard', 'http://localhost/dashboard'], f"Unexpected redirect for '{username}': {res.headers['Location']}"

def test_security_challenge_recovery_flow(client):
    """Test self-service challenge retrieval and account recovery."""
    # 1. Fetch challenge questions
    res = client.get('/get-challenges?identifier=admin')
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert 'question_1' in data['data']
    
    # 2. Non-existent account returns 404
    res_err = client.get('/get-challenges?identifier=non_existent_corp_999')
    assert res_err.status_code == 404

def test_authenticated_cockpit(client):
    """Test authenticated session loads AEVORYN Executive Cockpit."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/dashboard')
    assert res.status_code == 200
    assert b'AEVORYN' in res.data
    assert b'Executive Cockpit' in res.data

    res_an = client.get('/analytics/')
    assert res_an.status_code == 200
    assert b'AEVORYN' in res_an.data

def test_expense_twin_chart_contrast_and_grouped_bars(client):
    """Test Expense Twin renders high-contrast grouped bar chart and insights panel."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/business-twin/expenses')
    assert res.status_code == 200
    assert b'Expense Twin' in res.data
    # Assert grouped bar mode (eliminates confusing overlapping bars)
    assert b"barmode: 'group'" in res.data
    assert b'deptComparisonChart' in res.data
    assert b'window.getPlotlyThemeLayout' in res.data
    # Assert distinct color encoding for Budget and Spent
    assert b'#2563EB' in res.data
    assert b'#7C3AED' in res.data
    assert b'Department Budget vs. Actual Expenditure' in res.data
    assert b'insights-panel' in res.data

def test_departments_twin_chart_contrast(client):
    """Test Department Twin charts use theme layout and legible fonts."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/business-twin/departments')
    assert res.status_code == 200
    assert b'headcountChart' in res.data
    assert b'payrollChart' in res.data
    assert b'window.getPlotlyThemeLayout' in res.data

def test_clay_glass_css_plotly_svg_contrast_rules(client):
    """Test clay_glass.css contains universal Plotly SVG text fill and modal close button contrast rules."""
    res = client.get('/static/css/clay_glass.css')
    assert res.status_code == 200
    assert b'.js-plotly-plot .xtick text' in res.data
    assert b'fill: #0F172A !important' in res.data
    assert b'[data-theme="white_clay_glass"] .btn-close-white' in res.data
    assert b'filter: none !important' in res.data
    assert b'[data-theme="white_clay_glass"] .status-normal' in res.data

def test_revenue_twin_contrast_and_table_glass(client):
    """Test Revenue Twin uses table-glass and theme variables instead of low-contrast dark styling."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/business-twin/revenue')
    assert res.status_code == 200
    assert b'table-glass' in res.data
    assert b'table-dark' not in res.data
    assert b'revenueChart' in res.data
    assert b'window.getPlotlyThemeLayout' in res.data
    assert b'var(--card-bg)' in res.data
    assert b'form-control-glass' in res.data

def test_competition_analysis_and_modules_no_rogue_root(client):
    """Test Competition Analysis and key modules do not contain rogue :root overrides or ghost-white headings."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    endpoints = [
        '/competition/',
        '/market/',
        '/reports/',
        '/operations/',
        '/forecasting/',
        '/risk/',
    ]
    for ep in endpoints:
        res = client.get(ep)
        assert res.status_code == 200, f"Failed GET {ep}"
        # Ensure rogue dark variables are not overriding the global light theme
        assert b'--text-primary: #e2e8f0' not in res.data, f"Rogue text-primary found in {ep} output!"
        assert b'--glass-bg: rgba(20, 20, 35,' not in res.data, f"Rogue glass-bg found in {ep} output!"

    # Template file static inspection: verify none of the inner templates contain rogue :root overrides
    import os
    template_files = [
        'templates/market/competition_analysis.html',
        'templates/market/market_intelligence.html',
        'templates/reports/report_center.html',
        'templates/operations/operations_simulator.html',
        'templates/forecasting/forecast_lab.html',
        'templates/risk/risk_engine.html',
    ]
    for tf in template_files:
        with open(tf, 'r', encoding='utf-8') as f:
            content = f.read()
            assert ':root' not in content, f"Rogue :root override still present in {tf}"

    # Specific assertions for Competition Analysis
    res_comp = client.get('/competition/')
    assert b'Competition Analysis' in res_comp.data
    assert b'class="text-white">Competition Analysis' not in res_comp.data
    assert b'metric-card' in res_comp.data
    assert b'competitor-card' in res_comp.data

def test_departments_twin_chart_multi_palette_and_alignment(client):
    """Test Department Twin Headcount donut and Payroll bar charts use multi-color palette and matching bar colors."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/business-twin/departments')
    assert res.status_code == 200
    assert b'headcountChart' in res.data
    assert b'payrollChart' in res.data
    # Verify modernPalette and distinct mapping
    assert b'modernPalette' in res.data
    assert b'headcountColors' in res.data
    # Verify outside pointer layout automargin and clearance
    assert b'automargin: true' in res.data
    # Verify Payroll bars marker color matches headcountColors
    assert b'color: headcountColors' in res.data

def test_default_departments_have_distinct_colors():
    """Test that default company creation sets distinct, non-uniform department colors."""
    from services.company_service import DEFAULT_DEPARTMENTS, CompanyService
    with app.app_context():
        from database.models.department import Department
        depts = Department.query.all()
        distinct_colors = {d.color.upper() for d in depts if d.color}
        # Verify that departments are not all monochromatic #00D4FF
        assert len(distinct_colors) > 3, f"Expected >3 distinct colors, got: {distinct_colors}"

def test_ai_status_pill_hover_and_contrast(client):
    """Test AI status pill has high-contrast emerald styling and never washes out to white on hover."""
    res_prem = client.get('/static/css/premium.css')
    assert res_prem.status_code == 200
    # Assert bleached white color #D1FAE5 is completely removed from ai-status-pill:hover
    assert b'color: #D1FAE5;' not in res_prem.data
    assert b'color: #064E3B;' in res_prem.data

    res_clay = client.get('/static/css/clay_glass.css')
    assert res_clay.status_code == 200
    assert b'[data-theme="white_clay_glass"] .ai-status-pill' in res_clay.data
    assert b'color: #047857 !important' in res_clay.data
    assert b'color: #064E3B !important' in res_clay.data
    # Assert Plotly pie/donut leader line styling is present
    assert b'.js-plotly-plot .pielayer path.line' in res_clay.data

def test_analytics_overview_donut_chart_layout(client):
    """Test Business Analytics Budget Mix donut chart has 360px height, center KPI, and outside pointing margins."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/analytics/')
    assert res.status_code == 200
    assert b'Budget Mix by Department' in res.data
    assert b'height: 360px;' in res.data or b'height:360px;' in res.data
    assert b'Total Budget' in res.data
    assert b'direction: \'clockwise\'' in res.data
    assert b'sort: true' in res.data
    assert b'automargin: true' in res.data
    assert b'textposition: \'outside\'' in res.data

def test_department_analytics_donut_chart_layout(client):
    """Test Department Analytics Budget Allocation donut chart has 360px height and auto margins."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/analytics/departments')
    assert res.status_code == 200
    assert b'Budget Allocation' in res.data
    assert b'height: 360px;' in res.data or b'height:360px;' in res.data
    assert b'Total Budget' in res.data
    assert b'automargin: true' in res.data

def test_forecasting_lab_page_renders(client):
    """Test Forecasting Lab renders with complete 10 types, theme-adaptive styling, and no dark thead."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/forecasting/')
    assert res.status_code == 200
    assert b'Forecasting Lab' in res.data
    assert b'Opportunity Forecast' in res.data
    assert b'Risk Forecast' in res.data
    assert b'Cash Flow Forecast' in res.data
    assert b'Prophet' in res.data
    assert b'ARIMA' in res.data
    assert b'1825 days' in res.data
    # Assert dark thead is completely absent
    assert b'background: rgba(20, 20, 35,' not in res.data
    assert b'table-glass' in res.data

def test_forecast_opportunity_prophet_90d(client):
    """Test the exact user scenario: Opportunity Forecast with Prophet and 90 days succeeds with 100% truth."""
    from database.models.forecast import Forecast
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.post('/forecasting/run', data={
        'name': 'Production Opportunity Projection',
        'forecast_type': 'opportunity',
        'method': 'prophet',
        'horizon_days': '90'
    }, follow_redirects=True)
    assert res.status_code == 200
    assert b'generated successfully' in res.data
    assert b'Completed' in res.data
    assert b'Opportunity' in res.data
    assert b'Prophet' in res.data
    assert b'90 days' in res.data
    assert b'Model Fit (R' in res.data
    assert b'#2563EB' in res.data

    # Verify in database
    with app.app_context():
        fc = Forecast.query.filter_by(name='Production Opportunity Projection').first()
        assert fc is not None
        assert fc.status == 'completed'
        assert fc.results.count() == 90
        assert fc.accuracy_r2 is not None
        assert fc.accuracy_mae is not None

def test_all_10_forecast_types_run_successfully():
    """Verify that every one of the 10 enterprise forecast types executes without failure."""
    from services.forecast_service import ForecastService
    from config.constants import FORECAST_TYPES
    with app.app_context():
        u = User.query.first()
        for ft in FORECAST_TYPES:
            f = ForecastService.generate_forecast(1, u.id, ft, 'moving_average', 30, f'Automated {ft}')
            assert f.status == 'completed', f"Forecast failed for type '{ft}': {f.summary}"
            assert f.results.count() == 30
            # Clean up after test
            from database.db import db
            db.session.delete(f)
            db.session.commit()

def test_forecast_rerun_and_delete_routes(client):
    """Test 1-click recalculation and deletion of forecast models."""
    from database.models.forecast import Forecast
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    # 1. Create a test forecast
    res_run = client.post('/forecasting/run', data={
        'name': 'Rerun Test Target',
        'forecast_type': 'demand',
        'method': 'linear_regression',
        'horizon_days': '30'
    }, follow_redirects=True)
    assert res_run.status_code == 200

    with app.app_context():
        target = Forecast.query.filter_by(name='Rerun Test Target').first()
        target_id = target.id

    # 2. Test re-run endpoint
    res_rerun = client.post(f'/forecasting/rerun/{target_id}', follow_redirects=True)
    assert res_rerun.status_code == 200
    assert b're-calculated and healed successfully' in res_rerun.data

    # 3. Test delete endpoint
    res_del = client.post(f'/forecasting/delete/{target_id}', follow_redirects=True)
    assert res_del.status_code == 200
    assert b'deleted successfully' in res_del.data

    with app.app_context():
        assert Forecast.query.get(target_id) is None

def test_global_shell_and_stylesheets_zero_cyan_hardcodes(client):
    """Verify that premium.css, clay_glass.css, and base.html have zero hardcoded cyan and contain tactile glass rules."""
    import os
    # 1. Inspect static/css/premium.css
    with open('static/css/premium.css', 'r', encoding='utf-8') as f:
        prem_content = f.read()
    assert '0, 212, 255' not in prem_content
    assert '0,212,255' not in prem_content
    assert 'var(--accent-primary-rgb' in prem_content

    # 2. Inspect templates/base.html
    with open('templates/base.html', 'r', encoding='utf-8') as f:
        base_content = f.read()
    assert '0, 212, 255' not in base_content
    assert '0,212,255' not in base_content
    assert 'rgba(0, 212, 255' not in base_content

    # 3. Inspect static/css/clay_glass.css for tactile normalizers
    with open('static/css/clay_glass.css', 'r', encoding='utf-8') as f:
        clay_content = f.read()
    assert '.action-glass-card' in clay_content
    assert '.stat-glass-card' in clay_content
    assert 'inset 0 1.5px 2px' in clay_content

def test_submodules_render_tactile_glass_and_no_legacy_cyan(client):
    """Verify Command Center and AI Insights render with theme tokens and zero legacy cyan."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res_cc = client.get('/command-center/')
    assert res_cc.status_code == 200
    assert b'Command Center' in res_cc.data
    assert b'#00D4FF' not in res_cc.data
    assert b'agent-bar' in res_cc.data
    assert b'kpi-card' in res_cc.data

    res_ai = client.get('/ai-insights/')
    assert res_ai.status_code == 200
    assert b'AI Insights' in res_ai.data
    assert b'#00D4FF' not in res_ai.data
    assert b'AI-Generated Decision Insights' in res_ai.data
    assert b'glass-card-primary' in res_ai.data

def test_dashboard_enterprise_cockpit_full_features(client):
    """Verify that the Executive Dashboard renders real enterprise cockpit modules and zero broken UI."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/dashboard')
    assert res.status_code == 200
    html = res.data.decode('utf-8')
    
    # Assert Executive Header and Telemetry Ribbon
    assert 'Executive Brief' in html
    assert 'Cash Runway' in html
    assert 'Net Daily Cash Flow' in html
    assert 'Gross Margin' in html
    assert 'Target Attainment' in html
    assert 'Twin Nodes' in html

    # Assert 7-Card Scorecards Grid
    assert 'Composite Vitals' in html
    assert 'Workforce & Output' in html
    assert 'Supply Chain & Inventory' in html

    # Assert Departmental Twin Performance Matrix
    assert 'Departmental Twin Performance & Capacity Utilization Matrix' in html
    assert 'Live Capacity' in html
    assert 'Twin Status' in html

    # Assert Operational Threat Matrix
    assert 'Operational Threat Matrix' in html
    assert 'Active Enterprise Risks & Vulnerability Radar' in html

    # Assert 3-Variable What-If Sandbox
    assert 'Executive Scenario Simulator (3-Variable What-If Sandbox)' in html
    assert 'Price Shift' in html
    assert 'Cost Reduction' in html
    assert 'Volume Shift' in html
    assert 'Runway Impact' in html

    # Assert AI Forecast toggle and Board Briefing modal
    assert 'AI Forecast Projection' in html
    assert 'Executive Board Briefing Summary' in html
    assert 'boardBriefModal' in html

def test_dashboard_api_forecast_overlay(client):
    """Verify GET /dashboard/api/forecast-overlay returns valid 30-day forecast projection with confidence bands."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/dashboard/api/forecast-overlay?days=30')
    assert res.status_code == 200
    data = res.get_json()
    assert 'dates' in data
    assert 'revenue' in data
    assert 'expenses' in data
    assert 'upper_band' in data
    assert 'lower_band' in data
    assert len(data['dates']) == 30
    assert len(data['revenue']) == 30
    assert len(data['upper_band']) == 30
    assert len(data['lower_band']) == 30

def test_dashboard_api_board_brief(client):
    """Verify GET /dashboard/api/board-brief returns structured executive summary data."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else None

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id
        sess['theme'] = 'white_clay_glass'

    res = client.get('/dashboard/api/board-brief')
    assert res.status_code == 200
    data = res.get_json()
    assert 'company_name' in data
    assert 'health_score' in data
    assert 'revenue_30d' in data
    assert 'profit_30d' in data
    assert 'margin' in data
    assert 'departments' in data

def test_clay_glass_css_glow_tokens():
    """Verify static/css/clay_glass.css contains new glowing tokens and live radar pulse."""
    with open('static/css/clay_glass.css', 'r', encoding='utf-8') as f:
        content = f.read()
    assert '.glass-card-glow' in content
    assert '.glass-card-glow-primary' in content
    assert '.badge-glow-success' in content
    assert '.live-pulse-dot' in content
    assert '@keyframes live-radar-pulse' in content

def test_all_active_templates_zero_legacy_cyan():
    """Ensure all active templates have zero occurrences of hardcoded cyan rgb values."""
    import os
    for root, _, files in os.walk('templates'):
        for file in files:
            if file.endswith('.html'):
                filepath = os.path.join(root, file)
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                assert '0, 212, 255' not in content, f"Legacy cyan '0, 212, 255' found in {filepath}"
                assert '0,212,255' not in content, f"Legacy cyan '0,212,255' found in {filepath}"

def test_reporting_center_page_authenticated(client):
    """Verify GET /reports renders 9 domain selector cards, 3 format cards, and HUD blueprint."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else 1

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id

    res = client.get('/reports/')
    assert res.status_code == 200
    # Check 9 domains
    for domain in ['executive', 'board', 'investor', 'risk', 'growth', 'forecast', 'financial', 'operational', 'department']:
        assert f'data-report-type="{domain}"'.encode() in res.data
    # Check 3 export formats
    assert b'data-format="pdf"' in res.data
    assert b'data-format="excel"' in res.data
    assert b'data-format="csv"' in res.data
    # Check HUD blueprint elements
    assert b'hudDomainBadge' in res.data
    assert b'hudFormatBadge' in res.data
    assert b'hudManifestItems' in res.data

def test_reporting_api_deliverable_manifests(client):
    """Verify GET /reports/api/deliverable-preview/<report_type>/<format_type> returns valid manifests for all 27 combinations."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else 1

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id

    domains = ['executive', 'board', 'investor', 'risk', 'growth', 'forecast', 'financial', 'operational', 'department']
    formats = ['pdf', 'excel', 'csv']

    for domain in domains:
        for fmt in formats:
            res = client.get(f'/reports/api/deliverable-preview/{domain}/{fmt}')
            assert res.status_code == 200
            data = res.get_json()
            assert data['report_type'] == domain
            assert data['format'] == fmt
            assert 'components' in data and len(data['components']) > 0
            assert 'audience' in data and len(data['audience']) > 0
            assert 'provenance' in data

def test_reporting_web_viewer_all_domains(client):
    """Verify GET /reports/view/<report_type> renders successfully with live data for all 9 domains."""
    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else 1

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id

    domains = ['executive', 'board', 'investor', 'risk', 'growth', 'forecast', 'financial', 'operational', 'department']
    for domain in domains:
        res = client.get(f'/reports/view/{domain}')
        assert res.status_code == 200
        assert b'Reporting Center' in res.data
        assert b'Download PDF' in res.data
        assert b'Download Excel' in res.data
        assert b'Download CSV' in res.data

def test_reporting_generation_and_management(client):
    """Verify POST /reports/generate produces valid file, re-exports companion format, and deletes properly."""
    import os
    from database.models.report import Report
    from database.db import db

    with app.app_context():
        u = User.query.first()
        comp = Company.query.first()
        comp_id = comp.id if comp else 1

    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
        sess['company_id'] = comp_id

    # 1. Generate an Executive Excel report
    res = client.post('/reports/generate', data={
        'report_type': 'executive',
        'format': 'excel',
        'name': 'Test Executive Model'
    }, follow_redirects=True)
    assert res.status_code == 200

    with app.app_context():
        rep = Report.query.filter_by(company_id=comp_id, name='Test Executive Model').first()
        assert rep is not None
        assert rep.format in ('excel', 'xlsx')
        assert rep.file_path is not None
        assert os.path.exists(rep.file_path)
        rep_id = rep.id
        file_path = rep.file_path

    # 2. Re-export companion as CSV
    res_re = client.post(f'/reports/re-export/{rep_id}/csv', follow_redirects=True)
    assert res_re.status_code == 200
    with app.app_context():
        companion = Report.query.filter_by(company_id=comp_id, format='csv').order_by(Report.id.desc()).first()
        assert companion is not None
        assert os.path.exists(companion.file_path)
        companion_id = companion.id
        companion_path = companion.file_path

    # 3. Delete reports
    res_del = client.post(f'/reports/delete/{rep_id}', follow_redirects=True)
    assert res_del.status_code == 200
    assert not os.path.exists(file_path)

    res_del_comp = client.post(f'/reports/delete/{companion_id}', follow_redirects=True)
    assert res_del_comp.status_code == 200
    assert not os.path.exists(companion_path)

if __name__ == '__main__':
    pytest.main(['-v', __file__])



