import pytest
import json
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from services.custom_twin_service import (
    CustomTwinSchemaService, TwinFormulaEngine,
    SchemaValidationError, CycleDependencyError, FormulaEvaluationError
)


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage8'
    })
    with app.app_context():
        db.create_all()
        # Seed test user and company
        user = User(username='stage8_admin', email='stage8@example.com', role='admin')
        user.set_password('password123')
        db.session.add(user)
        db.session.commit()

        company = Company(
            company_name='Stage 8 Corp',
            business_name='Stage 8 Corp',
            owner_name='Stage 8 Owner',
            ceo_name='Stage 8 CEO'
        )
        db.session.add(company)
        db.session.commit()

        yield app
        db.session.remove()
        db.drop_all()


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def auth_client(client, app):
    with client.session_transaction() as sess:
        with app.app_context():
            user = User.query.filter_by(username='stage8_admin').first()
            company = Company.query.first()
            sess['_user_id'] = str(user.id)
            sess['company_id'] = company.id
    return client


# =============================================================================
# 1. FIELD DEFINITIONS SCHEMA VALIDATION
# =============================================================================

def test_validate_field_definitions_valid():
    fields = [
        {'name': 'sku', 'label': 'SKU Code', 'type': 'text', 'required': True},
        {'name': 'quantity', 'label': 'Quantity', 'type': 'integer', 'required': True},
        {'name': 'unit_cost', 'label': 'Unit Cost', 'type': 'number', 'required': True},
        {'name': 'total_cost', 'label': 'Total Cost', 'type': 'formula', 'formula': '{quantity} * {unit_cost}'},
        {'name': 'status', 'label': 'Status', 'type': 'select', 'options': ['In Stock', 'Ordered']},
        {'name': 'reorder_needed', 'label': 'Reorder?', 'type': 'boolean'},
        {'name': 'received_date', 'label': 'Received Date', 'type': 'date'}
    ]
    cleaned, errors = CustomTwinSchemaService.validate_field_definitions(fields)
    assert not errors
    assert len(cleaned) == 7
    assert cleaned[3]['type'] == 'formula'
    assert cleaned[3]['formula'] == '{quantity} * {unit_cost}'


def test_validate_field_definitions_invalid_names_and_duplicates():
    fields = [
        {'name': '123_bad', 'type': 'text'},
        {'name': 'has space', 'type': 'text'},
        {'name': 'valid_name', 'type': 'text'},
        {'name': 'valid_name', 'type': 'number'},  # duplicate
        {'name': 'unsupported', 'type': 'invalid_type_xyz'}
    ]
    cleaned, errors = CustomTwinSchemaService.validate_field_definitions(fields)
    assert 'field_0_name' in errors
    assert 'field_1_name' in errors
    assert 'field_3_name' in errors  # duplicate
    assert 'field_4_type' in errors  # unsupported


# =============================================================================
# 2. FORMULA ENGINE & CYCLE DETECTION
# =============================================================================

def test_formula_engine_evaluation_basic():
    record = {'qty': 10, 'price': 25.5}
    # Test bracket syntax
    res1 = TwinFormulaEngine.evaluate_expression('{qty} * {price}', record)
    assert res1 == 255.0

    # Test direct syntax and safe math functions
    record_adv = {'val_a': 100, 'val_b': 45}
    res2 = TwinFormulaEngine.evaluate_expression('max(val_a, val_b) - min(val_a, val_b)', record_adv)
    assert res2 == 55.0

    # Test division by zero safety
    res3 = TwinFormulaEngine.evaluate_expression('val_a / 0', record_adv)
    assert res3 == 0.0


def test_formula_engine_disallowed_syntax():
    record = {'val': 10}
    # Attempting attribute access or function calls that are not whitelisted
    with pytest.raises(FormulaEvaluationError):
        TwinFormulaEngine.evaluate_expression('__import__("os").system("ls")', record, raise_on_error=True)

    with pytest.raises(FormulaEvaluationError):
        TwinFormulaEngine.evaluate_expression('val.__class__', record, raise_on_error=True)


def test_formula_cycle_detection():
    fields = [
        {'name': 'a', 'type': 'formula', 'formula': '{b} + 1'},
        {'name': 'b', 'type': 'formula', 'formula': '{c} * 2'},
        {'name': 'c', 'type': 'formula', 'formula': '{a} - 5'}
    ]
    with pytest.raises(CycleDependencyError) as exc_info:
        TwinFormulaEngine.get_evaluation_order(fields)
    assert exc_info.value.cycle_path is not None


def test_formula_topological_sort_and_record_evaluation():
    fields = [
        {'name': 'base', 'type': 'number'},
        {'name': 'tax_rate', 'type': 'number'},
        {'name': 'grand_total', 'type': 'formula', 'formula': '{subtotal} + {tax_amount}'},
        {'name': 'subtotal', 'type': 'formula', 'formula': '{base} * 2'},
        {'name': 'tax_amount', 'type': 'formula', 'formula': '{subtotal} * {tax_rate}'}
    ]
    # Dependency order must resolve subtotal -> tax_amount -> grand_total
    order = TwinFormulaEngine.get_evaluation_order(fields)
    order_names = [f['name'] for f in order]
    assert order_names.index('subtotal') < order_names.index('grand_total')
    assert order_names.index('tax_amount') < order_names.index('grand_total')

    record = {'base': 100, 'tax_rate': 0.1}
    evaled = TwinFormulaEngine.evaluate_record(fields, record)
    assert evaled['subtotal'] == 200.0
    assert evaled['tax_amount'] == 20.0
    assert evaled['grand_total'] == 220.0


# =============================================================================
# 3. RECORD DATA CLEANING & VALIDATION
# =============================================================================

def test_validate_and_clean_record_data():
    fields = [
        {'name': 'title', 'type': 'text', 'required': True},
        {'name': 'count', 'type': 'integer', 'required': True},
        {'name': 'cost', 'type': 'number'},
        {'name': 'total', 'type': 'formula', 'formula': '{count} * {cost}'},
        {'name': 'category', 'type': 'select', 'options': ['Tech', 'Ops']}
    ]

    # Missing required field
    cleaned, errors = CustomTwinSchemaService.validate_and_clean_record_data(fields, {'count': '5'})
    assert 'title' in errors

    # Invalid select option
    cleaned, errors = CustomTwinSchemaService.validate_and_clean_record_data(
        fields, {'title': 'Server', 'count': '5', 'category': 'Invalid'}
    )
    assert 'category' in errors

    # Complete valid data with automatic formula calculation
    cleaned, errors = CustomTwinSchemaService.validate_and_clean_record_data(
        fields, {'title': 'Server', 'count': '4', 'cost': '150.50', 'category': 'Tech'}
    )
    assert not errors
    assert cleaned['title'] == 'Server'
    assert cleaned['count'] == 4
    assert cleaned['cost'] == 150.5
    assert cleaned['total'] == 602.0


# =============================================================================
# 4. HIERARCHY CYCLE DETECTION & DESCENDANTS
# =============================================================================

def test_parent_hierarchy_cycle_detection(app):
    with app.app_context():
        company = Company.query.first()
        t1 = CustomTwin(company_id=company.id, name='Twin 1', slug='twin-1')
        t2 = CustomTwin(company_id=company.id, name='Twin 2', slug='twin-2')
        db.session.add_all([t1, t2])
        db.session.commit()

        # Self as parent
        with pytest.raises(CycleDependencyError) as exc_info:
            CustomTwinSchemaService.validate_parent_hierarchy(company.id, t1.id, t1.id)
        assert "cannot be its own parent" in str(exc_info.value)

        # Make t2 child of t1
        t2.parent_twin_id = t1.id
        db.session.commit()

        # Now attempting to make t1 child of t2 should be rejected as cycle
        with pytest.raises(CycleDependencyError) as exc_info2:
            CustomTwinSchemaService.validate_parent_hierarchy(company.id, t1.id, t2.id)
        assert "circular" in str(exc_info2.value).lower()

        # Verify CustomTwin.get_descendant_twins is safe against loops
        descendants = t1.get_descendant_twins()
        assert len(descendants) == 1
        assert descendants[0].id == t2.id


# =============================================================================
# 5. HTTP ROUTES INTEGRATION
# =============================================================================

def test_create_and_record_flow_with_formulas(auth_client, app):
    # 1. Create twin with formula field
    payload = {
        'name': 'Warehouse Inventory',
        'field_definitions': [
            {'name': 'item_name', 'label': 'Item Name', 'type': 'text', 'required': True},
            {'name': 'units', 'label': 'Units', 'type': 'integer', 'required': True},
            {'name': 'unit_price', 'label': 'Unit Price', 'type': 'number', 'required': True},
            {'name': 'inventory_val', 'label': 'Total Value', 'type': 'formula', 'formula': '{units} * {unit_price}'}
        ],
        'stats_config': [
            {'name': 'total_val', 'label': 'Total Asset Value', 'type': 'sum', 'field': 'inventory_val'}
        ]
    }
    resp = auth_client.post('/business-twin/custom-twins/create', json=payload)
    assert resp.status_code == 200
    res_data = resp.get_json()
    assert res_data['success'] is True
    twin_id = res_data['twin']['id']

    # 2. Add record - formula should be evaluated automatically
    rec_resp = auth_client.post(f'/business-twin/custom-twins/{twin_id}/records', json={
        'item_name': 'MacBook Pro',
        'units': 10,
        'unit_price': 1999.00
    })
    assert rec_resp.status_code == 200
    rec_json = rec_resp.get_json()
    assert rec_json['success'] is True
    assert rec_json['record']['data']['inventory_val'] == 19990.0

    rec_id = rec_json['record']['id']

    # 3. Edit record - formula should recompute
    edit_resp = auth_client.post(f'/business-twin/custom-twins/records/{rec_id}', json={
        'units': 20
    })
    assert edit_resp.status_code == 200
    edit_json = edit_resp.get_json()
    assert edit_json['success'] is True
    assert edit_json['record']['data']['units'] == 20
    assert edit_json['record']['data']['inventory_val'] == 39980.0

    # 4. Export CSV
    export_resp = auth_client.get(f'/business-twin/custom-twins/{twin_id}/export-csv')
    assert export_resp.status_code == 200
    assert 'text/csv' in export_resp.content_type
    csv_text = export_resp.data.decode('utf-8-sig')
    assert 'MacBook Pro' in csv_text
    assert '39980.0' in csv_text

    # 5. Delete all records
    del_resp = auth_client.delete(f'/business-twin/custom-twins/{twin_id}/records/delete-all')
    assert del_resp.status_code == 200
    del_json = del_resp.get_json()
    assert del_json['success'] is True
    assert del_json['deleted'] == 1


def test_create_custom_twin_cycle_rejection(auth_client):
    # Reject formula cycle on twin creation
    payload = {
        'name': 'Cyclic Twin',
        'field_definitions': [
            {'name': 'f1', 'type': 'formula', 'formula': '{f2} + 1'},
            {'name': 'f2', 'type': 'formula', 'formula': '{f1} * 2'}
        ]
    }
    resp = auth_client.post('/business-twin/custom-twins/create', json=payload)
    assert resp.status_code == 400
    data = resp.get_json()
    assert data['success'] is False
    assert 'Circular dependency' in data['error']
