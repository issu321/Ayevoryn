"""
AEVORYN / INSIGHT-PULSE
STAGE 13: TEMPORAL DIGITAL TWIN AUTOMATED TEST SUITE
Validates point-in-time historical reconstruction, snapshot lifecycle,
variance diff analysis, multi-tenant isolation, and RBAC route security.
"""

import pytest
from datetime import datetime, date, timedelta
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.financial import FinancialRecord
from database.models.twin_snapshot import TwinSnapshot, SnapshotType
from services.events import DomainEvent, EventBus, EventTypes
from services.temporal_service import TemporalService
from security.rbac import Role, Permission


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage13'
    })
    with app.app_context():
        db.create_all()

        # Seed Company 1 (Tenant Alpha)
        comp_a = Company(
            company_name='Temporal Alpha Corp',
            business_name='Temporal Alpha',
            owner_name='Alice Temporal',
            ceo_name='Arthur Temporal',
            total_equity=100000.0
        )
        db.session.add(comp_a)

        # Seed Company 2 (Tenant Beta)
        comp_b = Company(
            company_name='Temporal Beta Corp',
            business_name='Temporal Beta',
            owner_name='Bob Temporal',
            ceo_name='Boris Temporal',
            total_equity=50000.0
        )
        db.session.add(comp_b)
        db.session.commit()

        # Seed Admin user for Company 1
        admin_user = User(
            username='alpha_admin_stage13',
            email='admin@temporal-alpha.com',
            role=Role.ADMIN,
            company_id=comp_a.id
        )
        admin_user.set_password('password123')
        db.session.add(admin_user)

        # Seed Viewer user for Company 1
        viewer_user = User(
            username='alpha_viewer_stage13',
            email='viewer@temporal-alpha.com',
            role=Role.VIEWER,
            company_id=comp_a.id
        )
        viewer_user.set_password('password123')
        db.session.add(viewer_user)

        # Seed User for Company 2
        beta_user = User(
            username='beta_user_stage13',
            email='user@temporal-beta.com',
            role=Role.MANAGER,
            company_id=comp_b.id
        )
        beta_user.set_password('password123')
        db.session.add(beta_user)
        db.session.commit()

        EventBus.clear_subscribers()
        yield app
        EventBus.clear_subscribers()
        db.session.remove()
        db.drop_all()


@pytest.fixture
def admin_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_admin_stage13').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def viewer_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_viewer_stage13').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def beta_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='beta_user_stage13').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


# =============================================================================
# 1. MULTI-TENANT SNAPSHOT ISOLATION
# =============================================================================

def test_multi_tenant_snapshot_isolation(app):
    """Verify that snapshots are strictly partitioned by company_id."""
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Temporal Alpha Corp').first()
        comp_b = Company.query.filter_by(company_name='Temporal Beta Corp').first()

        snap_a = TemporalService.create_snapshot(
            company_id=comp_a.id,
            name="Alpha Baseline",
            description="Alpha baseline snapshot"
        )
        snap_b = TemporalService.create_snapshot(
            company_id=comp_b.id,
            name="Beta Baseline",
            description="Beta baseline snapshot"
        )

        snap_a_id = snap_a.snapshot_id
        snap_b_id = snap_b.snapshot_id

        # Query snapshots
        snaps_for_a = TemporalService.get_snapshots(comp_a.id)
        snaps_for_b = TemporalService.get_snapshots(comp_b.id)

        a_ids = [s['snapshot_id'] for s in snaps_for_a]
        b_ids = [s['snapshot_id'] for s in snaps_for_b]

        assert snap_a_id in a_ids
        assert snap_b_id not in a_ids

        assert snap_b_id in b_ids
        assert snap_a_id not in b_ids

        # Direct lookup by ID
        assert TemporalService.get_snapshot_by_id(comp_a.id, snap_a_id) is not None
        assert TemporalService.get_snapshot_by_id(comp_b.id, snap_a_id) is None


# =============================================================================
# 2. POINT-IN-TIME HISTORICAL RECONSTRUCTION
# =============================================================================

def test_reconstruct_state_as_of_historical_date(app):
    """Verify that reconstructing state as of a historical date includes only past records."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Temporal Alpha Corp').first()

        d1 = date(2026, 1, 15)
        d2 = date(2026, 3, 1)

        # Early transaction: January 15, 2026
        r1 = FinancialRecord(
            company_id=comp.id,
            amount=25000.0,
            transaction_type='revenue',
            transaction_date=d1,
            category='Services',
            description='Q1 Advisory'
        )
        # Later transaction: March 1, 2026
        r2 = FinancialRecord(
            company_id=comp.id,
            amount=50000.0,
            transaction_type='revenue',
            transaction_date=d2,
            category='Software',
            description='Enterprise License'
        )
        e2 = FinancialRecord(
            company_id=comp.id,
            amount=15000.0,
            transaction_type='expense',
            transaction_date=d2,
            category='Hosting',
            description='Cloud Infrastructure'
        )
        db.session.add_all([r1, r2, e2])
        db.session.commit()

        # 1. As-of February 1, 2026: only r1 exists
        as_of_feb = datetime(2026, 2, 1, 0, 0, 0)
        state_feb = TemporalService.reconstruct_state_as_of(comp.id, as_of_feb)

        assert state_feb['metrics']['cumulative_revenue'] == 25000.0
        assert state_feb['metrics']['cumulative_expenses'] == 0.0

        # 2. As-of March 15, 2026: both r1, r2, e2 exist
        as_of_mar = datetime(2026, 3, 15, 0, 0, 0)
        state_mar = TemporalService.reconstruct_state_as_of(comp.id, as_of_mar)

        assert state_mar['metrics']['cumulative_revenue'] == 75000.0
        assert state_mar['metrics']['cumulative_expenses'] == 15000.0
        # 30d window around March 15 includes March 1 transaction
        assert state_mar['metrics']['revenue_30d'] == 50000.0
        assert state_mar['metrics']['expense_30d'] == 15000.0
        assert state_mar['metrics']['net_profit_30d'] == 35000.0


# =============================================================================
# 3. SNAPSHOT LIFECYCLE & EVENTS
# =============================================================================

def test_create_and_delete_snapshot_lifecycle(app):
    """Verify snapshot creation, JSON payload serialization, and event emissions."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Temporal Alpha Corp').first()

        captured_events = []
        def listener(ev):
            captured_events.append(ev)
        EventBus.subscribe('*', listener)

        # Create
        snap = TemporalService.create_snapshot(
            company_id=comp.id,
            name="Q1 Fiscal Close",
            snapshot_type=SnapshotType.CLOSE,
            description="Official close milestone for Q1"
        )
        assert snap is not None
        assert snap.name == "Q1 Fiscal Close"
        assert snap.snapshot_type == SnapshotType.CLOSE
        assert 'revenue_30d' in snap.get_metrics()
        assert 'employees' in snap.get_entity_counts()

        event_types = [e.event_type for e in captured_events]
        assert EventTypes.TWIN_SNAPSHOT_CREATED in event_types

        # Delete
        success = TemporalService.delete_snapshot(comp.id, snap.snapshot_id)
        assert success is True
        assert TemporalService.get_snapshot_by_id(comp.id, snap.snapshot_id) is None

        event_types = [e.event_type for e in captured_events]
        assert EventTypes.TWIN_SNAPSHOT_DELETED in event_types


# =============================================================================
# 4. TEMPORAL VARIANCE COMPARISON
# =============================================================================

def test_compare_snapshots_variance(app):
    """Verify multi-dimensional variance analysis between two digital twin snapshots."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Temporal Alpha Corp').first()

        # Milestone 1
        s1 = TemporalService.create_snapshot(
            company_id=comp.id,
            name="Milestone 1 - Initial State",
            as_of=datetime(2026, 1, 1, 0, 0, 0)
        )

        # Add revenue & employee before Milestone 2
        r = FinancialRecord(
            company_id=comp.id,
            amount=40000.0,
            transaction_type='revenue',
            transaction_date=date(2026, 2, 1),
            category='Sales',
            description='Client Retainer'
        )
        emp = Employee(
            company_id=comp.id,
            first_name='John',
            last_name='Doe',
            email='john.doe@temporal-alpha.com',
            job_title='Software Engineer',
            salary=90000.0,
            hire_date=date(2026, 2, 1)
        )
        db.session.add_all([r, emp])
        db.session.commit()

        # Milestone 2
        s2 = TemporalService.create_snapshot(
            company_id=comp.id,
            name="Milestone 2 - Post Growth",
            as_of=datetime(2026, 2, 15, 0, 0, 0)
        )

        diff = TemporalService.compare_snapshots(comp.id, s1.snapshot_id, s2.snapshot_id)
        assert diff is not None
        assert 'financial_variances' in diff
        assert 'entity_variances' in diff
        assert 'summary_text' in diff

        # Check financial variance on revenue_30d
        rev_var = next(f for f in diff['financial_variances'] if f['metric_key'] == 'revenue_30d')
        assert rev_var['delta'] == 40000.0
        assert rev_var['signal'] == 'FAVORABLE'

        # Check employee delta
        emp_var = diff['entity_variances']['employees']
        assert emp_var['delta'] == 1


def test_compare_historical_dates_variance(app):
    """Verify direct historical date-to-date comparative analysis."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Temporal Alpha Corp').first()

        d_a = datetime(2026, 1, 1, 0, 0, 0)
        d_b = datetime(2026, 3, 1, 0, 0, 0)

        diff = TemporalService.compare_historical_dates(comp.id, d_a, d_b)
        assert diff is not None
        assert diff['date_a'] == d_a.isoformat()
        assert diff['date_b'] == d_b.isoformat()
        assert 'financial_variances' in diff


# =============================================================================
# 5. HTTP ROUTES & RBAC AUTHORIZATION
# =============================================================================

def test_temporal_routes_admin_access(app, admin_client):
    """Verify that authenticated admin can view UI and execute all temporal APIs."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Temporal Alpha Corp').first()

    # 1. GET /temporal/ HTML UI
    res_ui = admin_client.get('/temporal/')
    assert res_ui.status_code == 200
    assert b'Temporal Digital Twin' in res_ui.data

    # 2. GET /temporal/api/state-as-of
    res_state = admin_client.get('/temporal/api/state-as-of?date=2026-02-01')
    assert res_state.status_code == 200
    json_state = res_state.get_json()
    assert json_state['success'] is True
    assert 'metrics' in json_state['data']

    # 3. POST /temporal/api/snapshots
    res_create = admin_client.post('/temporal/api/snapshots', json={
        'name': 'Sprint 42 Close',
        'snapshot_type': 'MILESTONE',
        'description': 'End of sprint snapshot'
    })
    assert res_create.status_code == 201
    json_create = res_create.get_json()
    assert json_create['success'] is True
    snap_id = json_create['snapshot']['snapshot_id']

    # 4. GET /temporal/api/snapshots
    res_list = admin_client.get('/temporal/api/snapshots')
    assert res_list.status_code == 200
    assert res_list.get_json()['count'] >= 1

    # 5. GET /temporal/api/snapshots/<id>
    res_get = admin_client.get(f'/temporal/api/snapshots/{snap_id}')
    assert res_get.status_code == 200
    assert res_get.get_json()['data']['snapshot_id'] == snap_id

    # 6. DELETE /temporal/api/snapshots/<id>
    res_del = admin_client.delete(f'/temporal/api/snapshots/{snap_id}')
    assert res_del.status_code == 200
    assert res_del.get_json()['success'] is True


def test_temporal_routes_viewer_forbidden(app, viewer_client):
    """Verify that Viewer role without data:write or data:delete is rejected with HTTP 403."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Temporal Alpha Corp').first()
        snap = TemporalService.create_snapshot(company_id=comp.id, name="Protected Snapshot")
        snap_id = snap.snapshot_id

    # Viewer cannot create snapshots
    res_post = viewer_client.post('/temporal/api/snapshots', json={
        'name': 'Unauthorized Snapshot'
    })
    assert res_post.status_code == 403

    # Viewer cannot delete snapshots
    res_del = viewer_client.delete(f'/temporal/api/snapshots/{snap_id}')
    assert res_del.status_code == 403


def test_temporal_snapshot_tenant_idor_forbidden(app, beta_client):
    """Verify that Tenant Beta cannot access or delete snapshots belonging to Tenant Alpha."""
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Temporal Alpha Corp').first()
        snap_a = TemporalService.create_snapshot(company_id=comp_a.id, name="Alpha Confidential Snap")
        snap_a_id = snap_a.snapshot_id

    # Beta attempts to get Alpha snapshot
    res_get = beta_client.get(f'/temporal/api/snapshots/{snap_a_id}')
    assert res_get.status_code == 404

    # Beta attempts to delete Alpha snapshot
    res_del = beta_client.delete(f'/temporal/api/snapshots/{snap_a_id}')
    assert res_del.status_code == 404
