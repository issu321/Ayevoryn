import re
import os
import pytest
from app import create_app
from database import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.employee import Employee


@pytest.fixture(scope="module")
def test_app():
    app = create_app()
    app.config["TESTING"] = True
    app.config["WTF_CSRF_ENABLED"] = False
    with app.app_context():
        yield app


@pytest.fixture
def auth_client(test_app):
    client = test_app.test_client()
    with test_app.app_context():
        company = Company.query.first()
        if not company:
            company = Company(company_name="Test Corp", currency="USD")
            db.session.add(company)
            db.session.commit()

        user = User.query.filter_by(company_id=company.id).first()
        if not user:
            user = User(username="testuser", email="test@corp.com", company_id=company.id, role="admin")
            user.set_password("password123")
            db.session.add(user)
            db.session.commit()

        with client.session_transaction() as sess:
            sess["_user_id"] = str(user.id)
            sess["user_id"] = user.id
            sess["company_id"] = company.id
            sess["company_currency"] = company.currency or "USD"
            sess["currency_symbol"] = "$"
    return client


class TestDepartmentsChartRendering:
    """Tests for Departments Twin charts, metrics, and empty states."""

    def test_01_departments_route_returns_ok_with_currency_symbol(self, auth_client):
        res = auth_client.get("/business-twin/departments")
        assert res.status_code == 200
        html = res.data.decode("utf-8")
        assert "headcountChart" in html
        assert "payrollChart" in html
        assert "const currencySymbol =" in html
        assert "initDepartmentCharts" in html

    def test_02_company_1_renders_guaranteed_charts_with_active_data(self, test_app, auth_client):
        with test_app.app_context():
            comp = Company.query.get(1)
            if comp:
                with auth_client.session_transaction() as sess:
                    sess["company_id"] = 1
                    sess["company_currency"] = comp.currency or "INR"

        res = auth_client.get("/business-twin/departments")
        assert res.status_code == 200
        html = res.data.decode("utf-8")
        assert "renderDeptChartsGuaranteed" in html
        assert "initDepartmentCharts" in html
        assert "Plotly.newPlot('headcountChart'" in html
        assert "Plotly.newPlot('payrollChart'" in html
        assert "* 0.70" not in html
        assert "headcountValues.map(() => 1)" not in html

    def test_03_populated_company_renders_plotly_data(self, test_app, auth_client):
        with test_app.app_context():
            comp2 = Company.query.get(2)
            if comp2:
                with auth_client.session_transaction() as sess:
                    sess["company_id"] = 2
                    sess["company_currency"] = comp2.currency or "INR"

        res = auth_client.get("/business-twin/departments")
        assert res.status_code == 200
        html = res.data.decode("utf-8")
        assert "IT" in html
        assert "Plotly.newPlot" in html
        assert "Monthly Payroll Allocation" in html

    def test_04_no_fragile_leader_line_dom_hacking(self, auth_client):
        res = auth_client.get("/business-twin/departments")
        html = res.data.decode("utf-8")
        assert "renderAllLeaderLines" not in html
        assert "textEl.getBBox()" not in html
        assert "slicePath.__data__.pxmid" not in html

    def test_05_departments_html_scripts_have_no_js_syntax_errors(self, auth_client):
        import subprocess, tempfile
        res = auth_client.get("/business-twin/departments")
        html = res.data.decode("utf-8")
        scripts = re.findall(r'<script(?:\s+[^>]*)?>([\s\S]*?)</script>', html, re.IGNORECASE)
        for s in scripts:
            if not s.strip():
                continue
            with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as f:
                f.write(s)
                tmp_name = f.name
            try:
                chk = subprocess.run(["node", "--check", tmp_name], capture_output=True, text=True)
                assert chk.returncode == 0, f"JS Syntax Error in script: {chk.stderr}"
            finally:
                if os.path.exists(tmp_name):
                    os.remove(tmp_name)


class TestGlobalLoaderArchitecture:
    """Tests for universal AevorynLoader, tiered containers, and safe interception."""

    def test_01_loader_containers_in_base_html(self, auth_client):
        res = auth_client.get("/dashboard")
        assert res.status_code == 200
        html = res.data.decode("utf-8")
        assert 'id="pageLoadingOverlay"' in html
        assert 'id="pageLoadingCancelBtn"' in html
        assert 'id="pageLoadingText"' in html
        assert 'id="aevorynTopProgress"' in html
        assert 'id="aevorynTopProgressText"' in html
        assert 'id="aevorynTaskCard"' in html
        assert 'id="aevorynTaskCardTitle"' in html
        assert 'id="aevorynTaskCardMsg"' in html

    def test_02_aevoryn_loader_script_and_api(self, auth_client):
        res = auth_client.get("/dashboard")
        html = res.data.decode("utf-8")
        assert "window.AevorynLoader" in html
        assert "activeTokens" in html
        assert "timeoutMap" in html
        assert "window.showPageLoading" in html
        assert "window.hidePageLoading" in html

    def test_03_smart_event_interceptor_respects_default_prevented(self, auth_client):
        res = auth_client.get("/dashboard")
        html = res.data.decode("utf-8")
        assert "if (e.defaultPrevented) return;" in html

    def test_04_download_and_export_links_excluded_from_full_screen_blur(self, auth_client):
        res = auth_client.get("/dashboard")
        html = res.data.decode("utf-8")
        assert "isDownloadOrExport" in html
        assert "Preparing download..." in html

    def test_05_price_simulation_template_integrates_cleanly(self, auth_client):
        res = auth_client.get("/simulation/price_increase")
        assert res.status_code == 200
        html = res.data.decode("utf-8")
        assert "window.AevorynLoader.start" in html
        assert "window.AevorynLoader.stop" in html
