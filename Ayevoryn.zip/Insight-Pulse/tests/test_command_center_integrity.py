"""
TEST SUITE: Stage 20 - Executive Command Center & "What Changed?" Event Delta Feed
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. Canonical state consumption (BusinessStateService integration, KPI accuracy, provenance).
2. "What Changed?" period-over-period metric variance calculations.
3. Chronological domain events delta stream and categorization.
4. Timeframe filtering (24h, 7d, 30d).
5. Comprehensive health check execution & COMMAND_CENTER_HEALTH_CHECKED domain event emission.
6. Notification management (mark-as-read) & NOTIFICATIONS_MARKED_READ domain event emission.
7. Multi-tenant IDOR protection and cross-tenant access rejection.
8. RBAC enforcement: Viewers can read dashboard & APIs, but receive 403 on mutation endpoints.
9. Elimination of obsolete/deceptive confidence badges in UI.
10. Backward compatibility with BusinessAgent executive briefings and recommendation callers.
"""

import pytest
import json
from datetime import datetime, timedelta, date
from database.db import db
from database.models.company import Company
from database.models.user import User
from security.rbac import Role
from database.models.financial import FinancialRecord
from database.models.customer import Customer
from database.models.employee import Employee
from database.models.inventory import Inventory
from database.models.notification import Notification
from database.models.business_event import BusinessEvent
from database.models.activity_log import ActivityLog
from services.business_agent import BusinessAgent
from services.business_state_service import BusinessStateService
from services.events import EventBus, EventTypes


def _clean_s20_data():
    db.session.remove()
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE business_name IN ('Stage20 Alpha Corp', 'Stage20 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] not in ('companies', 'sqlite_sequence')]
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's20_%' OR email LIKE 's20_%'")
        cursor.execute("PRAGMA foreign_keys = ON")
        conn.commit()
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def command_center_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users, financials, inventory, and events."""
    with app.app_context():
        _clean_s20_data()

        # Tenant Alpha
        comp_a = Company(
            company_name='Stage20 Alpha Corp',
            business_name='Stage20 Alpha Corp',
            owner_name='Alpha Executive Owner',
            ceo_name='Alpha CEO',
            industry='Technology',
            country='United States',
            annual_revenue=12000000.0,
            employee_count=45,
            currency='USD',
            health_score=75
        )
        db.session.add(comp_a)
        db.session.commit()

        user_admin_a = User(
            username='s20_admin_a',
            email='s20_admin_a@alpha.corp',
            role=Role.ADMIN,
            company_id=comp_a.id,
            first_name='Admin',
            last_name='Alpha'
        )
        user_admin_a.set_password('SecretPass123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s20_viewer_a',
            email='s20_viewer_a@alpha.corp',
            role=Role.VIEWER,
            company_id=comp_a.id,
            first_name='Viewer',
            last_name='Alpha'
        )
        user_viewer_a.set_password('SecretPass123!')
        db.session.add(user_viewer_a)

        # Tenant Beta
        comp_b = Company(
            company_name='Stage20 Beta Corp',
            business_name='Stage20 Beta Corp',
            owner_name='Beta Executive Owner',
            ceo_name='Beta CEO',
            industry='Consulting',
            country='United States',
            annual_revenue=3000000.0,
            employee_count=15,
            currency='USD',
            health_score=60
        )
        db.session.add(comp_b)
        db.session.commit()

        user_admin_b = User(
            username='s20_admin_b',
            email='s20_admin_b@beta.corp',
            role=Role.ADMIN,
            company_id=comp_b.id,
            first_name='Admin',
            last_name='Beta'
        )
        user_admin_b.set_password('SecretPass123!')
        db.session.add(user_admin_b)
        db.session.commit()

        # Seed Financials for Alpha: Current 30d vs Previous 30d
        now = datetime.utcnow()
        today = now.date()
        
        # Current 30d: $80,000 revenue, $50,000 expenses
        f1 = FinancialRecord(company_id=comp_a.id, transaction_type='revenue', amount=80000.0, transaction_date=today - timedelta(days=5), category='Product Sales')
        f2 = FinancialRecord(company_id=comp_a.id, transaction_type='expense', amount=50000.0, transaction_date=today - timedelta(days=7), category='Payroll')
        
        # Previous 30d (between 30d and 60d ago): $60,000 revenue, $45,000 expenses
        f3 = FinancialRecord(company_id=comp_a.id, transaction_type='revenue', amount=60000.0, transaction_date=today - timedelta(days=40), category='Product Sales')
        f4 = FinancialRecord(company_id=comp_a.id, transaction_type='expense', amount=45000.0, transaction_date=today - timedelta(days=42), category='Payroll')
        
        # Customers & Employees
        c1 = Customer(company_id=comp_a.id, company_name='Alpha Customer 1', first_name='Alpha', last_name='Client1', status='active', is_churned=False, lifetime_value=25000.0)
        c2 = Customer(company_id=comp_a.id, company_name='Alpha Customer 2', first_name='Alpha', last_name='Client2', status='active', is_churned=False, lifetime_value=15000.0)
        e1 = Employee(company_id=comp_a.id, first_name='John', last_name='Doe', email='john@alpha.corp', status='active', salary=120000.0)
        
        # Inventory
        inv1 = Inventory(company_id=comp_a.id, sku='SKU-001', name='Widget A', quantity_on_hand=100, unit_cost=25.0, reorder_point=10, is_active=True)
        
        # Unread notification
        notif = Notification(company_id=comp_a.id, user_id=user_admin_a.id, title='Initial Alert', message='Welcome to Command Center', is_read=False)

        # Business Events
        ev1 = BusinessEvent(
            company_id=comp_a.id,
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            aggregate_type='financial_record',
            aggregate_id='101',
            actor_id=user_admin_a.id,
            actor_name='Admin Alpha',
            payload_json=json.dumps({'amount': 80000.0, 'transaction_type': 'revenue'}),
            occurred_at=now - timedelta(hours=2)
        )
        ev2 = BusinessEvent(
            company_id=comp_a.id,
            event_type=EventTypes.COMPETITOR_CREATED,
            aggregate_type='competitor',
            aggregate_id='201',
            actor_id=user_admin_a.id,
            actor_name='Admin Alpha',
            payload_json=json.dumps({'name': 'Rival Tech Corp'}),
            occurred_at=now - timedelta(days=3)
        )
        ev3 = BusinessEvent(
            company_id=comp_a.id,
            event_type=EventTypes.RISK_TRIGGERED,
            aggregate_type='risk',
            aggregate_id='301',
            actor_id=user_admin_a.id,
            actor_name='Admin Alpha',
            payload_json=json.dumps({'risk_name': 'Supply Chain Bottleneck'}),
            occurred_at=now - timedelta(days=15)
        )

        db.session.add_all([f1, f2, f3, f4, c1, c2, e1, inv1, notif, ev1, ev2, ev3])
        db.session.commit()

        data = {
            'comp_a_id': comp_a.id,
            'comp_b_id': comp_b.id,
            'admin_a_id': user_admin_a.id,
            'viewer_a_id': user_viewer_a.id,
            'admin_b_id': user_admin_b.id,
        }

    yield data

    with app.app_context():
        _clean_s20_data()


def test_canonical_state_consumption(client, command_center_tenants):
    """
    Test 1: Verifies that the Executive Command Center consumes the authoritative
    canonical state from BusinessStateService, matching revenue, profit, cash, and provenance.
    """
    cid = command_center_tenants['comp_a_id']
    admin_id = command_center_tenants['admin_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = admin_id
        sess['_user_id'] = str(admin_id)
        sess['_fresh'] = True
        sess['company_id'] = cid
        sess['role'] = Role.ADMIN

    # 1. Fetch via BusinessAgent directly
    cc_data = BusinessAgent.get_command_center(cid)
    assert 'kpis' in cc_data
    assert 'provenance' in cc_data
    assert 'data_quality' in cc_data
    assert 'what_changed' in cc_data

    # Verify canonical values
    assert cc_data['kpis']['revenue_30d'] == 80000.0
    assert cc_data['kpis']['profit_30d'] == 30000.0  # 80k - 50k
    assert cc_data['kpis']['revenue_growth'] == 33.3  # (80k - 60k) / 60k * 100
    assert cc_data['kpis']['inventory_value'] == 2500.0  # 100 * $25
    assert cc_data['kpis']['total_employees'] == 1
    assert cc_data['kpis']['total_customers'] == 2

    # Verify provenance map exists
    assert 'revenue' in cc_data['provenance']
    assert cc_data['provenance']['revenue'] == 'OBSERVED'

    # 2. Fetch via API
    res = client.get('/command-center/api/command-center')
    assert res.status_code == 200
    api_data = res.get_json()
    assert api_data['kpis']['revenue_30d'] == 80000.0
    assert api_data['kpis']['revenue_growth'] == 33.3
    assert 'what_changed' in api_data


def test_what_changed_metric_deltas(command_center_tenants):
    """
    Test 2: Verifies that What Changed? metric variance calculations correctly compute
    period-over-period differences (Revenue, Expenses, Profit, Margin, Headcount, Churn).
    """
    cid = command_center_tenants['comp_a_id']
    what_changed = BusinessAgent.get_what_changed(cid, period='30d')

    assert what_changed['period'] == '30d'
    assert 'metric_deltas' in what_changed
    deltas = {d['metric']: d for d in what_changed['metric_deltas']}

    # Revenue: 80k current vs 60k previous -> +20k, +33.3%
    assert 'Revenue' in deltas
    assert deltas['Revenue']['current'] == 80000.0
    assert deltas['Revenue']['previous'] == 60000.0
    assert deltas['Revenue']['delta'] == 20000.0
    assert deltas['Revenue']['delta_pct'] == 33.3
    assert deltas['Revenue']['direction'] == 'positive'

    # Operating Expenses: 50k current vs 45k previous -> +5k (direction is negative since expense grew)
    assert 'Operating Expenses' in deltas
    assert deltas['Operating Expenses']['current'] == 50000.0
    assert deltas['Operating Expenses']['previous'] == 45000.0
    assert deltas['Operating Expenses']['delta'] == 5000.0
    assert deltas['Operating Expenses']['direction'] == 'negative'

    # Operating Profit: 30k current vs 15k previous -> +15k, +100.0%
    assert 'Operating Profit' in deltas
    assert deltas['Operating Profit']['current'] == 30000.0
    assert deltas['Operating Profit']['previous'] == 15000.0
    assert deltas['Operating Profit']['delta'] == 15000.0
    assert deltas['Operating Profit']['delta_pct'] == 100.0
    assert deltas['Operating Profit']['direction'] == 'positive'


def test_what_changed_business_events_feed(command_center_tenants):
    """
    Test 3: Verifies that domain events are retrieved in chronological order with
    proper categorization, title formatting, and actor attribution.
    """
    cid = command_center_tenants['comp_a_id']
    what_changed = BusinessAgent.get_what_changed(cid, period='30d', limit=10)

    events = what_changed['events']
    assert len(events) >= 3

    # Event 1: Financial Transaction (2 hours ago)
    ev_fin = next((e for e in events if e['event_type'] == EventTypes.FINANCIAL_TRANSACTION_CREATED), None)
    assert ev_fin is not None
    assert ev_fin['category'] == 'Finance'
    assert 'Financial Revenue: $80,000.00' in ev_fin['title']
    assert ev_fin['actor_name'] == 'Admin Alpha'

    # Event 2: Competitor Tracked (3 days ago)
    ev_comp = next((e for e in events if e['event_type'] == EventTypes.COMPETITOR_CREATED), None)
    assert ev_comp is not None
    assert ev_comp['category'] == 'Market Intelligence'
    assert 'Competitor tracked: Rival Tech Corp' in ev_comp['title']

    # Event 3: Risk Triggered (15 days ago)
    ev_risk = next((e for e in events if e['event_type'] == EventTypes.RISK_TRIGGERED), None)
    assert ev_risk is not None
    assert ev_risk['category'] == 'Risk & Governance'
    assert 'Risk triggered: Supply Chain Bottleneck' in ev_risk['title']


def test_what_changed_timeframe_filtering(client, command_center_tenants):
    """
    Test 4: Verifies that timeframe query parameters (24h, 7d, 30d) strictly filter
    the returned business events based on occurred_at timestamp.
    """
    cid = command_center_tenants['comp_a_id']
    admin_id = command_center_tenants['admin_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = admin_id
        sess['_user_id'] = str(admin_id)
        sess['_fresh'] = True
        sess['company_id'] = cid
        sess['role'] = Role.ADMIN

    # 1. Period = 24h: only the 2-hour-old financial event should qualify
    res_24h = client.get('/command-center/api/what-changed?period=24h')
    assert res_24h.status_code == 200
    data_24h = res_24h.get_json()
    assert data_24h['period'] == '24h'
    # Exactly 1 event happened in last 24h
    event_types_24h = [e['event_type'] for e in data_24h['events']]
    assert EventTypes.FINANCIAL_TRANSACTION_CREATED in event_types_24h
    assert EventTypes.RISK_TRIGGERED not in event_types_24h

    # 2. Period = 7d: financial (2h) and competitor (3d) qualify; risk (15d) does not
    res_7d = client.get('/command-center/api/what-changed?period=7d')
    assert res_7d.status_code == 200
    data_7d = res_7d.get_json()
    assert data_7d['period'] == '7d'
    event_types_7d = [e['event_type'] for e in data_7d['events']]
    assert EventTypes.FINANCIAL_TRANSACTION_CREATED in event_types_7d
    assert EventTypes.COMPETITOR_CREATED in event_types_7d
    assert EventTypes.RISK_TRIGGERED not in event_types_7d

    # 3. Period = 30d: all 3 events qualify
    res_30d = client.get('/command-center/api/what-changed?period=30d')
    assert res_30d.status_code == 200
    data_30d = res_30d.get_json()
    assert data_30d['period'] == '30d'
    assert len(data_30d['events']) >= 3


def test_health_check_execution_and_domain_event(client, command_center_tenants):
    """
    Test 5: Verifies that running an executive health check re-evaluates company metrics,
    creates notifications, updates company health score, and emits COMMAND_CENTER_HEALTH_CHECKED.
    """
    cid = command_center_tenants['comp_a_id']
    admin_id = command_center_tenants['admin_a_id']

    events_captured = []
    def on_health_checked(event):
        events_captured.append(event)

    EventBus.subscribe(EventTypes.COMMAND_CENTER_HEALTH_CHECKED, on_health_checked)

    with client.session_transaction() as sess:
        sess['user_id'] = admin_id
        sess['_user_id'] = str(admin_id)
        sess['_fresh'] = True
        sess['company_id'] = cid
        sess['role'] = Role.ADMIN

    res = client.post('/command-center/api/health-check')
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert 'health_score' in data
    assert data['health_score'] > 0

    # Verify domain event emitted
    assert any(e.event_type == EventTypes.COMMAND_CENTER_HEALTH_CHECKED and e.company_id == cid for e in events_captured)

    # Verify activity log recorded
    act = ActivityLog.query.filter_by(company_id=cid, activity_type='command_center.health_check').first()
    assert act is not None
    assert 'Executive Health Check' in act.description


def test_notifications_mark_read(client, command_center_tenants):
    """
    Test 6: Verifies that marking notifications as read updates notification status
    and publishes the NOTIFICATIONS_MARKED_READ domain event.
    """
    cid = command_center_tenants['comp_a_id']
    admin_id = command_center_tenants['admin_a_id']

    events_captured = []
    def on_marked_read(event):
        events_captured.append(event)

    EventBus.subscribe(EventTypes.NOTIFICATIONS_MARKED_READ, on_marked_read)

    with client.session_transaction() as sess:
        sess['user_id'] = admin_id
        sess['_user_id'] = str(admin_id)
        sess['_fresh'] = True
        sess['company_id'] = cid
        sess['role'] = Role.ADMIN

    # Confirm initial unread notification exists
    unread_before = Notification.query.filter_by(company_id=cid, user_id=admin_id, is_read=False).count()
    assert unread_before >= 1

    res = client.post('/command-center/api/notifications/mark-read')
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert data['marked_count'] >= 1

    # Confirm notifications are now marked read
    unread_after = Notification.query.filter_by(company_id=cid, user_id=admin_id, is_read=False).count()
    assert unread_after == 0

    # Confirm domain event emitted
    assert any(e.event_type == EventTypes.NOTIFICATIONS_MARKED_READ and e.company_id == cid for e in events_captured)


def test_command_center_tenant_isolation_idor(client, command_center_tenants):
    """
    Test 7: Verifies multi-tenant isolation: Tenant B cannot access or mutate Tenant A's
    command center data or execute cross-tenant health checks.
    """
    comp_a_id = command_center_tenants['comp_a_id']
    comp_b_id = command_center_tenants['comp_b_id']
    admin_b_id = command_center_tenants['admin_b_id']

    # Authenticate as Tenant B Admin
    with client.session_transaction() as sess:
        sess['user_id'] = admin_b_id
        sess['_user_id'] = str(admin_b_id)
        sess['_fresh'] = True
        sess['company_id'] = comp_b_id
        sess['role'] = Role.ADMIN

    # 1. API command center should only return Tenant B data
    res = client.get('/command-center/api/command-center')
    assert res.status_code == 200
    data = res.get_json()
    # Tenant B has 0 financial records, so revenue_30d must be 0, not Alpha's 80,000
    assert data['kpis']['revenue_30d'] == 0.0

    # 2. What Changed? should not contain Tenant A's events
    res_wc = client.get('/command-center/api/what-changed')
    assert res_wc.status_code == 200
    wc_data = res_wc.get_json()
    event_titles = [e['title'] for e in wc_data['events']]
    assert not any('Rival Tech Corp' in t for t in event_titles)


def test_viewer_rbac_rejection_on_mutations(client, command_center_tenants):
    """
    Test 8: Verifies RBAC authorization: Users with VIEWER role can access the Command Center
    dashboard and read APIs, but receive HTTP 403 Forbidden on mutation endpoints.
    """
    cid = command_center_tenants['comp_a_id']
    viewer_id = command_center_tenants['viewer_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = viewer_id
        sess['_user_id'] = str(viewer_id)
        sess['_fresh'] = True
        sess['company_id'] = cid
        sess['role'] = Role.VIEWER

    # 1. Read endpoints should succeed with 200
    assert client.get('/command-center/').status_code == 200
    assert client.get('/command-center/api/command-center').status_code == 200
    assert client.get('/command-center/api/what-changed').status_code == 200
    assert client.get('/command-center/api/agent-status').status_code == 200
    assert client.get('/command-center/api/briefing/daily').status_code == 200
    assert client.get('/command-center/api/recommendations').status_code == 200
    assert client.get('/command-center/api/notifications').status_code == 200

    # 2. Mutation endpoints must be rejected with 403 Forbidden
    res_hc = client.post('/command-center/api/health-check')
    assert res_hc.status_code == 403

    res_mr = client.post('/command-center/api/notifications/mark-read')
    assert res_mr.status_code == 403


def test_elimination_of_deceptive_confidence_badges(client, command_center_tenants):
    """
    Test 9: Verifies that neither rendered HTML nor API payloads output deceptive
    mock confidence percentages like "None% confidence" or hardcoded integers (92, 88, 95).
    """
    cid = command_center_tenants['comp_a_id']
    admin_id = command_center_tenants['admin_a_id']

    with client.session_transaction() as sess:
        sess['user_id'] = admin_id
        sess['_user_id'] = str(admin_id)
        sess['_fresh'] = True
        sess['company_id'] = cid
        sess['role'] = Role.ADMIN

    res = client.get('/command-center/')
    assert res.status_code == 200
    html = res.get_data(as_text=True)

    # Must NOT contain obsolete or broken confidence patterns
    assert 'None% confidence' not in html
    assert '92% confidence' not in html
    assert '88% confidence' not in html
    assert '95% confidence' not in html

    # Must contain honest provenance tags
    assert 'OBSERVED' in html or 'PROVENANCE' in html.upper()
    assert 'What Changed?' in html


def test_business_agent_briefing_and_recommendations(command_center_tenants):
    """
    Test 10: Verifies that executive briefings and business recommendations execute cleanly,
    incorporate canonical metrics, and maintain full backward compatibility.
    """
    cid = command_center_tenants['comp_a_id']

    # 1. Executive Briefing
    briefing = BusinessAgent.generate_executive_briefing(cid, period='daily')
    assert briefing is not None
    assert 'headline' in briefing
    assert 'summary' in briefing
    assert 'highlights' in briefing
    assert 'kpis' in briefing
    assert 'what_changed' in briefing
    assert briefing['kpis']['revenue_30d'] == 80000.0

    # 2. Business Recommendations
    recs = BusinessAgent.get_recommendations(cid)
    assert isinstance(recs, list)
    assert len(recs) >= 1
    for r in recs:
        assert 'category' in r
        assert 'title' in r
        assert 'description' in r
        assert 'action' in r
