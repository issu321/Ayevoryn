"""
Unit and integration tests for BusinessStateService (Stage 5 - Canonical Business State).
Verifies:
1. MetricResult serialization, properties, and provenance classification.
2. Trailing revenue, expense, profit, and margin resolution with OBSERVED vs DECLARED provenance.
3. Strict cash balance hierarchical resolution (FinancialAccount -> total_equity -> 0.0).
4. Mathematical burn rate and runway calculation (net vs gross, profitable states).
5. Headcount and customer metrics provenance integrity.
6. Canonical state parity across metrics and flat summary.
"""

import pytest
from datetime import datetime, date, timedelta
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.employee import Employee
from database.models.customer import Customer
from database.models.department import Department
from services.business_state_service import BusinessStateService, MetricResult, ProvenanceType


@pytest.fixture
def test_app():
    """Create a dedicated test application context."""
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    return app


@pytest.fixture
def sample_company(test_app):
    """Create a sample company with known parameters for testing."""
    with test_app.app_context():
        company = Company(
            company_name="Test Canonical Corp",
            business_name="Test Canonical Corp",
            owner_name="Test Owner",
            ceo_name="Test CEO",
            industry="Software",
            currency="USD",
            annual_revenue=1200000.0,
            employee_count=20,
            customer_count=50,
            total_equity=100000.0
        )
        db.session.add(company)
        db.session.commit()
        cid = company.id

        yield cid

        # Cleanup
        FinancialRecord.query.filter_by(company_id=cid).delete()
        FinancialAccount.query.filter_by(company_id=cid).delete()
        Employee.query.filter_by(company_id=cid).delete()
        Customer.query.filter_by(company_id=cid).delete()
        Department.query.filter_by(company_id=cid).delete()
        Company.query.filter_by(id=cid).delete()
        db.session.commit()


def test_metric_result_serialization_and_properties():
    """Test MetricResult properties and JSON serialization."""
    mr = MetricResult(
        name="test_metric",
        value=42.5,
        unit="USD",
        provenance=ProvenanceType.OBSERVED,
        source_description="Test observed metric",
        confidence=1.0,
        is_synthetic=False,
        metadata={"detail": "sample"}
    )
    assert mr.is_observed is True
    assert mr.is_declared is False
    
    serialized = mr.to_dict()
    assert serialized['name'] == "test_metric"
    assert serialized['value'] == 42.5
    assert serialized['unit'] == "USD"
    assert serialized['provenance'] == "OBSERVED"
    assert serialized['confidence'] == 1.0
    assert serialized['metadata']['detail'] == "sample"


def test_observed_revenue_and_expense_provenance(test_app, sample_company):
    """Test that ledger records produce OBSERVED metrics with accurate sums and confidence."""
    with test_app.app_context():
        cid = sample_company
        today = datetime.utcnow().date()

        # Add 3 revenue records ($30,000 total) and 2 expense records ($10,000 total)
        r1 = FinancialRecord(company_id=cid, transaction_type='revenue', amount=10000.0, transaction_date=today - timedelta(days=5))
        r2 = FinancialRecord(company_id=cid, transaction_type='revenue', amount=15000.0, transaction_date=today - timedelta(days=10))
        r3 = FinancialRecord(company_id=cid, transaction_type='revenue', amount=5000.0, transaction_date=today - timedelta(days=20))
        e1 = FinancialRecord(company_id=cid, transaction_type='expense', amount=6000.0, transaction_date=today - timedelta(days=2))
        e2 = FinancialRecord(company_id=cid, transaction_type='expense', amount=4000.0, transaction_date=today - timedelta(days=15))
        
        db.session.add_all([r1, r2, r3, e1, e2])
        db.session.commit()

        rev = BusinessStateService.get_revenue(cid, 30)
        assert rev.provenance == ProvenanceType.OBSERVED
        assert rev.value == 30000.0
        assert rev.confidence == 1.0
        assert rev.metadata['record_count'] == 3

        exp = BusinessStateService.get_expenses(cid, 30)
        assert exp.provenance == ProvenanceType.OBSERVED
        assert exp.value == 10000.0
        assert exp.confidence == 1.0
        assert exp.metadata['record_count'] == 2

        profit = BusinessStateService.get_profit(cid, 30)
        assert profit.provenance == ProvenanceType.OBSERVED
        assert profit.value == 20000.0

        margin = BusinessStateService.get_gross_margin(cid, 30)
        assert margin.value == pytest.approx(66.67, 0.01)
        assert margin.unit == "%"


def test_declared_revenue_when_no_transactions(test_app, sample_company):
    """When zero ledger records exist, declared annual target is reported as target context, not fake revenue."""
    with test_app.app_context():
        cid = sample_company
        # No FinancialRecord inserted

        rev = BusinessStateService.get_revenue(cid, 30)
        assert rev.value == 0.0
        assert rev.provenance == ProvenanceType.DECLARED
        assert rev.metadata['annual_target'] == 1200000.0
        assert rev.metadata['record_count'] == 0


def test_cash_balance_provenance_hierarchy(test_app, sample_company):
    """Verifies cash balance hierarchical resolution: FinancialAccount -> total_equity -> 0.0."""
    with test_app.app_context():
        cid = sample_company

        # Step 1: No accounts, but company has total_equity = 100000.0 -> DECLARED
        cash1 = BusinessStateService.get_cash_balance(cid)
        assert cash1.provenance == ProvenanceType.DECLARED
        assert cash1.value == 100000.0
        assert cash1.confidence == 0.80

        # Step 2: Add actual cash account ($75,000) -> OBSERVED overrides DECLARED
        acc = FinancialAccount(
            company_id=cid,
            account_name="Primary Operating Checking",
            account_type="cash",
            current_balance=75000.0,
            is_active=True
        )
        db.session.add(acc)
        db.session.commit()

        cash2 = BusinessStateService.get_cash_balance(cid)
        assert cash2.provenance == ProvenanceType.OBSERVED
        assert cash2.value == 75000.0
        assert cash2.confidence == 1.0
        assert cash2.metadata['account_count'] == 1

        # Step 3: Deactivate account and reset total_equity to 0 -> explicit zero cash
        acc.is_active = False
        comp = Company.query.get(cid)
        comp.total_equity = 0.0
        db.session.commit()

        cash3 = BusinessStateService.get_cash_balance(cid)
        assert cash3.provenance == ProvenanceType.OBSERVED
        assert cash3.value == 0.0


def test_burn_rate_and_runway_calculation(test_app, sample_company):
    """
    Verifies burn rate and runway calculation:
    - Expenses: $30,000 / month, Revenue: $10,000 / month
    - Net monthly burn: $20,000 / month
    - Cash balance: $60,000
    - Net runway: $60,000 / $20,000 = 3.0 months (NOT 90 months as the 30x bug would report!)
    """
    with test_app.app_context():
        cid = sample_company
        today = datetime.utcnow().date()

        # Set cash balance to $60,000 via account
        acc = FinancialAccount(company_id=cid, account_name="Treasury", account_type="bank", current_balance=60000.0, is_active=True)
        # Revenue $10,000, Expense $30,000 over 30 days
        r = FinancialRecord(company_id=cid, transaction_type='revenue', amount=10000.0, transaction_date=today - timedelta(days=10))
        e = FinancialRecord(company_id=cid, transaction_type='expense', amount=30000.0, transaction_date=today - timedelta(days=10))
        db.session.add_all([acc, r, e])
        db.session.commit()

        burn = BusinessStateService.get_burn_rate(cid, 30)
        assert burn.metadata['gross_monthly_burn'] == 30000.0
        assert burn.metadata['net_monthly_burn'] == 20000.0
        assert burn.metadata['is_burning'] is True

        # Net runway
        net_runway = BusinessStateService.get_runway(cid, 30, burn_type='net')
        assert net_runway.value == 3.0
        assert net_runway.metadata['is_sustainable'] is False
        assert net_runway.metadata['status'] == 'burning'

        # Gross runway
        gross_runway = BusinessStateService.get_runway(cid, 30, burn_type='gross')
        assert gross_runway.value == 2.0  # 60,000 / 30,000 = 2.0 months


def test_profitable_runway_returns_self_sustaining(test_app, sample_company):
    """When revenue >= expenses, net runway must return None with self-sustaining status (NOT hardcoded 99.0)."""
    with test_app.app_context():
        cid = sample_company
        today = datetime.utcnow().date()

        # Set cash balance to $50,000
        acc = FinancialAccount(company_id=cid, account_name="Treasury", account_type="bank", current_balance=50000.0, is_active=True)
        # Revenue $40,000, Expense $25,000 (Profitable)
        r = FinancialRecord(company_id=cid, transaction_type='revenue', amount=40000.0, transaction_date=today - timedelta(days=10))
        e = FinancialRecord(company_id=cid, transaction_type='expense', amount=25000.0, transaction_date=today - timedelta(days=10))
        db.session.add_all([acc, r, e])
        db.session.commit()

        runway = BusinessStateService.get_runway(cid, 30, burn_type='net')
        assert runway.value is None  # Indefinite / self-sustaining
        assert runway.metadata['is_sustainable'] is True
        assert runway.metadata['status'] == 'self_sustaining'
        assert runway.metadata['display'] == 'Self-Sustaining'


def test_canonical_state_full_parity(test_app, sample_company):
    """Verifies that get_canonical_state provides both rich MetricResult objects and complete flat summary dict."""
    with test_app.app_context():
        cid = sample_company
        
        # Add 2 employees and 1 customer
        emp1 = Employee(company_id=cid, first_name="Alice", last_name="Engineer", status="active", salary=120000.0)
        emp2 = Employee(company_id=cid, first_name="Bob", last_name="Architect", status="active", salary=140000.0)
        cust1 = Customer(company_id=cid, first_name="Enterprise", company_name="Acme Corp", status="active", lifetime_value=5000.0, acquisition_cost=500.0)
        db.session.add_all([emp1, emp2, cust1])
        db.session.commit()

        canonical = BusinessStateService.get_canonical_state(cid, 30)

        # 1. Rich metrics dictionary
        metrics = canonical['metrics']
        assert 'revenue' in metrics
        assert 'expenses' in metrics
        assert 'profit' in metrics
        assert 'margin' in metrics
        assert 'cash_balance' in metrics
        assert 'burn_rate' in metrics
        assert 'runway' in metrics
        assert 'headcount' in metrics
        assert 'active_customers' in metrics
        assert metrics['headcount'].value == 2
        assert metrics['headcount'].provenance == ProvenanceType.OBSERVED

        # 2. Flat summary dictionary
        summary = canonical['summary']
        expected_keys = [
            'revenue_30d', 'expense_30d', 'profit_30d', 'margin', 'total_employees',
            'cash_balance', 'monthly_burn', 'runway_months', 'health_score',
            'data_quality', 'provenance', 'setup_progress_pct', 'financial_complete'
        ]
        for key in expected_keys:
            assert key in summary, f"Expected key '{key}' missing from canonical summary"

        assert summary['total_employees'] == 2
        assert summary['total_customers'] == 1
        assert summary['provenance']['headcount'] == "OBSERVED"
