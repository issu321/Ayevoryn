"""
AEVORYN / INSIGHT-PULSE
STAGE 3: AUTHENTICATION & AUTHORIZATION HARDENING TEST SUITE
Verifies:
1. Security answer hashing, salting, verification, and legacy upgrade.
2. Account recovery rate limiting and security answer challenge verification.
3. Password rotation requiring current password verification.
4. RBAC role decorators, admin_required, and endpoint protection.
5. RBAC role hierarchy and permission checking helpers.
"""

import pytest
from database.db import db
from database.models.user import User, hash_security_answer
from database.models.company import Company
from services.auth_service import AuthService
from security.rate_limiter import limiter
from security.rbac import Role, Permission, has_role, has_permission


@pytest.fixture
def auth_fixture(app):
    """Setup dedicated test users for authentication and authorization tests."""
    with app.app_context():
        comp = Company.query.filter_by(company_name="Auth Hardening Corp").first()
        if not comp:
            comp = Company(
                company_name="Auth Hardening Corp",
                business_name="Auth Corp",
                owner_name="Auth Owner",
                ceo_name="Auth Owner",
                currency="USD",
                is_active=True
            )
            db.session.add(comp)
            db.session.commit()

        # Admin User
        admin = User.query.filter_by(username="auth_admin_user").first()
        if not admin:
            admin = User(
                username="auth_admin_user",
                email="admin@authcorp.test",
                role="Admin",
                is_admin=True,
                company_id=comp.id,
                security_question_1="Primary challenge?",
                security_question_2="Secondary challenge?"
            )
            admin.set_password("AdminSecurePass123!")
            admin.set_security_answer(1, "FirstAdminAnswer")
            admin.set_security_answer(2, "SecondAdminAnswer")
            db.session.add(admin)

        # Analyst User (Non-admin)
        analyst = User.query.filter_by(username="auth_analyst_user").first()
        if not analyst:
            analyst = User(
                username="auth_analyst_user",
                email="analyst@authcorp.test",
                role="Analyst",
                is_admin=False,
                company_id=comp.id,
                security_question_1="Favorite food?",
                security_question_2="First pet?"
            )
            analyst.set_password("AnalystPass123!")
            analyst.set_security_answer(1, "Pizza")
            analyst.set_security_answer(2, "Rover")
            db.session.add(analyst)

        # Viewer User
        viewer = User.query.filter_by(username="auth_viewer_user").first()
        if not viewer:
            viewer = User(
                username="auth_viewer_user",
                email="viewer@authcorp.test",
                role="Viewer",
                is_admin=False,
                company_id=comp.id
            )
            viewer.set_password("ViewerPass123!")
            db.session.add(viewer)

        db.session.commit()

        return {
            'company_id': comp.id,
            'admin_id': admin.id,
            'analyst_id': analyst.id,
            'viewer_id': viewer.id
        }


def test_security_answer_hashing_and_verification(app, auth_fixture):
    """Verify security answers are stored as irreversible SHA-256 salted hashes, not plaintext."""
    with app.app_context():
        user = User.query.get(auth_fixture['analyst_id'])
        
        # Must NOT be stored in plaintext
        assert user.security_answer_1 != "Pizza"
        assert user.security_answer_1.startswith("sha256$")
        assert len(user.security_answer_1) == 7 + 64

        # Verification must succeed with correct answer (case-insensitive & trimmed)
        assert user.verify_security_answer(1, "Pizza") is True
        assert user.verify_security_answer(1, "  pizza  ") is True
        assert user.verify_security_answer(1, "PIZZA") is True

        # Verification must fail with incorrect answer
        assert user.verify_security_answer(1, "Burger") is False
        assert user.verify_security_answer(1, "") is False


def test_legacy_security_answer_auto_upgrade(app, auth_fixture):
    """Verify existing plaintext security answers from older databases auto-upgrade on verification."""
    with app.app_context():
        user = User.query.get(auth_fixture['analyst_id'])
        
        # Inject raw plaintext directly into database column via raw SQL to simulate legacy state
        db.session.execute(
            db.text("UPDATE users SET security_answer_3 = 'legacy_secret' WHERE id = :uid"),
            {'uid': user.id}
        )
        db.session.commit()

        # Reload user
        db.session.expire_all()
        reloaded = User.query.get(user.id)
        assert reloaded.security_answer_3 == "legacy_secret"

        # Verify should succeed AND transparently upgrade stored value to sha256$
        assert reloaded.verify_security_answer(3, "legacy_secret") is True
        
        # Verify it has been upgraded in memory and in DB
        db.session.expire_all()
        upgraded = User.query.get(user.id)
        assert upgraded.security_answer_3.startswith("sha256$")
        assert upgraded.security_answer_3 != "legacy_secret"
        assert upgraded.verify_security_answer(3, "legacy_secret") is True


def test_password_recovery_with_security_answers(app, auth_fixture):
    """Verify self-service password recovery succeeds with correct challenges and fails with incorrect."""
    with app.app_context():
        user = User.query.get(auth_fixture['analyst_id'])
        limiter.reset(f"recovery:{user.username.lower()}")

        # Incorrect challenge answer 1
        ok, msg = AuthService.reset_password_with_security_answers(
            user.username, "WrongFood", "Rover", "NewSecretPass456!"
        )
        assert ok is False
        assert "answer 1 is incorrect" in msg

        # Incorrect challenge answer 2
        ok, msg = AuthService.reset_password_with_security_answers(
            user.username, "Pizza", "WrongPet", "NewSecretPass456!"
        )
        assert ok is False
        assert "answer 2 is incorrect" in msg

        # Password too short
        ok, msg = AuthService.reset_password_with_security_answers(
            user.username, "Pizza", "Rover", "123"
        )
        assert ok is False
        assert "at least 6 characters" in msg

        # Successful recovery
        ok, msg = AuthService.reset_password_with_security_answers(
            user.username, "Pizza", "Rover", "NewValidSecretPass789!"
        )
        assert ok is True
        assert "successfully updated" in msg

        # Verify new password actually works
        db.session.expire_all()
        updated = User.query.get(user.id)
        assert updated.check_password("NewValidSecretPass789!") is True
        assert updated.check_password("AnalystPass123!") is False

        # Reset password back so subsequent tests are isolated
        updated.set_password("AnalystPass123!")
        db.session.commit()


def test_password_recovery_rate_limiting(app, auth_fixture):
    """Verify brute-forcing security challenge answers is blocked after 5 attempts."""
    with app.app_context():
        user = User.query.get(auth_fixture['analyst_id'])
        rate_key = f"recovery:{user.username.lower()}"
        limiter.reset(rate_key)

        # 5 failed attempts
        for i in range(5):
            ok, msg = AuthService.reset_password_with_security_answers(
                user.username, f"BadGuess_{i}", "BadPet", "BrandNewPass999!"
            )
            assert ok is False

        # 6th attempt must be blocked by rate limiter even if answers were correct
        ok, msg = AuthService.reset_password_with_security_answers(
            user.username, "Pizza", "Rover", "BrandNewPass999!"
        )
        assert ok is False
        assert "Too many recovery attempts" in msg


def test_password_rotation_requires_current_password(client, app, auth_fixture):
    """Verify profile password change requires and validates current_password."""
    # Authenticate as Analyst
    login_resp = client.post('/login', data={
        'username': 'auth_analyst_user',
        'password': 'AnalystPass123!'
    }, follow_redirects=True)
    assert login_resp.status_code == 200

    # 1. Attempt password change without current_password
    resp = client.post('/settings/profile', data={
        'first_name': 'Analyst',
        'last_name': 'Tester',
        'email': 'analyst@authcorp.test',
        'current_password': '',
        'new_password': 'BrandNewPassword123!',
        'confirm_password': 'BrandNewPassword123!'
    }, follow_redirects=True)
    assert resp.status_code == 200
    assert b"Current password is required" in resp.data

    with app.app_context():
        u = User.query.get(auth_fixture['analyst_id'])
        assert u.check_password("BrandNewPassword123!") is False

    # 2. Attempt password change with incorrect current_password
    resp = client.post('/settings/profile', data={
        'first_name': 'Analyst',
        'last_name': 'Tester',
        'email': 'analyst@authcorp.test',
        'current_password': 'IncorrectCurrentPassword!',
        'new_password': 'BrandNewPassword123!',
        'confirm_password': 'BrandNewPassword123!'
    }, follow_redirects=True)
    assert resp.status_code == 200
    assert b"Current password verification failed" in resp.data

    # 3. Successful password change with correct current_password
    resp = client.post('/settings/profile', data={
        'first_name': 'Analyst',
        'last_name': 'Tester',
        'email': 'analyst@authcorp.test',
        'current_password': 'AnalystPass123!',
        'new_password': 'RotatedPassword456!',
        'confirm_password': 'RotatedPassword456!'
    }, follow_redirects=True)
    assert resp.status_code == 200
    assert b"Password updated successfully" in resp.data

    with app.app_context():
        u = User.query.get(auth_fixture['analyst_id'])
        assert u.check_password("RotatedPassword456!") is True
        u.set_password("AnalystPass123!")
        db.session.commit()


def test_rbac_route_enforcement(client, app, auth_fixture):
    """Verify non-admin roles are forbidden from accessing admin routes."""
    # 1. Login as Analyst (Non-admin)
    login_resp = client.post('/login', data={
        'username': 'auth_analyst_user',
        'password': 'AnalystPass123!'
    }, follow_redirects=True)
    assert login_resp.status_code == 200

    # 2. Analyst attempting to update company settings -> 403 Forbidden
    resp = client.post('/settings/company', data={
        'company_name': 'Hacked Company Name',
        'currency': 'EUR'
    })
    assert resp.status_code == 403

    # 3. Logout
    client.get('/logout', follow_redirects=True)

    # 4. Login as Admin
    client.post('/login', data={
        'username': 'auth_admin_user',
        'password': 'AdminSecurePass123!'
    }, follow_redirects=True)

    # 5. Admin updating company settings -> 302 Redirect (allowed)
    resp = client.post('/settings/company', data={
        'company_name': 'Auth Hardening Corp',
        'currency': 'USD'
    })
    assert resp.status_code in (200, 302)


def test_rbac_roles_and_permissions_matrix(app, auth_fixture):
    """Verify RBAC role hierarchy and permission checks."""
    with app.app_context():
        admin = User.query.get(auth_fixture['admin_id'])
        analyst = User.query.get(auth_fixture['analyst_id'])
        viewer = User.query.get(auth_fixture['viewer_id'])

        # Admin
        assert has_role(admin, Role.ADMIN) is True
        assert has_role(admin, 'Admin') is True
        assert has_permission(admin, Permission.MANAGE_USERS) is True
        assert has_permission(admin, Permission.RUN_SIMULATION) is True

        # Analyst
        assert has_role(analyst, Role.ANALYST) is True
        assert has_role(analyst, Role.ADMIN) is False
        assert has_permission(analyst, Permission.MANAGE_USERS) is False
        assert has_permission(analyst, Permission.RUN_SIMULATION) is True
        assert has_permission(analyst, Permission.VIEW_DASHBOARD) is True

        # Viewer
        assert has_role(viewer, Role.VIEWER) is True
        assert has_role(viewer, Role.ANALYST) is False
        assert has_permission(viewer, Permission.RUN_SIMULATION) is False
        assert has_permission(viewer, Permission.VIEW_DASHBOARD) is True
