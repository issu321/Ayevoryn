"""
TEST SUITE: Stage 23 - Background Job Foundation & Worker Pool
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. BackgroundJob model serialization, UUID generation, duration tracking, JSON payload/result.
2. Synchronous & Asynchronous execution of registered background jobs.
3. Progress callback telemetry and status transition mechanics.
4. Job cancellation handling for pending and running jobs.
5. Error capture, traceback logging, and failure status handling.
6. EventBus lifecycle notifications (JOB_ENQUEUED, JOB_STARTED, JOB_PROGRESS, JOB_COMPLETED, JOB_FAILED, JOB_CANCELLED).
7. Strict multi-tenant isolation (preventing cross-tenant job access or cancellation).
8. API v1 background job management endpoints (/api/v1/jobs CRUD, filtering, cancellation, types).
9. Web interface endpoints (/jobs/ dashboard, real-time status polling /jobs/api/status/<id>).
"""

import pytest
import time
from datetime import datetime
from unittest.mock import MagicMock

from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.job import BackgroundJob
from database.models.api_key import ApiKey
from security.rbac import Role, Permission
from services.events import EventBus, DomainEvent, EventTypes
from services.job_service import JobService, JobCancelledException


def _clean_s23_data():
    """Wipe any pre-existing stage 23 test data cleanly."""
    db.session.remove()
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE company_name IN ('Stage23 Alpha Corp', 'Stage23 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute(f"DELETE FROM background_jobs WHERE company_id IN ({ids_str})")
            cursor.execute(f"DELETE FROM api_keys WHERE company_id IN ({ids_str})")
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's23_%' OR email LIKE 's23_%'")
        cursor.execute("PRAGMA foreign_keys = ON")
        conn.commit()
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def job_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users and API keys."""
    with app.app_context():
        JobService.init_app(app)
        db.create_all()
        _clean_s23_data()

        # Tenant Alpha
        comp_a = Company(
            company_name='Stage23 Alpha Corp',
            business_name='Stage23 Alpha Corp',
            owner_name='Alpha Jobs Owner',
            ceo_name='Alpha CEO',
            industry='Technology',
            country='United States',
            currency='USD'
        )
        db.session.add(comp_a)
        db.session.commit()

        user_admin_a = User(
            username='s23_admin_a',
            email='s23_admin_a@alpha.corp',
            role=Role.ADMIN,
            is_admin=True,
            company_id=comp_a.id,
            first_name='Admin',
            last_name='Alpha'
        )
        user_admin_a.set_password('SecretPass123!')
        db.session.add(user_admin_a)
        db.session.commit()

        key_admin_a, raw_admin_key_a = ApiKey.generate(
            company_id=comp_a.id,
            user_id=user_admin_a.id,
            name='Alpha Admin Key',
            role=Role.ADMIN
        )
        db.session.add(key_admin_a)
        db.session.commit()

        # Tenant Beta
        comp_b = Company(
            company_name='Stage23 Beta Corp',
            business_name='Stage23 Beta Corp',
            owner_name='Beta Jobs Owner',
            ceo_name='Beta CEO',
            industry='Finance',
            country='United Kingdom',
            currency='GBP'
        )
        db.session.add(comp_b)
        db.session.commit()

        user_admin_b = User(
            username='s23_admin_b',
            email='s23_admin_b@beta.corp',
            role=Role.ADMIN,
            is_admin=True,
            company_id=comp_b.id,
            first_name='Admin',
            last_name='Beta'
        )
        user_admin_b.set_password('SecretPass123!')
        db.session.add(user_admin_b)
        db.session.commit()

        key_admin_b, raw_admin_key_b = ApiKey.generate(
            company_id=comp_b.id,
            user_id=user_admin_b.id,
            name='Beta Admin Key',
            role=Role.ADMIN
        )
        db.session.add(key_admin_b)
        db.session.commit()

        yield {
            "comp_a_id": comp_a.id,
            "comp_b_id": comp_b.id,
            "user_a_id": user_admin_a.id,
            "user_b_id": user_admin_b.id,
            "raw_key_a": raw_admin_key_a,
            "raw_key_b": raw_admin_key_b,
        }

        _clean_s23_data()


# --------------------------------------------------------------------------
# UNIT & SERVICE TESTS
# --------------------------------------------------------------------------

def test_job_model_creation_and_dict(app, job_tenants):
    """Test BackgroundJob model creation, payload/result storage, and to_dict()."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        job = BackgroundJob(
            company_id=cid,
            user_id=uid,
            job_type='test_job',
            priority=8,
            max_retries=5,
            status='pending',
            progress=0,
            stage_message='Initialized'
        )
        job.set_payload({"param1": "value1", "count": 42})
        db.session.add(job)
        db.session.commit()

        assert job.id is not None
        assert len(job.id) == 36  # UUID length
        assert job.get_payload() == {"param1": "value1", "count": 42}
        assert job.duration_seconds is None

        # Simulate completion
        job.started_at = datetime.utcnow()
        time.sleep(0.01)
        job.completed_at = datetime.utcnow()
        job.duration_ms = 150
        job.status = 'completed'
        job.progress = 100
        job.set_result({"output": "success"})
        db.session.commit()

        d = job.to_dict()
        assert d['id'] == job.id
        assert d['company_id'] == cid
        assert d['job_type'] == 'test_job'
        assert d['status'] == 'completed'
        assert d['progress'] == 100
        assert d['result'] == {"output": "success"}
        assert d['duration_ms'] == 150
        assert d['duration_seconds'] == 0.15


def test_job_service_synchronous_simulation(app, job_tenants):
    """Verify synchronous execution of simulation_monte_carlo job."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        payload = {
            "revenue_before": 100000,
            "cost_before": 60000,
            "revenue_after": 120000,
            "cost_after": 70000,
            "iterations": 100,
            "volatility": 0.1,
            "seed": 42
        }

        job = JobService.enqueue_job(
            job_type='simulation_monte_carlo',
            company_id=cid,
            payload=payload,
            user_id=uid,
            synchronous=True
        )

        assert job.status == 'completed'
        assert job.progress == 100
        assert job.duration_ms is not None and job.duration_ms > 0
        assert job.result is not None
        assert 'metrics' in job.result or 'mean_npv' in job.result or 'success_probability' in job.result or 'iterations' in job.result


def test_job_service_asynchronous_execution(app, job_tenants):
    """Verify async worker pool executes and completes batch_import task."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        payload = {
            "domain": "customers",
            "records": [{"name": f"Cust {i}"} for i in range(10)]
        }

        job = JobService.enqueue_job(
            job_type='batch_import',
            company_id=cid,
            payload=payload,
            user_id=uid,
            synchronous=False
        )
        job_id = job.id

        # Poll for completion (max 5 seconds)
        completed = False
        for _ in range(50):
            time.sleep(0.1)
            db.session.remove()
            fresh_job = db.session.get(BackgroundJob, job_id)
            if fresh_job and fresh_job.status == 'completed':
                completed = True
                assert fresh_job.progress == 100
                assert fresh_job.result['total_records_processed'] == 10
                break

        assert completed, "Background job did not complete within timeout."


def test_job_service_cancellation(app, job_tenants):
    """Verify job cancellation before execution sets status to cancelled."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        # Create job without worker execution
        job = BackgroundJob(
            company_id=cid,
            user_id=uid,
            job_type='simulation_monte_carlo',
            status='pending',
            progress=0,
            stage_message='Queued'
        )
        db.session.add(job)
        db.session.commit()
        job_id = job.id

        cancelled_job = JobService.cancel_job(job_id, company_id=cid, user_id=uid)
        assert cancelled_job is not None
        assert cancelled_job.status == 'cancelled'
        assert 'Cancelled' in cancelled_job.stage_message


def test_job_service_unregistered_type(app, job_tenants):
    """Attempting to enqueue an unregistered job type raises ValueError."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        with pytest.raises(ValueError) as exc:
            JobService.enqueue_job(
                job_type='invalid_mystery_job_handler',
                company_id=cid,
                user_id=uid
            )
        assert 'Unregistered job type' in str(exc.value)


def test_job_service_error_handling(app, job_tenants):
    """Verify that an exception in handler captures error and marks job failed."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        # Temporarily register a failing handler
        @JobService.register_handler("failing_test_handler")
        def handle_fail(job, payload, progress_cb):
            progress_cb(20, "About to fail")
            raise RuntimeError("Engine catastrophic simulation explosion!")

        job = JobService.enqueue_job(
            job_type='failing_test_handler',
            company_id=cid,
            user_id=uid,
            synchronous=True
        )

        assert job.status == 'failed'
        assert 'Engine catastrophic simulation explosion!' in job.error_message


def test_job_service_eventbus_dispatch(app, job_tenants):
    """Verify that JobService publishes domain events on EventBus."""
    with app.app_context():
        cid = job_tenants["comp_a_id"]
        uid = job_tenants["user_a_id"]

        events_captured = []

        def listener(evt):
            if evt.event_type.startswith("job."):
                events_captured.append(evt.event_type)

        EventBus.subscribe('*', listener)
        try:
            JobService.enqueue_job(
                job_type='simulation_monte_carlo',
                company_id=cid,
                payload={"iterations": 50},
                user_id=uid,
                synchronous=True
            )

            assert EventTypes.JOB_ENQUEUED in events_captured
            assert EventTypes.JOB_STARTED in events_captured
            assert EventTypes.JOB_PROGRESS in events_captured
            assert EventTypes.JOB_COMPLETED in events_captured
        finally:
            EventBus.unsubscribe('*', listener)


def test_job_multi_tenant_isolation(app, job_tenants):
    """Verify tenant isolation: Tenant Beta cannot view or cancel Tenant Alpha's jobs."""
    with app.app_context():
        comp_a = job_tenants["comp_a_id"]
        comp_b = job_tenants["comp_b_id"]

        job_a = JobService.enqueue_job(
            job_type='simulation_monte_carlo',
            company_id=comp_a,
            payload={"iterations": 50},
            synchronous=True
        )

        # Tenant B lookup must return None
        assert JobService.get_job(job_a.id, company_id=comp_b) is None

        # Tenant B cancellation must return None / fail
        assert JobService.cancel_job(job_a.id, company_id=comp_b) is None

        # Tenant B list must not include job_a
        jobs_b = JobService.list_jobs(company_id=comp_b)
        assert all(j.id != job_a.id for j in jobs_b)


# --------------------------------------------------------------------------
# REST API v1 ENDPOINT TESTS (/api/v1/jobs)
# --------------------------------------------------------------------------

def test_api_v1_enqueue_job(client, job_tenants):
    """POST /api/v1/jobs enqueues a job and returns HTTP 202 with envelope."""
    headers = {'X-API-Key': job_tenants["raw_key_a"]}
    payload = {
        "job_type": "simulation_monte_carlo",
        "payload": {
            "iterations": 100,
            "volatility": 0.1
        },
        "priority": 7
    }

    res = client.post('/api/v1/jobs', headers=headers, json=payload)
    assert res.status_code == 202
    data = res.get_json()
    assert data['success'] is True
    assert data['data']['job_type'] == 'simulation_monte_carlo'
    assert data['data']['status'] in ('pending', 'running', 'completed')
    assert data['data']['priority'] == 7


def test_api_v1_list_jobs(client, job_tenants):
    """GET /api/v1/jobs lists jobs with pagination and metadata."""
    headers = {'X-API-Key': job_tenants["raw_key_a"]}

    # Enqueue a couple of jobs
    client.post('/api/v1/jobs', headers=headers, json={"job_type": "batch_import", "payload": {}})

    res = client.get('/api/v1/jobs?per_page=10', headers=headers)
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert isinstance(data['data'], list)
    assert len(data['data']) >= 1
    assert 'meta' in data
    assert 'pagination' in data['meta']
    assert data['meta']['pagination']['page'] == 1


def test_api_v1_get_job_detail_and_cross_tenant_block(client, job_tenants):
    """GET /api/v1/jobs/<id> returns detail for owner, 404 for other tenant."""
    headers_a = {'X-API-Key': job_tenants["raw_key_a"]}
    headers_b = {'X-API-Key': job_tenants["raw_key_b"]}

    create_res = client.post('/api/v1/jobs', headers=headers_a, json={"job_type": "simulation_monte_carlo"})
    job_id = create_res.get_json()['data']['id']

    # Tenant Alpha retrieves successfully
    res_a = client.get(f'/api/v1/jobs/{job_id}', headers=headers_a)
    assert res_a.status_code == 200
    assert res_a.get_json()['data']['id'] == job_id

    # Tenant Beta cannot access Tenant Alpha's job (returns 404)
    res_b = client.get(f'/api/v1/jobs/{job_id}', headers=headers_b)
    assert res_b.status_code == 404
    assert res_b.get_json()['success'] is False


def test_api_v1_cancel_job(client, job_tenants):
    """POST /api/v1/jobs/<id>/cancel requests job cancellation."""
    headers = {'X-API-Key': job_tenants["raw_key_a"]}

    create_res = client.post('/api/v1/jobs', headers=headers, json={"job_type": "batch_import"})
    job_id = create_res.get_json()['data']['id']

    cancel_res = client.post(f'/api/v1/jobs/{job_id}/cancel', headers=headers)
    assert cancel_res.status_code in (200, 404)
    data = cancel_res.get_json()
    if cancel_res.status_code == 200:
        assert data['success'] is True


def test_api_v1_job_types(client, job_tenants):
    """GET /api/v1/jobs/types lists registered handlers."""
    headers = {'X-API-Key': job_tenants["raw_key_a"]}
    res = client.get('/api/v1/jobs/types', headers=headers)
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    types = [item['type'] for item in data['data']]
    assert 'simulation_monte_carlo' in types
    assert 'data_quality_scan' in types
    assert 'batch_import' in types


# --------------------------------------------------------------------------
# WEB INTERFACE ROUTE TESTS (/jobs/)
# --------------------------------------------------------------------------

def test_jobs_web_dashboard_unauthenticated_redirect(client):
    """Unauthenticated access to /jobs/ redirects to login."""
    res = client.get('/jobs/')
    assert res.status_code in (302, 401)


def test_jobs_web_dashboard_authenticated(client, job_tenants):
    """Authenticated user can load /jobs/ dashboard HTML."""
    with client.session_transaction() as sess:
        sess['_user_id'] = str(job_tenants["user_a_id"])
        sess['company_id'] = job_tenants["comp_a_id"]
        sess['_fresh'] = True

    res = client.get('/jobs/')
    assert res.status_code == 200
    html = res.get_data(as_text=True)
    assert 'Background Task Engine' in html
    assert 'Background Job Registry' in html


def test_jobs_web_status_polling_api(client, job_tenants, app):
    """Authenticated user can poll real-time status via /jobs/api/status/<id>."""
    with app.app_context():
        job = JobService.enqueue_job(
            job_type='simulation_monte_carlo',
            company_id=job_tenants["comp_a_id"],
            user_id=job_tenants["user_a_id"],
            synchronous=True
        )
        job_id = job.id

    with client.session_transaction() as sess:
        sess['_user_id'] = str(job_tenants["user_a_id"])
        sess['company_id'] = job_tenants["comp_a_id"]
        sess['_fresh'] = True

    res = client.get(f'/jobs/api/status/{job_id}')
    assert res.status_code == 200
    data = res.get_json()
    assert data['success'] is True
    assert data['job']['id'] == job_id
    assert data['job']['status'] == 'completed'
