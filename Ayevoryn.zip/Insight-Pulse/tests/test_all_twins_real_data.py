import pytest
from app import create_app
from database.db import db
from database.models import User, Company, Customer, Employee, Department, Inventory, Supplier
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from datetime import date

@pytest.fixture
def test_app():
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    return app

def test_company2_customer_twin_metrics(test_app):
    with test_app.app_context():
        user = User.query.filter_by(username='ussu321').first() or User.query.first()
        with test_app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['company_id'] = 2
            
            res = client.get('/business-twin/customers')
            assert res.status_code == 200
            html = res.data.decode('utf-8')
            
            assert 'Total Customers' in html
            assert 'Active Customers' in html
            assert 'Churned' in html
            # Churned customers should be 2
            assert 'const churned = 2;' in html

def test_edit_customer_syncs_is_churned(test_app):
    with test_app.app_context():
        user = User.query.filter_by(username='ussu321').first() or User.query.first()
        cust = Customer.query.filter_by(company_id=2, status='active').first()
        assert cust is not None
        
        with test_app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['company_id'] = 2
            
            # Edit customer status to churned
            res = client.post(f'/business-twin/customers/{cust.id}/edit', data={
                'first_name': cust.first_name,
                'last_name': cust.last_name,
                'email': cust.email,
                'status': 'churned'
            })
            assert res.status_code == 200
            
            db.session.refresh(cust)
            assert cust.status == 'churned'
            assert cust.is_churned == True
            assert cust.churn_date is not None
            
            # Revert to active
            res = client.post(f'/business-twin/customers/{cust.id}/edit', data={
                'first_name': cust.first_name,
                'last_name': cust.last_name,
                'email': cust.email,
                'status': 'active'
            })
            assert res.status_code == 200
            db.session.refresh(cust)
            assert cust.status == 'active'
            assert cust.is_churned == False

def test_company2_employee_twin_metrics(test_app):
    with test_app.app_context():
        user = User.query.filter_by(username='ussu321').first() or User.query.first()
        with test_app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['company_id'] = 2
            
            res = client.get('/business-twin/employees')
            assert res.status_code == 200
            html = res.data.decode('utf-8')
            
            assert 'IT' in html
            assert 'deptStats' in html
            assert 'Staff Headcount' in html

def test_company2_inventory_twin_metrics(test_app):
    with test_app.app_context():
        user = User.query.filter_by(username='ussu321').first() or User.query.first()
        with test_app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['company_id'] = 2
            
            res = client.get('/business-twin/inventory')
            assert res.status_code == 200
            html = res.data.decode('utf-8')
            
            assert 'catStats' in html
            assert 'Optimal Stock' in html

def test_company2_supplier_twin_metrics(test_app):
    with test_app.app_context():
        user = User.query.filter_by(username='ussu321').first() or User.query.first()
        with test_app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['company_id'] = 2
            
            res = client.get('/business-twin/suppliers')
            assert res.status_code == 200
            html = res.data.decode('utf-8')
            
            assert 'rankings' in html
            assert 'supplierSpendChart' in html


def test_custom_twin_dynamic_stats_and_charts(test_app):
    with test_app.app_context():
        user = User.query.filter_by(username='ussu321').first() or User.query.first()
        twin = CustomTwin.query.filter_by(company_id=2, is_active=True).first()
        if not twin:
            twin = CustomTwin(
                company_id=2,
                name='Vehicles',
                slug='vehicles',
                icon='fa-car',
                color='#3B82F6',
                created_by=user.id,
                is_active=True
            )
            twin.set_field_definitions([
                {'name': 'vehicle_name', 'label': 'Vehicle Name', 'type': 'text'},
                {'name': 'category', 'label': 'Category', 'type': 'select'},
                {'name': 'mileage', 'label': 'Mileage', 'type': 'number'}
            ])
            twin.set_table_columns(['vehicle_name', 'category', 'mileage'])
            db.session.add(twin)
            db.session.commit()
            
            # Add records
            r1 = CustomTwinRecord(twin_id=twin.id, company_id=2, created_by=user.id)
            r1.set_data({'vehicle_name': 'Van A', 'category': 'Fleet', 'mileage': 45000})
            r2 = CustomTwinRecord(twin_id=twin.id, company_id=2, created_by=user.id)
            r2.set_data({'vehicle_name': 'Truck B', 'category': 'Freight', 'mileage': 82000})
            db.session.add_all([r1, r2])
            db.session.commit()
            
        with test_app.test_client() as client:
            with client.session_transaction() as sess:
                sess['_user_id'] = str(user.id)
                sess['company_id'] = 2
            
            res = client.get(f'/business-twin/custom-twins/{twin.slug}')
            assert res.status_code == 200
            html = res.data.decode('utf-8')
            
            # Auto derived stats and dynamic charts
            assert 'Total Records' in html
            assert 'customTwinCategoryChart' in html
