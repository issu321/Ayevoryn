"""
TEST SUITE: Stage 24 - PostgreSQL Readiness & Dialect Portability
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. Database URI normalization (converting legacy postgres:// to postgresql://).
2. Engine options and connection pooling tuning for PostgreSQL.
3. Metadata completeness across all 50+ enterprise digital twin tables.
4. Primary key and foreign key constraint validity across all models.
5. Topological dependency sorting for acyclic database migration.
6. Alembic versioning configuration and initial schema revision.
7. SQLite to PostgreSQL migration utility execution in dry-run and validation modes.
8. Dialect-portable table creation via db.metadata.create_all().
"""

import pytest
import os
import sys
import subprocess
from sqlalchemy import create_engine, text, MetaData
from alembic.script import ScriptDirectory
from alembic.config import Config as AlembicConfig

from database.db import db, normalize_db_uri
from config.settings import Config
from tools.migrate_sqlite_to_postgres import get_topological_table_order, sync_postgres_sequences


def test_normalize_db_uri():
    """Verify normalize_db_uri converts postgres:// to postgresql:// and leaves other schemes intact."""
    assert normalize_db_uri("postgres://user:pass@localhost:5432/mydb") == "postgresql://user:pass@localhost:5432/mydb"
    assert normalize_db_uri("postgresql://user:pass@localhost:5432/mydb") == "postgresql://user:pass@localhost:5432/mydb"
    assert normalize_db_uri("sqlite:///instance/test.db") == "sqlite:///instance/test.db"
    assert normalize_db_uri("") == ""
    assert normalize_db_uri(None) is None


def test_postgres_engine_options_configuration(monkeypatch):
    """Verify that PostgreSQL URIs activate connection pooling options."""
    pg_uri = "postgresql://user:secret@db.host.internal:5432/aevoryn_db"
    assert pg_uri.startswith("postgresql")

    # Verify Config settings when postgres is target
    is_pg = pg_uri.startswith('postgresql')
    assert is_pg is True

    options = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    if is_pg:
        options.update({
            'pool_size': 15,
            'max_overflow': 25,
        })

    assert options['pool_size'] == 15
    assert options['max_overflow'] == 25
    assert options['pool_pre_ping'] is True


def test_all_metadata_tables_present(app):
    """Verify that all core enterprise models are properly registered in db.metadata."""
    with app.app_context():
        tables = db.metadata.tables
        expected_tables = [
            'companies', 'users', 'customers', 'financial_records',
            'employees', 'departments', 'inventory', 'suppliers',
            'simulations', 'audit_logs', 'activity_logs', 'scenarios',
            'risks', 'forecasts', 'api_keys', 'webhook_subscriptions',
            'webhook_deliveries', 'background_jobs', 'custom_twins',
            'twin_dependencies', 'twin_snapshots', 'documents'
        ]
        for tbl in expected_tables:
            assert tbl in tables, f"Expected table '{tbl}' not found in db.metadata"


def test_all_tables_have_primary_keys(app):
    """Verify that every single model table has an explicit primary key defined."""
    with app.app_context():
        for name, table in db.metadata.tables.items():
            pks = list(table.primary_key.columns)
            assert len(pks) >= 1, f"Table '{name}' has no primary key defined!"


def test_foreign_keys_referential_integrity(app):
    """Verify all defined foreign keys point to registered target tables."""
    with app.app_context():
        table_names = set(db.metadata.tables.keys())
        for name, table in db.metadata.tables.items():
            for fk in table.foreign_keys:
                target_table = fk.column.table.name
                assert target_table in table_names, (
                    f"Table '{name}' has foreign key to unknown table '{target_table}'"
                )


def test_topological_sort_order(app):
    """Verify topological table ordering places parents before children."""
    with app.app_context():
        sorted_tables = get_topological_table_order(db.metadata)
        assert len(sorted_tables) >= 50

        table_indices = {t.name: i for i, t in enumerate(sorted_tables)}

        # Parent tables must appear before dependent child tables
        assert table_indices['companies'] < table_indices['users']
        assert table_indices['companies'] < table_indices['customers']
        assert table_indices['companies'] < table_indices['financial_records']
        assert table_indices['companies'] < table_indices['background_jobs']
        assert table_indices['companies'] < table_indices['webhook_subscriptions']
        assert table_indices['webhook_subscriptions'] < table_indices['webhook_deliveries']


def test_alembic_migrations_scaffold_and_head(app):
    """Verify Alembic migration directory is configured with 001_initial_schema head."""
    ini_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'migrations', 'alembic.ini')
    assert os.path.exists(ini_path)

    alembic_cfg = AlembicConfig(ini_path)
    alembic_cfg.set_main_option('script_location', os.path.dirname(ini_path))
    script_dir = ScriptDirectory.from_config(alembic_cfg)
    heads = script_dir.get_heads()

    assert len(heads) == 1
    assert heads[0] == '001_initial_schema'


def test_migration_tool_cli_dry_run():
    """Verify that tools/migrate_sqlite_to_postgres.py executes dry-run without errors."""
    res = subprocess.run(
        [sys.executable, 'tools/migrate_sqlite_to_postgres.py', '--dry-run'],
        capture_output=True,
        text=True,
        cwd=os.path.dirname(os.path.dirname(__file__))
    )
    assert res.returncode == 0
    assert 'DRY RUN MODE' in res.stdout or 'DRY RUN MODE' in res.stderr
    assert 'companies' in res.stdout or 'companies' in res.stderr


def test_portable_ddl_generation(app):
    """Verify that db.metadata can cleanly create all tables on a fresh isolated engine."""
    isolated_engine = create_engine('sqlite:///:memory:')
    with app.app_context():
        # Create all tables on isolated engine
        db.metadata.create_all(bind=isolated_engine)

        with isolated_engine.connect() as conn:
            created_tables = {
                r[0] for r in conn.execute(text("SELECT name FROM sqlite_master WHERE type='table'")).fetchall()
            }
            assert 'companies' in created_tables
            assert 'users' in created_tables
            assert 'background_jobs' in created_tables
            assert 'webhook_subscriptions' in created_tables
            assert 'financial_records' in created_tables
            assert len(created_tables) >= 50

    isolated_engine.dispose()
