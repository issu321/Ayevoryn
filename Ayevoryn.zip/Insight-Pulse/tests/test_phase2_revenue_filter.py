"""
Verification suite for AEVORYN Phase 2:
1. Flexible date parser (ISO, European DD/MM/YYYY, US MM/DD/YYYY, Excel serial numbers).
2. Currency scrubbing & reference cleaning.
3. Twin Record Service import processing with mode logic ('upsert', 'add', 'update').
4. UniversalFilterService periods, financial metrics calculation, and all-time reporting.
5. Superadmin bulk company deletion without foreign key violations.
"""
import unittest
from datetime import date
from app import create_app
from database import db
from database.models.company import Company
from database.models.financial import FinancialRecord
from services.twin_record_service import TwinRecordService
from services.universal_filter_service import UniversalFilterService
from services.superadmin_service import SuperadminService
from services.company_service import CompanyService


class TestPhase2RevenueAndFilters(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = create_app()
        cls.app.config['TESTING'] = True
        cls.app_context = cls.app.app_context()
        cls.app_context.push()

    @classmethod
    def tearDownClass(cls):
        cls.app_context.pop()

    def test_01_flexible_date_parser(self):
        """Test multi-format date parsing."""
        # ISO
        d1, err1 = TwinRecordService.parse_flexible_date("2026-11-06")
        self.assertIsNone(err1)
        self.assertEqual(d1, date(2026, 11, 6))

        # European DD/MM/YYYY (e.g. 25/11/2026)
        d2, err2 = TwinRecordService.parse_flexible_date("25/11/2026")
        self.assertIsNone(err2)
        self.assertEqual(d2, date(2026, 11, 25))

        # US MM/DD/YYYY (e.g. 11/25/2026)
        d3, err3 = TwinRecordService.parse_flexible_date("11/25/2026")
        self.assertIsNone(err3)
        self.assertEqual(d3, date(2026, 11, 25))

        # Excel Serial number (46332 -> 2026-11-06)
        d4, err4 = TwinRecordService.parse_flexible_date(46332)
        self.assertIsNone(err4)
        self.assertEqual(d4, date(2026, 11, 6))

        # Invalid date string should return error, NOT fallback to date.today()
        d5, err5 = TwinRecordService.parse_flexible_date("not-a-valid-date")
        self.assertIsNone(d5)
        self.assertIsNotNone(err5)

    def test_02_currency_and_reference_sanitization(self):
        """Test stripping currency symbols and cleaning Excel reference numbers."""
        amt1, err1 = TwinRecordService.validate_amount("₹ 25,000.50")
        self.assertIsNone(err1)
        self.assertAlmostEqual(amt1, 25000.50)

        amt2, err2 = TwinRecordService.validate_amount("-$1,250.00", allow_negative=True)
        self.assertIsNone(err2)
        self.assertAlmostEqual(amt2, -1250.00)

        ref1 = TwinRecordService.clean_reference("INV-1002.0")
        self.assertEqual(ref1, "INV-1002")

        ref2 = TwinRecordService.clean_reference(10045)
        self.assertEqual(ref2, "10045")

    def test_03_universal_filter_service_periods(self):
        """Verify period bounds and Company 2 financial metrics."""
        today = date.today()
        s_today, e_today, label_today = UniversalFilterService.get_period_bounds('today')
        self.assertEqual(s_today, today)
        self.assertEqual(e_today, today)
        self.assertEqual(label_today, 'today')

        s_all, e_all, label_all = UniversalFilterService.get_period_bounds('all_time')
        self.assertIsNone(s_all)
        self.assertIsNone(e_all)
        self.assertEqual(label_all, 'all_time')

        # Metrics for Company 2 (USMANIA INDUSTRIES)
        c2 = Company.query.filter_by(id=2).first()
        if c2:
            metrics_all = UniversalFilterService.get_financial_summary_metrics(2, 'all_time')
            self.assertGreater(metrics_all['all_time_revenue_count'], 0)
            self.assertGreater(metrics_all['period_revenue'], 0)

            # In 30d period, Company 2's historical records outside trailing 30 days
            # still preserve the true all-time metrics!
            metrics_30d = UniversalFilterService.get_financial_summary_metrics(2, '30d')
            self.assertEqual(metrics_30d['all_time_revenue_count'], metrics_all['all_time_revenue_count'])
            self.assertEqual(metrics_30d['all_time_revenue'], metrics_all['all_time_revenue'])

    def test_04_twin_record_service_import_modes(self):
        """Test upsert, add, and update import modes."""
        existing_test = Company.query.filter_by(company_name='TEST_PHASE2_INC').first()
        if existing_test:
            SuperadminService.delete_company_permanently(existing_test.id)

        test_company = Company(
            company_name='TEST_PHASE2_INC',
            business_name='TEST_PHASE2_INC',
            owner_name='Admin',
            ceo_name='Admin',
            industry='Technology'
        )
        db.session.add(test_company)
        db.session.commit()
        CompanyService.ensure_company_financial_accounts(test_company.id)

        rows = [
            {
                'transaction_date': '2026-11-01',
                'amount': '5000.00',
                'reference_number': 'TEST-REC-001',
                'category': 'Revenue',
                'subcategory': 'Software'
            },
            {
                'transaction_date': '2026-11-02',
                'amount': '8000.00',
                'reference_number': 'TEST-REC-002',
                'category': 'Revenue',
                'subcategory': 'Consulting'
            }
        ]

        # 1. Upsert mode: insert 2 records
        res1 = TwinRecordService.process_financial_records_import(test_company.id, rows, 'revenue', 'upsert')
        self.assertTrue(res1['success'])
        self.assertEqual(res1['inserted'], 2)

        # 2. Add mode with duplicate: should skip duplicate
        rows_add = [
            {
                'transaction_date': '2026-11-01',
                'amount': '9999.00',
                'reference_number': 'TEST-REC-001',
                'category': 'Revenue'
            },
            {
                'transaction_date': '2026-11-03',
                'amount': '3000.00',
                'reference_number': 'TEST-REC-003',
                'category': 'Revenue'
            }
        ]
        res2 = TwinRecordService.process_financial_records_import(test_company.id, rows_add, 'revenue', 'add')
        self.assertTrue(res2['success'])
        self.assertEqual(res2['inserted'], 1)
        self.assertEqual(res2['skipped'], 1)

        # Verify TEST-REC-001 was untouched in 'add' mode
        rec1 = FinancialRecord.query.filter_by(company_id=test_company.id, reference_number='TEST-REC-001').first()
        self.assertEqual(rec1.amount, 5000.00)

        # 3. Update mode: should update TEST-REC-001 and skip TEST-REC-999
        rows_upd = [
            {
                'transaction_date': '2026-11-01',
                'amount': '6200.00',
                'reference_number': 'TEST-REC-001',
                'category': 'Revenue'
            },
            {
                'transaction_date': '2026-11-04',
                'amount': '1500.00',
                'reference_number': 'TEST-REC-999',
                'category': 'Revenue'
            }
        ]
        res3 = TwinRecordService.process_financial_records_import(test_company.id, rows_upd, 'revenue', 'update')
        self.assertTrue(res3['success'])
        self.assertEqual(res3['updated'], 1)
        self.assertEqual(res3['skipped'], 1)

        rec1_upd = FinancialRecord.query.filter_by(company_id=test_company.id, reference_number='TEST-REC-001').first()
        self.assertEqual(rec1_upd.amount, 6200.00)

        # Cleanup test company using SuperadminService to verify foreign-key-safe purge
        from database.models.user import User
        from security.rbac import Role
        sa_user = User.query.filter_by(role=Role.GLOBAL_SUPERADMIN).first()
        del_ok, del_msg = SuperadminService.delete_company_permanently(
            test_company.id,
            actor_user=sa_user,
            require_exact_name=False,
            require_password=False
        )
        self.assertTrue(del_ok, f"Delete failed: {del_msg}")


if __name__ == '__main__':
    unittest.main()
