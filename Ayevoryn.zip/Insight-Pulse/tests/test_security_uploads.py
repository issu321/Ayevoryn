import os
import pytest
from app import app
from database.models.user import User
from database.models.company import Company

@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client

def test_unauthenticated_upload_access_denied(client):
    """Unauthenticated requests to /uploads/ must be rejected or redirected to login."""
    res = client.get('/uploads/.env')
    assert res.status_code in [302, 401, 404], f'Expected 302/401/404, got {res.status_code}'

def test_blocked_env_file_access(client):
    """Authenticated requests cannot retrieve .env."""
    with app.app_context():
        u = User.query.first()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
    
    res = client.get('/uploads/.env')
    assert res.status_code == 404
    assert b'SECRET_KEY' not in res.data

def test_blocked_source_code_access(client):
    """Authenticated requests cannot retrieve app.py or python source code."""
    with app.app_context():
        u = User.query.first()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
    
    res = client.get('/uploads/app.py')
    assert res.status_code == 404

def test_blocked_database_access(client):
    """Authenticated requests cannot retrieve SQLite database."""
    with app.app_context():
        u = User.query.first()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
    
    res = client.get('/uploads/instance/business_simulator.db')
    assert res.status_code == 404

def test_blocked_path_traversal(client):
    """Path traversal attempts must fail with 404."""
    with app.app_context():
        u = User.query.first()
    with client.session_transaction() as sess:
        sess['_user_id'] = str(u.id)
        sess['_fresh'] = True
    
    res = client.get('/uploads/..%2F..%2F.env')
    assert res.status_code in [400, 404]
    
    res2 = client.get('/uploads/subdir/../../.env')
    assert res2.status_code in [400, 404]

def test_legitimate_upload_serving(client):
    """Verify that legitimate uploaded files within UPLOAD_FOLDER are served correctly."""
    upload_dir = os.path.abspath(app.config.get('UPLOAD_FOLDER') or os.path.join(app.root_path, 'uploads'))
    os.makedirs(upload_dir, exist_ok=True)
    test_file_path = os.path.join(upload_dir, 'test_sample.txt')
    with open(test_file_path, 'w', encoding='utf-8') as f:
        f.write('Legitimate upload content')
        
    try:
        with app.app_context():
            u = User.query.first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(u.id)
            sess['_fresh'] = True
            
        res = client.get('/uploads/test_sample.txt')
        assert res.status_code == 200
        assert b'Legitimate upload content' in res.data
        res.close()
    finally:
        if os.path.exists(test_file_path):
            try:
                os.remove(test_file_path)
            except Exception:
                pass
