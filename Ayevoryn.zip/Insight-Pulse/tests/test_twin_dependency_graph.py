"""
AEVORYN / INSIGHT-PULSE
STAGE 11: TWIN DEPENDENCY GRAPH AUTOMATED TEST SUITE
Verifies topological graph discovery, DIRECT, DERIVED, CONFIGURED, and ESTIMATED dependencies,
cycle detection, topological ordering, blast radius traversal, upstream lineage, and RBAC routes.
"""

import pytest
from datetime import datetime
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.employee import Employee
from database.models.supplier import Supplier
from database.models.inventory import Inventory
from database.models.financial import FinancialRecord
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.twin_dependency import TwinDependency, DependencyType
from services.events import EventBus, EventTypes
from services.twin_dependency_service import TwinDependencyService
from security.rbac import Role, Permission


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage11'
    })
    with app.app_context():
        db.create_all()

        # Seed Company 1 (Tenant Alpha)
        comp_a = Company(
            company_name='Alpha Aerospace',
            business_name='Alpha Aero',
            owner_name='Alice Alpha',
            ceo_name='Arthur Alpha'
        )
        db.session.add(comp_a)

        # Seed Company 2 (Tenant Beta)
        comp_b = Company(
            company_name='Beta BioTech',
            business_name='Beta Bio',
            owner_name='Bob Beta',
            ceo_name='Boris Beta'
        )
        db.session.add(comp_b)
        db.session.commit()

        # Seed Admin user for Company 1
        admin_user = User(
            username='alpha_admin_stage11',
            email='admin@alpha.org',
            role=Role.ADMIN,
            company_id=comp_a.id
        )
        admin_user.set_password('password123')
        db.session.add(admin_user)

        # Seed Viewer user for Company 1 (no data:write permission)
        viewer_user = User(
            username='alpha_viewer_stage11',
            email='viewer@alpha.org',
            role=Role.VIEWER,
            company_id=comp_a.id
        )
        viewer_user.set_password('password123')
        db.session.add(viewer_user)
        db.session.commit()

        EventBus.clear_subscribers()
        yield app
        EventBus.clear_subscribers()
        db.session.remove()
        db.drop_all()


@pytest.fixture
def admin_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_admin_stage11').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def viewer_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_viewer_stage11').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


# =============================================================================
# 1. MULTI-TENANT ISOLATION
# =============================================================================

def test_multi_tenant_dependency_graph_isolation(app):
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Alpha Aerospace').first()
        comp_b = Company.query.filter_by(company_name='Beta BioTech').first()

        # Tenant A: Department & Employee
        dept_a = Department(company_id=comp_a.id, name='Propulsion', budget=200000)
        db.session.add(dept_a)
        db.session.commit()
        emp_a = Employee(company_id=comp_a.id, first_name='Neil', last_name='Armstrong', department_id=dept_a.id)
        db.session.add(emp_a)

        # Tenant B: Department & Employee
        dept_b = Department(company_id=comp_b.id, name='Genomics', budget=500000)
        db.session.add(dept_b)
        db.session.commit()
        emp_b = Employee(company_id=comp_b.id, first_name='Gregor', last_name='Mendel', department_id=dept_b.id)
        db.session.add(emp_b)
        db.session.commit()

        # Query graph for Tenant A
        graph_a = TwinDependencyService.build_graph(company_id=comp_a.id)
        node_ids_a = {n['id'] for n in graph_a['nodes']}
        assert f"department:{dept_a.id}" in node_ids_a
        assert f"employee:{emp_a.id}" in node_ids_a
        assert f"department:{dept_b.id}" not in node_ids_a
        assert f"employee:{emp_b.id}" not in node_ids_a

        # Query graph for Tenant B
        graph_b = TwinDependencyService.build_graph(company_id=comp_b.id)
        node_ids_b = {n['id'] for n in graph_b['nodes']}
        assert f"department:{dept_b.id}" in node_ids_b
        assert f"employee:{emp_b.id}" in node_ids_b
        assert f"department:{dept_a.id}" not in node_ids_b


# =============================================================================
# 2. DIRECT RELATIONAL DEPENDENCY DISCOVERY
# =============================================================================

def test_direct_dependency_discovery(app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()

        # 1. Employee -> Department
        dept = Department(company_id=comp.id, name='Avionics', budget=150000)
        db.session.add(dept)
        db.session.commit()
        emp = Employee(company_id=comp.id, first_name='Buzz', last_name='Aldrin', department_id=dept.id)
        db.session.add(emp)

        # 2. Inventory -> Supplier
        sup = Supplier(company_id=comp.id, name='Titanium Works', category='Raw Materials')
        db.session.add(sup)
        db.session.commit()
        item = Inventory(
            company_id=comp.id,
            sku='TI-PLATE-01',
            name='Titanium Alloy Plate',
            supplier_id=sup.id,
            quantity_on_hand=50,
            unit_cost=300
        )
        db.session.add(item)

        # 3. Custom Twin Child -> Parent
        parent_twin = CustomTwin(company_id=comp.id, name='Aircraft Fleet', slug='aircraft-fleet')
        db.session.add(parent_twin)
        db.session.commit()
        child_twin = CustomTwin(company_id=comp.id, name='Engine Subsystem', slug='engine-subsystem', parent_twin_id=parent_twin.id)
        db.session.add(child_twin)
        db.session.commit()

        graph = TwinDependencyService.build_graph(company_id=comp.id, include_types=[DependencyType.DIRECT])
        direct_edges = [(e['source'], e['target']) for e in graph['edges'] if e['dependency_type'] == DependencyType.DIRECT]

        # Assert direct edges exist
        assert (f"employee:{emp.id}", f"department:{dept.id}") in direct_edges
        assert (f"supplier:{sup.id}", f"inventory:{item.id}") in direct_edges
        assert (f"custom_twin:{child_twin.id}", f"custom_twin:{parent_twin.id}") in direct_edges


# =============================================================================
# 3. DERIVED COMPUTATIONAL & FINANCIAL EDGES
# =============================================================================

def test_derived_financial_and_operational_dependencies(app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()

        dept = Department(company_id=comp.id, name='Flight Operations', budget=500000)
        db.session.add(dept)
        db.session.commit()

        # Expense charged to department
        exp = FinancialRecord(
            company_id=comp.id,
            transaction_type='expense',
            transaction_date=datetime.utcnow().date(),
            amount=50000,
            department_id=dept.id
        )
        db.session.add(exp)
        db.session.commit()

        graph = TwinDependencyService.build_graph(company_id=comp.id, include_types=[DependencyType.DERIVED])
        derived_edges = [(e['source'], e['target']) for e in graph['edges'] if e['dependency_type'] == DependencyType.DERIVED]

        # Assert financial derivations exist
        assert ('metric:monthly_burn', 'metric:cash_runway') in derived_edges
        assert ('metric:monthly_revenue', 'metric:net_margin') in derived_edges
        assert (f"department:{dept.id}", f"metric:dept_utilization:{dept.id}") in derived_edges


# =============================================================================
# 4. CYCLE DETECTION & TOPOLOGICAL ORDERING
# =============================================================================

def test_cycle_detection_and_topological_sort():
    # Acyclic graph: A -> B -> C -> D
    acyclic_edges = [
        {'source': 'A', 'target': 'B'},
        {'source': 'B', 'target': 'C'},
        {'source': 'C', 'target': 'D'},
    ]
    nodes = [{'id': 'A'}, {'id': 'B'}, {'id': 'C'}, {'id': 'D'}]

    cycles = TwinDependencyService.detect_cycles(acyclic_edges)
    assert len(cycles) == 0

    topo = TwinDependencyService.get_topological_order(nodes, acyclic_edges)
    assert topo['is_dag'] is True
    assert topo['ordered_nodes'] == ['A', 'B', 'C', 'D']

    # Cyclic graph: A -> B -> C -> A
    cyclic_edges = [
        {'source': 'A', 'target': 'B'},
        {'source': 'B', 'target': 'C'},
        {'source': 'C', 'target': 'A'},
    ]
    cycles_detected = TwinDependencyService.detect_cycles(cyclic_edges)
    assert len(cycles_detected) >= 1
    assert 'A' in cycles_detected[0] and 'B' in cycles_detected[0] and 'C' in cycles_detected[0]

    topo_cyclic = TwinDependencyService.get_topological_order(nodes, cyclic_edges)
    assert topo_cyclic['is_dag'] is False


# =============================================================================
# 5. BLAST RADIUS DOWNSTREAM IMPACT TRAVERSAL
# =============================================================================

def test_blast_radius_traversal(app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()

        # Build dependency chain: Node 1 -> Node 2 -> Node 3
        # e.g. Supplier -> Inventory -> Configured Target
        sup = Supplier(company_id=comp.id, name='Rocket Engines Inc', category='Critical')
        db.session.add(sup)
        db.session.commit()

        inv = Inventory(
            company_id=comp.id,
            sku='ION-THRUST-01',
            name='Ion Thruster',
            supplier_id=sup.id,
            quantity_on_hand=10,
            unit_cost=5000
        )
        db.session.add(inv)
        db.session.commit()

        # Add configured link: inventory -> metric:cash_runway
        TwinDependencyService.add_configured_dependency(
            company_id=comp.id,
            source_type='inventory',
            source_id=str(inv.id),
            target_type='metric',
            target_id='cash_runway',
            strength=0.8,
            description='Inventory carrying costs impact runway'
        )

        blast = TwinDependencyService.get_blast_radius(company_id=comp.id, node_id=f"supplier:{sup.id}")
        assert blast['total_affected'] >= 2

        affected_ids = [a['node']['id'] for a in blast['affected_nodes']]
        assert f"inventory:{inv.id}" in affected_ids
        assert "metric:cash_runway" in affected_ids

        # Check attenuation: depth 1 has strength 1.0, depth 2 has strength 1.0 * 0.8 = 0.8
        inv_hit = next(a for a in blast['affected_nodes'] if a['node']['id'] == f"inventory:{inv.id}")
        assert inv_hit['depth'] == 1
        assert inv_hit['attenuated_impact'] == 1.0

        runway_hit = next(a for a in blast['affected_nodes'] if a['node']['id'] == "metric:cash_runway")
        assert runway_hit['depth'] == 2
        assert runway_hit['attenuated_impact'] == 0.8


# =============================================================================
# 6. UPSTREAM LINEAGE ROOT-CAUSE TRAVERSAL
# =============================================================================

def test_upstream_lineage_root_cause(app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()

        lineage = TwinDependencyService.get_upstream_lineage(
            company_id=comp.id,
            node_id='metric:cash_runway'
        )

        assert lineage['total_upstream'] >= 1
        upstream_ids = [u['node']['id'] for u in lineage['upstream_nodes']]
        assert 'metric:monthly_burn' in upstream_ids


# =============================================================================
# 7. CONFIGURED DEPENDENCY CRUD & DOMAIN EVENTS
# =============================================================================

def test_configured_dependency_crud_and_events(app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()
        events_captured = []

        def listener(event):
            events_captured.append(event)

        EventBus.subscribe(EventTypes.TWIN_DEPENDENCY_CREATED, listener)
        EventBus.subscribe(EventTypes.TWIN_DEPENDENCY_DELETED, listener)

        # 1. Create
        dep = TwinDependencyService.add_configured_dependency(
            company_id=comp.id,
            source_type='department',
            source_id='10',
            target_type='metric',
            target_id='custom_kpi',
            dependency_type=DependencyType.CONFIGURED,
            strength=0.75,
            description='Department productivity driver',
            actor_name='Alice'
        )

        assert dep.id is not None
        assert dep.strength == 0.75
        assert len(events_captured) == 1
        assert events_captured[0].event_type == EventTypes.TWIN_DEPENDENCY_CREATED
        assert events_captured[0].payload['strength'] == 0.75

        # 2. Self-loop rejected
        with pytest.raises(ValueError):
            TwinDependencyService.add_configured_dependency(
                company_id=comp.id,
                source_type='department',
                source_id='10',
                target_type='department',
                target_id='10'
            )

        # 3. Delete
        success = TwinDependencyService.delete_configured_dependency(
            company_id=comp.id,
            dependency_id=dep.id,
            actor_name='Alice'
        )
        assert success is True
        assert len(events_captured) == 2
        assert events_captured[1].event_type == EventTypes.TWIN_DEPENDENCY_DELETED


# =============================================================================
# 8. ROUTE INTEGRATION & RBAC AUTHORIZATION
# =============================================================================

def test_twin_graph_routes_admin_access(admin_client, app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()
        dept = Department(company_id=comp.id, name='R&D', budget=300000)
        db.session.add(dept)
        db.session.commit()
        dept_id = dept.id

    # 1. Admin access to UI
    res_ui = admin_client.get('/twin-graph/')
    assert res_ui.status_code == 200
    assert b'Digital Twin Dependency Graph' in res_ui.data

    # 2. Admin access to API data
    res_data = admin_client.get('/twin-graph/api/data')
    assert res_data.status_code == 200
    json_data = res_data.get_json()
    assert json_data['success'] is True
    assert 'nodes' in json_data['data']
    assert 'edges' in json_data['data']

    # 3. Admin access to centrality API
    res_cent = admin_client.get('/twin-graph/api/centrality')
    assert res_cent.status_code == 200
    cent_data = res_cent.get_json()
    assert cent_data['success'] is True
    assert 'graph_density' in cent_data['data']

    # 4. Admin creates link via POST (Permission.DATA_WRITE)
    link_payload = {
        'source_type': 'department',
        'source_id': str(dept_id),
        'target_type': 'metric',
        'target_id': 'cash_runway',
        'dependency_type': 'CONFIGURED',
        'strength': 0.9,
        'description': 'R&D burn sensitivity'
    }
    res_post_admin = admin_client.post('/twin-graph/api/dependencies', json=link_payload)
    assert res_post_admin.status_code == 201
    dep_id = res_post_admin.get_json()['dependency']['id']

    # 5. Admin deletes link via DELETE (Permission.DATA_DELETE)
    res_del = admin_client.delete(f"/twin-graph/api/dependencies/{dep_id}")
    assert res_del.status_code == 200
    assert res_del.get_json()['success'] is True


def test_twin_graph_routes_viewer_forbidden(viewer_client, app):
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Aerospace').first()
        dept = Department.query.filter_by(company_id=comp.id).first()
        dept_id = dept.id if dept else 1

    link_payload = {
        'source_type': 'department',
        'source_id': str(dept_id),
        'target_type': 'metric',
        'target_id': 'cash_runway',
        'dependency_type': 'CONFIGURED',
        'strength': 0.9,
        'description': 'Unauthorized modification'
    }
    # Viewer role forbidden on POST (lacks Permission.DATA_WRITE -> HTTP 403)
    res_post_viewer = viewer_client.post('/twin-graph/api/dependencies', json=link_payload)
    assert res_post_viewer.status_code == 403

