"""
AEVORYN / INSIGHT-PULSE
STAGE 12: IMPACT PROPAGATION ENGINE TESTS
Validates explainable causal propagation, multi-hop blast radius, automated risk triggering,
recursion prevention via correlation IDs, what-if simulations, and multi-tenant isolation.
"""

import pytest
import json
from datetime import datetime, date
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.department import Department
from database.models.inventory import Inventory
from database.models.customer import Customer
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.risk import Risk
from database.models.impact_trace import ImpactTrace, ImpactSeverity
from database.models.twin_dependency import TwinDependency, DependencyType
from services.events import DomainEvent, EventBus, EventTypes
from services.impact_engine import ImpactEngine
from security.rbac import Role, Permission


@pytest.fixture
def app():
    app = create_app({
        'TESTING': True,
        'SQLALCHEMY_DATABASE_URI': 'sqlite:///:memory:',
        'WTF_CSRF_ENABLED': False,
        'SECRET_KEY': 'test-secret-stage12'
    })
    with app.app_context():
        db.create_all()

        # Seed Company 1 (Tenant Alpha)
        comp_a = Company(
            company_name='Alpha Propulsion Corp',
            business_name='Alpha Propulsion',
            owner_name='Alice Alpha',
            ceo_name='Arthur Alpha',
            industry='Aerospace'
        )
        db.session.add(comp_a)

        # Seed Company 2 (Tenant Beta)
        comp_b = Company(
            company_name='Beta Diagnostics Lab',
            business_name='Beta Diagnostics',
            owner_name='Bob Beta',
            ceo_name='Boris Beta',
            industry='Healthcare'
        )
        db.session.add(comp_b)
        db.session.commit()

        # Seed Admin user for Company 1
        admin_user = User(
            username='alpha_admin_stage12',
            email='admin@alpha-propulsion.org',
            role=Role.ADMIN,
            company_id=comp_a.id
        )
        admin_user.set_password('password123')
        db.session.add(admin_user)

        # Seed Viewer user for Company 2
        beta_user = User(
            username='beta_viewer_stage12',
            email='viewer@beta-lab.org',
            role=Role.VIEWER,
            company_id=comp_b.id
        )
        beta_user.set_password('password123')
        db.session.add(beta_user)
        db.session.commit()

        EventBus.clear_subscribers()
        yield app
        EventBus.clear_subscribers()
        db.session.remove()
        db.drop_all()


@pytest.fixture
def admin_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='alpha_admin_stage12').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


@pytest.fixture
def beta_client(app):
    client = app.test_client()
    with app.app_context():
        user = User.query.filter_by(username='beta_viewer_stage12').first()
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['company_id'] = user.company_id
    return client


# =============================================================================
# 1. MULTI-TENANT TRACE ISOLATION
# =============================================================================

def test_multi_tenant_trace_isolation(app):
    """Verify that impact traces are strictly partitioned by tenant company_id."""
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()
        comp_b = Company.query.filter_by(company_name='Beta Diagnostics Lab').first()

        # Create trace for Tenant A
        trace_a = ImpactTrace(
            company_id=comp_a.id,
            trigger_type='test.mutation.a',
            root_entity_type='department',
            root_entity_id='101',
            severity=ImpactSeverity.HIGH,
            affected_nodes_count=3,
            max_depth=2,
            summary_text="Alpha trace"
        )
        trace_a.set_causal_steps([{'step_index': 1, 'description': 'Alpha step'}])
        db.session.add(trace_a)

        # Create trace for Tenant B
        trace_b = ImpactTrace(
            company_id=comp_b.id,
            trigger_type='test.mutation.b',
            root_entity_type='inventory',
            root_entity_id='202',
            severity=ImpactSeverity.CRITICAL,
            affected_nodes_count=5,
            max_depth=3,
            summary_text="Beta trace"
        )
        trace_b.set_causal_steps([{'step_index': 1, 'description': 'Beta step'}])
        db.session.add(trace_b)
        db.session.commit()

        trace_a_id = trace_a.trace_id
        trace_b_id = trace_b.trace_id

        # Query via ImpactEngine
        traces_for_a = ImpactEngine.get_recent_traces(company_id=comp_a.id)
        traces_for_b = ImpactEngine.get_recent_traces(company_id=comp_b.id)

        a_ids = [t['trace_id'] for t in traces_for_a]
        b_ids = [t['trace_id'] for t in traces_for_b]

        assert trace_a_id in a_ids
        assert trace_b_id not in a_ids

        assert trace_b_id in b_ids
        assert trace_a_id not in b_ids

        # Direct lookup by ID
        assert ImpactEngine.get_trace_by_id(comp_a.id, trace_a_id) is not None
        assert ImpactEngine.get_trace_by_id(comp_b.id, trace_a_id) is None


# =============================================================================
# 2. DEPARTMENT BUDGET BREACH & AUTOMATED RISK TRIGGER
# =============================================================================

def test_department_budget_breach_and_automated_risk(app):
    """
    Verify that an expense causing department spending to exceed budget
    triggers an explainable causal trace with HIGH/CRITICAL severity and creates a Risk.
    """
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()

        dept = Department(
            company_id=comp.id,
            name="Research & Development",
            budget=10000.0,
            head_name="Dr. Vance"
        )
        db.session.add(dept)
        db.session.flush()

        # Add expense exceeding the budget ($13,500 > $10,000 = 135% utilization)
        exp = FinancialRecord(
            company_id=comp.id,
            department_id=dept.id,
            amount=13500.0,
            transaction_type='expense',
            transaction_date=date.today(),
            category='R&D Equipment',
            description='Lab equipment upgrade'
        )
        db.session.add(exp)
        db.session.commit()

        captured_events = []
        def listener(ev):
            captured_events.append(ev)
        EventBus.subscribe('*', listener)

        # Trigger domain event
        event = DomainEvent.create(
            event_type=EventTypes.FINANCIAL_TRANSACTION_CREATED,
            company_id=comp.id,
            aggregate_type='financial_record',
            aggregate_id=str(exp.id),
            payload={'department_id': dept.id, 'amount': 13500.0}
        )

        trace = ImpactEngine.propagate_event(event, dry_run=False)

        assert trace is not None
        assert trace.company_id == comp.id
        assert trace.severity in [ImpactSeverity.HIGH, ImpactSeverity.CRITICAL]

        steps = trace.get_causal_steps()
        assert len(steps) >= 2
        # Check budget breach step
        breach_steps = [s for s in steps if "Department Budget Breach" in s.get('description', '')]
        assert len(breach_steps) == 1
        assert "135.0% utilization" in breach_steps[0]['description']

        # Assert automated Risk Engine trigger
        risk = Risk.query.filter_by(company_id=comp.id, name=f"Budget Breach: {dept.name}").first()
        assert risk is not None
        assert risk.status == 'active'
        assert risk.category == 'Financial'
        assert risk.risk_score > 0

        # Assert emitted domain events
        event_types = [e.event_type for e in captured_events]
        assert EventTypes.TWIN_IMPACT_RISK_TRIGGERED in event_types
        assert EventTypes.TWIN_IMPACT_PROPAGATED in event_types


# =============================================================================
# 3. INVENTORY STOCKOUT & LOW STOCK WARNING
# =============================================================================

def test_inventory_stockout_and_low_stock(app):
    """
    Verify that 0 quantity triggers CRITICAL stockout trace and automated Risk,
    while quantity <= reorder_point triggers MEDIUM low stock warning.
    """
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()

        # Stockout item (qty = 0)
        item_out = Inventory(
            company_id=comp.id,
            name="Lithium Battery Cell",
            sku="BAT-001",
            quantity_on_hand=0,
            reorder_point=25,
            unit_cost=45.0
        )
        # Low stock item (qty = 15, reorder = 20)
        item_low = Inventory(
            company_id=comp.id,
            name="Microcontroller IC",
            sku="MCU-002",
            quantity_on_hand=15,
            reorder_point=20,
            unit_cost=8.5
        )
        db.session.add_all([item_out, item_low])
        db.session.commit()

        # 1. Stockout propagation
        ev_out = DomainEvent.create(
            event_type=EventTypes.INVENTORY_ITEM_UPDATED,
            company_id=comp.id,
            aggregate_type='inventory',
            aggregate_id=str(item_out.id),
            payload={'quantity': 0, 'item_id': item_out.id}
        )
        trace_out = ImpactEngine.propagate_event(ev_out, dry_run=False)
        assert trace_out is not None
        assert trace_out.severity == ImpactSeverity.CRITICAL

        out_steps = [s for s in trace_out.get_causal_steps() if "Stockout Alert" in s.get('description', '')]
        assert len(out_steps) == 1

        # Check automated risk
        risk_out = Risk.query.filter_by(company_id=comp.id, name=f"Inventory Stockout: {item_out.name}").first()
        assert risk_out is not None
        assert risk_out.category == "Operational"
        assert risk_out.risk_level == "critical"

        # 2. Low stock propagation
        ev_low = DomainEvent.create(
            event_type=EventTypes.INVENTORY_ITEM_UPDATED,
            company_id=comp.id,
            aggregate_type='inventory',
            aggregate_id=str(item_low.id),
            payload={'quantity': 15, 'item_id': item_low.id}
        )
        trace_low = ImpactEngine.propagate_event(ev_low, dry_run=False)
        assert trace_low is not None
        assert trace_low.severity == ImpactSeverity.MEDIUM

        low_steps = [s for s in trace_low.get_causal_steps() if "Low Stock Warning" in s.get('description', '')]
        assert len(low_steps) == 1


# =============================================================================
# 4. CUSTOMER CHURN IMPACT
# =============================================================================

def test_customer_churn_impact(app):
    """Verify that customer deletion or churn status triggers causal revenue impact."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()

        cust = Customer(
            company_id=comp.id,
            company_name="Global Enterprise Client",
            status="active"
        )
        db.session.add(cust)
        db.session.commit()

        ev = DomainEvent.create(
            event_type=EventTypes.CUSTOMER_DELETED,
            company_id=comp.id,
            aggregate_type='customer',
            aggregate_id=str(cust.id),
            payload={'name': cust.full_name(), 'status': 'churned'}
        )

        trace = ImpactEngine.propagate_event(ev, dry_run=False)
        assert trace is not None
        assert trace.severity in [ImpactSeverity.MEDIUM, ImpactSeverity.HIGH]

        steps = trace.get_causal_steps()
        churn_step = [s for s in steps if "Customer Churn" in s.get('description', '')]
        assert len(churn_step) == 1
        assert churn_step[0]['target_id'] == 'metric:total_revenue'


# =============================================================================
# 5. RECURSION PREVENT & CYCLE GUARD
# =============================================================================

def test_recursion_prevention_and_cycle_guard(app):
    """
    Verify that internal twin.impact.* events are completely ignored by ImpactEngine,
    preventing infinite cascade, and that circular dependency graphs terminate gracefully.
    """
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()

        # 1. Self-trigger recursion guard
        impact_ev = DomainEvent.create(
            event_type=EventTypes.TWIN_IMPACT_PROPAGATED,
            company_id=comp.id,
            aggregate_type='impact_trace',
            aggregate_id='fake-trace-id'
        )
        result = ImpactEngine.propagate_event(impact_ev)
        assert result is None, "ImpactEngine must ignore twin.impact.* events to avoid infinite loops"

        risk_ev = DomainEvent.create(
            event_type=EventTypes.TWIN_IMPACT_RISK_TRIGGERED,
            company_id=comp.id,
            aggregate_type='risk',
            aggregate_id='123'
        )
        result_risk = ImpactEngine.propagate_event(risk_ev)
        assert result_risk is None

        # 2. Circular graph cycle guard
        d1 = Department(company_id=comp.id, name="Dept Alpha", budget=5000)
        d2 = Department(company_id=comp.id, name="Dept Beta", budget=5000)
        db.session.add_all([d1, d2])
        db.session.commit()

        # Create configured cycle: Dept Alpha -> Dept Beta -> Dept Alpha
        dep1 = TwinDependency(
            company_id=comp.id,
            source_type='department',
            source_id=str(d1.id),
            target_type='department',
            target_id=str(d2.id),
            dependency_type=DependencyType.CONFIGURED,
            strength=0.9
        )
        dep2 = TwinDependency(
            company_id=comp.id,
            source_type='department',
            source_id=str(d2.id),
            target_type='department',
            target_id=str(d1.id),
            dependency_type=DependencyType.CONFIGURED,
            strength=0.9
        )
        db.session.add_all([dep1, dep2])
        db.session.commit()

        # Propagate from Dept Alpha: should terminate cleanly without infinite loop or stack overflow
        trigger_ev = DomainEvent.create(
            event_type=EventTypes.DEPARTMENT_UPDATED,
            company_id=comp.id,
            aggregate_type='department',
            aggregate_id=str(d1.id),
            payload={'budget': 5000}
        )

        trace = ImpactEngine.propagate_event(trigger_ev, dry_run=False)
        assert trace is not None
        assert trace.max_depth <= ImpactEngine.MAX_PROPAGATION_DEPTH


# =============================================================================
# 6. WHAT-IF DRY RUN SIMULATION
# =============================================================================

def test_dry_run_what_if_simulation(app):
    """Verify that simulate_impact returns explainable predictions without saving records."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()

        dept = Department(company_id=comp.id, name="Operations Support", budget=8000)
        db.session.add(dept)
        db.session.commit()

        initial_trace_count = ImpactTrace.query.filter_by(company_id=comp.id).count()
        initial_risk_count = Risk.query.filter_by(company_id=comp.id).count()

        sim_result = ImpactEngine.simulate_impact(
            company_id=comp.id,
            root_type='department',
            root_id=str(dept.id),
            delta_payload={'budget': 8000}
        )

        assert sim_result['simulated'] is True
        assert sim_result['company_id'] == comp.id
        assert 'causal_steps' in sim_result
        assert len(sim_result['causal_steps']) >= 1

        # Assert zero side-effect persistence in dry-run
        final_trace_count = ImpactTrace.query.filter_by(company_id=comp.id).count()
        final_risk_count = Risk.query.filter_by(company_id=comp.id).count()

        assert final_trace_count == initial_trace_count
        assert final_risk_count == initial_risk_count


# =============================================================================
# 7. ROUTE INTEGRATION & ADMIN ACCESS
# =============================================================================

def test_impact_routes_admin_access(app, admin_client):
    """Verify that authenticated admin can simulate impact and query traces via HTTP."""
    with app.app_context():
        comp = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()
        dept = Department(company_id=comp.id, name="Flight Systems", budget=25000)
        db.session.add(dept)
        db.session.flush()

        # Seed an impact trace
        trace = ImpactTrace(
            company_id=comp.id,
            trigger_type='test.http.route',
            root_entity_type='department',
            root_entity_id=str(dept.id),
            severity=ImpactSeverity.MEDIUM,
            summary_text="HTTP Route Test Trace"
        )
        trace.set_causal_steps([{'step_index': 1, 'description': 'Initial trigger'}])
        db.session.add(trace)
        db.session.commit()

        trace_uuid = trace.trace_id
        dept_id_val = str(dept.id)

    # 1. Test POST /twin-graph/api/impact/simulate
    res_sim = admin_client.post('/twin-graph/api/impact/simulate', json={
        'root_type': 'department',
        'root_id': dept_id_val
    })
    assert res_sim.status_code == 200
    json_sim = res_sim.get_json()
    assert json_sim['success'] is True
    assert json_sim['data']['simulated'] is True

    # 2. Test GET /twin-graph/api/impact/traces
    res_traces = admin_client.get('/twin-graph/api/impact/traces')
    assert res_traces.status_code == 200
    json_traces = res_traces.get_json()
    assert json_traces['success'] is True
    assert len(json_traces['data']) >= 1

    # 3. Test GET /twin-graph/api/impact/traces/<trace_id>
    res_single = admin_client.get(f'/twin-graph/api/impact/traces/{trace_uuid}')
    assert res_single.status_code == 200
    json_single = res_single.get_json()
    assert json_single['success'] is True
    assert json_single['data']['trace_id'] == trace_uuid


# =============================================================================
# 8. TENANT IDOR FORBIDDEN
# =============================================================================

def test_impact_trace_tenant_idor_forbidden(app, beta_client):
    """Verify that a user from Company Beta cannot access an impact trace from Company Alpha."""
    with app.app_context():
        comp_a = Company.query.filter_by(company_name='Alpha Propulsion Corp').first()

        trace_a = ImpactTrace(
            company_id=comp_a.id,
            trigger_type='confidential.alpha.mutation',
            root_entity_type='financial_record',
            root_entity_id='999',
            severity=ImpactSeverity.CRITICAL,
            summary_text="Confidential Alpha Trace"
        )
        db.session.add(trace_a)
        db.session.commit()
        trace_a_uuid = trace_a.trace_id

    # Request with beta_client (Tenant Beta)
    res = beta_client.get(f'/twin-graph/api/impact/traces/{trace_a_uuid}')
    assert res.status_code == 404
    json_data = res.get_json()
    assert json_data['success'] is False
