"""
TEST SUITE: Stage 26 - Production Deployment Assets & Container Hardening
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. Multi-stage Dockerfile architecture (builder vs lean runtime stage).
2. Hardened non-root user (UID 10001) container execution.
3. Built-in container HEALTHCHECK targeting Stage 25 /healthz endpoint.
4. Air-gapped .dockerignore security exclusions (preventing credential / SQLite DB leakage).
5. Production Gunicorn configuration (threaded worker pool, timeouts, stdout logging).
6. Docker Compose multi-service orchestration (Web + PostgreSQL 16 + volumes + healthchecks).
7. Production security deployment checklist documentation.
"""

import os
import pytest


def test_dockerfile_multi_stage_architecture():
    """Verify Dockerfile utilizes multi-stage compilation for minimal runtime attack surface."""
    df_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'Dockerfile')
    assert os.path.exists(df_path), "Dockerfile not found in root directory!"

    with open(df_path, 'r', encoding='utf-8') as f:
        content = f.read()

    assert 'FROM python:3.11-slim AS builder' in content
    assert 'FROM python:3.11-slim AS runtime' in content
    assert 'COPY --from=builder /build/wheels /wheels' in content


def test_dockerfile_non_root_security():
    """Verify Dockerfile creates and switches to unprivileged non-root user."""
    df_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'Dockerfile')
    with open(df_path, 'r', encoding='utf-8') as f:
        content = f.read()

    assert '10001' in content
    assert 'useradd' in content
    assert 'USER aevoryn' in content


def test_dockerfile_healthcheck_and_ports():
    """Verify Dockerfile declares container healthcheck and exposes standard port."""
    df_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'Dockerfile')
    with open(df_path, 'r', encoding='utf-8') as f:
        content = f.read()

    assert 'HEALTHCHECK' in content
    assert '/healthz' in content
    assert 'EXPOSE 5000' in content
    assert 'gunicorn.conf.py' in content


def test_dockerignore_security_exclusions():
    """Verify .dockerignore excludes sensitive secrets, live databases, and artifacts."""
    di_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), '.dockerignore')
    assert os.path.exists(di_path), ".dockerignore not found!"

    with open(di_path, 'r', encoding='utf-8') as f:
        content = f.read()

    # Must exclude environment files and certificates
    assert '.env' in content
    # Must exclude live databases and backups
    assert 'instance/*.db' in content or '*.db' in content
    # Must exclude git metadata
    assert '.git' in content
    # Must exclude test and cache directories
    assert '__pycache__' in content
    assert '.pytest_cache' in content


def test_gunicorn_configuration():
    """Verify gunicorn.conf.py sets production threaded worker parameters."""
    conf_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'gunicorn.conf.py')
    assert os.path.exists(conf_path), "gunicorn.conf.py not found!"

    # Import configuration namespace
    namespace = {}
    with open(conf_path, 'r', encoding='utf-8') as f:
        exec(f.read(), namespace)

    assert '0.0.0.0:' in namespace['bind']
    assert namespace['worker_class'] == 'gthread'
    assert namespace['workers'] >= 2
    assert namespace['threads'] >= 2
    assert namespace['timeout'] >= 60
    assert namespace['accesslog'] == '-'
    assert namespace['errorlog'] == '-'


def test_docker_compose_stack():
    """Verify docker-compose.yml defines web and postgres services with healthchecks."""
    dc_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'docker-compose.yml')
    assert os.path.exists(dc_path), "docker-compose.yml not found!"

    with open(dc_path, 'r', encoding='utf-8') as f:
        content = f.read()

    assert 'services:' in content
    assert 'web:' in content
    assert 'db:' in content
    assert 'postgres:16' in content
    assert 'healthcheck:' in content
    assert 'pg_isready' in content
    assert 'aevoryn_internal' in content


def test_production_deployment_checklist():
    """Verify docs/PRODUCTION_DEPLOYMENT_CHECKLIST.md exists with all operational sections."""
    doc_path = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'docs', 'PRODUCTION_DEPLOYMENT_CHECKLIST.md')
    assert os.path.exists(doc_path), "Production checklist not found!"

    with open(doc_path, 'r', encoding='utf-8') as f:
        content = f.read()

    assert 'Secrets & Credentials Management' in content
    assert 'Infrastructure & Network Security' in content
    assert 'Database & Disaster Recovery' in content
    assert 'Observability & Monitoring' in content
