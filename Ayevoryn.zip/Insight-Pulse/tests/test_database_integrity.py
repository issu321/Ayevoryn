"""
AEVORYN / INSIGHT-PULSE
STAGE 4: DATABASE MIGRATIONS & INTEGRITY FOUNDATION TEST SUITE
Verifies:
1. SQLite PRAGMA foreign_keys = ON enforced across connections.
2. Foreign key constraints block invalid relational inserts.
3. Composite indexes exist in the live database schema.
4. Schema healing idempotence and automatic index synchronization.
5. CoreTwinExtraRecord orphan cleanup routine.
"""

import pytest
import sqlite3
from sqlalchemy import text
from sqlalchemy.exc import IntegrityError
from database.db import db, _heal_schema
from database.models.company import Company
from database.models.user import User
from database.models.financial import FinancialRecord, FinancialAccount
from database.models.simulation import Simulation
from database.models.custom_twin import CustomTwin, CustomTwinRecord
from database.models.core_twin_extra import CoreTwinExtraRecord


def test_sqlite_foreign_keys_pragma_enabled(app):
    """Verify PRAGMA foreign_keys is 1 (ON) for database connections."""
    with app.app_context():
        res = db.session.execute(text("PRAGMA foreign_keys;")).scalar()
        assert res == 1


def test_foreign_key_enforcement_blocks_invalid_child(app):
    """Verify that inserting a child record pointing to a non-existent parent raises IntegrityError."""
    with app.app_context():
        # Non-existent company_id = 99999999
        invalid_record = FinancialRecord(
            company_id=99999999,
            transaction_date=sqlite3.Date.today(),
            transaction_type='revenue',
            amount=1000.0
        )
        db.session.add(invalid_record)
        with pytest.raises(IntegrityError):
            db.session.commit()
        db.session.rollback()


def test_composite_indexes_exist(app):
    """Verify that high-frequency query composite indexes are registered in SQLite."""
    with app.app_context():
        rows = db.session.execute(
            text("SELECT name FROM sqlite_master WHERE type='index' AND name LIKE 'idx_%'")
        ).fetchall()
        index_names = {r[0] for r in rows}

        required_indexes = [
            'idx_financial_records_company_type_date',
            'idx_financial_records_company_date',
            'idx_financial_accounts_company_type',
            'idx_simulations_company_saved',
            'idx_simulations_company_type',
            'idx_custom_twins_company_active',
            'idx_custom_twins_company_slug',
            'idx_custom_twin_records_twin_active',
            'idx_custom_twin_records_company_twin',
        ]

        for req in required_indexes:
            assert req in index_names, f"Expected index {req} to exist in database"


def test_schema_healing_idempotence(app):
    """Verify that _heal_schema() can be executed repeatedly with zero errors or side effects."""
    with app.app_context():
        result1 = _heal_schema()
        assert isinstance(result1, dict)

        result2 = _heal_schema()
        assert isinstance(result2, dict)
        # On second execution with no schema changes, no new columns should be added
        assert len(result2) == 0


def test_core_twin_extra_orphan_cleanup(app):
    """Verify CoreTwinExtraRecord.cleanup_orphans removes dead pointer references."""
    with app.app_context():
        comp = Company.query.first()
        assert comp is not None

        # Create two extra records
        r1 = CoreTwinExtraRecord(
            company_id=comp.id,
            twin_key='employees',
            record_id=101,
            data='{"badge": "VIP"}'
        )
        r2 = CoreTwinExtraRecord(
            company_id=comp.id,
            twin_key='employees',
            record_id=102,
            data='{"badge": "STANDARD"}'
        )
        db.session.add_all([r1, r2])
        db.session.commit()

        # Simulate that employee 102 was deleted: valid_record_ids only includes 101
        deleted = CoreTwinExtraRecord.cleanup_orphans(
            company_id=comp.id,
            twin_key='employees',
            valid_record_ids=[101]
        )
        assert deleted == 1

        remaining = CoreTwinExtraRecord.query.filter_by(
            company_id=comp.id, twin_key='employees'
        ).all()
        assert len(remaining) == 1
        assert remaining[0].record_id == 101

        # Clean up r1 as well
        CoreTwinExtraRecord.cleanup_orphans(comp.id, 'employees', [])
        final_check = CoreTwinExtraRecord.query.filter_by(
            company_id=comp.id, twin_key='employees'
        ).all()
        assert len(final_check) == 0
