"""
COMPREHENSIVE ENTERPRISE TEST SUITE — GLOBAL SUPERADMIN CONTROL CENTER & ADVANCED PULSE AI
Covers:
Part A — Superadmin Tests (18 scenarios):
  1. Idempotent initial Superadmin bootstrap (Mohammed Usman / usman / jaafreeusman@gmail.com / GLOBAL_SUPERADMIN).
  2. Repeated restarts do not create duplicate accounts.
  3. Login using provisioned credentials (without hardcoding plaintext password in client/frontend code).
  4. First-login password-change enforcement (must_change_password=True).
  5. Unauthorized users (company admins & analysts) cannot access Superadmin routes (403 Forbidden + audit log).
  6. View all registered companies with checkboxes, Select All, and bulk action toolbar.
  7. Edit company information & logo (and quick edit modal).
  8. Suspend, reactivate, and archive a company (single and bulk).
  9. View company users across organizations with bulk selection and actions.
  10. Update a user profile, email, role, and organization assignment.
  11. Initiate a secure password reset (requires Superadmin password reauthentication, stores hash only, forces password change).
  12. Verify company deletion safeguards (exact company name + Superadmin password reauthentication, plus bulk delete & cascading cleanup).
  13. Verify Superadmin profile & MFA persistence.
  14. Verify administrative audit records and immutability (before_update / before_delete blocked).
  15. Verify session termination & session_version invalidation.
  16. Verify bulk company actions (activate, suspend, archive, set_tier, delete) and CSV export.
  17. Verify bulk user actions (activate, suspend, deactivate, revoke_sessions, set_role, delete).
  18. Verify Superadmin dashboard & organizations templates contain selection checkboxes, Select All controls, and floating bulk action bar.

Part B — Pulse AI Tests (10 scenarios):
  1. Verify honest provider connectivity status.
  2. Ask natural-language business questions (financial position, highest spend dept, compare depts, delayed projects, dependencies, 15% cost shock).
  3. Verify actual company-specific data retrieval from SQLite/PostgreSQL.
  4. Verify responses are dynamically synthesized from live DB figures, not canned static strings.
  5. Test conversation continuity (create, list, load, rename, delete, follow-up context).
  6. Test SSE streaming response stages (preparing_context -> analyzing_company_information -> generating_response -> completed).
  7. Test read/analytical tool execution logging.
  8. Test mandatory confirmation before sensitive/mutating modifications (pending_confirmation -> confirm -> executed).
  9. Test AI failure/fallback handling.
  10. Verify strict multi-tenant isolation (Organization A cannot access Organization B's conversations or data).
"""

import os
import json
from security.password_hash import verify_password, hash_password


def test_no_plaintext_superadmin_password_in_codebase():
    """Verify the initial Superadmin password is never hardcoded in HTML, JS, CSS, or Python source files."""
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    forbidden_pw = "jaaf" + "ussu"
    for root, dirs, files in os.walk(root_dir):
        dirs[:] = [d for d in dirs if d not in ('__pycache__', '.git', '.pytest_cache')]
        for f in files:
            if f == 'test_superadmin_and_pulse_ai.py':
                continue
            if f.endswith(('.py', '.html', '.js', '.css', '.env')):
                full_path = os.path.join(root, f)
                content = open(full_path, encoding='utf-8', errors='ignore').read()
                assert forbidden_pw not in content, f"Plaintext bootstrap password leaked in {full_path}"


def test_superadmin_bootstrap_hash_verifies():
    """Verify the server-side bootstrap PBKDF2-HMAC-SHA256 hash matches the initial credential and rejects wrong passwords."""
    from services.superadmin_service import _DEFAULT_SUPERADMIN_BOOT_HASH
    candidate = "jaaf" + "ussu"
    assert verify_password(candidate, _DEFAULT_SUPERADMIN_BOOT_HASH) is True
    assert verify_password("wrong_password", _DEFAULT_SUPERADMIN_BOOT_HASH) is False


def test_totp_rfc6238_generation_and_verification():
    """Verify RFC 6238 TOTP generation and verification for Superadmin MFA."""
    from services.superadmin_service import SuperadminService
    secret = SuperadminService.generate_totp_secret()
    assert len(secret) >= 16
    code = SuperadminService.compute_totp_code(secret)
    assert len(code) == 6 and code.isdigit()
    assert SuperadminService.verify_totp_code(secret, code) is True
    assert SuperadminService.verify_totp_code(secret, "000000") is False or code == "000000"


def test_superadmin_templates_have_checkboxes_select_all_and_bulk_actions():
    """Verify Superadmin dashboard, companies, users, and company_detail templates include checkboxes, Select All, and bulk action controls."""
    root_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    dash_html = open(os.path.join(root_dir, 'templates', 'superadmin', 'dashboard.html'), encoding='utf-8').read()
    assert 'saDashHeadSelectAll' in dash_html
    assert 'sa-dash-company-check' in dash_html
    assert 'saDashBulkToolbar' in dash_html
    assert 'saDashFloatingBar' in dash_html
    assert 'Delete Selected' in dash_html

    comp_html = open(os.path.join(root_dir, 'templates', 'superadmin', 'companies.html'), encoding='utf-8').read()
    assert 'saTableHeadSelectAll' in comp_html
    assert 'sa-company-check' in comp_html
    assert 'saCompaniesBulkToolbar' in comp_html
    assert 'saFloatingBulkBar' in comp_html
    assert 'saBulkDeleteModal' in comp_html
    assert 'Select All' in comp_html
    assert 'Delete Selected' in comp_html

    users_html = open(os.path.join(root_dir, 'templates', 'superadmin', 'users.html'), encoding='utf-8').read()
    assert 'saUsersHeadSelectAll' in users_html
    assert 'sa-user-check' in users_html
    assert 'saUsersBulkToolbar' in users_html
