"""
Test Suite for UI/UX Transformation & Intelligent Navigation
Verifies:
1. Sidebar collapse toggle is on the sidebar itself (#sidebarCollapseBtn)
2. Desktop top-bar hamburger button is removed (#sidebarToggleBtn not in topbar)
3. Sticky top-bar breadcrumb and executive controls render properly
4. All public pages render 200 OK with the unified floating navbar
"""
import pytest
from app import create_app
from database import db
from database.models.user import User
from database.models.company import Company


@pytest.fixture
def client():
    app = create_app()
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = False
    with app.test_client() as client:
        with app.app_context():
            yield client


def test_public_pages_render_successfully(client):
    """Verify all public marketing and landing pages render HTTP 200 OK."""
    endpoints = [
        '/',
        '/features',
        '/architecture',
        '/decision-models',
        '/dependency-intelligence',
        '/login',
        '/register',
    ]
    for url in endpoints:
        resp = client.get(url)
        assert resp.status_code == 200, f"Endpoint {url} failed with status {resp.status_code}"
        html = resp.data.decode('utf-8')
        # Check brand name exists
        assert 'AEVORYN' in html


def test_authenticated_sidebar_and_topbar_structure(client):
    """Verify authenticated layout: sidebar collapse button is on sidebar, not in topbar."""
    with client.application.app_context():
        user = User.query.first()
        company = Company.query.first()
        user_id = user.id if user else 1
        company_id = company.id if company else 1

    # Log in
    with client.session_transaction() as sess:
        sess['_user_id'] = str(user_id)
        sess['company_id'] = company_id
        sess['_fresh'] = True

    resp = client.get('/dashboard')
    assert resp.status_code == 200
    html = resp.data.decode('utf-8')

    # 1. Dedicated sidebar collapse button exists on the sidebar
    assert 'id="sidebarCollapseBtn"' in html
    assert 'toggleSidebarCollapse()' in html

    # 2. Desktop top-bar toggle button (#sidebarToggleBtn) is removed from top-bar
    assert 'id="sidebarToggleBtn"' not in html

    # 3. Mobile-only drawer opener exists
    assert 'id="mobileDrawerOpenBtn"' in html

    # 4. Top-bar breadcrumb exists
    assert 'topbar-breadcrumb-wrap' in html
    assert 'topbar-page-title' in html
