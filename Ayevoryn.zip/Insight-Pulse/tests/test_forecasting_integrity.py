"""
STAGE 16: FORECASTING INTEGRITY AUTOMATED TEST SUITE.
Validates:
1. Honest Model Registry metadata, mathematical families, and threshold gating.
2. Data Readiness categorization (INSUFFICIENT vs LIMITED vs SUFFICIENT vs ROBUST).
3. Rejection of unflagged empirical forecasts on sparse transaction history (<14d).
4. Explicit heuristic labeling when allow_heuristic=True.
5. Out-of-sample holdout backtesting (MAE, RMSE, MAPE, Directional Accuracy, Coverage).
6. Variance-weighted ensemble modeling combining base models.
7. Model comparison leaderboard and automatic best-fit model selection.
8. Strict multi-tenant IDOR protection (HTTP 404).
9. RBAC authorization enforcement (Viewer role receives HTTP 403 on mutations).
10. Domain events emission on forecast generation and deletion.
"""

import pytest
from datetime import datetime, timedelta, date
from flask import session
from database.db import db
from database.models.company import Company
from database.models.user import User
from database.models.financial import FinancialRecord
from database.models.forecast import (
    Forecast, ForecastResult, ForecastModelFamily, DataReadinessLevel, ForecastStatus
)
from database.models.business_event import BusinessEvent
from database.models.activity_log import ActivityLog
from database.models.audit_log import AuditLog
from services.forecasting import (
    ForecastModelRegistry, ModelDefinition, DataReadinessService, BacktestEngine
)
from services.forecast_service import ForecastService
from services.events import EventBus, EventTypes
from security.rbac import Role


def _clean_s16_data():
    """Safely delete Stage 16 test tenants and all child records across all tables."""
    try:
        db.session.rollback()
        db.session.close()
    except Exception:
        pass
    conn = db.engine.raw_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("PRAGMA foreign_keys = OFF")
        cursor.execute("SELECT id FROM companies WHERE business_name IN ('Stage16 Alpha Corp', 'Stage16 Beta Corp')")
        comp_ids = [r[0] for r in cursor.fetchall()]
        if comp_ids:
            ids_str = ','.join(str(i) for i in comp_ids)
            cursor.execute(f"DELETE FROM forecast_results WHERE forecast_id IN (SELECT id FROM forecasts WHERE company_id IN ({ids_str}))")
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [r[0] for r in cursor.fetchall() if r[0] != 'companies']
            for t in tables:
                try:
                    cursor.execute(f"DELETE FROM [{t}] WHERE company_id IN ({ids_str})")
                except Exception:
                    pass
            cursor.execute(f"DELETE FROM companies WHERE id IN ({ids_str})")
        cursor.execute("DELETE FROM users WHERE username LIKE 's16_%' OR email LIKE 's16_%'")
        conn.commit()
        cursor.execute("PRAGMA foreign_keys = ON")
    finally:
        cursor.close()
        conn.close()


@pytest.fixture
def forecast_tenants(app):
    """Set up isolated Tenant Alpha and Tenant Beta with users and initial ledger data."""
    with app.app_context():
        # Clean up any leftover test data
        _clean_s16_data()

        # Create Tenant Alpha
        comp_a = Company(
            company_name='Stage16 Alpha Corp',
            business_name='Stage16 Alpha Corp',
            owner_name='Alpha Owner',
            ceo_name='Alpha CEO',
            industry='Technology',
            currency='USD',
            annual_revenue=1200000.0,
            annual_expenses_plan=900000.0,
            customer_count=50,
            employee_count=10
        )
        db.session.add(comp_a)
        db.session.flush()

        user_admin_a = User(
            username='s16_admin_a',
            email='s16_admin_a@alpha.com',
            company_id=comp_a.id,
            role=Role.ADMIN
        )
        user_admin_a.set_password('Secret123!')
        db.session.add(user_admin_a)

        user_viewer_a = User(
            username='s16_viewer_a',
            email='s16_viewer_a@alpha.com',
            company_id=comp_a.id,
            role=Role.VIEWER
        )
        user_viewer_a.set_password('Secret123!')
        db.session.add(user_viewer_a)

        # Create Tenant Beta
        comp_b = Company(
            company_name='Stage16 Beta Corp',
            business_name='Stage16 Beta Corp',
            owner_name='Beta Owner',
            ceo_name='Beta CEO',
            industry='Retail',
            currency='USD',
            annual_revenue=500000.0,
            annual_expenses_plan=400000.0,
            customer_count=20,
            employee_count=5
        )
        db.session.add(comp_b)
        db.session.flush()

        user_admin_b = User(
            username='s16_admin_b',
            email='s16_admin_b@beta.com',
            company_id=comp_b.id,
            role=Role.ADMIN
        )
        user_admin_b.set_password('Secret123!')
        db.session.add(user_admin_b)

        # Seed 40 days of continuous transactions for Tenant Alpha
        today = datetime.now().date()
        for i in range(40):
            d = today - timedelta(days=40 - i)
            rev_amt = 3000.0 + (i * 25.0) + (100.0 if i % 2 == 0 else -50.0)
            exp_amt = 2000.0 + (i * 15.0)

            db.session.add(FinancialRecord(
                company_id=comp_a.id,
                transaction_date=d,
                transaction_type='revenue',
                amount=rev_amt,
                category='Sales'
            ))
            db.session.add(FinancialRecord(
                company_id=comp_a.id,
                transaction_date=d,
                transaction_type='expense',
                amount=exp_amt,
                category='Payroll'
            ))

        db.session.commit()

        yield {
            'comp_a_id': comp_a.id,
            'user_admin_a_id': user_admin_a.id,
            'user_viewer_a_id': user_viewer_a.id,
            'comp_b_id': comp_b.id,
            'user_admin_b_id': user_admin_b.id
        }

        # Cleanup
        try:
            _clean_s16_data()
        except Exception:
            db.session.rollback()


def test_model_registry_metadata_and_classification():
    """Validates that all registered models have honest mathematical descriptions and no AI hype."""
    models = ForecastModelRegistry.list_models()
    assert len(models) >= 5

    model_ids = {m.id for m in models}
    assert 'linear_regression' in model_ids
    assert 'moving_average' in model_ids
    assert 'weighted_ensemble' in model_ids

    for m in models:
        # Strictly verify no deceptive AI marketing claims
        assert 'neural' not in m.name.lower()
        assert 'deep learning' not in m.name.lower()
        assert 'magical' not in m.description.lower()
        assert m.min_observations >= 7
        assert m.family in [
            ForecastModelFamily.STATISTICAL_REGRESSION,
            ForecastModelFamily.MOVING_AVERAGE,
            ForecastModelFamily.EXPONENTIAL_SMOOTHING,
            ForecastModelFamily.AUTOREGRESSIVE_INTEGRATED,
            ForecastModelFamily.SEASONAL_DECOMPOSITION,
            ForecastModelFamily.ENSEMBLE_BLENDED
        ]
        assert len(m.assumptions) >= 2


def test_data_readiness_assessment_levels(app, forecast_tenants):
    """Validates data readiness tiers based on real observation density."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        comp_b_id = forecast_tenants['comp_b_id']

        # Tenant Alpha has 40 continuous observation days -> SUFFICIENT
        report_a = DataReadinessService.assess_readiness(comp_a_id, 'revenue')
        assert report_a.level == DataReadinessLevel.SUFFICIENT
        assert report_a.distinct_dates_count == 40
        assert report_a.is_sufficient_for_empirical is True
        assert 'linear_regression' in report_a.eligible_models
        assert 'moving_average' in report_a.eligible_models

        # Tenant Beta has 0 transactions -> INSUFFICIENT
        report_b = DataReadinessService.assess_readiness(comp_b_id, 'revenue')
        assert report_b.level == DataReadinessLevel.INSUFFICIENT
        assert report_b.distinct_dates_count == 0
        assert report_b.is_sufficient_for_empirical is False
        assert 'minimum of 14 continuous observation dates' in report_b.diagnostic_message


def test_refusal_to_fabricate_empirical_forecast_on_insufficient_data(app, forecast_tenants):
    """Confirms service halts and sets insufficient_data status instead of generating fake random charts."""
    with app.app_context():
        comp_b_id = forecast_tenants['comp_b_id']
        user_b_id = forecast_tenants['user_admin_b_id']

        # Run without allow_heuristic flag
        forecast = ForecastService.generate_forecast(
            company_id=comp_b_id,
            user_id=user_b_id,
            forecast_type='revenue',
            method='linear_regression',
            horizon_days=30,
            name='Premature Forecast',
            allow_heuristic=False
        )

        assert forecast.status == ForecastStatus.INSUFFICIENT_DATA
        assert forecast.data_readiness == DataReadinessLevel.INSUFFICIENT
        assert forecast.observation_count == 0
        assert forecast.is_synthetic_heuristic is False
        # Results must be empty
        assert forecast.results.count() == 0
        assert 'Insufficient transaction history' in forecast.summary


def test_honest_heuristic_scenario_mode(app, forecast_tenants):
    """Validates that heuristic mode explicitly stamps projections as synthetic and non-audited."""
    with app.app_context():
        comp_b_id = forecast_tenants['comp_b_id']
        user_b_id = forecast_tenants['user_admin_b_id']

        # Run with allow_heuristic=True
        forecast = ForecastService.generate_forecast(
            company_id=comp_b_id,
            user_id=user_b_id,
            forecast_type='revenue',
            method='linear_regression',
            horizon_days=30,
            name='Heuristic Scenario',
            allow_heuristic=True
        )

        assert forecast.status == ForecastStatus.COMPLETED
        assert forecast.is_synthetic_heuristic is True
        assert forecast.data_readiness == 'INSUFFICIENT_HEURISTIC'
        assert forecast.results.count() == 30
        assert forecast.summary.startswith('[HEURISTIC ESTIMATE]')


def test_out_of_sample_holdout_backtesting(app, forecast_tenants):
    """Validates that forecasts on sufficient data compute true out-of-sample backtest metrics."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        user_a_id = forecast_tenants['user_admin_a_id']

        forecast = ForecastService.generate_forecast(
            company_id=comp_a_id,
            user_id=user_a_id,
            forecast_type='revenue',
            method='linear_regression',
            horizon_days=30,
            name='Empirical Revenue Forecast',
            allow_heuristic=False
        )

        assert forecast.status == ForecastStatus.COMPLETED
        assert forecast.is_synthetic_heuristic is False
        assert forecast.is_backtested is True
        assert forecast.backtest_split_days >= 7
        assert forecast.backtest_mae is not None and forecast.backtest_mae > 0
        assert forecast.backtest_rmse is not None and forecast.backtest_rmse > 0
        assert forecast.backtest_mape is not None and forecast.backtest_mape > 0
        assert 0.0 <= forecast.backtest_directional_accuracy <= 100.0
        assert 0.0 <= forecast.backtest_coverage <= 100.0

        bt_data = forecast.get_backtest_results()
        assert len(bt_data['actuals']) == forecast.backtest_split_days
        assert len(bt_data['predictions']) == forecast.backtest_split_days
        assert len(bt_data['test_dates']) == forecast.backtest_split_days


def test_weighted_ensemble_model(app, forecast_tenants):
    """Validates variance-weighted multi-model ensemble forecast execution."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        user_a_id = forecast_tenants['user_admin_a_id']

        forecast = ForecastService.generate_forecast(
            company_id=comp_a_id,
            user_id=user_a_id,
            forecast_type='revenue',
            method='weighted_ensemble',
            horizon_days=30,
            name='Ensemble Projection'
        )

        assert forecast.status == ForecastStatus.COMPLETED
        assert forecast.model_family == ForecastModelFamily.ENSEMBLE_BLENDED
        assert forecast.results.count() == 30
        first_res = forecast.results.first()
        assert first_res.value > 0
        assert first_res.lower_bound <= first_res.value <= first_res.upper_bound


def test_model_comparison_and_best_fit(app, forecast_tenants):
    """Validates multi-model backtest comparison leaderboard and auto selection."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        user_a_id = forecast_tenants['user_admin_a_id']

        comp = ForecastService.compare_models(comp_a_id, 'revenue', horizon_days=30)
        assert len(comp['ranked_models']) >= 2
        # Verify ranked ascending by RMSE
        for i in range(len(comp['ranked_models']) - 1):
            assert comp['ranked_models'][i]['rmse'] <= comp['ranked_models'][i + 1]['rmse']

        best_model = comp['best_model_id']
        assert best_model is not None

        # Test auto selection route
        forecast = ForecastService.generate_forecast(
            company_id=comp_a_id,
            user_id=user_a_id,
            forecast_type='revenue',
            method='auto',
            horizon_days=30,
            name='Auto Best Fit'
        )
        assert forecast.status == ForecastStatus.COMPLETED
        assert forecast.method == best_model


def test_forecasting_cross_tenant_idor_protection(client, app, forecast_tenants):
    """Ensures HTTP 404 is returned when attempting to access another tenant's forecasts."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        user_a_id = forecast_tenants['user_admin_a_id']
        user_b_id = forecast_tenants['user_admin_b_id']

        # Create forecast belonging to Tenant Alpha
        f_a = Forecast(
            company_id=comp_a_id,
            user_id=user_a_id,
            name='Tenant Alpha Secret Forecast',
            forecast_type='revenue',
            method='linear_regression',
            status=ForecastStatus.COMPLETED
        )
        db.session.add(f_a)
        db.session.commit()
        target_f_id = f_a.id

    # Authenticate as Tenant Beta
    with client.session_transaction() as sess:
        sess['user_id'] = user_b_id
        sess['_user_id'] = str(user_b_id)
        sess['company_id'] = forecast_tenants['comp_b_id']
        sess['role'] = Role.ADMIN

    # 1. View route must 404
    resp = client.get(f'/forecasting/view/{target_f_id}')
    assert resp.status_code == 404

    # 2. Rerun route must 404
    resp = client.post(f'/forecasting/rerun/{target_f_id}')
    assert resp.status_code == 404

    # 3. Delete route must 404
    resp = client.post(f'/forecasting/delete/{target_f_id}')
    assert resp.status_code == 404

    # 4. API Data route must 404
    resp = client.get(f'/forecasting/api/data/{target_f_id}')
    assert resp.status_code == 404


def test_forecasting_viewer_rbac_rejection(client, app, forecast_tenants):
    """Ensures users with Viewer role receive HTTP 403 Forbidden on forecast mutations."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        viewer_a_id = forecast_tenants['user_viewer_a_id']

        f_a = Forecast(
            company_id=comp_a_id,
            user_id=forecast_tenants['user_admin_a_id'],
            name='Alpha Forecast',
            forecast_type='revenue',
            method='linear_regression',
            status=ForecastStatus.COMPLETED
        )
        db.session.add(f_a)
        db.session.commit()
        f_id = f_a.id

    with client.session_transaction() as sess:
        sess['user_id'] = viewer_a_id
        sess['_user_id'] = str(viewer_a_id)
        sess['company_id'] = comp_a_id
        sess['role'] = Role.VIEWER

    # 1. POST /forecasting/run forbidden for Viewer
    resp = client.post('/forecasting/run', data={
        'name': 'Unauthorized Run',
        'forecast_type': 'revenue',
        'method': 'linear_regression',
        'horizon_days': 30
    })
    assert resp.status_code == 403

    # 2. POST /forecasting/rerun forbidden for Viewer
    resp = client.post(f'/forecasting/rerun/{f_id}')
    assert resp.status_code == 403

    # 3. POST /forecasting/delete forbidden for Viewer
    resp = client.post(f'/forecasting/delete/{f_id}')
    assert resp.status_code == 403


def test_forecasting_domain_events_published(app, forecast_tenants):
    """Validates that forecast operations emit domain events into EventBus."""
    with app.app_context():
        comp_a_id = forecast_tenants['comp_a_id']
        user_a_id = forecast_tenants['user_admin_a_id']

        events_received = []

        def handle_event(event):
            events_received.append(event)

        EventBus.subscribe(EventTypes.FORECAST_GENERATED, handle_event)
        EventBus.subscribe(EventTypes.FORECAST_DELETED, handle_event)

        forecast = ForecastService.generate_forecast(
            company_id=comp_a_id,
            user_id=user_a_id,
            forecast_type='revenue',
            method='linear_regression',
            horizon_days=30,
            name='Event Test Forecast'
        )

        gen_events = [e for e in events_received if e.event_type == EventTypes.FORECAST_GENERATED]
        assert len(gen_events) >= 1
        assert gen_events[0].payload['forecast_id'] == forecast.id
        assert gen_events[0].payload['company_id'] == comp_a_id

        f_id = forecast.id
        ForecastService.delete_forecast(f_id, company_id=comp_a_id)

        del_events = [e for e in events_received if e.event_type == EventTypes.FORECAST_DELETED]
        assert del_events[0].payload['forecast_id'] == f_id