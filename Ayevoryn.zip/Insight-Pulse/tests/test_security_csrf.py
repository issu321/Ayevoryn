import pytest
from app import app
from flask_wtf.csrf import generate_csrf
from database.models.user import User

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['WTF_CSRF_ENABLED'] = True
    with app.test_client() as client:
        yield client

def test_post_without_csrf_is_blocked(client):
    """POST requests without CSRF token must be rejected with HTTP 400."""
    # Attempt login without CSRF token
    res = client.post('/login', data={'username': 'admin', 'password': '123456'})
    assert res.status_code == 400, f"Expected 400 Bad Request, got {res.status_code}"

def test_post_with_invalid_csrf_is_blocked(client):
    """POST requests with invalid CSRF token must be rejected with HTTP 400."""
    res = client.post('/login', 
                      data={'username': 'admin', 'password': '123456', 'csrf_token': 'fake-invalid-token-123'},
                      headers={'X-CSRFToken': 'fake-invalid-token-123'})
    assert res.status_code == 400, f"Expected 400 Bad Request, got {res.status_code}"

def test_post_with_valid_csrf_token_is_accepted(client):
    """POST requests with valid session-bound CSRF token must be accepted."""
    # First GET to initialize session and retrieve CSRF token
    get_res = client.get('/login')
    assert get_res.status_code == 200
    
    with client.session_transaction() as sess:
        csrf_token = sess.get('csrf_token')
    
    # Generate valid token in request context
    with app.test_request_context():
        token = generate_csrf()
        
    res = client.post('/login', 
                      data={'username': 'admin', 'password': '123456'},
                      headers={'X-CSRFToken': token})
    # Valid login redirects to dashboard (302)
    assert res.status_code == 302, f"Expected 302 Redirect with valid CSRF, got {res.status_code}"

def test_json_post_without_csrf_returns_json_400(client):
    """JSON POST requests without CSRF must receive JSON 400 response."""
    res = client.post('/recover-account', json={'identifier': 'admin', 'answer1': 'a', 'answer2': 'b', 'new_password': 'pass'})
    assert res.status_code == 400
    data = res.get_json()
    assert data is not None
    assert data.get('error') == 'CSRF Error'
