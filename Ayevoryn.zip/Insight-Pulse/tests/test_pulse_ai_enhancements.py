"""
Tests for Pulse AI Enhancements:
- Specific prompt handling for accounts, revenue, expenses, employees, department deep dives, runway, and greetings.
- Accurate data-grounding from company database (no static boilerplate).
- Streaming endpoint token generation cadence and event structures.
"""

import pytest
from app import create_app
from database.db import db
from database.models.company import Company
from database.models.user import User
from services.pulse_ai_engine import PulseAIEngine, PulseAIContextRetriever


@pytest.fixture
def app_instance():
    app = create_app()
    app.config['TESTING'] = True
    return app


@pytest.fixture
def client(app_instance):
    return app_instance.test_client()


def test_accounts_intent_returns_real_financial_accounts(app_instance):
    with app_instance.app_context():
        # Test Company 2 (USMANIA INDUSTRIES)
        domains = PulseAIContextRetriever.detect_domains('accounts')
        assert 'accounts' in domains
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        assert 'accounts' in ctx
        assert ctx['accounts']['total_liquid_reserves'] == 100000.0

        res = PulseAIEngine.synthesize_analytical_response('accounts', ctx)
        assert 'Treasury & Accounts Audit' in res['headline']
        assert '₹100,000.00' in res['markdown']
        assert 'CBoi — Current' in res['markdown']
        assert 'Corporate Treasury Reserves' in res['markdown']
        assert 'UPI Instant Settlement' in res['markdown']
        assert len(res['tables']) >= 1


def test_revenue_intent_returns_real_sales_metrics(app_instance):
    with app_instance.app_context():
        domains = PulseAIContextRetriever.detect_domains('What is our revenue?')
        assert 'financials' in domains
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        res = PulseAIEngine.synthesize_analytical_response('What is our revenue?', ctx)
        assert 'Revenue Velocity Audit' in res['headline']
        assert 'revenue' in res['markdown'].lower()


def test_workforce_intent_returns_real_headcount_and_payroll(app_instance):
    with app_instance.app_context():
        domains = PulseAIContextRetriever.detect_domains('Who works here?')
        assert 'employees' in domains
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        res = PulseAIEngine.synthesize_analytical_response('Who works here?', ctx)
        assert 'Workforce Structure Audit' in res['headline']
        expected_hc = str(ctx['employees']['company_reported_headcount'])
        assert expected_hc in res['markdown']
        assert 'IT' in res['markdown']


def test_department_deep_dive_returns_specific_department(app_instance):
    with app_instance.app_context():
        domains = PulseAIContextRetriever.detect_domains('tell me about IT department')
        assert 'departments' in domains
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        res = PulseAIEngine.synthesize_analytical_response('tell me about IT department', ctx)
        assert 'Department Audit: IT' in res['headline']
        assert '104' in res['markdown']


def test_greetings_intent_returns_executive_introduction(app_instance):
    with app_instance.app_context():
        domains = PulseAIContextRetriever.detect_domains('hi')
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        res = PulseAIEngine.synthesize_analytical_response('hi', ctx)
        assert 'Pulse AI Executive Intelligence' in res['headline']
        assert 'Hello! I am **Pulse AI**' in res['markdown']


def test_dynamic_fallback_is_prompt_aware(app_instance):
    with app_instance.app_context():
        prompt = 'What is our strategy for market expansion?'
        domains = PulseAIContextRetriever.detect_domains(prompt)
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        res = PulseAIEngine.synthesize_analytical_response(prompt, ctx)
        assert 'Executive Brief:' in res['headline']
        assert prompt in res['markdown']


def test_health_score_and_customer_records_intents(app_instance):
    with app_instance.app_context():
        domains = PulseAIContextRetriever.detect_domains('what is the health')
        ctx = PulseAIContextRetriever.retrieve_company_context(2, domains)
        res_health = PulseAIEngine.synthesize_analytical_response('what is the health', ctx)
        assert 'Enterprise Health Diagnostic' in res_health['headline']
        assert '5-Pillar' in res_health['markdown']

        domains_cust = PulseAIContextRetriever.detect_domains('how may customer records')
        ctx_cust = PulseAIContextRetriever.retrieve_company_context(2, domains_cust)
        res_cust = PulseAIEngine.synthesize_analytical_response('how may customer records', ctx_cust)
        assert 'CRM Customer Intelligence' in res_cust['headline']
        assert '16 Customer Records' in res_cust['headline']
        assert 'Acme Corp' in res_cust['markdown']
