"""
Stage 31: Technical Documentation Verification Test Suite
Validates that all required enterprise technical specifications exist,
are non-empty, include required structural headings, and contain valid syntax.
"""

import os
import pytest

DOCS_DIR = 'docs'

REQUIRED_DOCS = [
    ('ENTERPRISE_ARCHITECTURE.md', ['Architectural Overview', 'Seven-Pillar Digital Twin Ontology', 'Event-Driven Architecture', 'Scenario Branching']),
    ('SECURITY_AND_COMPLIANCE.md', ['Multi-Tenant Data Isolation', 'Role-Based Access Control', 'Cryptographic Security', 'CSRF', 'SOC 2']),
    ('DATA_PROVENANCE_AND_FINANCIAL_MATHEMATICS.md', ['Canonical Business State', 'Cash Runway Formula', 'Profit & Margin', 'Monte Carlo', 'Forecasting Honesty']),
    ('API_REFERENCE_V1.md', ['API Architecture', 'Authentication', 'Standard Response Envelope', 'Endpoints Catalog']),
    ('OPERATIONAL_RUNBOOK.md', ['Environment Configuration', 'Containerized Deployment', 'Kubernetes', 'Backup & Disaster Recovery']),
    ('POSTGRESQL_MIGRATION_GUIDE.md', ['Architectural Overview', 'Environment Configuration', 'Schema Management', 'Cutover Playbook']),
    ('PRODUCTION_DEPLOYMENT_CHECKLIST.md', ['Secrets & Credentials Management', 'Infrastructure & Network Security', 'Database & Disaster Recovery', 'Observability & Monitoring'])
]

@pytest.mark.parametrize("filename,required_sections", REQUIRED_DOCS)
def test_documentation_file_exists_and_complete(filename, required_sections):
    """Verify each technical documentation document exists, has substantive content, and contains key sections."""
    filepath = os.path.join(DOCS_DIR, filename)
    assert os.path.exists(filepath), f"Documentation file {filepath} does not exist"
    
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    assert len(content) > 500, f"Documentation file {filepath} is too brief ({len(content)} chars)"
    
    for section in required_sections:
        assert section.lower() in content.lower(), f"Missing required section '{section}' in {filepath}"

def test_documentation_cross_references():
    """Verify that architecture doc accurately reflects verified models and services."""
    arch_path = os.path.join(DOCS_DIR, 'ENTERPRISE_ARCHITECTURE.md')
    with open(arch_path, 'r', encoding='utf-8') as f:
        arch_content = f.read()

    # Core components must be documented
    expected_symbols = [
        'BusinessStateService', 'EventBus', 'TwinDependencyService',
        'ImpactEngine', 'TemporalService', 'ScenarioBranchingService',
        'SimulationService', 'JobService'
    ]
    for sym in expected_symbols:
        assert sym in arch_content, f"Symbol {sym} not documented in {arch_path}"