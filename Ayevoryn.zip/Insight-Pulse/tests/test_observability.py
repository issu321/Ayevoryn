"""
TEST SUITE: Stage 25 - Observability, Telemetry & Health Probes
Insight-Pulse / AEVORYN Enterprise Platform

Validates:
1. X-Request-ID generation for distributed tracing when header is missing.
2. X-Request-ID preservation when supplied by upstream reverse proxy/client.
3. Kubernetes Liveness Probe (/healthz) response schema and HTTP 200 status.
4. Kubernetes Readiness Probe (/readiness) subsystem diagnostics (DB, storage, workers).
5. Readiness Probe failure detection and HTTP 503 status code when database fails.
6. Runtime Telemetry (/health/metrics) uptime, worker threads, and database dialect.
7. JSONLogFormatter structured JSON lines output and standard telemetry fields.
8. Request context injection into structured JSON logs (request_id, method, path, tenant).
9. Exception traceback capture in JSON formatted log records.
"""

import pytest
import json
import logging
from unittest.mock import patch, MagicMock
from datetime import datetime

from database.db import db
from services.telemetry.logger import JSONLogFormatter


def test_request_id_generated_when_missing(client):
    """When client does not send X-Request-ID, the server generates a UUID and includes it in response."""
    res = client.get('/healthz')
    assert res.status_code == 200
    assert 'X-Request-ID' in res.headers
    req_id = res.headers['X-Request-ID']
    assert len(req_id) >= 32


def test_request_id_preserved_when_provided(client):
    """When client sends X-Request-ID, server preserves the correlation ID across the lifecycle."""
    custom_id = "trace-client-correlation-uuid-998877"
    res = client.get('/healthz', headers={'X-Request-ID': custom_id})
    assert res.status_code == 200
    assert res.headers.get('X-Request-ID') == custom_id


def test_healthz_liveness_probe(client):
    """GET /healthz returns fast HTTP 200 liveness status."""
    res = client.get('/healthz')
    assert res.status_code == 200
    data = res.get_json()
    assert data['status'] == 'healthy'
    assert 'timestamp' in data
    assert 'service' in data


def test_readiness_probe_healthy(client):
    """GET /readiness returns HTTP 200 and ready status when all subsystems are operational."""
    res = client.get('/readiness')
    assert res.status_code == 200
    data = res.get_json()
    assert data['status'] == 'ready'
    assert 'checks' in data
    assert data['checks']['database']['status'] == 'ok'
    assert data['checks']['storage']['status'] == 'ok'
    assert data['checks']['workers']['status'] == 'ok'


def test_readiness_probe_db_failure(client):
    """When database query fails, /readiness returns HTTP 503 and not_ready status."""
    with patch.object(db.session, 'execute', side_effect=RuntimeError("Connection refused to database")):
        res = client.get('/readiness')
        assert res.status_code == 503
        data = res.get_json()
        assert data['status'] == 'not_ready'
        assert data['checks']['database']['status'] == 'error'
        assert 'Connection refused' in data['checks']['database']['message']


def test_metrics_endpoint(client):
    """GET /health/metrics returns system uptime, worker threads, and database dialect."""
    res = client.get('/health/metrics')
    assert res.status_code == 200
    data = res.get_json()
    assert data['status'] == 'operational'
    assert 'uptime_seconds' in data
    assert data['uptime_seconds'] >= 0
    assert 'database' in data
    assert 'dialect' in data['database']
    assert 'background_jobs' in data
    assert 'registered_handlers' in data['background_jobs']
    assert 'max_workers' in data['background_jobs']


def test_json_log_formatter_standard_record():
    """Verify JSONLogFormatter serializes LogRecord into valid JSON line with standard fields."""
    formatter = JSONLogFormatter()
    record = logging.LogRecord(
        name="test_logger",
        level=logging.INFO,
        pathname=__file__,
        lineno=42,
        msg="Enterprise telemetry test message: %s",
        args=("operational",),
        exc_info=None
    )

    formatted = formatter.format(record)
    parsed = json.loads(formatted)

    assert parsed['level'] == 'INFO'
    assert parsed['logger'] == 'test_logger'
    assert parsed['message'] == 'Enterprise telemetry test message: operational'
    assert 'timestamp' in parsed
    assert parsed['line'] == 42


def test_json_log_formatter_with_request_context(app):
    """Verify JSONLogFormatter extracts request_id, method, path, and tenant inside request context."""
    formatter = JSONLogFormatter()

    with app.test_request_context('/api/v1/state/canonical', method='GET', headers={'X-Request-ID': 'req-test-456'}):
        from flask import g
        g.request_id = 'req-test-456'
        g.company_id = 42

        record = logging.LogRecord(
            name="app_audit",
            level=logging.WARNING,
            pathname=__file__,
            lineno=100,
            msg="Action in tenant context",
            args=(),
            exc_info=None
        )

        formatted = formatter.format(record)
        parsed = json.loads(formatted)

        assert parsed['request_id'] == 'req-test-456'
        assert parsed['method'] == 'GET'
        assert parsed['path'] == '/api/v1/state/canonical'
        assert parsed['company_id'] == 42


def test_json_log_formatter_exception_traceback():
    """Verify JSONLogFormatter serializes exception stacktrace into structured object."""
    formatter = JSONLogFormatter()
    try:
        raise ValueError("Simulated telemetry calculation error")
    except ValueError:
        import sys
        exc_info = sys.exc_info()

    record = logging.LogRecord(
        name="error_logger",
        level=logging.ERROR,
        pathname=__file__,
        lineno=120,
        msg="Unhandled operation failure",
        args=(),
        exc_info=exc_info
    )

    formatted = formatter.format(record)
    parsed = json.loads(formatted)

    assert parsed['level'] == 'ERROR'
    assert 'exception' in parsed
    assert parsed['exception']['type'] == 'ValueError'
    assert 'Simulated telemetry calculation error' in parsed['exception']['message']
    assert len(parsed['exception']['stacktrace']) > 0
