#!/usr/bin/env python3
"""
Test Migration - Try to add a column and see the actual error
"""

import sys
import os

# Add the project root to Python path
project_root = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, project_root)

from app import app
from database.db import db
from sqlalchemy import text
import traceback

import tempfile
import sqlite3

def test_add_column():
    """Test adding a column to an isolated temporary SQLite database."""
    print("="*70)
    print("TESTING MIGRATION - Adding column to isolated test database")
    print("="*70)
    
    with tempfile.NamedTemporaryFile(suffix='.db', delete=False) as tmp:
        temp_db_path = tmp.name
        
    try:
        conn = sqlite3.connect(temp_db_path)
        cursor = conn.cursor()
        cursor.execute("CREATE TABLE companies (id INTEGER PRIMARY KEY, name TEXT)")
        conn.commit()
        
        # Test adding column
        cursor.execute("ALTER TABLE companies ADD COLUMN altman_z_score FLOAT")
        conn.commit()
        
        cursor.execute("PRAGMA table_info(companies)")
        columns = [row[1] for row in cursor.fetchall()]
        conn.close()
        
        assert 'altman_z_score' in columns, "Column altman_z_score was not added"
        print("✓ Column successfully added in isolated test database!")
        return True
    finally:
        if os.path.exists(temp_db_path):
            try:
                os.remove(temp_db_path)
            except Exception:
                pass

if __name__ == "__main__":
    success = test_add_column()
    if success:
        print("\n✓ Test PASSED")
    else:
        print("\n✗ Test FAILED")