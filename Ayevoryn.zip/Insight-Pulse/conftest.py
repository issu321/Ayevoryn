import sys
import os
import pytest

project_root = os.path.dirname(os.path.abspath(__file__))
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from flask_wtf.csrf import generate_csrf
from app import app as flask_app

class CSRFTestClient:
    """Wrapper around Flask test client that auto-injects CSRF tokens for functional testing."""
    def __init__(self, client, app):
        self._client = client
        self._app = app

    def __getattr__(self, name):
        return getattr(self._client, name)

    def _inject_csrf(self, kwargs):
        headers = kwargs.get('headers', {})
        if isinstance(headers, dict) and 'X-CSRFToken' not in headers:
            import secrets
            with self._client.session_transaction() as sess:
                if 'csrf_token' not in sess:
                    sess['csrf_token'] = secrets.token_hex(20)
                raw_token = sess['csrf_token']
            
            with self._app.test_request_context():
                from flask import session
                session['csrf_token'] = raw_token
                token = generate_csrf()
                
            headers = dict(headers)
            headers['X-CSRFToken'] = token
            kwargs['headers'] = headers
        return kwargs

    def post(self, *args, **kwargs):
        kwargs = self._inject_csrf(kwargs)
        return self._client.post(*args, **kwargs)

    def put(self, *args, **kwargs):
        kwargs = self._inject_csrf(kwargs)
        return self._client.put(*args, **kwargs)

    def delete(self, *args, **kwargs):
        kwargs = self._inject_csrf(kwargs)
        return self._client.delete(*args, **kwargs)

    def patch(self, *args, **kwargs):
        kwargs = self._inject_csrf(kwargs)
        return self._client.patch(*args, **kwargs)

@pytest.fixture
def app():
    flask_app.config['TESTING'] = True
    return flask_app

@pytest.fixture
def client(app):
    with app.test_client() as raw_client:
        yield CSRFTestClient(raw_client, app)


