"""
AEVORYN / INSIGHT-PULSE
STAGE 24: SQLITE TO POSTGRESQL MIGRATION UTILITY
Production CLI tool for migrating data from SQLite to PostgreSQL with:
- Topological dependency sorting for foreign-key constraints
- Chunked batch streaming
- PostgreSQL sequence (SERIAL / BIGSERIAL) re-synchronization
- Automated schema and row-count parity verification
"""

import sys
import os
import argparse
import logging
from typing import List, Dict, Any

# Ensure project root is in sys.path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy import create_engine, text, MetaData, Table
from sqlalchemy.orm import sessionmaker
from database.db import normalize_db_uri

logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)
logger = logging.getLogger('sqlite_to_postgres')


def get_topological_table_order(metadata: MetaData) -> List[Table]:
    """
    Return tables in foreign-key dependency order (parents first, children last).
    Uses SQLAlchemy's built-in sorted_tables topological ordering.
    """
    return list(metadata.sorted_tables)


def sync_postgres_sequences(engine, tables: List[Table]):
    """
    Reset all PostgreSQL SERIAL / BIGSERIAL identity sequences to max(id)
    so subsequent application inserts do not fail with primary key collision errors.
    """
    logger.info("Synchronizing PostgreSQL primary key sequences...")
    with engine.begin() as conn:
        for table in tables:
            # Check for integer primary key column named 'id'
            pk_cols = [c for c in table.primary_key.columns if c.name == 'id']
            if pk_cols and pk_cols[0].type.python_type is int:
                seq_query = text(f"""
                    SELECT setval(
                        pg_get_serial_sequence('{table.name}', 'id'),
                        COALESCE((SELECT MAX(id) FROM "{table.name}"), 1),
                        true
                    );
                """)
                try:
                    conn.execute(seq_query)
                    logger.info(f"  Synced sequence for '{table.name}'.id")
                except Exception as ex:
                    # Table might not have a serial sequence or is empty
                    logger.debug(f"  Skipped sequence for '{table.name}': {ex}")


def migrate_data(sqlite_uri: str, pg_uri: str, batch_size: int = 500,
                 dry_run: bool = False, verify_only: bool = False):
    """
    Stream rows from SQLite to PostgreSQL in dependency order.
    """
    sqlite_uri = normalize_db_uri(sqlite_uri)
    pg_uri = normalize_db_uri(pg_uri)

    logger.info("=" * 60)
    logger.info("AEVORYN ENTERPRISE DATABASE MIGRATION")
    logger.info(f"Source (SQLite):     {sqlite_uri}")
    logger.info(f"Destination (PG):   {pg_uri.split('@')[-1] if '@' in pg_uri else pg_uri}")
    logger.info(f"Batch Size:         {batch_size}")
    logger.info(f"Dry Run:            {dry_run}")
    logger.info(f"Verify Only:        {verify_only}")
    logger.info("=" * 60)

    # Initialize engines and metadata
    src_engine = create_engine(sqlite_uri)
    dest_engine = create_engine(pg_uri)

    from app import create_app
    from database.db import db
    import database.models

    app = create_app({'SQLALCHEMY_DATABASE_URI': sqlite_uri, 'TESTING': True})

    with app.app_context():
        metadata = db.metadata
        sorted_tables = get_topological_table_order(metadata)

    logger.info(f"Found {len(sorted_tables)} registered tables to process.")

    if verify_only:
        verify_counts(src_engine, dest_engine, sorted_tables)
        return

    if dry_run:
        logger.info("DRY RUN MODE: Listing tables in topological insertion order:")
        for idx, table in enumerate(sorted_tables, 1):
            logger.info(f"  {idx:02d}. {table.name}")
        return

    # Phase 1: Ensure target schema exists
    logger.info("Phase 1: Ensuring destination schema is up to date...")
    metadata.create_all(bind=dest_engine)

    # Phase 2: Copy rows in dependency order
    logger.info("Phase 2: Migrating table records...")
    migration_summary = {}

    with src_engine.connect() as src_conn, dest_engine.begin() as dest_conn:
        # If target is PostgreSQL, optionally disable triggers / defer constraints
        is_pg = dest_engine.url.get_backend_name() == 'postgresql'
        if is_pg:
            dest_conn.execute(text("SET CONSTRAINTS ALL DEFERRED;"))

        for table in sorted_tables:
            table_name = table.name
            # Check source row count
            count_res = src_conn.execute(text(f"SELECT COUNT(*) FROM [{table_name}]"))
            src_count = count_res.scalar() or 0

            if src_count == 0:
                logger.info(f"  [-] Table '{table_name}': 0 records (skipped)")
                migration_summary[table_name] = {"src": 0, "dest": 0}
                continue

            logger.info(f"  [*] Migrating '{table_name}': {src_count} records...")

            # Select and stream rows in chunks
            select_stmt = table.select()
            result_proxy = src_conn.execution_options(stream_results=True).execute(select_stmt)

            batch = []
            transferred = 0
            for row in result_proxy:
                # Convert row mapping to dictionary
                row_dict = dict(row._mapping)
                batch.append(row_dict)

                if len(batch) >= batch_size:
                    dest_conn.execute(table.insert(), batch)
                    transferred += len(batch)
                    batch = []

            if batch:
                dest_conn.execute(table.insert(), batch)
                transferred += len(batch)

            migration_summary[table_name] = {"src": src_count, "dest": transferred}
            logger.info(f"      Successfully transferred {transferred}/{src_count} rows.")

    # Phase 3: Synchronize PostgreSQL sequences
    if dest_engine.url.get_backend_name() == 'postgresql':
        sync_postgres_sequences(dest_engine, sorted_tables)

    # Phase 4: Verification
    logger.info("Phase 4: Running verification...")
    verify_counts(src_engine, dest_engine, sorted_tables)


def verify_counts(src_engine, dest_engine, tables: List[Table]):
    """Verify that source and destination row counts match across all tables."""
    logger.info("-" * 60)
    logger.info(f"{'TABLE NAME':<35} | {'SOURCE':<8} | {'DEST':<8} | {'STATUS'}")
    logger.info("-" * 60)

    mismatches = 0
    with src_engine.connect() as src_conn, dest_engine.connect() as dest_conn:
        for table in tables:
            tname = table.name
            try:
                c1 = src_conn.execute(text(f"SELECT COUNT(*) FROM [{tname}]")).scalar()
            except Exception:
                c1 = 0

            try:
                quote_char = '"' if dest_engine.url.get_backend_name() == 'postgresql' else '['
                close_char = '"' if dest_engine.url.get_backend_name() == 'postgresql' else ']'
                c2 = dest_conn.execute(text(f"SELECT COUNT(*) FROM {quote_char}{tname}{close_char}")).scalar()
            except Exception:
                c2 = 0

            status = "OK" if c1 == c2 else "MISMATCH"
            if status != "OK":
                mismatches += 1
            logger.info(f"{tname:<35} | {c1:<8} | {c2:<8} | {status}")

    logger.info("-" * 60)
    if mismatches == 0:
        logger.info("SUCCESS: All tables verified with 100% row count parity!")
    else:
        logger.error(f"WARNING: {mismatches} table(s) had row count discrepancies.")


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Migrate AEVORYN database from SQLite to PostgreSQL")
    parser.add_argument('--sqlite-path', default='instance/business_simulator.db',
                        help='Path to source SQLite database file')
    parser.add_argument('--pg-uri', default=os.environ.get('TARGET_DATABASE_URL', ''),
                        help='Target PostgreSQL connection URI (or set TARGET_DATABASE_URL)')
    parser.add_argument('--batch-size', type=int, default=500,
                        help='Batch size for bulk insertion (default: 500)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Print migration dependency plan without executing')
    parser.add_argument('--verify-only', action='store_true',
                        help='Compare row counts between source and destination without copying')

    args = parser.parse_args()

    sqlite_db_uri = f"sqlite:///{os.path.abspath(args.sqlite_path)}"
    target_pg_uri = args.pg_uri

    if not args.dry_run and not target_pg_uri:
        parser.error("--pg-uri or TARGET_DATABASE_URL environment variable is required.")

    migrate_data(
        sqlite_uri=sqlite_db_uri,
        pg_uri=target_pg_uri or sqlite_db_uri,
        batch_size=args.batch_size,
        dry_run=args.dry_run,
        verify_only=args.verify_only
    )
