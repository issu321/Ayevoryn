import sys, os, subprocess
sys.path.insert(0, os.path.abspath("."))
from app import create_app
from database.models.user import User

app = create_app()
app.config["TESTING"] = True
app.config["WTF_CSRF_ENABLED"] = False

with app.app_context():
    client = app.test_client()
    user = User.query.filter_by(company_id=2).first()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["user_id"] = user.id
        sess["company_id"] = 2
        sess["company_currency"] = "INR"
        sess["currency_symbol"] = "₹"
    res = client.get("/business-twin/departments")
    html = res.data.decode("utf-8")
    
    # Extract scripts
    import re
    scripts = re.findall(r'<script(?:\s+[^>]*)?>([\s\S]*?)</script>', html, re.IGNORECASE)
    print(f"Found {len(scripts)} script tags in rendered HTML")
    for i, s in enumerate(scripts):
        if not s.strip():
            continue
        # Write to a temp js file
        tmp_file = f"scratch/test_script_{i}.js"
        with open(tmp_file, "w", encoding="utf-8") as f:
            f.write(s)
        # Run node --check
        result = subprocess.run(["node", "--check", tmp_file], capture_output=True, text=True)
        if result.returncode != 0:
            print(f"ERROR IN SCRIPT {i} ({tmp_file}):")
            print(result.stderr)
        else:
            print(f"Script {i} parsed successfully!")
