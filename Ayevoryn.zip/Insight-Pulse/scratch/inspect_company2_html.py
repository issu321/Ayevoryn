import sys, os
sys.path.insert(0, os.path.abspath("."))
from app import create_app
from database.models.company import Company
from database.models.user import User

app = create_app()
app.config["TESTING"] = True
app.config["WTF_CSRF_ENABLED"] = False

with app.app_context():
    client = app.test_client()
    user = User.query.filter_by(company_id=2).first()
    print("User for company 2:", user.username if user else "None")
    
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["user_id"] = user.id
        sess["company_id"] = 2
        sess["company_currency"] = "INR"
        sess["currency_symbol"] = "₹"
        
    res = client.get("/business-twin/departments")
    print("Status code:", res.status_code)
    html = res.data.decode("utf-8")
    
    # Extract the script block in extra_js
    start = html.find("const deptData =")
    if start != -1:
        end = html.find("</script>", start)
        print("--- FULL JS BLOCK ---")
        print(html[start:end])
        print("--- END JS BLOCK ---")
    else:
        print("const deptData NOT FOUND IN HTML!")
        # Let's see what is rendered around charts
        hc = html.find("headcountChart")
        print("headcountChart at:", hc)
        if hc != -1:
            print(html[hc-200:hc+300])
