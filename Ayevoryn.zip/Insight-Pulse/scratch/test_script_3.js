
    // ── Universal Core Theme & Plotly Engine (Pre-rendered for Instant Paint) ──
    (function() {
        window.getPlotlyThemeLayout = function(customLayout) {
            customLayout = customLayout || {};
            const themeId = document.documentElement.getAttribute('data-theme') || 'white_clay_glass';
            const isLight = themeId === 'white_clay_glass' || document.documentElement.style.colorScheme === 'light';
            
            const textColor = isLight ? '#0F172A' : '#F8FAFC';
            const subColor = isLight ? '#334155' : '#E2E8F0';
            const gridColor = isLight ? 'rgba(148, 163, 184, 0.28)' : 'rgba(255, 255, 255, 0.06)';
            const zeroLineColor = isLight ? 'rgba(100, 116, 139, 0.45)' : 'rgba(255, 255, 255, 0.15)';
            const hoverBg = isLight ? '#FFFFFF' : '#1E293B';
            const hoverBorder = isLight ? '#CBD5E1' : '#475569';
            const hoverText = isLight ? '#0F172A' : '#F8FAFC';
            const spikeColor = isLight ? 'rgba(100, 116, 139, 0.45)' : 'rgba(148, 163, 184, 0.35)';

            const base = {
                paper_bgcolor: 'transparent',
                plot_bgcolor: 'transparent',
                font: { family: 'Inter, sans-serif', color: textColor, size: 12 },
                hoverlabel: {
                    bgcolor: hoverBg,
                    bordercolor: hoverBorder,
                    font: { family: 'Inter, sans-serif', color: hoverText, size: 12 },
                    namelength: -1
                },
                xaxis: {
                    gridcolor: gridColor,
                    zerolinecolor: zeroLineColor,
                    spikecolor: spikeColor,
                    tickfont: { color: subColor, size: 11, family: 'Inter, sans-serif' },
                    title: { font: { color: textColor, size: 12, family: 'Inter, sans-serif' } }
                },
                yaxis: {
                    gridcolor: gridColor,
                    zerolinecolor: zeroLineColor,
                    spikecolor: spikeColor,
                    tickfont: { color: subColor, size: 11, family: 'Inter, sans-serif' },
                    title: { font: { color: textColor, size: 12, family: 'Inter, sans-serif' } }
                },
                legend: {
                    font: { color: textColor, size: 12, family: 'Inter, sans-serif' }
                }
            };
            
            const merged = Object.assign({}, base, customLayout);
            if (customLayout.hoverlabel) merged.hoverlabel = Object.assign({}, base.hoverlabel, customLayout.hoverlabel);
            if (customLayout.xaxis) merged.xaxis = Object.assign({}, base.xaxis, customLayout.xaxis);
            if (customLayout.yaxis) merged.yaxis = Object.assign({}, base.yaxis, customLayout.yaxis);
            if (customLayout.legend) merged.legend = Object.assign({}, base.legend, customLayout.legend);
            if (customLayout.font) merged.font = Object.assign({}, base.font, customLayout.font);
            return merged;
        };

        window.setTheme = function(themeId) {
            if (!themeId) return;
            const resolved = (themeId.indexOf('dark') !== -1) ? 'dark_clay_glass' : 'white_clay_glass';
            const scheme = (resolved === 'dark_clay_glass') ? 'dark' : 'light';

            // 1. Immediately apply attributes & properties to client (0ms latency)
            document.documentElement.setAttribute('data-theme', resolved);
            document.documentElement.style.colorScheme = scheme;

            try {
                localStorage.setItem('aevoryn_theme', resolved);
                document.cookie = 'aevoryn_theme=' + resolved + '; path=/; max-age=31536000; SameSite=Lax';
            } catch(e) {}

            const darkProps = {
                '--color-scheme': 'dark',
                '--bg-primary': '#0A0B0E',
                '--bg-secondary': '#11141E',
                '--sidebar-bg': '#11141E',
                '--topbar-bg': 'rgba(17, 20, 30, 0.85)',
                '--card-bg': 'rgba(18, 20, 28, 0.85)',
                '--card-bg-solid': '#14151B',
                '--accent-primary': '#6366F1',
                '--accent-primary-rgb': '99, 102, 241',
                '--accent-secondary': '#8B5CF6',
                '--accent-warning': '#F59E0B',
                '--accent-success': '#10B981',
                '--accent-danger': '#EF4444',
                '--text-primary': '#FFFFFF',
                '--text-secondary': '#CBD5E1',
                '--text-muted': '#94A3B8',
                '--border-color': 'rgba(255, 255, 255, 0.08)'
            };
            const lightProps = {
                '--color-scheme': 'light',
                '--bg-primary': '#F8FAFC',
                '--bg-secondary': '#FFFFFF',
                '--sidebar-bg': 'rgba(255, 255, 255, 0.92)',
                '--topbar-bg': 'rgba(255, 255, 255, 0.88)',
                '--card-bg': 'rgba(255, 255, 255, 0.78)',
                '--card-bg-solid': '#FFFFFF',
                '--accent-primary': '#2563EB',
                '--accent-primary-rgb': '37, 99, 235',
                '--accent-secondary': '#4F46E5',
                '--accent-warning': '#D97706',
                '--accent-success': '#059669',
                '--accent-danger': '#DC2626',
                '--text-primary': '#0F172A',
                '--text-secondary': '#334155',
                '--text-muted': '#64748B',
                '--border-color': 'rgba(203, 213, 225, 0.85)'
            };
            const activeProps = (scheme === 'dark') ? darkProps : lightProps;
            for (const [prop, val] of Object.entries(activeProps)) {
                document.documentElement.style.setProperty(prop, val);
            }

            const iconEl = document.getElementById('active-theme-icon');
            if (iconEl) {
                iconEl.className = (scheme === 'dark') ? 'fas fa-moon text-primary' : 'fas fa-sun text-warning';
            }
            const nameEl = document.getElementById('active-theme-name');
            if (nameEl) {
                nameEl.textContent = (scheme === 'dark') ? 'Dark Clay Glass' : 'Light Clay Glass';
            }

            document.querySelectorAll('.dropdown-menu-glass a[onclick*="setTheme"]').forEach(a => {
                const match = a.getAttribute('onclick').indexOf(resolved) !== -1;
                a.classList.toggle('active', match);
                a.classList.toggle('fw-bold', match);
                const checkIcon = a.querySelector('.fa-check');
                if (checkIcon) checkIcon.style.display = match ? 'inline-block' : 'none';
            });

            // Notify charts and UI listeners
            window.dispatchEvent(new CustomEvent('themechanged', { detail: { theme_id: resolved, color_scheme: scheme } }));

            // 2. Persist to server session and database
            const csrfMeta = document.querySelector('meta[name="csrf-token"]');
            const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

            const headers = {
                'Content-Type': 'application/json',
                'X-Requested-With': 'XMLHttpRequest'
            };
            if (csrfToken) headers['X-CSRFToken'] = csrfToken;

            fetch('/settings/theme', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ theme_id: resolved, csrf_token: csrfToken }),
                keepalive: true
            })
            .then(r => r.json())
            .then(data => {
                if (typeof showToast === 'function') {
                    showToast('Theme set to ' + (scheme === 'dark' ? 'Dark Clay Glass' : 'Light Clay Glass'), 'success');
                }
            })
            .catch(err => {
                console.warn('Theme backend sync notice:', err);
            });
        };

        window.toggleTheme = function() {
            const cur = document.documentElement.getAttribute('data-theme') || 'white_clay_glass';
            const next = (cur.indexOf('dark') !== -1) ? 'white_clay_glass' : 'dark_clay_glass';
            window.setTheme(next);
        };
    })();
    