import sys
import os
sys.path.insert(0, os.getcwd())
from app import create_app
from database import db
from database.models.company import Company
from database.models.user import User

app = create_app()
app.config['TESTING'] = True
with app.app_context():
    client = app.test_client()
    for cid in [1, 2]:
        comp = Company.query.get(cid)
        user = User.query.filter_by(company_id=cid).first()
        if not user:
            continue
        with client.session_transaction() as sess:
            sess['_user_id'] = str(user.id)
            sess['user_id'] = user.id
            sess['company_id'] = cid
            sess['company_currency'] = comp.currency or 'USD'
        res = client.get('/business-twin/departments')
        html = res.data.decode('utf-8', errors='ignore')
        
        # Check Plotly script tags in base
        has_plotly = 'plotly' in html.lower()
        print(f"\n--- Company {cid} ({comp.company_name}) ---")
        print("Response status:", res.status_code)
        print("Has plotly script:", has_plotly)
        print("headcountChart div:", 'id="headcountChart"' in html)
        print("payrollChart div:", 'id="payrollChart"' in html)
        
        # Check script content in the page
        start = html.find('<script>\nconst deptData =')
        if start != -1:
            end = html.find('</script>', start)
            print("Chart script (first 400 chars):")
            print(html[start:start+400])
        else:
            print("Chart script block NOT FOUND!")
