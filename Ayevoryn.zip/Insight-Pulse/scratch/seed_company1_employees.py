import sys
import os
import random
from datetime import datetime, timedelta

sys.path.insert(0, os.getcwd())
from app import create_app
from database import db
from database.models.company import Company
from database.models.department import Department
from database.models.employee import Employee

app = create_app()
app.config['TESTING'] = True

with app.app_context():
    company = Company.query.get(1)
    if not company:
        print("Company 1 not found!")
        sys.exit(1)

    existing_emps = Employee.query.filter_by(company_id=1).count()
    if existing_emps > 0:
        print(f"Company 1 already has {existing_emps} employees.")
    else:
        print("Seeding realistic enterprise employees for Company 1 across all 8 departments...")
        depts = Department.query.filter_by(company_id=1, is_active=True).all()
        dept_map = {d.code: d for d in depts}

        emp_templates = [
            # Executive Management (EXEC)
            ("Alex", "Vance", "alex.vance@aevoryn.global", "EXEC", "Chief Executive Officer", 350000.0, 45000.0, "Full-Time", "Strategy, Leadership, M&A"),
            ("Marcus", "Sterling", "marcus.sterling@aevoryn.global", "EXEC", "Chief Operating Officer", 280000.0, 38000.0, "Full-Time", "Operations, Scaling, Execution"),
            ("Julian", "Thorne", "julian.thorne@aevoryn.global", "EXEC", "Chief Financial Officer", 290000.0, 40000.0, "Full-Time", "FP&A, Treasury, Capital"),
            ("Dr. Elena", "Rostova", "elena.rostova@aevoryn.global", "EXEC", "Chief Technology Officer", 320000.0, 42000.0, "Full-Time", "AI Architecture, Engineering, Research"),
            ("Sarah", "Jenkins", "sarah.jenkins@aevoryn.global", "EXEC", "Chief People Officer", 240000.0, 32000.0, "Full-Time", "Talent, Org Design, Culture"),

            # Finance & Risk (FIN)
            ("David", "Kim", "david.kim@aevoryn.global", "FIN", "VP of FP&A", 185000.0, 24000.0, "Full-Time", "Financial Modeling, Forecasting, Analytics"),
            ("Rachel", "Green", "rachel.green@aevoryn.global", "FIN", "Corporate Controller", 165000.0, 22000.0, "Full-Time", "Accounting, Audit, Compliance"),
            ("Vikram", "Patel", "vikram.patel@aevoryn.global", "FIN", "Senior Treasury Manager", 145000.0, 19000.0, "Full-Time", "Cash Management, FX, Liquidity"),
            ("Claire", "Dubois", "claire.dubois@aevoryn.global", "FIN", "Enterprise Risk Director", 170000.0, 23000.0, "Full-Time", "Risk Modeling, Governance, Hedging"),
            ("Lucas", "Meyer", "lucas.meyer@aevoryn.global", "FIN", "Senior Financial Analyst", 115000.0, 15000.0, "Full-Time", "Budgeting, Variance Analysis, Reporting"),

            # Engineering & AI (ENG)
            ("Aarav", "Mehta", "aarav.mehta@aevoryn.global", "ENG", "Principal AI Architect", 220000.0, 30000.0, "Full-Time", "PyTorch, Neural Networks, Causal AI"),
            ("Liam", "O'Connor", "liam.oconnor@aevoryn.global", "ENG", "Staff Cloud Infrastructure Architect", 205000.0, 28000.0, "Full-Time", "Kubernetes, AWS, Distributed Systems"),
            ("Sophia", "Chen", "sophia.chen@aevoryn.global", "ENG", "Staff Data Platform Engineer", 195000.0, 26000.0, "Full-Time", "Apache Spark, Kafka, Data Pipelines"),
            ("Mateo", "Fernandez", "mateo.fernandez@aevoryn.global", "ENG", "Senior Neural Twin Engineer", 180000.0, 24000.0, "Full-Time", "Digital Twin Engine, Simulation, Rust"),
            ("Ananya", "Iyer", "ananya.iyer@aevoryn.global", "ENG", "Senior Backend Engineer", 165000.0, 22000.0, "Full-Time", "Python, Flask, PostgreSQL, GraphQL"),
            ("Tariq", "Al-Hassan", "tariq.alhassan@aevoryn.global", "ENG", "Senior Security Engineer", 175000.0, 23000.0, "Full-Time", "Zero Trust, SOC2, Cryptography"),
            ("Emma", "Watson", "emma.watson@aevoryn.global", "ENG", "Lead Frontend Architect", 170000.0, 22000.0, "Full-Time", "TypeScript, React, Design Systems"),
            ("Jonas", "Nilsson", "jonas.nilsson@aevoryn.global", "ENG", "Machine Learning Ops Lead", 185000.0, 25000.0, "Full-Time", "MLFlow, Feature Stores, Model Serving"),

            # Product Architecture (PRD)
            ("Chloe", "Martin", "chloe.martin@aevoryn.global", "PRD", "VP of Product", 210000.0, 28000.0, "Full-Time", "Roadmap, Strategy, Commercialization"),
            ("Oliver", "Brown", "oliver.brown@aevoryn.global", "PRD", "Principal UX Architect", 165000.0, 22000.0, "Full-Time", "Design Systems, User Research, Glass UI"),
            ("Priya", "Nair", "priya.nair@aevoryn.global", "PRD", "Group Product Manager", 175000.0, 23000.0, "Full-Time", "Enterprise Analytics, Simulation Tools"),
            ("Daniel", "Silva", "daniel.silva@aevoryn.global", "PRD", "Senior Product Designer", 140000.0, 18000.0, "Full-Time", "Figma, Prototyping, Clay Aesthetics"),

            # Global Sales (SLS)
            ("Michael", "Chang", "michael.chang@aevoryn.global", "SLS", "VP of Global Enterprise Sales", 225000.0, 32000.0, "Full-Time", "Enterprise SaaS, Deal Closing, ARR"),
            ("Jessica", "Taylor", "jessica.taylor@aevoryn.global", "SLS", "Strategic Enterprise Account Director", 175000.0, 24000.0, "Full-Time", "Fortune 500 Accounts, Expansion, Renewal"),
            ("Carlos", "Santana", "carlos.santana@aevoryn.global", "SLS", "Senior Solutions Engineering Lead", 165000.0, 22000.0, "Full-Time", "POC Delivery, Technical Demos, Architecture"),
            ("Fatima", "Zahra", "fatima.zahra@aevoryn.global", "SLS", "Regional Enterprise Sales Lead", 155000.0, 20000.0, "Full-Time", "EMEA Sales, Pipeline Generation, Negotiation"),

            # Marketing & Brand (MKT)
            ("Amara", "Okafor", "amara.okafor@aevoryn.global", "MKT", "VP of Global Marketing", 195000.0, 26000.0, "Full-Time", "Brand Strategy, Category Creation, PR"),
            ("Benjamin", "Scott", "benjamin.scott@aevoryn.global", "MKT", "Director of Demand Generation", 160000.0, 21000.0, "Full-Time", "Inbound Pipeline, Account-Based Marketing"),
            ("Zoe", "Kowalski", "zoe.kowalski@aevoryn.global", "MKT", "Head of Product Marketing", 155000.0, 20000.0, "Full-Time", "Positioning, Sales Enablement, Analyst Relations"),

            # Operations & Supply (OPS)
            ("Amina", "Al-Mansoor", "amina.mansoor@aevoryn.global", "OPS", "VP of Global Operations", 205000.0, 28000.0, "Full-Time", "Supply Chain, Cloud Operations, SLA"),
            ("Rohan", "Gupta", "rohan.gupta@aevoryn.global", "OPS", "Director of Procurement & Vendor Relations", 160000.0, 21000.0, "Full-Time", "Vendor Negotiation, Hardware, Cloud Spend"),
            ("Klaus", "Weber", "klaus.weber@aevoryn.global", "OPS", "IT Operations & Infrastructure Manager", 140000.0, 18000.0, "Full-Time", "Corporate IT, Device Fleet, Network"),

            # People & Culture (HR)
            ("Grace", "Adebayo", "grace.adebayo@aevoryn.global", "HR", "Director of Talent Acquisition", 155000.0, 20000.0, "Full-Time", "Executive Recruiting, Tech Hiring"),
            ("Hiroshi", "Tanaka", "hiroshi.tanaka@aevoryn.global", "HR", "Head of Total Rewards & Payroll", 150000.0, 20000.0, "Full-Time", "Executive Comp, Equity, Global Benefits"),
            ("Maya", "Lin", "maya.lin@aevoryn.global", "HR", "People Operations & HRBP Lead", 130000.0, 17000.0, "Full-Time", "Performance Management, Retention, Culture")
        ]

        count = 0
        hire_base = datetime.utcnow() - timedelta(days=750)
        for fn, ln, email, dcode, title, sal, ben, etype, skills in emp_templates:
            dept = dept_map.get(dcode)
            if not dept:
                continue
            h_date = hire_base + timedelta(days=random.randint(0, 500))
            emp = Employee(
                company_id=1,
                department_id=dept.id,
                first_name=fn,
                last_name=ln,
                email=email,
                job_title=title,
                salary=sal,
                benefits_cost=ben,
                employment_type=etype,
                status="active",
                hire_date=h_date.date(),
                skills=skills,
                performance_rating=round(random.uniform(4.0, 5.0), 1)
            )
            db.session.add(emp)
            count += 1

        db.session.commit()
        print(f"Successfully seeded {count} active enterprise employees for Company 1 across all 8 departments!")

        # Sync department employee_count
        for dept in depts:
            cnt = Employee.query.filter_by(company_id=1, department_id=dept.id, status='active').count()
            dept.employee_count = cnt
        db.session.commit()
        print("Updated department employee_counts.")
