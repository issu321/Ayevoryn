import sys, os, subprocess, re
sys.path.insert(0, os.path.abspath("."))
from app import create_app
from database.models.user import User

app = create_app()
app.config["TESTING"] = True
app.config["WTF_CSRF_ENABLED"] = False

routes = [
    "/business-twin/revenue",
    "/business-twin/expenses",
    "/business-twin/customers",
    "/business-twin/employees",
    "/business-twin/inventory",
    "/business-twin/suppliers",
    "/business-twin/departments"
]

with app.app_context():
    client = app.test_client()
    user = User.query.filter_by(company_id=2).first()
    with client.session_transaction() as sess:
        sess["_user_id"] = str(user.id)
        sess["user_id"] = user.id
        sess["company_id"] = 2
        sess["company_currency"] = "INR"
        sess["currency_symbol"] = "₹"
        
    for r in routes:
        res = client.get(r)
        print(f"\nChecking route: {r} (status {res.status_code})")
        if res.status_code != 200:
            print(f"FAILED TO LOAD {r}")
            continue
        html = res.data.decode("utf-8")
        scripts = re.findall(r'<script(?:\s+[^>]*)?>([\s\S]*?)</script>', html, re.IGNORECASE)
        has_err = False
        for i, s in enumerate(scripts):
            if not s.strip():
                continue
            tmp_file = f"scratch/validate_{r.replace('/', '_')}_{i}.js"
            with open(tmp_file, "w", encoding="utf-8") as f:
                f.write(s)
            res_node = subprocess.run(["node", "--check", tmp_file], capture_output=True, text=True)
            if res_node.returncode != 0:
                print(f"  SYNTAX ERROR in script {i}: {res_node.stderr.strip()}")
                has_err = True
        if not has_err:
            print(f"  ALL {len(scripts)} scripts valid!")
