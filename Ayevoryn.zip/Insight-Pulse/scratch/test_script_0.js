
    (function() {
        try {
            var m = document.cookie.match(/(?:^|;\s*)aevoryn_theme=([^;]+)/);
            var t = (m ? m[1] : null) || localStorage.getItem('aevoryn_theme');
            if (t) {
                var resolved = (t.indexOf('dark') !== -1) ? 'dark_clay_glass' : 'white_clay_glass';
                document.documentElement.setAttribute('data-theme', resolved);
                document.documentElement.style.colorScheme = (resolved === 'dark_clay_glass') ? 'dark' : 'light';
            }
            if (localStorage.getItem('aevoryn_sidebar_collapsed') === '1' && window.innerWidth >= 992) {
                document.documentElement.classList.add('sidebar-collapsed-preload');
            }
        } catch(e) {}
    })();
    