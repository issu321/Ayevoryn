
const deptData = [{"avg_salary": 83721.15384615384, "budget": 500000.0, "code": "DEPIT", "color": "#2563EB", "head_name": "Assinged", "headcount": 104, "id": 9, "is_active": true, "name": "IT", "remaining": 397979.5, "spent": 102020.5, "top_skills": [], "total_benefits": 1302857.0, "total_payroll": 10009857.0, "total_salary": 8707000.0, "type_breakdown": {"contract": 20, "full_time": 60, "part_time": 24}, "utilization": 20.4}, {"avg_salary": 79729.72972972973, "budget": 400000.0, "code": "DEPHR", "color": "#10B981", "head_name": "Assinged", "headcount": 37, "id": 10, "is_active": true, "name": "HR", "remaining": 383900.0, "spent": 16100.0, "top_skills": [], "total_benefits": 450605.0, "total_payroll": 3400605.0, "total_salary": 2950000.0, "type_breakdown": {"contract": 4, "full_time": 29, "part_time": 4}, "utilization": 4.0}, {"avg_salary": 91413.79310344828, "budget": 1000000.0, "code": "DEPFIN", "color": "#F59E0B", "head_name": "Assinged", "headcount": 29, "id": 11, "is_active": true, "name": "Finance", "remaining": 986000.0, "spent": 14000.0, "top_skills": [], "total_benefits": 404920.0, "total_payroll": 3055920.0, "total_salary": 2651000.0, "type_breakdown": {"contract": 5, "full_time": 20, "part_time": 4}, "utilization": 1.4}];
const currencySymbol = "\u20b9";
const totalHeadcount = 170;
const totalPayroll = 16466382.0;


function initDepartmentCharts() {
    if (typeof Plotly === 'undefined') {
        setTimeout(initDepartmentCharts, 80);
        return;
    }

    const isLight = document.documentElement.getAttribute('data-theme') === 'white_clay_glass' ||
                    document.documentElement.style.colorScheme === 'light';
    const chartTextColor = isLight ? '#0F172A' : '#F8FAFC';
    
    // Executive Business Color Palette (Apple / Linear Enterprise grade)
    const executivePalette = [
        '#2563EB', // Tech Royal Blue (IT / Engineering / Primary)
        '#10B981', // Vibrant Emerald (HR / Operations / Efficiency)
        '#F59E0B', // Rich Amber (Finance / Risk / Capital)
        '#8B5CF6', // Royal Purple (Product / Strategy)
        '#EC4899', // Modern Rose (Marketing / Growth)
        '#06B6D4', // Deep Cyan (Customer Support)
        '#F97316', // Warm Orange
        '#14B8A6', // Crisp Teal
        '#4F46E5', // Indigo Core
        '#65A30D', // Olive Lime
        '#DC2626', // Crimson Security
        '#0284C7'  // Sky Horizon
    ];

    // Detect if colors in deptData are identical, empty, or default monochrome
    const rawColors = deptData.map(d => (d.color || '').toUpperCase().trim());
    const distinctColors = new Set(rawColors.filter(c => c && c !== '#6366F1' && c !== '#00D4FF'));
    const needsAutoColors = distinctColors.size < Math.min(deptData.length, 2);

    // Build consistent department -> color map across both charts
    const deptColorMap = {};
    deptData.forEach((d, idx) => {
        if (!needsAutoColors && d.color && d.color.toUpperCase() !== '#00D4FF' && d.color.toUpperCase() !== '#6366F1') {
            deptColorMap[d.id] = d.color;
        } else {
            deptColorMap[d.id] = executivePalette[idx % executivePalette.length];
        }
    });

    // 1. Headcount & Department Distribution (Donut Chart)
    const hcContainer = document.getElementById('headcountChart');
    if (hcContainer) {
        let headcountValues = deptData.map(d => d.headcount || 0);
        const sumHc = headcountValues.reduce((a, b) => a + b, 0);

        // If headcount > 0, display actual headcount; if 0, distribute by department budget or equal share
        const valuesToPlot = sumHc > 0 ? headcountValues : deptData.map(d => Math.max(1, Math.round((d.budget || 1000000) / 100000)));
        const centerValue = sumHc > 0 ? sumHc : deptData.length;
        const centerSub = sumHc > 0 ? 'Headcount' : 'Departments';

        const headcountColors = deptData.map(d => deptColorMap[d.id]);
        const headcountLabels = deptData.map(d => d.name);

        const headcountLayout = (typeof window.getPlotlyThemeLayout === 'function')
            ? window.getPlotlyThemeLayout({
                showlegend: true,
                legend: {
                    orientation: 'h',
                    x: 0.5,
                    xanchor: 'center',
                    y: -0.16,
                    font: { size: 11, color: chartTextColor, family: 'Inter, sans-serif' }
                },
                margin: { t: 20, r: 25, b: 50, l: 25 },
                automargin: true,
                annotations: [{
                    text: `<b>${centerValue}</b><br><span style="font-size:11px;font-weight:600;">${centerSub}</span>`,
                    showarrow: false,
                    font: { size: 16, color: chartTextColor, family: 'Inter, sans-serif' }
                }]
            })
            : {
                showlegend: true,
                paper_bgcolor: 'transparent',
                plot_bgcolor: 'transparent',
                margin: { t: 20, r: 25, b: 50, l: 25 }
            };

        Plotly.newPlot('headcountChart', [{
            values: valuesToPlot,
            labels: headcountLabels,
            type: 'pie',
            hole: 0.58,
            sort: true,
            direction: 'clockwise',
            marker: { colors: headcountColors, line: { color: isLight ? '#FFFFFF' : '#1E293B', width: 2 } },
            textinfo: 'percent',
            textposition: 'inside',
            insidetextorientation: 'horizontal',
            textfont: { size: 11, color: '#FFFFFF', family: 'Inter, sans-serif', weight: 600 },
            hovertemplate: sumHc > 0
                ? '<b>%{label}</b><br>Headcount: <b>%{value}</b> employees<br>Share: <b>%{percent}</b><extra></extra>'
                : '<b>%{label}</b><br>Share: <b>%{percent}</b><extra></extra>'
        }], headcountLayout, { responsive: true, displayModeBar: false });
    }

    // 2. Payroll & Budget Breakdown by Department (Horizontal Bar Chart)
    const payrollContainer = document.getElementById('payrollChart');
    if (payrollContainer) {
        let payrollValues = deptData.map(d => d.total_payroll || 0);
        const sumPayroll = payrollValues.reduce((a, b) => a + b, 0);

        // If actual payroll > 0, plot payroll; if 0, plot operational budget / 12
        const isPayroll = sumPayroll > 0;
        const sortedDepts = [...deptData].sort((a, b) => {
            const valA = isPayroll ? (a.total_payroll || 0) : (a.budget || 0);
            const valB = isPayroll ? (b.total_payroll || 0) : (b.budget || 0);
            return valA - valB;
        });

        const pColors = sortedDepts.map(d => deptColorMap[d.id]);
        const xValues = sortedDepts.map(d => isPayroll ? (d.total_payroll || 0) : Math.round((d.budget || 0) / 12));

        const payrollTrace = {
            y: sortedDepts.map(d => d.name),
            x: xValues,
            type: 'bar',
            orientation: 'h',
            marker: {
                color: pColors,
                line: { color: isLight ? '#FFFFFF' : '#1E293B', width: 1 }
            },
            text: xValues.map(v => {
                if (v >= 1000000) return currencySymbol + (v/1000000).toFixed(1) + 'M';
                if (v >= 1000) return currencySymbol + (v/1000).toFixed(0) + 'K';
                return currencySymbol + Number(v).toLocaleString();
            }),
            textposition: 'outside',
            cliponaxis: false,
            textfont: { color: chartTextColor, size: 11, family: 'Inter, sans-serif' },
            hovertemplate: isPayroll
                ? `<b>%{y}</b><br>Monthly Payroll: ${currencySymbol}%{x:,.2f}<extra></extra>`
                : `<b>%{y}</b><br>Monthly Budget: ${currencySymbol}%{x:,.2f}<extra></extra>`
        };

        const payrollLayout = (typeof window.getPlotlyThemeLayout === 'function')
            ? window.getPlotlyThemeLayout({
                bargap: 0.38,
                xaxis: {
                    title: {
                        text: isPayroll ? `Monthly Payroll Allocation (${currencySymbol})` : `Monthly Budget Allocation (${currencySymbol})`,
                        font: { size: 11, color: chartTextColor, family: 'Inter, sans-serif' },
                        standoff: 12
                    },
                    tickprefix: currencySymbol,
                    tickfont: { size: 10, color: chartTextColor, family: 'Inter, sans-serif' },
                    gridcolor: isLight ? 'rgba(226, 232, 240, 0.8)' : 'rgba(148, 163, 184, 0.28)',
                    showticklabels: true,
                    automargin: true
                },
                yaxis: {
                    automargin: true,
                    dtick: 1,
                    tickfont: { size: 12, color: chartTextColor, family: 'Inter, sans-serif' },
                    range: [-0.65, sortedDepts.length - 0.35]
                },
                margin: { t: 25, r: 65, b: 65, l: 110 },
                hovermode: 'y unified'
            })
            : {
                bargap: 0.38,
                paper_bgcolor: 'transparent',
                plot_bgcolor: 'transparent',
                margin: { t: 25, r: 65, b: 65, l: 110 }
            };

        Plotly.newPlot('payrollChart', [payrollTrace], payrollLayout, { responsive: true, displayModeBar: false });
    }
}

// Multi-trigger guaranteed execution engine:
function renderDeptChartsGuaranteed() {
    initDepartmentCharts();
}

if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', renderDeptChartsGuaranteed);
} else {
    renderDeptChartsGuaranteed();
}
renderDeptChartsGuaranteed();
requestAnimationFrame(renderDeptChartsGuaranteed);
setTimeout(renderDeptChartsGuaranteed, 100);
setTimeout(renderDeptChartsGuaranteed, 400);

window.addEventListener('load', renderDeptChartsGuaranteed);
window.addEventListener('pageshow', renderDeptChartsGuaranteed);
window.addEventListener('resize', () => {
    if (typeof Plotly !== 'undefined') {
        const hc = document.getElementById('headcountChart');
        if (hc && hc.classList.contains('js-plotly-plot')) Plotly.Plots.resize(hc);
        const pc = document.getElementById('payrollChart');
        if (pc && pc.classList.contains('js-plotly-plot')) Plotly.Plots.resize(pc);
    }
});
window.addEventListener('themechanged', renderDeptChartsGuaranteed);


// Interactive Department Intelligence Modal Populator
window.openDeptDetailModal = function(id) {
    const dept = deptData.find(d => d.id === id);
    if (!dept) return;

    const modalEl = document.getElementById('deptDetailModal');
    if (!modalEl) return;

    const avatar = document.getElementById('mDeptAvatar');
    if (avatar) {
        avatar.textContent = dept.name ? dept.name[0] : 'D';
        avatar.style.background = (dept.color || '#2563EB') + '22';
        avatar.style.color = dept.color || '#2563EB';
    }

    const nameEl = document.getElementById('mDeptName');
    if (nameEl) nameEl.textContent = dept.name || 'Department';

    const codeEl = document.getElementById('mDeptCode');
    if (codeEl) codeEl.textContent = dept.code || 'DEPT';

    const statusEl = document.getElementById('mDeptStatus');
    if (statusEl) {
        statusEl.className = 'dept-status ' + (dept.utilization > 100 ? 'status-critical' : dept.utilization > 90 ? 'status-warning' : dept.utilization > 50 ? 'status-normal' : 'status-good');
        statusEl.textContent = dept.utilization > 100 ? 'Over Budget' : dept.utilization > 90 ? 'Critical' : dept.utilization > 70 ? 'High' : dept.utilization > 40 ? 'Normal' : 'Good';
    }

    const headEl = document.getElementById('mDeptHead');
    if (headEl) headEl.textContent = dept.head_name ? 'Department Lead: ' + dept.head_name : 'No lead assigned';

    const headCountEl = document.getElementById('mDeptHeadcount');
    if (headCountEl) headCountEl.textContent = dept.headcount || 0;

    const shareEl = document.getElementById('mDeptHeadcountShare');
    const totalHead = 170;
    const share = totalHead > 0 ? (((dept.headcount || 0) / totalHead) * 100).toFixed(1) : 0;
    if (shareEl) shareEl.textContent = share + '% of company (' + totalHead + ' total)';

    const sym = '₹';
    const payrollEl = document.getElementById('mDeptPayroll');
    if (payrollEl) payrollEl.textContent = sym + Number(dept.total_payroll || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

    const avgSalaryEl = document.getElementById('mDeptAvgSalary');
    if (avgSalaryEl) avgSalaryEl.textContent = 'Avg Salary: ' + sym + Number(dept.avg_salary || 0).toLocaleString(undefined, {maximumFractionDigits: 0});

    const budgetEl = document.getElementById('mDeptBudget');
    if (budgetEl) budgetEl.textContent = sym + Number(dept.budget || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

    const spentEl = document.getElementById('mDeptSpent');
    if (spentEl) spentEl.textContent = 'Spent: ' + sym + Number(dept.spent || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

    const remainingEl = document.getElementById('mDeptRemaining');
    if (remainingEl) remainingEl.textContent = sym + Number(dept.remaining || 0).toLocaleString(undefined, {minimumFractionDigits: 2, maximumFractionDigits: 2});

    const utilPctEl = document.getElementById('mDeptUtilPct');
    if (utilPctEl) utilPctEl.textContent = (dept.utilization || 0).toFixed(1) + '% utilized';

    const util = Math.min(dept.utilization || 0, 100);
    const pBar = document.getElementById('mDeptProgressBar');
    if (pBar) {
        pBar.style.width = util + '%';
        pBar.style.background = (dept.utilization > 100) ? '#EF4444' : 'linear-gradient(90deg, #059669 0%, #10B981 100%)';
    }

    const utilBadge = document.getElementById('mDeptUtilBadge');
    if (utilBadge) {
        utilBadge.textContent = (dept.utilization || 0).toFixed(1) + '%';
        utilBadge.style.color = (dept.utilization > 100) ? '#EF4444' : '#10B981';
    }

    const spentText = document.getElementById('mDeptSpentText');
    if (spentText) spentText.textContent = 'Spent: ' + sym + Number(dept.spent || 0).toLocaleString();

    const budgetText = document.getElementById('mDeptBudgetText');
    if (budgetText) budgetText.textContent = 'Allocated: ' + sym + Number(dept.budget || 0).toLocaleString();

    // Breakdown
    const typesDiv = document.getElementById('mDeptTypes');
    if (typesDiv) {
        typesDiv.innerHTML = '';
        if (dept.type_breakdown && Object.keys(dept.type_breakdown).length > 0) {
            for (let [type, count] of Object.entries(dept.type_breakdown)) {
                const pct = dept.headcount > 0 ? ((count / dept.headcount) * 100).toFixed(0) : 0;
                const row = document.createElement('div');
                row.className = 'd-flex justify-content-between align-items-center';
                row.style.fontSize = '0.8rem';
                row.innerHTML = `
                    <span style="color: var(--text-secondary);">${type.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())}</span>
                    <span class="fw-bold">${count} <small style="color: var(--text-secondary); font-weight: normal;">(${pct}%)</small></span>
                `;
                typesDiv.appendChild(row);
            }
        } else {
            typesDiv.innerHTML = '<span style="font-size: 0.75rem; color: var(--text-secondary);">No employment breakdown recorded.</span>';
        }
    }

    // Skills
    const skillsDiv = document.getElementById('mDeptSkills');
    if (skillsDiv) {
        skillsDiv.innerHTML = '';
        if (dept.top_skills && dept.top_skills.length > 0) {
            dept.top_skills.forEach(skill => {
                const tag = document.createElement('span');
                tag.className = 'skill-tag';
                tag.textContent = skill;
                skillsDiv.appendChild(tag);
            });
        } else {
            skillsDiv.innerHTML = '<span style="font-size: 0.75rem; color: var(--text-secondary);">No skill tags mapped yet.</span>';
        }
    }

    const modal = new bootstrap.Modal(modalEl);
    modal.show();
};

// Department table real-time filter
window.filterDeptTable = function() {
    const q = (document.getElementById('deptSearchInput')?.value || '').toLowerCase().trim();
    const rows = document.querySelectorAll('table[data-twin-table="departments"] tbody tr');
    let visible = 0;
    rows.forEach(r => {
        const text = r.textContent.toLowerCase();
        const match = !q || text.includes(q);
        r.style.display = match ? '' : 'none';
        if (match) visible++;
    });
    const badge = document.getElementById('deptCountBadge');
    if (badge) badge.textContent = visible + ' records';
};

function submitDepartment() {
    const form = document.getElementById('addDeptForm');
    const formData = new FormData(form);
    
    fetch('/business-twin/departments/add', {
        method: 'POST',
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast('Department created successfully!', 'success');
            const modal = bootstrap.Modal.getInstance(document.getElementById('addDeptModal'));
            modal.hide();
            setTimeout(() => window.location.reload(), 800);
        } else {
            showToast(data.error || 'Error creating department', 'error');
        }
    })
    .catch(err => {
        showToast('Network error: ' + err.message, 'error');
    });
}

function showToast(message, type) {
    const toast = document.createElement('div');
    toast.style.cssText = `
        position: fixed; top: 20px; right: 20px; z-index: 9999;
        padding: 12px 24px; border-radius: 8px; font-weight: 500;
        background: ${type === 'success' ? 'rgba(16,185,129,0.9)' : 'rgba(239,68,68,0.9)'};
        color: white; backdrop-filter: blur(10px);
        animation: slideIn 0.3s ease;
    `;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 3000);
}

function submitImportDept() {
    const form = document.getElementById('importDeptForm');
    const formData = new FormData(form);
    var csrfMeta = document.querySelector('meta[name="csrf-token"]');
    var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
    var headers = { 'X-Requested-With': 'XMLHttpRequest' };
    if (csrfToken) headers['X-CSRFToken'] = csrfToken;

    fetch('/business-twin/departments/import-csv', {
        method: 'POST',
        headers: headers,
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            showToast(data.message || 'Departments imported successfully!', 'success');
            const modal = bootstrap.Modal.getInstance(document.getElementById('importDeptModal'));
            if (modal) modal.hide();
            setTimeout(() => window.location.reload(), 800);
        } else {
            showToast(data.error || 'Import failed', 'error');
        }
    })
    .catch(err => {
        showToast('Import error: ' + err.message, 'error');
    });
}

function confirmDeleteAllDepartments() {
    window.twConfirmAction({
        title: 'Delete All Departments',
        message: 'WARNING: This will delete ALL departments and safely detach linked employees and financial records. Are you sure you want to proceed?',
        confirmText: 'Delete All Departments',
        variant: 'danger'
    }, function(done) {
        var csrfMeta = document.querySelector('meta[name="csrf-token"]');
        var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
        var headers = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
        if (csrfToken) headers['X-CSRFToken'] = csrfToken;

        fetch('/business-twin/departments/delete-all', {
            method: 'DELETE',
            headers: headers
        })
        .then(r => r.json())
        .then(data => {
            done();
            if (data.success) {
                showToast(data.message || 'All departments deleted', 'success');
                setTimeout(() => window.location.reload(), 700);
            } else {
                showToast(data.error || 'Failed to delete all departments', 'error');
            }
        })
        .catch(err => {
            done();
            showToast('Network error: ' + err.message, 'error');
        });
    });
}

// ─── Edit & Delete Department Handlers ───
window.openEditDeptModal = function(id) {
    const dept = deptData.find(d => d.id === id);
    if (!dept) return;

    document.getElementById('editDeptId').value = dept.id;
    document.getElementById('editDeptName').value = dept.name || '';
    document.getElementById('editDeptCode').value = dept.code || '';
    document.getElementById('editDeptHead').value = dept.head_name || '';
    document.getElementById('editDeptBudget').value = dept.budget || 0;
    document.getElementById('editDeptColor').value = dept.color || '#2563EB';
    document.getElementById('editDeptDesc').value = dept.description || '';
    document.getElementById('editDeptActive').checked = dept.is_active !== false;

    const modalEl = document.getElementById('editDeptModal');
    if (modalEl && typeof bootstrap !== 'undefined') {
        const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
        modal.show();
    }
};

window.submitEditDept = function(e) {
    e.preventDefault();
    const id = document.getElementById('editDeptId').value;
    const btn = document.getElementById('btnSaveEditDept');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fas fa-spinner fa-spin me-1"></i>Saving...';
    }

    const form = document.getElementById('editDeptForm');
    const formData = new FormData(form);

    fetch('/business-twin/departments/edit/' + id, {
        method: 'POST',
        headers: { 'X-Requested-With': 'XMLHttpRequest' },
        body: formData
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (typeof showToast === 'function') showToast(data.message || 'Department updated successfully', 'success');
            setTimeout(() => location.reload(), 400);
        } else {
            alert(data.error || 'Update failed');
            if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check me-1"></i>Save Changes'; }
        }
    })
    .catch(err => {
        alert('Network error: ' + err);
        if (btn) { btn.disabled = false; btn.innerHTML = '<i class="fas fa-check me-1"></i>Save Changes'; }
    });
};

window.deleteDepartment = function(deptId, deptName) {
    if (!confirm('Are you sure you want to delete department "' + (deptName || deptId) + '"? Employees and projects in this department will be detached.')) {
        return;
    }
    const csrfMeta = document.querySelector('meta[name="csrf-token"]');
    const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

    fetch('/business-twin/departments/delete/' + deptId, {
        method: 'DELETE',
        headers: {
            'X-Requested-With': 'XMLHttpRequest',
            'X-CSRFToken': csrfToken
        }
    })
    .then(r => r.json())
    .then(data => {
        if (data.success) {
            if (typeof showToast === 'function') showToast(data.message || 'Department deleted', 'info');
            setTimeout(() => location.reload(), 300);
        } else {
            alert(data.error || 'Delete failed');
        }
    })
    .catch(err => alert('Delete error: ' + err));
};

