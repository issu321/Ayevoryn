
(function () {
    'use strict';
    function parseCell(text) {
        var t = (text || '').trim().replace(/[$,%\s]/g, '');
        if (!t || t === '-') return null;
        var n = parseFloat(t.replace(/,/g, ''));
        return isNaN(n) ? null : n;
    }
    function cellText(tr, idx) {
        var td = tr.cells[idx];
        return td ? td.textContent : '';
    }
    function initTable(table) {
        var twin = table.getAttribute('data-twin-table');
        if (!twin || table.dataset.twReady) return;
        table.dataset.twReady = '1';
        var bulkUrl = table.getAttribute('data-bulk-url') || '/business-twin/bulk-delete';
        var thead = table.tHead, tbody = table.tBodies[0];
        if (!thead || !tbody || !thead.rows.length) return;
        var headRow = thead.rows[0];

        /* Responsive container accessibility */
        var holder = table.closest('.table-responsive') || table.parentElement;
        if (holder && !holder.hasAttribute('tabindex')) {
            holder.setAttribute('tabindex', '0');
            holder.setAttribute('role', 'region');
            holder.setAttribute('aria-label', (twin.charAt(0).toUpperCase() + twin.slice(1)) + ' Records Table');
        }

        /* 1. selection column with ARIA */
        var selTh = document.createElement('th');
        selTh.className = 'tw-nosort';
        selTh.setAttribute('scope', 'col');
        selTh.setAttribute('role', 'columnheader');
        selTh.style.width = '36px';
        selTh.innerHTML = '<input type="checkbox" class="form-check-input tw-select-all" aria-label="Select all rows" title="Select all rows">';
        headRow.insertBefore(selTh, headRow.cells[0]);

        var dataRows = [], otherRows = [];
        Array.prototype.forEach.call(tbody.rows, function (tr) {
            var id = tr.dataset.recordId || tr.dataset.id;
            var td = document.createElement('td');
            if (id) {
                td.innerHTML = '<input type="checkbox" class="form-check-input tw-row-check" value="' + id + '" aria-label="Select row ' + id + '">';
                dataRows.push(tr);
            } else { otherRows.push(tr); }
            tr.insertBefore(td, tr.cells[0]);

            /* Transform row-level action buttons into sleek circular bubble action buttons */
            tr.querySelectorAll('button, a.btn').forEach(function(btn) {
                if (btn.querySelector('.fa-pencil-alt, .fa-trash-alt, .fa-eye, .fa-edit, .fa-trash, .fa-users') || (btn.title && btn.title.match(/Edit|Delete|View|Details/i))) {
                    btn.classList.add('tw-bubble-action-btn');
                }
            });
        });

        /* 2. toolbar with ARIA labels and live region */
        var bar = document.createElement('div');
        bar.className = 'tw-toolbar';
        bar.setAttribute('role', 'toolbar');
        bar.setAttribute('aria-label', 'Table controls');
        bar.innerHTML =
            '<div class="tw-search"><i class="fas fa-search" aria-hidden="true"></i>' +
            '<input type="text" placeholder="Search records..." role="searchbox" aria-label="Search records"></div>' +
            '<button type="button" class="tw-btn-filter" aria-label="Toggle filters"><i class="fas fa-sliders-h"></i> Filters <span class="tw-filter-badge">0</span></button>' +
            '<span class="tw-count" role="status" aria-live="polite"></span>' +
            '<span class="tw-sel-count" role="status" aria-live="polite"></span>' +
            '<button type="button" class="tw-btn-bulk" aria-label="Delete selected records"><i class="fas fa-trash-alt" aria-hidden="true"></i> Delete Selected</button>' +
            '<button type="button" class="tw-btn-clear" aria-label="Clear selected rows">Clear selection</button>';
        holder.insertBefore(bar, holder.firstChild);

        var drawer = document.createElement('div');
        drawer.className = 'tw-filter-drawer';
        drawer.innerHTML =
            '<div class="row g-2 align-items-end">' +
            '  <div class="col-sm-3 col-6">' +
            '    <label style="font-size: 11px; font-weight: 600; color: var(--text-secondary); text-transform: uppercase;">From Date</label>' +
            '    <input type="date" class="form-control-glass form-control-sm tw-f-from" style="font-size: 12px; width: 100%;">' +
            '  </div>' +
            '  <div class="col-sm-3 col-6">' +
            '    <label style="font-size: 11px; font-weight: 600; color: var(--text-secondary); text-transform: uppercase;">To Date</label>' +
            '    <input type="date" class="form-control-glass form-control-sm tw-f-to" style="font-size: 12px; width: 100%;">' +
            '  </div>' +
            '  <div class="col-sm-2 col-6">' +
            '    <label style="font-size: 11px; font-weight: 600; color: var(--text-secondary); text-transform: uppercase;">Min Amount</label>' +
            '    <input type="number" step="0.01" placeholder="Min" class="form-control-glass form-control-sm tw-f-min" style="font-size: 12px; width: 100%;">' +
            '  </div>' +
            '  <div class="col-sm-2 col-6">' +
            '    <label style="font-size: 11px; font-weight: 600; color: var(--text-secondary); text-transform: uppercase;">Max Amount</label>' +
            '    <input type="number" step="0.01" placeholder="Max" class="form-control-glass form-control-sm tw-f-max" style="font-size: 12px; width: 100%;">' +
            '  </div>' +
            '  <div class="col-sm-2 col-12 d-flex gap-2">' +
            '    <button type="button" class="btn btn-sm btn-outline-glass tw-f-reset w-100" style="font-size: 12px; font-weight: 600;"><i class="fas fa-undo me-1"></i> Reset</button>' +
            '  </div>' +
            '</div>';
        holder.insertBefore(drawer, bar.nextSibling);

        var search = bar.querySelector('.tw-search input');
        var filterBtn = bar.querySelector('.tw-btn-filter');
        var filterBadge = bar.querySelector('.tw-filter-badge');
        var countEl = bar.querySelector('.tw-count');
        var selEl = bar.querySelector('.tw-sel-count');
        var bulkBtn = bar.querySelector('.tw-btn-bulk');
        var clearBtn = bar.querySelector('.tw-btn-clear');
        var selectAll = headRow.querySelector('.tw-select-all');

        var fFrom = drawer.querySelector('.tw-f-from');
        var fTo = drawer.querySelector('.tw-f-to');
        var fMin = drawer.querySelector('.tw-f-min');
        var fMax = drawer.querySelector('.tw-f-max');
        var fReset = drawer.querySelector('.tw-f-reset');

        var dateColIdx = -1, amountColIdx = -1;
        Array.prototype.forEach.call(headRow.cells, function(th, idx) {
            var txt = (th.textContent || '').trim().toLowerCase();
            if (dateColIdx === -1 && (txt.indexOf('date') !== -1 || txt.indexOf('created') !== -1 || txt.indexOf('joined') !== -1)) {
                dateColIdx = idx;
            }
            if (amountColIdx === -1 && (txt.indexOf('amount') !== -1 || txt.indexOf('spent') !== -1 || txt.indexOf('budget') !== -1 || txt.indexOf('price') !== -1 || txt.indexOf('balance') !== -1)) {
                amountColIdx = idx;
            }
        });

        filterBtn.addEventListener('click', function() {
            var isShown = drawer.classList.contains('show');
            drawer.classList.toggle('show', !isShown);
        });

        /* 2b. Floating Futuristic Action Bubble Pop Bar */
        var bubbleBar = document.querySelector('.tw-floating-bubble-bar[data-for-twin="' + twin + '"]');
        if (!bubbleBar) {
            bubbleBar = document.createElement('div');
            bubbleBar.className = 'tw-floating-bubble-bar';
            bubbleBar.setAttribute('data-for-twin', twin);
            bubbleBar.setAttribute('role', 'region');
            bubbleBar.setAttribute('aria-label', 'Floating record action bubble');
            bubbleBar.innerHTML =
                '<span class="tw-bubble-count"><i class="fas fa-check-circle" style="color: var(--accent-primary);"></i> <span class="tw-bubble-text">0 selected</span></span>' +
                '<div class="tw-bubble-actions-group">' +
                '  <button type="button" class="tw-bubble-circle-btn tw-bubble-edit" title="Edit Selected Record" aria-label="Edit selected record"><i class="fas fa-pencil-alt"></i></button>' +
                '  <button type="button" class="tw-bubble-circle-btn tw-bubble-export" title="Export Selected as CSV" aria-label="Export selected records"><i class="fas fa-file-download"></i></button>' +
                '  <button type="button" class="tw-bubble-circle-btn tw-bubble-delete" title="Delete Selected Records" aria-label="Delete selected records"><i class="fas fa-trash-alt"></i></button>' +
                '  <button type="button" class="tw-bubble-circle-btn tw-bubble-dismiss" title="Clear selection" aria-label="Clear selected rows"><i class="fas fa-times"></i></button>' +
                '</div>';
            document.body.appendChild(bubbleBar);
        }
        var bubbleText = bubbleBar.querySelector('.tw-bubble-text');
        var bubbleEditBtn = bubbleBar.querySelector('.tw-bubble-edit');
        var bubbleExportBtn = bubbleBar.querySelector('.tw-bubble-export');
        var bubbleDeleteBtn = bubbleBar.querySelector('.tw-bubble-delete');
        var bubbleDismissBtn = bubbleBar.querySelector('.tw-bubble-dismiss');

        function refreshCounts(isFiltered) {
            var visible = dataRows.filter(function (tr) { return !tr.classList.contains('tw-row-hidden'); }).length;
            countEl.textContent = 'Showing ' + visible + ' of ' + dataRows.length + ' records' + (isFiltered ? ' (Filtered)' : '');
            var checked = tbody.querySelectorAll('.tw-row-check:checked');
            selEl.textContent = checked.length ? checked.length + ' selected' : '';
            bulkBtn.classList.toggle('show', checked.length > 0);
            clearBtn.classList.toggle('show', checked.length > 0);
            if (selectAll) selectAll.checked = dataRows.length > 0 && checked.length === dataRows.length;

            /* Floating Bubble Pop State */
            if (checked.length > 0) {
                bubbleText.textContent = checked.length + (checked.length === 1 ? ' record selected' : ' records selected');
                bubbleBar.classList.add('show');
                bubbleEditBtn.style.display = checked.length === 1 ? 'inline-flex' : 'none';
            } else {
                bubbleBar.classList.remove('show');
            }

            /* Zero match search state row */
            var noMatchRow = tbody.querySelector('.tw-no-match-row');
            if (visible === 0 && dataRows.length > 0) {
                if (!noMatchRow) {
                    noMatchRow = document.createElement('tr');
                    noMatchRow.className = 'tw-no-match-row';
                    noMatchRow.setAttribute('role', 'status');
                    var colCount = headRow.cells.length;
                    noMatchRow.innerHTML = '<td colspan="' + colCount + '" class="text-center py-5" style="color: var(--text-secondary);">' +
                        '<div class="d-flex flex-column align-items-center justify-content-center">' +
                        '<i class="fas fa-search mb-2" style="font-size: 24px; opacity: 0.4;" aria-hidden="true"></i>' +
                        '<span style="font-weight: 600; color: var(--text-primary);">No records matching your search</span>' +
                        '<small style="color: var(--text-muted);">Try a different query or clear the filter.</small>' +
                        '</div></td>';
                    tbody.appendChild(noMatchRow);
                }
                noMatchRow.style.display = '';
            } else if (noMatchRow) {
                noMatchRow.style.display = 'none';
            }
        }
        refreshCounts(false);

        function runFilters() {
            var q = search.value.trim().toLowerCase();
            var fromVal = fFrom.value;
            var toVal = fTo.value;
            var minVal = parseFloat(fMin.value);
            var maxVal = parseFloat(fMax.value);

            var activeCount = 0;
            if (fromVal) activeCount++;
            if (toVal) activeCount++;
            if (!isNaN(minVal)) activeCount++;
            if (!isNaN(maxVal)) activeCount++;

            if (activeCount > 0) {
                filterBadge.textContent = activeCount;
                filterBadge.style.display = 'inline-block';
                filterBtn.classList.add('active');
            } else {
                filterBadge.style.display = 'none';
                filterBtn.classList.remove('active');
            }

            dataRows.forEach(function (tr) {
                var hide = false;
                if (q && tr.textContent.toLowerCase().indexOf(q) === -1) {
                    hide = true;
                }
                if (!hide && (fromVal || toVal) && dateColIdx !== -1) {
                    var rawD = cellText(tr, dateColIdx).trim().slice(0, 10);
                    if (fromVal && rawD < fromVal) hide = true;
                    if (toVal && rawD > toVal) hide = true;
                }
                if (!hide && (!isNaN(minVal) || !isNaN(maxVal)) && amountColIdx !== -1) {
                    var amt = parseCell(cellText(tr, amountColIdx));
                    if (amt !== null) {
                        if (!isNaN(minVal) && amt < minVal) hide = true;
                        if (!isNaN(maxVal) && amt > maxVal) hide = true;
                    }
                }
                tr.classList.toggle('tw-row-hidden', hide);
            });
            refreshCounts(activeCount > 0);
        }

        search.addEventListener('input', runFilters);
        fFrom.addEventListener('change', runFilters);
        fTo.addEventListener('change', runFilters);
        fMin.addEventListener('input', runFilters);
        fMax.addEventListener('input', runFilters);

        fReset.addEventListener('click', function() {
            fFrom.value = '';
            fTo.value = '';
            fMin.value = '';
            fMax.value = '';
            search.value = '';
            runFilters();
        });

        tbody.addEventListener('change', function (e) {
            if (e.target.classList.contains('tw-row-check')) refreshCounts();
        });

        if (selectAll) selectAll.addEventListener('change', function () {
            var on = selectAll.checked;
            dataRows.forEach(function (tr) {
                var cb = tr.querySelector('.tw-row-check');
                if (cb && !tr.classList.contains('tw-row-hidden')) cb.checked = on;
            });
            refreshCounts();
        });

        clearBtn.addEventListener('click', function () {
            tbody.querySelectorAll('.tw-row-check:checked').forEach(function (cb) { cb.checked = false; });
            refreshCounts();
        });

        if (bubbleDismissBtn) {
            bubbleDismissBtn.addEventListener('click', function () {
                clearBtn.click();
            });
        }

        /* 2c. Resync API for dynamically added/updated rows */
        function resync() {
            dataRows = Array.prototype.filter.call(tbody.rows, function (tr) {
                var id = tr.dataset.recordId || tr.dataset.id;
                return !!id && !tr.classList.contains('tw-no-match-row');
            });
            dataRows.forEach(function (tr) {
                var id = tr.dataset.recordId || tr.dataset.id;
                if (id && (!tr.cells.length || !tr.cells[0].querySelector('.tw-row-check'))) {
                    var td = document.createElement('td');
                    td.innerHTML = '<input type="checkbox" class="form-check-input tw-row-check" value="' + id + '" aria-label="Select row ' + id + '">';
                    tr.insertBefore(td, tr.cells[0]);
                }
                tr.querySelectorAll('button, a.btn').forEach(function (btn) {
                    if (btn.querySelector('.fa-pencil-alt, .fa-trash-alt, .fa-eye, .fa-edit, .fa-trash, .fa-users') || (btn.title && btn.title.match(/Edit|Delete|View|Details/i))) {
                        btn.classList.add('tw-bubble-action-btn');
                    }
                });
            });
            refreshCounts(false);
        }
        table.twResync = resync;

        /* 3. bulk delete with custom in-app glass confirmation modal */
        function executeBulkDelete() {
            var ids = Array.prototype.map.call(
                tbody.querySelectorAll('.tw-row-check:checked'),
                function (cb) { return parseInt(cb.value, 10); }
            ).filter(function (n) { return !isNaN(n); });
            if (!ids.length) return;

            window.twConfirmAction({
                title: 'Confirm Bulk Deletion',
                message: 'Permanently delete ' + ids.length + ' selected ' + twin + ' record(s)? This action cannot be reversed.',
                confirmText: 'Delete ' + ids.length + ' Records',
                variant: 'danger'
            }, function (done) {
                bulkBtn.disabled = true;
                if (bubbleDeleteBtn) bubbleDeleteBtn.disabled = true;

                var csrfMeta = document.querySelector('meta[name="csrf-token"]');
                var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
                var headers = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
                if (csrfToken) headers['X-CSRFToken'] = csrfToken;

                fetch(bulkUrl, {
                    method: 'POST',
                    headers: headers,
                    body: JSON.stringify({ twin: twin, ids: ids })
                }).then(function (r) { return r.json(); }).then(function (d) {
                    done();
                    if (d.success) {
                        if (typeof window.showToast === 'function') {
                            window.showToast(d.message || (ids.length + ' records deleted successfully'), 'success');
                        }
                        setTimeout(function () { window.location.reload(); }, 600);
                    } else {
                        if (typeof window.showToast === 'function') {
                            window.showToast(d.error || 'Bulk delete failed', 'error');
                        }
                        bulkBtn.disabled = false;
                        if (bubbleDeleteBtn) bubbleDeleteBtn.disabled = false;
                    }
                }).catch(function (err) {
                    done();
                    if (typeof window.showToast === 'function') {
                        window.showToast('Network error during bulk delete: ' + err.message, 'error');
                    }
                    bulkBtn.disabled = false;
                    if (bubbleDeleteBtn) bubbleDeleteBtn.disabled = false;
                });
            });
        }

        bulkBtn.addEventListener('click', executeBulkDelete);
        if (bubbleDeleteBtn) {
            bubbleDeleteBtn.addEventListener('click', executeBulkDelete);
        }

        /* Bubble Edit Action */
        if (bubbleEditBtn) {
            bubbleEditBtn.addEventListener('click', function () {
                var checked = tbody.querySelectorAll('.tw-row-check:checked');
                if (checked.length !== 1) return;
                var recId = checked[0].value;
                var row = checked[0].closest('tr');
                if (row) {
                    var rowEditBtn = row.querySelector('button[onclick*="Edit"], button[onclick*="edit"], a[href*="edit"], [title*="Edit"]');
                    if (rowEditBtn) {
                        rowEditBtn.click();
                        return;
                    }
                }
                if (twin === 'revenue' && typeof window.openEditModal === 'function') {
                    window.openEditModal(recId);
                    return;
                }
                if (twin === 'departments' && typeof window.openEditDeptModal === 'function') {
                    window.openEditDeptModal(recId);
                    return;
                }
                if (twin === 'expenses' && typeof window.openEditExpenseModal === 'function') {
                    window.openEditExpenseModal(recId);
                    return;
                }
                if (twin === 'employees' && typeof window.openEditEmployeeModal === 'function') {
                    window.openEditEmployeeModal(recId);
                    return;
                }
                if (twin === 'customers' && typeof window.openEditCustomerModal === 'function') {
                    window.openEditCustomerModal(recId);
                    return;
                }
                if (twin === 'suppliers' && typeof window.openEditSupplierModal === 'function') {
                    window.openEditSupplierModal(recId);
                    return;
                }
                if (twin === 'inventory' && typeof window.openEditInventoryModal === 'function') {
                    window.openEditInventoryModal(recId);
                    return;
                }
            });
        }

        /* Bubble Export Action */
        if (bubbleExportBtn) {
            bubbleExportBtn.addEventListener('click', function () {
                var checkedRows = Array.prototype.filter.call(tbody.querySelectorAll('tr'), function (tr) {
                    var cb = tr.querySelector('.tw-row-check');
                    return cb && cb.checked;
                });
                if (!checkedRows.length) return;

                var headers = [];
                Array.prototype.forEach.call(headRow.cells, function (th, i) {
                    if (i === 0) return; // skip checkbox col
                    var t = (th.textContent || '').trim();
                    if (t.toLowerCase().indexOf('action') === -1) {
                        headers.push('"' + t.replace(/"/g, '""') + '"');
                    }
                });

                var csvLines = [headers.join(',')];
                checkedRows.forEach(function (tr) {
                    var rowCells = [];
                    Array.prototype.forEach.call(tr.cells, function (td, i) {
                        if (i === 0) return; // skip checkbox
                        if (i <= headers.length) {
                            var val = (td.textContent || '').trim().replace(/\s+/g, ' ');
                            rowCells.push('"' + val.replace(/"/g, '""') + '"');
                        }
                    });
                    csvLines.push(rowCells.join(','));
                });

                var blob = new Blob([csvLines.join('\n')], { type: 'text/csv;charset=utf-8;' });
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.setAttribute('download', twin + '_selected_records_' + new Date().toISOString().slice(0, 10) + '.csv');
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            });
        }

        /* 4. accessible column sorting with keyboard and ARIA support */
        Array.prototype.forEach.call(headRow.cells, function (th, idx) {
            th.setAttribute('scope', 'col');
            th.setAttribute('role', 'columnheader');
            if (th.classList.contains('tw-nosort')) return;

            var label = (th.textContent || '').toLowerCase();
            if (label.indexOf('action') !== -1) { th.classList.add('tw-nosort'); return; }

            th.setAttribute('tabindex', '0');
            th.setAttribute('aria-sort', 'none');
            var headerText = (th.textContent || '').trim();
            th.setAttribute('aria-label', headerText + ', sort column');

            function performSort() {
                var desc = th.classList.contains('tw-sorted');
                Array.prototype.forEach.call(headRow.cells, function (c) {
                    c.classList.remove('tw-sorted', 'tw-sorted-desc');
                    if (!c.classList.contains('tw-nosort')) {
                        c.setAttribute('aria-sort', 'none');
                    }
                });

                if (desc) {
                    th.classList.add('tw-sorted-desc');
                    th.setAttribute('aria-sort', 'descending');
                } else {
                    th.classList.add('tw-sorted');
                    th.setAttribute('aria-sort', 'ascending');
                }

                var sorted = dataRows.slice().sort(function (a, b) {
                    var na = parseCell(cellText(a, idx)), nb = parseCell(cellText(b, idx));
                    var cmp;
                    if (na !== null && nb !== null) { cmp = na - nb; }
                    else if (na !== null) { cmp = -1; }
                    else if (nb !== null) { cmp = 1; }
                    else { cmp = cellText(a, idx).toLowerCase().localeCompare(cellText(b, idx).toLowerCase()); }
                    return desc ? -cmp : cmp;
                });
                sorted.concat(otherRows).forEach(function (tr) { tbody.appendChild(tr); });
            }

            th.addEventListener('click', performSort);
            th.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    performSort();
                }
            });
        });
    }

    /* 5. single-record delete helper using in-app glass confirmation modal */
    window.twDeleteOne = function (twin, id, bulkUrl) {
        window.twConfirmAction({
            title: 'Delete ' + (twin.charAt(0).toUpperCase() + twin.slice(1)) + ' Record',
            message: 'Permanently delete this record? This action cannot be reversed.',
            confirmText: 'Delete Record',
            variant: 'danger'
        }, function (done) {
            var csrfMeta = document.querySelector('meta[name="csrf-token"]');
            var csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';
            var headers = { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' };
            if (csrfToken) headers['X-CSRFToken'] = csrfToken;

            fetch(bulkUrl || '/business-twin/bulk-delete', {
                method: 'POST',
                headers: headers,
                body: JSON.stringify({ twin: twin, ids: [id] })
            }).then(function (r) { return r.json(); }).then(function (d) {
                done();
                if (d.success) {
                    if (typeof window.showToast === 'function') {
                        window.showToast('Record deleted successfully', 'success');
                    }
                    setTimeout(function () { window.location.reload(); }, 500);
                } else {
                    if (typeof window.showToast === 'function') {
                        window.showToast(d.error || 'Delete failed', 'error');
                    }
                }
            }).catch(function (err) {
                done();
                if (typeof window.showToast === 'function') {
                    window.showToast('Network error: ' + err.message, 'error');
                }
            });
        });
    };

    /* 6. Universal Glass Confirmation Modal Engine */
    window.twConfirmAction = function(options, onConfirm) {
        var modalEl = document.getElementById('twUniversalConfirmModal');
        if (!modalEl) {
            modalEl = document.createElement('div');
            modalEl.id = 'twUniversalConfirmModal';
            modalEl.className = 'modal fade';
            modalEl.tabIndex = -1;
            modalEl.setAttribute('aria-hidden', 'true');
            modalEl.style.zIndex = '10060';
            modalEl.innerHTML =
                '<div class="modal-dialog modal-dialog-centered modal-sm" style="max-width: 440px;">' +
                '  <div class="modal-content" style="background: var(--card-bg, #1A1F3A); backdrop-filter: blur(30px); -webkit-backdrop-filter: blur(30px); border: 1px solid rgba(239, 68, 68, 0.4); border-radius: 20px; box-shadow: 0 25px 60px rgba(0,0,0,0.5); color: var(--text-primary, #F8FAFC); overflow: hidden;">' +
                '    <div style="height: 4px; background: linear-gradient(90deg, #EF4444, #F59E0B);"></div>' +
                '    <div class="modal-body p-4 text-center">' +
                '      <div style="width: 58px; height: 58px; border-radius: 50%; background: rgba(239, 68, 68, 0.15); border: 1.5px solid rgba(239, 68, 68, 0.4); display: inline-flex; align-items: center; justify-content: center; margin-bottom: 16px; color: #EF4444; font-size: 24px;">' +
                '        <i class="fas fa-trash-can"></i>' +
                '      </div>' +
                '      <h5 id="twUniversalModalTitle" style="font-weight: 800; font-size: 1.15rem; margin-bottom: 8px; color: var(--text-primary, #F8FAFC);">Confirm Action</h5>' +
                '      <p id="twUniversalModalMsg" style="font-size: 0.9rem; color: var(--text-secondary, #94A3B8); line-height: 1.5; margin-bottom: 24px;">Are you sure you want to proceed?</p>' +
                '      <div class="d-flex justify-content-center gap-2">' +
                '        <button type="button" class="btn btn-outline-glass px-4 py-2" data-bs-dismiss="modal" style="border-radius: 12px; font-weight: 600;">Cancel</button>' +
                '        <button type="button" class="btn btn-danger px-4 py-2" id="twUniversalModalConfirmBtn" style="border-radius: 12px; font-weight: 700; background: #EF4444; border: none; box-shadow: 0 4px 14px rgba(239, 68, 68, 0.35);">' +
                '          <i class="fas fa-trash-alt me-1.5"></i> Confirm' +
                '        </button>' +
                '      </div>' +
                '    </div>' +
                '  </div>' +
                '</div>';
            document.body.appendChild(modalEl);
        }

        document.getElementById('twUniversalModalTitle').textContent = options.title || 'Confirm Deletion';
        document.getElementById('twUniversalModalMsg').textContent = options.message || 'Are you sure you want to proceed?';
        var confirmBtn = document.getElementById('twUniversalModalConfirmBtn');
        confirmBtn.innerHTML = '<i class="fas fa-trash-alt me-1.5"></i> ' + (options.confirmText || 'Delete');
        confirmBtn.disabled = false;

        var bsModal = new bootstrap.Modal(modalEl);
        bsModal.show();

        confirmBtn.onclick = function() {
            confirmBtn.disabled = true;
            confirmBtn.innerHTML = '<i class="fas fa-spinner fa-spin me-1.5"></i> Processing...';
            if (typeof onConfirm === 'function') {
                onConfirm(function() {
                    bsModal.hide();
                });
            } else {
                bsModal.hide();
            }
        };
    };

    /* 7. Public API to resync dynamic tables */
    window.twResyncTable = function(twinName) {
        var selector = twinName ? 'table[data-twin-table="' + twinName + '"]' : 'table[data-twin-table]';
        document.querySelectorAll(selector).forEach(function (tbl) {
            if (typeof tbl.twResync === 'function') tbl.twResync();
        });
    };

    function boot() {
        document.querySelectorAll('table[data-twin-table]').forEach(initTable);
    }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', boot); }
    else { boot(); }
})();
