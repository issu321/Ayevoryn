
    // ── Dedicated Sidebar Collapse / Expand Engine (Desktop & Tablet) ──
    window.toggleSidebarCollapse = function() {
        document.body.classList.toggle('sidebar-collapsed');
        const isCollapsed = document.body.classList.contains('sidebar-collapsed');
        try {
            localStorage.setItem('aevoryn_sidebar_collapsed', isCollapsed ? '1' : '0');
        } catch(e) {}
        const icon = document.getElementById('sidebarCollapseIcon');
        if (icon) {
            icon.className = isCollapsed ? 'fas fa-chevron-right' : 'fas fa-chevron-left';
        }
        const btn = document.getElementById('sidebarCollapseBtn');
        if (btn) {
            btn.setAttribute('title', isCollapsed ? 'Expand navigation (Ctrl+B)' : 'Collapse navigation (Ctrl+B)');
            btn.setAttribute('data-tooltip', isCollapsed ? 'Expand navigation' : 'Collapse navigation');
        }
        setTimeout(() => {
            window.dispatchEvent(new Event('resize'));
        }, 280);
    };

    // ── Mobile Compact Drawer Toggle (<992px) ──
    window.toggleMobileSidebar = function() {
        const sb = document.getElementById('sidebar');
        const bd = document.getElementById('sidebarBackdrop');
        if (sb) sb.classList.toggle('show');
        if (bd) bd.classList.toggle('show');
    };

    // Legacy / unified alias
    window.toggleSidebar = function() {
        if (window.innerWidth < 992) {
            window.toggleMobileSidebar();
        } else {
            window.toggleSidebarCollapse();
        }
    };

    // Global keyboard shortcut: Ctrl+B or Cmd+B to toggle sidebar collapse
    document.addEventListener('keydown', function(e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'b') {
            e.preventDefault();
            window.toggleSidebarCollapse();
        }
    });

    // Initialize sidebar state on page load
    (function initSidebar() {
        try {
            if (localStorage.getItem('aevoryn_sidebar_collapsed') === '1' && window.innerWidth >= 992) {
                document.body.classList.add('sidebar-collapsed');
                const icon = document.getElementById('sidebarCollapseIcon');
                if (icon) icon.className = 'fas fa-chevron-right';
                const btn = document.getElementById('sidebarCollapseBtn');
                if (btn) {
                    btn.setAttribute('title', 'Expand navigation (Ctrl+B)');
                    btn.setAttribute('data-tooltip', 'Expand navigation');
                }
            }
        } catch(e) {}
    })();
    
    // Global toast helper — tactile white clay / frosted glass styling
    window.showToast = function (message, type) {
        type = type || 'success';
        const colors = { success: '#059669', error: '#DC2626', warning: '#D97706', info: '#2563EB' };
        const color = colors[type] || '#059669';
        const icons = { success: 'check-circle', error: 'times-circle', warning: 'exclamation-triangle', info: 'info-circle' };
        let wrap = document.getElementById('global-toast-wrap');
        if (!wrap) {
            wrap = document.createElement('div');
            wrap.id = 'global-toast-wrap';
            wrap.style.cssText = 'position:fixed;top:24px;right:24px;z-index:10000;display:flex;flex-direction:column;gap:12px;pointer-events:none;';
            document.body.appendChild(wrap);
        }
        const t = document.createElement('div');
        t.style.cssText = 'min-width:280px;max-width:440px;padding:14px 18px;border-radius:14px;' +
            'background:var(--card-bg-solid, #FFFFFF);border:1px solid var(--border-color, #CBD5E1);border-left:5px solid ' + color + ';' +
            'color:var(--text-primary, #0F172A);font-size:13.5px;font-weight:600;box-shadow:0 14px 38px rgba(0,0,0,0.12), 0 2px 8px rgba(0,0,0,0.04);' +
            'display:flex;align-items:center;gap:12px;animation:toastIn .25s cubic-bezier(0.4, 0, 0.2, 1);pointer-events:auto;';
        t.innerHTML = '<i class="fas fa-' + icons[type] + '" style="color:' + color + ';font-size:17px;flex-shrink:0;"></i>' +
            '<div style="line-height:1.45;flex:1;">' + message + '</div>' +
            '<button type="button" style="background:none;border:none;color:var(--text-muted,#64748B);cursor:pointer;font-size:16px;padding:2px 4px;margin-left:8px;" onclick="this.parentElement.remove()">&times;</button>';
        wrap.appendChild(t);
        setTimeout(() => {
            t.style.opacity = '0';
            t.style.transform = 'translateY(-10px)';
            t.style.transition = 'all .3s ease';
            setTimeout(() => t.remove(), 300);
        }, 3800);
    };
    
    // Universal Plotly Theme Helper — ensures crisp, legible charts in light & dark modes
    window.getPlotlyThemeLayout = function(customLayout) {
        customLayout = customLayout || {};
        const themeId = document.documentElement.getAttribute('data-theme') || 'white_clay_glass';
        const isLight = themeId === 'white_clay_glass' || document.documentElement.style.colorScheme === 'light';
        
        const textColor = isLight ? '#0F172A' : '#F8FAFC';
        const subColor = isLight ? '#334155' : '#E2E8F0';
        const gridColor = isLight ? 'rgba(148, 163, 184, 0.28)' : 'rgba(255, 255, 255, 0.06)';
        const zeroLineColor = isLight ? 'rgba(100, 116, 139, 0.45)' : 'rgba(255, 255, 255, 0.15)';
        const hoverBg = isLight ? '#FFFFFF' : '#1E293B';
        const hoverBorder = isLight ? '#CBD5E1' : '#475569';
        const hoverText = isLight ? '#0F172A' : '#F8FAFC';
        const spikeColor = isLight ? 'rgba(100, 116, 139, 0.45)' : 'rgba(148, 163, 184, 0.35)';

        const base = {
            paper_bgcolor: 'transparent',
            plot_bgcolor: 'transparent',
            font: { family: 'Inter, sans-serif', color: textColor, size: 12 },
            hoverlabel: {
                bgcolor: hoverBg,
                bordercolor: hoverBorder,
                font: { family: 'Inter, sans-serif', color: hoverText, size: 12 },
                namelength: -1
            },
            xaxis: {
                gridcolor: gridColor,
                zerolinecolor: zeroLineColor,
                spikecolor: spikeColor,
                tickfont: { color: subColor, size: 11, family: 'Inter, sans-serif' },
                title: { font: { color: textColor, size: 12, family: 'Inter, sans-serif' } }
            },
            yaxis: {
                gridcolor: gridColor,
                zerolinecolor: zeroLineColor,
                spikecolor: spikeColor,
                tickfont: { color: subColor, size: 11, family: 'Inter, sans-serif' },
                title: { font: { color: textColor, size: 12, family: 'Inter, sans-serif' } }
            },
            legend: {
                font: { color: textColor, size: 12, family: 'Inter, sans-serif' }
            }
        };
        
        const merged = Object.assign({}, base, customLayout);
        if (customLayout.hoverlabel) merged.hoverlabel = Object.assign({}, base.hoverlabel, customLayout.hoverlabel);
        if (customLayout.xaxis) merged.xaxis = Object.assign({}, base.xaxis, customLayout.xaxis);
        if (customLayout.yaxis) merged.yaxis = Object.assign({}, base.yaxis, customLayout.yaxis);
        if (customLayout.legend) merged.legend = Object.assign({}, base.legend, customLayout.legend);
        if (customLayout.font) merged.font = Object.assign({}, base.font, customLayout.font);
        return merged;
    };

    // ─── 1-Click Instant Theme Toggle & Sync ───
    window.toggleTheme = function() {
        const cur = document.documentElement.getAttribute('data-theme') || 'white_clay_glass';
        const next = (cur.indexOf('dark') !== -1) ? 'white_clay_glass' : 'dark_clay_glass';
        window.setTheme(next);
    };

    // Seamless Dynamic Theme Switcher — Dual Persisted (Cookie + LocalStorage + Session + Real-Time DOM Styles)
    window.setTheme = function(themeId) {
        if (!themeId) return;
        const resolved = (themeId.indexOf('dark') !== -1) ? 'dark_clay_glass' : 'white_clay_glass';
        const scheme = (resolved === 'dark_clay_glass') ? 'dark' : 'light';

        // 1. Immediately apply attributes & properties to client (0ms latency)
        document.documentElement.setAttribute('data-theme', resolved);
        document.documentElement.style.colorScheme = scheme;

        try {
            localStorage.setItem('aevoryn_theme', resolved);
            document.cookie = 'aevoryn_theme=' + resolved + '; path=/; max-age=31536000; SameSite=Lax';
        } catch(e) {}

        const darkProps = {
            '--color-scheme': 'dark',
            '--bg-primary': '#0A0B0E',
            '--bg-secondary': '#11141E',
            '--sidebar-bg': '#11141E',
            '--topbar-bg': 'rgba(17, 20, 30, 0.85)',
            '--card-bg': 'rgba(18, 20, 28, 0.85)',
            '--card-bg-solid': '#14151B',
            '--accent-primary': '#6366F1',
            '--accent-primary-rgb': '99, 102, 241',
            '--accent-secondary': '#8B5CF6',
            '--accent-warning': '#F59E0B',
            '--accent-success': '#10B981',
            '--accent-danger': '#EF4444',
            '--text-primary': '#FFFFFF',
            '--text-secondary': '#CBD5E1',
            '--text-muted': '#94A3B8',
            '--border-color': 'rgba(255, 255, 255, 0.08)'
        };
        const lightProps = {
            '--color-scheme': 'light',
            '--bg-primary': '#F8FAFC',
            '--bg-secondary': '#FFFFFF',
            '--sidebar-bg': 'rgba(255, 255, 255, 0.92)',
            '--topbar-bg': 'rgba(255, 255, 255, 0.88)',
            '--card-bg': 'rgba(255, 255, 255, 0.78)',
            '--card-bg-solid': '#FFFFFF',
            '--accent-primary': '#2563EB',
            '--accent-primary-rgb': '37, 99, 235',
            '--accent-secondary': '#4F46E5',
            '--accent-warning': '#D97706',
            '--accent-success': '#059669',
            '--accent-danger': '#DC2626',
            '--text-primary': '#0F172A',
            '--text-secondary': '#334155',
            '--text-muted': '#64748B',
            '--border-color': 'rgba(203, 213, 225, 0.85)'
        };
        const activeProps = (scheme === 'dark') ? darkProps : lightProps;
        for (const [prop, val] of Object.entries(activeProps)) {
            document.documentElement.style.setProperty(prop, val);
        }

        const iconEl = document.getElementById('active-theme-icon');
        if (iconEl) {
            iconEl.className = (scheme === 'dark') ? 'fas fa-moon text-primary' : 'fas fa-sun text-warning';
        }
        const nameEl = document.getElementById('active-theme-name');
        if (nameEl) {
            nameEl.textContent = (scheme === 'dark') ? 'Dark Clay Glass' : 'Light Clay Glass';
        }

        document.querySelectorAll('.dropdown-menu-glass a[onclick*="setTheme"]').forEach(a => {
            const match = a.getAttribute('onclick').indexOf(resolved) !== -1;
            a.classList.toggle('active', match);
            a.classList.toggle('fw-bold', match);
            const checkIcon = a.querySelector('.fa-check');
            if (checkIcon) checkIcon.style.display = match ? 'inline-block' : 'none';
        });

        // Notify charts and UI listeners
        window.dispatchEvent(new CustomEvent('themechanged', { detail: { theme_id: resolved, color_scheme: scheme } }));

        // 2. Persist to server session and database
        const csrfMeta = document.querySelector('meta[name="csrf-token"]');
        const csrfToken = csrfMeta ? csrfMeta.getAttribute('content') : '';

        const headers = {
            'Content-Type': 'application/json',
            'X-Requested-With': 'XMLHttpRequest'
        };
        if (csrfToken) headers['X-CSRFToken'] = csrfToken;

        fetch('/settings/theme', {
            method: 'POST',
            headers: headers,
            body: JSON.stringify({ theme_id: resolved, csrf_token: csrfToken })
        })
        .then(r => r.json())
        .then(data => {
            if (typeof showToast === 'function') {
                showToast('Theme set to ' + (scheme === 'dark' ? 'Dark Clay Glass' : 'Light Clay Glass'), 'success');
            }
        })
        .catch(err => {
            console.warn('Theme backend sync notice:', err);
        });
    };
    
    // Auto-hide toasts
    setTimeout(() => {
        document.querySelectorAll('.toast-glass').forEach(t => t.style.opacity = '0');
        setTimeout(() => document.querySelectorAll('.toast-glass').forEach(t => t.remove()), 300);
    }, 5000);

    // =========================================================================
    // Universal Tiered Loader & Task State Manager (Aevoryn Executive Engine)
    // =========================================================================
    window.AevorynLoader = (function() {
        const activeTokens = new Set();
        const timeoutMap = new Map();
        const buttonStateMap = new Map();

        function start(opts) {
            opts = opts || {};
            const type = opts.type || 'medium'; // 'short' | 'medium' | 'long' | 'full'
            const message = opts.message || opts.text || (type === 'long' ? 'Synchronizing Digital Twin...' : 'Processing...');
            const token = opts.token || 'req_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6);
            activeTokens.add(token);

            if (type === 'short' && opts.targetBtn) {
                const btn = opts.targetBtn;
                if (!buttonStateMap.has(btn)) {
                    buttonStateMap.set(btn, {
                        html: btn.innerHTML,
                        disabled: btn.disabled
                    });
                    btn.disabled = true;
                    btn.innerHTML = `<span class="spinner-border spinner-border-sm me-1.5" role="status" aria-hidden="true" style="width: 0.85rem; height: 0.85rem; border-width: 2px;"></span> ${opts.text || 'Processing...'}`;
                }
            } else if (type === 'medium') {
                const pill = document.getElementById('aevorynTopProgress');
                const pillText = document.getElementById('aevorynTopProgressText');
                if (pill && pillText) {
                    pillText.textContent = message;
                    pill.style.opacity = '1';
                    pill.style.transform = 'translateX(-50%) translateY(0)';
                    pill.style.pointerEvents = 'auto';
                }
            } else if (type === 'long') {
                const card = document.getElementById('aevorynTaskCard');
                const title = document.getElementById('aevorynTaskCardTitle');
                const msg = document.getElementById('aevorynTaskCardMsg');
                if (card) {
                    if (title) title.textContent = opts.title || 'Digital Twin Operation';
                    if (msg) msg.textContent = message;
                    card.style.opacity = '1';
                    card.style.transform = 'translateY(0)';
                    card.style.pointerEvents = 'auto';
                }
            } else {
                // 'full' executive page overlay
                const overlay = document.getElementById('pageLoadingOverlay');
                const textEl = document.getElementById('pageLoadingText');
                const cancelBtn = document.getElementById('pageLoadingCancelBtn');
                if (overlay) {
                    if (textEl) textEl.textContent = message;
                    if (cancelBtn) cancelBtn.style.display = 'none';
                    overlay.style.opacity = '1';
                    overlay.style.pointerEvents = 'auto';
                    // Show cancel button after 3.5s
                    setTimeout(() => {
                        if (activeTokens.has(token) && cancelBtn) cancelBtn.style.display = 'inline-block';
                    }, 3500);
                }
            }

            // Safety timeout to ensure user is NEVER trapped
            const timeoutMs = opts.timeout || (type === 'long' ? 25000 : 10000);
            const timer = setTimeout(() => {
                console.warn(`[AevorynLoader] Operation token ${token} reached timeout (${timeoutMs}ms). Auto-releasing.`);
                stop(token);
            }, timeoutMs);
            timeoutMap.set(token, timer);

            return token;
        }

        function stop(token) {
            if (token) {
                activeTokens.delete(token);
                if (timeoutMap.has(token)) {
                    clearTimeout(timeoutMap.get(token));
                    timeoutMap.delete(token);
                }
            } else {
                activeTokens.clear();
                timeoutMap.forEach(t => clearTimeout(t));
                timeoutMap.clear();
            }

            // Restore any buttons associated with completed tasks
            buttonStateMap.forEach((orig, btn) => {
                if (btn && btn.isConnected) {
                    btn.innerHTML = orig.html;
                    btn.disabled = orig.disabled;
                }
            });
            buttonStateMap.clear();

            if (activeTokens.size === 0) {
                const overlay = document.getElementById('pageLoadingOverlay');
                if (overlay) {
                    overlay.style.opacity = '0';
                    overlay.style.pointerEvents = 'none';
                }
                const pill = document.getElementById('aevorynTopProgress');
                if (pill) {
                    pill.style.opacity = '0';
                    pill.style.transform = 'translateX(-50%) translateY(-35px)';
                    pill.style.pointerEvents = 'none';
                }
                const card = document.getElementById('aevorynTaskCard');
                if (card) {
                    card.style.opacity = '0';
                    card.style.transform = 'translateY(130%)';
                    card.style.pointerEvents = 'none';
                }
            }
        }

        function dismissTaskCard() {
            const card = document.getElementById('aevorynTaskCard');
            if (card) {
                card.style.opacity = '0';
                card.style.transform = 'translateY(130%)';
                card.style.pointerEvents = 'none';
            }
        }

        return {
            start: start,
            stop: stop,
            dismissTaskCard: dismissTaskCard,
            activeCount: () => activeTokens.size
        };
    })();

    // Backwards compatibility layer
    window.showPageLoading = function(message, type, targetEl) {
        return window.AevorynLoader.start({
            type: type || 'full',
            message: message || 'AEVORYN Twin Sync',
            targetBtn: targetEl
        });
    };

    window.hidePageLoading = function(token) {
        window.AevorynLoader.stop(token);
    };

    // Auto-dismiss on page transitions & navigation restores
    window.addEventListener('pageshow', () => { window.hidePageLoading(); });
    window.addEventListener('popstate', () => { window.hidePageLoading(); });
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'visible') {
            window.hidePageLoading();
        }
    });

    document.addEventListener('DOMContentLoaded', () => {
        window.hidePageLoading();

        // Intercept internal page navigations for smooth transitions
        document.addEventListener('click', (e) => {
            if (e.defaultPrevented) return;
            const link = e.target.closest('a');
            if (!link) return;
            const href = link.getAttribute('href');
            if (!href) return;
            if (href.startsWith('#') || href.startsWith('javascript:') || link.target === '_blank' || 
                link.hasAttribute('download') || link.getAttribute('data-bs-toggle') || 
                link.getAttribute('onclick') || link.hasAttribute('data-no-loader') ||
                href.startsWith('mailto:') || href.startsWith('tel:')) {
                return;
            }

            // Exclude data downloads and exports from full-screen blur
            const isDownloadOrExport = href.includes('export') || href.includes('download') || 
                                       href.includes('template') || /\.(csv|xlsx|xls|pdf|zip|json)$/i.test(href);
            if (isDownloadOrExport) {
                window.AevorynLoader.start({ type: 'medium', text: 'Preparing download...', timeout: 3500 });
                return;
            }

            // Standard page navigation with 6s timeout safety
            window.AevorynLoader.start({ type: 'full', message: 'Navigating...', timeout: 6000 });
        });

        // Intercept standard full-page form submissions ONLY (ignore AJAX/handled forms)
        document.addEventListener('submit', (e) => {
            if (e.defaultPrevented) return;
            const form = e.target;
            if (form.getAttribute('data-async') || form.hasAttribute('data-no-loader') || form.closest('.modal')) return;

            const submitBtn = form.querySelector('button[type="submit"], input[type="submit"]');
            window.AevorynLoader.start({ type: 'medium', text: 'Saving changes...', targetBtn: submitBtn, timeout: 8000 });
        });

        // Auto-inject CSRF token into all POST forms
        const csrfToken = document.querySelector('meta[name="csrf-token"]')?.getAttribute('content');
        if (csrfToken) {
            document.querySelectorAll('form').forEach(form => {
                const method = (form.getAttribute('method') || 'GET').toUpperCase();
                if (method === 'POST' && !form.querySelector('input[name="csrf_token"]')) {
                    const input = document.createElement('input');
                    input.type = 'hidden';
                    input.name = 'csrf_token';
                    input.value = csrfToken;
                    form.appendChild(input);
                }
            });

            // Auto-inject CSRF token into all window.fetch calls
            const originalFetch = window.fetch;
            if (originalFetch) {
                window.fetch = function(url, options) {
                    options = options || {};
                    const method = (options.method || 'GET').toUpperCase();
                    if (!['GET', 'HEAD', 'OPTIONS'].includes(method)) {
                        options.headers = options.headers || {};
                        if (typeof options.headers.set === 'function') {
                            if (!options.headers.has('X-CSRFToken')) options.headers.set('X-CSRFToken', csrfToken);
                        } else if (Array.isArray(options.headers)) {
                            options.headers.push(['X-CSRFToken', csrfToken]);
                        } else {
                            if (!options.headers['X-CSRFToken']) options.headers['X-CSRFToken'] = csrfToken;
                        }
                    }
                    return originalFetch.call(this, url, options);
                };
            }

            // Auto-inject CSRF token into all XMLHttpRequest
            const originalOpen = XMLHttpRequest.prototype.open;
            const originalSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function(method, url) {
                this._method = method;
                return originalOpen.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function(data) {
                if (this._method && !['GET', 'HEAD', 'OPTIONS'].includes(this._method.toUpperCase())) {
                    try {
                        this.setRequestHeader('X-CSRFToken', csrfToken);
                    } catch (e) {}
                }
                return originalSend.apply(this, arguments);
            };
        }
    });

    // ─── Enterprise Logout Lifecycle & Real-Time State Synchronization ───
    window.performEnterpriseLogout = function(e) {
        if (e) e.preventDefault();
        try {
            if (window._aevorynSyncTimer) {
                clearInterval(window._aevorynSyncTimer);
                window._aevorynSyncTimer = null;
            }
            // Clear user-specific cached state in sessionStorage
            sessionStorage.clear();
        } catch (err) {}
        window.showPageLoading();
        window.location.replace("/logout");
        return false;
    };

    // Handle bfcache (Back/Forward Cache) restoration after logout
    window.addEventListener('pageshow', function(event) {
        if (event.persisted) {
            window.location.reload();
        }
    });

    // Real-Time Application-Wide State Synchronizer
    window.syncAevorynRealtimeState = function() {
        fetch('/api/v1/realtime/state', {
            method: 'GET',
            headers: { 'Accept': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
            credentials: 'same-origin'
        })
        .then(res => {
            if (res.status === 401 || res.redirected) {
                return null;
            }
            return res.json();
        })
        .then(data => {
            if (!data || !data.success) return;
            // Synchronize Company Branding & Logo across DOM
            if (data.company) {
                const sbName = document.querySelector('.sidebar-header .company-info h6');
                if (sbName && data.company.name) sbName.textContent = data.company.name;
                const sbLogoImg = document.getElementById('sidebarCompanyLogoImg');
                const sbLogoInit = document.getElementById('sidebarCompanyLogoInitial');
                if (data.company.logo_url) {
                    if (sbLogoImg) {
                        if (sbLogoImg.getAttribute('src') !== data.company.logo_url) {
                            sbLogoImg.src = data.company.logo_url;
                        }
                        sbLogoImg.style.display = 'block';
                    }
                    if (sbLogoInit) sbLogoInit.style.display = 'none';
                }
                const dashLogoImg = document.getElementById('dashboardCompanyLogoImg');
                const dashLogoInit = document.getElementById('dashboardCompanyLogoInitial');
                if (data.company.logo_url && dashLogoImg) {
                    if (dashLogoImg.getAttribute('src') !== data.company.logo_url) {
                        dashLogoImg.src = data.company.logo_url;
                    }
                    dashLogoImg.style.display = 'block';
                    if (dashLogoInit) dashLogoInit.style.display = 'none';
                }
            }
            // Synchronize User Profile Avatar across DOM
            if (data.user) {
                const topAvatarImg = document.getElementById('topbarUserAvatarImg');
                const topAvatarMono = document.getElementById('topbarUserAvatarMonogram');
                if (data.user.avatar_url) {
                    if (topAvatarImg) {
                        if (topAvatarImg.getAttribute('src') !== data.user.avatar_url) {
                            topAvatarImg.src = data.user.avatar_url;
                        }
                        topAvatarImg.style.display = 'inline-block';
                    }
                    if (topAvatarMono) topAvatarMono.style.display = 'none';
                }
            }
            window.dispatchEvent(new CustomEvent('aevoryn:realtime-sync', { detail: data }));
        })
        .catch(() => {});
    };

    
    document.addEventListener('DOMContentLoaded', function() {
        // Poll every 15s and on window focus for cross-tab real-time consistency
        window._aevorynSyncTimer = setInterval(window.syncAevorynRealtimeState, 15000);
        window.addEventListener('focus', window.syncAevorynRealtimeState);
    });
    

    