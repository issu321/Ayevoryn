import sys, os
sys.path.insert(0, os.path.abspath("."))
from app import create_app
from database import db
from database.models.department import Department

app = create_app()
with app.app_context():
    depts = Department.query.filter_by(company_id=2).all()
    palette = {
        "IT": "#2563EB",       # Royal Tech Blue
        "HR": "#10B981",       # Vibrant Emerald Green
        "Finance": "#F59E0B"   # Warm Amber / Gold
    }
    for d in depts:
        if d.name in palette:
            d.color = palette[d.name]
            print(f"Updated {d.name} -> {d.color}")
    db.session.commit()
    print("Database updated successfully.")
