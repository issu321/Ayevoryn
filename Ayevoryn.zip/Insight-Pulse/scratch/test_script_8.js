
// ─── Global Command Palette Controller (Ctrl+K / Cmd+K) ───
let currentCmdQuery = '';

function openCommandPalette() {
  const modalEl = document.getElementById('commandPaletteModal');
  if (modalEl && typeof bootstrap !== 'undefined') {
    const modal = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
    modal.show();
    setTimeout(() => {
      const inp = document.getElementById('cmdPaletteSearchInput');
      if (inp) { inp.value = ''; inp.focus(); filterCommandPalette(''); }
    }, 150);
  }
}

document.addEventListener('keydown', function(e) {
  if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
    e.preventDefault();
    openCommandPalette();
  }
});

function filterCommandPalette(q) {
  currentCmdQuery = (q || '').toLowerCase().trim();
  const items = document.querySelectorAll('#cmdItemsList .cmd-item');
  const catTitles = document.querySelectorAll('#cmdItemsList .cmd-cat-title');
  const fallback = document.getElementById('cmdAiFallback');
  const aiQueryText = document.getElementById('cmdAiQueryText');

  let matchCount = 0;
  items.forEach(item => {
    const searchAttr = (item.getAttribute('data-search') || '').toLowerCase();
    const text = item.textContent.toLowerCase();
    const match = !currentCmdQuery || searchAttr.includes(currentCmdQuery) || text.includes(currentCmdQuery);
    item.style.display = match ? 'flex' : 'none';
    if (match) matchCount++;
  });

  catTitles.forEach(cat => {
    cat.style.display = currentCmdQuery ? 'none' : 'block';
  });

  if (fallback) {
    if (currentCmdQuery) {
      fallback.style.display = 'block';
      if (aiQueryText) aiQueryText.textContent = q;
    } else {
      fallback.style.display = 'none';
    }
  }
}

function handleCmdKeyDown(e) {
  if (e.key === 'Enter') {
    e.preventDefault();
    const visibleItems = Array.from(document.querySelectorAll('#cmdItemsList .cmd-item')).filter(i => i.style.display !== 'none');
    if (visibleItems.length > 0) {
      visibleItems[0].click();
    } else if (currentCmdQuery) {
      askPulseAiFromSearch();
    }
  }
}

function askPulseAiFromSearch() {
  const modalEl = document.getElementById('commandPaletteModal');
  if (modalEl && typeof bootstrap !== 'undefined') {
    const modal = bootstrap.Modal.getInstance(modalEl);
    if (modal) modal.hide();
  }
  if (typeof openPulseAiDrawer === 'function') {
    openPulseAiDrawer();
  } else if (typeof openCopilotDrawer === 'function') {
    openCopilotDrawer();
  }
  setTimeout(() => {
    const inp = document.getElementById('copilotCustomInput');
    if (inp) {
      inp.value = currentCmdQuery;
      if (typeof runCustomCopilotQuery === 'function') runCustomCopilotQuery();
    }
  }, 250);
}
