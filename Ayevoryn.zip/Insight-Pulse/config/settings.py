import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    ENV = os.environ.get('FLASK_ENV', 'development').lower()
    IS_PRODUCTION = ENV in ['production', 'prod']
    
    # Production SECRET_KEY validation: must not use insecure default in production
    _secret = os.environ.get('SECRET_KEY')
    if IS_PRODUCTION and (not _secret or _secret == 'dev-secret-key-change-in-production'):
        raise ValueError("CRITICAL SECURITY ERROR: SECRET_KEY must be set securely in production environment!")
    SECRET_KEY = _secret or 'dev-secret-key-change-in-production'
    
    _db_url = os.environ.get('DATABASE_URL') or 'sqlite:///business_simulator.db'
    if _db_url.startswith('postgres://'):
        _db_url = 'postgresql://' + _db_url[len('postgres://'):]
    SQLALCHEMY_DATABASE_URI = _db_url
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    _is_postgres = _db_url.startswith('postgresql')
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
    }
    if _is_postgres:
        SQLALCHEMY_ENGINE_OPTIONS.update({
            'pool_size': int(os.environ.get('DB_POOL_SIZE', 10)),
            'max_overflow': int(os.environ.get('DB_MAX_OVERFLOW', 20)),
        })
    
    # Upload settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'uploads')
    
    # Session Cookie Security Hardening (Stage 1C)
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SECURE = os.environ.get('SESSION_COOKIE_SECURE', 'true').lower() in ['true', '1'] if IS_PRODUCTION else False
    SESSION_COOKIE_SAMESITE = os.environ.get('SESSION_COOKIE_SAMESITE', 'Lax')
    PERMANENT_SESSION_LIFETIME = int(os.environ.get('SESSION_TIMEOUT') or 3600)
    
    # Global CSRF Protection Settings (Stage 1B)
    WTF_CSRF_ENABLED = True
    WTF_CSRF_CHECK_DEFAULT = True
    WTF_CSRF_TIME_LIMIT = int(os.environ.get('WTF_CSRF_TIME_LIMIT') or 3600)
    WTF_CSRF_HEADERS = ['X-CSRFToken', 'X-CSRF-Token']
    
    # Mail settings
    MAIL_SERVER = os.environ.get('MAIL_SERVER')
    MAIL_PORT = int(os.environ.get('MAIL_PORT') or 587)
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'true').lower() in ['true', 'on', '1']
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD')
    
    # Security settings
    SESSION_TIMEOUT = int(os.environ.get('SESSION_TIMEOUT') or 3600)
    MAX_LOGIN_ATTEMPTS = int(os.environ.get('MAX_LOGIN_ATTEMPTS') or 5)
    LOCKOUT_DURATION = int(os.environ.get('LOCKOUT_DURATION') or 900)
    
    # Cache settings
    CACHE_TYPE = os.environ.get('CACHE_TYPE') or 'simple'
    
    # Default theme
    DEFAULT_THEME = os.environ.get('DEFAULT_THEME') or 'white_clay_glass'
    
    # Pagination
    PER_PAGE = 25
    
    # Application branding
    APP_NAME = 'AEVORYN'
    APP_TAGLINE = 'Enterprise Digital Twin & Decision Intelligence'
    APP_VERSION = '2.4.0'
    BUILD_DATE = '2026-09-14'