# ══════════════════════════════════════════════════════════════════════════
# AEVORYN ENTERPRISE CLAY GLASS THEME SYSTEM
# Exclusively features Light Clay Glass and Modern Dark Clay Glass frameworks
# ══════════════════════════════════════════════════════════════════════════

THEMES = {
    'white_clay_glass': {
        'name': 'Light Clay Glass',
        'color_scheme': 'light',
        'bg_primary': '#F6F8FC',
        'bg_secondary': '#FFFFFF',
        'sidebar_bg': 'rgba(255, 255, 255, 0.85)',
        'topbar_bg': 'rgba(255, 255, 255, 0.82)',
        'accent_primary': '#2563EB',
        'accent_secondary': '#7C3AED',
        'accent_warning': '#D97706',
        'accent_success': '#059669',
        'accent_danger': '#DC2626',
        'text_primary': '#0F172A',
        'text_secondary': '#334155',
        'text_muted': '#64748B',
        'card_bg': 'rgba(255, 255, 255, 0.82)',
        'card_bg_solid': '#FFFFFF',
        'border': 'rgba(226, 232, 240, 0.80)',
        'shadow': '0 10px 28px -4px rgba(15, 23, 42, 0.06), 0 2px 8px -2px rgba(15, 23, 42, 0.03), inset 0 1px 1px rgba(255, 255, 255, 0.95)',
        'gradient': 'linear-gradient(135deg, #F8FAFC 0%, #F1F5F9 50%, #E2E8F0 100%)',
        'aurora': 'radial-gradient(ellipse at 15% 10%, rgba(37,99,235,0.06) 0%, transparent 50%), radial-gradient(ellipse at 85% 85%, rgba(124,58,237,0.05) 0%, transparent 50%), radial-gradient(ellipse at 50% 50%, rgba(16,185,129,0.03) 0%, transparent 60%)',
    },
    'dark_clay_glass': {
        'name': 'Dark Clay Glass',
        'color_scheme': 'dark',
        'bg_primary': '#090A10',
        'bg_secondary': '#11141E',
        'sidebar_bg': 'rgba(12, 14, 22, 0.88)',
        'topbar_bg': 'rgba(12, 14, 22, 0.85)',
        'accent_primary': '#6366F1',
        'accent_secondary': '#8B5CF6',
        'accent_warning': '#F59E0B',
        'accent_success': '#10B981',
        'accent_danger': '#EF4444',
        'text_primary': '#FFFFFF',
        'text_secondary': '#CBD5E1',
        'text_muted': '#94A3B8',
        'card_bg': 'rgba(18, 22, 34, 0.72)',
        'card_bg_solid': '#121522',
        'border': 'rgba(255, 255, 255, 0.08)',
        'shadow': '0 12px 32px -4px rgba(0, 0, 0, 0.45), 0 4px 14px -2px rgba(0, 0, 0, 0.28), inset 0 1px 1px rgba(255, 255, 255, 0.09)',
        'gradient': 'linear-gradient(135deg, #090A10 0%, #11141E 50%, #0D1018 100%)',
        'aurora': 'radial-gradient(ellipse at 15% 10%, rgba(99,102,241,0.08) 0%, transparent 55%), radial-gradient(ellipse at 85% 85%, rgba(139,92,246,0.06) 0%, transparent 55%), radial-gradient(ellipse at 50% 40%, rgba(16,185,129,0.04) 0%, transparent 60%)',
    }
}

LEGACY_THEME_FALLBACKS = {
    'aurora_enterprise': 'dark_clay_glass',
    'midnight_gold': 'dark_clay_glass',
    'arctic_frost': 'dark_clay_glass',
    'neon_cyber': 'dark_clay_glass',
    'solar_flare': 'dark_clay_glass',
    'obsidian_elite': 'dark_clay_glass',
    'forest_zen': 'dark_clay_glass',
    'cosmic_void': 'dark_clay_glass',
}

def resolve_theme_id(theme_id):
    """Normalize any theme_id to either 'white_clay_glass' or 'dark_clay_glass'."""
    if not theme_id:
        return 'white_clay_glass'
    if theme_id in THEMES:
        return theme_id
    if theme_id in LEGACY_THEME_FALLBACKS:
        return LEGACY_THEME_FALLBACKS[theme_id]
    if 'white' in str(theme_id).lower() or 'light' in str(theme_id).lower():
        return 'white_clay_glass'
    return 'dark_clay_glass'

def get_theme_css(theme_id):
    resolved_id = resolve_theme_id(theme_id)
    theme = THEMES[resolved_id]
    hexc = (theme.get('accent_primary') or '#2563EB').lstrip('#')
    try:
        rgb = tuple(int(hexc[i:i+2], 16) for i in (0, 2, 4))
        accent_rgb = f"{rgb[0]}, {rgb[1]}, {rgb[2]}"
    except Exception:
        accent_rgb = "37, 99, 235"
    return f"""
:root {{
    --color-scheme: {theme.get('color_scheme', 'light')};
    --bg-primary: {theme['bg_primary']};
    --bg-secondary: {theme['bg_secondary']};
    --sidebar-bg: {theme.get('sidebar_bg', theme['bg_secondary'])};
    --topbar-bg: {theme.get('topbar_bg', theme['bg_primary'])};
    --accent-primary: {theme['accent_primary']};
    --accent-primary-rgb: {accent_rgb};
    --accent-secondary: {theme['accent_secondary']};
    --accent-warning: {theme['accent_warning']};
    --accent-success: {theme['accent_success']};
    --accent-danger: {theme.get('accent_danger', '#DC2626')};
    --text-primary: {theme['text_primary']};
    --text-secondary: {theme['text_secondary']};
    --text-muted: {theme.get('text_muted', theme['text_secondary'])};
    --card-bg: {theme['card_bg']};
    --card-bg-solid: {theme.get('card_bg_solid', theme['bg_secondary'])};
    --border-color: {theme['border']};
    --shadow: {theme['shadow']};
    --gradient: {theme['gradient']};
    --aurora: {theme['aurora']};
}}
"""
