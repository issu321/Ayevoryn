import os
import sys
import logging

logging.raiseExceptions = False
for _stream in (sys.stdout, sys.stderr):
    try:
        if hasattr(_stream, 'reconfigure'):
            _stream.reconfigure(write_through=True)
    except Exception:
        pass

from app import app

if __name__ == '__main__':
    use_reloader = os.environ.get('FLASK_USE_RELOADER', '0') == '1'
    app.run(host='0.0.0.0', port=5000, debug=True, threaded=True, use_reloader=use_reloader)
